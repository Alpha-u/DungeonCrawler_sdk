// BlueprintGeneratedClass BP_DestructionField.BP_DestructionField_C
// Size: 0x2b8 (Inherited: 0x298)
struct ABP_DestructionField_C : AFieldSystemActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x298(0x08)
	struct URadialVector* RadialVector; // 0x2a0(0x08)
	struct URadialFalloff* RadialFalloff; // 0x2a8(0x08)
	struct USphereComponent* Sphere; // 0x2b0(0x08)

	void ReceiveBeginPlay(); // Function BP_DestructionField.BP_DestructionField_C.ReceiveBeginPlay // (None) // @ game+0xffff8009df830000
};

