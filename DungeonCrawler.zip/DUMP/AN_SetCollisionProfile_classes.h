// BlueprintGeneratedClass AN_SetCollisionProfile.AN_SetCollisionProfile_C
// Size: 0x39 (Inherited: 0x38)
struct UAN_SetCollisionProfile_C : UAnimNotify {
	enum class EMonsterCollisionProfile CollisionProfileName; // 0x38(0x01)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, struct FAnimNotifyEventReference& EventReference); // Function AN_SetCollisionProfile.AN_SetCollisionProfile_C.Received_Notify // (None) // @ game+0xffff8009df830000
};

