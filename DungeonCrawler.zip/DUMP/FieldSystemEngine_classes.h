// Class FieldSystemEngine.FieldSystemActor
// Size: 0x298 (Inherited: 0x290)
struct AFieldSystemActor : AActor {
	struct UFieldSystemComponent* FieldSystemComponent; // 0x290(0x08)
};

// Class FieldSystemEngine.FieldSystem
// Size: 0x38 (Inherited: 0x28)
struct UFieldSystem : UObject {
	char pad_28[0x10]; // 0x28(0x10)
};

// Class FieldSystemEngine.FieldSystemComponent
// Size: 0x610 (Inherited: 0x540)
struct UFieldSystemComponent : UPrimitiveComponent {
	struct UFieldSystem* FieldSystem; // 0x538(0x08)
	bool bIsWorldField; // 0x540(0x01)
	bool bIsChaosField; // 0x541(0x01)
	struct TArray<struct TSoftObjectPtr<AChaosSolverActor>> SupportedSolvers; // 0x548(0x10)
	struct FFieldObjectCommands ConstructionCommands; // 0x558(0x30)
	struct FFieldObjectCommands BufferCommands; // 0x588(0x30)
	char pad_5BA[0x56]; // 0x5ba(0x56)

	void ResetFieldSystem(); // Function FieldSystemEngine.FieldSystemComponent.ResetFieldSystem // (None) // @ game+0xffffc694df830041
};

// Class FieldSystemEngine.FieldSystemMetaData
// Size: 0xa0 (Inherited: 0xa0)
struct UFieldSystemMetaData : UActorComponent {
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x30(0x30)
	struct TArray<struct FName> ComponentTags; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	int32_t UCSSerializationIndex; // 0x84(0x04)
	char pad_F4_0 : 3; // 0xf4(0x01)
	char bNetAddressable : 1; // 0x88(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x88(0x01)
	char bReplicates : 1; // 0x88(0x01)
	char bAutoActivate : 1; // 0x8a(0x01)
	char bIsActive : 1; // 0x8a(0x01)
	char pad_F5_0 : 3; // 0xf5(0x01)
	char bEditableWhenInherited : 1; // 0x8a(0x01)
	char pad_F5_4 : 1; // 0xf5(0x01)
	char bCanEverAffectNavigation : 1; // 0x8a(0x01)
	char pad_F5_6 : 1; // 0xf5(0x01)
	char bIsEditorOnly : 1; // 0x8a(0x01)
	enum class EComponentCreationMethod CreationMethod; // 0x8d(0x01)
	struct FMulticastSparseDelegate OnComponentActivated; // 0x8e(0x01)
	struct FMulticastSparseDelegate OnComponentDeactivated; // 0x8f(0x01)
};

// Class FieldSystemEngine.FieldSystemMetaDataIteration
// Size: 0xa8 (Inherited: 0xa0)
struct UFieldSystemMetaDataIteration : UFieldSystemMetaData {
	int32_t Iterations; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)

	struct UFieldSystemMetaDataIteration* SetMetaDataIteration(int32_t Iterations); // Function FieldSystemEngine.FieldSystemMetaDataIteration.SetMetaDataIteration // (None) // @ game+0xffffc695df830041
};

// Class FieldSystemEngine.FieldSystemMetaDataProcessingResolution
// Size: 0xa8 (Inherited: 0xa0)
struct UFieldSystemMetaDataProcessingResolution : UFieldSystemMetaData {
	enum class EFieldResolutionType ResolutionType; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)

	struct UFieldSystemMetaDataProcessingResolution* SetMetaDataaProcessingResolutionType(enum class EFieldResolutionType ResolutionType); // Function FieldSystemEngine.FieldSystemMetaDataProcessingResolution.SetMetaDataaProcessingResolutionType // (None) // @ game+0xffffc696df830041
};

// Class FieldSystemEngine.FieldSystemMetaDataFilter
// Size: 0xa8 (Inherited: 0xa0)
struct UFieldSystemMetaDataFilter : UFieldSystemMetaData {
	enum class EFieldFilterType FilterType; // 0xa0(0x01)
	enum class EFieldObjectType ObjectType; // 0xa1(0x01)
	enum class EFieldPositionType PositionType; // 0xa2(0x01)
	char pad_A3[0x5]; // 0xa3(0x05)

	struct UFieldSystemMetaDataFilter* SetMetaDataFilterType(enum class EFieldFilterType FilterType, enum class EFieldObjectType ObjectType, enum class EFieldPositionType PositionType); // Function FieldSystemEngine.FieldSystemMetaDataFilter.SetMetaDataFilterType // (None) // @ game+0xffffc697df830041
};

// Class FieldSystemEngine.FieldNodeBase
// Size: 0xa0 (Inherited: 0xa0)
struct UFieldNodeBase : UActorComponent {
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x30(0x30)
	struct TArray<struct FName> ComponentTags; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	int32_t UCSSerializationIndex; // 0x84(0x04)
	char pad_F4_0 : 3; // 0xf4(0x01)
	char bNetAddressable : 1; // 0x88(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x88(0x01)
	char bReplicates : 1; // 0x88(0x01)
	char bAutoActivate : 1; // 0x8a(0x01)
	char bIsActive : 1; // 0x8a(0x01)
	char pad_F5_0 : 3; // 0xf5(0x01)
	char bEditableWhenInherited : 1; // 0x8a(0x01)
	char pad_F5_4 : 1; // 0xf5(0x01)
	char bCanEverAffectNavigation : 1; // 0x8a(0x01)
	char pad_F5_6 : 1; // 0xf5(0x01)
	char bIsEditorOnly : 1; // 0x8a(0x01)
	enum class EComponentCreationMethod CreationMethod; // 0x8d(0x01)
	struct FMulticastSparseDelegate OnComponentActivated; // 0x8e(0x01)
	struct FMulticastSparseDelegate OnComponentDeactivated; // 0x8f(0x01)
};

// Class FieldSystemEngine.FieldNodeInt
// Size: 0xa0 (Inherited: 0xa0)
struct UFieldNodeInt : UFieldNodeBase {
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x30(0x30)
	struct TArray<struct FName> ComponentTags; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	int32_t UCSSerializationIndex; // 0x84(0x04)
	char pad_F4_0 : 3; // 0xf4(0x01)
	char bNetAddressable : 1; // 0x88(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x88(0x01)
	char bReplicates : 1; // 0x88(0x01)
	char bAutoActivate : 1; // 0x8a(0x01)
	char bIsActive : 1; // 0x8a(0x01)
	char pad_F5_0 : 3; // 0xf5(0x01)
	char bEditableWhenInherited : 1; // 0x8a(0x01)
	char pad_F5_4 : 1; // 0xf5(0x01)
	char bCanEverAffectNavigation : 1; // 0x8a(0x01)
	char pad_F5_6 : 1; // 0xf5(0x01)
	char bIsEditorOnly : 1; // 0x8a(0x01)
	enum class EComponentCreationMethod CreationMethod; // 0x8d(0x01)
	struct FMulticastSparseDelegate OnComponentActivated; // 0x8e(0x01)
	struct FMulticastSparseDelegate OnComponentDeactivated; // 0x8f(0x01)
};

// Class FieldSystemEngine.FieldNodeFloat
// Size: 0xa0 (Inherited: 0xa0)
struct UFieldNodeFloat : UFieldNodeBase {
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x30(0x30)
	struct TArray<struct FName> ComponentTags; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	int32_t UCSSerializationIndex; // 0x84(0x04)
	char pad_F4_0 : 3; // 0xf4(0x01)
	char bNetAddressable : 1; // 0x88(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x88(0x01)
	char bReplicates : 1; // 0x88(0x01)
	char bAutoActivate : 1; // 0x8a(0x01)
	char bIsActive : 1; // 0x8a(0x01)
	char pad_F5_0 : 3; // 0xf5(0x01)
	char bEditableWhenInherited : 1; // 0x8a(0x01)
	char pad_F5_4 : 1; // 0xf5(0x01)
	char bCanEverAffectNavigation : 1; // 0x8a(0x01)
	char pad_F5_6 : 1; // 0xf5(0x01)
	char bIsEditorOnly : 1; // 0x8a(0x01)
	enum class EComponentCreationMethod CreationMethod; // 0x8d(0x01)
	struct FMulticastSparseDelegate OnComponentActivated; // 0x8e(0x01)
	struct FMulticastSparseDelegate OnComponentDeactivated; // 0x8f(0x01)
};

// Class FieldSystemEngine.FieldNodeVector
// Size: 0xa0 (Inherited: 0xa0)
struct UFieldNodeVector : UFieldNodeBase {
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x30(0x30)
	struct TArray<struct FName> ComponentTags; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	int32_t UCSSerializationIndex; // 0x84(0x04)
	char pad_F4_0 : 3; // 0xf4(0x01)
	char bNetAddressable : 1; // 0x88(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x88(0x01)
	char bReplicates : 1; // 0x88(0x01)
	char bAutoActivate : 1; // 0x8a(0x01)
	char bIsActive : 1; // 0x8a(0x01)
	char pad_F5_0 : 3; // 0xf5(0x01)
	char bEditableWhenInherited : 1; // 0x8a(0x01)
	char pad_F5_4 : 1; // 0xf5(0x01)
	char bCanEverAffectNavigation : 1; // 0x8a(0x01)
	char pad_F5_6 : 1; // 0xf5(0x01)
	char bIsEditorOnly : 1; // 0x8a(0x01)
	enum class EComponentCreationMethod CreationMethod; // 0x8d(0x01)
	struct FMulticastSparseDelegate OnComponentActivated; // 0x8e(0x01)
	struct FMulticastSparseDelegate OnComponentDeactivated; // 0x8f(0x01)
};

// Class FieldSystemEngine.UniformInteger
// Size: 0xa8 (Inherited: 0xa0)
struct UUniformInteger : UFieldNodeInt {
	int32_t Magnitude; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)

	struct UUniformInteger* SetUniformInteger(int32_t Magnitude); // Function FieldSystemEngine.UniformInteger.SetUniformInteger // (None) // @ game+0xffffc698df830041
};

// Class FieldSystemEngine.RadialIntMask
// Size: 0xd0 (Inherited: 0xa0)
struct URadialIntMask : UFieldNodeInt {
	float Radius; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)
	struct FVector Position; // 0xa8(0x18)
	int32_t InteriorValue; // 0xc0(0x04)
	int32_t ExteriorValue; // 0xc4(0x04)
	enum class ESetMaskConditionType SetMaskCondition; // 0xc8(0x01)
	char pad_C9[0x7]; // 0xc9(0x07)

	struct URadialIntMask* SetRadialIntMask(float Radius, struct FVector Position, int32_t InteriorValue, int32_t ExteriorValue, enum class ESetMaskConditionType SetMaskConditionIn); // Function FieldSystemEngine.RadialIntMask.SetRadialIntMask // (None) // @ game+0xffffc699df830041
};

// Class FieldSystemEngine.UniformScalar
// Size: 0xa8 (Inherited: 0xa0)
struct UUniformScalar : UFieldNodeFloat {
	float Magnitude; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)

	struct UUniformScalar* SetUniformScalar(float Magnitude); // Function FieldSystemEngine.UniformScalar.SetUniformScalar // (None) // @ game+0xffffc69adf830041
};

// Class FieldSystemEngine.WaveScalar
// Size: 0xd0 (Inherited: 0xa0)
struct UWaveScalar : UFieldNodeFloat {
	float Magnitude; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)
	struct FVector Position; // 0xa8(0x18)
	float WaveLength; // 0xc0(0x04)
	float Period; // 0xc4(0x04)
	enum class EWaveFunctionType Function; // 0xc8(0x01)
	enum class EFieldFalloffType Falloff; // 0xc9(0x01)
	char pad_CA[0x6]; // 0xca(0x06)

	struct UWaveScalar* SetWaveScalar(float Magnitude, struct FVector Position, float WaveLength, float Period, float Time, enum class EWaveFunctionType Function, enum class EFieldFalloffType Falloff); // Function FieldSystemEngine.WaveScalar.SetWaveScalar // (None) // @ game+0xffffc69bdf830041
};

// Class FieldSystemEngine.RadialFalloff
// Size: 0xd8 (Inherited: 0xa0)
struct URadialFalloff : UFieldNodeFloat {
	float Magnitude; // 0xa0(0x04)
	float MinRange; // 0xa4(0x04)
	float MaxRange; // 0xa8(0x04)
	float Default; // 0xac(0x04)
	float Radius; // 0xb0(0x04)
	char pad_B4[0x4]; // 0xb4(0x04)
	struct FVector Position; // 0xb8(0x18)
	enum class EFieldFalloffType Falloff; // 0xd0(0x01)
	char pad_D1[0x7]; // 0xd1(0x07)

	struct URadialFalloff* SetRadialFalloff(float Magnitude, float MinRange, float MaxRange, float Default, float Radius, struct FVector Position, enum class EFieldFalloffType Falloff); // Function FieldSystemEngine.RadialFalloff.SetRadialFalloff // (None) // @ game+0xffffc69cdf830041
};

// Class FieldSystemEngine.PlaneFalloff
// Size: 0xf0 (Inherited: 0xa0)
struct UPlaneFalloff : UFieldNodeFloat {
	float Magnitude; // 0xa0(0x04)
	float MinRange; // 0xa4(0x04)
	float MaxRange; // 0xa8(0x04)
	float Default; // 0xac(0x04)
	float Distance; // 0xb0(0x04)
	char pad_B4[0x4]; // 0xb4(0x04)
	struct FVector Position; // 0xb8(0x18)
	struct FVector Normal; // 0xd0(0x18)
	enum class EFieldFalloffType Falloff; // 0xe8(0x01)
	char pad_E9[0x7]; // 0xe9(0x07)

	struct UPlaneFalloff* SetPlaneFalloff(float Magnitude, float MinRange, float MaxRange, float Default, float Distance, struct FVector Position, struct FVector Normal, enum class EFieldFalloffType Falloff); // Function FieldSystemEngine.PlaneFalloff.SetPlaneFalloff // (None) // @ game+0xffffc69ddf830041
};

// Class FieldSystemEngine.BoxFalloff
// Size: 0x120 (Inherited: 0xa0)
struct UBoxFalloff : UFieldNodeFloat {
	float Magnitude; // 0xa0(0x04)
	float MinRange; // 0xa4(0x04)
	float MaxRange; // 0xa8(0x04)
	float Default; // 0xac(0x04)
	struct FTransform Transform; // 0xb0(0x60)
	enum class EFieldFalloffType Falloff; // 0x110(0x01)
	char pad_111[0xf]; // 0x111(0x0f)

	struct UBoxFalloff* SetBoxFalloff(float Magnitude, float MinRange, float MaxRange, float Default, struct FTransform Transform, enum class EFieldFalloffType Falloff); // Function FieldSystemEngine.BoxFalloff.SetBoxFalloff // (None) // @ game+0xffffc69edf830041
};

// Class FieldSystemEngine.NoiseField
// Size: 0x110 (Inherited: 0xa0)
struct UNoiseField : UFieldNodeFloat {
	float MinRange; // 0xa0(0x04)
	float MaxRange; // 0xa4(0x04)
	char pad_A8[0x8]; // 0xa8(0x08)
	struct FTransform Transform; // 0xb0(0x60)

	struct UNoiseField* SetNoiseField(float MinRange, float MaxRange, struct FTransform Transform); // Function FieldSystemEngine.NoiseField.SetNoiseField // (None) // @ game+0xffffc69fdf830041
};

// Class FieldSystemEngine.UniformVector
// Size: 0xc0 (Inherited: 0xa0)
struct UUniformVector : UFieldNodeVector {
	float Magnitude; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)
	struct FVector Direction; // 0xa8(0x18)

	struct UUniformVector* SetUniformVector(float Magnitude, struct FVector Direction); // Function FieldSystemEngine.UniformVector.SetUniformVector // (None) // @ game+0xffffc6a0df830041
};

// Class FieldSystemEngine.RadialVector
// Size: 0xc0 (Inherited: 0xa0)
struct URadialVector : UFieldNodeVector {
	float Magnitude; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)
	struct FVector Position; // 0xa8(0x18)

	struct URadialVector* SetRadialVector(float Magnitude, struct FVector Position); // Function FieldSystemEngine.RadialVector.SetRadialVector // (None) // @ game+0xffffc6a1df830041
};

// Class FieldSystemEngine.RandomVector
// Size: 0xa8 (Inherited: 0xa0)
struct URandomVector : UFieldNodeVector {
	float Magnitude; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)

	struct URandomVector* SetRandomVector(float Magnitude); // Function FieldSystemEngine.RandomVector.SetRandomVector // (None) // @ game+0xffffc6a2df830041
};

// Class FieldSystemEngine.OperatorField
// Size: 0xc0 (Inherited: 0xa0)
struct UOperatorField : UFieldNodeBase {
	float Magnitude; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)
	struct UFieldNodeBase* RightField; // 0xa8(0x08)
	struct UFieldNodeBase* LeftField; // 0xb0(0x08)
	enum class EFieldOperationType Operation; // 0xb8(0x01)
	char pad_B9[0x7]; // 0xb9(0x07)

	struct UOperatorField* SetOperatorField(float Magnitude, struct UFieldNodeBase* LeftField, struct UFieldNodeBase* RightField, enum class EFieldOperationType Operation); // Function FieldSystemEngine.OperatorField.SetOperatorField // (None) // @ game+0xffffc6a3df830041
};

// Class FieldSystemEngine.ToIntegerField
// Size: 0xa8 (Inherited: 0xa0)
struct UToIntegerField : UFieldNodeInt {
	struct UFieldNodeFloat* FloatField; // 0xa0(0x08)

	struct UToIntegerField* SetToIntegerField(struct UFieldNodeFloat* FloatField); // Function FieldSystemEngine.ToIntegerField.SetToIntegerField // (None) // @ game+0xffffc6a4df830041
};

// Class FieldSystemEngine.ToFloatField
// Size: 0xa8 (Inherited: 0xa0)
struct UToFloatField : UFieldNodeFloat {
	struct UFieldNodeInt* IntField; // 0xa0(0x08)

	struct UToFloatField* SetToFloatField(struct UFieldNodeInt* IntegerField); // Function FieldSystemEngine.ToFloatField.SetToFloatField // (None) // @ game+0xffffc6a5df830041
};

// Class FieldSystemEngine.CullingField
// Size: 0xb8 (Inherited: 0xa0)
struct UCullingField : UFieldNodeBase {
	struct UFieldNodeBase* Culling; // 0xa0(0x08)
	struct UFieldNodeBase* Field; // 0xa8(0x08)
	enum class EFieldCullingOperationType Operation; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)

	struct UCullingField* SetCullingField(struct UFieldNodeBase* Culling, struct UFieldNodeBase* Field, enum class EFieldCullingOperationType Operation); // Function FieldSystemEngine.CullingField.SetCullingField // (None) // @ game+0xffffc6a6df830041
};

// Class FieldSystemEngine.ReturnResultsTerminal
// Size: 0xa0 (Inherited: 0xa0)
struct UReturnResultsTerminal : UFieldNodeBase {
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x30(0x30)
	struct TArray<struct FName> ComponentTags; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	int32_t UCSSerializationIndex; // 0x84(0x04)
	char pad_F4_0 : 3; // 0xf4(0x01)
	char bNetAddressable : 1; // 0x88(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x88(0x01)
	char bReplicates : 1; // 0x88(0x01)
	char bAutoActivate : 1; // 0x8a(0x01)
	char bIsActive : 1; // 0x8a(0x01)
	char pad_F5_0 : 3; // 0xf5(0x01)
	char bEditableWhenInherited : 1; // 0x8a(0x01)
	char pad_F5_4 : 1; // 0xf5(0x01)
	char bCanEverAffectNavigation : 1; // 0x8a(0x01)
	char pad_F5_6 : 1; // 0xf5(0x01)
	char bIsEditorOnly : 1; // 0x8a(0x01)
	enum class EComponentCreationMethod CreationMethod; // 0x8d(0x01)
	struct FMulticastSparseDelegate OnComponentActivated; // 0x8e(0x01)
	struct FMulticastSparseDelegate OnComponentDeactivated; // 0x8f(0x01)

	struct UReturnResultsTerminal* SetReturnResultsTerminal(); // Function FieldSystemEngine.ReturnResultsTerminal.SetReturnResultsTerminal // (None) // @ game+0xffffc6a7df830041
};

