// Class CinematicCamera.CineCameraSettings
// Size: 0xb0 (Inherited: 0x38)
struct UCineCameraSettings : UDeveloperSettings {
	struct FString DefaultLensPresetName; // 0x38(0x10)
	float DefaultLensFocalLength; // 0x48(0x04)
	float DefaultLensFStop; // 0x4c(0x04)
	struct TArray<struct FNamedLensPreset> LensPresets; // 0x50(0x10)
	struct FString DefaultFilmbackPreset; // 0x60(0x10)
	struct TArray<struct FNamedFilmbackPreset> FilmbackPresets; // 0x70(0x10)
	struct FString DefaultCropPresetName; // 0x80(0x10)
	struct TArray<struct FNamedPlateCropPreset> CropPresets; // 0x90(0x10)
	char pad_A0[0x10]; // 0xa0(0x10)

	void SetLensPresets(struct TArray<struct FNamedLensPreset>& InLensPresets); // Function CinematicCamera.CineCameraSettings.SetLensPresets // (None) // @ game+0xffffc847df830041
};

// Class CinematicCamera.CameraRig_Crane
// Size: 0x2c0 (Inherited: 0x290)
struct ACameraRig_Crane : AActor {
	float CranePitch; // 0x290(0x04)
	float CraneYaw; // 0x294(0x04)
	float CraneArmLength; // 0x298(0x04)
	bool bLockMountPitch; // 0x29c(0x01)
	bool bLockMountYaw; // 0x29d(0x01)
	char pad_29E[0x2]; // 0x29e(0x02)
	struct USceneComponent* TransformComponent; // 0x2a0(0x08)
	struct USceneComponent* CraneYawControl; // 0x2a8(0x08)
	struct USceneComponent* CranePitchControl; // 0x2b0(0x08)
	struct USceneComponent* CraneCameraMount; // 0x2b8(0x08)
};

// Class CinematicCamera.CameraRig_Rail
// Size: 0x2b0 (Inherited: 0x290)
struct ACameraRig_Rail : AActor {
	float CurrentPositionOnRail; // 0x290(0x04)
	bool bLockOrientationToRail; // 0x294(0x01)
	char pad_295[0x3]; // 0x295(0x03)
	struct USceneComponent* TransformComponent; // 0x298(0x08)
	struct USplineComponent* RailSplineComponent; // 0x2a0(0x08)
	struct USceneComponent* RailCameraMount; // 0x2a8(0x08)

	struct USplineComponent* GetRailSplineComponent(); // Function CinematicCamera.CameraRig_Rail.GetRailSplineComponent // (None) // @ game+0xffffc848df830041
};

// Class CinematicCamera.CineCameraActor
// Size: 0xa20 (Inherited: 0x9a0)
struct ACineCameraActor : ACameraActor {
	struct FCameraLookatTrackingSettings LookatTrackingSettings; // 0x9a0(0x70)
	char pad_A10[0x10]; // 0xa10(0x10)

	struct UCineCameraComponent* GetCineCameraComponent(); // Function CinematicCamera.CineCameraActor.GetCineCameraComponent // (None) // @ game+0xffffc84adf830041
};

// Class CinematicCamera.CineCameraComponent
// Size: 0xb50 (Inherited: 0xa30)
struct UCineCameraComponent : UCameraComponent {
	struct FCameraFilmbackSettings FilmbackSettings; // 0xa30(0x0c)
	struct FCameraFilmbackSettings Filmback; // 0xa3c(0x0c)
	struct FCameraLensSettings LensSettings; // 0xa48(0x1c)
	char pad_A64[0x4]; // 0xa64(0x04)
	struct FCameraFocusSettings FocusSettings; // 0xa68(0x68)
	struct FPlateCropSettings CropSettings; // 0xad0(0x04)
	float CurrentFocalLength; // 0xad4(0x04)
	float CurrentAperture; // 0xad8(0x04)
	float CurrentFocusDistance; // 0xadc(0x04)
	char bOverride_CustomNearClippingPlane : 1; // 0xae0(0x01)
	char pad_AE0_1 : 7; // 0xae0(0x01)
	char pad_AE1[0x3]; // 0xae1(0x03)
	float CustomNearClippingPlane; // 0xae4(0x04)
	char pad_AE8[0x8]; // 0xae8(0x08)
	struct TArray<struct FNamedFilmbackPreset> FilmbackPresets; // 0xaf0(0x10)
	struct TArray<struct FNamedLensPreset> LensPresets; // 0xb00(0x10)
	struct FString DefaultFilmbackPresetName; // 0xb10(0x10)
	struct FString DefaultFilmbackPreset; // 0xb20(0x10)
	struct FString DefaultLensPresetName; // 0xb30(0x10)
	float DefaultLensFocalLength; // 0xb40(0x04)
	float DefaultLensFStop; // 0xb44(0x04)
	char pad_B48[0x8]; // 0xb48(0x08)

	void SetLensSettings(struct FCameraLensSettings& NewLensSettings); // Function CinematicCamera.CineCameraComponent.SetLensSettings // (None) // @ game+0xffffc868df830041
};

