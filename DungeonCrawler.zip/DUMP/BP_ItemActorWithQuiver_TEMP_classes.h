// BlueprintGeneratedClass BP_ItemActorWithQuiver_TEMP.BP_ItemActorWithQuiver_TEMP_C
// Size: 0x5c4 (Inherited: 0x578)
struct ABP_ItemActorWithQuiver_TEMP_C : ABP_DCItemActor_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x578(0x08)
	struct USkeletalMesh* QuiverMesh; // 0x580(0x08)
	struct FName QuiverAttachSocket; // 0x588(0x08)
	struct USkeletalMeshComponent* QuiverSkeletalMeshComponent; // 0x590(0x08)
	struct FName QuiverSheathAttachSocket; // 0x598(0x08)
	struct TArray<struct FName> ArrowSocketNames; // 0x5a0(0x10)
	int32_t CurrentAmmoCount; // 0x5b0(0x04)
	struct FName ItemEquippedLeftSocketName; // 0x5b4(0x08)
	struct FName ItemEquippedRightSocketName; // 0x5bc(0x08)

	void AttachQuiverMeshComponentToSocket(struct FName InSocketName); // Function BP_ItemActorWithQuiver_TEMP.BP_ItemActorWithQuiver_TEMP_C.AttachQuiverMeshComponentToSocket // (NetRequest|Native|Event|NetMulticast|UbergraphFunction|Delegate|NetServer|DLLImport|BlueprintCallable|BlueprintEvent|EditorOnly|NetValidate) // @ game+0xffff8206f4b5f500
};

