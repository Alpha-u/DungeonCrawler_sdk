// BlueprintGeneratedClass BP_RogueCowl.BP_RogueCowl_C
// Size: 0x578 (Inherited: 0x578)
struct ABP_RogueCowl_C : ABP_DCItemActor_C {
	struct UDCAkComponent* DCAk; // 0x570(0x08)
};

