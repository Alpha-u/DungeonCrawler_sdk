// BlueprintGeneratedClass BP_PortraitCharacter.BP_PortraitCharacter_C
// Size: 0x6c8 (Inherited: 0x6b0)
struct ABP_PortraitCharacter_C : ADCPortraitCharacter {
	struct USpotLightComponent* SpotLight; // 0x6b0(0x08)
	struct UPointLightComponent* PointLight; // 0x6b8(0x08)
	struct USceneCaptureComponent2D* SceneCaptureComponent2D; // 0x6c0(0x08)
};

