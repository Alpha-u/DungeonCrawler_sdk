// BlueprintGeneratedClass BP_PhysicalItemHolder.BP_PhysicalItemHolder_C
// Size: 0x400 (Inherited: 0x3e0)
struct ABP_PhysicalItemHolder_C : ASkeletalMeshItemHolderActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3e0(0x08)
	struct FPrimaryAssetId ItemIdToSpawn; // 0x3e8(0x10)
	double PhysicsSleepTime; // 0x3f8(0x08)

	void UserConstructionScript(); // Function BP_PhysicalItemHolder.BP_PhysicalItemHolder_C.UserConstructionScript // (None) // @ game+0x7d72dfab0003
};

