// BlueprintGeneratedClass BP_SimpleChestSmall_N.BP_SimpleChestSmall_N_C
// Size: 0x538 (Inherited: 0x520)
struct ABP_SimpleChestSmall_N_C : ABP_Chest_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x520(0x08)
	struct UDCGeometryCollectionComponent* GC_WoodChestSmall_Default; // 0x528(0x08)
	struct UDCGeometryCollectionComponent* GC_WoodChestSmall_Open; // 0x530(0x08)

	void ReceiveBeginPlay(); // Function BP_SimpleChestSmall_N.BP_SimpleChestSmall_N_C.ReceiveBeginPlay // (None) // @ game+0x105e5dfab0001
};

