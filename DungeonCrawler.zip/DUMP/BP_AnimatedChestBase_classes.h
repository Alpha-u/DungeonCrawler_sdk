// BlueprintGeneratedClass BP_AnimatedChestBase.BP_AnimatedChestBase_C
// Size: 0x4a0 (Inherited: 0x488)
struct ABP_AnimatedChestBase_C : ABP_PropsActorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x488(0x08)
	struct UExpandableInventoryComponent* ExpandableInventory; // 0x490(0x08)
	struct UItemRandomGenerateComponent* ItemRandomGenerate; // 0x498(0x08)

	void InteractSucceed(struct AActor* Interacter, struct FGameplayTag StateTag, struct FGameplayTag TriggerTag, struct FHitResult HitResult); // Function BP_AnimatedChestBase.BP_AnimatedChestBase_C.InteractSucceed // (None) // @ game+0xe941df8487a8
};

