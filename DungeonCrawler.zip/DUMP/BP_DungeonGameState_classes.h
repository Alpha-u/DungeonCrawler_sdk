// BlueprintGeneratedClass BP_DungeonGameState.BP_DungeonGameState_C
// Size: 0x808 (Inherited: 0x800)
struct ABP_DungeonGameState_C : ADCDungeonGameState {
	struct USceneComponent* DefaultSceneRoot; // 0x800(0x08)
};

