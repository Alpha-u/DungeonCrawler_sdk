// BlueprintGeneratedClass BTD_ProbabilitySuccess.BTD_ProbabilitySuccess_C
// Size: 0xe0 (Inherited: 0xa0)
struct UBTD_ProbabilitySuccess_C : UBTDecorator_BlueprintBase {
	double SuccessRatio; // 0xa0(0x08)
	double RandomRatio; // 0xa8(0x08)
	struct FName FloatValue; // 0xb0(0x08)
	struct FBlackboardKeySelector BlackboardKey; // 0xb8(0x28)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_ProbabilitySuccess.BTD_ProbabilitySuccess_C.PerformConditionCheckAI // (None) // @ game+0xae63dfab0001
};

