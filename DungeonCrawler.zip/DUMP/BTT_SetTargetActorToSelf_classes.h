// BlueprintGeneratedClass BTT_SetTargetActorToSelf.BTT_SetTargetActorToSelf_C
// Size: 0xb8 (Inherited: 0xa8)
struct UBTT_SetTargetActorToSelf_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct FName Key Name; // 0xb0(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_SetTargetActorToSelf.BTT_SetTargetActorToSelf_C.ReceiveExecuteAI // (None) // @ game+0xffff8115df830004
};

