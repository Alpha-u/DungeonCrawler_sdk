// BlueprintGeneratedClass GA_ChestLargeOpen.GA_ChestLargeOpen_C
// Size: 0x588 (Inherited: 0x588)
struct UGA_ChestLargeOpen_C : UGA_ChestOpen_C {
	struct TSoftObjectPtr<UAnimMontage> MontageToPlay; // 0x558(0x30)
};

