// BlueprintGeneratedClass BP_DCMonsterBase.BP_DCMonsterBase_C
// Size: 0xc28 (Inherited: 0xbe0)
struct ABP_DCMonsterBase_C : ADCMonsterBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xbe0(0x08)
	struct UDCAkComponent* DCAk; // 0xbe8(0x08)
	struct UExpandableInventoryComponent* ExpandableInventory; // 0xbf0(0x08)
	struct UInteractableTargetComponent* InteractableTarget; // 0xbf8(0x08)
	struct UItemRandomGenerateComponent* ItemRandomGenerate; // 0xc00(0x08)
	double AudibleDistance; // 0xc08(0x08)
	struct UAkAudioEvent* MonsterFootsteps; // 0xc10(0x08)
	struct TArray<struct FPrimaryAssetId> InteractSettingArray; // 0xc18(0x10)

	void OnMessageReceived_BD0C56DE4311A2D9C82D2C927A275C83(struct UMsgBaseNode* ProxyObject); // Function BP_DCMonsterBase.BP_DCMonsterBase_C.OnMessageReceived_BD0C56DE4311A2D9C82D2C927A275C83 // (None) // @ game+0x8c30dfab0001
};

