// BlueprintGeneratedClass DCUIFunctionLibrary.DCUIFunctionLibrary_C
// Size: 0x28 (Inherited: 0x28)
struct UDCUIFunctionLibrary_C : UBlueprintFunctionLibrary {

	void GetSemicircleSelectedIndexByInputDirection(struct FVector2D Direction, double SectionDegreeSize, struct UObject* __WorldContext, int32_t& RadialIndex); // Function DCUIFunctionLibrary.DCUIFunctionLibrary_C.GetSemicircleSelectedIndexByInputDirection // (None) // @ game+0x12490dfab0001
};

