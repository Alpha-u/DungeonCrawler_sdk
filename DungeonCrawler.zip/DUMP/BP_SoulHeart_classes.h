// BlueprintGeneratedClass BP_SoulHeart.BP_SoulHeart_C
// Size: 0x588 (Inherited: 0x578)
struct ABP_SoulHeart_C : ABP_DCItemActor_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x578(0x08)
	struct UNiagaraComponent* P_BlueFire_StMesh; // 0x580(0x08)

	void ItemDataUpdated(struct FItemData& InItemData); // Function BP_SoulHeart.BP_SoulHeart_C.ItemDataUpdated // (None) // @ game+0x121b2dfab0001
};

