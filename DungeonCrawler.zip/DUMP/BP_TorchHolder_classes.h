// BlueprintGeneratedClass BP_TorchHolder.BP_TorchHolder_C
// Size: 0x418 (Inherited: 0x400)
struct ABP_TorchHolder_C : ABP_PhysicalItemHolder_C {
	struct UNiagaraComponent* NS_Util_Torch; // 0x400(0x08)
	struct UPointLightComponent* PointLightFire; // 0x408(0x08)
	struct UPointLightComponent* PointLight; // 0x410(0x08)
};

