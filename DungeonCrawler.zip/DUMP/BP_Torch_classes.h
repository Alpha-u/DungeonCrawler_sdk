// BlueprintGeneratedClass BP_Torch.BP_Torch_C
// Size: 0x5e1 (Inherited: 0x578)
struct ABP_Torch_C : ABP_DCItemActor_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x578(0x08)
	struct UPointLightComponent* PointLightFire; // 0x580(0x08)
	struct UNiagaraComponent* NS_Util_Torch; // 0x588(0x08)
	struct UParticleSystemComponent* ParticleSystem_DEP(NOT VISIBLE); // 0x590(0x08)
	struct UPointLightComponent* PointLight; // 0x598(0x08)
	float Timeline_1______0_7F21B36F49084E2FFFDF24934E6F84E3; // 0x5a0(0x04)
	enum class ETimelineDirection Timeline_1__Direction_7F21B36F49084E2FFFDF24934E6F84E3; // 0x5a4(0x01)
	char pad_5A5[0x3]; // 0x5a5(0x03)
	struct UTimelineComponent* Timeline_2; // 0x5a8(0x08)
	float Timeline_0______0_6145DD0448B5200434111FAC5AB7DB9E; // 0x5b0(0x04)
	enum class ETimelineDirection Timeline_0__Direction_6145DD0448B5200434111FAC5AB7DB9E; // 0x5b4(0x01)
	char pad_5B5[0x3]; // 0x5b5(0x03)
	struct UTimelineComponent* Timeline_1; // 0x5b8(0x08)
	float Turnoff0______0_E26990AB47A70FBFA31C6995236988FE; // 0x5c0(0x04)
	enum class ETimelineDirection Turnoff0__Direction_E26990AB47A70FBFA31C6995236988FE; // 0x5c4(0x01)
	char pad_5C5[0x3]; // 0x5c5(0x03)
	struct UTimelineComponent* Turnoff0; // 0x5c8(0x08)
	float Turnon0______0_2833AFE640BF8DAF2D12378F02141537; // 0x5d0(0x04)
	enum class ETimelineDirection Turnon0__Direction_2833AFE640BF8DAF2D12378F02141537; // 0x5d4(0x01)
	char pad_5D5[0x3]; // 0x5d5(0x03)
	struct UTimelineComponent* Turnon0; // 0x5d8(0x08)
	bool bAttachedSheathSocket; // 0x5e0(0x01)

	void Turnon0__FinishedFunc(); // Function BP_Torch.BP_Torch_C.Turnon0__FinishedFunc // (None) // @ game+0x8443dfab0001
};

