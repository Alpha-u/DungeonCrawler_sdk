// BlueprintGeneratedClass BP_SkeletonChampionShield.BP_SkeletonChampionShield_C
// Size: 0x580 (Inherited: 0x578)
struct ABP_SkeletonChampionShield_C : ABP_DCItemActor_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x578(0x08)

	void GameplayTagUpdated(struct FGameplayTag InGameplayTag, int32_t InCount); // Function BP_SkeletonChampionShield.BP_SkeletonChampionShield_C.GameplayTagUpdated // (None) // @ game+0xffff8009df830000
};

