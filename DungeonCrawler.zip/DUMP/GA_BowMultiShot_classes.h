// BlueprintGeneratedClass GA_BowMultiShot.GA_BowMultiShot_C
// Size: 0x5e8 (Inherited: 0x5c0)
struct UGA_BowMultiShot_C : UGA_MultiShotBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5c0(0x08)
	double AngleValue; // 0x5c8(0x08)
	struct FVector EndTraceLocation; // 0x5d0(0x18)

	void OnSuccess_AD00B3DA4CDB4D669E483EA55702AB02(struct AActor* ProjectileActor); // Function GA_BowMultiShot.GA_BowMultiShot_C.OnSuccess_AD00B3DA4CDB4D669E483EA55702AB02 // (None) // @ game+0x8c24dfab0001
};

