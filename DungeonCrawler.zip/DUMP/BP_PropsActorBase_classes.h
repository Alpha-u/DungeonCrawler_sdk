// BlueprintGeneratedClass BP_PropsActorBase.BP_PropsActorBase_C
// Size: 0x488 (Inherited: 0x3c0)
struct ABP_PropsActorBase_C : APropsActorBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3c0(0x08)
	struct UDCAkComponent* DCAk; // 0x3c8(0x08)
	struct USceneComponent* Root; // 0x3d0(0x08)
	struct UGeometryCollectionComponent* SelectedGeometryCollection; // 0x3d8(0x08)
	bool bDesturctOnBegin; // 0x3e0(0x01)
	char pad_3E1[0x7]; // 0x3e1(0x07)
	struct TMap<struct FGameplayTag, struct UGeometryCollectionComponent*> MatchGeometryCollection; // 0x3e8(0x50)
	struct ABP_DestructionField_C* DestructionField; // 0x438(0x08)
	struct FGameplayTag DestructionSound; // 0x440(0x08)
	bool HideGC; // 0x448(0x01)
	char pad_449[0x7]; // 0x449(0x07)
	double HideGCDelay; // 0x450(0x08)
	struct FVector CustomImpactPoint; // 0x458(0x18)
	struct FVector ImpactPoint; // 0x470(0x18)

	void FindNavModifier(struct TArray<struct UNavModifierComponent*>& Results); // Function BP_PropsActorBase.BP_PropsActorBase_C.FindNavModifier // (Net|NetReliableEvent|NetResponse|UbergraphFunction|Public|NetServer|NetClient|BlueprintCallable|BlueprintPure|EditorOnly|Const|NetValidate) // @ game+0x3ac3dfab0008
};

