// BlueprintGeneratedClass GA_BowQuickShot.GA_BowQuickShot_C
// Size: 0x5d0 (Inherited: 0x5c8)
struct UGA_BowQuickShot_C : UGA_BowQuickShotBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5c8(0x08)

	void AbilityActivated(struct FGameplayEventData TriggerEventData); // Function GA_BowQuickShot.GA_BowQuickShot_C.AbilityActivated // (None) // @ game+0x7ea9dfab0008
};

