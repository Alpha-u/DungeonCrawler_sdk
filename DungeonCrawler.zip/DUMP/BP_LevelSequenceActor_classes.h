// BlueprintGeneratedClass BP_LevelSequenceActor.BP_LevelSequenceActor_C
// Size: 0x340 (Inherited: 0x328)
struct ABP_LevelSequenceActor_C : ADCLevelSequenceActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x328(0x08)
	struct UDCGameObjectLinkComponent* DCGameObjectLink; // 0x330(0x08)
	struct FGameplayTag CurEventTag; // 0x338(0x08)

	void BndEvt__BP_LevelSequenceActor_DCGameObjectLink_K2Node_ComponentBoundEvent_0_DCGameObjectLinkComponentGameObjectLinkEvent__DelegateSignature(struct FObjectLinkRequestEvent& RecvEvent, struct UObjectLinkMetaDataBlueprint* SendEventParam); // Function BP_LevelSequenceActor.BP_LevelSequenceActor_C.BndEvt__BP_LevelSequenceActor_DCGameObjectLink_K2Node_ComponentBoundEvent_0_DCGameObjectLinkComponentGameObjectLinkEvent__DelegateSignature // (None) // @ game+0xffff8009df830000
};

