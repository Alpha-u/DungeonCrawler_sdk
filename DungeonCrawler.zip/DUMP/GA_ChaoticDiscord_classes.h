// BlueprintGeneratedClass GA_ChaoticDiscord.GA_ChaoticDiscord_C
// Size: 0x618 (Inherited: 0x610)
struct UGA_ChaoticDiscord_C : UGA_Music_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x610(0x08)

	void OnOverlapBegin(struct AActor* Target); // Function GA_ChaoticDiscord.GA_ChaoticDiscord_C.OnOverlapBegin // (None) // @ game+0xffff8207315a4d90
};

