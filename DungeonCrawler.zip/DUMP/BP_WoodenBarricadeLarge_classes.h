// BlueprintGeneratedClass BP_WoodenBarricadeLarge.BP_WoodenBarricadeLarge_C
// Size: 0x498 (Inherited: 0x488)
struct ABP_WoodenBarricadeLarge_C : ABP_PropsActorBase_C {
	struct UGeometryCollectionComponent* GC_WoodenBarricadeLarge_Default; // 0x488(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x490(0x08)
};

