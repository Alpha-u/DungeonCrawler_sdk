// BlueprintGeneratedClass BP_ProjectileActor.BP_ProjectileActor_C
// Size: 0x6b0 (Inherited: 0x690)
struct ABP_ProjectileActor_C : AProjectileActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x690(0x08)
	struct UNiagaraComponent* Niagara; // 0x698(0x08)
	struct UParticleSystemComponent* TrailParticleSystem; // 0x6a0(0x08)
	struct UAkComponent* Ak; // 0x6a8(0x08)

	void GameplayTagUpdated(struct FGameplayTag InGameplayTag, int32_t InCount); // Function BP_ProjectileActor.BP_ProjectileActor_C.GameplayTagUpdated // (None) // @ game+0x8c13dfab0001
};

