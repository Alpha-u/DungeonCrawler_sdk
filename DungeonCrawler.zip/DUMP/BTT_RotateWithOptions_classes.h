// BlueprintGeneratedClass BTT_RotateWithOptions.BTT_RotateWithOptions_C
// Size: 0x138 (Inherited: 0xa8)
struct UBTT_RotateWithOptions_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	enum class E_RotateOption RotateTo; // 0xb0(0x01)
	enum class EHitBoxType HitBoxType; // 0xb1(0x01)
	char pad_B2[0x6]; // 0xb2(0x06)
	double Angle; // 0xb8(0x08)
	double RotateSpeed; // 0xc0(0x08)
	struct FName TargetActor; // 0xc8(0x08)
	struct FName FloatValue; // 0xd0(0x08)
	struct FVector DestLocation; // 0xd8(0x18)
	struct FRotator DestRotation; // 0xf0(0x18)
	double FinalRotationAngle; // 0x108(0x08)
	struct AAIController* Owner Controller; // 0x110(0x08)
	struct APawn* Controlled Pawn; // 0x118(0x08)
	struct ADCCharacterBase* As DCCharacter Base; // 0x120(0x08)
	struct FName Angle Key; // 0x128(0x08)
	struct AActor*  s  ; // 0x130(0x08)

	void GetFloatRotationValue(); // Function BTT_RotateWithOptions.BTT_RotateWithOptions_C.GetFloatRotationValue // (None) // @ game+0xffff8009df830000
};

