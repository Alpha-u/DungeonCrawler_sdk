// UserDefinedEnum E_RotateOption.E_RotateOption
enum class E_RotateOption : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator2 = 1,
	NewEnumerator3 = 2,
	E_MAX = 3
};

