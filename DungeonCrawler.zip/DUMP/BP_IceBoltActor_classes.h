// BlueprintGeneratedClass BP_IceBoltActor.BP_IceBoltActor_C
// Size: 0x410 (Inherited: 0x410)
struct ABP_IceBoltActor_C : ABP_SpellActor_C {
	struct USceneComponent* DefaultSceneRoot; // 0x408(0x08)
};

