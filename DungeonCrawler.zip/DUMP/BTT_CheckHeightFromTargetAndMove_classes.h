// BlueprintGeneratedClass BTT_CheckHeightFromTargetAndMove.BTT_CheckHeightFromTargetAndMove_C
// Size: 0xd8 (Inherited: 0xa8)
struct UBTT_CheckHeightFromTargetAndMove_C : UBTT_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	double Allowed Height From Target; // 0xb0(0x08)
	struct FName TargetActor; // 0xb8(0x08)
	bool Reached; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
	double Return Value X; // 0xc8(0x08)
	double Return Value Y; // 0xd0(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_CheckHeightFromTargetAndMove.BTT_CheckHeightFromTargetAndMove_C.ReceiveExecuteAI // (None) // @ game+0xffff8009df830000
};

