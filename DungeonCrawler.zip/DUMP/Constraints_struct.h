// Enum Constraints.EHandleEvent
enum class EHandleEvent : uint8 {
	LocalTransformUpdated = 0,
	GlobalTransformUpdated = 1,
	ComponentUpdated = 2,
	Max = 3
};

// ScriptStruct Constraints.ConstraintAndActiveChannel
// Size: 0x138 (Inherited: 0x00)
struct FConstraintAndActiveChannel {
	struct TSoftObjectPtr<UTickableConstraint> Constraint; // 0x00(0x30)
	struct FMovieSceneConstraintChannel ActiveChannel; // 0x30(0x100)
	struct UTickableConstraint* ConstraintCopyToSpawn; // 0x130(0x08)
};

// ScriptStruct Constraints.MovieSceneConstraintChannel
// Size: 0x100 (Inherited: 0x100)
struct FMovieSceneConstraintChannel : FMovieSceneBoolChannel {
	struct TArray<struct FFrameNumber> Times; // 0x50(0x10)
	bool DefaultValue; // 0x60(0x01)
	bool bHasDefaultValue; // 0x61(0x01)
	struct TArray<bool> Values; // 0x68(0x10)
};

// ScriptStruct Constraints.ConstraintTickFunction
// Size: 0x40 (Inherited: 0x28)
struct FConstraintTickFunction : FTickFunction {
	enum class ETickingGroup TickGroup; // 0x08(0x01)
	enum class ETickingGroup EndTickGroup; // 0x09(0x01)
	char bTickEvenWhenPaused : 1; // 0x0a(0x01)
	char bCanEverTick : 1; // 0x0a(0x01)
	char bStartWithTickEnabled : 1; // 0x0a(0x01)
	char bAllowTickOnDedicatedServer : 1; // 0x0a(0x01)
	float TickInterval; // 0x0c(0x04)
	char pad_2E_4 : 4; // 0x2e(0x01)
	char pad_2F[0x11]; // 0x2f(0x11)
};

