// BlueprintGeneratedClass BTD_CheckUseCustomBT.BTD_CheckUseCustomBT_C
// Size: 0xa0 (Inherited: 0xa0)
struct UBTD_CheckUseCustomBT_C : UBTDecorator_BlueprintBase {
	struct AAIController* AIOwner; // 0x68(0x08)
	struct AActor* ActorOwner; // 0x70(0x08)
	struct TArray<struct FName> ObservedKeyNames; // 0x78(0x10)
	char bShowPropertyDetails : 1; // 0x98(0x01)
	char bCheckConditionOnlyBlackBoardChanges : 1; // 0x98(0x01)
	char bIsObservingBB : 1; // 0x98(0x01)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_CheckUseCustomBT.BTD_CheckUseCustomBT_C.PerformConditionCheckAI // (None) // @ game+0xffff8009df830000
};

