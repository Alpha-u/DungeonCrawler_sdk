// BlueprintGeneratedClass BTD_CheckFloatAttributeCondition.BTD_CheckFloatAttributeCondition_C
// Size: 0xe0 (Inherited: 0xa0)
struct UBTD_CheckFloatAttributeCondition_C : UBTDecorator_BlueprintBase {
	bool Get Param Type From Monster BP; // 0xa0(0x01)
	enum class E_FloatAttributeType Param Type; // 0xa1(0x01)
	enum class E_CompareNumber CompareWith; // 0xa2(0x01)
	char pad_A3[0x5]; // 0xa3(0x05)
	double FloatValue; // 0xa8(0x08)
	struct FBlackboardKeySelector BlackboardKey; // 0xb0(0x28)
	struct ABP_DCMonsterBaseWithOptions_C* As BP DCMonster Base With Options; // 0xd8(0x08)

	void Compare Move Speed(double Move Speed, bool& bool); // Function BTD_CheckFloatAttributeCondition.BTD_CheckFloatAttributeCondition_C.Compare Move Speed // (None) // @ game+0xffff8009df830000
};

