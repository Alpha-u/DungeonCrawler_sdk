// UserDefinedEnum BP_DungeonKillLogItemEnum.BP_DungeonKillLogItemEnum
enum class BP_DungeonKillLogItemEnum : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator3 = 2,
	BP_MAX = 3
};

