// BlueprintGeneratedClass BP_DeathSwarm.BP_DeathSwarm_C
// Size: 0x590 (Inherited: 0x510)
struct ABP_DeathSwarm_C : ADeathSwarmBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x510(0x08)
	struct UStaticMeshComponent* SpawnRejectionIndicator; // 0x518(0x08)
	struct UNiagaraComponent* BugSpawner; // 0x520(0x08)
	struct UStaticMeshComponent* ST_Surface_Bug_Swarming_Wavy; // 0x528(0x08)
	struct UStaticMeshComponent* ST_Surface_Bug_Swarming_Surface; // 0x530(0x08)
	struct UStaticMeshComponent* ST_Surface_Inner_Fog; // 0x538(0x08)
	struct UStaticMeshComponent* ST_Surface_Main; // 0x540(0x08)
	struct UMaterialInstanceDynamic* Material_BugSwarming_Wavy; // 0x548(0x08)
	struct UMaterialInstanceDynamic* Material_BugSwarming_Surface; // 0x550(0x08)
	struct UMaterialInstanceDynamic* Material_FieldMain; // 0x558(0x08)
	struct UMaterialInstanceDynamic* Material_InnerFog; // 0x560(0x08)
	double UV Multiplier_X; // 0x568(0x08)
	double UV Multiplier_Y; // 0x570(0x08)
	double BeetleSpawnRate; // 0x578(0x08)
	double Initiail Field Size; // 0x580(0x08)
	double SpawnRejectionRadius; // 0x588(0x08)

	void UserConstructionScript(); // Function BP_DeathSwarm.BP_DeathSwarm_C.UserConstructionScript // (None) // @ game+0xaef5df849f1f
};

