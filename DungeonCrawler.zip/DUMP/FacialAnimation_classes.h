// Class FacialAnimation.AudioCurveSourceComponent
// Size: 0xca0 (Inherited: 0xc60)
struct UAudioCurveSourceComponent : UAudioComponent {
	char pad_C60[0x8]; // 0xc60(0x08)
	struct FName CurveSourceBindingName; // 0xc68(0x08)
	float CurveSyncOffset; // 0xc70(0x04)
	char pad_C74[0x2c]; // 0xc74(0x2c)
};

