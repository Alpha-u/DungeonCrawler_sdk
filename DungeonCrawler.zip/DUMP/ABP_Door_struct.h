// ScriptStruct ABP_Door.ABP_Door_C.AnimBlueprintGeneratedMutableData
// Size: 0x01 (Inherited: 0x01)
struct FAnimBlueprintGeneratedMutableData : FAnimBlueprintMutableData {
};

// ScriptStruct ABP_Door.ABP_Door_C.AnimBlueprintGeneratedConstantData
// Size: 0x130 (Inherited: 0x01)
struct FAnimBlueprintGeneratedConstantData : FAnimBlueprintConstantData {
	char pad_1[0x3]; // 0x01(0x03)
	struct FName __NameProperty_70; // 0x04(0x08)
	struct FName __NameProperty_71; // 0x0c(0x08)
	int32_t __IntProperty_72; // 0x14(0x04)
	struct FName __NameProperty_73; // 0x18(0x08)
	int32_t __IntProperty_74; // 0x20(0x04)
	bool __BoolProperty_75; // 0x24(0x01)
	char pad_25[0x3]; // 0x25(0x03)
	float __FloatProperty_76; // 0x28(0x04)
	struct FInputScaleBiasClampConstants __StructProperty_77; // 0x2c(0x2c)
	float __FloatProperty_78; // 0x58(0x04)
	bool __BoolProperty_79; // 0x5c(0x01)
	enum class EAnimSyncMethod __EnumProperty_80; // 0x5d(0x01)
	enum class EAnimGroupRole __ByteProperty_81; // 0x5e(0x01)
	char pad_5F[0x1]; // 0x5f(0x01)
	struct FName __NameProperty_82; // 0x60(0x08)
	struct FName __NameProperty_83; // 0x68(0x08)
	int32_t __IntProperty_84; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct FAnimNodeFunctionRef __StructProperty_85; // 0x78(0x20)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess; // 0x98(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base; // 0x118(0x18)
};

