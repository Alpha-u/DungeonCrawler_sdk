// BlueprintGeneratedClass BP_Resurrection_Capture_Base.BP_Resurrection_Capture_Base_C
// Size: 0x678 (Inherited: 0x670)
struct ABP_Resurrection_Capture_Base_C : ADCCharacterProduction {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x670(0x08)

	void ReceiveBeginPlay(); // Function BP_Resurrection_Capture_Base.BP_Resurrection_Capture_Base_C.ReceiveBeginPlay // (None) // @ game+0xffffeb66dfab0001
};

