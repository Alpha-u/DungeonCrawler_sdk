// BlueprintGeneratedClass BP_SkeletonCorpse01_N.BP_SkeletonCorpse01_N_C
// Size: 0x530 (Inherited: 0x520)
struct ABP_SkeletonCorpse01_N_C : ABP_Chest_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x520(0x08)
	struct UNavModifierComponent* NavModifier; // 0x528(0x08)

	void ReceiveBeginPlay(); // Function BP_SkeletonCorpse01_N.BP_SkeletonCorpse01_N_C.ReceiveBeginPlay // (None) // @ game+0xffff8009df830000
};

