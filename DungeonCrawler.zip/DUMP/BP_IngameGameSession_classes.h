// BlueprintGeneratedClass BP_IngameGameSession.BP_IngameGameSession_C
// Size: 0x488 (Inherited: 0x488)
struct ABP_IngameGameSession_C : ADCIngameGameSession {
	struct FDCGameplayEffectData RespawnGameplayEffectData; // 0x3a0(0x48)
	struct FPrimaryAssetId MaxPerkSlotCountConstant; // 0x438(0x10)
	struct FPrimaryAssetId MaxSkillSlotCountConstant; // 0x448(0x10)
	struct FPrimaryAssetId AdvPointPlayerKillConstant; // 0x458(0x10)
	struct FPrimaryAssetId AdvPointDungeonDownConstant; // 0x468(0x10)
	struct FPrimaryAssetId ExpPointDungeonDownConstant; // 0x478(0x10)
};

