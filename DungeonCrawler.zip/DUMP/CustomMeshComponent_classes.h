// Class CustomMeshComponent.CustomMeshComponent
// Size: 0x580 (Inherited: 0x570)
struct UCustomMeshComponent : UMeshComponent {
	struct TArray<struct UMaterialInterface*> OverrideMaterials; // 0x538(0x10)
	struct UMaterialInterface* OverlayMaterial; // 0x548(0x08)
	float OverlayMaterialMaxDrawDistance; // 0x550(0x04)
	char bEnableMaterialParameterCaching : 1; // 0x568(0x01)

	bool SetCustomMeshTriangles(struct TArray<struct FCustomMeshTriangle>& Triangles); // Function CustomMeshComponent.CustomMeshComponent.SetCustomMeshTriangles // (None) // @ game+0xffffb865df830041
};

