// BlueprintGeneratedClass BP_LanternProjectile.BP_LanternProjectile_C
// Size: 0x6f8 (Inherited: 0x6c0)
struct ABP_LanternProjectile_C : ABP_ProjectileToSpawnItemHolder_C {
	struct UNiagaraComponent* FXS_Fire_OilLantern_Util; // 0x6c0(0x08)
	struct UPointLightComponent* PointLightFire; // 0x6c8(0x08)
	struct UPointLightComponent* PointLight; // 0x6d0(0x08)
	struct URotatingMovementComponent* RotatingMovement; // 0x6d8(0x08)
	struct FRotator RepRotation; // 0x6e0(0x18)

	void OnRep_RepRotation(); // Function BP_LanternProjectile.BP_LanternProjectile_C.OnRep_RepRotation // (None) // @ game+0x1324adfab0001
};

