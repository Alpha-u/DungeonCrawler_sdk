// BlueprintGeneratedClass BP_RoundShield.BP_RoundShield_C
// Size: 0x588 (Inherited: 0x578)
struct ABP_RoundShield_C : ABP_DCItemActor_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x578(0x08)
	struct UBoxComponent* StuckBox; // 0x580(0x08)

	void GameplayTagUpdated(struct FGameplayTag InGameplayTag, int32_t InCount); // Function BP_RoundShield.BP_RoundShield_C.GameplayTagUpdated // (None) // @ game+0x83f7dfab0001
};

