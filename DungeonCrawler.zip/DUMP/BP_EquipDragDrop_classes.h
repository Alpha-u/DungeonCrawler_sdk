// BlueprintGeneratedClass BP_EquipDragDrop.BP_EquipDragDrop_C
// Size: 0xc0 (Inherited: 0x90)
struct UBP_EquipDragDrop_C : UDragDropOperation {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x90(0x08)
	struct UUserWidget* WidgetReference; // 0x98(0x08)
	struct FVector2D WidgetSize; // 0xa0(0x10)
	struct FVector2D TargetSize; // 0xb0(0x10)

	void ClearOpacity(); // Function BP_EquipDragDrop.BP_EquipDragDrop_C.ClearOpacity // (None) // @ game+0x12dcbdfab0001
};

