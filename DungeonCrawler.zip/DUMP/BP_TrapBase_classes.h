// BlueprintGeneratedClass BP_TrapBase.BP_TrapBase_C
// Size: 0x524 (Inherited: 0x488)
struct ABP_TrapBase_C : ABP_PropsActorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x488(0x08)
	struct UDCSkeletalMeshComponent* Mesh; // 0x490(0x08)
	struct UDCTagCollisionDetectorComponent* DCTagCollisionDetector; // 0x498(0x08)
	struct FAccountDataReplication OwnerAccountDataReplication; // 0x4a0(0x78)
	int32_t DepthIndex; // 0x518(0x04)
	struct FGameplayTag AbilityTriggerTag; // 0x51c(0x08)

	void OnTrapDetectingByInteract(bool IsDetecting); // Function BP_TrapBase.BP_TrapBase_C.OnTrapDetectingByInteract // (None) // @ game+0xffff8009df830000
};

