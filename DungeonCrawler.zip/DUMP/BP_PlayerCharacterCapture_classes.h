// BlueprintGeneratedClass BP_PlayerCharacterCapture.BP_PlayerCharacterCapture_C
// Size: 0x440 (Inherited: 0x418)
struct ABP_PlayerCharacterCapture_C : APlayerCharacterCaptureActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x418(0x08)
	struct UPointLightComponent* PointLight1; // 0x420(0x08)
	struct USpotLightComponent* SpotLight; // 0x428(0x08)
	struct USceneCaptureComponent2D* SceneCaptureComponent2D; // 0x430(0x08)
	struct USpringArmComponent* SpringArm; // 0x438(0x08)

	void OnItemEquipped(struct UAnimationAsset* ItemStandIdle, struct FGameplayTag ItemHandType, struct FGameplayTag ItemSlotType); // Function BP_PlayerCharacterCapture.BP_PlayerCharacterCapture_C.OnItemEquipped // (None) // @ game+0xffff8009dfb2c2d7
};

