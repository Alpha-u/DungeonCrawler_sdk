// BlueprintGeneratedClass BP_ItemDragDrop.BP_ItemDragDrop_C
// Size: 0x180 (Inherited: 0x90)
struct UBP_ItemDragDrop_C : UDragDropOperation {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x90(0x08)
	struct FVector2D WidgetSize; // 0x98(0x10)
	struct FItemData ItemData; // 0xa8(0xa0)
	struct AActor* ItemOwner; // 0x148(0x08)
	struct FVector2D PointSlotOffset; // 0x150(0x10)
	struct FVector2D DragVisualScreenPosition; // 0x160(0x10)
	struct FVector2D DragVisualScreenPosInBag; // 0x170(0x10)

	void Dragged(struct FPointerEvent& PointerEvent); // Function BP_ItemDragDrop.BP_ItemDragDrop_C.Dragged // (None) // @ game+0x12898dfab0001
};

