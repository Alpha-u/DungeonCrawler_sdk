// UserDefinedEnum E_TargetType.E_TargetType
enum class E_TargetType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	E_MAX = 2
};

