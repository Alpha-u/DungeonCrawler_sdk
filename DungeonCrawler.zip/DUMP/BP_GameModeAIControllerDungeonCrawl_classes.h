// BlueprintGeneratedClass BP_GameModeAIControllerDungeonCrawl.BP_GameModeAIControllerDungeonCrawl_C
// Size: 0x4a0 (Inherited: 0x4a0)
struct ABP_GameModeAIControllerDungeonCrawl_C : ADCGameModeAIControllerDungeonCrawlBase {
	struct FPlayerPointData DownPlayerPointData; // 0x430(0x70)
};

