// Class CommonInput.CommonInputActionDomain
// Size: 0x40 (Inherited: 0x30)
struct UCommonInputActionDomain : UDataAsset {
	enum class ECommonInputEventFlowBehavior Behavior; // 0x30(0x04)
	enum class ECommonInputEventFlowBehavior InnerBehavior; // 0x34(0x04)
	bool bUseActionDomainDesiredInputConfig; // 0x38(0x01)
	enum class ECommonInputMode InputMode; // 0x39(0x01)
	enum class EMouseCaptureMode MouseCaptureMode; // 0x3a(0x01)
	char pad_3B[0x5]; // 0x3b(0x05)
};

// Class CommonInput.CommonInputActionDomainTable
// Size: 0x48 (Inherited: 0x30)
struct UCommonInputActionDomainTable : UDataAsset {
	struct TArray<struct UCommonInputActionDomain*> ActionDomains; // 0x30(0x10)
	enum class ECommonInputMode InputMode; // 0x40(0x01)
	enum class EMouseCaptureMode MouseCaptureMode; // 0x41(0x01)
	char pad_42[0x6]; // 0x42(0x06)
};

// Class CommonInput.CommonUIInputData
// Size: 0x48 (Inherited: 0x28)
struct UCommonUIInputData : UObject {
	struct FDataTableRowHandle DefaultClickAction; // 0x28(0x10)
	struct FDataTableRowHandle DefaultBackAction; // 0x38(0x10)
};

// Class CommonInput.CommonInputBaseControllerData
// Size: 0x110 (Inherited: 0x28)
struct UCommonInputBaseControllerData : UObject {
	enum class ECommonInputType InputType; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	struct FName GamepadName; // 0x2c(0x08)
	char pad_34[0x4]; // 0x34(0x04)
	struct FText GamepadDisplayName; // 0x38(0x18)
	struct FText GamepadCategory; // 0x50(0x18)
	struct FText GamepadPlatformName; // 0x68(0x18)
	struct TArray<struct FInputDeviceIdentifierPair> GamepadHardwareIdMapping; // 0x80(0x10)
	struct TSoftObjectPtr<UTexture2D> ControllerTexture; // 0x90(0x30)
	struct TSoftObjectPtr<UTexture2D> ControllerButtonMaskTexture; // 0xc0(0x30)
	struct TArray<struct FCommonInputKeyBrushConfiguration> InputBrushDataMap; // 0xf0(0x10)
	struct TArray<struct FCommonInputKeySetBrushConfiguration> InputBrushKeySets; // 0x100(0x10)

	struct TArray<struct FName> GetRegisteredGamepads(); // Function CommonInput.CommonInputBaseControllerData.GetRegisteredGamepads // (None) // @ game+0xffffb20cdf830041
};

// Class CommonInput.CommonInputPlatformSettings
// Size: 0x70 (Inherited: 0x40)
struct UCommonInputPlatformSettings : UPlatformSettings {
	enum class ECommonInputType DefaultInputType; // 0x40(0x01)
	bool bSupportsMouseAndKeyboard; // 0x41(0x01)
	bool bSupportsTouch; // 0x42(0x01)
	bool bSupportsGamepad; // 0x43(0x01)
	struct FName DefaultGamepadName; // 0x44(0x08)
	bool bCanChangeGamepadType; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	struct TArray<struct TSoftClassPtr<UObject>> ControllerData; // 0x50(0x10)
	struct TArray<struct UCommonInputBaseControllerData*> ControllerDataClasses; // 0x60(0x10)
};

// Class CommonInput.CommonInputSettings
// Size: 0x130 (Inherited: 0x38)
struct UCommonInputSettings : UDeveloperSettings {
	struct TSoftClassPtr<UObject> InputData; // 0x38(0x30)
	struct FPerPlatformSettings PlatformInput; // 0x68(0x10)
	struct TMap<struct FName, struct FCommonInputPlatformBaseData> CommonInputPlatformData; // 0x78(0x50)
	bool bEnableInputMethodThrashingProtection; // 0xc8(0x01)
	char pad_C9[0x3]; // 0xc9(0x03)
	int32_t InputMethodThrashingLimit; // 0xcc(0x04)
	double InputMethodThrashingWindowInSeconds; // 0xd0(0x08)
	double InputMethodThrashingCooldownInSeconds; // 0xd8(0x08)
	bool bAllowOutOfFocusDeviceInput; // 0xe0(0x01)
	bool bEnableDefaultInputConfig; // 0xe1(0x01)
	char pad_E2[0x6]; // 0xe2(0x06)
	struct TSoftObjectPtr<UCommonInputActionDomainTable> ActionDomainTable; // 0xe8(0x30)
	char pad_118[0x8]; // 0x118(0x08)
	struct UCommonUIInputData* InputDataClass; // 0x120(0x08)
	struct UCommonInputActionDomainTable* ActionDomainTablePtr; // 0x128(0x08)
};

// Class CommonInput.CommonInputSubsystem
// Size: 0x108 (Inherited: 0x30)
struct UCommonInputSubsystem : ULocalPlayerSubsystem {
	char pad_30[0x28]; // 0x30(0x28)
	struct FMulticastInlineDelegate OnInputMethodChanged; // 0x58(0x10)
	int32_t NumberOfInputMethodChangesRecently; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
	double LastInputMethodChangeTime; // 0x70(0x08)
	double LastTimeInputMethodThrashingBegan; // 0x78(0x08)
	enum class ECommonInputType LastInputType; // 0x80(0x01)
	enum class ECommonInputType CurrentInputType; // 0x81(0x01)
	char pad_82[0x2]; // 0x82(0x02)
	struct FName GamepadInputType; // 0x84(0x08)
	char pad_8C[0x4]; // 0x8c(0x04)
	struct TMap<struct FName, enum class ECommonInputType> CurrentInputLocks; // 0x90(0x50)
	char pad_E0[0x18]; // 0xe0(0x18)
	struct UCommonInputActionDomainTable* ActionDomainTable; // 0xf8(0x08)
	bool bIsGamepadSimulatedClick; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)

	bool ShouldShowInputKeys(); // Function CommonInput.CommonInputSubsystem.ShouldShowInputKeys // (None) // @ game+0xffffb214df830041
};

