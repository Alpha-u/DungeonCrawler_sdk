// BlueprintGeneratedClass GA_DCCrouch.GA_DCCrouch_C
// Size: 0x560 (Inherited: 0x558)
struct UGA_DCCrouch_C : UDCGameplayAbilityBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x558(0x08)

	void EventReceived_F8111BF74E13C0F203A0A2A357F51B3A(struct FGameplayTag EventTag, struct FGameplayEventData EventData); // Function GA_DCCrouch.GA_DCCrouch_C.EventReceived_F8111BF74E13C0F203A0A2A357F51B3A // (None) // @ game+0xffff8009df830000
};

