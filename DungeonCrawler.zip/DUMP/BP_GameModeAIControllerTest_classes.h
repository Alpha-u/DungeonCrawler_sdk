// BlueprintGeneratedClass BP_GameModeAIControllerTest.BP_GameModeAIControllerTest_C
// Size: 0x430 (Inherited: 0x430)
struct ABP_GameModeAIControllerTest_C : ADCGameModeAIControllerTestBase {
	struct UAccountLinkAll* AccountLinkAll; // 0x428(0x08)
};

