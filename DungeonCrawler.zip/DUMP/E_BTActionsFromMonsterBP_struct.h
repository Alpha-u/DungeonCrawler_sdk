// UserDefinedEnum E_BTActionsFromMonsterBP.E_BTActionsFromMonsterBP
enum class E_BTActionsFromMonsterBP : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator9 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	E_MAX = 4
};

