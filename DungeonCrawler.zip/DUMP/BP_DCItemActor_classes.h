// BlueprintGeneratedClass BP_DCItemActor.BP_DCItemActor_C
// Size: 0x578 (Inherited: 0x570)
struct ABP_DCItemActor_C : AItemActor {
	struct UDCAkComponent* DCAk; // 0x570(0x08)
};

