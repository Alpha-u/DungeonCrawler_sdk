// BlueprintGeneratedClass BP_Tranquility.BP_Tranquility_C
// Size: 0x3e0 (Inherited: 0x3e0)
struct ABP_Tranquility_C : ABP_MusicActor_C {
	struct USceneComponent* DefaultSceneRoot; // 0x3d8(0x08)
};

