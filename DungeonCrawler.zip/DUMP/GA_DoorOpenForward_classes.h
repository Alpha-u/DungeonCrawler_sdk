// BlueprintGeneratedClass GA_DoorOpenForward.GA_DoorOpenForward_C
// Size: 0x588 (Inherited: 0x588)
struct UGA_DoorOpenForward_C : UGA_ChangeIdle {
	struct TSoftObjectPtr<UAnimMontage> MontageToPlay; // 0x558(0x30)
};

