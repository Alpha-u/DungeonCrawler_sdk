// BlueprintGeneratedClass BP_MagicMissileActor.BP_MagicMissileActor_C
// Size: 0x410 (Inherited: 0x410)
struct ABP_MagicMissileActor_C : ABP_SpellActor_C {
	struct USceneComponent* DefaultSceneRoot; // 0x408(0x08)
};

