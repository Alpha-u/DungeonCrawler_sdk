// BlueprintGeneratedClass BP_Lamp02On.BP_Lamp02On_C
// Size: 0x4d9 (Inherited: 0x488)
struct ABP_Lamp02On_C : ABP_LightSourceBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x488(0x08)
	struct UStaticMeshComponent* SM_wood_support_low_wood_support_low; // 0x490(0x08)
	struct UPointLightComponent* PointLight1; // 0x498(0x08)
	struct UStaticMeshComponent* Torch; // 0x4a0(0x08)
	struct USphereComponent* Sphere; // 0x4a8(0x08)
	struct UParticleSystemComponent* ParticleSystem; // 0x4b0(0x08)
	float Timeline_1______0_880E3B4943383BF3137FBA8105F54BEF; // 0x4b8(0x04)
	enum class ETimelineDirection Timeline_1__Direction_880E3B4943383BF3137FBA8105F54BEF; // 0x4bc(0x01)
	char pad_4BD[0x3]; // 0x4bd(0x03)
	struct UTimelineComponent* Timeline_2; // 0x4c0(0x08)
	float Timeline_0______0_4566267841C10261712DC38A0CE24984; // 0x4c8(0x04)
	enum class ETimelineDirection Timeline_0__Direction_4566267841C10261712DC38A0CE24984; // 0x4cc(0x01)
	char pad_4CD[0x3]; // 0x4cd(0x03)
	struct UTimelineComponent* Timeline_1; // 0x4d0(0x08)
	bool bIsOverlapped; // 0x4d8(0x01)

	void Timeline_0__FinishedFunc(); // Function BP_Lamp02On.BP_Lamp02On_C.Timeline_0__FinishedFunc // (None) // @ game+0x19531dfab0001
};

