// BlueprintGeneratedClass BP_DeathBeetle_Sting.BP_DeathBeetle_Sting_C
// Size: 0x6b0 (Inherited: 0x6b0)
struct ABP_DeathBeetle_Sting_C : ABP_ProjectileActor_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x690(0x08)
	struct UNiagaraComponent* Niagara; // 0x698(0x08)
	struct UParticleSystemComponent* TrailParticleSystem; // 0x6a0(0x08)
	struct UAkComponent* Ak; // 0x6a8(0x08)

	void UserConstructionScript(); // Function BP_DeathBeetle_Sting.BP_DeathBeetle_Sting_C.UserConstructionScript // (None) // @ game+0xffff8009df830000
};

