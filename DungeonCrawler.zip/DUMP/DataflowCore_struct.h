// ScriptStruct DataflowCore.DataflowNode
// Size: 0xd0 (Inherited: 0x00)
struct FDataflowNode {
	char pad_0[0xc8]; // 0x00(0xc8)
	bool bActive; // 0xc8(0x01)
	char pad_C9[0x7]; // 0xc9(0x07)
};

// ScriptStruct DataflowCore.DataflowConnection
// Size: 0x40 (Inherited: 0x00)
struct FDataflowConnection {
	char pad_0[0x40]; // 0x00(0x40)
};

// ScriptStruct DataflowCore.DataflowInput
// Size: 0x48 (Inherited: 0x40)
struct FDataflowInput : FDataflowConnection {
	char pad_40[0x8]; // 0x40(0x08)
};

// ScriptStruct DataflowCore.DataflowOutput
// Size: 0x68 (Inherited: 0x40)
struct FDataflowOutput : FDataflowConnection {
	char pad_40[0x28]; // 0x40(0x28)
};

