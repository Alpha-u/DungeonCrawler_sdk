// BlueprintGeneratedClass BP_Resource.BP_Resource_C
// Size: 0x368 (Inherited: 0x368)
struct UBP_Resource_C : UDCResource {
	struct TMap<enum class EDCGender, struct UDCCharacterPartsArtData*> CharacterPartsDataMap; // 0x28(0x50)
	struct TMap<struct FDCPlayerCharacterKey, struct FDCPlayerCharacterData> PlayerCharacterDataMap; // 0x78(0x50)
	struct TMap<enum class EDCGender, struct TSoftObjectPtr<USoundData>> CharacterSounds; // 0xc8(0x50)
	struct TMap<enum class EDCGender, struct ADCCharacterProduction*> ProductionMap; // 0x118(0x50)
	struct UDCInputConfigData* InputConfigData; // 0x168(0x08)
	struct TArray<struct FMappableConfigPair> MappableConfigPairs; // 0x170(0x10)
	struct UDCContextMenuWidget* ContextMenuWidgetClass; // 0x180(0x08)
	struct TMap<struct FGameplayAttribute, struct FText> AttributeDisplayNameMap; // 0x188(0x50)
	struct FDCMerchantAssetManager MerchantAssetManager; // 0x1d8(0x140)
	struct TMap<enum class EGameDifficultyType, struct TSoftObjectPtr<UWorld>> WaitingMaps; // 0x318(0x50)
};

