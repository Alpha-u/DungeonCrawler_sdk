// Enum CustomizableSequencerTracks.ECustomSequencerTrackType
enum class ECustomSequencerTrackType : uint8 {
	MasterTrack = 0,
	ObjectTrack = 1,
	ECustomSequencerTrackType_MAX = 2
};

// ScriptStruct CustomizableSequencerTracks.SequencerTrackInstanceInput
// Size: 0x70 (Inherited: 0x00)
struct FSequencerTrackInstanceInput {
	struct USequencerSectionBP* Section; // 0x00(0x08)
	char pad_8[0x68]; // 0x08(0x68)
};

