// BlueprintGeneratedClass BP_SkeletonMage_Common.BP_SkeletonMage_Common_C
// Size: 0x11d4 (Inherited: 0x1140)
struct ABP_SkeletonMage_Common_C : ABP_DCMonsterBaseWithOptions_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1140(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox9; // 0x1148(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox8; // 0x1150(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox7; // 0x1158(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox6; // 0x1160(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox5; // 0x1168(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox4; // 0x1170(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox3; // 0x1178(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox2; // 0x1180(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox1; // 0x1188(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox; // 0x1190(0x08)
	struct FName Key Name; // 0x1198(0x08)
	struct UObject* BarrierTarget; // 0x11a0(0x08)
	struct TArray<struct FPrimaryAssetId> In Gameplay Effect Id Array; // 0x11a8(0x10)
	double BeforeBarrierHealth; // 0x11b8(0x08)
	struct ABP_DCMonsterBase_C* As BP DCMonster Base; // 0x11c0(0x08)
	struct FName Probability; // 0x11c8(0x08)
	int32_t Count; // 0x11d0(0x04)

	void OnSetAI(); // Function BP_SkeletonMage_Common.BP_SkeletonMage_Common_C.OnSetAI // (None) // @ game+0xffff8207154051e0
};

