// Class AssetTags.AssetTagsSubsystem
// Size: 0x30 (Inherited: 0x30)
struct UAssetTagsSubsystem : UEngineSubsystem {

	struct TArray<struct FName> K2_GetCollectionsContainingAsset(struct FSoftObjectPath& AssetPath); // Function AssetTags.AssetTagsSubsystem.K2_GetCollectionsContainingAsset // (None) // @ game+0xffffb856df830041
};

