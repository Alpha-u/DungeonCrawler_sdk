// BlueprintGeneratedClass BP_GameObjectLinker.BP_GameObjectLinker_C
// Size: 0x308 (Inherited: 0x300)
struct ABP_GameObjectLinker_C : ADCGameObjectLinker {
	struct USceneComponent* DefaultSceneRoot; // 0x300(0x08)
};

