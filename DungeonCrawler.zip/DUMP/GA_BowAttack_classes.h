// BlueprintGeneratedClass GA_BowAttack.GA_BowAttack_C
// Size: 0x5e0 (Inherited: 0x5d8)
struct UGA_BowAttack_C : UGA_BowAttackBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5d8(0x08)

	void AbilityActivated(struct FGameplayEventData TriggerEventData); // Function GA_BowAttack.GA_BowAttack_C.AbilityActivated // (None) // @ game+0xffff8009df830000
};

