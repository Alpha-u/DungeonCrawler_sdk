// Class ChainPlugin.ChainComponent
// Size: 0x740 (Inherited: 0x570)
struct UChainComponent : UMeshComponent {
	struct FMulticastInlineDelegate onSoundReached; // 0x570(0x10)
	struct FMulticastInlineDelegate onCollide; // 0x580(0x10)
	struct UStaticMesh* chainMesh; // 0x590(0x08)
	struct FVector Scale; // 0x598(0x18)
	int32_t Segments; // 0x5b0(0x04)
	char pad_5B4[0x4]; // 0x5b4(0x04)
	struct FVector additiveRotation; // 0x5b8(0x18)
	float ChainLength; // 0x5d0(0x04)
	bool bIsLocal; // 0x5d4(0x01)
	char pad_5D5[0x3]; // 0x5d5(0x03)
	struct FVector endPoint; // 0x5d8(0x18)
	bool attachStart; // 0x5f0(0x01)
	char pad_5F1[0x7]; // 0x5f1(0x07)
	struct FComponentReference attachStartTo; // 0x5f8(0x28)
	struct FName attachStartToSocket; // 0x620(0x08)
	bool attachEnd; // 0x628(0x01)
	char pad_629[0x7]; // 0x629(0x07)
	struct FComponentReference attachEndTo; // 0x630(0x28)
	struct FName attachEndToSocket; // 0x658(0x08)
	struct FComponentReference attachComponentToStart; // 0x660(0x28)
	bool rotateStartAttachment; // 0x688(0x01)
	char pad_689[0x7]; // 0x689(0x07)
	struct FComponentReference attachComponentToEnd; // 0x690(0x28)
	bool rotateEndAttachment; // 0x6b8(0x01)
	char pad_6B9[0x3]; // 0x6b9(0x03)
	float Gravity; // 0x6bc(0x04)
	int32_t Stiffness; // 0x6c0(0x04)
	float Friction; // 0x6c4(0x04)
	float chainWidth; // 0x6c8(0x04)
	bool selfCollision; // 0x6cc(0x01)
	char pad_6CD[0x3]; // 0x6cd(0x03)
	float selfCollisionWidth; // 0x6d0(0x04)
	float selfCollisionThreshold; // 0x6d4(0x04)
	int32_t Skip; // 0x6d8(0x04)
	bool drawDebugger; // 0x6dc(0x01)
	char pad_6DD[0x3]; // 0x6dd(0x03)
	struct UInstancedStaticMeshComponent* instanceComponent; // 0x6e0(0x08)
	float soundThreshold; // 0x6e8(0x04)
	int32_t soundSkip; // 0x6ec(0x04)
	char pad_6F0[0x50]; // 0x6f0(0x50)

	struct FVector getChainPoint(int32_t Index); // Function ChainPlugin.ChainComponent.getChainPoint // (None) // @ game+0xffffb34ddf830041
};

// Class ChainPlugin.SplineChainComponent
// Size: 0x7d0 (Inherited: 0x740)
struct USplineChainComponent : UChainComponent {
	struct FRuntimeFloatCurve SplineFollowWeight; // 0x738(0x88)
	struct USplineComponent* SplineComponent; // 0x7c0(0x08)
};

