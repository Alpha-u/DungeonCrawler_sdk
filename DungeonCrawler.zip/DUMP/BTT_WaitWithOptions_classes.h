// BlueprintGeneratedClass BTT_WaitWithOptions.BTT_WaitWithOptions_C
// Size: 0xd0 (Inherited: 0xa8)
struct UBTT_WaitWithOptions_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct FName FloatValue; // 0xb0(0x08)
	bool Use Float From BlackBoard; // 0xb8(0x01)
	bool Use Float From Monster BP; // 0xb9(0x01)
	char pad_BA[0x6]; // 0xba(0x06)
	double ManualWaitTime1; // 0xc0(0x08)
	double ManualWaitTime2; // 0xc8(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_WaitWithOptions.BTT_WaitWithOptions_C.ReceiveExecuteAI // (None) // @ game+0xffff8059df830048
};

