// BlueprintGeneratedClass BTD_CheckTarget.BTD_CheckTarget_C
// Size: 0x140 (Inherited: 0xa0)
struct UBTD_CheckTarget_C : UBTDecorator_BlueprintBase {
	struct ABP_DCMonsterBaseWithOptions_C* ControlledPawn; // 0xa0(0x08)
	struct UAIPerceptionComponent* AIPerception; // 0xa8(0x08)
	struct UBlackboardComponent* Blackboard; // 0xb0(0x08)
	struct TArray<struct ADCCharacterBase*> TargetArray; // 0xb8(0x10)
	struct FName TargetActor; // 0xc8(0x08)
	bool Find BlackBoard TargetActor; // 0xd0(0x01)
	enum class E_SensorType Get List From; // 0xd1(0x01)
	bool Player; // 0xd2(0x01)
	bool Monster; // 0xd3(0x01)
	bool Get from Combat Area; // 0xd4(0x01)
	bool FilterSpawnLocation; // 0xd5(0x01)
	char pad_D6[0x2]; // 0xd6(0x02)
	double Filter Distance from Spawn Location; // 0xd8(0x08)
	struct TArray<struct FGameplayTag> Tags; // 0xe0(0x10)
	struct TArray<struct FGameplayTag> Untags; // 0xf0(0x10)
	bool Get ActivityArea From Monster BP; // 0x100(0x01)
	enum class E_ActivityArea Activity Area; // 0x101(0x01)
	char pad_102[0x6]; // 0x102(0x06)
	double MinDistance; // 0x108(0x08)
	enum class E_DistanceFromVariables MaxDistanceFrom; // 0x110(0x01)
	char pad_111[0x7]; // 0x111(0x07)
	double MaxDistance; // 0x118(0x08)
	double Angle; // 0x120(0x08)
	double Direction; // 0x128(0x08)
	double MinHP; // 0x130(0x08)
	double MaxHP; // 0x138(0x08)

	void ClearVariables(); // Function BTD_CheckTarget.BTD_CheckTarget_C.ClearVariables // (None) // @ game+0xffff8009df830040
};

