// BlueprintGeneratedClass BP_Fireflies.BP_Fireflies_C
// Size: 0x2c0 (Inherited: 0x290)
struct ABP_Fireflies_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct UPointLightComponent* PointLight; // 0x298(0x08)
	struct UNiagaraComponent* FXS_Env_Fireflies_01; // 0x2a0(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x2a8(0x08)
	float Timeline_NewTrack_0_DB59D52241CD8465E5FD67ABFC261504; // 0x2b0(0x04)
	enum class ETimelineDirection Timeline__Direction_DB59D52241CD8465E5FD67ABFC261504; // 0x2b4(0x01)
	char pad_2B5[0x3]; // 0x2b5(0x03)
	struct UTimelineComponent* Timeline; // 0x2b8(0x08)

	void Timeline__FinishedFunc(); // Function BP_Fireflies.BP_Fireflies_C.Timeline__FinishedFunc // (None) // @ game+0x12146dfab0001
};

