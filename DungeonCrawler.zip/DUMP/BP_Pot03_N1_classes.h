// BlueprintGeneratedClass BP_Pot03_N1.BP_Pot03_N1_C
// Size: 0x4b0 (Inherited: 0x4b0)
struct ABP_Pot03_N1_C : ABP_PotBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x488(0x08)
	struct UDCGeometryCollectionComponent* GC_PotBase_Default; // 0x490(0x08)
	struct UExpandableInventoryComponent* ExpandableInventory; // 0x498(0x08)
	struct UItemRandomGenerateComponent* ItemRandomGenerate; // 0x4a0(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x4a8(0x08)
};

