// BlueprintGeneratedClass BTT_MoveWithOptions.BTT_MoveWithOptions_C
// Size: 0x172 (Inherited: 0xa8)
struct UBTT_MoveWithOptions_C : UBTT_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	double Acceptance Radius; // 0xb0(0x08)
	double StopTime; // 0xb8(0x08)
	enum class E_TargetTypeToMove DestinationType; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
	double DestAngle; // 0xc8(0x08)
	double DestDistance; // 0xd0(0x08)
	enum class EHitBoxType HitBoxType; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
	double CheckEnemyTick; // 0xe0(0x08)
	struct FName TargetActor; // 0xe8(0x08)
	struct FName TargetLocation; // 0xf0(0x08)
	struct FName BlackBoardDistance; // 0xf8(0x08)
	struct AAIController* Owner Controller; // 0x100(0x08)
	struct APawn* Controlled Pawn; // 0x108(0x08)
	struct ABP_DCMonsterBaseWithOptions_C* As BP DCMonster Base; // 0x110(0x08)
	struct FVector Destination; // 0x118(0x18)
	double MaxDistance RandomMove; // 0x130(0x08)
	double CheckEnemyDistance; // 0x138(0x08)
	struct TArray<struct ADCCharacterBase*> TargetArray; // 0x140(0x10)
	struct FTimerHandle TimerHandleNearEnemy; // 0x150(0x08)
	struct FTimerHandle TimerHandleFollowUnRechableTarget; // 0x158(0x08)
	struct FTimerHandle TimerHandleInvisibleTarget; // 0x160(0x08)
	struct AActor* ValidTargetActor; // 0x168(0x08)
	bool Result; // 0x170(0x01)
	bool Reachable; // 0x171(0x01)

	void Check Invisible Target(); // Function BTT_MoveWithOptions.BTT_MoveWithOptions_C.Check Invisible Target // (None) // @ game+0xffff8669df830640
};

