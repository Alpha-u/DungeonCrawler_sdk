// AnimBlueprintGeneratedClass ABP_PlayerCharacterResurrection.ABP_PlayerCharacterResurrection_C
// Size: 0x4b8 (Inherited: 0x350)
struct UABP_PlayerCharacterResurrection_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x350(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess; // 0x358(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base; // 0x360(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x368(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x388(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x3d0(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x3f0(0xc8)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_PlayerCharacterResurrection.ABP_PlayerCharacterResurrection_C.AnimGraph // (None) // @ game+0x15cb4df870008
};

