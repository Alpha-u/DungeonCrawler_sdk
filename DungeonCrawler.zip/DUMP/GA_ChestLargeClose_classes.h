// BlueprintGeneratedClass GA_ChestLargeClose.GA_ChestLargeClose_C
// Size: 0x588 (Inherited: 0x588)
struct UGA_ChestLargeClose_C : UGA_ChestClose_C {
	struct TSoftObjectPtr<UAnimMontage> MontageToPlay; // 0x558(0x30)
};

