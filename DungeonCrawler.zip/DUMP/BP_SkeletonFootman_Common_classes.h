// BlueprintGeneratedClass BP_SkeletonFootman_Common.BP_SkeletonFootman_Common_C
// Size: 0x1190 (Inherited: 0x1140)
struct ABP_SkeletonFootman_Common_C : ABP_Skeleton_C {
	struct UBP_DCHitBox_C* BP_DCHitBox_Foot_L; // 0x1140(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox_Foot_R; // 0x1148(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox_Upper_Leg_L; // 0x1150(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox_Upper_Leg_R; // 0x1158(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox_Down_Leg_L; // 0x1160(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox_Down_Leg_R; // 0x1168(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox_Body; // 0x1170(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox_Head; // 0x1178(0x08)
	struct TArray<struct ADCCharacterBase*> Target Array_1; // 0x1180(0x10)
};

