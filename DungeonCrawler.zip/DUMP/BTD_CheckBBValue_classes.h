// BlueprintGeneratedClass BTD_CheckBBValue.BTD_CheckBBValue_C
// Size: 0xf8 (Inherited: 0xa0)
struct UBTD_CheckBBValue_C : UBTDecorator_BlueprintBase {
	enum class E_Variables Variable Type; // 0xa0(0x01)
	bool TRUE; // 0xa1(0x01)
	enum class E_CompareNumber Int; // 0xa2(0x01)
	char pad_A3[0x5]; // 0xa3(0x05)
	double Float Value; // 0xa8(0x08)
	int32_t Int Value; // 0xb0(0x04)
	char pad_B4[0x4]; // 0xb4(0x04)
	struct FBlackboardKeySelector Select Key; // 0xb8(0x28)
	struct FName Key Name; // 0xe0(0x08)
	enum class E_LocationVariables Select Vector; // 0xe8(0x01)
	char pad_E9[0x3]; // 0xe9(0x03)
	float Tolerance; // 0xec(0x04)
	struct APawn* Controlled Pawn; // 0xf0(0x08)

	void CompareVectorValue(bool& bool); // Function BTD_CheckBBValue.BTD_CheckBBValue_C.CompareVectorValue // (None) // @ game+0xbd68dfab0001
};

