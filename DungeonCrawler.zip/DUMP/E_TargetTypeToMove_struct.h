// UserDefinedEnum E_TargetTypeToMove.E_TargetTypeToMove
enum class E_TargetTypeToMove : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator5 = 2,
	NewEnumerator3 = 3,
	NewEnumerator4 = 4,
	NewEnumerator2 = 5,
	E_MAX = 6
};

