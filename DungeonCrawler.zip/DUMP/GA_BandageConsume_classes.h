// BlueprintGeneratedClass GA_BandageConsume.GA_BandageConsume_C
// Size: 0x640 (Inherited: 0x640)
struct UGA_BandageConsume_C : UGA_ItemConsume_C {
	struct UAnimMontage* PreConsumeMontage; // 0x558(0x08)
	struct UAnimMontage* ConsumeMontage; // 0x560(0x08)
	struct UAnimMontage* PreConsumeMontageOnSourceObject; // 0x568(0x08)
	struct UAnimMontage* ConsumeMontageOnSourceObject; // 0x570(0x08)
	struct FItemData ItemData; // 0x578(0xa0)
	struct FDesignDataItemConsume ItemConsumeData; // 0x618(0x20)
};

