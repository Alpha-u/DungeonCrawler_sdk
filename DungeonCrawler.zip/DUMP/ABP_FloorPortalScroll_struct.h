// ScriptStruct ABP_FloorPortalScroll.ABP_FloorPortalScroll_C.AnimBlueprintGeneratedMutableData
// Size: 0x01 (Inherited: 0x01)
struct FAnimBlueprintGeneratedMutableData : FAnimBlueprintMutableData {
};

// ScriptStruct ABP_FloorPortalScroll.ABP_FloorPortalScroll_C.AnimBlueprintGeneratedConstantData
// Size: 0x130 (Inherited: 0x01)
struct FAnimBlueprintGeneratedConstantData : FAnimBlueprintConstantData {
	char pad_1[0x3]; // 0x01(0x03)
	struct FName __NameProperty_64; // 0x04(0x08)
	struct FName __NameProperty_65; // 0x0c(0x08)
	int32_t __IntProperty_66; // 0x14(0x04)
	bool __BoolProperty_67; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	struct FName __NameProperty_68; // 0x1c(0x08)
	int32_t __IntProperty_69; // 0x24(0x04)
	float __FloatProperty_70; // 0x28(0x04)
	struct FInputScaleBiasClampConstants __StructProperty_71; // 0x2c(0x2c)
	float __FloatProperty_72; // 0x58(0x04)
	bool __BoolProperty_73; // 0x5c(0x01)
	enum class EAnimSyncMethod __EnumProperty_74; // 0x5d(0x01)
	enum class EAnimGroupRole __ByteProperty_75; // 0x5e(0x01)
	char pad_5F[0x1]; // 0x5f(0x01)
	struct FName __NameProperty_76; // 0x60(0x08)
	struct FName __NameProperty_77; // 0x68(0x08)
	int32_t __IntProperty_78; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct FAnimNodeFunctionRef __StructProperty_79; // 0x78(0x20)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess; // 0x98(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base; // 0x118(0x18)
};

