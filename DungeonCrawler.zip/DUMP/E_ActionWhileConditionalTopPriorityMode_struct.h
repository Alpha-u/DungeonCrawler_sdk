// UserDefinedEnum E_ActionWhileConditionalTopPriorityMode.E_ActionWhileConditionalTopPriorityMode
enum class E_ActionWhileConditionalTopPriorityMode : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	E_MAX = 2
};

