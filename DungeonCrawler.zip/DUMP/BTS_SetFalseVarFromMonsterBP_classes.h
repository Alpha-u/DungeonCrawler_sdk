// BlueprintGeneratedClass BTS_SetFalseVarFromMonsterBP.BTS_SetFalseVarFromMonsterBP_C
// Size: 0xa1 (Inherited: 0x98)
struct UBTS_SetFalseVarFromMonsterBP_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x98(0x08)
	enum class E_BTActionsFromMonsterBP SetBoolVar; // 0xa0(0x01)

	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_SetFalseVarFromMonsterBP.BTS_SetFalseVarFromMonsterBP_C.ReceiveDeactivationAI // (None) // @ game+0xffff8009df830000
};

