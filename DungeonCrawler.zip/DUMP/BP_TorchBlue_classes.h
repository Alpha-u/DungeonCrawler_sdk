// BlueprintGeneratedClass BP_TorchBlue.BP_TorchBlue_C
// Size: 0x5e1 (Inherited: 0x578)
struct ABP_TorchBlue_C : ABP_DCItemActor_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x578(0x08)
	struct UPointLightComponent* PointLightFire; // 0x580(0x08)
	struct UNiagaraComponent* NS_Util_Torch; // 0x588(0x08)
	struct UParticleSystemComponent* ParticleSystem_DEP(NOT VISIBLE); // 0x590(0x08)
	struct UPointLightComponent* PointLight; // 0x598(0x08)
	float Timeline_1______0_A7C156BE4B4A9C2612B9DFA772EB70BB; // 0x5a0(0x04)
	enum class ETimelineDirection Timeline_1__Direction_A7C156BE4B4A9C2612B9DFA772EB70BB; // 0x5a4(0x01)
	char pad_5A5[0x3]; // 0x5a5(0x03)
	struct UTimelineComponent* Timeline_2; // 0x5a8(0x08)
	float Timeline_0______0_5F64C78840F8FA4B631B1DB6EE530C33; // 0x5b0(0x04)
	enum class ETimelineDirection Timeline_0__Direction_5F64C78840F8FA4B631B1DB6EE530C33; // 0x5b4(0x01)
	char pad_5B5[0x3]; // 0x5b5(0x03)
	struct UTimelineComponent* Timeline_1; // 0x5b8(0x08)
	float Turnoff0______0_AE68BD0D41C43DC1B7FDE69DB7DD0769; // 0x5c0(0x04)
	enum class ETimelineDirection Turnoff0__Direction_AE68BD0D41C43DC1B7FDE69DB7DD0769; // 0x5c4(0x01)
	char pad_5C5[0x3]; // 0x5c5(0x03)
	struct UTimelineComponent* Turnoff0; // 0x5c8(0x08)
	float Turnon0______0_593D07734A106DBF653B8EB5E937E825; // 0x5d0(0x04)
	enum class ETimelineDirection Turnon0__Direction_593D07734A106DBF653B8EB5E937E825; // 0x5d4(0x01)
	char pad_5D5[0x3]; // 0x5d5(0x03)
	struct UTimelineComponent* Turnon0; // 0x5d8(0x08)
	bool bAttachedSheathSocket; // 0x5e0(0x01)

	void Turnon0__FinishedFunc(); // Function BP_TorchBlue.BP_TorchBlue_C.Turnon0__FinishedFunc // (None) // @ game+0x1217fdfab0008
};

