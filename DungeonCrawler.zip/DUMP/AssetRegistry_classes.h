// Class AssetRegistry.AssetRegistryHelpers
// Size: 0x28 (Inherited: 0x28)
struct UAssetRegistryHelpers : UObject {

	struct FSoftObjectPath ToSoftObjectPath(struct FAssetData& InAssetData); // Function AssetRegistry.AssetRegistryHelpers.ToSoftObjectPath // (None) // @ game+0xffffc8d3df830041
};

// Class AssetRegistry.AssetRegistry
// Size: 0x28 (Inherited: 0x28)
struct UAssetRegistry : UInterface {

	void WaitForPackage(struct FString PackageName); // Function AssetRegistry.AssetRegistry.WaitForPackage // (None) // @ game+0xffffc8eedf830041
};

// Class AssetRegistry.AssetRegistryImpl
// Size: 0x9c0 (Inherited: 0x28)
struct UAssetRegistryImpl : UObject {
	char pad_28[0x998]; // 0x28(0x998)
};

