// Class CableComponent.CableActor
// Size: 0x298 (Inherited: 0x290)
struct ACableActor : AActor {
	struct UCableComponent* CableComponent; // 0x290(0x08)
};

// Class CableComponent.CableComponent
// Size: 0x620 (Inherited: 0x570)
struct UCableComponent : UMeshComponent {
	bool bAttachStart; // 0x570(0x01)
	bool bAttachEnd; // 0x571(0x01)
	char pad_572[0x6]; // 0x572(0x06)
	struct FComponentReference attachEndTo; // 0x578(0x28)
	struct FName AttachEndToSocketName; // 0x5a0(0x08)
	struct FVector EndLocation; // 0x5a8(0x18)
	float CableLength; // 0x5c0(0x04)
	int32_t NumSegments; // 0x5c4(0x04)
	float SubstepTime; // 0x5c8(0x04)
	int32_t SolverIterations; // 0x5cc(0x04)
	bool bEnableStiffness; // 0x5d0(0x01)
	bool bUseSubstepping; // 0x5d1(0x01)
	bool bSkipCableUpdateWhenNotVisible; // 0x5d2(0x01)
	bool bSkipCableUpdateWhenNotOwnerRecentlyRendered; // 0x5d3(0x01)
	bool bEnableCollision; // 0x5d4(0x01)
	char pad_5D5[0x3]; // 0x5d5(0x03)
	float CollisionFriction; // 0x5d8(0x04)
	char pad_5DC[0x4]; // 0x5dc(0x04)
	struct FVector CableForce; // 0x5e0(0x18)
	float CableGravityScale; // 0x5f8(0x04)
	float CableWidth; // 0x5fc(0x04)
	int32_t NumSides; // 0x600(0x04)
	float TileMaterial; // 0x604(0x04)
	char pad_608[0x18]; // 0x608(0x18)

	void SetAttachEndToComponent(struct USceneComponent* Component, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndToComponent // (None) // @ game+0xffffb862df830041
};

