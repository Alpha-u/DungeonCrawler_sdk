// BlueprintGeneratedClass BP_LanternHolder.BP_LanternHolder_C
// Size: 0x428 (Inherited: 0x400)
struct ABP_LanternHolder_C : ABP_PhysicalItemHolder_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x400(0x08)
	struct UNiagaraComponent* FXS_Fire_OilLantern_Util; // 0x408(0x08)
	struct UNiagaraComponent* NS_Util_Torch; // 0x410(0x08)
	struct UPointLightComponent* PointLightFire; // 0x418(0x08)
	struct UPointLightComponent* PointLight; // 0x420(0x08)

	void ReceiveBeginPlay(); // Function BP_LanternHolder.BP_LanternHolder_C.ReceiveBeginPlay // (None) // @ game+0x8c47dfab0001
};

