// BlueprintGeneratedClass GA_ActivateOnAbilityHandleData.GA_ActivateOnAbilityHandleData_C
// Size: 0x558 (Inherited: 0x558)
struct UGA_ActivateOnAbilityHandleData_C : UDCGameplayAbilityBase {
	struct TArray<struct FDCGameplayEffectContainer> EffectContainerArray; // 0x498(0x10)
	struct TArray<struct FDCGameplayEffectData> OverrideGameplayEffectDataArray; // 0x4a8(0x10)
	struct TArray<struct FActiveGameplayEffectHandle> ActiveEffectHandles; // 0x4b8(0x10)
	struct FGameplayTag IdleAnimSequenceGameplayTag; // 0x4c8(0x08)
	struct UDCMovementModifierContainerData* MovementModifierContainer; // 0x4d0(0x08)
	struct FDesignDataGameplayAbility DesignDataGameplayAbility; // 0x4d8(0x58)
	struct FGameplayTagContainer AppliedMovementModifierTags; // 0x530(0x20)
	bool bIsDefaultMovementModifierApplied; // 0x550(0x01)
};

