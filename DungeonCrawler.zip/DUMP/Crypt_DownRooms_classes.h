// BlueprintGeneratedClass Crypt_DownRooms.Crypt_DownRooms_C
// Size: 0x2a0 (Inherited: 0x298)
struct ACrypt_DownRooms_C : ALevelScriptActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x298(0x08)

	void ReceiveBeginPlay(); // Function Crypt_DownRooms.Crypt_DownRooms_C.ReceiveBeginPlay // (None) // @ game+0xffff8009df830000
};

