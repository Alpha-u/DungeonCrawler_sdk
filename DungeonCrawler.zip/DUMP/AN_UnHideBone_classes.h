// BlueprintGeneratedClass AN_UnHideBone.AN_UnHideBone_C
// Size: 0x40 (Inherited: 0x38)
struct UAN_UnHideBone_C : UAnimNotify {
	struct FName BoneName; // 0x38(0x08)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, struct FAnimNotifyEventReference& EventReference); // Function AN_UnHideBone.AN_UnHideBone_C.Received_Notify // (None) // @ game+0x8c0ddfab0008
};

