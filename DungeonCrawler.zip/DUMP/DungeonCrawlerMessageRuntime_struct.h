// ScriptStruct DungeonCrawlerMessageRuntime.MsgBase
// Size: 0x18 (Inherited: 0x00)
struct FMsgBase {
	char pad_0[0x10]; // 0x00(0x10)
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawlerMessageRuntime.BindMsgNodeArray
// Size: 0x10 (Inherited: 0x00)
struct FBindMsgNodeArray {
	struct TArray<struct UBindMsgNode*> BindMsgNodeArray; // 0x00(0x10)
};

