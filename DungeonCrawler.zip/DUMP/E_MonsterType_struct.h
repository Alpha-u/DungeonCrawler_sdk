// UserDefinedEnum E_MonsterType.E_MonsterType
enum class E_MonsterType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator3 = 2,
	E_MAX = 3
};

