// BlueprintGeneratedClass BP_DCItemPreviewActor.BP_DCItemPreviewActor_C
// Size: 0x348 (Inherited: 0x320)
struct ABP_DCItemPreviewActor_C : ADCItemViewerActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x320(0x08)
	struct UPointLightComponent* PointLight; // 0x328(0x08)
	struct USceneCaptureComponent2D* SceneCaptureComponent2D; // 0x330(0x08)
	struct USpringArmComponent* SpringArm; // 0x338(0x08)
	struct UChildActorComponent* BP_TorchTest; // 0x340(0x08)

	void SetActiveSceneCapture(bool bActive); // Function BP_DCItemPreviewActor.BP_DCItemPreviewActor_C.SetActiveSceneCapture // (None) // @ game+0xffffec12dfab0001
};

