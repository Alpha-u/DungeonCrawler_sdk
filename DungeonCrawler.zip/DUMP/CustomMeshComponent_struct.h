// ScriptStruct CustomMeshComponent.CustomMeshTriangle
// Size: 0x48 (Inherited: 0x00)
struct FCustomMeshTriangle {
	struct FVector Vertex0; // 0x00(0x18)
	struct FVector Vertex1; // 0x18(0x18)
	struct FVector Vertex2; // 0x30(0x18)
};

