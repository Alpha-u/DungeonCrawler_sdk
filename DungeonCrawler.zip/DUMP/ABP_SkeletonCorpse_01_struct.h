// ScriptStruct ABP_SkeletonCorpse_01.ABP_SkeletonCorpse_01_C.AnimBlueprintGeneratedMutableData
// Size: 0x01 (Inherited: 0x01)
struct FAnimBlueprintGeneratedMutableData : FAnimBlueprintMutableData {
};

// ScriptStruct ABP_SkeletonCorpse_01.ABP_SkeletonCorpse_01_C.AnimBlueprintGeneratedConstantData
// Size: 0x120 (Inherited: 0x01)
struct FAnimBlueprintGeneratedConstantData : FAnimBlueprintConstantData {
	char pad_1[0x3]; // 0x01(0x03)
	struct FName __NameProperty_41; // 0x04(0x08)
	struct FName __NameProperty_42; // 0x0c(0x08)
	int32_t __IntProperty_43; // 0x14(0x04)
	bool __BoolProperty_44; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	float __FloatProperty_45; // 0x1c(0x04)
	struct FInputScaleBiasClampConstants __StructProperty_46; // 0x20(0x2c)
	float __FloatProperty_47; // 0x4c(0x04)
	bool __BoolProperty_48; // 0x50(0x01)
	enum class EAnimSyncMethod __EnumProperty_49; // 0x51(0x01)
	enum class EAnimGroupRole __ByteProperty_50; // 0x52(0x01)
	char pad_53[0x1]; // 0x53(0x01)
	struct FName __NameProperty_51; // 0x54(0x08)
	struct FName __NameProperty_52; // 0x5c(0x08)
	int32_t __IntProperty_53; // 0x64(0x04)
	struct FAnimNodeFunctionRef __StructProperty_54; // 0x68(0x20)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess; // 0x88(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base; // 0x108(0x18)
};

