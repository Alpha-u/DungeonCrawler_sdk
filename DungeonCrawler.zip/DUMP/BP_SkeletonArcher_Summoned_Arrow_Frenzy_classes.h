// BlueprintGeneratedClass BP_SkeletonArcher_Summoned_Arrow_Frenzy.BP_SkeletonArcher_Summoned_Arrow_Frenzy_C
// Size: 0x6c0 (Inherited: 0x6b0)
struct ABP_SkeletonArcher_Summoned_Arrow_Frenzy_C : ABP_ProjectileActor_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x6b0(0x08)
	struct UParticleSystemComponent* ParticleSystem_1; // 0x6b8(0x08)

	void GameplayTagUpdated(struct FGameplayTag InGameplayTag, int32_t InCount); // Function BP_SkeletonArcher_Summoned_Arrow_Frenzy.BP_SkeletonArcher_Summoned_Arrow_Frenzy_C.GameplayTagUpdated // (None) // @ game+0xffff8009df830000
};

