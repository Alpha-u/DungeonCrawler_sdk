// UserDefinedEnum E_MonsterGrade.E_MonsterGrade
enum class E_MonsterGrade : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	E_MAX = 3
};

