// BlueprintGeneratedClass BP_WoodenDoorArched.BP_WoodenDoorArched_C
// Size: 0x4e0 (Inherited: 0x4b8)
struct ABP_WoodenDoorArched_C : ABP_DoorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4b8(0x08)
	struct UDCGeometryCollectionComponent* GC_WoodenDoorWithLock_Open_Backward; // 0x4c0(0x08)
	struct UDCGeometryCollectionComponent* GC_WoodenDoorWithLock_Open_Forward; // 0x4c8(0x08)
	struct UDCGeometryCollectionComponent* GC_WoodenDoorWithLock_Default; // 0x4d0(0x08)
	struct UArrowComponent* Arrow; // 0x4d8(0x08)

	void ReceiveBeginPlay(); // Function BP_WoodenDoorArched.BP_WoodenDoorArched_C.ReceiveBeginPlay // (None) // @ game+0xffff8109df8300e8
};

