// BlueprintGeneratedClass BP_SkeletonCrossbowman_Bolt.BP_SkeletonCrossbowman_Bolt_C
// Size: 0x6b8 (Inherited: 0x6b0)
struct ABP_SkeletonCrossbowman_Bolt_C : ABP_ProjectileActor_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x6b0(0x08)

	void ReceiveBeginPlay(); // Function BP_SkeletonCrossbowman_Bolt.BP_SkeletonCrossbowman_Bolt_C.ReceiveBeginPlay // (None) // @ game+0xffff800cdf830002
};

