// Class AIModule.EnvQueryNode
// Size: 0x30 (Inherited: 0x28)
struct UEnvQueryNode : UObject {
	int32_t VerNum; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// Class AIModule.EnvQueryTest
// Size: 0x1f8 (Inherited: 0x30)
struct UEnvQueryTest : UEnvQueryNode {
	int32_t TestOrder; // 0x30(0x04)
	enum class EEnvTestPurpose TestPurpose; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
	struct FString TestComment; // 0x38(0x10)
	enum class EEnvTestFilterOperator MultipleContextFilterOp; // 0x48(0x01)
	enum class EEnvTestScoreOperator MultipleContextScoreOp; // 0x49(0x01)
	enum class EEnvTestFilterType FilterType; // 0x4a(0x01)
	char pad_4B[0x5]; // 0x4b(0x05)
	struct FAIDataProviderBoolValue BoolValue; // 0x50(0x38)
	struct FAIDataProviderFloatValue FloatValueMin; // 0x88(0x38)
	struct FAIDataProviderFloatValue FloatValueMax; // 0xc0(0x38)
	char pad_F8[0x1]; // 0xf8(0x01)
	enum class EEnvTestScoreEquation ScoringEquation; // 0xf9(0x01)
	enum class EEnvQueryTestClamping ClampMinType; // 0xfa(0x01)
	enum class EEnvQueryTestClamping ClampMaxType; // 0xfb(0x01)
	enum class EEQSNormalizationType NormalizationType; // 0xfc(0x01)
	char pad_FD[0x3]; // 0xfd(0x03)
	struct FAIDataProviderFloatValue ScoreClampMin; // 0x100(0x38)
	struct FAIDataProviderFloatValue ScoreClampMax; // 0x138(0x38)
	struct FAIDataProviderFloatValue ScoringFactor; // 0x170(0x38)
	struct FAIDataProviderFloatValue ReferenceValue; // 0x1a8(0x38)
	bool bDefineReferenceValue; // 0x1e0(0x01)
	char pad_1E1[0xf]; // 0x1e1(0x0f)
	char bWorkOnFloatValues : 1; // 0x1f0(0x01)
	char pad_1F0_1 : 7; // 0x1f0(0x01)
	char pad_1F1[0x7]; // 0x1f1(0x07)
};

// Class AIModule.BTNode
// Size: 0x58 (Inherited: 0x28)
struct UBTNode : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FString NodeName; // 0x30(0x10)
	struct UBehaviorTree* TreeAsset; // 0x40(0x08)
	struct UBTCompositeNode* ParentNode; // 0x48(0x08)
	char pad_50[0x8]; // 0x50(0x08)
};

// Class AIModule.BTAuxiliaryNode
// Size: 0x60 (Inherited: 0x58)
struct UBTAuxiliaryNode : UBTNode {
	struct FString NodeName; // 0x30(0x10)
	struct UBehaviorTree* TreeAsset; // 0x40(0x08)
	struct UBTCompositeNode* ParentNode; // 0x48(0x08)
};

// Class AIModule.BTDecorator
// Size: 0x68 (Inherited: 0x60)
struct UBTDecorator : UBTAuxiliaryNode {
	char pad_60_0 : 7; // 0x60(0x01)
	char bInverseCondition : 1; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	enum class EBTFlowAbortMode FlowAbortMode; // 0x64(0x01)
	char pad_65[0x3]; // 0x65(0x03)
};

// Class AIModule.BTDecorator_BlackboardBase
// Size: 0x90 (Inherited: 0x68)
struct UBTDecorator_BlackboardBase : UBTDecorator {
	struct FBlackboardKeySelector BlackboardKey; // 0x68(0x28)
};

// Class AIModule.BTDecorator_Blackboard
// Size: 0xc0 (Inherited: 0x90)
struct UBTDecorator_Blackboard : UBTDecorator_BlackboardBase {
	int32_t IntValue; // 0x90(0x04)
	float FloatValue; // 0x94(0x04)
	struct FString StringValue; // 0x98(0x10)
	struct FString CachedDescription; // 0xa8(0x10)
	char OperationType; // 0xb8(0x01)
	enum class EBTBlackboardRestart NotifyObserver; // 0xb9(0x01)
	char pad_BA[0x6]; // 0xba(0x06)
};

// Class AIModule.BTDecorator_CheckGameplayTagsOnActor
// Size: 0xc8 (Inherited: 0x68)
struct UBTDecorator_CheckGameplayTagsOnActor : UBTDecorator {
	struct FBlackboardKeySelector ActorToCheck; // 0x68(0x28)
	enum class EGameplayContainerMatchType TagsToMatch; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
	struct FGameplayTagContainer GameplayTags; // 0x98(0x20)
	struct FString CachedDescription; // 0xb8(0x10)
};

// Class AIModule.BTService
// Size: 0x70 (Inherited: 0x60)
struct UBTService : UBTAuxiliaryNode {
	float Interval; // 0x60(0x04)
	float RandomDeviation; // 0x64(0x04)
	char bCallTickOnSearchStart : 1; // 0x68(0x01)
	char bRestartTimerOnEachActivation : 1; // 0x68(0x01)
	char pad_68_2 : 6; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
};

// Class AIModule.BTTaskNode
// Size: 0x70 (Inherited: 0x58)
struct UBTTaskNode : UBTNode {
	struct TArray<struct UBTService*> Services; // 0x58(0x10)
	char bIgnoreRestartSelf : 1; // 0x68(0x01)
	char pad_68_1 : 7; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
};

// Class AIModule.BTTask_BlueprintBase
// Size: 0xa8 (Inherited: 0x70)
struct UBTTask_BlueprintBase : UBTTaskNode {
	struct AAIController* AIOwner; // 0x70(0x08)
	struct AActor* ActorOwner; // 0x78(0x08)
	struct FIntervalCountdown TickInterval; // 0x80(0x08)
	char pad_88[0x18]; // 0x88(0x18)
	char bShowPropertyDetails : 1; // 0xa0(0x01)
	char pad_A0_1 : 7; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)

	void SetFinishOnMessageWithId(struct FName MessageName, int32_t RequestID); // Function AIModule.BTTask_BlueprintBase.SetFinishOnMessageWithId // (None) // @ game+0xffffb9eedf830041
};

// Class AIModule.BTTask_RunBehavior
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_RunBehavior : UBTTaskNode {
	struct UBehaviorTree* BehaviorAsset; // 0x70(0x08)
};

// Class AIModule.AIPerceptionComponent
// Size: 0x180 (Inherited: 0xa0)
struct UAIPerceptionComponent : UActorComponent {
	struct TArray<struct UAISenseConfig*> SensesConfig; // 0xa0(0x10)
	struct UAISense* DominantSense; // 0xb0(0x08)
	char pad_B8[0x10]; // 0xb8(0x10)
	struct AAIController* AIOwner; // 0xc8(0x08)
	char pad_D0[0x80]; // 0xd0(0x80)
	struct FMulticastInlineDelegate OnPerceptionUpdated; // 0x150(0x10)
	struct FMulticastInlineDelegate OnTargetPerceptionUpdated; // 0x160(0x10)
	struct FMulticastInlineDelegate OnTargetPerceptionInfoUpdated; // 0x170(0x10)

	void SetSenseEnabled(struct UAISense* SenseClass, bool bEnable); // Function AIModule.AIPerceptionComponent.SetSenseEnabled // (None) // @ game+0xffffbb62df830041
};

// Class AIModule.AIController
// Size: 0x3b8 (Inherited: 0x328)
struct AAIController : AController {
	char pad_328[0x38]; // 0x328(0x38)
	char bStartAILogicOnPossess : 1; // 0x360(0x01)
	char bStopAILogicOnUnposses : 1; // 0x360(0x01)
	char bLOSflag : 1; // 0x360(0x01)
	char bSkipExtraLOSChecks : 1; // 0x360(0x01)
	char bAllowStrafe : 1; // 0x360(0x01)
	char bWantsPlayerState : 1; // 0x360(0x01)
	char bSetControlRotationFromPawnOrientation : 1; // 0x360(0x01)
	char pad_360_7 : 1; // 0x360(0x01)
	char pad_361[0x7]; // 0x361(0x07)
	struct UPathFollowingComponent* PathFollowingComponent; // 0x368(0x08)
	struct UBrainComponent* BrainComponent; // 0x370(0x08)
	struct UAIPerceptionComponent* PerceptionComponent; // 0x378(0x08)
	struct UPawnActionsComponent* ActionsComp; // 0x380(0x08)
	struct UBlackboardComponent* Blackboard; // 0x388(0x08)
	struct UGameplayTasksComponent* CachedGameplayTasksComponent; // 0x390(0x08)
	struct UNavigationQueryFilter* DefaultNavigationFilterClass; // 0x398(0x08)
	struct FMulticastInlineDelegate ReceiveMoveCompleted; // 0x3a0(0x10)
	char pad_3B0[0x8]; // 0x3b0(0x08)

	bool UseBlackboard(struct UBlackboardData* BlackboardAsset, struct UBlackboardComponent*& BlackboardComponent); // Function AIModule.AIController.UseBlackboard // (None) // @ game+0xffffbba9df830041
};

// Class AIModule.AIAsyncTaskBlueprintProxy
// Size: 0x68 (Inherited: 0x28)
struct UAIAsyncTaskBlueprintProxy : UObject {
	struct FMulticastInlineDelegate OnSuccess; // 0x28(0x10)
	struct FMulticastInlineDelegate OnFail; // 0x38(0x10)
	char pad_48[0x20]; // 0x48(0x20)

	void OnMoveCompleted(struct FAIRequestID RequestID, enum class EPathFollowingResult MovementResult); // Function AIModule.AIAsyncTaskBlueprintProxy.OnMoveCompleted // (None) // @ game+0xffffd314df830041
};

// Class AIModule.AIResourceInterface
// Size: 0x28 (Inherited: 0x28)
struct UAIResourceInterface : UInterface {
};

// Class AIModule.AISenseBlueprintListener
// Size: 0x108 (Inherited: 0x108)
struct UAISenseBlueprintListener : UUserDefinedStruct {
	enum class EUserDefinedStructureStatus Status; // 0xc0(0x01)
	struct FGuid Guid; // 0xc4(0x10)
};

// Class AIModule.AISenseConfig
// Size: 0x48 (Inherited: 0x28)
struct UAISenseConfig : UObject {
	struct FColor DebugColor; // 0x28(0x04)
	float MaxAge; // 0x2c(0x04)
	char bStartsEnabled : 1; // 0x30(0x01)
	char pad_30_1 : 7; // 0x30(0x01)
	char pad_31[0x17]; // 0x31(0x17)
};

// Class AIModule.AISenseConfig_Blueprint
// Size: 0x50 (Inherited: 0x48)
struct UAISenseConfig_Blueprint : UAISenseConfig {
	struct UAISense_Blueprint* Implementation; // 0x48(0x08)
};

// Class AIModule.AISenseConfig_Hearing
// Size: 0x60 (Inherited: 0x48)
struct UAISenseConfig_Hearing : UAISenseConfig {
	struct UAISense_Hearing* Implementation; // 0x48(0x08)
	float HearingRange; // 0x50(0x04)
	float LoSHearingRange; // 0x54(0x04)
	char bUseLoSHearing : 1; // 0x58(0x01)
	char pad_58_1 : 7; // 0x58(0x01)
	char pad_59[0x3]; // 0x59(0x03)
	struct FAISenseAffiliationFilter DetectionByAffiliation; // 0x5c(0x04)
};

// Class AIModule.AISenseConfig_Prediction
// Size: 0x48 (Inherited: 0x48)
struct UAISenseConfig_Prediction : UAISenseConfig {
	struct FColor DebugColor; // 0x28(0x04)
	float MaxAge; // 0x2c(0x04)
	char bStartsEnabled : 1; // 0x30(0x01)
};

// Class AIModule.AISenseConfig_Sight
// Size: 0x70 (Inherited: 0x48)
struct UAISenseConfig_Sight : UAISenseConfig {
	struct UAISense_Sight* Implementation; // 0x48(0x08)
	float SightRadius; // 0x50(0x04)
	float LoseSightRadius; // 0x54(0x04)
	float PeripheralVisionAngleDegrees; // 0x58(0x04)
	struct FAISenseAffiliationFilter DetectionByAffiliation; // 0x5c(0x04)
	float AutoSuccessRangeFromLastSeenLocation; // 0x60(0x04)
	float PointOfViewBackwardOffset; // 0x64(0x04)
	float NearClippingRadius; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// Class AIModule.AISenseConfig_Team
// Size: 0x48 (Inherited: 0x48)
struct UAISenseConfig_Team : UAISenseConfig {
	struct FColor DebugColor; // 0x28(0x04)
	float MaxAge; // 0x2c(0x04)
	char bStartsEnabled : 1; // 0x30(0x01)
};

// Class AIModule.AISenseConfig_Touch
// Size: 0x48 (Inherited: 0x48)
struct UAISenseConfig_Touch : UAISenseConfig {
	struct FColor DebugColor; // 0x28(0x04)
	float MaxAge; // 0x2c(0x04)
	char bStartsEnabled : 1; // 0x30(0x01)
};

// Class AIModule.AISenseEvent
// Size: 0x28 (Inherited: 0x28)
struct UAISenseEvent : UObject {
};

// Class AIModule.AISenseEvent_Damage
// Size: 0x78 (Inherited: 0x28)
struct UAISenseEvent_Damage : UAISenseEvent {
	struct FAIDamageEvent Event; // 0x28(0x50)
};

// Class AIModule.AISenseEvent_Hearing
// Size: 0x68 (Inherited: 0x28)
struct UAISenseEvent_Hearing : UAISenseEvent {
	struct FAINoiseEvent Event; // 0x28(0x40)
};

// Class AIModule.CrowdAgentInterface
// Size: 0x28 (Inherited: 0x28)
struct UCrowdAgentInterface : UInterface {
};

// Class AIModule.EnvQueryTypes
// Size: 0x28 (Inherited: 0x28)
struct UEnvQueryTypes : UObject {
};

// Class AIModule.EQSQueryResultSourceInterface
// Size: 0x28 (Inherited: 0x28)
struct UEQSQueryResultSourceInterface : UInterface {
};

// Class AIModule.GenericTeamAgentInterface
// Size: 0x28 (Inherited: 0x28)
struct UGenericTeamAgentInterface : UInterface {
};

// Class AIModule.PawnAction
// Size: 0x90 (Inherited: 0x28)
struct UPawnAction : UObject {
	struct UPawnAction* ChildAction; // 0x28(0x08)
	struct UPawnAction* ParentAction; // 0x30(0x08)
	struct UPawnActionsComponent* OwnerComponent; // 0x38(0x08)
	struct UObject* Instigator; // 0x40(0x08)
	struct UBrainComponent* BrainComp; // 0x48(0x08)
	char pad_50[0x30]; // 0x50(0x30)
	char bAllowNewSameClassInstance : 1; // 0x80(0x01)
	char bReplaceActiveSameClassInstance : 1; // 0x80(0x01)
	char bShouldPauseMovement : 1; // 0x80(0x01)
	char bAlwaysNotifyOnFinished : 1; // 0x80(0x01)
	char pad_80_4 : 4; // 0x80(0x01)
	char pad_81[0xf]; // 0x81(0x0f)

	enum class EAIRequestPriority GetActionPriority(); // Function AIModule.PawnAction.GetActionPriority // (None) // @ game+0xffffd317df830041
};

// Class AIModule.PawnActionsComponent
// Size: 0xd8 (Inherited: 0xa0)
struct UPawnActionsComponent : UActorComponent {
	struct APawn* ControlledPawn; // 0xa0(0x08)
	struct TArray<struct FPawnActionStack> ActionStacks; // 0xa8(0x10)
	struct TArray<struct FPawnActionEvent> ActionEvents; // 0xb8(0x10)
	struct UPawnAction* CurrentAction; // 0xc8(0x08)
	char pad_D0[0x8]; // 0xd0(0x08)

	bool K2_PushAction(struct UPawnAction* NewAction, enum class EAIRequestPriority Priority, struct UObject* Instigator); // Function AIModule.PawnActionsComponent.K2_PushAction // (None) // @ game+0xffffd31bdf830041
};

// Class AIModule.PawnAction_BlueprintBase
// Size: 0x90 (Inherited: 0x90)
struct UPawnAction_BlueprintBase : UPawnAction {
	struct UPawnAction* ChildAction; // 0x28(0x08)
	struct UPawnAction* ParentAction; // 0x30(0x08)
	struct UPawnActionsComponent* OwnerComponent; // 0x38(0x08)
	struct UObject* Instigator; // 0x40(0x08)
	struct UBrainComponent* BrainComp; // 0x48(0x08)
	char bAllowNewSameClassInstance : 1; // 0x80(0x01)
	char bReplaceActiveSameClassInstance : 1; // 0x80(0x01)
	char bShouldPauseMovement : 1; // 0x80(0x01)
	char bAlwaysNotifyOnFinished : 1; // 0x80(0x01)

	void ActionTick(struct APawn* ControlledPawn, float DeltaSeconds); // Function AIModule.PawnAction_BlueprintBase.ActionTick // (None) // @ game+0xffffd320df830041
};

// Class AIModule.PawnAction_Move
// Size: 0xf0 (Inherited: 0x90)
struct UPawnAction_Move : UPawnAction {
	struct AActor* GoalActor; // 0x90(0x08)
	struct FVector GoalLocation; // 0x98(0x18)
	float AcceptableRadius; // 0xb0(0x04)
	char pad_B4[0x4]; // 0xb4(0x04)
	struct UNavigationQueryFilter* FilterClass; // 0xb8(0x08)
	char bAllowStrafe : 1; // 0xc0(0x01)
	char bFinishOnOverlap : 1; // 0xc0(0x01)
	char bUsePathfinding : 1; // 0xc0(0x01)
	char bAllowPartialPath : 1; // 0xc0(0x01)
	char bProjectGoalToNavigation : 1; // 0xc0(0x01)
	char bUpdatePathToGoal : 1; // 0xc0(0x01)
	char bAbortSubActionOnPathChange : 1; // 0xc0(0x01)
	char pad_C0_7 : 1; // 0xc0(0x01)
	char pad_C1[0x2f]; // 0xc1(0x2f)
};

// Class AIModule.PawnAction_Repeat
// Size: 0xb0 (Inherited: 0x90)
struct UPawnAction_Repeat : UPawnAction {
	struct UPawnAction* ActionToRepeat; // 0x90(0x08)
	struct UPawnAction* RecentActionCopy; // 0x98(0x08)
	enum class EPawnActionFailHandling ChildFailureHandlingMode; // 0xa0(0x01)
	char pad_A1[0xf]; // 0xa1(0x0f)
};

// Class AIModule.PawnAction_Sequence
// Size: 0xb8 (Inherited: 0x90)
struct UPawnAction_Sequence : UPawnAction {
	struct TArray<struct UPawnAction*> ActionSequence; // 0x90(0x10)
	enum class EPawnActionFailHandling ChildFailureHandlingMode; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)
	struct UPawnAction* RecentActionCopy; // 0xa8(0x08)
	char pad_B0[0x8]; // 0xb0(0x08)
};

// Class AIModule.PawnAction_Wait
// Size: 0xa0 (Inherited: 0x90)
struct UPawnAction_Wait : UPawnAction {
	float TimeToWait; // 0x90(0x04)
	char pad_94[0xc]; // 0x94(0x0c)
};

// Class AIModule.AIResource_Movement
// Size: 0x38 (Inherited: 0x38)
struct UAIResource_Movement : UGameplayTaskResource {
	int32_t ManualResourceID; // 0x28(0x04)
	int8_t AutoResourceID; // 0x2c(0x01)
	char bManuallySetID : 1; // 0x30(0x01)
};

// Class AIModule.AIResource_Logic
// Size: 0x38 (Inherited: 0x38)
struct UAIResource_Logic : UGameplayTaskResource {
	int32_t ManualResourceID; // 0x28(0x04)
	int8_t AutoResourceID; // 0x2c(0x01)
	char bManuallySetID : 1; // 0x30(0x01)
};

// Class AIModule.AISubsystem
// Size: 0x38 (Inherited: 0x28)
struct UAISubsystem : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct UAISystem* AISystem; // 0x30(0x08)
};

// Class AIModule.AISystem
// Size: 0x168 (Inherited: 0x60)
struct UAISystem : UAISystemBase {
	struct FSoftClassPath PerceptionSystemClassName; // 0x60(0x20)
	struct FSoftClassPath HotSpotManagerClassName; // 0x80(0x20)
	struct FSoftClassPath EnvQueryManagerClassName; // 0xa0(0x20)
	float AcceptanceRadius; // 0xc0(0x04)
	float PathfollowingRegularPathPointAcceptanceRadius; // 0xc4(0x04)
	float PathfollowingNavLinkAcceptanceRadius; // 0xc8(0x04)
	bool bFinishMoveOnGoalOverlap; // 0xcc(0x01)
	bool bAcceptPartialPaths; // 0xcd(0x01)
	bool bAllowStrafing; // 0xce(0x01)
	bool bEnableBTAITasks; // 0xcf(0x01)
	bool bAllowControllersAsEQSQuerier; // 0xd0(0x01)
	bool bEnableDebuggerPlugin; // 0xd1(0x01)
	bool bForgetStaleActors; // 0xd2(0x01)
	bool bAddBlackboardSelfKey; // 0xd3(0x01)
	bool bClearBBEntryOnBTEQSFail; // 0xd4(0x01)
	enum class ECollisionChannel DefaultSightCollisionChannel; // 0xd5(0x01)
	char pad_D6[0x2]; // 0xd6(0x02)
	struct UBehaviorTreeManager* BehaviorTreeManager; // 0xd8(0x08)
	struct UEnvQueryManager* EnvironmentQueryManager; // 0xe0(0x08)
	struct UAIPerceptionSystem* PerceptionSystem; // 0xe8(0x08)
	struct TArray<struct UAIAsyncTaskBlueprintProxy*> AllProxyObjects; // 0xf0(0x10)
	struct UAIHotSpotManager* HotSpotManager; // 0x100(0x08)
	struct UNavLocalGridManager* NavLocalGrids; // 0x108(0x08)
	char pad_110[0x58]; // 0x110(0x58)

	void AILoggingVerbose(); // Function AIModule.AISystem.AILoggingVerbose // (None) // @ game+0xffffd322df830041
};

// Class AIModule.BehaviorTree
// Size: 0x68 (Inherited: 0x28)
struct UBehaviorTree : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct UBTCompositeNode* RootNode; // 0x30(0x08)
	struct UBlackboardData* BlackboardAsset; // 0x38(0x08)
	struct TArray<struct UBTDecorator*> RootDecorators; // 0x40(0x10)
	struct TArray<struct FBTDecoratorLogic> RootDecoratorOps; // 0x50(0x10)
	char pad_60[0x8]; // 0x60(0x08)
};

// Class AIModule.BrainComponent
// Size: 0xf8 (Inherited: 0xa0)
struct UBrainComponent : UActorComponent {
	char pad_A0[0x8]; // 0xa0(0x08)
	struct UBlackboardComponent* BlackboardComp; // 0xa8(0x08)
	struct AAIController* AIOwner; // 0xb0(0x08)
	char pad_B8[0x40]; // 0xb8(0x40)

	void StopLogic(struct FString Reason); // Function AIModule.BrainComponent.StopLogic // (None) // @ game+0xffffd327df830041
};

// Class AIModule.BehaviorTreeComponent
// Size: 0x288 (Inherited: 0xf8)
struct UBehaviorTreeComponent : UBrainComponent {
	char pad_F8[0x20]; // 0xf8(0x20)
	struct TArray<struct UBTNode*> NodeInstances; // 0x118(0x10)
	char pad_128[0x148]; // 0x128(0x148)
	struct UBehaviorTree* DefaultBehaviorTreeAsset; // 0x270(0x08)
	char pad_278[0x10]; // 0x278(0x10)

	void SetDynamicSubtree(struct FGameplayTag InjectTag, struct UBehaviorTree* BehaviorAsset); // Function AIModule.BehaviorTreeComponent.SetDynamicSubtree // (None) // @ game+0xffffd32adf830041
};

// Class AIModule.BehaviorTreeManager
// Size: 0x50 (Inherited: 0x28)
struct UBehaviorTreeManager : UObject {
	int32_t MaxDebuggerSteps; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct TArray<struct FBehaviorTreeTemplateInfo> LoadedTemplates; // 0x30(0x10)
	struct TArray<struct UBehaviorTreeComponent*> ActiveComponents; // 0x40(0x10)
};

// Class AIModule.BehaviorTreeTypes
// Size: 0x28 (Inherited: 0x28)
struct UBehaviorTreeTypes : UObject {
};

// Class AIModule.BlackboardAssetProvider
// Size: 0x28 (Inherited: 0x28)
struct UBlackboardAssetProvider : UInterface {

	struct UBlackboardData* GetBlackboardAsset(); // Function AIModule.BlackboardAssetProvider.GetBlackboardAsset // (None) // @ game+0xffffd32bdf830041
};

// Class AIModule.BlackboardComponent
// Size: 0x1a8 (Inherited: 0xa0)
struct UBlackboardComponent : UActorComponent {
	struct UBrainComponent* BrainComp; // 0xa0(0x08)
	struct UBlackboardData* DefaultBlackboardAsset; // 0xa8(0x08)
	struct UBlackboardData* BlackboardAsset; // 0xb0(0x08)
	char pad_B8[0x20]; // 0xb8(0x20)
	struct TArray<struct UBlackboardKeyType*> KeyInstances; // 0xd8(0x10)
	char pad_E8[0xc0]; // 0xe8(0xc0)

	void SetValueAsVector(struct FName& KeyName, struct FVector VectorValue); // Function AIModule.BlackboardComponent.SetValueAsVector // (None) // @ game+0xffffd343df830041
};

// Class AIModule.BlackboardData
// Size: 0x50 (Inherited: 0x30)
struct UBlackboardData : UDataAsset {
	struct UBlackboardData* Parent; // 0x30(0x08)
	struct TArray<struct FBlackboardEntry> Keys; // 0x38(0x10)
	char bHasSynchronizedKeys : 1; // 0x48(0x01)
	char pad_48_1 : 7; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class AIModule.BlackboardKeyType
// Size: 0x30 (Inherited: 0x28)
struct UBlackboardKeyType : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class AIModule.BlackboardKeyType_Bool
// Size: 0x30 (Inherited: 0x30)
struct UBlackboardKeyType_Bool : UBlackboardKeyType {
};

// Class AIModule.BlackboardKeyType_Class
// Size: 0x38 (Inherited: 0x30)
struct UBlackboardKeyType_Class : UBlackboardKeyType {
	ClassPtrProperty BaseClass; // 0x30(0x08)
};

// Class AIModule.BlackboardKeyType_Enum
// Size: 0x50 (Inherited: 0x30)
struct UBlackboardKeyType_Enum : UBlackboardKeyType {
	struct UEnum* EnumType; // 0x30(0x08)
	struct FString EnumName; // 0x38(0x10)
	char bIsEnumNameValid : 1; // 0x48(0x01)
	char pad_48_1 : 7; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class AIModule.BlackboardKeyType_Float
// Size: 0x30 (Inherited: 0x30)
struct UBlackboardKeyType_Float : UBlackboardKeyType {
};

// Class AIModule.BlackboardKeyType_Int
// Size: 0x30 (Inherited: 0x30)
struct UBlackboardKeyType_Int : UBlackboardKeyType {
};

// Class AIModule.BlackboardKeyType_Name
// Size: 0x30 (Inherited: 0x30)
struct UBlackboardKeyType_Name : UBlackboardKeyType {
};

// Class AIModule.BlackboardKeyType_NativeEnum
// Size: 0x48 (Inherited: 0x30)
struct UBlackboardKeyType_NativeEnum : UBlackboardKeyType {
	struct FString EnumName; // 0x30(0x10)
	struct UEnum* EnumType; // 0x40(0x08)
};

// Class AIModule.BlackboardKeyType_Object
// Size: 0x38 (Inherited: 0x30)
struct UBlackboardKeyType_Object : UBlackboardKeyType {
	ClassPtrProperty BaseClass; // 0x30(0x08)
};

// Class AIModule.BlackboardKeyType_Rotator
// Size: 0x30 (Inherited: 0x30)
struct UBlackboardKeyType_Rotator : UBlackboardKeyType {
};

// Class AIModule.BlackboardKeyType_String
// Size: 0x40 (Inherited: 0x30)
struct UBlackboardKeyType_String : UBlackboardKeyType {
	struct FString StringValue; // 0x30(0x10)
};

// Class AIModule.BlackboardKeyType_Vector
// Size: 0x30 (Inherited: 0x30)
struct UBlackboardKeyType_Vector : UBlackboardKeyType {
};

// Class AIModule.BTCompositeNode
// Size: 0x90 (Inherited: 0x58)
struct UBTCompositeNode : UBTNode {
	struct TArray<struct FBTCompositeChild> Children; // 0x58(0x10)
	struct TArray<struct UBTService*> Services; // 0x68(0x10)
	char pad_78[0x10]; // 0x78(0x10)
	char bApplyDecoratorScope : 1; // 0x88(0x01)
	char pad_88_1 : 7; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
};

// Class AIModule.BTFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UBTFunctionLibrary : UBlueprintFunctionLibrary {

	void StopUsingExternalEvent(struct UBTNode* NodeOwner); // Function AIModule.BTFunctionLibrary.StopUsingExternalEvent // (None) // @ game+0xffffd35edf830041
};

// Class AIModule.BTComposite_Selector
// Size: 0x90 (Inherited: 0x90)
struct UBTComposite_Selector : UBTCompositeNode {
	struct TArray<struct FBTCompositeChild> Children; // 0x58(0x10)
	struct TArray<struct UBTService*> Services; // 0x68(0x10)
	char bApplyDecoratorScope : 1; // 0x88(0x01)
};

// Class AIModule.BTComposite_Sequence
// Size: 0x90 (Inherited: 0x90)
struct UBTComposite_Sequence : UBTCompositeNode {
	struct TArray<struct FBTCompositeChild> Children; // 0x58(0x10)
	struct TArray<struct UBTService*> Services; // 0x68(0x10)
	char bApplyDecoratorScope : 1; // 0x88(0x01)
};

// Class AIModule.BTComposite_SimpleParallel
// Size: 0x98 (Inherited: 0x90)
struct UBTComposite_SimpleParallel : UBTCompositeNode {
	enum class EBTParallelMode FinishMode; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// Class AIModule.BTDecorator_BlueprintBase
// Size: 0xa0 (Inherited: 0x68)
struct UBTDecorator_BlueprintBase : UBTDecorator {
	struct AAIController* AIOwner; // 0x68(0x08)
	struct AActor* ActorOwner; // 0x70(0x08)
	struct TArray<struct FName> ObservedKeyNames; // 0x78(0x10)
	char pad_88[0x10]; // 0x88(0x10)
	char bShowPropertyDetails : 1; // 0x98(0x01)
	char bCheckConditionOnlyBlackBoardChanges : 1; // 0x98(0x01)
	char bIsObservingBB : 1; // 0x98(0x01)
	char pad_98_3 : 5; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function AIModule.BTDecorator_BlueprintBase.ReceiveTickAI // (None) // @ game+0xffffd36cdf830041
};

// Class AIModule.BTDecorator_CompareBBEntries
// Size: 0xc0 (Inherited: 0x68)
struct UBTDecorator_CompareBBEntries : UBTDecorator {
	enum class EBlackBoardEntryComparison Operator; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
	struct FBlackboardKeySelector BlackboardKeyA; // 0x70(0x28)
	struct FBlackboardKeySelector BlackboardKeyB; // 0x98(0x28)
};

// Class AIModule.BTDecorator_ConditionalLoop
// Size: 0xc0 (Inherited: 0xc0)
struct UBTDecorator_ConditionalLoop : UBTDecorator_Blackboard {
	int32_t IntValue; // 0x90(0x04)
	float FloatValue; // 0x94(0x04)
	struct FString StringValue; // 0x98(0x10)
	struct FString CachedDescription; // 0xa8(0x10)
	char OperationType; // 0xb8(0x01)
	enum class EBTBlackboardRestart NotifyObserver; // 0xb9(0x01)
};

// Class AIModule.BTDecorator_ConeCheck
// Size: 0xf0 (Inherited: 0x68)
struct UBTDecorator_ConeCheck : UBTDecorator {
	float ConeHalfAngle; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct FBlackboardKeySelector ConeOrigin; // 0x70(0x28)
	struct FBlackboardKeySelector ConeDirection; // 0x98(0x28)
	struct FBlackboardKeySelector Observed; // 0xc0(0x28)
	char pad_E8[0x8]; // 0xe8(0x08)
};

// Class AIModule.BTDecorator_Cooldown
// Size: 0x70 (Inherited: 0x68)
struct UBTDecorator_Cooldown : UBTDecorator {
	float CoolDownTime; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// Class AIModule.BTDecorator_DoesPathExist
// Size: 0xc8 (Inherited: 0x68)
struct UBTDecorator_DoesPathExist : UBTDecorator {
	struct FBlackboardKeySelector BlackboardKeyA; // 0x68(0x28)
	struct FBlackboardKeySelector BlackboardKeyB; // 0x90(0x28)
	char bUseSelf : 1; // 0xb8(0x01)
	char pad_B8_1 : 7; // 0xb8(0x01)
	char pad_B9[0x3]; // 0xb9(0x03)
	enum class EPathExistanceQueryType PathQueryType; // 0xbc(0x01)
	char pad_BD[0x3]; // 0xbd(0x03)
	struct UNavigationQueryFilter* FilterClass; // 0xc0(0x08)
};

// Class AIModule.BTDecorator_ForceSuccess
// Size: 0x68 (Inherited: 0x68)
struct UBTDecorator_ForceSuccess : UBTDecorator {
	char pad_68_0 : 7; // 0x68(0x01)
	char bInverseCondition : 1; // 0x60(0x01)
	enum class EBTFlowAbortMode FlowAbortMode; // 0x64(0x01)
};

// Class AIModule.BTDecorator_IsAtLocation
// Size: 0xd8 (Inherited: 0x90)
struct UBTDecorator_IsAtLocation : UBTDecorator_BlackboardBase {
	float AcceptableRadius; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
	struct FAIDataProviderFloatValue ParametrizedAcceptableRadius; // 0x98(0x38)
	enum class FAIDistanceType GeometricDistanceType; // 0xd0(0x01)
	char pad_D1[0x3]; // 0xd1(0x03)
	char bUseParametrizedRadius : 1; // 0xd4(0x01)
	char bUseNavAgentGoalLocation : 1; // 0xd4(0x01)
	char bPathFindingBasedTest : 1; // 0xd4(0x01)
	char pad_D4_3 : 5; // 0xd4(0x01)
	char pad_D5[0x3]; // 0xd5(0x03)
};

// Class AIModule.BTDecorator_IsBBEntryOfClass
// Size: 0x98 (Inherited: 0x90)
struct UBTDecorator_IsBBEntryOfClass : UBTDecorator_BlackboardBase {
	struct UObject* TestClass; // 0x90(0x08)
};

// Class AIModule.BTDecorator_KeepInCone
// Size: 0xc8 (Inherited: 0x68)
struct UBTDecorator_KeepInCone : UBTDecorator {
	float ConeHalfAngle; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct FBlackboardKeySelector ConeOrigin; // 0x70(0x28)
	struct FBlackboardKeySelector Observed; // 0x98(0x28)
	char bUseSelfAsOrigin : 1; // 0xc0(0x01)
	char bUseSelfAsObserved : 1; // 0xc0(0x01)
	char pad_C0_2 : 6; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
};

// Class AIModule.BTDecorator_Loop
// Size: 0x78 (Inherited: 0x68)
struct UBTDecorator_Loop : UBTDecorator {
	int32_t NumLoops; // 0x68(0x04)
	bool bInfiniteLoop; // 0x6c(0x01)
	char pad_6D[0x3]; // 0x6d(0x03)
	float InfiniteLoopTimeoutTime; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// Class AIModule.BTDecorator_ReachedMoveGoal
// Size: 0x68 (Inherited: 0x68)
struct UBTDecorator_ReachedMoveGoal : UBTDecorator {
	char pad_68_0 : 7; // 0x68(0x01)
	char bInverseCondition : 1; // 0x60(0x01)
	enum class EBTFlowAbortMode FlowAbortMode; // 0x64(0x01)
};

// Class AIModule.BTDecorator_SetTagCooldown
// Size: 0x78 (Inherited: 0x68)
struct UBTDecorator_SetTagCooldown : UBTDecorator {
	struct FGameplayTag CooldownTag; // 0x68(0x08)
	float CooldownDuration; // 0x70(0x04)
	bool bAddToExistingDuration; // 0x74(0x01)
	char pad_75[0x3]; // 0x75(0x03)
};

// Class AIModule.BTDecorator_TagCooldown
// Size: 0x78 (Inherited: 0x68)
struct UBTDecorator_TagCooldown : UBTDecorator {
	struct FGameplayTag CooldownTag; // 0x68(0x08)
	float CooldownDuration; // 0x70(0x04)
	bool bAddToExistingDuration; // 0x74(0x01)
	bool bActivatesCooldown; // 0x75(0x01)
	char pad_76[0x2]; // 0x76(0x02)
};

// Class AIModule.BTDecorator_TimeLimit
// Size: 0x70 (Inherited: 0x68)
struct UBTDecorator_TimeLimit : UBTDecorator {
	float TimeLimit; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// Class AIModule.BTService_BlackboardBase
// Size: 0x98 (Inherited: 0x70)
struct UBTService_BlackboardBase : UBTService {
	struct FBlackboardKeySelector BlackboardKey; // 0x70(0x28)
};

// Class AIModule.BTService_BlueprintBase
// Size: 0x98 (Inherited: 0x70)
struct UBTService_BlueprintBase : UBTService {
	struct AAIController* AIOwner; // 0x70(0x08)
	struct AActor* ActorOwner; // 0x78(0x08)
	char pad_80[0x10]; // 0x80(0x10)
	char bShowPropertyDetails : 1; // 0x90(0x01)
	char bShowEventDetails : 1; // 0x90(0x01)
	char pad_90_2 : 6; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function AIModule.BTService_BlueprintBase.ReceiveTickAI // (None) // @ game+0xffffd375df830041
};

// Class AIModule.BTService_DefaultFocus
// Size: 0xa0 (Inherited: 0x98)
struct UBTService_DefaultFocus : UBTService_BlackboardBase {
	char FocusPriority; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
};

// Class AIModule.BTService_RunEQS
// Size: 0xf8 (Inherited: 0x98)
struct UBTService_RunEQS : UBTService_BlackboardBase {
	struct FEQSParametrizedQueryExecutionRequest EQSRequest; // 0x98(0x48)
	bool bUpdateBBOnFail; // 0xe0(0x01)
	char pad_E1[0x17]; // 0xe1(0x17)
};

// Class AIModule.BTTask_BlackboardBase
// Size: 0x98 (Inherited: 0x70)
struct UBTTask_BlackboardBase : UBTTaskNode {
	struct FBlackboardKeySelector BlackboardKey; // 0x70(0x28)
};

// Class AIModule.BTTask_FinishWithResult
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_FinishWithResult : UBTTaskNode {
	enum class EBTNodeResult Result; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class AIModule.BTTask_GameplayTaskBase
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_GameplayTaskBase : UBTTaskNode {
	char bWaitForGameplayTask : 1; // 0x70(0x01)
	char pad_70_1 : 7; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class AIModule.BTTask_MakeNoise
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_MakeNoise : UBTTaskNode {
	float Loudnes; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// Class AIModule.BTTask_MoveTo
// Size: 0xb0 (Inherited: 0x98)
struct UBTTask_MoveTo : UBTTask_BlackboardBase {
	float AcceptableRadius; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
	struct UNavigationQueryFilter* FilterClass; // 0xa0(0x08)
	float ObservedBlackboardValueTolerance; // 0xa8(0x04)
	char bObserveBlackboardValue : 1; // 0xac(0x01)
	char bAllowStrafe : 1; // 0xac(0x01)
	char bAllowPartialPath : 1; // 0xac(0x01)
	char bTrackMovingGoal : 1; // 0xac(0x01)
	char bProjectGoalLocation : 1; // 0xac(0x01)
	char bReachTestIncludesAgentRadius : 1; // 0xac(0x01)
	char bReachTestIncludesGoalRadius : 1; // 0xac(0x01)
	char bStopOnOverlap : 1; // 0xac(0x01)
	char bStopOnOverlapNeedsUpdate : 1; // 0xad(0x01)
	char pad_AD_1 : 7; // 0xad(0x01)
	char pad_AE[0x2]; // 0xae(0x02)
};

// Class AIModule.BTTask_MoveDirectlyToward
// Size: 0xb8 (Inherited: 0xb0)
struct UBTTask_MoveDirectlyToward : UBTTask_MoveTo {
	char bDisablePathUpdateOnGoalLocationChange : 1; // 0xb0(0x01)
	char bProjectVectorGoalToNavigation : 1; // 0xb0(0x01)
	char bUpdatedDeprecatedProperties : 1; // 0xb0(0x01)
	char pad_B0_3 : 5; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
};

// Class AIModule.BTTask_PawnActionBase
// Size: 0x70 (Inherited: 0x70)
struct UBTTask_PawnActionBase : UBTTaskNode {
	struct TArray<struct UBTService*> Services; // 0x58(0x10)
	char bIgnoreRestartSelf : 1; // 0x68(0x01)
};

// Class AIModule.BTTask_PlayAnimation
// Size: 0xb0 (Inherited: 0x70)
struct UBTTask_PlayAnimation : UBTTaskNode {
	struct UAnimationAsset* AnimationToPlay; // 0x70(0x08)
	char bLooping : 1; // 0x78(0x01)
	char bNonBlocking : 1; // 0x78(0x01)
	char pad_78_2 : 6; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
	struct UBehaviorTreeComponent* MyOwnerComp; // 0x80(0x08)
	struct USkeletalMeshComponent* CachedSkelMesh; // 0x88(0x08)
	char pad_90[0x20]; // 0x90(0x20)
};

// Class AIModule.BTTask_PlaySound
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_PlaySound : UBTTaskNode {
	struct USoundCue* SoundToPlay; // 0x70(0x08)
};

// Class AIModule.BTTask_PushPawnAction
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_PushPawnAction : UBTTask_PawnActionBase {
	struct UPawnAction* Action; // 0x70(0x08)
};

// Class AIModule.BTTask_RotateToFaceBBEntry
// Size: 0xa0 (Inherited: 0x98)
struct UBTTask_RotateToFaceBBEntry : UBTTask_BlackboardBase {
	float Precision; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
};

// Class AIModule.BTTask_RunBehaviorDynamic
// Size: 0x88 (Inherited: 0x70)
struct UBTTask_RunBehaviorDynamic : UBTTaskNode {
	struct FGameplayTag InjectionTag; // 0x70(0x08)
	struct UBehaviorTree* DefaultBehaviorAsset; // 0x78(0x08)
	struct UBehaviorTree* BehaviorAsset; // 0x80(0x08)
};

// Class AIModule.BTTask_RunEQSQuery
// Size: 0x158 (Inherited: 0x98)
struct UBTTask_RunEQSQuery : UBTTask_BlackboardBase {
	struct UEnvQuery* QueryTemplate; // 0x98(0x08)
	struct TArray<struct FEnvNamedValue> QueryParams; // 0xa0(0x10)
	struct TArray<struct FAIDynamicParam> QueryConfig; // 0xb0(0x10)
	enum class EEnvQueryRunMode RunMode; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
	struct FBlackboardKeySelector EQSQueryBlackboardKey; // 0xc8(0x28)
	bool bUseBBKey; // 0xf0(0x01)
	char pad_F1[0x7]; // 0xf1(0x07)
	struct FEQSParametrizedQueryExecutionRequest EQSRequest; // 0xf8(0x48)
	bool bUpdateBBOnFail; // 0x140(0x01)
	char pad_141[0x17]; // 0x141(0x17)
};

// Class AIModule.BTTask_SetTagCooldown
// Size: 0x80 (Inherited: 0x70)
struct UBTTask_SetTagCooldown : UBTTaskNode {
	struct FGameplayTag CooldownTag; // 0x70(0x08)
	bool bAddToExistingDuration; // 0x78(0x01)
	char pad_79[0x3]; // 0x79(0x03)
	float CooldownDuration; // 0x7c(0x04)
};

// Class AIModule.BTTask_Wait
// Size: 0x78 (Inherited: 0x70)
struct UBTTask_Wait : UBTTaskNode {
	float WaitTime; // 0x70(0x04)
	float RandomDeviation; // 0x74(0x04)
};

// Class AIModule.BTTask_WaitBlackboardTime
// Size: 0xa0 (Inherited: 0x78)
struct UBTTask_WaitBlackboardTime : UBTTask_Wait {
	struct FBlackboardKeySelector BlackboardKey; // 0x78(0x28)
};

// Class AIModule.AIBlueprintHelperLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAIBlueprintHelperLibrary : UBlueprintFunctionLibrary {

	void UnlockAIResourcesWithAnimation(struct UAnimInstance* AnimInstance, bool bUnlockMovement, bool UnlockAILogic); // Function AIModule.AIBlueprintHelperLibrary.UnlockAIResourcesWithAnimation // (None) // @ game+0xffffd385df830041
};

// Class AIModule.AIDataProvider
// Size: 0x28 (Inherited: 0x28)
struct UAIDataProvider : UObject {
};

// Class AIModule.AIDataProvider_QueryParams
// Size: 0x40 (Inherited: 0x28)
struct UAIDataProvider_QueryParams : UAIDataProvider {
	struct FName ParamName; // 0x28(0x08)
	float FloatValue; // 0x30(0x04)
	int32_t IntValue; // 0x34(0x04)
	bool BoolValue; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// Class AIModule.AIDataProvider_Random
// Size: 0x50 (Inherited: 0x40)
struct UAIDataProvider_Random : UAIDataProvider_QueryParams {
	float Min; // 0x40(0x04)
	float Max; // 0x44(0x04)
	char bInteger : 1; // 0x48(0x01)
	char pad_48_1 : 7; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class AIModule.DetourCrowdAIController
// Size: 0x3b8 (Inherited: 0x3b8)
struct ADetourCrowdAIController : AAIController {
	char bStartAILogicOnPossess : 1; // 0x360(0x01)
	char bStopAILogicOnUnposses : 1; // 0x360(0x01)
	char bLOSflag : 1; // 0x360(0x01)
	char bSkipExtraLOSChecks : 1; // 0x360(0x01)
	char bAllowStrafe : 1; // 0x360(0x01)
	char bWantsPlayerState : 1; // 0x360(0x01)
	char bSetControlRotationFromPawnOrientation : 1; // 0x360(0x01)
	struct UPathFollowingComponent* PathFollowingComponent; // 0x368(0x08)
	struct UBrainComponent* BrainComponent; // 0x370(0x08)
	struct UAIPerceptionComponent* PerceptionComponent; // 0x378(0x08)
	struct UPawnActionsComponent* ActionsComp; // 0x380(0x08)
	struct UBlackboardComponent* Blackboard; // 0x388(0x08)
	struct UGameplayTasksComponent* CachedGameplayTasksComponent; // 0x390(0x08)
	struct UNavigationQueryFilter* DefaultNavigationFilterClass; // 0x398(0x08)
	struct FMulticastInlineDelegate ReceiveMoveCompleted; // 0x3a0(0x10)
};

// Class AIModule.EnvQueryContext
// Size: 0x28 (Inherited: 0x28)
struct UEnvQueryContext : UObject {
};

// Class AIModule.EnvQueryContext_BlueprintBase
// Size: 0x30 (Inherited: 0x28)
struct UEnvQueryContext_BlueprintBase : UEnvQueryContext {
	char pad_28[0x8]; // 0x28(0x08)

	void ProvideSingleLocation(struct UObject* QuerierObject, struct AActor* QuerierActor, struct FVector& ResultingLocation); // Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleLocation // (None) // @ game+0xffffd389df830041
};

// Class AIModule.EnvQueryContext_Item
// Size: 0x28 (Inherited: 0x28)
struct UEnvQueryContext_Item : UEnvQueryContext {
};

// Class AIModule.EnvQueryContext_Querier
// Size: 0x28 (Inherited: 0x28)
struct UEnvQueryContext_Querier : UEnvQueryContext {
};

// Class AIModule.EnvQuery
// Size: 0x48 (Inherited: 0x30)
struct UEnvQuery : UDataAsset {
	struct FName QueryName; // 0x30(0x08)
	struct TArray<struct UEnvQueryOption*> Options; // 0x38(0x10)
};

// Class AIModule.EnvQueryDebugHelpers
// Size: 0x28 (Inherited: 0x28)
struct UEnvQueryDebugHelpers : UObject {
};

// Class AIModule.EnvQueryGenerator
// Size: 0x50 (Inherited: 0x30)
struct UEnvQueryGenerator : UEnvQueryNode {
	struct FString OptionName; // 0x30(0x10)
	struct UEnvQueryItemType* ItemType; // 0x40(0x08)
	char bAutoSortTests : 1; // 0x48(0x01)
	char pad_48_1 : 7; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class AIModule.EnvQueryInstanceBlueprintWrapper
// Size: 0x78 (Inherited: 0x28)
struct UEnvQueryInstanceBlueprintWrapper : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	int32_t QueryID; // 0x30(0x04)
	char pad_34[0x24]; // 0x34(0x24)
	struct UEnvQueryItemType* ItemType; // 0x58(0x08)
	int32_t OptionIndex; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
	struct FMulticastInlineDelegate OnQueryFinishedEvent; // 0x68(0x10)

	void SetNamedParam(struct FName ParamName, float Value); // Function AIModule.EnvQueryInstanceBlueprintWrapper.SetNamedParam // (None) // @ game+0xffff9d05df830041
};

// Class AIModule.EnvQueryManager
// Size: 0x158 (Inherited: 0x38)
struct UEnvQueryManager : UAISubsystem {
	char pad_38[0x70]; // 0x38(0x70)
	struct TArray<struct FEnvQueryInstanceCache> InstanceCache; // 0xa8(0x10)
	struct TArray<struct UEnvQueryContext*> LocalContexts; // 0xb8(0x10)
	struct TArray<struct UEnvQueryInstanceBlueprintWrapper*> GCShieldedWrappers; // 0xc8(0x10)
	char pad_D8[0x54]; // 0xd8(0x54)
	float MaxAllowedTestingTime; // 0x12c(0x04)
	bool bTestQueriesUsingBreadth; // 0x130(0x01)
	char pad_131[0x3]; // 0x131(0x03)
	int32_t QueryCountWarningThreshold; // 0x134(0x04)
	double QueryCountWarningInterval; // 0x138(0x08)
	double ExecutionTimeWarningSeconds; // 0x140(0x08)
	double HandlingResultTimeWarningSeconds; // 0x148(0x08)
	double GenerationTimeWarningSeconds; // 0x150(0x08)

	struct UEnvQueryInstanceBlueprintWrapper* RunEQSQuery(struct UObject* WorldContextObject, struct UEnvQuery* QueryTemplate, struct UObject* Querier, enum class EEnvQueryRunMode RunMode, struct UEnvQueryInstanceBlueprintWrapper* WrapperClass); // Function AIModule.EnvQueryManager.RunEQSQuery // (None) // @ game+0xffffd38adf830041
};

// Class AIModule.EnvQueryOption
// Size: 0x40 (Inherited: 0x28)
struct UEnvQueryOption : UObject {
	struct UEnvQueryGenerator* Generator; // 0x28(0x08)
	struct TArray<struct UEnvQueryTest*> Tests; // 0x30(0x10)
};

// Class AIModule.EQSRenderingComponent
// Size: 0x5c0 (Inherited: 0x590)
struct UEQSRenderingComponent : UDebugDrawComponent {
	float MinDrawDistance; // 0x2b0(0x04)
	float LDMaxDrawDistance; // 0x2b4(0x04)
	float CachedMaxDrawDistance; // 0x2b8(0x04)
	enum class ESceneDepthPriorityGroup DepthPriorityGroup; // 0x2bc(0x01)
	enum class ESceneDepthPriorityGroup ViewOwnerDepthPriorityGroup; // 0x2bd(0x01)
	enum class EIndirectLightingCacheQuality IndirectLightingCacheQuality; // 0x2be(0x01)
	enum class ELightmapType LightmapType; // 0x2bf(0x01)
	char bIsValidTextureStreamingBuiltData : 1; // 0x2c0(0x01)
	char bNeverDistanceCull : 1; // 0x2c0(0x01)
	char pad_5A0_2 : 5; // 0x5a0(0x01)
	char bAlwaysCreatePhysicsState : 1; // 0x2c0(0x01)
	char bGenerateOverlapEvents : 1; // 0x2c1(0x01)
	char bMultiBodyOverlap : 1; // 0x2c1(0x01)
	char bTraceComplexOnMove : 1; // 0x2c1(0x01)
	char bReturnMaterialOnMove : 1; // 0x2c1(0x01)
	char bUseViewOwnerDepthPriorityGroup : 1; // 0x2c1(0x01)
	char bAllowCullDistanceVolume : 1; // 0x2c1(0x01)
	char bVisibleInReflectionCaptures : 1; // 0x2c1(0x01)
	char bVisibleInRealTimeSkyCaptures : 1; // 0x2c1(0x01)
	char bVisibleInRayTracing : 1; // 0x2c2(0x01)
	char bRenderInMainPass : 1; // 0x2c2(0x01)
	char bRenderInDepthPass : 1; // 0x2c2(0x01)
	char bReceivesDecals : 1; // 0x2c2(0x01)
	char bOwnerNoSee : 1; // 0x2c2(0x01)
	char bOnlyOwnerSee : 1; // 0x2c2(0x01)
	char bTreatAsBackgroundForOcclusion : 1; // 0x2c2(0x01)
	char bUseAsOccluder : 1; // 0x2c2(0x01)
	char bSelectable : 1; // 0x2c3(0x01)
	char bForceMipStreaming : 1; // 0x2c3(0x01)
	char bHasPerInstanceHitProxies : 1; // 0x2c3(0x01)
	char CastShadow : 1; // 0x2c3(0x01)
	char bEmissiveLightSource : 1; // 0x2c3(0x01)
	char bAffectDynamicIndirectLighting : 1; // 0x2c3(0x01)
	char bAffectIndirectLightingWhileHidden : 1; // 0x2c3(0x01)
	char bAffectDistanceFieldLighting : 1; // 0x2c3(0x01)
	char bCastDynamicShadow : 1; // 0x2c4(0x01)
	char bCastStaticShadow : 1; // 0x2c4(0x01)
	char bCastVolumetricTranslucentShadow : 1; // 0x2c4(0x01)
	char bCastContactShadow : 1; // 0x2c4(0x01)
	char bSelfShadowOnly : 1; // 0x2c4(0x01)
	char bCastFarShadow : 1; // 0x2c4(0x01)
	char bCastInsetShadow : 1; // 0x2c4(0x01)
	char bCastCinematicShadow : 1; // 0x2c4(0x01)
	char bCastHiddenShadow : 1; // 0x2c5(0x01)
	char bCastShadowAsTwoSided : 1; // 0x2c5(0x01)
	char bLightAsIfStatic : 1; // 0x2c5(0x01)
	char bLightAttachmentsAsGroup : 1; // 0x2c5(0x01)
	char bExcludeFromLightAttachmentGroup : 1; // 0x2c5(0x01)
	char bReceiveMobileCSMShadows : 1; // 0x2c5(0x01)
	char bSingleSampleShadowFromStationaryLights : 1; // 0x2c5(0x01)
	char bIgnoreRadialImpulse : 1; // 0x2c5(0x01)
	char bIgnoreRadialForce : 1; // 0x2c6(0x01)
	char bApplyImpulseOnDamage : 1; // 0x2c6(0x01)
	char bReplicatePhysicsToAutonomousProxy : 1; // 0x2c6(0x01)
	char bFillCollisionUnderneathForNavmesh : 1; // 0x2c6(0x01)
	char AlwaysLoadOnClient : 1; // 0x2c6(0x01)
	char AlwaysLoadOnServer : 1; // 0x2c6(0x01)
	char bUseEditorCompositing : 1; // 0x2c6(0x01)
	char bIsBeingMovedByEditor : 1; // 0x2c6(0x01)
	char bRenderCustomDepth : 1; // 0x2c7(0x01)
	char bVisibleInSceneCaptureOnly : 1; // 0x2c7(0x01)
	char bHiddenInSceneCapture : 1; // 0x2c7(0x01)
	char bRayTracingFarField : 1; // 0x2c7(0x01)
	char pad_5A7_4 : 1; // 0x5a7(0x01)
	char bHasNoStreamableTextures : 1; // 0x2c7(0x01)
	enum class EHasCustomNavigableGeometry bHasCustomNavigableGeometry; // 0x2c8(0x01)
	enum class ECanBeCharacterBase CanCharacterStepUpOn; // 0x2ca(0x01)
	struct FLightingChannels LightingChannels; // 0x2cb(0x01)
	int32_t RayTracingGroupId; // 0x2cc(0x04)
	int32_t VisibilityId; // 0x2d0(0x04)
	int32_t CustomDepthStencilValue; // 0x2d4(0x04)
	struct FCustomPrimitiveData CustomPrimitiveData; // 0x2d8(0x10)
	struct FCustomPrimitiveData CustomPrimitiveDataInternal; // 0x2e8(0x10)
	int32_t TranslucencySortPriority; // 0x300(0x04)
	float TranslucencySortDistanceOffset; // 0x304(0x04)
	struct TArray<struct URuntimeVirtualTexture*> RuntimeVirtualTextures; // 0x308(0x10)
	int8_t VirtualTextureLodBias; // 0x318(0x01)
	int8_t VirtualTextureCullMips; // 0x319(0x01)
	int8_t VirtualTextureMinCoverage; // 0x31a(0x01)
	enum class ERuntimeVirtualTextureMainPassType VirtualTextureRenderPassType; // 0x31b(0x01)
	float BoundsScale; // 0x32c(0x04)
	struct TArray<struct AActor*> MoveIgnoreActors; // 0x340(0x10)
	struct TArray<struct UPrimitiveComponent*> MoveIgnoreComponents; // 0x350(0x10)
	struct FBodyInstance BodyInstance; // 0x370(0x190)
	struct FMulticastSparseDelegate OnComponentHit; // 0x500(0x01)
	struct FMulticastSparseDelegate OnComponentBeginOverlap; // 0x501(0x01)
	struct FMulticastSparseDelegate OnComponentEndOverlap; // 0x502(0x01)
	struct FMulticastSparseDelegate OnComponentWake; // 0x503(0x01)
	struct FMulticastSparseDelegate OnComponentSleep; // 0x504(0x01)
	struct FMulticastSparseDelegate OnComponentPhysicsStateChanged; // 0x506(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x507(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x508(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x509(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x50a(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x50b(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x50c(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x50d(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x50e(0x01)
	enum class ERayTracingGroupCullingPriority RayTracingGroupCullingPriority; // 0x50f(0x01)
	enum class ERendererStencilMask CustomDepthStencilWriteMask; // 0x510(0x01)
	struct UPrimitiveComponent* LODParentPrimitive; // 0x530(0x08)
};

// Class AIModule.EQSTestingPawn
// Size: 0x6c0 (Inherited: 0x620)
struct AEQSTestingPawn : ACharacter {
	struct UEnvQuery* QueryTemplate; // 0x620(0x08)
	struct TArray<struct FEnvNamedValue> QueryParams; // 0x628(0x10)
	struct TArray<struct FAIDynamicParam> QueryConfig; // 0x638(0x10)
	float TimeLimitPerStep; // 0x648(0x04)
	int32_t StepToDebugDraw; // 0x64c(0x04)
	enum class EEnvQueryHightlightMode HighlightMode; // 0x650(0x01)
	char pad_651[0x3]; // 0x651(0x03)
	char bDrawLabels : 1; // 0x654(0x01)
	char bDrawFailedItems : 1; // 0x654(0x01)
	char bReRunQueryOnlyOnFinishedMove : 1; // 0x654(0x01)
	char bShouldBeVisibleInGame : 1; // 0x654(0x01)
	char bTickDuringGame : 1; // 0x654(0x01)
	char pad_654_5 : 3; // 0x654(0x01)
	char pad_655[0x3]; // 0x655(0x03)
	enum class EEnvQueryRunMode QueryingMode; // 0x658(0x01)
	char pad_659[0x7]; // 0x659(0x07)
	struct FNavAgentProperties NavAgentProperties; // 0x660(0x38)
	char pad_698[0x28]; // 0x698(0x28)
};

// Class AIModule.EnvQueryGenerator_ActorsOfClass
// Size: 0xd0 (Inherited: 0x50)
struct UEnvQueryGenerator_ActorsOfClass : UEnvQueryGenerator {
	struct AActor* SearchedActorClass; // 0x50(0x08)
	struct FAIDataProviderBoolValue GenerateOnlyActorsInRadius; // 0x58(0x38)
	struct FAIDataProviderFloatValue SearchRadius; // 0x90(0x38)
	struct UEnvQueryContext* SearchCenter; // 0xc8(0x08)
};

// Class AIModule.EnvQueryGenerator_BlueprintBase
// Size: 0x88 (Inherited: 0x50)
struct UEnvQueryGenerator_BlueprintBase : UEnvQueryGenerator {
	struct FText GeneratorsActionDescription; // 0x50(0x18)
	struct UEnvQueryContext* Context; // 0x68(0x08)
	struct UEnvQueryItemType* GeneratedItemType; // 0x70(0x08)
	char pad_78[0x10]; // 0x78(0x10)

	struct UObject* GetQuerier(); // Function AIModule.EnvQueryGenerator_BlueprintBase.GetQuerier // (None) // @ game+0xffffd38fdf830041
};

// Class AIModule.EnvQueryGenerator_Composite
// Size: 0x70 (Inherited: 0x50)
struct UEnvQueryGenerator_Composite : UEnvQueryGenerator {
	struct TArray<struct UEnvQueryGenerator*> Generators; // 0x50(0x10)
	char bAllowDifferentItemTypes : 1; // 0x60(0x01)
	char bHasMatchingItemType : 1; // 0x60(0x01)
	char pad_60_2 : 6; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
	struct UEnvQueryItemType* ForcedItemType; // 0x68(0x08)
};

// Class AIModule.EnvQueryGenerator_ProjectedPoints
// Size: 0x90 (Inherited: 0x50)
struct UEnvQueryGenerator_ProjectedPoints : UEnvQueryGenerator {
	struct FEnvTraceData ProjectionData; // 0x50(0x40)
};

// Class AIModule.EnvQueryGenerator_Cone
// Size: 0x180 (Inherited: 0x90)
struct UEnvQueryGenerator_Cone : UEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderFloatValue AlignedPointsDistance; // 0x90(0x38)
	struct FAIDataProviderFloatValue ConeDegrees; // 0xc8(0x38)
	struct FAIDataProviderFloatValue AngleStep; // 0x100(0x38)
	struct FAIDataProviderFloatValue Range; // 0x138(0x38)
	struct UEnvQueryContext* CenterActor; // 0x170(0x08)
	char bIncludeContextLocation : 1; // 0x178(0x01)
	char pad_178_1 : 7; // 0x178(0x01)
	char pad_179[0x7]; // 0x179(0x07)
};

// Class AIModule.EnvQueryGenerator_CurrentLocation
// Size: 0x58 (Inherited: 0x50)
struct UEnvQueryGenerator_CurrentLocation : UEnvQueryGenerator {
	struct UEnvQueryContext* QueryContext; // 0x50(0x08)
};

// Class AIModule.EnvQueryGenerator_Donut
// Size: 0x1e0 (Inherited: 0x90)
struct UEnvQueryGenerator_Donut : UEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderFloatValue InnerRadius; // 0x90(0x38)
	struct FAIDataProviderFloatValue OuterRadius; // 0xc8(0x38)
	struct FAIDataProviderIntValue NumberOfRings; // 0x100(0x38)
	struct FAIDataProviderIntValue PointsPerRing; // 0x138(0x38)
	struct FEnvDirection ArcDirection; // 0x170(0x20)
	struct FAIDataProviderFloatValue ArcAngle; // 0x190(0x38)
	bool bUseSpiralPattern; // 0x1c8(0x01)
	char pad_1C9[0x7]; // 0x1c9(0x07)
	struct UEnvQueryContext* Center; // 0x1d0(0x08)
	char bDefineArc : 1; // 0x1d8(0x01)
	char pad_1D8_1 : 7; // 0x1d8(0x01)
	char pad_1D9[0x7]; // 0x1d9(0x07)
};

// Class AIModule.EnvQueryGenerator_OnCircle
// Size: 0x230 (Inherited: 0x90)
struct UEnvQueryGenerator_OnCircle : UEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderFloatValue CircleRadius; // 0x90(0x38)
	struct FAIDataProviderFloatValue SpaceBetween; // 0xc8(0x38)
	struct FAIDataProviderIntValue NumberOfPoints; // 0x100(0x38)
	enum class EPointOnCircleSpacingMethod PointOnCircleSpacingMethod; // 0x138(0x01)
	char pad_139[0x7]; // 0x139(0x07)
	struct FEnvDirection ArcDirection; // 0x140(0x20)
	struct FAIDataProviderFloatValue ArcAngle; // 0x160(0x38)
	float AngleRadians; // 0x198(0x04)
	char pad_19C[0x4]; // 0x19c(0x04)
	struct UEnvQueryContext* CircleCenter; // 0x1a0(0x08)
	bool bIgnoreAnyContextActorsWhenGeneratingCircle; // 0x1a8(0x01)
	char pad_1A9[0x7]; // 0x1a9(0x07)
	struct FAIDataProviderFloatValue CircleCenterZOffset; // 0x1b0(0x38)
	struct FEnvTraceData TraceData; // 0x1e8(0x40)
	char bDefineArc : 1; // 0x228(0x01)
	char pad_228_1 : 7; // 0x228(0x01)
	char pad_229[0x7]; // 0x229(0x07)
};

// Class AIModule.EnvQueryGenerator_SimpleGrid
// Size: 0x108 (Inherited: 0x90)
struct UEnvQueryGenerator_SimpleGrid : UEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderFloatValue GridSize; // 0x90(0x38)
	struct FAIDataProviderFloatValue SpaceBetween; // 0xc8(0x38)
	struct UEnvQueryContext* GenerateAround; // 0x100(0x08)
};

// Class AIModule.EnvQueryGenerator_PathingGrid
// Size: 0x180 (Inherited: 0x108)
struct UEnvQueryGenerator_PathingGrid : UEnvQueryGenerator_SimpleGrid {
	struct FAIDataProviderBoolValue PathToItem; // 0x108(0x38)
	struct UNavigationQueryFilter* NavigationFilter; // 0x140(0x08)
	struct FAIDataProviderFloatValue ScanRangeMultiplier; // 0x148(0x38)
};

// Class AIModule.EnvQueryGenerator_PerceivedActors
// Size: 0xa8 (Inherited: 0x50)
struct UEnvQueryGenerator_PerceivedActors : UEnvQueryGenerator {
	struct AActor* AllowedActorClass; // 0x50(0x08)
	struct FAIDataProviderFloatValue SearchRadius; // 0x58(0x38)
	struct UEnvQueryContext* ListenerContext; // 0x90(0x08)
	struct UAISense* SenseToUse; // 0x98(0x08)
	bool bIncludeKnownActors; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)
};

// Class AIModule.EnvQueryItemType
// Size: 0x30 (Inherited: 0x28)
struct UEnvQueryItemType : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class AIModule.EnvQueryItemType_VectorBase
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryItemType_VectorBase : UEnvQueryItemType {
};

// Class AIModule.EnvQueryItemType_ActorBase
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryItemType_ActorBase : UEnvQueryItemType_VectorBase {
};

// Class AIModule.EnvQueryItemType_Actor
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryItemType_Actor : UEnvQueryItemType_ActorBase {
};

// Class AIModule.EnvQueryItemType_Direction
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryItemType_Direction : UEnvQueryItemType_VectorBase {
};

// Class AIModule.EnvQueryItemType_Point
// Size: 0x30 (Inherited: 0x30)
struct UEnvQueryItemType_Point : UEnvQueryItemType_VectorBase {
};

// Class AIModule.EnvQueryTest_Distance
// Size: 0x208 (Inherited: 0x1f8)
struct UEnvQueryTest_Distance : UEnvQueryTest {
	enum class EEnvTestDistance TestMode; // 0x1f8(0x01)
	char pad_1F9[0x7]; // 0x1f9(0x07)
	struct UEnvQueryContext* DistanceTo; // 0x200(0x08)
};

// Class AIModule.EnvQueryTest_Dot
// Size: 0x240 (Inherited: 0x1f8)
struct UEnvQueryTest_Dot : UEnvQueryTest {
	struct FEnvDirection LineA; // 0x1f8(0x20)
	struct FEnvDirection LineB; // 0x218(0x20)
	enum class EEnvTestDot TestMode; // 0x238(0x01)
	bool bAbsoluteValue; // 0x239(0x01)
	char pad_23A[0x6]; // 0x23a(0x06)
};

// Class AIModule.EnvQueryTest_GameplayTags
// Size: 0x268 (Inherited: 0x1f8)
struct UEnvQueryTest_GameplayTags : UEnvQueryTest {
	struct FGameplayTagQuery TagQueryToMatch; // 0x1f8(0x48)
	bool bRejectIncompatibleItems; // 0x240(0x01)
	bool bUpdatedToUseQuery; // 0x241(0x01)
	enum class EGameplayContainerMatchType TagsToMatch; // 0x242(0x01)
	char pad_243[0x5]; // 0x243(0x05)
	struct FGameplayTagContainer GameplayTags; // 0x248(0x20)
};

// Class AIModule.EnvQueryTest_Overlap
// Size: 0x228 (Inherited: 0x1f8)
struct UEnvQueryTest_Overlap : UEnvQueryTest {
	struct FEnvOverlapData OverlapData; // 0x1f8(0x30)
};

// Class AIModule.EnvQueryTest_Pathfinding
// Size: 0x280 (Inherited: 0x1f8)
struct UEnvQueryTest_Pathfinding : UEnvQueryTest {
	enum class EEnvTestPathfinding TestMode; // 0x1f8(0x01)
	char pad_1F9[0x7]; // 0x1f9(0x07)
	struct UEnvQueryContext* Context; // 0x200(0x08)
	struct FAIDataProviderBoolValue PathFromContext; // 0x208(0x38)
	struct FAIDataProviderBoolValue SkipUnreachable; // 0x240(0x38)
	struct UNavigationQueryFilter* FilterClass; // 0x278(0x08)
};

// Class AIModule.EnvQueryTest_PathfindingBatch
// Size: 0x2b8 (Inherited: 0x280)
struct UEnvQueryTest_PathfindingBatch : UEnvQueryTest_Pathfinding {
	struct FAIDataProviderFloatValue ScanRangeMultiplier; // 0x280(0x38)
};

// Class AIModule.EnvQueryTest_Project
// Size: 0x238 (Inherited: 0x1f8)
struct UEnvQueryTest_Project : UEnvQueryTest {
	struct FEnvTraceData ProjectionData; // 0x1f8(0x40)
};

// Class AIModule.EnvQueryTest_Random
// Size: 0x1f8 (Inherited: 0x1f8)
struct UEnvQueryTest_Random : UEnvQueryTest {
	int32_t TestOrder; // 0x30(0x04)
	enum class EEnvTestPurpose TestPurpose; // 0x34(0x01)
	struct FString TestComment; // 0x38(0x10)
	enum class EEnvTestFilterOperator MultipleContextFilterOp; // 0x48(0x01)
	enum class EEnvTestScoreOperator MultipleContextScoreOp; // 0x49(0x01)
	enum class EEnvTestFilterType FilterType; // 0x4a(0x01)
	struct FAIDataProviderBoolValue BoolValue; // 0x50(0x38)
	struct FAIDataProviderFloatValue FloatValueMin; // 0x88(0x38)
	struct FAIDataProviderFloatValue FloatValueMax; // 0xc0(0x38)
	enum class EEnvTestScoreEquation ScoringEquation; // 0xf9(0x01)
	enum class EEnvQueryTestClamping ClampMinType; // 0xfa(0x01)
	enum class EEnvQueryTestClamping ClampMaxType; // 0xfb(0x01)
	enum class EEQSNormalizationType NormalizationType; // 0xfc(0x01)
	struct FAIDataProviderFloatValue ScoreClampMin; // 0x100(0x38)
	struct FAIDataProviderFloatValue ScoreClampMax; // 0x138(0x38)
	struct FAIDataProviderFloatValue ScoringFactor; // 0x170(0x38)
	struct FAIDataProviderFloatValue ReferenceValue; // 0x1a8(0x38)
	bool bDefineReferenceValue; // 0x1e0(0x01)
	char bWorkOnFloatValues : 1; // 0x1f0(0x01)
};

// Class AIModule.EnvQueryTest_Trace
// Size: 0x2e8 (Inherited: 0x1f8)
struct UEnvQueryTest_Trace : UEnvQueryTest {
	struct FEnvTraceData TraceData; // 0x1f8(0x40)
	struct FAIDataProviderBoolValue TraceFromContext; // 0x238(0x38)
	struct FAIDataProviderFloatValue ItemHeightOffset; // 0x270(0x38)
	struct FAIDataProviderFloatValue ContextHeightOffset; // 0x2a8(0x38)
	struct UEnvQueryContext* Context; // 0x2e0(0x08)
};

// Class AIModule.EnvQueryTest_Volume
// Size: 0x210 (Inherited: 0x1f8)
struct UEnvQueryTest_Volume : UEnvQueryTest {
	struct UEnvQueryContext* VolumeContext; // 0x1f8(0x08)
	struct AVolume* VolumeClass; // 0x200(0x08)
	char bDoComplexVolumeTest : 1; // 0x208(0x01)
	char pad_208_1 : 7; // 0x208(0x01)
	char pad_209[0x7]; // 0x209(0x07)
};

// Class AIModule.GridPathAIController
// Size: 0x3b8 (Inherited: 0x3b8)
struct AGridPathAIController : AAIController {
	char bStartAILogicOnPossess : 1; // 0x360(0x01)
	char bStopAILogicOnUnposses : 1; // 0x360(0x01)
	char bLOSflag : 1; // 0x360(0x01)
	char bSkipExtraLOSChecks : 1; // 0x360(0x01)
	char bAllowStrafe : 1; // 0x360(0x01)
	char bWantsPlayerState : 1; // 0x360(0x01)
	char bSetControlRotationFromPawnOrientation : 1; // 0x360(0x01)
	struct UPathFollowingComponent* PathFollowingComponent; // 0x368(0x08)
	struct UBrainComponent* BrainComponent; // 0x370(0x08)
	struct UAIPerceptionComponent* PerceptionComponent; // 0x378(0x08)
	struct UPawnActionsComponent* ActionsComp; // 0x380(0x08)
	struct UBlackboardComponent* Blackboard; // 0x388(0x08)
	struct UGameplayTasksComponent* CachedGameplayTasksComponent; // 0x390(0x08)
	struct UNavigationQueryFilter* DefaultNavigationFilterClass; // 0x398(0x08)
	struct FMulticastInlineDelegate ReceiveMoveCompleted; // 0x3a0(0x10)
};

// Class AIModule.AIHotSpotManager
// Size: 0x28 (Inherited: 0x28)
struct UAIHotSpotManager : UObject {
};

// Class AIModule.PathFollowingComponent
// Size: 0x2b8 (Inherited: 0xa0)
struct UPathFollowingComponent : UActorComponent {
	char pad_A0[0x38]; // 0xa0(0x38)
	struct UNavMovementComponent* MovementComp; // 0xd8(0x08)
	char pad_E0[0x8]; // 0xe0(0x08)
	struct ANavigationData* MyNavData; // 0xe8(0x08)
	char pad_F0[0x1c8]; // 0xf0(0x1c8)

	void OnNavDataRegistered(struct ANavigationData* NavData); // Function AIModule.PathFollowingComponent.OnNavDataRegistered // (None) // @ game+0xffffd393df830041
};

// Class AIModule.CrowdFollowingComponent
// Size: 0x308 (Inherited: 0x2b8)
struct UCrowdFollowingComponent : UPathFollowingComponent {
	char pad_2B8[0x18]; // 0x2b8(0x18)
	struct FVector CrowdAgentMoveDirection; // 0x2d0(0x18)
	char pad_2E8[0x20]; // 0x2e8(0x20)

	void SuspendCrowdSteering(bool bSuspend); // Function AIModule.CrowdFollowingComponent.SuspendCrowdSteering // (None) // @ game+0xffffd394df830041
};

// Class AIModule.CrowdManager
// Size: 0xf0 (Inherited: 0x28)
struct UCrowdManager : UCrowdManagerBase {
	struct ANavigationData* MyNavData; // 0x28(0x08)
	struct TArray<struct FCrowdAvoidanceConfig> AvoidanceConfig; // 0x30(0x10)
	struct TArray<struct FCrowdAvoidanceSamplingPattern> SamplingPatterns; // 0x40(0x10)
	int32_t MaxAgents; // 0x50(0x04)
	float MaxAgentRadius; // 0x54(0x04)
	int32_t MaxAvoidedAgents; // 0x58(0x04)
	int32_t MaxAvoidedWalls; // 0x5c(0x04)
	float NavmeshCheckInterval; // 0x60(0x04)
	float PathOptimizationInterval; // 0x64(0x04)
	float SeparationDirClamp; // 0x68(0x04)
	float PathOffsetRadiusMultiplier; // 0x6c(0x04)
	char pad_70_0 : 4; // 0x70(0x01)
	char bResolveCollisions : 1; // 0x70(0x01)
	char pad_70_5 : 3; // 0x70(0x01)
	char pad_71[0x7f]; // 0x71(0x7f)
};

// Class AIModule.GridPathFollowingComponent
// Size: 0x2e8 (Inherited: 0x2b8)
struct UGridPathFollowingComponent : UPathFollowingComponent {
	struct UNavLocalGridManager* GridManager; // 0x2b8(0x08)
	char pad_2C0[0x28]; // 0x2c0(0x28)
};

// Class AIModule.NavFilter_AIControllerDefault
// Size: 0x48 (Inherited: 0x48)
struct UNavFilter_AIControllerDefault : UNavigationQueryFilter {
	struct TArray<struct FNavigationFilterArea> Areas; // 0x28(0x10)
	struct FNavigationFilterFlags IncludeFlags; // 0x38(0x04)
	struct FNavigationFilterFlags ExcludeFlags; // 0x3c(0x04)
};

// Class AIModule.NavLinkProxy
// Size: 0x2e0 (Inherited: 0x290)
struct ANavLinkProxy : AActor {
	char pad_290[0x10]; // 0x290(0x10)
	struct TArray<struct FNavigationLink> PointLinks; // 0x2a0(0x10)
	struct TArray<struct FNavigationSegmentLink> SegmentLinks; // 0x2b0(0x10)
	struct UNavLinkCustomComponent* SmartLinkComp; // 0x2c0(0x08)
	bool bSmartLinkIsRelevant; // 0x2c8(0x01)
	char pad_2C9[0x7]; // 0x2c9(0x07)
	struct FMulticastInlineDelegate OnSmartLinkReached; // 0x2d0(0x10)

	void SetSmartLinkEnabled(bool bEnabled); // Function AIModule.NavLinkProxy.SetSmartLinkEnabled // (None) // @ game+0xffffd399df830041
};

// Class AIModule.NavLocalGridManager
// Size: 0x58 (Inherited: 0x28)
struct UNavLocalGridManager : UObject {
	char pad_28[0x30]; // 0x28(0x30)

	bool SetLocalNavigationGridDensity(struct UObject* WorldContextObject, float CellSize); // Function AIModule.NavLocalGridManager.SetLocalNavigationGridDensity // (None) // @ game+0xffffd3a0df830041
};

// Class AIModule.PathFollowingManager
// Size: 0x28 (Inherited: 0x28)
struct UPathFollowingManager : UObject {
};

// Class AIModule.AIPerceptionListenerInterface
// Size: 0x28 (Inherited: 0x28)
struct UAIPerceptionListenerInterface : UInterface {
};

// Class AIModule.AIPerceptionStimuliSourceComponent
// Size: 0xb8 (Inherited: 0xa0)
struct UAIPerceptionStimuliSourceComponent : UActorComponent {
	char bAutoRegisterAsSource : 1; // 0xa0(0x01)
	char pad_A0_1 : 7; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)
	struct TArray<struct UAISense*> RegisterAsSourceForSenses; // 0xa8(0x10)

	void UnregisterFromSense(struct UAISense* SenseClass); // Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromSense // (None) // @ game+0xffffd3a4df830041
};

// Class AIModule.AIPerceptionSystem
// Size: 0x130 (Inherited: 0x38)
struct UAIPerceptionSystem : UAISubsystem {
	char pad_38[0x50]; // 0x38(0x50)
	struct TArray<struct UAISense*> Senses; // 0x88(0x10)
	float PerceptionAgingRate; // 0x98(0x04)
	char pad_9C[0x94]; // 0x9c(0x94)

	void ReportPerceptionEvent(struct UObject* WorldContextObject, struct UAISenseEvent* PerceptionEvent); // Function AIModule.AIPerceptionSystem.ReportPerceptionEvent // (None) // @ game+0xffffd3a9df830041
};

// Class AIModule.AISense
// Size: 0x80 (Inherited: 0x28)
struct UAISense : UObject {
	float DefaultExpirationAge; // 0x28(0x04)
	enum class EAISenseNotifyType NotifyType; // 0x2c(0x01)
	char pad_2D[0x3]; // 0x2d(0x03)
	char bWantsNewPawnNotification : 1; // 0x30(0x01)
	char bAutoRegisterAllPawnsAsSources : 1; // 0x30(0x01)
	char pad_30_2 : 6; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct UAIPerceptionSystem* PerceptionSystemInstance; // 0x38(0x08)
	char pad_40[0x40]; // 0x40(0x40)
};

// Class AIModule.AISenseConfig_Damage
// Size: 0x50 (Inherited: 0x48)
struct UAISenseConfig_Damage : UAISenseConfig {
	struct UAISense_Damage* Implementation; // 0x48(0x08)
};

// Class AIModule.AISense_Blueprint
// Size: 0xa8 (Inherited: 0x80)
struct UAISense_Blueprint : UAISense {
	struct UUserDefinedStruct* ListenerDataType; // 0x80(0x08)
	struct TArray<struct UAIPerceptionComponent*> ListenerContainer; // 0x88(0x10)
	struct TArray<struct UAISenseEvent*> UnprocessedEvents; // 0x98(0x10)

	float OnUpdate(struct TArray<struct UAISenseEvent*>& EventsToProcess); // Function AIModule.AISense_Blueprint.OnUpdate // (None) // @ game+0xffffd3b0df830041
};

// Class AIModule.AISense_Damage
// Size: 0x90 (Inherited: 0x80)
struct UAISense_Damage : UAISense {
	struct TArray<struct FAIDamageEvent> RegisteredEvents; // 0x80(0x10)

	void ReportDamageEvent(struct UObject* WorldContextObject, struct AActor* DamagedActor, struct AActor* Instigator, float DamageAmount, struct FVector EventLocation, struct FVector HitLocation, struct FName Tag); // Function AIModule.AISense_Damage.ReportDamageEvent // (None) // @ game+0xffffd3b1df830041
};

// Class AIModule.AISense_Hearing
// Size: 0xe8 (Inherited: 0x80)
struct UAISense_Hearing : UAISense {
	struct TArray<struct FAINoiseEvent> NoiseEvents; // 0x80(0x10)
	float SpeedOfSoundSq; // 0x90(0x04)
	char pad_94[0x54]; // 0x94(0x54)

	void ReportNoiseEvent(struct UObject* WorldContextObject, struct FVector NoiseLocation, float Loudness, struct AActor* Instigator, float MaxRange, struct FName Tag); // Function AIModule.AISense_Hearing.ReportNoiseEvent // (None) // @ game+0xffffd3b2df830041
};

// Class AIModule.AISense_Prediction
// Size: 0x90 (Inherited: 0x80)
struct UAISense_Prediction : UAISense {
	struct TArray<struct FAIPredictionEvent> RegisteredEvents; // 0x80(0x10)

	void RequestPawnPredictionEvent(struct APawn* Requestor, struct AActor* PredictedActor, float PredictionTime); // Function AIModule.AISense_Prediction.RequestPawnPredictionEvent // (None) // @ game+0xffffd3b4df830041
};

// Class AIModule.AISense_Sight
// Size: 0x170 (Inherited: 0x80)
struct UAISense_Sight : UAISense {
	char pad_80[0xc8]; // 0x80(0xc8)
	int32_t MaxTracesPerTick; // 0x148(0x04)
	int32_t MinQueriesPerTimeSliceCheck; // 0x14c(0x04)
	double MaxTimeSlicePerTick; // 0x150(0x08)
	float HighImportanceQueryDistanceThreshold; // 0x158(0x04)
	char pad_15C[0x4]; // 0x15c(0x04)
	float MaxQueryImportance; // 0x160(0x04)
	float SightLimitQueryImportance; // 0x164(0x04)
	char pad_168[0x8]; // 0x168(0x08)
};

// Class AIModule.AISense_Team
// Size: 0x90 (Inherited: 0x80)
struct UAISense_Team : UAISense {
	struct TArray<struct FAITeamStimulusEvent> RegisteredEvents; // 0x80(0x10)
};

// Class AIModule.AISense_Touch
// Size: 0x90 (Inherited: 0x80)
struct UAISense_Touch : UAISense {
	struct TArray<struct FAITouchEvent> RegisteredEvents; // 0x80(0x10)

	void ReportTouchEvent(struct UObject* WorldContextObject, struct AActor* TouchReceiver, struct AActor* OtherActor, struct FVector Location); // Function AIModule.AISense_Touch.ReportTouchEvent // (None) // @ game+0xffffd3b5df830041
};

// Class AIModule.AISightTargetInterface
// Size: 0x28 (Inherited: 0x28)
struct UAISightTargetInterface : UInterface {
};

// Class AIModule.PawnSensingComponent
// Size: 0xe8 (Inherited: 0xa0)
struct UPawnSensingComponent : UActorComponent {
	float HearingThreshold; // 0xa0(0x04)
	float LOSHearingThreshold; // 0xa4(0x04)
	float SightRadius; // 0xa8(0x04)
	float SensingInterval; // 0xac(0x04)
	float HearingMaxSoundAge; // 0xb0(0x04)
	char bEnableSensingUpdates : 1; // 0xb4(0x01)
	char bOnlySensePlayers : 1; // 0xb4(0x01)
	char bSeePawns : 1; // 0xb4(0x01)
	char bHearNoises : 1; // 0xb4(0x01)
	char pad_B4_4 : 4; // 0xb4(0x01)
	char pad_B5[0xb]; // 0xb5(0x0b)
	struct FMulticastInlineDelegate OnSeePawn; // 0xc0(0x10)
	struct FMulticastInlineDelegate OnHearNoise; // 0xd0(0x10)
	float PeripheralVisionAngle; // 0xe0(0x04)
	float PeripheralVisionCosine; // 0xe4(0x04)

	void SetSensingUpdatesEnabled(bool bEnabled); // Function AIModule.PawnSensingComponent.SetSensingUpdatesEnabled // (None) // @ game+0xffffa948df830041
};

// Class AIModule.AITask
// Size: 0x70 (Inherited: 0x68)
struct UAITask : UGameplayTask {
	struct AAIController* OwnerController; // 0x68(0x08)
};

// Class AIModule.AITask_LockLogic
// Size: 0x70 (Inherited: 0x70)
struct UAITask_LockLogic : UAITask {
	struct AAIController* OwnerController; // 0x68(0x08)
};

// Class AIModule.AITask_MoveTo
// Size: 0x118 (Inherited: 0x70)
struct UAITask_MoveTo : UAITask {
	struct FMulticastInlineDelegate OnRequestFailed; // 0x70(0x10)
	struct FMulticastInlineDelegate OnMoveFinished; // 0x80(0x10)
	struct FAIMoveRequest MoveRequest; // 0x90(0x48)
	char pad_D8[0x40]; // 0xd8(0x40)

	struct UAITask_MoveTo* AIMoveTo(struct AAIController* Controller, struct FVector GoalLocation, struct AActor* GoalActor, float AcceptanceRadius, enum class EAIOptionFlag StopOnOverlap, enum class EAIOptionFlag AcceptPartialPath, bool bUsePathfinding, bool bLockAILogic, bool bUseContinuousGoalTracking, enum class EAIOptionFlag ProjectGoalOnNavigation); // Function AIModule.AITask_MoveTo.AIMoveTo // (None) // @ game+0xffffd3b6df830041
};

// Class AIModule.AITask_RunEQS
// Size: 0xe8 (Inherited: 0x70)
struct UAITask_RunEQS : UAITask {
	struct AAIController* OwnerController; // 0x68(0x08)
	char pad_78[0x70]; // 0x78(0x70)

	struct UAITask_RunEQS* RunEQS(struct AAIController* Controller, struct UEnvQuery* QueryTemplate); // Function AIModule.AITask_RunEQS.RunEQS // (None) // @ game+0xffffd3b7df830041
};

// Class AIModule.VisualLoggerExtension
// Size: 0x28 (Inherited: 0x28)
struct UVisualLoggerExtension : UObject {
};

