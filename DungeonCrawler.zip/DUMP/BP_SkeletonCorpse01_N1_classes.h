// BlueprintGeneratedClass BP_SkeletonCorpse01_N1.BP_SkeletonCorpse01_N1_C
// Size: 0x530 (Inherited: 0x520)
struct ABP_SkeletonCorpse01_N1_C : ABP_Chest_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x520(0x08)
	struct UNavModifierComponent* NavModifier; // 0x528(0x08)

	void ReceiveBeginPlay(); // Function BP_SkeletonCorpse01_N1.BP_SkeletonCorpse01_N1_C.ReceiveBeginPlay // (None) // @ game+0xdcc9dfab0001
};

