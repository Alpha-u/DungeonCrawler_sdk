// BlueprintGeneratedClass BP_Mimic_Medium_Base.BP_Mimic_Medium_Base_C
// Size: 0x11d8 (Inherited: 0x11d0)
struct ABP_Mimic_Medium_Base_C : ABP_Mimic_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x11d0(0x08)

	void GameplayTagUpdated(struct FGameplayTag InGameplayTag, int32_t InCount); // Function BP_Mimic_Medium_Base.BP_Mimic_Medium_Base_C.GameplayTagUpdated // (None) // @ game+0x1084cdfab0008
};

