// BlueprintGeneratedClass BP_Roaster03On.BP_Roaster03On_C
// Size: 0x4d0 (Inherited: 0x488)
struct ABP_Roaster03On_C : ABP_LightSourceBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x488(0x08)
	struct UNiagaraComponent* Niagara; // 0x490(0x08)
	struct UParticleSystemComponent* ParticleSystem; // 0x498(0x08)
	struct UPointLightComponent* PointLight1; // 0x4a0(0x08)
	struct UStaticMeshComponent* Roaster; // 0x4a8(0x08)
	float Timeline_1______0_B16D46F84A6F4703D6A4F1B3D9388CC6; // 0x4b0(0x04)
	enum class ETimelineDirection Timeline_1__Direction_B16D46F84A6F4703D6A4F1B3D9388CC6; // 0x4b4(0x01)
	char pad_4B5[0x3]; // 0x4b5(0x03)
	struct UTimelineComponent* Timeline_2; // 0x4b8(0x08)
	float _____0______0_D5401464413E98B233A5D58C0DF85BF4; // 0x4c0(0x04)
	enum class ETimelineDirection _____0__Direction_D5401464413E98B233A5D58C0DF85BF4; // 0x4c4(0x01)
	char pad_4C5[0x3]; // 0x4c5(0x03)
	struct UTimelineComponent*  �� _1; // 0x4c8(0x08)

	void  ��임라인_0__Fini(); // Function BP_Roaster03On.BP_Roaster03On_C. ��임라인_0__Fini // (None) // @ game+0xffff8ff9df830e20
};

