// BlueprintGeneratedClass BP_DummyVoipActor.BP_DummyVoipActor_C
// Size: 0x300 (Inherited: 0x2f0)
struct ABP_DummyVoipActor_C : ADCActorBase {
	struct UBP_VoipAkComponent_C* ReceiveVoipAkComponent; // 0x2f0(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x2f8(0x08)
};

