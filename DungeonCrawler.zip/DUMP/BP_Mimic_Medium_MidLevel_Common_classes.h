// BlueprintGeneratedClass BP_Mimic_Medium_MidLevel_Common.BP_Mimic_Medium_MidLevel_Common_C
// Size: 0x11d8 (Inherited: 0x11d8)
struct ABP_Mimic_Medium_MidLevel_Common_C : ABP_Mimic_Medium_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x11d0(0x08)
};

