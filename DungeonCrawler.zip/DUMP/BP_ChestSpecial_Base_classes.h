// BlueprintGeneratedClass BP_ChestSpecial_Base.BP_ChestSpecial_Base_C
// Size: 0x4b0 (Inherited: 0x4a0)
struct ABP_ChestSpecial_Base_C : ABP_AnimatedChestBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4a0(0x08)
	struct UDCSkeletalMeshComponent* DCSkeletalMesh; // 0x4a8(0x08)

	void InteractFailed(struct AActor* Interacter, struct FGameplayTag EventTag); // Function BP_ChestSpecial_Base.BP_ChestSpecial_Base_C.InteractFailed // (None) // @ game+0xd75cdf870008
};

