// BlueprintGeneratedClass GA_ChargedRangedAttack.GA_ChargedRangedAttack_C
// Size: 0x5f8 (Inherited: 0x5c8)
struct UGA_ChargedRangedAttack_C : UGA_ChargedRangedAttackBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5c8(0x08)
	double RnadomAngle; // 0x5d0(0x08)
	double RnadomAngle_Sum; // 0x5d8(0x08)
	struct FVector EndTraceLocation; // 0x5e0(0x18)

	void OnSuccess_1109563B47783EC02F381C99DD38D5C5(struct AActor* ProjectileActor); // Function GA_ChargedRangedAttack.GA_ChargedRangedAttack_C.OnSuccess_1109563B47783EC02F381C99DD38D5C5 // (None) // @ game+0x3af4dfab0003
};

