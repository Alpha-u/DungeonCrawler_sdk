// BlueprintGeneratedClass BP_SingleGameSpawnerGroup.BP_SingleGameSpawnerGroup_C
// Size: 0x300 (Inherited: 0x2f8)
struct ABP_SingleGameSpawnerGroup_C : ADCGameSpawnerGroup {
	struct USceneComponent* DefaultSceneRoot; // 0x2f8(0x08)
};

