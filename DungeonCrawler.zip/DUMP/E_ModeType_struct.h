// UserDefinedEnum E_ModeType.E_ModeType
enum class E_ModeType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	E_MAX = 3
};

