// BlueprintGeneratedClass BP_SpellActor.BP_SpellActor_C
// Size: 0x410 (Inherited: 0x408)
struct ABP_SpellActor_C : ASpellActor {
	struct USceneComponent* DefaultSceneRoot; // 0x408(0x08)
};

