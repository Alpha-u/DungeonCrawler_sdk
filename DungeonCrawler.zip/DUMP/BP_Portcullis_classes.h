// BlueprintGeneratedClass BP_Portcullis.BP_Portcullis_C
// Size: 0x4c0 (Inherited: 0x4b8)
struct ABP_Portcullis_C : ABP_DoorBase_C {
	struct UArrowComponent* Arrow; // 0x4b8(0x08)
};

