// UserDefinedEnum E_NonPlayableTarget.E_NonPlayableTarget
enum class E_NonPlayableTarget : uint8 {
	NewEnumerator0 = 0,
	E_MAX = 1
};

