// BlueprintGeneratedClass BP_HuntingTrapProp_0001.BP_HuntingTrapProp_0001_C
// Size: 0x579 (Inherited: 0x524)
struct ABP_HuntingTrapProp_0001_C : ABP_TrapBase_C {
	char pad_524[0x4]; // 0x524(0x04)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x528(0x08)
	struct USkeletalMeshComponent* Pin; // 0x530(0x08)
	struct UChainComponent* chain; // 0x538(0x08)
	struct UBoxComponent* Box; // 0x540(0x08)
	struct ADCCharacterBase* TrappedCharacter; // 0x548(0x08)
	bool bDisarmed; // 0x550(0x01)
	char pad_551[0x3]; // 0x551(0x03)
	struct FPrimaryAssetId HuntingTrapRangeId; // 0x554(0x10)
	char pad_564[0x4]; // 0x564(0x04)
	double ConfineRange; // 0x568(0x08)
	double ChainSoundPlayMinVelocity; // 0x570(0x08)
	bool bPlayInstallSound; // 0x578(0x01)

	void OnRep_bDisarmed(); // Function BP_HuntingTrapProp_0001.BP_HuntingTrapProp_0001_C.OnRep_bDisarmed // (None) // @ game+0xffff800902622002
};

