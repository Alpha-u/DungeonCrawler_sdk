// BlueprintGeneratedClass BP_FootTrace.BP_FootTrace_C
// Size: 0x3c8 (Inherited: 0x298)
struct ABP_FootTrace_C : ADecalActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x298(0x08)
	struct UDCTagCollisionDetectorComponent* DCTagCollisionDetector; // 0x2a0(0x08)
	struct TMap<int32_t, struct UMaterialInstance*> FootTraceMaterialMap; // 0x2a8(0x50)
	bool bLeftFoot; // 0x2f8(0x01)
	char pad_2F9[0x7]; // 0x2f9(0x07)
	struct FRotator InRotator; // 0x300(0x18)
	struct UMaterialInstanceDynamic* DecalMaterialInstance; // 0x318(0x08)
	double FootTraceDuration; // 0x320(0x08)
	double CurrentDuration; // 0x328(0x08)
	struct FAccountDataReplication OwnerAccountDataReplication; // 0x330(0x78)
	struct FLinearColor Colour A; // 0x3a8(0x10)
	struct FLinearColor Colour B; // 0x3b8(0x10)

	void ReceiveBeginPlay(); // Function BP_FootTrace.BP_FootTrace_C.ReceiveBeginPlay // (None) // @ game+0xffff8009df830000
};

