// BlueprintGeneratedClass BP_Chest_Base.BP_Chest_Base_C
// Size: 0x520 (Inherited: 0x4a0)
struct ABP_Chest_Base_C : ABP_AnimatedChestBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4a0(0x08)
	struct UDCSkeletalMeshComponent* DCSkeletalMesh; // 0x4a8(0x08)
	struct TArray<struct ADCMonsterBase*> Monsters; // 0x4b0(0x10)
	int32_t Spawn Ratio; // 0x4c0(0x04)
	char pad_4C4[0x4]; // 0x4c4(0x04)
	double Random Delay; // 0x4c8(0x08)
	struct TMap<struct AActor*, struct FTimerHandle> TimerHandleMap; // 0x4d0(0x50)

	void InteractFailed(struct AActor* Interacter, struct FGameplayTag EventTag); // Function BP_Chest_Base.BP_Chest_Base_C.InteractFailed // (None) // @ game+0x10836dfab0001
};

