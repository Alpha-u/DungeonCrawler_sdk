// BlueprintGeneratedClass BP_DamageIndicator.BP_DamageIndicator_C
// Size: 0x2a8 (Inherited: 0x290)
struct ABP_DamageIndicator_C : AActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x290(0x08)
	struct UGameHeadupWidgetComponent* GameHeadupWidget; // 0x298(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x2a0(0x08)

	void OnDamgeIndicator(double Value, struct FVector Color, bool OnDefaultAnim, bool IsHitHead, bool CustomColor); // Function BP_DamageIndicator.BP_DamageIndicator_C.OnDamgeIndicator // (None) // @ game+0xe880df870008
};

