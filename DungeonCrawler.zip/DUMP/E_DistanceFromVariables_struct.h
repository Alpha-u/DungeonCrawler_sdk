// UserDefinedEnum E_DistanceFromVariables.E_DistanceFromVariables
enum class E_DistanceFromVariables : uint8 {
	NewEnumerator3 = 0,
	NewEnumerator0 = 1,
	NewEnumerator1 = 2,
	NewEnumerator4 = 3,
	E_MAX = 4
};

