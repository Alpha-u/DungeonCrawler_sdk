// BlueprintGeneratedClass BP_GameVoipComponent.BP_GameVoipComponent_C
// Size: 0x270 (Inherited: 0x270)
struct UBP_GameVoipComponent_C : UGameVoipComponent {
	struct TMap<struct FDCAccountId, struct FBindAccountUserData> BindAccountUserDataMap; // 0x220(0x50)
};

