// BlueprintGeneratedClass BP_Resurrection_Man_Capture.BP_Resurrection_Man_Capture_C
// Size: 0x680 (Inherited: 0x678)
struct ABP_Resurrection_Man_Capture_C : ABP_Resurrection_Capture_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x678(0x08)

	void OnEquipItemMesh(struct USkeletalMeshComponent* PartComp, struct USkeletalMesh* ItemMesh); // Function BP_Resurrection_Man_Capture.BP_Resurrection_Man_Capture_C.OnEquipItemMesh // (None) // @ game+0xffffeb8cdfab0001
};

