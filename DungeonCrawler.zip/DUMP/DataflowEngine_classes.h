// Class DataflowEngine.DataflowEdNode
// Size: 0xb8 (Inherited: 0x98)
struct UDataflowEdNode : UEdGraphNode {
	struct TArray<struct UEdGraphPin_Deprecated*> DeprecatedPins; // 0x38(0x10)
	int32_t NodePosX; // 0x48(0x04)
	int32_t NodePosY; // 0x4c(0x04)
	int32_t NodeWidth; // 0x50(0x04)
	int32_t NodeHeight; // 0x54(0x04)
	enum class ENodeAdvancedPins AdvancedPinDisplay; // 0x58(0x01)
	enum class ENodeEnabledState EnabledState; // 0x59(0x01)
	char pad_BA_0 : 1; // 0xba(0x01)
	char bDisplayAsDisabled : 1; // 0x5b(0x01)
	char bUserSetEnabledState : 1; // 0x5b(0x01)
	char bIsIntermediateNode : 1; // 0x5b(0x01)
	char bHasCompilerMessage : 1; // 0x5b(0x01)
	struct FString NodeComment; // 0x60(0x10)
	int32_t ErrorType; // 0x70(0x04)
	struct FString ErrorMsg; // 0x78(0x10)
	struct FGuid NodeGuid; // 0x88(0x10)
};

// Class DataflowEngine.Dataflow
// Size: 0x88 (Inherited: 0x60)
struct UDataflow : UEdGraph {
	char pad_60[0x10]; // 0x60(0x10)
	bool bActive; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
	struct TArray<struct UObject*> Targets; // 0x78(0x10)
};

