// Class AnimGraphRuntime.BlendSpacePlayerLibrary
// Size: 0x28 (Inherited: 0x28)
struct UBlendSpacePlayerLibrary : UBlueprintFunctionLibrary {

	bool ShouldResetPlayTimeWhenBlendSpaceChanges(struct FBlendSpacePlayerReference& BlendSpacePlayer); // Function AnimGraphRuntime.BlendSpacePlayerLibrary.ShouldResetPlayTimeWhenBlendSpaceChanges // (None) // @ game+0xffffc6c6df830041
};

// Class AnimGraphRuntime.LayeredBoneBlendLibrary
// Size: 0x28 (Inherited: 0x28)
struct ULayeredBoneBlendLibrary : UBlueprintFunctionLibrary {

	struct FLayeredBoneBlendReference SetBlendMask(struct FAnimUpdateContext& UpdateContext, struct FLayeredBoneBlendReference& LayeredBoneBlend, int32_t PoseIndex, struct FName BlendMaskName); // Function AnimGraphRuntime.LayeredBoneBlendLibrary.SetBlendMask // (None) // @ game+0xffffc6cadf830041
};

// Class AnimGraphRuntime.AnimationStateMachineLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAnimationStateMachineLibrary : UBlueprintFunctionLibrary {

	void SetState(struct FAnimUpdateContext& UpdateContext, struct FAnimationStateMachineReference& Node, struct FName TargetState, float Duration, enum class ETransitionLogicType BlendType, struct UBlendProfile* BlendProfile, enum class EAlphaBlendOption AlphaBlendOption, struct UCurveFloat* CustomBlendCurve); // Function AnimGraphRuntime.AnimationStateMachineLibrary.SetState // (None) // @ game+0xffffc6d4df830041
};

// Class AnimGraphRuntime.AnimExecutionContextLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAnimExecutionContextLibrary : UBlueprintFunctionLibrary {

	float GetDeltaTime(struct FAnimUpdateContext& Context); // Function AnimGraphRuntime.AnimExecutionContextLibrary.GetDeltaTime // (None) // @ game+0xffffc6dcdf830041
};

// Class AnimGraphRuntime.AnimNotify_PlayMontageNotify
// Size: 0x40 (Inherited: 0x38)
struct UAnimNotify_PlayMontageNotify : UAnimNotify {
	struct FName NotifyName; // 0x38(0x08)
};

// Class AnimGraphRuntime.AnimNotify_PlayMontageNotifyWindow
// Size: 0x38 (Inherited: 0x30)
struct UAnimNotify_PlayMontageNotifyWindow : UAnimNotifyState {
	struct FName NotifyName; // 0x30(0x08)
};

// Class AnimGraphRuntime.AnimSequencerInstance
// Size: 0x350 (Inherited: 0x350)
struct UAnimSequencerInstance : UAnimInstance {
	struct USkeleton* CurrentSkeleton; // 0x28(0x08)
	enum class ERootMotionMode RootMotionMode; // 0x30(0x01)
	char bUseMultiThreadedAnimationUpdate : 1; // 0x31(0x01)
	char bUsingCopyPoseFromMesh : 1; // 0x31(0x01)
	char pad_359_2 : 2; // 0x359(0x01)
	char bReceiveNotifiesFromLinkedInstances : 1; // 0x31(0x01)
	char bPropagateNotifiesToLinkedInstances : 1; // 0x31(0x01)
	char bUseMainInstanceMontageEvaluationData : 1; // 0x31(0x01)
	char bQueueMontageEvents : 1; // 0x31(0x01)
	struct FMulticastInlineDelegate OnMontageBlendingOut; // 0x38(0x10)
	struct FMulticastInlineDelegate OnMontageStarted; // 0x48(0x10)
	struct FMulticastInlineDelegate OnMontageEnded; // 0x58(0x10)
	struct FMulticastInlineDelegate OnAllMontageInstancesEnded; // 0x68(0x10)
	struct FAnimNotifyQueue NotifyQueue; // 0x150(0x70)
	struct TArray<struct FAnimNotifyEvent> ActiveAnimNotifyState; // 0x1c0(0x10)
	struct TArray<struct FAnimNotifyEventReference> ActiveAnimNotifyEventReference; // 0x1d0(0x10)
};

// Class AnimGraphRuntime.KismetAnimationLibrary
// Size: 0x28 (Inherited: 0x28)
struct UKismetAnimationLibrary : UBlueprintFunctionLibrary {

	void K2_TwoBoneIK(struct FVector& RootPos, struct FVector& JointPos, struct FVector& EndPos, struct FVector& JointTarget, struct FVector& Effector, struct FVector& OutJointPos, struct FVector& OutEndPos, bool bAllowStretching, float StartStretchRatio, float MaxStretchScale); // Function AnimGraphRuntime.KismetAnimationLibrary.K2_TwoBoneIK // (None) // @ game+0xffffc6e7df830041
};

// Class AnimGraphRuntime.LinkedAnimGraphLibrary
// Size: 0x28 (Inherited: 0x28)
struct ULinkedAnimGraphLibrary : UBlueprintFunctionLibrary {

	bool HasLinkedAnimInstance(struct FLinkedAnimGraphReference& Node); // Function AnimGraphRuntime.LinkedAnimGraphLibrary.HasLinkedAnimInstance // (None) // @ game+0xffffc6ebdf830041
};

// Class AnimGraphRuntime.PlayMontageCallbackProxy
// Size: 0xa8 (Inherited: 0x28)
struct UPlayMontageCallbackProxy : UObject {
	struct FMulticastInlineDelegate OnCompleted; // 0x28(0x10)
	struct FMulticastInlineDelegate OnBlendOut; // 0x38(0x10)
	struct FMulticastInlineDelegate OnInterrupted; // 0x48(0x10)
	struct FMulticastInlineDelegate OnNotifyBegin; // 0x58(0x10)
	struct FMulticastInlineDelegate OnNotifyEnd; // 0x68(0x10)
	char pad_78[0x30]; // 0x78(0x30)

	void OnNotifyEndReceived(struct FName NotifyName, struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload); // Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyEndReceived // (None) // @ game+0xffffc6f0df830041
};

// Class AnimGraphRuntime.SequenceEvaluatorLibrary
// Size: 0x28 (Inherited: 0x28)
struct USequenceEvaluatorLibrary : UBlueprintFunctionLibrary {

	struct FSequenceEvaluatorReference SetSequenceWithInertialBlending(struct FAnimUpdateContext& UpdateContext, struct FSequenceEvaluatorReference& SequenceEvaluator, struct UAnimSequenceBase* Sequence, float BlendTime); // Function AnimGraphRuntime.SequenceEvaluatorLibrary.SetSequenceWithInertialBlending // (None) // @ game+0xffffc6f8df830041
};

// Class AnimGraphRuntime.SequencePlayerLibrary
// Size: 0x28 (Inherited: 0x28)
struct USequencePlayerLibrary : UBlueprintFunctionLibrary {

	struct FSequencePlayerReference SetStartPosition(struct FSequencePlayerReference& SequencePlayer, float StartPosition); // Function AnimGraphRuntime.SequencePlayerLibrary.SetStartPosition // (None) // @ game+0xffffc706df830041
};

// Class AnimGraphRuntime.SequencerAnimationSupport
// Size: 0x28 (Inherited: 0x28)
struct USequencerAnimationSupport : UInterface {
};

// Class AnimGraphRuntime.SkeletalControlLibrary
// Size: 0x28 (Inherited: 0x28)
struct USkeletalControlLibrary : UBlueprintFunctionLibrary {

	struct FSkeletalControlReference SetAlpha(struct FSkeletalControlReference& SkeletalControl, float Alpha); // Function AnimGraphRuntime.SkeletalControlLibrary.SetAlpha // (None) // @ game+0xffffc70adf830041
};

