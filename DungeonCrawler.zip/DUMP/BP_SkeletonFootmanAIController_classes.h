// BlueprintGeneratedClass BP_SkeletonFootmanAIController.BP_SkeletonFootmanAIController_C
// Size: 0x458 (Inherited: 0x458)
struct ABP_SkeletonFootmanAIController_C : ABP_SkeletonAIController_C {
	struct UBaseObject* BaseObject; // 0x410(0x08)
	struct FGameplayTagContainer TargetInvisibleStateTagContainer; // 0x438(0x20)
};

