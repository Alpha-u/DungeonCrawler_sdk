// BlueprintGeneratedClass GA_DeathSwarmAura04.GA_DeathSwarmAura04_C
// Size: 0x5c0 (Inherited: 0x5c0)
struct UGA_DeathSwarmAura04_C : UGA_AuraBase {
	struct AActor* TargetActorClass; // 0x558(0x08)
	bool bUsePremadeSpec; // 0x560(0x01)
	struct FGameplayCueTag GameplayCueTag; // 0x564(0x08)
};

