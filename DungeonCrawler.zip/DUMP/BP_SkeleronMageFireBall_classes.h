// BlueprintGeneratedClass BP_SkeleronMageFireBall.BP_SkeleronMageFireBall_C
// Size: 0x6b0 (Inherited: 0x6b0)
struct ABP_SkeleronMageFireBall_C : ABP_ProjectileActor_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x690(0x08)
	struct UNiagaraComponent* Niagara; // 0x698(0x08)
	struct UParticleSystemComponent* TrailParticleSystem; // 0x6a0(0x08)
	struct UAkComponent* Ak; // 0x6a8(0x08)
};

