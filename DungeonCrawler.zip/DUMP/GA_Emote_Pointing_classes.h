// BlueprintGeneratedClass GA_Emote_Pointing.GA_Emote_Pointing_C
// Size: 0x560 (Inherited: 0x560)
struct UGA_Emote_Pointing_C : UGA_EmoteBase_C {
	struct UAnimMontage* MontageToPlay; // 0x558(0x08)
};

