// BlueprintGeneratedClass BP_HuntingTrapReticle.BP_HuntingTrapReticle_C
// Size: 0x2e8 (Inherited: 0x2d8)
struct ABP_HuntingTrapReticle_C : AGameplayAbilityWorldReticle_ActorVisualization {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d8(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x2e0(0x08)

	void SetReticleMaterialParamVector(struct FName ParamName, struct FVector Value); // Function BP_HuntingTrapReticle.BP_HuntingTrapReticle_C.SetReticleMaterialParamVector // (None) // @ game+0xffff8009dfb25a96
};

