// BlueprintGeneratedClass BP_ThrowingKnifeProjectileBase.BP_ThrowingKnifeProjectileBase_C
// Size: 0x6c0 (Inherited: 0x6c0)
struct ABP_ThrowingKnifeProjectileBase_C : ABP_ProjectileToSpawnItemHolder_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x6b0(0x08)
	struct ABP_PhysicalItemHolder_C* ItemHolderToSpawn; // 0x6b8(0x08)
};

