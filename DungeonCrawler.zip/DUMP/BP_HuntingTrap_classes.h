// BlueprintGeneratedClass BP_HuntingTrap.BP_HuntingTrap_C
// Size: 0x590 (Inherited: 0x578)
struct ABP_HuntingTrap_C : ABP_DCItemActor_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x578(0x08)
	struct USkeletalMeshComponent* Pin; // 0x580(0x08)
	struct UChainComponent* chain; // 0x588(0x08)

	void ReceiveBeginPlay(); // Function BP_HuntingTrap.BP_HuntingTrap_C.ReceiveBeginPlay // (None) // @ game+0xffff800902622002
};

