// Class CommonUI.CommonBoundActionButtonInterface
// Size: 0x28 (Inherited: 0x28)
struct UCommonBoundActionButtonInterface : UInterface {
};

// Class CommonUI.CommonStyleSheetTypeBase
// Size: 0x30 (Inherited: 0x28)
struct UCommonStyleSheetTypeBase : UObject {
	bool bIsEnabled; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// Class CommonUI.CommonStyleSheetTypeColor
// Size: 0x40 (Inherited: 0x30)
struct UCommonStyleSheetTypeColor : UCommonStyleSheetTypeBase {
	struct FLinearColor Color; // 0x30(0x10)
};

// Class CommonUI.CommonStyleSheetTypeOpacity
// Size: 0x38 (Inherited: 0x30)
struct UCommonStyleSheetTypeOpacity : UCommonStyleSheetTypeBase {
	float Opacity; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class CommonUI.CommonStyleSheetTypeLineHeightPercentage
// Size: 0x38 (Inherited: 0x30)
struct UCommonStyleSheetTypeLineHeightPercentage : UCommonStyleSheetTypeBase {
	float LineHeightPercentage; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class CommonUI.CommonStyleSheetTypeFontTypeface
// Size: 0x88 (Inherited: 0x30)
struct UCommonStyleSheetTypeFontTypeface : UCommonStyleSheetTypeBase {
	struct FSlateFontInfo Typeface; // 0x30(0x58)
};

// Class CommonUI.CommonStyleSheetTypeFontSize
// Size: 0x38 (Inherited: 0x30)
struct UCommonStyleSheetTypeFontSize : UCommonStyleSheetTypeBase {
	int32_t Size; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class CommonUI.CommonStyleSheetTypeFontLetterSpacing
// Size: 0x38 (Inherited: 0x30)
struct UCommonStyleSheetTypeFontLetterSpacing : UCommonStyleSheetTypeBase {
	int32_t LetterSpacing; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class CommonUI.CommonStyleSheetTypeMarginLeft
// Size: 0x38 (Inherited: 0x30)
struct UCommonStyleSheetTypeMarginLeft : UCommonStyleSheetTypeBase {
	float Left; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class CommonUI.CommonStyleSheetTypeMarginRight
// Size: 0x38 (Inherited: 0x30)
struct UCommonStyleSheetTypeMarginRight : UCommonStyleSheetTypeBase {
	float Right; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class CommonUI.CommonStyleSheetTypeMarginTop
// Size: 0x38 (Inherited: 0x30)
struct UCommonStyleSheetTypeMarginTop : UCommonStyleSheetTypeBase {
	float Top; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class CommonUI.CommonStyleSheetTypeMarginBottom
// Size: 0x38 (Inherited: 0x30)
struct UCommonStyleSheetTypeMarginBottom : UCommonStyleSheetTypeBase {
	float Bottom; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class CommonUI.AnalogSlider
// Size: 0x720 (Inherited: 0x700)
struct UAnalogSlider : USlider {
	struct FMulticastInlineDelegate OnAnalogCapture; // 0x700(0x10)
	char pad_710[0x10]; // 0x710(0x10)
};

// Class CommonUI.CommonActionHandlerInterface
// Size: 0x28 (Inherited: 0x28)
struct UCommonActionHandlerInterface : UInterface {
};

// Class CommonUI.CommonActionWidget
// Size: 0x450 (Inherited: 0x150)
struct UCommonActionWidget : UWidget {
	struct FMulticastInlineDelegate OnInputMethodChanged; // 0x150(0x10)
	struct FSlateBrush ProgressMaterialBrush; // 0x160(0xd0)
	struct FName ProgressMaterialParam; // 0x230(0x08)
	char pad_238[0x8]; // 0x238(0x08)
	struct FSlateBrush IconRimBrush; // 0x240(0xd0)
	struct TArray<struct FDataTableRowHandle> InputActions; // 0x310(0x10)
	char pad_320[0x8]; // 0x320(0x08)
	struct UMaterialInstanceDynamic* ProgressDynamicMaterial; // 0x328(0x08)
	char pad_330[0x120]; // 0x330(0x120)

	void SetInputActions(struct TArray<struct FDataTableRowHandle> NewInputActions); // Function CommonUI.CommonActionWidget.SetInputActions // (None) // @ game+0xffff95bddf830041
};

// Class CommonUI.CommonUserWidget
// Size: 0x2a0 (Inherited: 0x278)
struct UCommonUserWidget : UUserWidget {
	bool bDisplayInActionBar; // 0x278(0x01)
	bool bConsumePointerInput; // 0x279(0x01)
	char pad_27A[0x26]; // 0x27a(0x26)

	void SetConsumePointerInput(bool bInConsumePointerInput); // Function CommonUI.CommonUserWidget.SetConsumePointerInput // (None) // @ game+0xffff965bdf830041
};

// Class CommonUI.CommonActivatableWidget
// Size: 0x3c8 (Inherited: 0x2a0)
struct UCommonActivatableWidget : UCommonUserWidget {
	bool bIsBackHandler; // 0x2a0(0x01)
	bool bIsBackActionDisplayedInActionBar; // 0x2a1(0x01)
	bool bAutoActivate; // 0x2a2(0x01)
	bool bSupportsActivationFocus; // 0x2a3(0x01)
	bool bIsModal; // 0x2a4(0x01)
	bool bAutoRestoreFocus; // 0x2a5(0x01)
	bool bOverrideActionDomain; // 0x2a6(0x01)
	char pad_2A7[0x1]; // 0x2a7(0x01)
	struct TSoftObjectPtr<UCommonInputActionDomain> ActionDomainOverride; // 0x2a8(0x30)
	struct FMulticastInlineDelegate BP_OnWidgetActivated; // 0x2d8(0x10)
	struct FMulticastInlineDelegate BP_OnWidgetDeactivated; // 0x2e8(0x10)
	bool bIsActive; // 0x2f8(0x01)
	char pad_2F9[0x7]; // 0x2f9(0x07)
	struct TArray<struct TWeakObjectPtr<struct UCommonActivatableWidget>> VisibilityBoundWidgets; // 0x300(0x10)
	char pad_310[0xb0]; // 0x310(0xb0)
	bool bSetVisibilityOnActivated; // 0x3c0(0x01)
	enum class ESlateVisibility ActivatedVisibility; // 0x3c1(0x01)
	bool bSetVisibilityOnDeactivated; // 0x3c2(0x01)
	enum class ESlateVisibility DeactivatedVisibility; // 0x3c3(0x01)
	char pad_3C4[0x4]; // 0x3c4(0x04)

	void SetBindVisibilities(enum class ESlateVisibility OnActivatedVisibility, enum class ESlateVisibility OnDeactivatedVisibility, bool bInAllActive); // Function CommonUI.CommonActivatableWidget.SetBindVisibilities // (None) // @ game+0xffffb0d2df830041
};

// Class CommonUI.CommonAnimatedSwitcher
// Size: 0x1f0 (Inherited: 0x180)
struct UCommonAnimatedSwitcher : UWidgetSwitcher {
	char pad_180[0x30]; // 0x180(0x30)
	enum class ECommonSwitcherTransition TransitionType; // 0x1b0(0x01)
	enum class ETransitionCurve TransitionCurveType; // 0x1b1(0x01)
	char pad_1B2[0x2]; // 0x1b2(0x02)
	float TransitionDuration; // 0x1b4(0x04)
	char pad_1B8[0x38]; // 0x1b8(0x38)

	void SetDisableTransitionAnimation(bool bDisableAnimation); // Function CommonUI.CommonAnimatedSwitcher.SetDisableTransitionAnimation // (None) // @ game+0xffffb0dedf830041
};

// Class CommonUI.CommonActivatableWidgetSwitcher
// Size: 0x200 (Inherited: 0x1f0)
struct UCommonActivatableWidgetSwitcher : UCommonAnimatedSwitcher {
	enum class ECommonSwitcherTransition TransitionType; // 0x1b0(0x01)
	enum class ETransitionCurve TransitionCurveType; // 0x1b1(0x01)
	float TransitionDuration; // 0x1b4(0x04)
	char pad_1F6[0xa]; // 0x1f6(0x0a)
};

// Class CommonUI.CommonBorderStyle
// Size: 0x100 (Inherited: 0x28)
struct UCommonBorderStyle : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FSlateBrush Background; // 0x30(0xd0)

	void GetBackgroundBrush(struct FSlateBrush& Brush); // Function CommonUI.CommonBorderStyle.GetBackgroundBrush // (None) // @ game+0xffffb0dfdf830041
};

// Class CommonUI.CommonBorder
// Size: 0x330 (Inherited: 0x310)
struct UCommonBorder : UBorder {
	struct UCommonBorderStyle* Style; // 0x308(0x08)
	bool bReducePaddingBySafezone; // 0x310(0x01)
	struct FMargin MinimumPadding; // 0x314(0x10)
	char pad_329[0x7]; // 0x329(0x07)

	void SetStyle(struct UCommonBorderStyle* InStyle); // Function CommonUI.CommonBorder.SetStyle // (None) // @ game+0xffffb0e0df830041
};

// Class CommonUI.CommonButtonStyle
// Size: 0x7b0 (Inherited: 0x28)
struct UCommonButtonStyle : UObject {
	bool bSingleMaterial; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FSlateBrush SingleMaterialBrush; // 0x30(0xd0)
	struct FSlateBrush NormalBase; // 0x100(0xd0)
	struct FSlateBrush NormalHovered; // 0x1d0(0xd0)
	struct FSlateBrush NormalPressed; // 0x2a0(0xd0)
	struct FSlateBrush SelectedBase; // 0x370(0xd0)
	struct FSlateBrush SelectedHovered; // 0x440(0xd0)
	struct FSlateBrush SelectedPressed; // 0x510(0xd0)
	struct FSlateBrush Disabled; // 0x5e0(0xd0)
	struct FMargin ButtonPadding; // 0x6b0(0x10)
	struct FMargin CustomPadding; // 0x6c0(0x10)
	int32_t MinWidth; // 0x6d0(0x04)
	int32_t MinHeight; // 0x6d4(0x04)
	struct UCommonTextStyle* NormalTextStyle; // 0x6d8(0x08)
	struct UCommonTextStyle* NormalHoveredTextStyle; // 0x6e0(0x08)
	struct UCommonTextStyle* SelectedTextStyle; // 0x6e8(0x08)
	struct UCommonTextStyle* SelectedHoveredTextStyle; // 0x6f0(0x08)
	struct UCommonTextStyle* DisabledTextStyle; // 0x6f8(0x08)
	struct FSlateSound PressedSlateSound; // 0x700(0x18)
	struct FCommonButtonStyleOptionalSlateSound SelectedPressedSlateSound; // 0x718(0x20)
	struct FCommonButtonStyleOptionalSlateSound LockedPressedSlateSound; // 0x738(0x20)
	struct FSlateSound HoveredSlateSound; // 0x758(0x18)
	struct FCommonButtonStyleOptionalSlateSound SelectedHoveredSlateSound; // 0x770(0x20)
	struct FCommonButtonStyleOptionalSlateSound LockedHoveredSlateSound; // 0x790(0x20)

	struct UCommonTextStyle* GetSelectedTextStyle(); // Function CommonUI.CommonButtonStyle.GetSelectedTextStyle // (None) // @ game+0xffffb0efdf830041
};

// Class CommonUI.CommonButtonInternalBase
// Size: 0x660 (Inherited: 0x5f0)
struct UCommonButtonInternalBase : UButton {
	char pad_5F0[0x8]; // 0x5f0(0x08)
	struct FMulticastInlineDelegate OnDoubleClicked; // 0x5f8(0x10)
	char pad_608[0x20]; // 0x608(0x20)
	int32_t MinWidth; // 0x628(0x04)
	int32_t MinHeight; // 0x62c(0x04)
	bool bButtonEnabled; // 0x630(0x01)
	bool bInteractionEnabled; // 0x631(0x01)
	char pad_632[0x2e]; // 0x632(0x2e)
};

// Class CommonUI.CommonButtonBase
// Size: 0x14f0 (Inherited: 0x2a0)
struct UCommonButtonBase : UCommonUserWidget {
	int32_t MinWidth; // 0x2a0(0x04)
	int32_t MinHeight; // 0x2a4(0x04)
	struct UCommonButtonStyle* Style; // 0x2a8(0x08)
	bool bHideInputAction; // 0x2b0(0x01)
	char pad_2B1[0x7]; // 0x2b1(0x07)
	struct FSlateSound PressedSlateSoundOverride; // 0x2b8(0x18)
	struct FSlateSound HoveredSlateSoundOverride; // 0x2d0(0x18)
	struct FSlateSound SelectedPressedSlateSoundOverride; // 0x2e8(0x18)
	struct FSlateSound SelectedHoveredSlateSoundOverride; // 0x300(0x18)
	struct FSlateSound LockedPressedSlateSoundOverride; // 0x318(0x18)
	struct FSlateSound LockedHoveredSlateSoundOverride; // 0x330(0x18)
	char bApplyAlphaOnDisable : 1; // 0x348(0x01)
	char bLocked : 1; // 0x348(0x01)
	char bSelectable : 1; // 0x348(0x01)
	char bShouldSelectUponReceivingFocus : 1; // 0x348(0x01)
	char bInteractableWhenSelected : 1; // 0x348(0x01)
	char bToggleable : 1; // 0x348(0x01)
	char bTriggerClickedAfterSelection : 1; // 0x348(0x01)
	char bDisplayInputActionWhenNotInteractable : 1; // 0x348(0x01)
	char bHideInputActionWithKeyboard : 1; // 0x349(0x01)
	char bShouldUseFallbackDefaultInputAction : 1; // 0x349(0x01)
	char pad_349_2 : 6; // 0x349(0x01)
	enum class EButtonClickMethod ClickMethod; // 0x34a(0x01)
	enum class EButtonTouchMethod TouchMethod; // 0x34b(0x01)
	enum class EButtonPressMethod PressMethod; // 0x34c(0x01)
	char pad_34D[0x3]; // 0x34d(0x03)
	int32_t InputPriority; // 0x350(0x04)
	char pad_354[0x4]; // 0x354(0x04)
	struct FDataTableRowHandle TriggeringInputAction; // 0x358(0x10)
	char pad_368[0x10]; // 0x368(0x10)
	struct FMulticastInlineDelegate OnSelectedChangedBase; // 0x378(0x10)
	struct FMulticastInlineDelegate OnButtonBaseClicked; // 0x388(0x10)
	struct FMulticastInlineDelegate OnButtonBaseDoubleClicked; // 0x398(0x10)
	struct FMulticastInlineDelegate OnButtonBaseHovered; // 0x3a8(0x10)
	struct FMulticastInlineDelegate OnButtonBaseUnhovered; // 0x3b8(0x10)
	char pad_3C8[0x4]; // 0x3c8(0x04)
	bool bIsPersistentBinding; // 0x3cc(0x01)
	enum class ECommonInputMode InputModeOverride; // 0x3cd(0x01)
	char pad_3CE[0x32]; // 0x3ce(0x32)
	struct UMaterialInstanceDynamic* SingleMaterialStyleMID; // 0x400(0x08)
	char pad_408[0x8]; // 0x408(0x08)
	struct FButtonStyle NormalStyle; // 0x410(0x3f0)
	struct FButtonStyle SelectedStyle; // 0x800(0x3f0)
	struct FButtonStyle DisabledStyle; // 0xbf0(0x3f0)
	struct FButtonStyle LockedStyle; // 0xfe0(0x3f0)
	char bStopDoubleClickPropagation : 1; // 0x13d0(0x01)
	char pad_13D0_1 : 7; // 0x13d0(0x01)
	char pad_13D1[0x117]; // 0x13d1(0x117)
	struct UCommonActionWidget* InputActionWidget; // 0x14e8(0x08)

	void StopDoubleClickPropagation(); // Function CommonUI.CommonButtonBase.StopDoubleClickPropagation // (None) // @ game+0xffffb13ddf830041
};

// Class CommonUI.CommonCustomNavigation
// Size: 0x320 (Inherited: 0x310)
struct UCommonCustomNavigation : UBorder {
	struct FDelegate OnNavigationEvent; // 0x308(0x10)
};

// Class CommonUI.CommonTextBlock
// Size: 0x370 (Inherited: 0x340)
struct UCommonTextBlock : UTextBlock {
	struct UCommonTextStyle* Style; // 0x338(0x08)
	struct UCommonTextScrollStyle* ScrollStyle; // 0x340(0x08)
	struct UCommonStyleSheet* StyleSheet; // 0x348(0x08)
	bool bIsScrollingEnabled; // 0x350(0x01)
	bool bDisplayAllCaps; // 0x351(0x01)
	bool bAutoCollapseWithEmptyText; // 0x352(0x01)
	float MobileFontSizeMultiplier; // 0x354(0x04)
	char pad_35F[0x11]; // 0x35f(0x11)

	void SetWrapTextWidth(int32_t InWrapTextAt); // Function CommonUI.CommonTextBlock.SetWrapTextWidth // (None) // @ game+0xffff95e9df830041
};

// Class CommonUI.CommonDateTimeTextBlock
// Size: 0x3c0 (Inherited: 0x370)
struct UCommonDateTimeTextBlock : UCommonTextBlock {
	struct UCommonTextStyle* Style; // 0x338(0x08)
	struct UCommonTextScrollStyle* ScrollStyle; // 0x340(0x08)
	struct UCommonStyleSheet* StyleSheet; // 0x348(0x08)
	bool bIsScrollingEnabled; // 0x350(0x01)
	bool bDisplayAllCaps; // 0x351(0x01)
	bool bAutoCollapseWithEmptyText; // 0x352(0x01)
	float MobileFontSizeMultiplier; // 0x354(0x04)
	char pad_38F[0x31]; // 0x38f(0x31)

	void SetTimespanValue(struct FTimespan InTimespan); // Function CommonUI.CommonDateTimeTextBlock.SetTimespanValue // (None) // @ game+0xffffb141df830041
};

// Class CommonUI.CommonGameViewportClient
// Size: 0x3e0 (Inherited: 0x3a0)
struct UCommonGameViewportClient : UGameViewportClient {
	struct UConsole* ViewportConsole; // 0x40(0x08)
	struct TArray<struct FDebugDisplayProperty> DebugProperties; // 0x48(0x10)
	int32_t MaxSplitscreenPlayers; // 0x68(0x04)
	struct UWorld* World; // 0x78(0x08)
	struct UGameInstance* GameInstance; // 0x80(0x08)
	char pad_3CC[0x14]; // 0x3cc(0x14)
};

// Class CommonUI.CommonHardwareVisibilityBorder
// Size: 0x380 (Inherited: 0x330)
struct UCommonHardwareVisibilityBorder : UCommonBorder {
	struct FGameplayTagQuery VisibilityQuery; // 0x328(0x48)
	enum class ESlateVisibility VisibleType; // 0x370(0x01)
	enum class ESlateVisibility HiddenType; // 0x371(0x01)
	char pad_37A[0x6]; // 0x37a(0x06)
};

// Class CommonUI.CommonHierarchicalScrollBox
// Size: 0xca0 (Inherited: 0xca0)
struct UCommonHierarchicalScrollBox : UScrollBox {
	struct FScrollBoxStyle WidgetStyle; // 0x170(0x350)
	struct FScrollBarStyle WidgetBarStyle; // 0x4c0(0x770)
	enum class EOrientation Orientation; // 0xc30(0x01)
	enum class ESlateVisibility ScrollBarVisibility; // 0xc31(0x01)
	enum class EConsumeMouseWheel ConsumeMouseWheel; // 0xc32(0x01)
	struct FVector2D ScrollbarThickness; // 0xc38(0x10)
	struct FMargin ScrollbarPadding; // 0xc48(0x10)
	bool AlwaysShowScrollbar; // 0xc58(0x01)
	bool AlwaysShowScrollbarTrack; // 0xc59(0x01)
	bool AllowOverscroll; // 0xc5a(0x01)
	bool BackPadScrolling; // 0xc5b(0x01)
	bool FrontPadScrolling; // 0xc5c(0x01)
	bool bAnimateWheelScrolling; // 0xc5d(0x01)
	enum class EDescendantScrollDestination NavigationDestination; // 0xc5e(0x01)
	float NavigationScrollPadding; // 0xc60(0x04)
	enum class EScrollWhenFocusChanges ScrollWhenFocusChanges; // 0xc64(0x01)
	bool bAllowRightClickDragScrolling; // 0xc65(0x01)
	float WheelScrollMultiplier; // 0xc68(0x04)
	struct FMulticastInlineDelegate OnUserScrolled; // 0xc70(0x10)
};

// Class CommonUI.CommonLazyImage
// Size: 0x3c0 (Inherited: 0x2b0)
struct UCommonLazyImage : UImage {
	struct FSlateBrush LoadingBackgroundBrush; // 0x2b0(0xd0)
	struct FName MaterialTextureParamName; // 0x380(0x08)
	struct FMulticastInlineDelegate BP_OnLoadingStateChanged; // 0x388(0x10)
	char pad_398[0x28]; // 0x398(0x28)

	void SetMaterialTextureParamName(struct FName TextureParamName); // Function CommonUI.CommonLazyImage.SetMaterialTextureParamName // (None) // @ game+0xffffb1addf830041
};

// Class CommonUI.CommonLazyWidget
// Size: 0x2b0 (Inherited: 0x150)
struct UCommonLazyWidget : UWidget {
	struct FSlateBrush LoadingBackgroundBrush; // 0x150(0xd0)
	struct UUserWidget* Content; // 0x220(0x08)
	char pad_228[0x30]; // 0x228(0x30)
	struct FMulticastInlineDelegate BP_OnLoadingStateChanged; // 0x258(0x10)
	char pad_268[0x48]; // 0x268(0x48)

	void SetLazyContent(struct TSoftClassPtr<UObject> SoftWidget); // Function CommonUI.CommonLazyWidget.SetLazyContent // (None) // @ game+0xffffb16edf830041
};

// Class CommonUI.CommonListView
// Size: 0xc20 (Inherited: 0xc20)
struct UCommonListView : UListView {
	struct FTableViewStyle WidgetStyle; // 0x340(0xe0)
	struct FScrollBarStyle ScrollBarStyle; // 0x420(0x770)
	enum class EOrientation Orientation; // 0xb90(0x01)
	enum class ESelectionMode SelectionMode; // 0xb91(0x01)
	enum class EConsumeMouseWheel ConsumeMouseWheel; // 0xb92(0x01)
	bool bClearSelectionOnClick; // 0xb93(0x01)
	bool bIsFocusable; // 0xb94(0x01)
	float EntrySpacing; // 0xb98(0x04)
	bool bReturnFocusToSelection; // 0xb9c(0x01)
	struct TArray<struct UObject*> ListItems; // 0xba0(0x10)
	struct FMulticastInlineDelegate BP_OnEntryInitialized; // 0xbc0(0x10)
	struct FMulticastInlineDelegate BP_OnItemClicked; // 0xbd0(0x10)
	struct FMulticastInlineDelegate BP_OnItemDoubleClicked; // 0xbe0(0x10)
	struct FMulticastInlineDelegate BP_OnItemIsHoveredChanged; // 0xbf0(0x10)
	struct FMulticastInlineDelegate BP_OnItemSelectionChanged; // 0xc00(0x10)
	struct FMulticastInlineDelegate BP_OnItemScrolledIntoView; // 0xc10(0x10)

	void SetEntrySpacing(float InEntrySpacing); // Function CommonUI.CommonListView.SetEntrySpacing // (None) // @ game+0xffffb191df830041
};

// Class CommonUI.LoadGuardSlot
// Size: 0x60 (Inherited: 0x38)
struct ULoadGuardSlot : UPanelSlot {
	struct FMargin Padding; // 0x38(0x10)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x48(0x01)
	enum class EVerticalAlignment VerticalAlignment; // 0x49(0x01)
	char pad_4A[0x16]; // 0x4a(0x16)

	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Function CommonUI.LoadGuardSlot.SetVerticalAlignment // (None) // @ game+0xffffb194df830041
};

// Class CommonUI.CommonLoadGuard
// Size: 0x2d0 (Inherited: 0x168)
struct UCommonLoadGuard : UContentWidget {
	char pad_168[0x8]; // 0x168(0x08)
	struct FSlateBrush LoadingBackgroundBrush; // 0x170(0xd0)
	enum class EHorizontalAlignment ThrobberAlignment; // 0x240(0x01)
	char pad_241[0x3]; // 0x241(0x03)
	struct FMargin ThrobberPadding; // 0x244(0x10)
	char pad_254[0x4]; // 0x254(0x04)
	struct FText LoadingText; // 0x258(0x18)
	struct UCommonTextStyle* TextStyle; // 0x270(0x08)
	struct FMulticastInlineDelegate BP_OnLoadingStateChanged; // 0x278(0x10)
	struct FSoftObjectPath SpinnerMaterialPath; // 0x288(0x20)
	char pad_2A8[0x28]; // 0x2a8(0x28)

	void SetLoadingText(struct FText& InLoadingText); // Function CommonUI.CommonLoadGuard.SetLoadingText // (None) // @ game+0xffff95d1df830041
};

// Class CommonUI.CommonNumericTextBlock
// Size: 0x410 (Inherited: 0x370)
struct UCommonNumericTextBlock : UCommonTextBlock {
	struct FMulticastInlineDelegate OnInterpolationStartedEvent; // 0x368(0x10)
	struct FMulticastInlineDelegate OnInterpolationUpdatedEvent; // 0x378(0x10)
	struct FMulticastInlineDelegate OnOutroEvent; // 0x388(0x10)
	struct FMulticastInlineDelegate OnInterpolationEndedEvent; // 0x398(0x10)
	float CurrentNumericValue; // 0x3a8(0x04)
	enum class ECommonNumericType NumericType; // 0x3ac(0x01)
	struct FCommonNumberFormattingOptions FormattingSpecification; // 0x3b0(0x14)
	float EaseOutInterpolationExponent; // 0x3c4(0x04)
	float InterpolationUpdateInterval; // 0x3c8(0x04)
	float PostInterpolationShrinkDuration; // 0x3cc(0x04)
	bool PerformSizeInterpolation; // 0x3d0(0x01)
	bool IsPercentage; // 0x3d1(0x01)
	char pad_3D7[0x39]; // 0x3d7(0x39)

	void SetNumericType(enum class ECommonNumericType InNumericType); // Function CommonUI.CommonNumericTextBlock.SetNumericType // (None) // @ game+0xffff95f2df830041
};

// Class CommonUI.CommonPoolableWidgetInterface
// Size: 0x28 (Inherited: 0x28)
struct UCommonPoolableWidgetInterface : UInterface {

	void OnReleaseToPool(); // Function CommonUI.CommonPoolableWidgetInterface.OnReleaseToPool // (None) // @ game+0xffffb196df830041
};

// Class CommonUI.CommonRichTextBlock
// Size: 0x8b0 (Inherited: 0x870)
struct UCommonRichTextBlock : URichTextBlock {
	enum class ERichTextInlineIconDisplayMode InlineIconDisplayMode; // 0x870(0x01)
	bool bTintInlineIcon; // 0x871(0x01)
	char pad_872[0x6]; // 0x872(0x06)
	struct UCommonTextStyle* DefaultTextStyleOverrideClass; // 0x878(0x08)
	float MobileTextBlockScale; // 0x880(0x04)
	char pad_884[0x4]; // 0x884(0x04)
	struct UCommonTextScrollStyle* ScrollStyle; // 0x888(0x08)
	bool bIsScrollingEnabled; // 0x890(0x01)
	bool bDisplayAllCaps; // 0x891(0x01)
	bool bAutoCollapseWithEmptyText; // 0x892(0x01)
	char pad_893[0x1d]; // 0x893(0x1d)

	void SetScrollingEnabled(bool bInIsScrollingEnabled); // Function CommonUI.CommonRichTextBlock.SetScrollingEnabled // (None) // @ game+0xffffb1abdf830041
};

// Class CommonUI.CommonRotator
// Size: 0x1550 (Inherited: 0x14f0)
struct UCommonRotator : UCommonButtonBase {
	char pad_14F0[0x10]; // 0x14f0(0x10)
	struct FMulticastInlineDelegate OnRotated; // 0x1500(0x10)
	char pad_1510[0x18]; // 0x1510(0x18)
	struct UCommonTextBlock* MyText; // 0x1528(0x08)
	char pad_1530[0x20]; // 0x1530(0x20)

	void ShiftTextRight(); // Function CommonUI.CommonRotator.ShiftTextRight // (None) // @ game+0xffffb1b3df830041
};

// Class CommonUI.CommonTabListWidgetBase
// Size: 0x388 (Inherited: 0x2a0)
struct UCommonTabListWidgetBase : UCommonUserWidget {
	struct FMulticastInlineDelegate OnTabSelected; // 0x2a0(0x10)
	struct FMulticastInlineDelegate OnTabButtonCreation; // 0x2b0(0x10)
	struct FMulticastInlineDelegate OnTabButtonRemoval; // 0x2c0(0x10)
	struct FMulticastInlineDelegate OnTabListRebuilt; // 0x2d0(0x10)
	struct FDataTableRowHandle NextTabInputActionData; // 0x2e0(0x10)
	struct FDataTableRowHandle PreviousTabInputActionData; // 0x2f0(0x10)
	bool bAutoListenForInput; // 0x300(0x01)
	bool bDeferRebuildingTabList; // 0x301(0x01)
	char pad_302[0x2]; // 0x302(0x02)
	struct TWeakObjectPtr<struct UCommonAnimatedSwitcher> LinkedSwitcher; // 0x304(0x08)
	char pad_30C[0x4]; // 0x30c(0x04)
	struct UCommonButtonGroupBase* TabButtonGroup; // 0x310(0x08)
	char pad_318[0x8]; // 0x318(0x08)
	struct TMap<struct FName, struct FCommonRegisteredTabInfo> RegisteredTabsByID; // 0x320(0x50)
	char pad_370[0x18]; // 0x370(0x18)

	void SetTabVisibility(struct FName TabNameID, enum class ESlateVisibility NewVisibility); // Function CommonUI.CommonTabListWidgetBase.SetTabVisibility // (None) // @ game+0xffff9679df830041
};

// Class CommonUI.CommonTextStyle
// Size: 0x1b0 (Inherited: 0x28)
struct UCommonTextStyle : UObject {
	struct FSlateFontInfo Font; // 0x28(0x58)
	struct FLinearColor Color; // 0x80(0x10)
	bool bUsesDropShadow; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
	struct FVector2D ShadowOffset; // 0x98(0x10)
	struct FLinearColor ShadowColor; // 0xa8(0x10)
	struct FMargin Margin; // 0xb8(0x10)
	char pad_C8[0x8]; // 0xc8(0x08)
	struct FSlateBrush StrikeBrush; // 0xd0(0xd0)
	float LineHeightPercentage; // 0x1a0(0x04)
	char pad_1A4[0xc]; // 0x1a4(0x0c)

	void GetStrikeBrush(struct FSlateBrush& OutStrikeBrush); // Function CommonUI.CommonTextStyle.GetStrikeBrush // (None) // @ game+0xffffb1badf830041
};

// Class CommonUI.CommonTextScrollStyle
// Size: 0x40 (Inherited: 0x28)
struct UCommonTextScrollStyle : UObject {
	float Speed; // 0x28(0x04)
	float StartDelay; // 0x2c(0x04)
	float EndDelay; // 0x30(0x04)
	float FadeInDelay; // 0x34(0x04)
	float FadeOutDelay; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class CommonUI.CommonTileView
// Size: 0xc40 (Inherited: 0xc40)
struct UCommonTileView : UTileView {
	float EntryHeight; // 0xc20(0x04)
	float EntryWidth; // 0xc24(0x04)
	enum class EListItemAlignment TileAlignment; // 0xc28(0x01)
	bool bWrapHorizontalNavigation; // 0xc29(0x01)
};

// Class CommonUI.CommonTreeView
// Size: 0xc80 (Inherited: 0xc80)
struct UCommonTreeView : UTreeView {
	struct FDelegate BP_OnGetItemChildren; // 0xc30(0x10)
	struct FMulticastInlineDelegate BP_OnItemExpansionChanged; // 0xc40(0x10)
};

// Class CommonUI.CommonUIEditorSettings
// Size: 0xc0 (Inherited: 0x28)
struct UCommonUIEditorSettings : UObject {
	struct TSoftClassPtr<UObject> TemplateTextStyle; // 0x28(0x30)
	struct TSoftClassPtr<UObject> TemplateButtonStyle; // 0x58(0x30)
	struct TSoftClassPtr<UObject> TemplateBorderStyle; // 0x88(0x30)
	char pad_B8[0x8]; // 0xb8(0x08)
};

// Class CommonUI.CommonUILibrary
// Size: 0x28 (Inherited: 0x28)
struct UCommonUILibrary : UBlueprintFunctionLibrary {

	struct UWidget* FindParentWidgetOfType(struct UWidget* StartingWidget, struct UWidget* Type); // Function CommonUI.CommonUILibrary.FindParentWidgetOfType // (None) // @ game+0xffffb1c2df830041
};

// Class CommonUI.CommonUIRichTextData
// Size: 0x30 (Inherited: 0x28)
struct UCommonUIRichTextData : UObject {
	struct UDataTable* InlineIconSet; // 0x28(0x08)
};

// Class CommonUI.CommonUISettings
// Size: 0x1f0 (Inherited: 0x28)
struct UCommonUISettings : UObject {
	bool bAutoLoadData; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct TSoftObjectPtr<UObject> DefaultImageResourceObject; // 0x30(0x30)
	struct TSoftObjectPtr<UMaterialInterface> DefaultThrobberMaterial; // 0x60(0x30)
	struct TSoftClassPtr<UObject> DefaultRichTextDataClass; // 0x90(0x30)
	struct TArray<struct FGameplayTag> PlatformTraits; // 0xc0(0x10)
	char pad_D0[0x28]; // 0xd0(0x28)
	struct UObject* DefaultImageResourceObjectInstance; // 0xf8(0x08)
	struct UMaterialInterface* DefaultThrobberMaterialInstance; // 0x100(0x08)
	char pad_108[0x8]; // 0x108(0x08)
	struct FSlateBrush DefaultThrobberBrush; // 0x110(0xd0)
	struct UCommonUIRichTextData* RichTextDataInstance; // 0x1e0(0x08)
	char pad_1E8[0x8]; // 0x1e8(0x08)
};

// Class CommonUI.CommonUISubsystemBase
// Size: 0x40 (Inherited: 0x30)
struct UCommonUISubsystemBase : UGameInstanceSubsystem {
	char pad_30[0x10]; // 0x30(0x10)

	struct FSlateBrush GetInputActionButtonIcon(struct FDataTableRowHandle& InputActionRowHandle, enum class ECommonInputType InputType, struct FName& GamepadName); // Function CommonUI.CommonUISubsystemBase.GetInputActionButtonIcon // (None) // @ game+0xffffb1c3df830041
};

// Class CommonUI.CommonUIVisibilitySubsystem
// Size: 0x88 (Inherited: 0x30)
struct UCommonUIVisibilitySubsystem : ULocalPlayerSubsystem {
	char pad_30[0x58]; // 0x30(0x58)
};

// Class CommonUI.CommonVideoPlayer
// Size: 0x2b0 (Inherited: 0x150)
struct UCommonVideoPlayer : UWidget {
	struct UMediaSource* Video; // 0x150(0x08)
	struct UMediaPlayer* MediaPlayer; // 0x158(0x08)
	struct UMediaTexture* MediaTexture; // 0x160(0x08)
	struct UMaterial* VideoMaterial; // 0x168(0x08)
	struct UMediaSoundComponent* SoundComponent; // 0x170(0x08)
	char pad_178[0x8]; // 0x178(0x08)
	struct FSlateBrush VideoBrush; // 0x180(0xd0)
	char pad_250[0x60]; // 0x250(0x60)
};

// Class CommonUI.CommonVisibilitySwitcher
// Size: 0x1a0 (Inherited: 0x178)
struct UCommonVisibilitySwitcher : UOverlay {
	enum class ESlateVisibility ShownVisibility; // 0x178(0x01)
	char pad_179[0x3]; // 0x179(0x03)
	int32_t ActiveWidgetIndex; // 0x17c(0x04)
	bool bAutoActivateSlot; // 0x180(0x01)
	bool bActivateFirstSlotOnAdding; // 0x181(0x01)
	char pad_182[0x1e]; // 0x182(0x1e)

	void SetActiveWidgetIndex(int32_t Index); // Function CommonUI.CommonVisibilitySwitcher.SetActiveWidgetIndex // (None) // @ game+0xffffb1ccdf830041
};

// Class CommonUI.CommonVisibilitySwitcherSlot
// Size: 0x68 (Inherited: 0x58)
struct UCommonVisibilitySwitcherSlot : UOverlaySlot {
	struct FMargin Padding; // 0x40(0x10)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x50(0x01)
	enum class EVerticalAlignment VerticalAlignment; // 0x51(0x01)
};

// Class CommonUI.UCommonVisibilityWidgetBase
// Size: 0x380 (Inherited: 0x330)
struct UUCommonVisibilityWidgetBase : UCommonBorder {
	struct TMap<struct FName, bool> VisibilityControls; // 0x328(0x50)
	bool bShowForGamepad; // 0x378(0x01)
	bool bShowForMouseAndKeyboard; // 0x379(0x01)
	bool bShowForTouch; // 0x37a(0x01)
	enum class ESlateVisibility VisibleType; // 0x37b(0x01)
	enum class ESlateVisibility HiddenType; // 0x37c(0x01)

	struct TArray<struct FName> GetRegisteredPlatforms(); // Function CommonUI.UCommonVisibilityWidgetBase.GetRegisteredPlatforms // (None) // @ game+0xffffb1d0df830041
};

// Class CommonUI.CommonVisualAttachment
// Size: 0x1c0 (Inherited: 0x1a0)
struct UCommonVisualAttachment : USizeBox {
	struct FVector2D ContentAnchor; // 0x1a0(0x10)
	char pad_1B0[0x10]; // 0x1b0(0x10)
};

// Class CommonUI.CommonWidgetCarousel
// Size: 0x1b0 (Inherited: 0x168)
struct UCommonWidgetCarousel : UPanelWidget {
	int32_t ActiveWidgetIndex; // 0x168(0x04)
	char pad_16C[0x4]; // 0x16c(0x04)
	struct FMulticastInlineDelegate OnCurrentPageIndexChanged; // 0x170(0x10)
	char pad_180[0x30]; // 0x180(0x30)

	void SetActiveWidgetIndex(int32_t Index); // Function CommonUI.CommonWidgetCarousel.SetActiveWidgetIndex // (None) // @ game+0xffffb1e8df830041
};

// Class CommonUI.CommonWidgetCarouselNavBar
// Size: 0x198 (Inherited: 0x150)
struct UCommonWidgetCarouselNavBar : UWidget {
	struct UCommonButtonBase* ButtonWidgetType; // 0x150(0x08)
	struct FMargin ButtonPadding; // 0x158(0x10)
	char pad_168[0x10]; // 0x168(0x10)
	struct UCommonWidgetCarousel* LinkedCarousel; // 0x178(0x08)
	struct UCommonButtonGroupBase* ButtonGroup; // 0x180(0x08)
	struct TArray<struct UCommonButtonBase*> Buttons; // 0x188(0x10)

	void SetLinkedCarousel(struct UCommonWidgetCarousel* CommonCarousel); // Function CommonUI.CommonWidgetCarouselNavBar.SetLinkedCarousel // (None) // @ game+0xffffb1ebdf830041
};

// Class CommonUI.CommonWidgetGroupBase
// Size: 0x28 (Inherited: 0x28)
struct UCommonWidgetGroupBase : UObject {

	void RemoveWidget(struct UWidget* InWidget); // Function CommonUI.CommonWidgetGroupBase.RemoveWidget // (None) // @ game+0xffffb1eedf830041
};

// Class CommonUI.CommonButtonGroupBase
// Size: 0x110 (Inherited: 0x28)
struct UCommonButtonGroupBase : UCommonWidgetGroupBase {
	struct FMulticastInlineDelegate OnSelectedButtonBaseChanged; // 0x28(0x10)
	char pad_38[0x18]; // 0x38(0x18)
	struct FMulticastInlineDelegate OnHoveredButtonBaseChanged; // 0x50(0x10)
	char pad_60[0x18]; // 0x60(0x18)
	struct FMulticastInlineDelegate OnButtonBaseClicked; // 0x78(0x10)
	char pad_88[0x18]; // 0x88(0x18)
	struct FMulticastInlineDelegate OnButtonBaseDoubleClicked; // 0xa0(0x10)
	char pad_B0[0x18]; // 0xb0(0x18)
	struct FMulticastInlineDelegate OnSelectionCleared; // 0xc8(0x10)
	char pad_D8[0x18]; // 0xd8(0x18)
	bool bSelectionRequired; // 0xf0(0x01)
	char pad_F1[0x1f]; // 0xf1(0x1f)

	void SetSelectionRequired(bool bRequireSelection); // Function CommonUI.CommonButtonGroupBase.SetSelectionRequired // (None) // @ game+0xffffb1ffdf830041
};

// Class CommonUI.CommonBoundActionBar
// Size: 0x240 (Inherited: 0x230)
struct UCommonBoundActionBar : UDynamicEntryBoxBase {
	struct UCommonButtonBase* ActionButtonClass; // 0x230(0x08)
	bool bDisplayOwningPlayerActionsOnly; // 0x238(0x01)
	bool bIgnoreDuplicateActions; // 0x239(0x01)
	char pad_23A[0x6]; // 0x23a(0x06)

	void SetDisplayOwningPlayerActionsOnly(bool bShouldOnlyDisplayOwningPlayerActions); // Function CommonUI.CommonBoundActionBar.SetDisplayOwningPlayerActionsOnly // (None) // @ game+0xffffb204df830041
};

// Class CommonUI.CommonBoundActionButton
// Size: 0x1510 (Inherited: 0x14f0)
struct UCommonBoundActionButton : UCommonButtonBase {
	char pad_14F0[0x8]; // 0x14f0(0x08)
	struct UCommonTextBlock* Text_ActionName; // 0x14f8(0x08)
	char pad_1500[0x10]; // 0x1500(0x10)

	void OnUpdateInputAction(); // Function CommonUI.CommonBoundActionButton.OnUpdateInputAction // (None) // @ game+0xffffb205df830041
};

// Class CommonUI.CommonGenericInputActionDataTable
// Size: 0xb0 (Inherited: 0xb0)
struct UCommonGenericInputActionDataTable : UDataTable {
	struct UScriptStruct* RowStruct; // 0x28(0x08)
	char bStripFromClientBuilds : 1; // 0x80(0x01)
	char bIgnoreExtraFields : 1; // 0x80(0x01)
	char bIgnoreMissingFields : 1; // 0x80(0x01)
	struct FString ImportKeyField; // 0x88(0x10)
};

// Class CommonUI.CommonInputActionDataProcessor
// Size: 0x28 (Inherited: 0x28)
struct UCommonInputActionDataProcessor : UObject {
};

// Class CommonUI.CommonUIActionRouterBase
// Size: 0x158 (Inherited: 0x30)
struct UCommonUIActionRouterBase : ULocalPlayerSubsystem {
	char pad_30[0x128]; // 0x30(0x128)
};

// Class CommonUI.CommonUIInputSettings
// Size: 0x78 (Inherited: 0x28)
struct UCommonUIInputSettings : UObject {
	bool bLinkCursorToGamepadFocus; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	int32_t UIActionProcessingPriority; // 0x2c(0x04)
	struct TArray<struct FUIInputAction> InputActions; // 0x30(0x10)
	struct TArray<struct FUIInputAction> ActionOverrides; // 0x40(0x10)
	struct FCommonAnalogCursorSettings AnalogCursorSettings; // 0x50(0x24)
	char pad_74[0x4]; // 0x74(0x04)
};

// Class CommonUI.CommonStyleSheet
// Size: 0x58 (Inherited: 0x30)
struct UCommonStyleSheet : UDataAsset {
	struct TArray<struct UCommonStyleSheetTypeBase*> Properties; // 0x30(0x10)
	struct TArray<struct UCommonStyleSheet*> ImportedStyleSheets; // 0x40(0x10)
	char pad_50[0x8]; // 0x50(0x08)
};

// Class CommonUI.CommonActivatableWidgetContainerBase
// Size: 0x270 (Inherited: 0x150)
struct UCommonActivatableWidgetContainerBase : UWidget {
	char pad_150[0x18]; // 0x150(0x18)
	enum class ECommonSwitcherTransition TransitionType; // 0x168(0x01)
	enum class ETransitionCurve TransitionCurveType; // 0x169(0x01)
	char pad_16A[0x2]; // 0x16a(0x02)
	float TransitionDuration; // 0x16c(0x04)
	struct TArray<struct UCommonActivatableWidget*> WidgetList; // 0x170(0x10)
	struct UCommonActivatableWidget* DisplayedWidget; // 0x180(0x08)
	struct FUserWidgetPool GeneratedWidgetsPool; // 0x188(0x88)
	char pad_210[0x60]; // 0x210(0x60)

	void SetTransitionDuration(float Duration); // Function CommonUI.CommonActivatableWidgetContainerBase.SetTransitionDuration // (None) // @ game+0xffffb24ddf830041
};

// Class CommonUI.CommonActivatableWidgetStack
// Size: 0x280 (Inherited: 0x270)
struct UCommonActivatableWidgetStack : UCommonActivatableWidgetContainerBase {
	struct UCommonActivatableWidget* RootContentWidgetClass; // 0x270(0x08)
	struct UCommonActivatableWidget* RootContentWidget; // 0x278(0x08)
};

// Class CommonUI.CommonActivatableWidgetQueue
// Size: 0x270 (Inherited: 0x270)
struct UCommonActivatableWidgetQueue : UCommonActivatableWidgetContainerBase {
	enum class ECommonSwitcherTransition TransitionType; // 0x168(0x01)
	enum class ETransitionCurve TransitionCurveType; // 0x169(0x01)
	float TransitionDuration; // 0x16c(0x04)
	struct TArray<struct UCommonActivatableWidget*> WidgetList; // 0x170(0x10)
	struct UCommonActivatableWidget* DisplayedWidget; // 0x180(0x08)
	struct FUserWidgetPool GeneratedWidgetsPool; // 0x188(0x88)
};

