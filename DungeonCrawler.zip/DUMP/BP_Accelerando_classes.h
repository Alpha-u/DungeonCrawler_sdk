// BlueprintGeneratedClass BP_Accelerando.BP_Accelerando_C
// Size: 0x3e0 (Inherited: 0x3e0)
struct ABP_Accelerando_C : ABP_MusicActor_C {
	struct USceneComponent* DefaultSceneRoot; // 0x3d8(0x08)
};

