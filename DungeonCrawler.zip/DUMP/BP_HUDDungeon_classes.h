// BlueprintGeneratedClass BP_HUDDungeon.BP_HUDDungeon_C
// Size: 0x390 (Inherited: 0x380)
struct ABP_HUDDungeon_C : AHUD {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x380(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x388(0x08)

	void ReceiveBeginPlay(); // Function BP_HUDDungeon.BP_HUDDungeon_C.ReceiveBeginPlay // (None) // @ game+0xffff8009df830000
};

