// Class AudioCapture.AudioCapture
// Size: 0xb0 (Inherited: 0xa8)
struct UAudioCapture : UAudioGenerator {
	char pad_A8[0x8]; // 0xa8(0x08)

	void StopCapturingAudio(); // Function AudioCapture.AudioCapture.StopCapturingAudio // (None) // @ game+0xffffb85adf830041
};

// Class AudioCapture.AudioCaptureFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAudioCaptureFunctionLibrary : UBlueprintFunctionLibrary {

	struct UAudioCapture* CreateAudioCapture(); // Function AudioCapture.AudioCaptureFunctionLibrary.CreateAudioCapture // (None) // @ game+0xffffb85bdf830041
};

// Class AudioCapture.AudioCaptureBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAudioCaptureBlueprintLibrary : UBlueprintFunctionLibrary {

	void GetAvailableAudioInputDevices(struct UObject* WorldContextObject, struct FDelegate& OnObtainDevicesEvent); // Function AudioCapture.AudioCaptureBlueprintLibrary.GetAvailableAudioInputDevices // (None) // @ game+0xffffb85ddf830041
};

// Class AudioCapture.AudioCaptureComponent
// Size: 0x850 (Inherited: 0x790)
struct UAudioCaptureComponent : USynthComponent {
	int32_t JitterLatencyFrames; // 0x790(0x04)
	char pad_794[0xbc]; // 0x794(0xbc)
};

