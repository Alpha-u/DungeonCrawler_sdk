// BlueprintGeneratedClass BTD_CheckToRunBehavior.BTD_CheckToRunBehavior_C
// Size: 0xc0 (Inherited: 0xa0)
struct UBTD_CheckToRunBehavior_C : UBTDecorator_BlueprintBase {
	int32_t Check Depth; // 0xa0(0x04)
	enum class E_BTActionsFromMonsterBP Check To Run; // 0xa4(0x01)
	enum class E_ActionWhileConditionalTopPriorityMode Check Conditional Top Priority Action; // 0xa5(0x01)
	enum class E_ActionWhilePeaceMode Check Peace Action; // 0xa6(0x01)
	enum class E_ActionWhileCombat Check Combat Action; // 0xa7(0x01)
	struct TArray<struct ADCCharacterBase*> Target Array; // 0xa8(0x10)
	struct ABP_DCMonsterBaseWithOptions_C* As BP DCMonster Base With Options; // 0xb8(0x08)

	void Check Combat Action Type Function(struct ABP_DCMonsterBaseWithOptions_C* MonsterBP, bool& Return Value); // Function BTD_CheckToRunBehavior.BTD_CheckToRunBehavior_C.Check Combat Action Type Function // (None) // @ game+0xffff8009df830000
};

