// BlueprintGeneratedClass GA_DCInteractPassive.GA_DCInteractPassive_C
// Size: 0x620 (Inherited: 0x620)
struct UGA_DCInteractPassive_C : UGA_InteractPassive {
	struct FPrimaryAssetId InteractionRangeConstant; // 0x578(0x10)
	struct FPrimaryAssetId InteractionAdditionalSphereRadiusConstant; // 0x588(0x10)
	struct ADCGATA_LineTraceInteractable* TargetActor; // 0x598(0x08)
	struct UDCAT_WaitInteractableTarget* WaitInteractableTargetTask; // 0x5a0(0x08)
	struct FGameplayAbilityTargetDataHandle CurrentTargetData; // 0x5a8(0x28)
	struct TMap<struct FGameplayTag, struct FInteractionData> CurrentInteractableDatas; // 0x5d0(0x50)
};

