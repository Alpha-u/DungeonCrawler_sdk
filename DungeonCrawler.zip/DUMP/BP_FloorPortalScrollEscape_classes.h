// BlueprintGeneratedClass BP_FloorPortalScrollEscape.BP_FloorPortalScrollEscape_C
// Size: 0x418 (Inherited: 0x3f1)
struct ABP_FloorPortalScrollEscape_C : ABP_FloorPortalScrollBase_C {
	char pad_3F1[0x7]; // 0x3f1(0x07)
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f8(0x08)
	struct UNiagaraComponent* FXS_FloorPortal_Escape; // 0x400(0x08)
	float PlayPortalFXTimeline_Progress_7EFF54324C92BC355884B081BD33F76E; // 0x408(0x04)
	enum class ETimelineDirection PlayPortalFXTimeline__Direction_7EFF54324C92BC355884B081BD33F76E; // 0x40c(0x01)
	char pad_40D[0x3]; // 0x40d(0x03)
	struct UTimelineComponent* PlayPortalFXTimeline; // 0x410(0x08)

	void PlayPortalFXTimeline__FinishedFunc(); // Function BP_FloorPortalScrollEscape.BP_FloorPortalScrollEscape_C.PlayPortalFXTimeline__FinishedFunc // (None) // @ game+0xdda2dfab0001
};

