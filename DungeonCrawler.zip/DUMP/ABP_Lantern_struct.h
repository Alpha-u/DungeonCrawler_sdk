// ScriptStruct ABP_Lantern.ABP_Lantern_C.AnimBlueprintGeneratedMutableData
// Size: 0x10 (Inherited: 0x01)
struct FAnimBlueprintGeneratedMutableData : FAnimBlueprintMutableData {
	char pad_1[0x3]; // 0x01(0x03)
	float __FloatProperty; // 0x04(0x04)
	bool __BoolProperty_1; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float __FloatProperty_2; // 0x0c(0x04)
};

// ScriptStruct ABP_Lantern.ABP_Lantern_C.AnimBlueprintGeneratedConstantData
// Size: 0x140 (Inherited: 0x01)
struct FAnimBlueprintGeneratedConstantData : FAnimBlueprintConstantData {
	char pad_1[0x3]; // 0x01(0x03)
	struct FName __NameProperty_46; // 0x04(0x08)
	struct FInputScaleBiasClampConstants __StructProperty_47; // 0x0c(0x2c)
	struct UBlendProfile* __BlendProfile_48; // 0x38(0x08)
	struct UCurveFloat* __CurveFloat_49; // 0x40(0x08)
	enum class EAlphaBlendOption __EnumProperty_50; // 0x48(0x01)
	enum class EBlendListTransitionType __EnumProperty_51; // 0x49(0x01)
	char pad_4A[0x6]; // 0x4a(0x06)
	struct TArray<float> __ArrayProperty_52; // 0x50(0x10)
	struct FName __NameProperty_53; // 0x60(0x08)
	int32_t __IntProperty_54; // 0x68(0x04)
	bool __BoolProperty_55; // 0x6c(0x01)
	char pad_6D[0x3]; // 0x6d(0x03)
	float __FloatProperty_56; // 0x70(0x04)
	float __FloatProperty_57; // 0x74(0x04)
	bool __BoolProperty_58; // 0x78(0x01)
	enum class EAnimSyncMethod __EnumProperty_59; // 0x79(0x01)
	enum class EAnimGroupRole __ByteProperty_60; // 0x7a(0x01)
	char pad_7B[0x1]; // 0x7b(0x01)
	struct FName __NameProperty_61; // 0x7c(0x08)
	char pad_84[0x4]; // 0x84(0x04)
	struct FAnimNodeFunctionRef __StructProperty_62; // 0x88(0x20)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess; // 0xa8(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base; // 0x128(0x18)
};

