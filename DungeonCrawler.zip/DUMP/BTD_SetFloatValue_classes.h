// BlueprintGeneratedClass BTD_SetFloatValue.BTD_SetFloatValue_C
// Size: 0xe8 (Inherited: 0xa0)
struct UBTD_SetFloatValue_C : UBTDecorator_BlueprintBase {
	bool Use Random Range; // 0xa0(0x01)
	enum class E_FloatValueCalculate CalculateType; // 0xa1(0x01)
	char pad_A2[0x6]; // 0xa2(0x06)
	double Value1; // 0xa8(0x08)
	double Value2; // 0xb0(0x08)
	double Obtained Value; // 0xb8(0x08)
	double Obtained Final Value; // 0xc0(0x08)
	struct FName FloatValue; // 0xc8(0x08)
	struct UBlackboardComponent* Blackboard; // 0xd0(0x08)
	struct AAIController* Owner Controller; // 0xd8(0x08)
	struct APawn* Controlled Pawn; // 0xe0(0x08)

	void Add(double FloatValue Before Change); // Function BTD_SetFloatValue.BTD_SetFloatValue_C.Add // (None) // @ game+0xffff8009df830000
};

