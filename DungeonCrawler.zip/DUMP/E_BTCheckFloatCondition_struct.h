// UserDefinedEnum E_BTCheckFloatCondition.E_BTCheckFloatCondition
enum class E_BTCheckFloatCondition : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator3 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	E_MAX = 4
};

