// BlueprintGeneratedClass BP_GameModeDungeon.BP_GameModeDungeon_C
// Size: 0x520 (Inherited: 0x518)
struct ABP_GameModeDungeon_C : ADCDungeonGameMode {
	struct USceneComponent* DefaultSceneRoot; // 0x518(0x08)
};

