// BlueprintGeneratedClass BP_ArcheryTarget.BP_ArcheryTarget_C
// Size: 0x4a8 (Inherited: 0x488)
struct ABP_ArcheryTarget_C : ABP_PropsActorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x488(0x08)
	struct UArrowComponent* Arrow; // 0x490(0x08)
	struct UBoxComponent* Box; // 0x498(0x08)
	struct UStaticMeshComponent* SM_ArcheryTarget; // 0x4a0(0x08)

	void CalArcheryScore(struct FVector HitLocation, double& Score); // Function BP_ArcheryTarget.BP_ArcheryTarget_C.CalArcheryScore // (Net|NetReliableNative|Event|NetResponse|Static|NetMulticast|UbergraphFunction|MulticastDelegate|Private|HasOutParms|HasDefaults|DLLImport|BlueprintEvent|Const|NetValidate) // @ game+0x18f61dfab0008
};

