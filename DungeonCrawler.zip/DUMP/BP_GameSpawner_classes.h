// BlueprintGeneratedClass BP_GameSpawner.BP_GameSpawner_C
// Size: 0x3b0 (Inherited: 0x368)
struct ABP_GameSpawner_C : ADCGameSpawner {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x368(0x08)
	struct UArrowComponent* Arrow; // 0x370(0x08)
	struct UBillboardComponent* Billboard; // 0x378(0x08)
	bool IsRespawn; // 0x380(0x01)
	char pad_381[0x7]; // 0x381(0x07)
	double RespawnTime; // 0x388(0x08)
	struct ADCMonsterBase* Monster; // 0x390(0x08)
	struct UBindMsgNode* BindMsgNodeRef; // 0x398(0x08)
	bool Wander While Peace; // 0x3a0(0x01)
	char pad_3A1[0x7]; // 0x3a1(0x07)
	double Wander Distance; // 0x3a8(0x08)

	void OnMessageReceived_7BD037A94378DC6DC7ED5E9029A4A824(struct UMsgBaseNode* ProxyObject); // Function BP_GameSpawner.BP_GameSpawner_C.OnMessageReceived_7BD037A94378DC6DC7ED5E9029A4A824 // (None) // @ game+0x13be0dfab0001
};

