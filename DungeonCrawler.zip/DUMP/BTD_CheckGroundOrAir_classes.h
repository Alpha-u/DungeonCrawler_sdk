// BlueprintGeneratedClass BTD_CheckGroundOrAir.BTD_CheckGroundOrAir_C
// Size: 0xa1 (Inherited: 0xa0)
struct UBTD_CheckGroundOrAir_C : UBTDecorator_BlueprintBase {
	enum class E_ActivityArea Monster Type; // 0xa0(0x01)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_CheckGroundOrAir.BTD_CheckGroundOrAir_C.PerformConditionCheckAI // (None) // @ game+0xe75fdf843df0
};

