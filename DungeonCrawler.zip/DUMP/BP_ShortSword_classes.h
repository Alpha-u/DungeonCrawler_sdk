// BlueprintGeneratedClass BP_ShortSword.BP_ShortSword_C
// Size: 0x578 (Inherited: 0x578)
struct ABP_ShortSword_C : ABP_DCItemActor_C {
	struct UDCAkComponent* DCAk; // 0x570(0x08)
};

