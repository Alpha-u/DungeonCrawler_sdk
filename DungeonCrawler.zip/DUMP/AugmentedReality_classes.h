// Class AugmentedReality.ARActor
// Size: 0x290 (Inherited: 0x290)
struct AARActor : AActor {
	struct FActorTickFunction PrimaryActorTick; // 0x28(0x30)
	char bNetTemporary : 1; // 0x58(0x01)
	char pad_2C0_1 : 1; // 0x2c0(0x01)
	char bOnlyRelevantToOwner : 1; // 0x58(0x01)
	char bAlwaysRelevant : 1; // 0x58(0x01)
	char bReplicateMovement : 1; // 0x58(0x01)
	char bCallPreReplication : 1; // 0x58(0x01)
	char bCallPreReplicationForReplay : 1; // 0x58(0x01)
	char bHidden : 1; // 0x58(0x01)
	char bTearOff : 1; // 0x59(0x01)
	char bForceNetAddressable : 1; // 0x59(0x01)
	char bExchangedRoles : 1; // 0x59(0x01)
	char bNetLoadOnClient : 1; // 0x59(0x01)
	char bNetUseOwnerRelevancy : 1; // 0x59(0x01)
	char bRelevantForNetworkReplays : 1; // 0x59(0x01)
	char bRelevantForLevelBounds : 1; // 0x59(0x01)
	char bReplayRewindable : 1; // 0x59(0x01)
	char bAllowTickBeforeBeginPlay : 1; // 0x5a(0x01)
	char bAutoDestroyWhenFinished : 1; // 0x5a(0x01)
	char bCanBeDamaged : 1; // 0x5a(0x01)
	char bBlockInput : 1; // 0x5a(0x01)
	char bCollideWhenPlacing : 1; // 0x5a(0x01)
	char bFindCameraComponentWhenViewTarget : 1; // 0x5a(0x01)
	char bGenerateOverlapEventsDuringLevelStreaming : 1; // 0x5a(0x01)
	char bIgnoresOriginShifting : 1; // 0x5a(0x01)
	char bEnableAutoLODGeneration : 1; // 0x5b(0x01)
	char bIsEditorOnlyActor : 1; // 0x5b(0x01)
	char bActorSeamlessTraveled : 1; // 0x5b(0x01)
	char bReplicates : 1; // 0x5b(0x01)
	char bCanBeInCluster : 1; // 0x5b(0x01)
	char bAllowReceiveTickEventOnDedicatedServer : 1; // 0x5b(0x01)
	char pad_2C3_6 : 1; // 0x2c3(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x5b(0x01)
	char pad_2C4_0 : 7; // 0x2c4(0x01)
	char bActorEnableCollision : 1; // 0x5c(0x01)
	char bActorIsBeingDestroyed : 1; // 0x5d(0x01)
	char pad_2C5_1 : 4; // 0x2c5(0x01)
	char bAsyncPhysicsTickEnabled : 1; // 0x5d(0x01)
	enum class EActorUpdateOverlapsMethod UpdateOverlapsMethodDuringLevelStreaming; // 0x5e(0x01)
	enum class EActorUpdateOverlapsMethod DefaultUpdateOverlapsMethodDuringLevelStreaming; // 0x5f(0x01)
	float InitialLifeSpan; // 0x60(0x04)
	float CustomTimeDilation; // 0x64(0x04)
	enum class ENetRole RemoteRole; // 0x68(0x01)
	int32_t RayTracingGroupId; // 0x6c(0x04)
	struct FRepAttachment AttachmentReplication; // 0x70(0x60)
	struct FRepMovement ReplicatedMovement; // 0xd0(0x70)
	struct AActor* Owner; // 0x140(0x08)
	struct FName NetDriverName; // 0x148(0x08)
	enum class ENetRole Role; // 0x150(0x01)
	enum class ENetDormancy NetDormancy; // 0x151(0x01)
	enum class ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingMethod; // 0x152(0x01)
	enum class EAutoReceiveInput AutoReceiveInput; // 0x153(0x01)
	int32_t InputPriority; // 0x154(0x04)
	struct UInputComponent* InputComponent; // 0x160(0x08)
	float NetCullDistanceSquared; // 0x168(0x04)
	int32_t NetTag; // 0x16c(0x04)
	float NetUpdateFrequency; // 0x170(0x04)
	float MinNetUpdateFrequency; // 0x174(0x04)
	float NetPriority; // 0x178(0x04)
	struct APawn* Instigator; // 0x180(0x08)
	struct TArray<struct AActor*> Children; // 0x188(0x10)
	struct USceneComponent* RootComponent; // 0x198(0x08)
	struct TArray<struct FName> Layers; // 0x1a8(0x10)
	struct TWeakObjectPtr<struct UChildActorComponent> ParentComponent; // 0x1b8(0x08)
	struct TArray<struct FName> Tags; // 0x1c0(0x10)
	struct FMulticastSparseDelegate OnTakeAnyDamage; // 0x1d0(0x01)
	struct FMulticastSparseDelegate OnTakePointDamage; // 0x1d1(0x01)
	struct FMulticastSparseDelegate OnTakeRadialDamage; // 0x1d2(0x01)
	struct FMulticastSparseDelegate OnActorBeginOverlap; // 0x1d3(0x01)
	struct FMulticastSparseDelegate OnActorEndOverlap; // 0x1d4(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x1d5(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x1d6(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x1d7(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x1d8(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x1d9(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x1da(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x1db(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x1dc(0x01)
	struct FMulticastSparseDelegate OnActorHit; // 0x1dd(0x01)
	struct FMulticastSparseDelegate OnDestroyed; // 0x1de(0x01)
	struct FMulticastSparseDelegate OnEndPlay; // 0x1df(0x01)
	struct TArray<struct UActorComponent*> InstanceComponents; // 0x260(0x10)
	struct TArray<struct UActorComponent*> BlueprintCreatedComponents; // 0x270(0x10)

	struct UARComponent* AddARComponent(struct UARComponent* InComponentClass, struct FGuid& NativeID); // Function AugmentedReality.ARActor.AddARComponent // (None) // @ game+0xffffc46edf830041
};

// Class AugmentedReality.ARBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UARBlueprintLibrary : UBlueprintFunctionLibrary {

	void UnpinComponent(struct USceneComponent* ComponentToUnpin); // Function AugmentedReality.ARBlueprintLibrary.UnpinComponent // (None) // @ game+0xffffc4abdf830041
};

// Class AugmentedReality.ARTraceResultLibrary
// Size: 0x28 (Inherited: 0x28)
struct UARTraceResultLibrary : UBlueprintFunctionLibrary {

	struct UARTrackedGeometry* GetTrackedGeometry(struct FARTraceResult& TraceResult); // Function AugmentedReality.ARTraceResultLibrary.GetTrackedGeometry // (None) // @ game+0xffffc4b1df830041
};

// Class AugmentedReality.ARBaseAsyncTaskBlueprintProxy
// Size: 0x50 (Inherited: 0x30)
struct UARBaseAsyncTaskBlueprintProxy : UBlueprintAsyncActionBase {
	char pad_30[0x20]; // 0x30(0x20)
};

// Class AugmentedReality.ARSaveWorldAsyncTaskBlueprintProxy
// Size: 0x80 (Inherited: 0x50)
struct UARSaveWorldAsyncTaskBlueprintProxy : UARBaseAsyncTaskBlueprintProxy {
	struct FMulticastInlineDelegate OnSuccess; // 0x50(0x10)
	struct FMulticastInlineDelegate OnFailed; // 0x60(0x10)
	char pad_70[0x10]; // 0x70(0x10)

	struct UARSaveWorldAsyncTaskBlueprintProxy* ARSaveWorld(struct UObject* WorldContextObject); // Function AugmentedReality.ARSaveWorldAsyncTaskBlueprintProxy.ARSaveWorld // (None) // @ game+0xffffc4b2df830041
};

// Class AugmentedReality.ARGetCandidateObjectAsyncTaskBlueprintProxy
// Size: 0xb0 (Inherited: 0x50)
struct UARGetCandidateObjectAsyncTaskBlueprintProxy : UARBaseAsyncTaskBlueprintProxy {
	struct FMulticastInlineDelegate OnSuccess; // 0x50(0x10)
	struct FMulticastInlineDelegate OnFailed; // 0x60(0x10)
	char pad_70[0x40]; // 0x70(0x40)

	struct UARGetCandidateObjectAsyncTaskBlueprintProxy* ARGetCandidateObject(struct UObject* WorldContextObject, struct FVector Location, struct FVector Extent); // Function AugmentedReality.ARGetCandidateObjectAsyncTaskBlueprintProxy.ARGetCandidateObject // (None) // @ game+0xffffc4b3df830041
};

// Class AugmentedReality.ARComponent
// Size: 0x320 (Inherited: 0x2a0)
struct UARComponent : USceneComponent {
	struct FGuid NativeID; // 0x2a0(0x10)
	char pad_2B0[0x30]; // 0x2b0(0x30)
	bool bUseDefaultReplication; // 0x2e0(0x01)
	char pad_2E1[0x7]; // 0x2e1(0x07)
	struct UMaterialInterface* DefaultMeshMaterial; // 0x2e8(0x08)
	struct UMaterialInterface* DefaultWireframeMeshMaterial; // 0x2f0(0x08)
	struct UMRMeshComponent* MRMeshComponent; // 0x2f8(0x08)
	struct UARTrackedGeometry* MyTrackedGeometry; // 0x300(0x08)
	char pad_308[0x18]; // 0x308(0x18)

	void UpdateVisualization(); // Function AugmentedReality.ARComponent.UpdateVisualization // (None) // @ game+0xffffc4b8df830041
};

// Class AugmentedReality.ARPlaneComponent
// Size: 0x3f0 (Inherited: 0x320)
struct UARPlaneComponent : UARComponent {
	struct FARPlaneUpdatePayload ReplicatedPayload; // 0x320(0xd0)

	void SetPlaneComponentDebugMode(enum class EPlaneComponentDebugMode NewDebugMode); // Function AugmentedReality.ARPlaneComponent.SetPlaneComponentDebugMode // (None) // @ game+0xffffc4bedf830041
};

// Class AugmentedReality.ARPointComponent
// Size: 0x330 (Inherited: 0x320)
struct UARPointComponent : UARComponent {
	struct FARPointUpdatePayload ReplicatedPayload; // 0x320(0x01)
	char pad_321[0xf]; // 0x321(0x0f)

	void ServerUpdatePayload(struct FARPointUpdatePayload NewPayload); // Function AugmentedReality.ARPointComponent.ServerUpdatePayload // (None) // @ game+0xffffc4c1df830041
};

// Class AugmentedReality.ARFaceComponent
// Size: 0x3b0 (Inherited: 0x320)
struct UARFaceComponent : UARComponent {
	enum class EARFaceTransformMixing TransformSetting; // 0x320(0x01)
	bool bUpdateVertexNormal; // 0x321(0x01)
	bool bFaceOutOfScreen; // 0x322(0x01)
	char pad_323[0x5]; // 0x323(0x05)
	struct FARFaceUpdatePayload ReplicatedPayload; // 0x328(0x60)
	char pad_388[0x28]; // 0x388(0x28)

	void SetFaceComponentDebugMode(enum class EFaceComponentDebugMode NewDebugMode); // Function AugmentedReality.ARFaceComponent.SetFaceComponentDebugMode // (None) // @ game+0xffffc4c5df830041
};

// Class AugmentedReality.ARImageComponent
// Size: 0x3c0 (Inherited: 0x320)
struct UARImageComponent : UARComponent {
	struct FARImageUpdatePayload ReplicatedPayload; // 0x320(0xa0)

	void SetImageComponentDebugMode(enum class EImageComponentDebugMode NewDebugMode); // Function AugmentedReality.ARImageComponent.SetImageComponentDebugMode // (None) // @ game+0xffffc4c9df830041
};

// Class AugmentedReality.ARQRCodeComponent
// Size: 0x3d0 (Inherited: 0x320)
struct UARQRCodeComponent : UARComponent {
	struct FARQRCodeUpdatePayload ReplicatedPayload; // 0x320(0xb0)

	void SetQRCodeComponentDebugMode(enum class EQRCodeComponentDebugMode NewDebugMode); // Function AugmentedReality.ARQRCodeComponent.SetQRCodeComponentDebugMode // (None) // @ game+0xffffc4cddf830041
};

// Class AugmentedReality.ARPoseComponent
// Size: 0x390 (Inherited: 0x320)
struct UARPoseComponent : UARComponent {
	struct FARPoseUpdatePayload ReplicatedPayload; // 0x320(0x70)

	void SetPoseComponentDebugMode(enum class EPoseComponentDebugMode NewDebugMode); // Function AugmentedReality.ARPoseComponent.SetPoseComponentDebugMode // (None) // @ game+0xffffc4d1df830041
};

// Class AugmentedReality.AREnvironmentProbeComponent
// Size: 0x380 (Inherited: 0x320)
struct UAREnvironmentProbeComponent : UARComponent {
	struct FAREnvironmentProbeUpdatePayload ReplicatedPayload; // 0x320(0x60)

	void ServerUpdatePayload(struct FAREnvironmentProbeUpdatePayload NewPayload); // Function AugmentedReality.AREnvironmentProbeComponent.ServerUpdatePayload // (None) // @ game+0xffffc4d4df830041
};

// Class AugmentedReality.ARObjectComponent
// Size: 0x380 (Inherited: 0x320)
struct UARObjectComponent : UARComponent {
	struct FARObjectUpdatePayload ReplicatedPayload; // 0x320(0x60)

	void ServerUpdatePayload(struct FARObjectUpdatePayload NewPayload); // Function AugmentedReality.ARObjectComponent.ServerUpdatePayload // (None) // @ game+0xffffc4d7df830041
};

// Class AugmentedReality.ARMeshComponent
// Size: 0x3b0 (Inherited: 0x320)
struct UARMeshComponent : UARComponent {
	struct FARMeshUpdatePayload ReplicatedPayload; // 0x320(0x90)

	void ServerUpdatePayload(struct FARMeshUpdatePayload NewPayload); // Function AugmentedReality.ARMeshComponent.ServerUpdatePayload // (None) // @ game+0xffffc4dadf830041
};

// Class AugmentedReality.ARGeoAnchorComponent
// Size: 0x3c0 (Inherited: 0x320)
struct UARGeoAnchorComponent : UARComponent {
	struct FARGeoAnchorUpdatePayload ReplicatedPayload; // 0x320(0xa0)

	void SetGeoAnchorComponentDebugMode(enum class EGeoAnchorComponentDebugMode NewDebugMode); // Function AugmentedReality.ARGeoAnchorComponent.SetGeoAnchorComponentDebugMode // (None) // @ game+0xffffc4dedf830041
};

// Class AugmentedReality.ARDependencyHandler
// Size: 0x28 (Inherited: 0x28)
struct UARDependencyHandler : UObject {

	void StartARSessionLatent(struct UObject* WorldContextObject, struct UARSessionConfig* SessionConfig, struct FLatentActionInfo LatentInfo); // Function AugmentedReality.ARDependencyHandler.StartARSessionLatent // (None) // @ game+0xffffc4e3df830041
};

// Class AugmentedReality.ARGeoTrackingSupport
// Size: 0x28 (Inherited: 0x28)
struct UARGeoTrackingSupport : UObject {

	struct UARGeoTrackingSupport* GetGeoTrackingSupport(); // Function AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingSupport // (None) // @ game+0xffffc4e9df830041
};

// Class AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy
// Size: 0xa0 (Inherited: 0x50)
struct UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy : UARBaseAsyncTaskBlueprintProxy {
	struct FMulticastInlineDelegate OnSuccess; // 0x50(0x10)
	struct FMulticastInlineDelegate OnFailed; // 0x60(0x10)
	char pad_70[0x30]; // 0x70(0x30)

	void GeoTrackingAvailabilityDelegate__DelegateSignature(bool bIsAvailable, struct FString Error); // DelegateFunction AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy.GeoTrackingAvailabilityDelegate__DelegateSignature // (None) // @ game+0xffff9961df830041
};

// Class AugmentedReality.GetGeoLocationAsyncTaskBlueprintProxy
// Size: 0xa8 (Inherited: 0x50)
struct UGetGeoLocationAsyncTaskBlueprintProxy : UARBaseAsyncTaskBlueprintProxy {
	struct FMulticastInlineDelegate OnSuccess; // 0x50(0x10)
	struct FMulticastInlineDelegate OnFailed; // 0x60(0x10)
	char pad_70[0x38]; // 0x70(0x38)

	void GetGeoLocationDelegate__DelegateSignature(float Longitude, float Latitude, float Altitude, struct FString Error); // DelegateFunction AugmentedReality.GetGeoLocationAsyncTaskBlueprintProxy.GetGeoLocationDelegate__DelegateSignature // (None) // @ game+0xffff9963df830041
};

// Class AugmentedReality.ARLifeCycleComponent
// Size: 0x2d0 (Inherited: 0x2a0)
struct UARLifeCycleComponent : USceneComponent {
	struct FMulticastInlineDelegate OnARActorSpawnedDelegate; // 0x2a0(0x10)
	struct FMulticastInlineDelegate OnARActorToBeDestroyedDelegate; // 0x2b0(0x10)
	char pad_2C0[0x10]; // 0x2c0(0x10)

	void ServerSpawnARActor(struct UObject* ComponentClass, struct FGuid NativeID); // Function AugmentedReality.ARLifeCycleComponent.ServerSpawnARActor // (None) // @ game+0xffff995edf830041
};

// Class AugmentedReality.ARLightEstimate
// Size: 0x28 (Inherited: 0x28)
struct UARLightEstimate : UObject {
};

// Class AugmentedReality.ARBasicLightEstimate
// Size: 0x40 (Inherited: 0x28)
struct UARBasicLightEstimate : UARLightEstimate {
	float AmbientIntensityLumens; // 0x28(0x04)
	float AmbientColorTemperatureKelvin; // 0x2c(0x04)
	struct FLinearColor AmbientColor; // 0x30(0x10)

	float GetAmbientIntensityLumens(); // Function AugmentedReality.ARBasicLightEstimate.GetAmbientIntensityLumens // (None) // @ game+0xffffc4ecdf830041
};

// Class AugmentedReality.AROriginActor
// Size: 0x290 (Inherited: 0x290)
struct AAROriginActor : AActor {
	struct FActorTickFunction PrimaryActorTick; // 0x28(0x30)
	char bNetTemporary : 1; // 0x58(0x01)
	char pad_2C0_1 : 1; // 0x2c0(0x01)
	char bOnlyRelevantToOwner : 1; // 0x58(0x01)
	char bAlwaysRelevant : 1; // 0x58(0x01)
	char bReplicateMovement : 1; // 0x58(0x01)
	char bCallPreReplication : 1; // 0x58(0x01)
	char bCallPreReplicationForReplay : 1; // 0x58(0x01)
	char bHidden : 1; // 0x58(0x01)
	char bTearOff : 1; // 0x59(0x01)
	char bForceNetAddressable : 1; // 0x59(0x01)
	char bExchangedRoles : 1; // 0x59(0x01)
	char bNetLoadOnClient : 1; // 0x59(0x01)
	char bNetUseOwnerRelevancy : 1; // 0x59(0x01)
	char bRelevantForNetworkReplays : 1; // 0x59(0x01)
	char bRelevantForLevelBounds : 1; // 0x59(0x01)
	char bReplayRewindable : 1; // 0x59(0x01)
	char bAllowTickBeforeBeginPlay : 1; // 0x5a(0x01)
	char bAutoDestroyWhenFinished : 1; // 0x5a(0x01)
	char bCanBeDamaged : 1; // 0x5a(0x01)
	char bBlockInput : 1; // 0x5a(0x01)
	char bCollideWhenPlacing : 1; // 0x5a(0x01)
	char bFindCameraComponentWhenViewTarget : 1; // 0x5a(0x01)
	char bGenerateOverlapEventsDuringLevelStreaming : 1; // 0x5a(0x01)
	char bIgnoresOriginShifting : 1; // 0x5a(0x01)
	char bEnableAutoLODGeneration : 1; // 0x5b(0x01)
	char bIsEditorOnlyActor : 1; // 0x5b(0x01)
	char bActorSeamlessTraveled : 1; // 0x5b(0x01)
	char bReplicates : 1; // 0x5b(0x01)
	char bCanBeInCluster : 1; // 0x5b(0x01)
	char bAllowReceiveTickEventOnDedicatedServer : 1; // 0x5b(0x01)
	char pad_2C3_6 : 1; // 0x2c3(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x5b(0x01)
	char pad_2C4_0 : 7; // 0x2c4(0x01)
	char bActorEnableCollision : 1; // 0x5c(0x01)
	char bActorIsBeingDestroyed : 1; // 0x5d(0x01)
	char pad_2C5_1 : 4; // 0x2c5(0x01)
	char bAsyncPhysicsTickEnabled : 1; // 0x5d(0x01)
	enum class EActorUpdateOverlapsMethod UpdateOverlapsMethodDuringLevelStreaming; // 0x5e(0x01)
	enum class EActorUpdateOverlapsMethod DefaultUpdateOverlapsMethodDuringLevelStreaming; // 0x5f(0x01)
	float InitialLifeSpan; // 0x60(0x04)
	float CustomTimeDilation; // 0x64(0x04)
	enum class ENetRole RemoteRole; // 0x68(0x01)
	int32_t RayTracingGroupId; // 0x6c(0x04)
	struct FRepAttachment AttachmentReplication; // 0x70(0x60)
	struct FRepMovement ReplicatedMovement; // 0xd0(0x70)
	struct AActor* Owner; // 0x140(0x08)
	struct FName NetDriverName; // 0x148(0x08)
	enum class ENetRole Role; // 0x150(0x01)
	enum class ENetDormancy NetDormancy; // 0x151(0x01)
	enum class ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingMethod; // 0x152(0x01)
	enum class EAutoReceiveInput AutoReceiveInput; // 0x153(0x01)
	int32_t InputPriority; // 0x154(0x04)
	struct UInputComponent* InputComponent; // 0x160(0x08)
	float NetCullDistanceSquared; // 0x168(0x04)
	int32_t NetTag; // 0x16c(0x04)
	float NetUpdateFrequency; // 0x170(0x04)
	float MinNetUpdateFrequency; // 0x174(0x04)
	float NetPriority; // 0x178(0x04)
	struct APawn* Instigator; // 0x180(0x08)
	struct TArray<struct AActor*> Children; // 0x188(0x10)
	struct USceneComponent* RootComponent; // 0x198(0x08)
	struct TArray<struct FName> Layers; // 0x1a8(0x10)
	struct TWeakObjectPtr<struct UChildActorComponent> ParentComponent; // 0x1b8(0x08)
	struct TArray<struct FName> Tags; // 0x1c0(0x10)
	struct FMulticastSparseDelegate OnTakeAnyDamage; // 0x1d0(0x01)
	struct FMulticastSparseDelegate OnTakePointDamage; // 0x1d1(0x01)
	struct FMulticastSparseDelegate OnTakeRadialDamage; // 0x1d2(0x01)
	struct FMulticastSparseDelegate OnActorBeginOverlap; // 0x1d3(0x01)
	struct FMulticastSparseDelegate OnActorEndOverlap; // 0x1d4(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x1d5(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x1d6(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x1d7(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x1d8(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x1d9(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x1da(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x1db(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x1dc(0x01)
	struct FMulticastSparseDelegate OnActorHit; // 0x1dd(0x01)
	struct FMulticastSparseDelegate OnDestroyed; // 0x1de(0x01)
	struct FMulticastSparseDelegate OnEndPlay; // 0x1df(0x01)
	struct TArray<struct UActorComponent*> InstanceComponents; // 0x260(0x10)
	struct TArray<struct UActorComponent*> BlueprintCreatedComponents; // 0x270(0x10)
};

// Class AugmentedReality.ARPin
// Size: 0x150 (Inherited: 0x28)
struct UARPin : UObject {
	struct UARTrackedGeometry* TrackedGeometry; // 0x28(0x08)
	struct USceneComponent* PinnedComponent; // 0x30(0x08)
	char pad_38[0x8]; // 0x38(0x08)
	struct FTransform LocalToTrackingTransform; // 0x40(0x60)
	struct FTransform LocalToAlignedTrackingTransform; // 0xa0(0x60)
	enum class EARTrackingState TrackingState; // 0x100(0x01)
	char pad_101[0x1f]; // 0x101(0x1f)
	struct FMulticastInlineDelegate OnARTrackingStateChanged; // 0x120(0x10)
	struct FMulticastInlineDelegate OnARTransformUpdated; // 0x130(0x10)
	char pad_140[0x10]; // 0x140(0x10)

	enum class EARTrackingState GetTrackingState(); // Function AugmentedReality.ARPin.GetTrackingState // (None) // @ game+0xffffc4f3df830041
};

// Class AugmentedReality.ARSessionConfig
// Size: 0x110 (Inherited: 0x30)
struct UARSessionConfig : UDataAsset {
	bool bGenerateMeshDataFromTrackedGeometry; // 0x30(0x01)
	bool bGenerateCollisionForMeshData; // 0x31(0x01)
	bool bGenerateNavMeshForMeshData; // 0x32(0x01)
	bool bUseMeshDataForOcclusion; // 0x33(0x01)
	bool bRenderMeshDataInWireframe; // 0x34(0x01)
	bool bTrackSceneObjects; // 0x35(0x01)
	bool bUsePersonSegmentationForOcclusion; // 0x36(0x01)
	bool bUseSceneDepthForOcclusion; // 0x37(0x01)
	bool bUseAutomaticImageScaleEstimation; // 0x38(0x01)
	bool bUseStandardOnboardingUX; // 0x39(0x01)
	enum class EARWorldAlignment WorldAlignment; // 0x3a(0x01)
	enum class EARSessionType SessionType; // 0x3b(0x01)
	enum class EARPlaneDetectionMode PlaneDetectionMode; // 0x3c(0x01)
	bool bHorizontalPlaneDetection; // 0x3d(0x01)
	bool bVerticalPlaneDetection; // 0x3e(0x01)
	bool bEnableAutoFocus; // 0x3f(0x01)
	enum class EARLightEstimationMode LightEstimationMode; // 0x40(0x01)
	enum class EARFrameSyncMode FrameSyncMode; // 0x41(0x01)
	bool bEnableAutomaticCameraOverlay; // 0x42(0x01)
	bool bEnableAutomaticCameraTracking; // 0x43(0x01)
	bool bResetCameraTracking; // 0x44(0x01)
	bool bResetTrackedObjects; // 0x45(0x01)
	char pad_46[0x2]; // 0x46(0x02)
	struct TArray<struct UARCandidateImage*> CandidateImages; // 0x48(0x10)
	int32_t MaxNumSimultaneousImagesTracked; // 0x58(0x04)
	enum class EAREnvironmentCaptureProbeType EnvironmentCaptureProbeType; // 0x5c(0x01)
	char pad_5D[0x3]; // 0x5d(0x03)
	struct TArray<char> WorldMapData; // 0x60(0x10)
	struct TArray<struct UARCandidateObject*> CandidateObjects; // 0x70(0x10)
	struct FARVideoFormat DesiredVideoFormat; // 0x80(0x0c)
	bool bUseOptimalVideoFormat; // 0x8c(0x01)
	enum class EARFaceTrackingDirection FaceTrackingDirection; // 0x8d(0x01)
	enum class EARFaceTrackingUpdate FaceTrackingUpdate; // 0x8e(0x01)
	char pad_8F[0x1]; // 0x8f(0x01)
	int32_t MaxNumberOfTrackedFaces; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
	struct TArray<char> SerializedARCandidateImageDatabase; // 0x98(0x10)
	enum class EARSessionTrackingFeature EnabledSessionTrackingFeature; // 0xa8(0x01)
	enum class EARSceneReconstruction SceneReconstructionMethod; // 0xa9(0x01)
	char pad_AA[0x6]; // 0xaa(0x06)
	struct UARPlaneComponent* PlaneComponentClass; // 0xb0(0x08)
	struct UARPointComponent* PointComponentClass; // 0xb8(0x08)
	struct UARFaceComponent* FaceComponentClass; // 0xc0(0x08)
	struct UARImageComponent* ImageComponentClass; // 0xc8(0x08)
	struct UARQRCodeComponent* QRCodeComponentClass; // 0xd0(0x08)
	struct UARPoseComponent* PoseComponentClass; // 0xd8(0x08)
	struct UAREnvironmentProbeComponent* EnvironmentProbeComponentClass; // 0xe0(0x08)
	struct UARObjectComponent* ObjectComponentClass; // 0xe8(0x08)
	struct UARMeshComponent* MeshComponentClass; // 0xf0(0x08)
	struct UARGeoAnchorComponent* GeoAnchorComponentClass; // 0xf8(0x08)
	struct UMaterialInterface* DefaultMeshMaterial; // 0x100(0x08)
	struct UMaterialInterface* DefaultWireframeMeshMaterial; // 0x108(0x08)

	bool ShouldResetTrackedObjects(); // Function AugmentedReality.ARSessionConfig.ShouldResetTrackedObjects // (None) // @ game+0xffffc513df830041
};

// Class AugmentedReality.ARSharedWorldGameMode
// Size: 0x3e0 (Inherited: 0x378)
struct AARSharedWorldGameMode : AGameMode {
	int32_t BufferSizePerChunk; // 0x378(0x04)
	char pad_37C[0x64]; // 0x37c(0x64)

	void SetPreviewImageData(struct TArray<char> ImageData); // Function AugmentedReality.ARSharedWorldGameMode.SetPreviewImageData // (None) // @ game+0xffffc521df830041
};

// Class AugmentedReality.ARSharedWorldGameState
// Size: 0x338 (Inherited: 0x300)
struct AARSharedWorldGameState : AGameState {
	struct TArray<char> PreviewImageData; // 0x300(0x10)
	struct TArray<char> ARWorldData; // 0x310(0x10)
	int32_t PreviewImageBytesTotal; // 0x320(0x04)
	int32_t ARWorldBytesTotal; // 0x324(0x04)
	int32_t PreviewImageBytesDelivered; // 0x328(0x04)
	int32_t ARWorldBytesDelivered; // 0x32c(0x04)
	char pad_330[0x8]; // 0x330(0x08)

	void K2_OnARWorldMapIsReady(); // Function AugmentedReality.ARSharedWorldGameState.K2_OnARWorldMapIsReady // (None) // @ game+0xffffc524df830041
};

// Class AugmentedReality.ARSharedWorldPlayerController
// Size: 0x858 (Inherited: 0x850)
struct AARSharedWorldPlayerController : APlayerController {
	struct UPlayer* Player; // 0x330(0x08)
	struct APawn* AcknowledgedPawn; // 0x338(0x08)
	struct AHUD* MyHUD; // 0x340(0x08)
	struct APlayerCameraManager* PlayerCameraManager; // 0x348(0x08)
	struct APlayerCameraManager* PlayerCameraManagerClass; // 0x350(0x08)
	bool bAutoManageActiveCameraTarget; // 0x358(0x01)
	struct FRotator TargetViewRotation; // 0x360(0x18)
	float SmoothTargetViewRotationSpeed; // 0x390(0x04)
	struct TArray<struct AActor*> HiddenActors; // 0x398(0x10)
	struct TArray<struct TWeakObjectPtr<struct UPrimitiveComponent>> HiddenPrimitiveComponents; // 0x3a8(0x10)
	float LastSpectatorStateSynchTime; // 0x3bc(0x04)
	struct FVector LastSpectatorSyncLocation; // 0x3c0(0x18)
	struct FRotator LastSpectatorSyncRotation; // 0x3d8(0x18)
	int32_t ClientCap; // 0x3f0(0x04)
	struct UCheatManager* CheatManager; // 0x3f8(0x08)
	struct UCheatManager* CheatClass; // 0x400(0x08)
	struct UPlayerInput* PlayerInput; // 0x408(0x08)
	struct TArray<struct FActiveForceFeedbackEffect> ActiveForceFeedbackEffects; // 0x410(0x10)
	struct UAsyncPhysicsData* AsyncPhysicsDataClass; // 0x420(0x08)
	struct UAsyncPhysicsInputComponent* AsyncPhysicsDataComponent; // 0x428(0x08)
	char pad_925_0 : 4; // 0x925(0x01)
	char bPlayerIsWaiting : 1; // 0x4b0(0x01)
	char NetPlayerIndex; // 0x4b4(0x01)
	struct UNetConnection* PendingSwapConnection; // 0x510(0x08)
	struct UNetConnection* NetConnection; // 0x518(0x08)
	float InputYawScale; // 0x538(0x04)
	float InputPitchScale; // 0x53c(0x04)
	float InputRollScale; // 0x540(0x04)
	char bShowMouseCursor : 1; // 0x544(0x01)
	char bEnableClickEvents : 1; // 0x544(0x01)
	char bEnableTouchEvents : 1; // 0x544(0x01)
	char pad_943_0 : 3; // 0x943(0x01)
	char bEnableMouseOverEvents : 1; // 0x544(0x01)
	char bEnableTouchOverEvents : 1; // 0x544(0x01)
	char bForceFeedbackEnabled : 1; // 0x544(0x01)
	char bEnableMotionControls : 1; // 0x544(0x01)
	char bEnableStreamingSource : 1; // 0x544(0x01)
	char bStreamingSourceShouldActivate : 1; // 0x545(0x01)
	char bStreamingSourceShouldBlockOnSlowStreaming : 1; // 0x545(0x01)
	enum class EStreamingSourcePriority StreamingSourcePriority; // 0x548(0x01)
	struct FColor StreamingSourceDebugColor; // 0x54c(0x04)
	struct TArray<struct FStreamingSourceShape> StreamingSourceShapes; // 0x550(0x10)
	float ForceFeedbackScale; // 0x560(0x04)
	struct TArray<struct FKey> ClickEventKeys; // 0x568(0x10)
	enum class EMouseCursor DefaultMouseCursor; // 0x578(0x01)
	enum class EMouseCursor CurrentMouseCursor; // 0x579(0x01)
	enum class ECollisionChannel DefaultClickTraceChannel; // 0x57a(0x01)
	enum class ECollisionChannel CurrentClickTraceChannel; // 0x57b(0x01)
	float HitResultTraceDistance; // 0x57c(0x04)
	uint16_t SeamlessTravelCount; // 0x580(0x02)
	uint16_t LastCompletedSeamlessTravelCount; // 0x582(0x02)
	struct UInputComponent* InactiveStateInputComponent; // 0x608(0x08)
	char bShouldPerformFullTickWhenPaused : 1; // 0x610(0x01)
	struct UTouchInterface* CurrentTouchInterface; // 0x628(0x08)
	struct UPlayerInput* OverridePlayerInputClass; // 0x630(0x08)
	struct ASpectatorPawn* SpectatorPawn; // 0x6b0(0x08)
	bool bIsLocalPlayerController; // 0x6bc(0x01)
	struct FVector SpawnLocation; // 0x6c0(0x18)

	void ServerMarkReadyForReceiving(); // Function AugmentedReality.ARSharedWorldPlayerController.ServerMarkReadyForReceiving // (None) // @ game+0xffffc528df830041
};

// Class AugmentedReality.ARSkyLight
// Size: 0x2b0 (Inherited: 0x2a0)
struct AARSkyLight : ASkyLight {
	struct UAREnvironmentCaptureProbe* CaptureProbe; // 0x2a0(0x08)
	char pad_2A8[0x8]; // 0x2a8(0x08)

	void SetEnvironmentCaptureProbe(struct UAREnvironmentCaptureProbe* InCaptureProbe); // Function AugmentedReality.ARSkyLight.SetEnvironmentCaptureProbe // (None) // @ game+0xffffc52adf830041
};

// Class AugmentedReality.ARTexture
// Size: 0x220 (Inherited: 0x1f0)
struct UARTexture : UTexture {
	enum class EARTextureType TextureType; // 0x1f0(0x01)
	char pad_1F1[0x3]; // 0x1f1(0x03)
	float Timestamp; // 0x1f4(0x04)
	struct FGuid ExternalTextureGuid; // 0x1f8(0x10)
	struct FVector2D Size; // 0x208(0x10)
	char pad_218[0x8]; // 0x218(0x08)
};

// Class AugmentedReality.ARTextureCameraImage
// Size: 0x220 (Inherited: 0x220)
struct UARTextureCameraImage : UARTexture {
	enum class EARTextureType TextureType; // 0x1f0(0x01)
	float Timestamp; // 0x1f4(0x04)
	struct FGuid ExternalTextureGuid; // 0x1f8(0x10)
	struct FVector2D Size; // 0x208(0x10)
};

// Class AugmentedReality.ARTextureCameraDepth
// Size: 0x220 (Inherited: 0x220)
struct UARTextureCameraDepth : UARTexture {
	enum class EARDepthQuality DepthQuality; // 0x218(0x01)
	enum class EARDepthAccuracy DepthAccuracy; // 0x219(0x01)
	bool bIsTemporallySmoothed; // 0x21a(0x01)
};

// Class AugmentedReality.AREnvironmentCaptureProbeTexture
// Size: 0x2c0 (Inherited: 0x290)
struct UAREnvironmentCaptureProbeTexture : UTextureCube {
	enum class EARTextureType TextureType; // 0x290(0x01)
	char pad_291[0x3]; // 0x291(0x03)
	float Timestamp; // 0x294(0x04)
	struct FGuid ExternalTextureGuid; // 0x298(0x10)
	struct FVector2D Size; // 0x2a8(0x10)
	char pad_2B8[0x8]; // 0x2b8(0x08)
};

// Class AugmentedReality.ARTraceResultDummy
// Size: 0x28 (Inherited: 0x28)
struct UARTraceResultDummy : UObject {
};

// Class AugmentedReality.ARTrackedGeometry
// Size: 0x160 (Inherited: 0x28)
struct UARTrackedGeometry : UObject {
	struct FGuid UniqueId; // 0x28(0x10)
	char pad_38[0x8]; // 0x38(0x08)
	struct FTransform LocalToTrackingTransform; // 0x40(0x60)
	struct FTransform LocalToAlignedTrackingTransform; // 0xa0(0x60)
	enum class EARTrackingState TrackingState; // 0x100(0x01)
	char pad_101[0xf]; // 0x101(0x0f)
	struct UMRMeshComponent* UnderlyingMesh; // 0x110(0x08)
	enum class EARObjectClassification ObjectClassification; // 0x118(0x01)
	enum class EARSpatialMeshUsageFlags SpatialMeshUsageFlags; // 0x119(0x01)
	char pad_11A[0x16]; // 0x11a(0x16)
	int32_t LastUpdateFrameNumber; // 0x130(0x04)
	char pad_134[0xc]; // 0x134(0x0c)
	struct FName DebugName; // 0x140(0x08)
	char pad_148[0x18]; // 0x148(0x18)

	bool IsTracked(); // Function AugmentedReality.ARTrackedGeometry.IsTracked // (None) // @ game+0xffffc537df830041
};

// Class AugmentedReality.ARPlaneGeometry
// Size: 0x1b0 (Inherited: 0x160)
struct UARPlaneGeometry : UARTrackedGeometry {
	enum class EARPlaneOrientation Orientation; // 0x158(0x01)
	struct FVector Center; // 0x160(0x18)
	struct FVector Extent; // 0x178(0x18)
	struct TArray<struct FVector> BoundaryPolygon; // 0x190(0x10)
	struct UARPlaneGeometry* SubsumedBy; // 0x1a0(0x08)
	char pad_1A9[0x7]; // 0x1a9(0x07)

	struct UARPlaneGeometry* GetSubsumedBy(); // Function AugmentedReality.ARPlaneGeometry.GetSubsumedBy // (None) // @ game+0xffffc53cdf830041
};

// Class AugmentedReality.ARTrackedPoint
// Size: 0x160 (Inherited: 0x160)
struct UARTrackedPoint : UARTrackedGeometry {
	struct FGuid UniqueId; // 0x28(0x10)
	struct FTransform LocalToTrackingTransform; // 0x40(0x60)
	struct FTransform LocalToAlignedTrackingTransform; // 0xa0(0x60)
	enum class EARTrackingState TrackingState; // 0x100(0x01)
	struct UMRMeshComponent* UnderlyingMesh; // 0x110(0x08)
	enum class EARObjectClassification ObjectClassification; // 0x118(0x01)
	enum class EARSpatialMeshUsageFlags SpatialMeshUsageFlags; // 0x119(0x01)
	int32_t LastUpdateFrameNumber; // 0x130(0x04)
	struct FName DebugName; // 0x140(0x08)
};

// Class AugmentedReality.ARTrackedImage
// Size: 0x170 (Inherited: 0x160)
struct UARTrackedImage : UARTrackedGeometry {
	struct UARCandidateImage* DetectedImage; // 0x158(0x08)
	struct FVector2D EstimatedSize; // 0x160(0x10)

	struct FVector2D GetEstimateSize(); // Function AugmentedReality.ARTrackedImage.GetEstimateSize // (None) // @ game+0xffffc53edf830041
};

// Class AugmentedReality.ARTrackedQRCode
// Size: 0x190 (Inherited: 0x170)
struct UARTrackedQRCode : UARTrackedImage {
	struct FString QRCode; // 0x170(0x10)
	int32_t Version; // 0x180(0x04)
	char pad_184[0xc]; // 0x184(0x0c)
};

// Class AugmentedReality.ARFaceGeometry
// Size: 0x2c0 (Inherited: 0x160)
struct UARFaceGeometry : UARTrackedGeometry {
	struct FVector LookAtTarget; // 0x158(0x18)
	bool bIsTracked; // 0x170(0x01)
	struct TMap<enum class EARFaceBlendShape, float> BlendShapes; // 0x178(0x50)
	char pad_1C9[0x37]; // 0x1c9(0x37)
	struct FTransform LeftEyeTransform; // 0x200(0x60)
	struct FTransform RightEyeTransform; // 0x260(0x60)

	struct FTransform GetWorldSpaceEyeTransform(enum class EAREye Eye); // Function AugmentedReality.ARFaceGeometry.GetWorldSpaceEyeTransform // (None) // @ game+0xffffc542df830041
};

// Class AugmentedReality.AREnvironmentCaptureProbe
// Size: 0x180 (Inherited: 0x160)
struct UAREnvironmentCaptureProbe : UARTrackedGeometry {
	struct FVector Extent; // 0x158(0x18)
	struct UAREnvironmentCaptureProbeTexture* EnvironmentCaptureTexture; // 0x170(0x08)

	struct FVector GetExtent(); // Function AugmentedReality.AREnvironmentCaptureProbe.GetExtent // (None) // @ game+0xffffc544df830041
};

// Class AugmentedReality.ARTrackedObject
// Size: 0x160 (Inherited: 0x160)
struct UARTrackedObject : UARTrackedGeometry {
	struct UARCandidateObject* DetectedObject; // 0x158(0x08)

	struct UARCandidateObject* GetDetectedObject(); // Function AugmentedReality.ARTrackedObject.GetDetectedObject // (None) // @ game+0xffffc545df830041
};

// Class AugmentedReality.ARTrackedPose
// Size: 0x1b0 (Inherited: 0x160)
struct UARTrackedPose : UARTrackedGeometry {
	struct FARPose3D TrackedPose; // 0x158(0x50)

	struct FARPose3D GetTrackedPoseData(); // Function AugmentedReality.ARTrackedPose.GetTrackedPoseData // (None) // @ game+0xffffc546df830041
};

// Class AugmentedReality.ARMeshGeometry
// Size: 0x160 (Inherited: 0x160)
struct UARMeshGeometry : UARTrackedGeometry {
	struct FGuid UniqueId; // 0x28(0x10)
	struct FTransform LocalToTrackingTransform; // 0x40(0x60)
	struct FTransform LocalToAlignedTrackingTransform; // 0xa0(0x60)
	enum class EARTrackingState TrackingState; // 0x100(0x01)
	struct UMRMeshComponent* UnderlyingMesh; // 0x110(0x08)
	enum class EARObjectClassification ObjectClassification; // 0x118(0x01)
	enum class EARSpatialMeshUsageFlags SpatialMeshUsageFlags; // 0x119(0x01)
	int32_t LastUpdateFrameNumber; // 0x130(0x04)
	struct FName DebugName; // 0x140(0x08)

	bool GetObjectClassificationAtLocation(struct FVector& InWorldLocation, enum class EARObjectClassification& OutClassification, struct FVector& OutClassificationLocation, float MaxLocationDiff); // Function AugmentedReality.ARMeshGeometry.GetObjectClassificationAtLocation // (None) // @ game+0xffffc547df830041
};

// Class AugmentedReality.ARGeoAnchor
// Size: 0x170 (Inherited: 0x160)
struct UARGeoAnchor : UARTrackedGeometry {
	struct FGuid UniqueId; // 0x28(0x10)
	struct FTransform LocalToTrackingTransform; // 0x40(0x60)
	struct FTransform LocalToAlignedTrackingTransform; // 0xa0(0x60)
	enum class EARTrackingState TrackingState; // 0x100(0x01)
	struct UMRMeshComponent* UnderlyingMesh; // 0x110(0x08)
	enum class EARObjectClassification ObjectClassification; // 0x118(0x01)
	enum class EARSpatialMeshUsageFlags SpatialMeshUsageFlags; // 0x119(0x01)
	int32_t LastUpdateFrameNumber; // 0x130(0x04)
	struct FName DebugName; // 0x140(0x08)

	float GetLongitude(); // Function AugmentedReality.ARGeoAnchor.GetLongitude // (None) // @ game+0xffffc54bdf830041
};

// Class AugmentedReality.ARTrackableNotifyComponent
// Size: 0x1f0 (Inherited: 0xa0)
struct UARTrackableNotifyComponent : UActorComponent {
	struct FMulticastInlineDelegate OnAddTrackedGeometry; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnUpdateTrackedGeometry; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnRemoveTrackedGeometry; // 0xc0(0x10)
	struct FMulticastInlineDelegate OnAddTrackedPlane; // 0xd0(0x10)
	struct FMulticastInlineDelegate OnUpdateTrackedPlane; // 0xe0(0x10)
	struct FMulticastInlineDelegate OnRemoveTrackedPlane; // 0xf0(0x10)
	struct FMulticastInlineDelegate OnAddTrackedPoint; // 0x100(0x10)
	struct FMulticastInlineDelegate OnUpdateTrackedPoint; // 0x110(0x10)
	struct FMulticastInlineDelegate OnRemoveTrackedPoint; // 0x120(0x10)
	struct FMulticastInlineDelegate OnAddTrackedImage; // 0x130(0x10)
	struct FMulticastInlineDelegate OnUpdateTrackedImage; // 0x140(0x10)
	struct FMulticastInlineDelegate OnRemoveTrackedImage; // 0x150(0x10)
	struct FMulticastInlineDelegate OnAddTrackedFace; // 0x160(0x10)
	struct FMulticastInlineDelegate OnUpdateTrackedFace; // 0x170(0x10)
	struct FMulticastInlineDelegate OnRemoveTrackedFace; // 0x180(0x10)
	struct FMulticastInlineDelegate OnAddTrackedEnvProbe; // 0x190(0x10)
	struct FMulticastInlineDelegate OnUpdateTrackedEnvProbe; // 0x1a0(0x10)
	struct FMulticastInlineDelegate OnRemoveTrackedEnvProbe; // 0x1b0(0x10)
	struct FMulticastInlineDelegate OnAddTrackedObject; // 0x1c0(0x10)
	struct FMulticastInlineDelegate OnUpdateTrackedObject; // 0x1d0(0x10)
	struct FMulticastInlineDelegate OnRemoveTrackedObject; // 0x1e0(0x10)
};

// Class AugmentedReality.ARTypesDummyClass
// Size: 0x28 (Inherited: 0x28)
struct UARTypesDummyClass : UObject {
};

// Class AugmentedReality.ARCandidateImage
// Size: 0x58 (Inherited: 0x30)
struct UARCandidateImage : UDataAsset {
	struct UTexture2D* CandidateTexture; // 0x30(0x08)
	struct FString FriendlyName; // 0x38(0x10)
	float Width; // 0x48(0x04)
	float Height; // 0x4c(0x04)
	enum class EARCandidateImageOrientation Orientation; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)

	float GetPhysicalWidth(); // Function AugmentedReality.ARCandidateImage.GetPhysicalWidth // (None) // @ game+0xffffc550df830041
};

// Class AugmentedReality.ARCandidateObject
// Size: 0x88 (Inherited: 0x30)
struct UARCandidateObject : UDataAsset {
	struct TArray<char> CandidateObjectData; // 0x30(0x10)
	struct FString FriendlyName; // 0x40(0x10)
	struct FBox BoundingBox; // 0x50(0x38)

	void SetFriendlyName(struct FString NewName); // Function AugmentedReality.ARCandidateObject.SetFriendlyName // (None) // @ game+0xffffc556df830041
};

