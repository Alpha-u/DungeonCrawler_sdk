// Class DungeonCrawlerMessageRuntime.BaseObject
// Size: 0xc8 (Inherited: 0x28)
struct UBaseObject : UObject {
	char pad_28[0x50]; // 0x28(0x50)
	struct TMap<struct FString, struct FBindMsgNodeArray> MsgMulticastDelegateBlueprintMap; // 0x78(0x50)
};

// Class DungeonCrawlerMessageRuntime.BaseInterface
// Size: 0x28 (Inherited: 0x28)
struct UBaseInterface : UInterface {

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawlerMessageRuntime.BaseInterface.UnbindMsgAll // (None) // @ game+0xffffaf89df830041
};

// Class DungeonCrawlerMessageRuntime.MsgBaseNode
// Size: 0x70 (Inherited: 0x30)
struct UMsgBaseNode : UCancellableAsyncAction {
	struct FMulticastInlineDelegate OnMessageReceived; // 0x30(0x10)
	char pad_40[0x30]; // 0x40(0x30)

	void ReplyMsg(int32_t& InMsg); // Function DungeonCrawlerMessageRuntime.MsgBaseNode.ReplyMsg // (None) // @ game+0xffffaf8bdf830041
};

// Class DungeonCrawlerMessageRuntime.BindMsgNode
// Size: 0x70 (Inherited: 0x70)
struct UBindMsgNode : UMsgBaseNode {
	struct FMulticastInlineDelegate OnMessageReceived; // 0x30(0x10)

	struct UBindMsgNode* BindMsgNode(struct UObject* Owner, struct UScriptStruct* RecvMsgType, struct TScriptInterface<IBaseInterface> BaseInterface); // Function DungeonCrawlerMessageRuntime.BindMsgNode.BindMsgNode // (None) // @ game+0xffffaf8cdf830041
};

// Class DungeonCrawlerMessageRuntime.BroadcastMsgNode
// Size: 0x70 (Inherited: 0x70)
struct UBroadcastMsgNode : UMsgBaseNode {
	struct FMulticastInlineDelegate OnMessageReceived; // 0x30(0x10)

	struct UBroadcastMsgNode* BroadcastMsgNode(struct UObject* Owner, struct UScriptStruct* RecvMsgType, struct TScriptInterface<IBaseInterface> BaseInterface); // Function DungeonCrawlerMessageRuntime.BroadcastMsgNode.BroadcastMsgNode // (None) // @ game+0xffffaf8edf830041
};

