// BlueprintGeneratedClass BTT_SkillOnWhileState.BTT_SkillOnWhileState_C
// Size: 0x148 (Inherited: 0xa8)
struct UBTT_SkillOnWhileState_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	bool Get Variables From MonsterBP; // 0xb0(0x01)
	enum class E_BTActionsFromMonsterBP Select Action; // 0xb1(0x01)
	char pad_B2[0x6]; // 0xb2(0x06)
	struct FBlackboardKeySelector TargetActor; // 0xb8(0x28)
	struct TArray<struct FGameplayTag> AbilityTags; // 0xe0(0x10)
	struct TArray<int32_t> AbilityRates; // 0xf0(0x10)
	bool WaitState; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct TArray<struct FGameplayTag> WaitStateTags; // 0x108(0x10)
	int32_t Ability Tags Count; // 0x118(0x04)
	int32_t Rate; // 0x11c(0x04)
	struct FGameplayTag AbilityTag; // 0x120(0x08)
	struct FGameplayTag WaitStateTag; // 0x128(0x08)
	int32_t WaitTagsCount; // 0x130(0x04)
	int32_t RateTemp; // 0x134(0x04)
	struct ABP_DCMonsterBaseWithOptions_C* Controlled Pawn; // 0x138(0x08)
	struct UDCAnimInstanceBase* As DCAnim Instance Base; // 0x140(0x08)

	void Removed_241FC3634545136A0308048C3368EF5F(); // Function BTT_SkillOnWhileState.BTT_SkillOnWhileState_C.Removed_241FC3634545136A0308048C3368EF5F // (None) // @ game+0x1527cdfab0001
};

