// Class AudioWidgets.AudioMeter
// Size: 0x6d0 (Inherited: 0x150)
struct UAudioMeter : UWidget {
	struct TArray<struct FMeterChannelInfo> MeterChannelInfo; // 0x150(0x10)
	struct FDelegate MeterChannelInfoDelegate; // 0x160(0x10)
	struct FAudioMeterStyle WidgetStyle; // 0x170(0x4d0)
	enum class EOrientation Orientation; // 0x640(0x01)
	char pad_641[0x3]; // 0x641(0x03)
	struct FLinearColor BackgroundColor; // 0x644(0x10)
	struct FLinearColor MeterBackgroundColor; // 0x654(0x10)
	struct FLinearColor MeterValueColor; // 0x664(0x10)
	struct FLinearColor MeterPeakColor; // 0x674(0x10)
	struct FLinearColor MeterClippingColor; // 0x684(0x10)
	struct FLinearColor MeterScaleColor; // 0x694(0x10)
	struct FLinearColor MeterScaleLabelColor; // 0x6a4(0x10)
	char pad_6B4[0x1c]; // 0x6b4(0x1c)

	void SetMeterValueColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterValueColor // (None) // @ game+0xffff9795df830041
};

// Class AudioWidgets.AudioRadialSlider
// Size: 0x370 (Inherited: 0x150)
struct UAudioRadialSlider : UWidget {
	float Value; // 0x150(0x04)
	struct FDelegate ValueDelegate; // 0x154(0x10)
	enum class EAudioRadialSliderLayout WidgetLayout; // 0x164(0x01)
	char pad_165[0x3]; // 0x165(0x03)
	struct FLinearColor CenterBackgroundColor; // 0x168(0x10)
	struct FLinearColor SliderProgressColor; // 0x178(0x10)
	struct FLinearColor SliderBarColor; // 0x188(0x10)
	struct FVector2D HandStartEndRatio; // 0x198(0x10)
	struct FText UnitsText; // 0x1a8(0x18)
	struct FLinearColor TextLabelBackgroundColor; // 0x1c0(0x10)
	bool ShowLabelOnlyOnHover; // 0x1d0(0x01)
	bool ShowUnitsText; // 0x1d1(0x01)
	bool IsUnitsTextReadOnly; // 0x1d2(0x01)
	bool IsValueTextReadOnly; // 0x1d3(0x01)
	float SliderThickness; // 0x1d4(0x04)
	struct FVector2D OutputRange; // 0x1d8(0x10)
	struct FMulticastInlineDelegate OnValueChanged; // 0x1e8(0x10)
	char pad_1F8[0x178]; // 0x1f8(0x178)

	void SetWidgetLayout(enum class EAudioRadialSliderLayout InLayout); // Function AudioWidgets.AudioRadialSlider.SetWidgetLayout // (None) // @ game+0xffffb88edf830041
};

// Class AudioWidgets.AudioVolumeRadialSlider
// Size: 0x370 (Inherited: 0x370)
struct UAudioVolumeRadialSlider : UAudioRadialSlider {
	float Value; // 0x150(0x04)
	struct FDelegate ValueDelegate; // 0x154(0x10)
	enum class EAudioRadialSliderLayout WidgetLayout; // 0x164(0x01)
	struct FLinearColor CenterBackgroundColor; // 0x168(0x10)
	struct FLinearColor SliderProgressColor; // 0x178(0x10)
	struct FLinearColor SliderBarColor; // 0x188(0x10)
	struct FVector2D HandStartEndRatio; // 0x198(0x10)
	struct FText UnitsText; // 0x1a8(0x18)
	struct FLinearColor TextLabelBackgroundColor; // 0x1c0(0x10)
	bool ShowLabelOnlyOnHover; // 0x1d0(0x01)
	bool ShowUnitsText; // 0x1d1(0x01)
	bool IsUnitsTextReadOnly; // 0x1d2(0x01)
	bool IsValueTextReadOnly; // 0x1d3(0x01)
	float SliderThickness; // 0x1d4(0x04)
	struct FVector2D OutputRange; // 0x1d8(0x10)
	struct FMulticastInlineDelegate OnValueChanged; // 0x1e8(0x10)
};

// Class AudioWidgets.AudioFrequencyRadialSlider
// Size: 0x370 (Inherited: 0x370)
struct UAudioFrequencyRadialSlider : UAudioRadialSlider {
	float Value; // 0x150(0x04)
	struct FDelegate ValueDelegate; // 0x154(0x10)
	enum class EAudioRadialSliderLayout WidgetLayout; // 0x164(0x01)
	struct FLinearColor CenterBackgroundColor; // 0x168(0x10)
	struct FLinearColor SliderProgressColor; // 0x178(0x10)
	struct FLinearColor SliderBarColor; // 0x188(0x10)
	struct FVector2D HandStartEndRatio; // 0x198(0x10)
	struct FText UnitsText; // 0x1a8(0x18)
	struct FLinearColor TextLabelBackgroundColor; // 0x1c0(0x10)
	bool ShowLabelOnlyOnHover; // 0x1d0(0x01)
	bool ShowUnitsText; // 0x1d1(0x01)
	bool IsUnitsTextReadOnly; // 0x1d2(0x01)
	bool IsValueTextReadOnly; // 0x1d3(0x01)
	float SliderThickness; // 0x1d4(0x04)
	struct FVector2D OutputRange; // 0x1d8(0x10)
	struct FMulticastInlineDelegate OnValueChanged; // 0x1e8(0x10)
};

// Class AudioWidgets.AudioSliderBase
// Size: 0x9a0 (Inherited: 0x150)
struct UAudioSliderBase : UWidget {
	float Value; // 0x150(0x04)
	char pad_154[0x4]; // 0x154(0x04)
	struct FText UnitsText; // 0x158(0x18)
	struct FLinearColor TextLabelBackgroundColor; // 0x170(0x10)
	struct FDelegate TextLabelBackgroundColorDelegate; // 0x180(0x10)
	bool ShowLabelOnlyOnHover; // 0x190(0x01)
	bool ShowUnitsText; // 0x191(0x01)
	bool IsUnitsTextReadOnly; // 0x192(0x01)
	bool IsValueTextReadOnly; // 0x193(0x01)
	struct FDelegate ValueDelegate; // 0x194(0x10)
	struct FLinearColor SliderBackgroundColor; // 0x1a4(0x10)
	struct FDelegate SliderBackgroundColorDelegate; // 0x1b4(0x10)
	struct FLinearColor SliderBarColor; // 0x1c4(0x10)
	struct FDelegate SliderBarColorDelegate; // 0x1d4(0x10)
	struct FLinearColor SliderThumbColor; // 0x1e4(0x10)
	struct FDelegate SliderThumbColorDelegate; // 0x1f4(0x10)
	struct FLinearColor WidgetBackgroundColor; // 0x204(0x10)
	struct FDelegate WidgetBackgroundColorDelegate; // 0x214(0x10)
	enum class EOrientation Orientation; // 0x224(0x01)
	char pad_225[0x3]; // 0x225(0x03)
	struct FMulticastInlineDelegate OnValueChanged; // 0x228(0x10)
	char pad_238[0x768]; // 0x238(0x768)

	void SetWidgetBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioSliderBase.SetWidgetBackgroundColor // (None) // @ game+0xffffb89bdf830041
};

// Class AudioWidgets.AudioSlider
// Size: 0x9b0 (Inherited: 0x9a0)
struct UAudioSlider : UAudioSliderBase {
	struct TWeakObjectPtr<struct UCurveFloat> LinToOutputCurve; // 0x9a0(0x08)
	struct TWeakObjectPtr<struct UCurveFloat> OutputToLinCurve; // 0x9a8(0x08)
};

// Class AudioWidgets.AudioVolumeSlider
// Size: 0x9b0 (Inherited: 0x9b0)
struct UAudioVolumeSlider : UAudioSlider {
	struct TWeakObjectPtr<struct UCurveFloat> LinToOutputCurve; // 0x9a0(0x08)
	struct TWeakObjectPtr<struct UCurveFloat> OutputToLinCurve; // 0x9a8(0x08)
};

// Class AudioWidgets.AudioFrequencySlider
// Size: 0x9b0 (Inherited: 0x9a0)
struct UAudioFrequencySlider : UAudioSliderBase {
	struct FVector2D OutputRange; // 0x9a0(0x10)
};

