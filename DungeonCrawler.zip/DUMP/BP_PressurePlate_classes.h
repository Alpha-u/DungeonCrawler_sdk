// BlueprintGeneratedClass BP_PressurePlate.BP_PressurePlate_C
// Size: 0x4bc (Inherited: 0x4a8)
struct ABP_PressurePlate_C : ABP_TriggerBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4a8(0x08)
	struct UBoxComponent* ActiveBox; // 0x4b0(0x08)
	int32_t Count; // 0x4b8(0x04)

	void BndEvt__BP_FloorSpikeTrap_ActiveBox_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_PressurePlate.BP_PressurePlate_C.BndEvt__BP_FloorSpikeTrap_ActiveBox_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature // (None) // @ game+0xffff82075b8c53a0
};

