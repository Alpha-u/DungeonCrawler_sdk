// BlueprintGeneratedClass BP_DCPlayerController.BP_DCPlayerController_C
// Size: 0xa88 (Inherited: 0xa28)
struct ABP_DCPlayerController_C : ADCPlayerController {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa28(0x08)
	struct UBP_VoipAkComponent_C* SendVoipAkComponent; // 0xa30(0x08)
	struct UDCAkComponent* DCAk; // 0xa38(0x08)
	struct UBP_GameVoipComponent_C* GameVoipComponent; // 0xa40(0x08)
	struct UDCContextComponent* DCContext; // 0xa48(0x08)
	struct UDCCustomizeComponent* DCCustomize; // 0xa50(0x08)
	struct UDCPlayerChatComponent* DCPlayerChat; // 0xa58(0x08)
	struct UGameTestComponent* GameTest; // 0xa60(0x08)
	struct UItemMoveValidatorComponent* ItemMoveValidator; // 0xa68(0x08)
	enum class EInventoryType MovedItemInventoryType; // 0xa70(0x01)
	char pad_A71[0x7]; // 0xa71(0x07)
	struct TArray<struct AActor*> PlayerFootprintArray; // 0xa78(0x10)

	void OnLoadSoundData(struct UObject* Object); // Function BP_DCPlayerController.BP_DCPlayerController_C.OnLoadSoundData // (NetRequest|Exec|Event|NetResponse|Static|UbergraphFunction|MulticastDelegate|Public|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|EditorOnly|NetValidate) // @ game+0xffff8009df830000
};

