// BlueprintGeneratedClass BP_SimpleChestMedium_N1.BP_SimpleChestMedium_N1_C
// Size: 0x538 (Inherited: 0x520)
struct ABP_SimpleChestMedium_N1_C : ABP_Chest_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x520(0x08)
	struct UDCGeometryCollectionComponent* GC_WoodChestSmall_Default; // 0x528(0x08)
	struct UDCGeometryCollectionComponent* GC_WoodChestSmall_Open; // 0x530(0x08)

	void ReceiveBeginPlay(); // Function BP_SimpleChestMedium_N1.BP_SimpleChestMedium_N1_C.ReceiveBeginPlay // (None) // @ game+0xffff8009df830000
};

