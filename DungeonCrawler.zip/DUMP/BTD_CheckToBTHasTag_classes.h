// BlueprintGeneratedClass BTD_CheckToBTHasTag.BTD_CheckToBTHasTag_C
// Size: 0xd0 (Inherited: 0xa0)
struct UBTD_CheckToBTHasTag_C : UBTDecorator_BlueprintBase {
	enum class E_BTActionsFromMonsterBP BT Action To Check; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)
	struct ABP_DCMonsterBaseWithOptions_C* As BP DCMonster Base With Options; // 0xa8(0x08)
	struct FGameplayTagContainer Check Tags; // 0xb0(0x20)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_CheckToBTHasTag.BTD_CheckToBTHasTag_C.PerformConditionCheckAI // (None) // @ game+0xffff8009df830000
};

