// BlueprintGeneratedClass BP_TriggerBase.BP_TriggerBase_C
// Size: 0x4a8 (Inherited: 0x488)
struct ABP_TriggerBase_C : ABP_PropsActorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x488(0x08)
	struct UDCGameObjectLinkComponent* DCGameObjectLink; // 0x490(0x08)
	struct UDCSkeletalMeshComponent* DCSkeletalMesh; // 0x498(0x08)
	struct FGameplayTag AbilityTriggerTag; // 0x4a0(0x08)

	void InteractSucceed(struct AActor* Interacter, struct FGameplayTag StateTag, struct FGameplayTag TriggerTag, struct FHitResult HitResult); // Function BP_TriggerBase.BP_TriggerBase_C.InteractSucceed // (None) // @ game+0x18bd3dfab0000
};

