// BlueprintGeneratedClass BP_Roaster05On.BP_Roaster05On_C
// Size: 0x4c8 (Inherited: 0x488)
struct ABP_Roaster05On_C : ABP_LightSourceBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x488(0x08)
	struct UPointLightComponent* PointLight1; // 0x490(0x08)
	struct UStaticMeshComponent* Roaster; // 0x498(0x08)
	struct UParticleSystemComponent* ParticleSystem; // 0x4a0(0x08)
	float Timeline_1______0_37213880460A36829B90169A8BD8554D; // 0x4a8(0x04)
	enum class ETimelineDirection Timeline_1__Direction_37213880460A36829B90169A8BD8554D; // 0x4ac(0x01)
	char pad_4AD[0x3]; // 0x4ad(0x03)
	struct UTimelineComponent* Timeline_2; // 0x4b0(0x08)
	float _____0______0_06C026FE438FC94A22C8AC93C349A2D2; // 0x4b8(0x04)
	enum class ETimelineDirection _____0__Direction_06C026FE438FC94A22C8AC93C349A2D2; // 0x4bc(0x01)
	char pad_4BD[0x3]; // 0x4bd(0x03)
	struct UTimelineComponent*  �� _1; // 0x4c0(0x08)

	void  ��임라인_0__Fini(); // Function BP_Roaster05On.BP_Roaster05On_C. ��임라인_0__Fini // (None) // @ game+0x15501dfab0001
};

