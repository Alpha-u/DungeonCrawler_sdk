// BlueprintGeneratedClass BP_ProjectileToSpawnItemHolder.BP_ProjectileToSpawnItemHolder_C
// Size: 0x6c0 (Inherited: 0x6b0)
struct ABP_ProjectileToSpawnItemHolder_C : ABP_ProjectileActor_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x6b0(0x08)
	struct ABP_PhysicalItemHolder_C* ItemHolderToSpawn; // 0x6b8(0x08)

	void ProjectileHit(struct FHitResult& Hit, bool bIsAttached, struct FTransform& ActorPrevTickTransform); // Function BP_ProjectileToSpawnItemHolder.BP_ProjectileToSpawnItemHolder_C.ProjectileHit // (None) // @ game+0x13225dfab0001
};

