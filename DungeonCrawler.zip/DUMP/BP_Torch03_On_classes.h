// BlueprintGeneratedClass BP_Torch03_On.BP_Torch03_On_C
// Size: 0x4d1 (Inherited: 0x488)
struct ABP_Torch03_On_C : ABP_LightSourceBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x488(0x08)
	struct USphereComponent* Sphere; // 0x490(0x08)
	struct UParticleSystemComponent* ParticleSystem; // 0x498(0x08)
	struct UPointLightComponent* PointLight1; // 0x4a0(0x08)
	struct UStaticMeshComponent* Torch; // 0x4a8(0x08)
	float Timeline_1______0_A84C0CB64108A3789B3807B83D99D19E; // 0x4b0(0x04)
	enum class ETimelineDirection Timeline_1__Direction_A84C0CB64108A3789B3807B83D99D19E; // 0x4b4(0x01)
	char pad_4B5[0x3]; // 0x4b5(0x03)
	struct UTimelineComponent* Timeline_2; // 0x4b8(0x08)
	float Timeline_0______0_CFB41F8244390F5FD25911956C55FB90; // 0x4c0(0x04)
	enum class ETimelineDirection Timeline_0__Direction_CFB41F8244390F5FD25911956C55FB90; // 0x4c4(0x01)
	char pad_4C5[0x3]; // 0x4c5(0x03)
	struct UTimelineComponent* Timeline_1; // 0x4c8(0x08)
	bool bIsOverlapped; // 0x4d0(0x01)

	void Timeline_0__FinishedFunc(); // Function BP_Torch03_On.BP_Torch03_On_C.Timeline_0__FinishedFunc // (None) // @ game+0x119c5dfab0001
};

