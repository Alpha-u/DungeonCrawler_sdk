// BlueprintGeneratedClass BP_TorchProjectileBase.BP_TorchProjectileBase_C
// Size: 0x6f0 (Inherited: 0x6c0)
struct ABP_TorchProjectileBase_C : ABP_ProjectileToSpawnItemHolder_C {
	struct UPointLightComponent* PointLightFire; // 0x6c0(0x08)
	struct UPointLightComponent* PointLight; // 0x6c8(0x08)
	struct URotatingMovementComponent* RotatingMovement; // 0x6d0(0x08)
	struct FRotator RepRotation; // 0x6d8(0x18)

	void OnRep_RepRotation(); // Function BP_TorchProjectileBase.BP_TorchProjectileBase_C.OnRep_RepRotation // (None) // @ game+0xffff8009df830000
};

