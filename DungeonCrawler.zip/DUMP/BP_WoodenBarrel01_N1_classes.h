// BlueprintGeneratedClass BP_WoodenBarrel01_N1.BP_WoodenBarrel01_N1_C
// Size: 0x4b0 (Inherited: 0x488)
struct ABP_WoodenBarrel01_N1_C : ABP_PropsActorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x488(0x08)
	struct UDCGeometryCollectionComponent* GC_WoodenBarrel_Default; // 0x490(0x08)
	struct UExpandableInventoryComponent* ExpandableInventory; // 0x498(0x08)
	struct UItemRandomGenerateComponent* ItemRandomGenerate; // 0x4a0(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x4a8(0x08)

	void BndEvt__BP_ChestBase_ItemRandomGenerate_K2Node_ComponentBoundEvent_0_ItemGenerationFinishedSignature__DelegateSignature(struct TArray<struct FItemData>& ResultItems); // Function BP_WoodenBarrel01_N1.BP_WoodenBarrel01_N1_C.BndEvt__BP_ChestBase_ItemRandomGenerate_K2Node_ComponentBoundEvent_0_ItemGenerationFinishedSignature__DelegateSignature // (None) // @ game+0xeb36df8512b4
};

