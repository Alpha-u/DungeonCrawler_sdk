// BlueprintGeneratedClass GA_DCRest.GA_DCRest_C
// Size: 0x5d4 (Inherited: 0x558)
struct UGA_DCRest_C : UDCGameplayAbilityBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x558(0x08)
	bool bIsRestEnded; // 0x560(0x01)
	char pad_561[0x7]; // 0x561(0x07)
	struct FGameplayTagContainer Input Config Tags; // 0x568(0x20)
	struct FPrimaryAssetId SpellRechargeDefaultAmount; // 0x588(0x10)
	struct FPrimaryAssetId SkillRechargeDefaultAmount; // 0x598(0x10)
	struct UAnimMontage* MontageToPlay; // 0x5a8(0x08)
	struct FPrimaryAssetId SpellRechargeInCampfireAmount; // 0x5b0(0x10)
	struct FPrimaryAssetId SkillRechargeInCampfireAmount; // 0x5c0(0x10)
	int32_t SkillRechargeInCampfireArea; // 0x5d0(0x04)

	void GetSkillRechargeAmount(int32_t& RechargeAmount); // Function GA_DCRest.GA_DCRest_C.GetSkillRechargeAmount // (NetRequest|NetResponse|Static|NetMulticast|UbergraphFunction|Private|Delegate|HasDefaults|DLLImport|BlueprintEvent|Const|NetValidate) // @ game+0xffff8009df830000
};

