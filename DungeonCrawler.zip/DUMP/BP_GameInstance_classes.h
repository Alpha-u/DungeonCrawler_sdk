// BlueprintGeneratedClass BP_GameInstance.BP_GameInstance_C
// Size: 0x3b0 (Inherited: 0x3a0)
struct UBP_GameInstance_C : UDCGameInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3a0(0x08)
	struct UAkAudioEvent* Ak Event; // 0x3a8(0x08)

	void ReceiveInit(); // Function BP_GameInstance.BP_GameInstance_C.ReceiveInit // (None) // @ game+0xffff8009df830000
};

