// BlueprintGeneratedClass BTT_GetTargetNonPlayable.BTT_GetTargetNonPlayable_C
// Size: 0xc8 (Inherited: 0xa8)
struct UBTT_GetTargetNonPlayable_C : UBTT_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct TArray<struct AActor*> Out Actors; // 0xb0(0x10)
	struct UObject* Actor Class Filter; // 0xc0(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_GetTargetNonPlayable.BTT_GetTargetNonPlayable_C.ReceiveExecuteAI // (None) // @ game+0x143c7dfab0001
};

