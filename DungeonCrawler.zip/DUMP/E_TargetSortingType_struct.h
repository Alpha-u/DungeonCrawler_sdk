// UserDefinedEnum E_TargetSortingType.E_TargetSortingType
enum class E_TargetSortingType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator3 = 3,
	E_MAX = 4
};

