// BlueprintGeneratedClass BP_ChainLightningActor.BP_ChainLightningActor_C
// Size: 0x410 (Inherited: 0x410)
struct ABP_ChainLightningActor_C : ABP_SpellActor_C {
	struct USceneComponent* DefaultSceneRoot; // 0x408(0x08)
};

