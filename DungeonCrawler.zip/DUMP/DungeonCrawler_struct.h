// Enum DungeonCrawler.EInventoryType
enum class EInventoryType : uint8 {
	None = 0,
	Chest = 1,
	Bag = 2,
	Equipment = 3,
	Storage = 4,
	StockBuy = 5,
	StockSellBack = 6,
	StockCraft = 7,
	DealTable = 8,
	EInventoryType_MAX = 9
};

// Enum DungeonCrawler.EAoeFilterSortingType
enum class EAoeFilterSortingType : uint8 {
	Ascending = 0,
	Desending = 1,
	EAoeFilterSortingType_MAX = 2
};

// Enum DungeonCrawler.EDCChatChannelType
enum class EDCChatChannelType : uint8 {
	None = 0,
	Recruit = 1,
	EDCChatChannelType_MAX = 2
};

// Enum DungeonCrawler.EDCPagingState
enum class EDCPagingState : uint8 {
	None = 0,
	Begin = 1,
	Progress = 2,
	End = 3,
	EDCPagingState_MAX = 4
};

// Enum DungeonCrawler.EServerLocation
enum class EServerLocation : uint8 {
	None = 0,
	Local = 1,
	QA = 2,
	PlayTest = 3,
	NA = 4,
	EServerLocation_MAX = 5
};

// Enum DungeonCrawler.EMetaState
enum class EMetaState : uint8 {
	None = 0,
	Login = 1,
	CharacterSelect = 2,
	Lobby = 3,
	InGame = 4,
	EMetaState_MAX = 5
};

// Enum DungeonCrawler.EServicePolicyType
enum class EServicePolicyType : uint8 {
	None = 0,
	ChatMaxLength = 1,
	ChatResendTime = 2,
	ChatMaxLine = 3,
	TradeChannelChatResendTime = 4,
	TradeChannelChatMaxLine = 5,
	HighRollerEntraceFeeGold = 6,
	HighRollerEntraceMinLevel = 7,
	MatchCancelDelayTime = 8,
	RecruitChannelChatSendCooldownSeconds = 9,
	RecruitChannelNumChatLogMax = 10,
	RecruitChannelJoinMinLevel = 11,
	EServicePolicyType_MAX = 12
};

// Enum DungeonCrawler.ETradeState
enum class ETradeState : uint8 {
	None = 0,
	TradeChannel = 1,
	Trading = 2,
	TradingConfirm = 3,
	ETradeState_MAX = 4
};

// Enum DungeonCrawler.EContextOptionType
enum class EContextOptionType : uint8 {
	None = 0,
	TradeRequest = 1,
	Whisper = 2,
	Block = 3,
	Equip = 4,
	Unequip = 5,
	KickPartyMember = 6,
	InvitePartyMember = 7,
	Unblock = 8,
	Inspect = 9,
	EContextOptionType_MAX = 10
};

// Enum DungeonCrawler.EAccountLinkType
enum class EAccountLinkType : uint8 {
	Static = 0,
	PlayerController = 1,
	PlayerPawn = 2,
	Dynamic = 3,
	EAccountLinkType_MAX = 4
};

// Enum DungeonCrawler.EAccountLinkFlag
enum class EAccountLinkFlag : uint8 {
	None = 0,
	AccountSessionData = 1,
	Attribute = 2,
	GameplayTag = 4,
	ActorStatus = 8,
	Inventory = 16,
	Perk = 32,
	Skill = 64,
	PartySessionData = 128,
	EAccountLinkFlag_MAX = 129
};

// Enum DungeonCrawler.EGameplayEffectType
enum class EGameplayEffectType : uint8 {
	MMC = 0,
	MMCSimple = 1,
	InfiniteTagOnly = 2,
	DurationTagOnly = 3,
	EGameplayEffectType_MAX = 4
};

// Enum DungeonCrawler.EGameplayEffectTargetType
enum class EGameplayEffectTargetType : uint8 {
	Owner = 0,
	EventData = 1,
	EGameplayEffectTargetType_MAX = 2
};

// Enum DungeonCrawler.EItemType
enum class EItemType : uint8 {
	None = 0,
	Weapon = 1,
	Armor = 2,
	Utility = 3,
	Accessory = 4,
	Misc = 5,
	EItemType_MAX = 6
};

// Enum DungeonCrawler.EItemRequirementType
enum class EItemRequirementType : uint8 {
	Class = 0,
	Strength = 1,
	Agility = 2,
	Will = 3,
	Knowledge = 4,
	Resourceful = 5,
	Perk = 6,
	EItemRequirementType_MAX = 7
};

// Enum DungeonCrawler.EDCCharacterClass
enum class EDCCharacterClass : uint8 {
	None = 0,
	Wizard = 1,
	Rogue = 2,
	Ranger = 3,
	Fighter = 4,
	Cleric = 5,
	Barbarian = 6,
	Bard = 7,
	Warlock = 8,
	EDCCharacterClass_MAX = 9
};

// Enum DungeonCrawler.EDCGender
enum class EDCGender : uint8 {
	None = 0,
	Man = 1,
	Woman = 2,
	EDCGender_MAX = 3
};

// Enum DungeonCrawler.EChatSetType
enum class EChatSetType : uint8 {
	None = 0,
	TradeChannel = 1,
	TradePrivate = 2,
	Party = 3,
	EChatSetType_MAX = 4
};

// Enum DungeonCrawler.EChatType
enum class EChatType : uint8 {
	None = 0,
	Normal = 1,
	Whisper = 2,
	EChatType_MAX = 3
};

// Enum DungeonCrawler.EChatWidgetType
enum class EChatWidgetType : uint8 {
	None = 0,
	System = 1,
	Normal = 2,
	Mine = 3,
	WhisperFrom = 4,
	WhisperTo = 5,
	Party = 6,
	EChatWidgetType_MAX = 7
};

// Enum DungeonCrawler.EDCMorphTarget
enum class EDCMorphTarget : uint8 {
	None = 0,
	WomanFrontHair = 1,
	FrontHair = 2,
	MidHair = 3,
	BackHair = 4,
	Beard = 5,
	UnderHair = 6,
	Ear = 7,
	GlovesEquipped = 8,
	ShortGlovesEquipped = 9,
	HelmetEquipped = 10,
	BootsEquipped = 11,
	EDCMorphTarget_MAX = 12
};

// Enum DungeonCrawler.EChatRoomCategoryType
enum class EChatRoomCategoryType : uint8 {
	None = 0,
	GatheringHall = 1,
	Trade_WeaponArmor = 2,
	Trade_UtilityAccessory = 3,
	Trade_Misc = 4,
	EChatRoomCategoryType_MAX = 5
};

// Enum DungeonCrawler.EAbilityDataAssetType
enum class EAbilityDataAssetType : uint8 {
	AbilityData_Skill = 0,
	AbilityData_Spell = 1,
	AbilityData_Perk = 2,
	AbilityData_Music = 3,
	AbilityData_MAX = 4
};

// Enum DungeonCrawler.EAbilityDataAssetOption
enum class EAbilityDataAssetOption : uint8 {
	CastingTime = 0,
	ChannelingTime = 1,
	ChannelingInterval = 2,
	Range = 3,
	EAbilityDataAssetOption_MAX = 4
};

// Enum DungeonCrawler.EDesignDataConstantType
enum class EDesignDataConstantType : uint8 {
	NONE = 0,
	ADD = 1,
	MUTIPLY = 2,
	MUTIPLY_PERCENTAGE_ONE = 3,
	MUTIPLY_PERCENTAGE_ZERO = 4,
	EDesignDataConstantType_MAX = 5
};

// Enum DungeonCrawler.EDCActionSkinType
enum class EDCActionSkinType : uint8 {
	None = 0,
	Rest = 1,
	EDCActionSkinType_MAX = 2
};

// Enum DungeonCrawler.EHitBoxType
enum class EHitBoxType : uint8 {
	None = 0,
	Head = 1,
	Body = 2,
	Arm = 3,
	Leg = 4,
	Hand = 5,
	Foot = 6,
	EHitBoxType_MAX = 7
};

// Enum DungeonCrawler.EHitDirection
enum class EHitDirection : uint8 {
	None = 0,
	Front = 1,
	Back = 2,
	Left = 3,
	Right = 4,
	EHitDirection_MAX = 5
};

// Enum DungeonCrawler.EDCInventoryTaskType
enum class EDCInventoryTaskType : uint8 {
	None = 0,
	Add = 1,
	AddGold = 2,
	Move = 3,
	MoveGold = 4,
	Remove = 5,
	Merge = 6,
	MergeGold = 7,
	Swap = 8,
	EDCInventoryTaskType_MAX = 9
};

// Enum DungeonCrawler.EDCValidatorTargetType
enum class EDCValidatorTargetType : uint8 {
	Add = 0,
	Merge = 1,
	EDCValidatorTargetType_MAX = 2
};

// Enum DungeonCrawler.EDCInventoryValidatorType
enum class EDCInventoryValidatorType : uint8 {
	None = 0,
	NotAllowed = 1,
	MerchantOnly = 2,
	JunkItemNotAllowed = 3,
	LockedItemNotAllowed = 4,
	EDCInventoryValidatorType_MAX = 5
};

// Enum DungeonCrawler.EDCKillReason
enum class EDCKillReason : uint8 {
	None = 0,
	Killed = 1,
	FellOutOfWorld = 2,
	OutsideWorldBounds = 3,
	FloorRuleFinished = 4,
	EDCKillReason_MAX = 5
};

// Enum DungeonCrawler.EDCLogEventType
enum class EDCLogEventType : uint8 {
	None = 0,
	PlayerKill = 1,
	DungeonDown = 2,
	MonsterKill = 3,
	PropsInteraction = 4,
	ItemAchieve = 5,
	PlayerDead = 6,
	EDCLogEventType_MAX = 7
};

// Enum DungeonCrawler.EDCLoginState
enum class EDCLoginState : uint8 {
	None = 0,
	Welcome = 1,
	InputIdAndPw = 2,
	NsLookup = 3,
	Connect = 4,
	Login = 5,
	ConfirmToReconnect = 6,
	AcceptToReconnect = 7,
	Enter = 8,
	NotifyPrevGameClosed = 9,
	EDCLoginState_MAX = 10
};

// Enum DungeonCrawler.EMonsterSpawnerType
enum class EMonsterSpawnerType : uint8 {
	Circle = 0,
	Rect = 1,
	EMonsterSpawnerType_MAX = 2
};

// Enum DungeonCrawler.EDCExitType
enum class EDCExitType : uint8 {
	None = 0,
	BackToLobby = 1,
	ExitClient = 2,
	BackToLobbyWithTerminatePopup = 3,
	ExitClientWithDetectPopup = 4,
	EDCExitType_MAX = 5
};

// Enum DungeonCrawler.EDCOnlineState
enum class EDCOnlineState : uint8 {
	None = 0,
	Online = 1,
	Disconnected = 2,
	Offline = 3,
	EDCOnlineState_MAX = 4
};

// Enum DungeonCrawler.EDCDungeonState
enum class EDCDungeonState : uint8 {
	None = 0,
	PlayingInDungeon = 1,
	Escaped = 2,
	WaitingNextFloor = 3,
	FloorMatchmaking = 4,
	EDCDungeonState_MAX = 5
};

// Enum DungeonCrawler.EDCSpectatorSearchType
enum class EDCSpectatorSearchType : uint8 {
	None = 0,
	Right = 1,
	Left = 2,
	Dead = 3,
	EDCSpectatorSearchType_MAX = 4
};

// Enum DungeonCrawler.EDCPostState
enum class EDCPostState : uint8 {
	PostStateNone = 0,
	PostStateEscaping = 1,
	PostStateEscaped = 2,
	PostStateExiting = 3,
	PostStateExited = 4,
	EDCPostState_MAX = 5
};

// Enum DungeonCrawler.EDCPreLobbyMenu
enum class EDCPreLobbyMenu : uint8 {
	None = 0,
	CreateCharacter = 1,
	SelectCharacter = 2,
	EDCPreLobbyMenu_MAX = 3
};

// Enum DungeonCrawler.EDCReportPlayerCategory
enum class EDCReportPlayerCategory : uint8 {
	None = 0,
	Cheater = 1,
	InappropriateName = 2,
	EDCReportPlayerCategory_MAX = 3
};

// Enum DungeonCrawler.EDCShopItemType
enum class EDCShopItemType : uint8 {
	None = 0,
	CharacterSkin = 1,
	ItemSkin = 2,
	Emote = 3,
	ActionSkin = 4,
	LobbyEmote = 5,
	EDCShopItemType_MAX = 6
};

// Enum DungeonCrawler.EDCPortalScrollType
enum class EDCPortalScrollType : uint8 {
	None = 0,
	Escape = 1,
	Down = 2,
	EDCPortalScrollType_MAX = 3
};

// Enum DungeonCrawler.EFunctionTriggerType
enum class EFunctionTriggerType : uint8 {
	Once = 0,
	Repeat = 1,
	EFunctionTriggerType_MAX = 2
};

// Enum DungeonCrawler.EGameStateType
enum class EGameStateType : uint8 {
	None = 0,
	FadeOut = 1,
	TavernWait = 2,
	TavernCountDown = 3,
	TavernStart = 4,
	DungeonPrepareLevel = 5,
	DungeonPrepareNPC = 6,
	DungeonPreparePC = 7,
	DungeonPlay = 8,
	DungeonNextFloor = 9,
	DungeonResult = 10,
	LobbyPrepareAccount = 11,
	LobbyStart = 12,
	EGameStateType_MAX = 13
};

// Enum DungeonCrawler.EGameDifficultyType
enum class EGameDifficultyType : uint8 {
	None = 0,
	Normal = 1,
	HighRoller = 2,
	Goblin = 3,
	EGameDifficultyType_MAX = 4
};

// Enum DungeonCrawler.EFloorLogType
enum class EFloorLogType : uint8 {
	None = 0,
	EscapePortal = 1,
	DownPortal = 2,
	Escape = 3,
	Down = 4,
	EFloorLogType_MAX = 5
};

// Enum DungeonCrawler.EFloorRulePhase
enum class EFloorRulePhase : uint8 {
	None = 0,
	Display = 1,
	Shrink = 2,
	End = 3,
	EFloorRulePhase_MAX = 4
};

// Enum DungeonCrawler.EMeleeAttackStuckType
enum class EMeleeAttackStuckType : uint8 {
	None = 0,
	HitBox = 1,
	WeakShield = 2,
	MidShield = 3,
	HeavyShield = 4,
	StaticObject = 5,
	EMeleeAttackStuckType_MAX = 6
};

// Enum DungeonCrawler.ESkillCheckResult
enum class ESkillCheckResult : uint8 {
	None = 0,
	PerfectSucceed = 1,
	Succeed = 2,
	Failed = 3,
	ESkillCheckResult_MAX = 4
};

// Enum DungeonCrawler.EInteractabilityType
enum class EInteractabilityType : uint8 {
	None = 0,
	Interactable = 1,
	SourceConditionNotMet = 2,
	TargetConditionNotMet = 3,
	EInteractabilityType_MAX = 4
};

// Enum DungeonCrawler.ESlotSearchResult
enum class ESlotSearchResult : uint8 {
	InventoryFull = 0,
	NotEnoughSlots = 1,
	Success = 2,
	ESlotSearchResult_MAX = 3
};

// Enum DungeonCrawler.EEquipmentQuickSlotType
enum class EEquipmentQuickSlotType : uint8 {
	None = 0,
	WeaponSetA = 1,
	WeaponSetB = 2,
	UtilityA = 3,
	UtilityB = 4,
	EEquipmentQuickSlotType_MAX = 5
};

// Enum DungeonCrawler.EItemEquipState
enum class EItemEquipState : uint8 {
	BareHands = 0,
	TwoHandedPrimaryItemEquipped = 1,
	OneHandedPrimaryItemEquipped = 2,
	SecondaryItemEquipped = 3,
	EachHandFull = 4,
	EItemEquipState_MAX = 5
};

// Enum DungeonCrawler.EDCEquipmentSlotIndex
enum class EDCEquipmentSlotIndex : uint8 {
	None = 0,
	Armor_Head = 1,
	Armor_Chest = 2,
	Armor_Hands = 3,
	Armor_Legs = 4,
	Armor_Foot = 5,
	Utility_L1 = 8,
	Utility_R1 = 9,
	Weapon_L1 = 10,
	Weapon_L2 = 11,
	Weapon_R1 = 12,
	Weapon_R2 = 13,
	Utility_L2 = 14,
	Utility_L3 = 15,
	Utility_R2 = 16,
	Utility_R3 = 17,
	SoulHeart = 18,
	Accessory_Necklace = 19,
	Accessory_Ring_2 = 20,
	Accessory_Ring_3 = 21,
	Armor_Back = 22,
	EDCEquipmentSlotIndex_MAX = 23
};

// Enum DungeonCrawler.EDCInventoryId
enum class EDCInventoryId : uint8 {
	None = 0,
	Chest = 1,
	Bag = 2,
	Equipment = 3,
	Storage = 4,
	TradingLocal = 5,
	TradingRemote = 6,
	MerchantDummy = 7,
	MerchantSaleList = 8,
	MerchantCraftList = 9,
	MerchantDealTable = 10,
	EDCInventoryId_MAX = 11
};

// Enum DungeonCrawler.EDCItemDropPreview
enum class EDCItemDropPreview : uint8 {
	None = 0,
	Valid = 1,
	Invalid = 2,
	EDCItemDropPreview_MAX = 3
};

// Enum DungeonCrawler.EDCItemEquipType
enum class EDCItemEquipType : uint8 {
	None = 0,
	Unarmed = 1,
	Primary = 2,
	Secondary = 3,
	Utility = 4,
	SoulHeart = 5,
	Head = 6,
	Chest = 7,
	Legs = 8,
	Foot = 9,
	Hands = 10,
	Back = 11,
	Necklace = 12,
	Ring = 13,
	EDCItemEquipType_MAX = 14
};

// Enum DungeonCrawler.EDCItemActionType
enum class EDCItemActionType : uint8 {
	Default = 0,
	EquipToggle = 1,
	StorageToggle = 2,
	StorageToggleSingle = 3,
	LinkToChat = 4,
	EDCItemActionType_MAX = 5
};

// Enum DungeonCrawler.EDCItemAttachType
enum class EDCItemAttachType : uint8 {
	None = 0,
	Hand = 1,
	Back = 2,
	EDCItemAttachType_MAX = 3
};

// Enum DungeonCrawler.EDCLocationStatus
enum class EDCLocationStatus : uint8 {
	None = 0,
	Lobby = 1,
	Dungeon = 2,
	Offline = 3,
	EDCLocationStatus_MAX = 4
};

// Enum DungeonCrawler.EMonsterCollisionProfile
enum class EMonsterCollisionProfile : uint8 {
	Normal = 0,
	Death = 1,
	Burrow = 2,
	Interactable = 3,
	InteractableOnly = 4,
	InteractableWithoutHit = 5,
	Fly = 6,
	BeforeDeath = 7,
	EMonsterCollisionProfile_MAX = 8
};

// Enum DungeonCrawler.EMonsterFilterSortingType
enum class EMonsterFilterSortingType : uint8 {
	Ascending = 0,
	Desending = 1,
	EMonsterFilterSortingType_MAX = 2
};

// Enum DungeonCrawler.EWidgetMusicSlotsType
enum class EWidgetMusicSlotsType : uint8 {
	None = 0,
	Percussion = 1,
	String = 2,
	Wind = 3,
	EWidgetMusicSlotsType_MAX = 4
};

// Enum DungeonCrawler.EMusicPlayabilityType
enum class EMusicPlayabilityType : uint8 {
	None = 0,
	Playable = 1,
	NotSelected = 2,
	EMusicPlayabilityType_MAX = 3
};

// Enum DungeonCrawler.EMusicPlaySectionJudgement
enum class EMusicPlaySectionJudgement : uint8 {
	None = 0,
	Miss = 1,
	Bad = 2,
	Good = 3,
	Perfect = 4,
	EMusicPlaySectionJudgement_MAX = 5
};

// Enum DungeonCrawler.EReportMsgType
enum class EReportMsgType : uint8 {
	None = 0,
	Check = 1,
	Detect = 2,
	EReportMsgType_MAX = 3
};

// Enum DungeonCrawler.EUpdateReason
enum class EUpdateReason : uint8 {
	NO_UPDATE_RECEIVED = 0,
	BACKFILL_INITIATED = 1,
	MATCHMAKING_DATA_UPDATED = 2,
	BACKFILL_FAILED = 3,
	BACKFILL_TIMED_OUT = 4,
	BACKFILL_CANCELLED = 5,
	BACKFILL_COMPLETED = 6,
	EUpdateReason_MAX = 7
};

// Enum DungeonCrawler.ESkillIndex
enum class ESkillIndex : uint8 {
	SKILL_INDEX_ONE = 0,
	SKILL_INDEX_TWO = 1,
	SKILL_INDEX_MAX = 2
};

// Enum DungeonCrawler.ESkillActivatableType
enum class ESkillActivatableType : uint8 {
	None = 0,
	Activatable = 1,
	OnCooldown = 2,
	NotEnoughCount = 3,
	NotEnoughSpace = 4,
	CannotActivateWhileMoving = 5,
	NoTargetAimed = 6,
	ESkillActivatableType_MAX = 7
};

// Enum DungeonCrawler.EWidgetSpellSlotsType
enum class EWidgetSpellSlotsType : uint8 {
	None = 0,
	Primary = 1,
	Secondary = 2,
	EWidgetSpellSlotsType_MAX = 3
};

// Enum DungeonCrawler.ESpellCastabilityType
enum class ESpellCastabilityType : uint8 {
	None = 0,
	Castable = 1,
	NotSelected = 2,
	NotEnoughCount = 3,
	CapacityOverloaded = 4,
	ESpellCastabilityType_MAX = 5
};

// Enum DungeonCrawler.EDCBuildConfiguration
enum class EDCBuildConfiguration : uint8 {
	Unknown = 0,
	Debug = 1,
	DebugGame = 2,
	Development = 3,
	Shipping = 4,
	Test = 5,
	EDCBuildConfiguration_MAX = 6
};

// Enum DungeonCrawler.EVoipAkComponentState
enum class EVoipAkComponentState : uint8 {
	None = 0,
	Send = 1,
	Receive2d = 2,
	Receive3d = 3,
	EVoipAkComponentState_MAX = 4
};

// Enum DungeonCrawler.EVoipStatus
enum class EVoipStatus : uint8 {
	None = 0,
	Waiting = 1,
	Speaking = 2,
	Muted = 3,
	EVoipStatus_MAX = 4
};

// Enum DungeonCrawler.EWidgetCharacterSelectGroupType
enum class EWidgetCharacterSelectGroupType : uint8 {
	None = 0,
	CharacterSelectMain = 1,
	CharacterCreateMain = 2,
	Menu = 3,
	MessageAnnounce = 4,
	EWidgetCharacterSelectGroupType_MAX = 5
};

// Enum DungeonCrawler.EWidgetGameGroupType
enum class EWidgetGameGroupType : uint8 {
	None = 0,
	Main = 1,
	Menu = 2,
	Inventory = 3,
	Status = 4,
	Interact = 5,
	Alive = 6,
	Spectator = 7,
	PartyManage = 8,
	ClassSelect = 9,
	Class = 10,
	SpellSelect = 11,
	SpellSelectSecondary = 12,
	EmoteSelect = 13,
	PlaqueText = 14,
	Customize = 15,
	ReportPlayer = 16,
	MusicSelect = 17,
	TestCmd = 18,
	EWidgetGameGroupType_MAX = 19
};

// Enum DungeonCrawler.EWidgetInventoryGroupType
enum class EWidgetInventoryGroupType : uint8 {
	LinkedPlayer = 0,
	LootingTarget = 1,
	LootingTargetPlayer = 2,
	Storage = 3,
	EWidgetInventoryGroupType_MAX = 4
};

// Enum DungeonCrawler.EMsgWidgetChatResult
enum class EMsgWidgetChatResult : uint8 {
	Succeed = 0,
	Wait = 1,
	EMsgWidgetChatResult_MAX = 2
};

// Enum DungeonCrawler.EWidgetLobbyGroupType
enum class EWidgetLobbyGroupType : uint8 {
	None = 0,
	Play = 1,
	TopMenu = 2,
	Menu = 3,
	LeaderBoard = 4,
	Status = 5,
	InviteParty = 6,
	Loadout = 7,
	MerchantList = 8,
	Merchant = 9,
	Class = 10,
	TradeChannelList = 11,
	TradeChannel = 12,
	Trading = 13,
	TradeConfirm = 14,
	Customize = 15,
	Shop = 16,
	Block = 17,
	RecruitChannelList = 18,
	RecruitChannel = 19,
	Karma = 20,
	LobbyEmoteSelect = 21,
	EWidgetLobbyGroupType_MAX = 22
};

// Enum DungeonCrawler.EWidgetClassGroupType
enum class EWidgetClassGroupType : uint8 {
	None = 0,
	Level = 1,
	PerkandSkill = 2,
	Spell = 3,
	EWidgetClassGroupType_MAX = 4
};

// Enum DungeonCrawler.EWidgetPlayUserPartyState
enum class EWidgetPlayUserPartyState : uint8 {
	Solo = 0,
	Ready = 1,
	NotReady = 2,
	EWidgetPlayUserPartyState_MAX = 3
};

// Enum DungeonCrawler.EWidgetPartyUserLocate
enum class EWidgetPartyUserLocate : uint8 {
	Mine = 0,
	Left = 1,
	Right = 2,
	None = 3,
	EWidgetPartyUserLocate_MAX = 4
};

// Enum DungeonCrawler.EWidgetPlayerInventoryTabType
enum class EWidgetPlayerInventoryTabType : uint8 {
	None = 0,
	Inventory = 1,
	Storage = 2,
	EWidgetPlayerInventoryTabType_MAX = 3
};

// Enum DungeonCrawler.EWidgetMerchantServiceType
enum class EWidgetMerchantServiceType : uint8 {
	None = 0,
	Buy = 1,
	Sell = 2,
	Craft = 3,
	Repair = 4,
	Quest = 5,
	Archived = 6,
	EWidgetMerchantServiceType_MAX = 7
};

// Enum DungeonCrawler.EWidgetMerchantInventoryType
enum class EWidgetMerchantInventoryType : uint8 {
	None = 0,
	StockBuy = 1,
	StockSellBack = 2,
	StockCraft = 3,
	DealTable = 4,
	EWidgetMerchantInventoryType_MAX = 5
};

// Enum DungeonCrawler.EWidgetCustomizeType
enum class EWidgetCustomizeType : uint8 {
	None = 0,
	Character = 1,
	Item = 2,
	Emote = 3,
	LobbyEmote = 4,
	Rest = 5,
	EWidgetCustomizeType_MAX = 6
};

// Enum DungeonCrawler.EPopupButtonType
enum class EPopupButtonType : uint8 {
	None = 0,
	NoButton = 1,
	OneButton = 2,
	TwoButton_InviteParty = 3,
	TwoButton_YesNo = 4,
	TwoButton_LobbySpectator = 5,
	TwoButton_DeleteCharacter = 6,
	EPopupButtonType_MAX = 7
};

// Enum DungeonCrawler.EServiceConnectFailType
enum class EServiceConnectFailType : uint8 {
	None = 0,
	ConnectFail = 1,
	SteamVersionUpdate = 2,
	BanUser = 3,
	BanUserCheater = 4,
	NotSteam = 5,
	DuplicatedLogin = 6,
	BanUserInappropriateName = 7,
	BanUserETC = 8,
	EServiceConnectFailType_MAX = 9
};

// Enum DungeonCrawler.EPopupResult
enum class EPopupResult : uint8 {
	Accept = 0,
	Cancel = 1,
	EPopupResult_MAX = 2
};

// Enum DungeonCrawler.EItemCountSelectWidgetType
enum class EItemCountSelectWidgetType : uint8 {
	None = 0,
	ItemCountSelectDrop = 1,
	ItemCountSelectSplit = 2,
	ItemCountSelectMerge = 3,
	EItemCountSelectWidgetType_MAX = 4
};

// ScriptStruct DungeonCrawler.GameUserSettingAudios
// Size: 0x28 (Inherited: 0x00)
struct FGameUserSettingAudios {
	float TotalVolume; // 0x00(0x04)
	float EffectVolume; // 0x04(0x04)
	float MusicVolume; // 0x08(0x04)
	bool IsBackgroundVolume; // 0x0c(0x01)
	bool bVoipEnable; // 0x0d(0x01)
	bool bVoipGlobal; // 0x0e(0x01)
	bool bVoipSendAlways; // 0x0f(0x01)
	float VoipInputVolume; // 0x10(0x04)
	float VoipOutputVolume; // 0x14(0x04)
	struct TArray<struct FGameUserSettingAudiosVoipPartyMember> VoipPartyMemberSettingArray; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.GameUserSettingAudiosVoipPartyMember
// Size: 0x18 (Inherited: 0x00)
struct FGameUserSettingAudiosVoipPartyMember {
	struct FString AccountId; // 0x00(0x10)
	bool bMute; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	float ReceiveVolume; // 0x14(0x04)
};

// ScriptStruct DungeonCrawler.AccountDataReplication
// Size: 0x78 (Inherited: 0x00)
struct FAccountDataReplication {
	struct FString AccountId; // 0x00(0x10)
	struct FNickname Nickname; // 0x10(0x28)
	struct FString PlayerCharacterId; // 0x38(0x10)
	struct FString PartyId; // 0x48(0x10)
	struct FString CharacterId; // 0x58(0x10)
	int32_t Gender; // 0x68(0x04)
	int32_t Level; // 0x6c(0x04)
	bool bInit; // 0x70(0x01)
	bool bExit; // 0x71(0x01)
	bool bLogin; // 0x72(0x01)
	bool bAlive; // 0x73(0x01)
	bool bEscape; // 0x74(0x01)
	bool bDown; // 0x75(0x01)
	char pad_76[0x2]; // 0x76(0x02)
};

// ScriptStruct DungeonCrawler.Nickname
// Size: 0x28 (Inherited: 0x00)
struct FNickname {
	struct FString OriginalNickName; // 0x00(0x10)
	struct FString StreamingModeNickName; // 0x10(0x10)
	int32_t KarmaRating; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.DCGameplayEffectContext
// Size: 0x1c8 (Inherited: 0x80)
struct FDCGameplayEffectContext : FGameplayEffectContext {
	char pad_80[0x130]; // 0x80(0x130)
	struct TArray<struct FItemData> ItemDatas; // 0x1b0(0x10)
	bool bActivatedQuickSlotEvent; // 0x1c0(0x01)
	char pad_1C1[0x7]; // 0x1c1(0x07)
};

// ScriptStruct DungeonCrawler.ItemData
// Size: 0xa0 (Inherited: 0x00)
struct FItemData {
	int64_t ItemUniqueId; // 0x00(0x08)
	struct FPrimaryAssetId ItemId; // 0x08(0x10)
	int32_t InventoryId; // 0x18(0x04)
	int32_t SlotId; // 0x1c(0x04)
	int32_t ItemCount; // 0x20(0x04)
	int32_t ItemAmmoCount; // 0x24(0x04)
	int32_t ItemContentsCount; // 0x28(0x04)
	bool bEquipped; // 0x2c(0x01)
	char pad_2D[0x3]; // 0x2d(0x03)
	struct FItemDataMeta MetaData; // 0x30(0x50)
	struct TArray<struct FItemDataProperty> ItemDataPrimaryPropertyArray; // 0x80(0x10)
	struct TArray<struct FItemDataProperty> ItemDataSecondaryPropertyArray; // 0x90(0x10)
};

// ScriptStruct DungeonCrawler.ItemDataProperty
// Size: 0x14 (Inherited: 0x00)
struct FItemDataProperty {
	struct FPrimaryAssetId PropertyTypeId; // 0x00(0x10)
	int32_t PropertyValue; // 0x10(0x04)
};

// ScriptStruct DungeonCrawler.ItemDataMeta
// Size: 0x50 (Inherited: 0x00)
struct FItemDataMeta {
	struct FString SoulHeart_AccountId; // 0x00(0x10)
	struct FString SoulHeart_PartyId; // 0x10(0x10)
	struct FNickname SoulHeart_NickName; // 0x20(0x28)
	int32_t AvailableValue; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// ScriptStruct DungeonCrawler.EmptySlotInfoArray
// Size: 0x10 (Inherited: 0x00)
struct FEmptySlotInfoArray {
	struct TArray<struct FEmptySlotInfo> Values; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.EmptySlotInfo
// Size: 0x08 (Inherited: 0x00)
struct FEmptySlotInfo {
	int32_t Index; // 0x00(0x04)
	int32_t CountOfConnectedEmptySlots; // 0x04(0x04)
};

// ScriptStruct DungeonCrawler.SlotInfo
// Size: 0x10 (Inherited: 0x00)
struct FSlotInfo {
	int32_t Index; // 0x00(0x04)
	int32_t Row; // 0x04(0x04)
	int64_t ItemUniqueId; // 0x08(0x08)
};

// ScriptStruct DungeonCrawler.ObjectLinkRequestEvent
// Size: 0xb0 (Inherited: 0x00)
struct FObjectLinkRequestEvent {
	struct FGameplayTag SrcTypeTag; // 0x00(0x08)
	struct FGameplayTag EventTag; // 0x08(0x08)
	struct FGameplayTagQuery DstTypeTagQuery; // 0x10(0x48)
	struct FObjectLinkMetaData MetaData; // 0x58(0x58)
};

// ScriptStruct DungeonCrawler.ObjectLinkMetaData
// Size: 0x58 (Inherited: 0x00)
struct FObjectLinkMetaData {
	struct FGameplayTagQuery MetaDataTagQuery; // 0x00(0x48)
	struct AActor* MetaDataActor; // 0x48(0x08)
	float MetaDataFloat; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// ScriptStruct DungeonCrawler.AccountDataGameplayEffectValue
// Size: 0x18 (Inherited: 0x00)
struct FAccountDataGameplayEffectValue {
	struct FString EffectTag; // 0x00(0x10)
	int32_t EffectValue; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct DungeonCrawler.AccountDataGameplayEffect
// Size: 0x20 (Inherited: 0x00)
struct FAccountDataGameplayEffect {
	struct FString EffectId; // 0x00(0x10)
	struct TArray<struct FAccountDataGameplayEffectValue> SelfEffectValueArray; // 0x10(0x10)
};

// ScriptStruct DungeonCrawler.AccountDataGameplayAbility
// Size: 0x20 (Inherited: 0x00)
struct FAccountDataGameplayAbility {
	struct FString AbilityId; // 0x00(0x10)
	struct TArray<struct FAccountDataGameplayEffect> SelfEffectArray; // 0x10(0x10)
};

// ScriptStruct DungeonCrawler.AccountDataItemMeta
// Size: 0x50 (Inherited: 0x00)
struct FAccountDataItemMeta {
	struct FString SoulHeart_AccountId; // 0x00(0x10)
	struct FString SoulHeart_PartyId; // 0x10(0x10)
	struct FNickname SoulHeart_NickName; // 0x20(0x28)
	int32_t AvailableValue; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// ScriptStruct DungeonCrawler.AccountDataItemProperty
// Size: 0x18 (Inherited: 0x00)
struct FAccountDataItemProperty {
	struct FString PropertyTypeId; // 0x00(0x10)
	int32_t PropertyValue; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct DungeonCrawler.AccountDataItem
// Size: 0xa0 (Inherited: 0x00)
struct FAccountDataItem {
	int64_t ItemUniqueId; // 0x00(0x08)
	struct FString ItemId; // 0x08(0x10)
	int32_t InventoryId; // 0x18(0x04)
	int32_t SlotId; // 0x1c(0x04)
	int32_t ItemCount; // 0x20(0x04)
	int32_t ItemAmmoCount; // 0x24(0x04)
	int32_t ItemContentsCount; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct FAccountDataItemMeta MetaData; // 0x30(0x50)
	struct TArray<struct FAccountDataItemProperty> PrimaryPropertyArray; // 0x80(0x10)
	struct TArray<struct FAccountDataItemProperty> SecondaryPropertyArray; // 0x90(0x10)
};

// ScriptStruct DungeonCrawler.AccountDataPerk
// Size: 0x18 (Inherited: 0x00)
struct FAccountDataPerk {
	int32_t Index; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString PerkId; // 0x08(0x10)
};

// ScriptStruct DungeonCrawler.PerkData
// Size: 0x10 (Inherited: 0x00)
struct FPerkData {
	struct FPrimaryAssetId PerkId; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.AccountDataSkill
// Size: 0x18 (Inherited: 0x00)
struct FAccountDataSkill {
	int32_t Index; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString SkillId; // 0x08(0x10)
};

// ScriptStruct DungeonCrawler.DataSkill
// Size: 0x10 (Inherited: 0x00)
struct FDataSkill {
	struct FPrimaryAssetId SkillId; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.AccountDataSpell
// Size: 0x18 (Inherited: 0x00)
struct FAccountDataSpell {
	int32_t SlotIndex; // 0x00(0x04)
	int32_t SequenceIndex; // 0x04(0x04)
	struct FString SpellId; // 0x08(0x10)
};

// ScriptStruct DungeonCrawler.AccountDataGameSpell
// Size: 0x18 (Inherited: 0x00)
struct FAccountDataGameSpell {
	struct FPrimaryAssetId SpellId; // 0x00(0x10)
	int32_t Count; // 0x10(0x04)
	int32_t ChargeAmount; // 0x14(0x04)
};

// ScriptStruct DungeonCrawler.AccountDataMusic
// Size: 0x18 (Inherited: 0x00)
struct FAccountDataMusic {
	int32_t SlotIndex; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString MusicId; // 0x08(0x10)
};

// ScriptStruct DungeonCrawler.AccountDataGameSkill
// Size: 0x18 (Inherited: 0x00)
struct FAccountDataGameSkill {
	struct FPrimaryAssetId SkillId; // 0x00(0x10)
	int32_t Count; // 0x10(0x04)
	int32_t ChargeAmount; // 0x14(0x04)
};

// ScriptStruct DungeonCrawler.AccountDataGameMusic
// Size: 0x10 (Inherited: 0x00)
struct FAccountDataGameMusic {
	struct FPrimaryAssetId MusicId; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.AccountData
// Size: 0xe0 (Inherited: 0x00)
struct FAccountData {
	struct FAccountDataReplication AccountDataReplication; // 0x00(0x78)
	struct TArray<struct FAccountDataItem> AccountDataItemArray; // 0x78(0x10)
	struct TArray<struct FAccountDataPerk> AccountDataPerkArray; // 0x88(0x10)
	struct TArray<struct FAccountDataSkill> AccountDataSkillArray; // 0x98(0x10)
	struct TArray<struct FAccountDataSpell> AccountDataSpellArray; // 0xa8(0x10)
	struct TArray<struct FAccountDataMusic> AccountDataMusicArray; // 0xb8(0x10)
	struct FString ExitReason; // 0xc8(0x10)
	bool bNeedBlock; // 0xd8(0x01)
	bool bNeedHWBlock; // 0xd9(0x01)
	char pad_DA[0x6]; // 0xda(0x06)
};

// ScriptStruct DungeonCrawler.AccountSessionData
// Size: 0xf0 (Inherited: 0x00)
struct FAccountSessionData {
	struct FAccountData AccountData; // 0x00(0xe0)
	struct TWeakObjectPtr<struct APlayerController> PlayerController; // 0xe0(0x08)
	struct TWeakObjectPtr<struct APawn> PlayerPawn; // 0xe8(0x08)
};

// ScriptStruct DungeonCrawler.PartyMemberData
// Size: 0x10 (Inherited: 0x00)
struct FPartyMemberData {
	struct FString AccountId; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.PartyData
// Size: 0x20 (Inherited: 0x00)
struct FPartyData {
	struct FString PartyId; // 0x00(0x10)
	struct TArray<struct FPartyMemberData> PartyMemberDataArray; // 0x10(0x10)
};

// ScriptStruct DungeonCrawler.PartySessionData
// Size: 0x20 (Inherited: 0x00)
struct FPartySessionData {
	struct FPartyData PartyData; // 0x00(0x20)
};

// ScriptStruct DungeonCrawler.RankRecord
// Size: 0x58 (Inherited: 0x00)
struct FRankRecord {
	int32_t PageIndex; // 0x00(0x04)
	int32_t Rank; // 0x04(0x04)
	int32_t Score; // 0x08(0x04)
	float Percentage; // 0x0c(0x04)
	struct FString AccountId; // 0x10(0x10)
	struct FNickname Nickname; // 0x20(0x28)
	struct FString CharacterClass; // 0x48(0x10)
};

// ScriptStruct DungeonCrawler.RankData
// Size: 0x10 (Inherited: 0x00)
struct FRankData {
	struct TArray<struct FRankRecord> RankRecords; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.CharacterSlot
// Size: 0x98 (Inherited: 0x00)
struct FCharacterSlot {
	struct FString CharacterId; // 0x00(0x10)
	struct FNickname Nickname; // 0x10(0x28)
	struct FString CharacterClass; // 0x38(0x10)
	int64_t CreateAt; // 0x48(0x08)
	enum class EDCGender Gender; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	int32_t Level; // 0x54(0x04)
	int64_t LastLoginDate; // 0x58(0x08)
	bool bSelected; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
	struct TArray<struct FAccountDataItem> EquipItemList; // 0x68(0x10)
	struct FPrimaryAssetId EquipCharacterSkin; // 0x78(0x10)
	struct TArray<struct FPrimaryAssetId> EquipItemSkinList; // 0x88(0x10)
};

// ScriptStruct DungeonCrawler.CharacterSlotData
// Size: 0x10 (Inherited: 0x00)
struct FCharacterSlotData {
	struct TArray<struct FCharacterSlot> CharacterSlotArray; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.InvitePartyUserSlot
// Size: 0x70 (Inherited: 0x00)
struct FInvitePartyUserSlot {
	struct FString AccountId; // 0x00(0x10)
	struct FNickname Nickname; // 0x10(0x28)
	struct FString CharacterClass; // 0x38(0x10)
	struct FString CharacterId; // 0x48(0x10)
	int32_t Gender; // 0x58(0x04)
	int32_t Level; // 0x5c(0x04)
	int32_t LocationStatus; // 0x60(0x04)
	int32_t PartyMemeberCount; // 0x64(0x04)
	int32_t PartyMaxMemeberCount; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// ScriptStruct DungeonCrawler.InvitePartyUserSlotData
// Size: 0x10 (Inherited: 0x00)
struct FInvitePartyUserSlotData {
	struct TArray<struct FInvitePartyUserSlot> InvitePartyUserSlotArray; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.LobbyCharacterInfo
// Size: 0x90 (Inherited: 0x00)
struct FLobbyCharacterInfo {
	struct FString AccountId; // 0x00(0x10)
	struct FNickname Nickname; // 0x10(0x28)
	struct FString CharacterClass; // 0x38(0x10)
	struct FString CharacterId; // 0x48(0x10)
	int32_t Gender; // 0x58(0x04)
	int32_t Level; // 0x5c(0x04)
	struct FString ServiceGrpc; // 0x60(0x10)
	struct TArray<struct FAccountDataItem> CharacterItemList; // 0x70(0x10)
	struct TArray<struct FAccountDataItem> CharacterStorageItemList; // 0x80(0x10)
};

// ScriptStruct DungeonCrawler.AccountDataCustomizeCharacter
// Size: 0x18 (Inherited: 0x00)
struct FAccountDataCustomizeCharacter {
	struct FString CustomizeCharacterId; // 0x00(0x10)
	int32_t IsEquip; // 0x10(0x04)
	int32_t IsNew; // 0x14(0x04)
};

// ScriptStruct DungeonCrawler.AccountDataCustomizeItem
// Size: 0x18 (Inherited: 0x00)
struct FAccountDataCustomizeItem {
	struct FString CustomizeItemId; // 0x00(0x10)
	int32_t IsEquip; // 0x10(0x04)
	int32_t IsNew; // 0x14(0x04)
};

// ScriptStruct DungeonCrawler.AccountDataEmote
// Size: 0x18 (Inherited: 0x00)
struct FAccountDataEmote {
	struct FString EmoteId; // 0x00(0x10)
	int32_t EquipSlotIndex; // 0x10(0x04)
	int32_t IsNew; // 0x14(0x04)
};

// ScriptStruct DungeonCrawler.AccountDataCustomizeAction
// Size: 0x18 (Inherited: 0x00)
struct FAccountDataCustomizeAction {
	struct FString CustomizeActionId; // 0x00(0x10)
	int32_t IsEquip; // 0x10(0x04)
	int32_t IsNew; // 0x14(0x04)
};

// ScriptStruct DungeonCrawler.AccountDataLobbyEmote
// Size: 0x18 (Inherited: 0x00)
struct FAccountDataLobbyEmote {
	struct FString LobbyEmoteId; // 0x00(0x10)
	int32_t EquipSlotIndex; // 0x10(0x04)
	int32_t IsNew; // 0x14(0x04)
};

// ScriptStruct DungeonCrawler.MsgAccountDataNotify
// Size: 0xf8 (Inherited: 0x18)
struct FMsgAccountDataNotify : FMsgBase {
	struct FAccountData AccountData; // 0x18(0xe0)
};

// ScriptStruct DungeonCrawler.MsgAccountDataItemChangeRequest
// Size: 0xc8 (Inherited: 0x18)
struct FMsgAccountDataItemChangeRequest : FMsgBase {
	struct FString AccountId; // 0x18(0x10)
	struct FAccountDataItem AccountDataItem; // 0x28(0xa0)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkResponse
// Size: 0x20 (Inherited: 0x18)
struct FMsgAccountLinkResponse : FMsgBase {
	struct UAccountSession* AccountSession; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgAccountSessionDataNotify
// Size: 0x108 (Inherited: 0x18)
struct FMsgAccountSessionDataNotify : FMsgBase {
	struct FAccountSessionData AccountSessionData; // 0x18(0xf0)
};

// ScriptStruct DungeonCrawler.MsgAccountSessionNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgAccountSessionNotify : FMsgBase {
	struct UAccountSession* AccountSession; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkAccountSessionDataRequest
// Size: 0x18 (Inherited: 0x18)
struct FMsgAccountLinkAccountSessionDataRequest : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkAccountSessionDataResponse
// Size: 0x110 (Inherited: 0x18)
struct FMsgAccountLinkAccountSessionDataResponse : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct FAccountSessionData AccountSessionData; // 0x20(0xf0)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkBegin
// Size: 0x128 (Inherited: 0x18)
struct FMsgAccountLinkBegin : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct FAccountData AccountData; // 0x20(0xe0)
	struct UDCAttributeSet* AttributeSet; // 0x100(0x08)
	struct FPartySessionData PartySessionData; // 0x108(0x20)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkAccountDataReplicationNotify
// Size: 0x98 (Inherited: 0x18)
struct FMsgAccountLinkAccountDataReplicationNotify : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct FAccountDataReplication AccountDataReplication; // 0x20(0x78)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkPlayerControllerNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgAccountLinkPlayerControllerNotify : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct APlayerController* PlayerController; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkPlayerPawnNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgAccountLinkPlayerPawnNotify : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct APawn* PlayerPawn; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkAttributeSetNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgAccountLinkAttributeSetNotify : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct UDCAttributeSet* AttributeSet; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkAttributeNotify
// Size: 0x238 (Inherited: 0x18)
struct FMsgAccountLinkAttributeNotify : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct UDCAttributeSet* AttributeSet; // 0x20(0x08)
	struct FGameplayAttribute Attribute; // 0x28(0x38)
	float NewValue; // 0x60(0x04)
	float OldValue; // 0x64(0x04)
	struct UGameplayEffect* GameplayEffectClass; // 0x68(0x08)
	struct FDCGameplayEffectContext EffectContext; // 0x70(0x1c8)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkGameplayTagContainerNotify
// Size: 0x40 (Inherited: 0x18)
struct FMsgAccountLinkGameplayTagContainerNotify : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct FGameplayTagContainer GameplayTagContainer; // 0x20(0x20)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkGameplayTagNotify
// Size: 0x50 (Inherited: 0x18)
struct FMsgAccountLinkGameplayTagNotify : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct FGameplayTagContainer GameplayTagContainer; // 0x20(0x20)
	struct FGameplayTag GameplayTag; // 0x40(0x08)
	int32_t Count; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkActorStatusNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgAccountLinkActorStatusNotify : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct TArray<struct FActorStatusData> ActorStatusDatas; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ActorStatusData
// Size: 0x20 (Inherited: 0x00)
struct FActorStatusData {
	struct FActiveGameplayEffectHandle EffectHandle; // 0x00(0x08)
	struct UGameplayEffect* GameplayEffectClass; // 0x08(0x08)
	int32_t StackCount; // 0x10(0x04)
	float StartServerWorldTime; // 0x14(0x04)
	float MaxDuration; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkEquipmentInventoryNotifiy
// Size: 0x28 (Inherited: 0x18)
struct FMsgAccountLinkEquipmentInventoryNotifiy : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct UEquipmentInventoryComponent* EquipmentInventory; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkContainerInventoryNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgAccountLinkContainerInventoryNotify : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct UInventoryComponent* OldInventory; // 0x20(0x08)
	struct UInventoryComponent* NewInventory; // 0x28(0x08)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkLootComponentNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgAccountLinkLootComponentNotify : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct ULootComponent* OldLootComponent; // 0x20(0x08)
	struct ULootComponent* NewLootComponent; // 0x28(0x08)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkLootingTargetPlayerEquipmentInventoryNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgAccountLinkLootingTargetPlayerEquipmentInventoryNotify : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct UEquipmentInventoryComponent* EquipmentInventory; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkLootingTargetPlayerInventoryNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgAccountLinkLootingTargetPlayerInventoryNotify : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct UInventoryComponent* OldTargetInventory; // 0x20(0x08)
	struct UInventoryComponent* NewTargetInventory; // 0x28(0x08)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkStorageInventoryNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgAccountLinkStorageInventoryNotify : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct UMetaStorageComponent* OldStorage; // 0x20(0x08)
	struct UMetaStorageComponent* NewStorage; // 0x28(0x08)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkPerkIdArrayNotify
// Size: 0x40 (Inherited: 0x18)
struct FMsgAccountLinkPerkIdArrayNotify : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct TArray<struct FPrimaryAssetId> OldPerkIdArray; // 0x20(0x10)
	struct TArray<struct FPrimaryAssetId> NewPerkIdArray; // 0x30(0x10)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkSkillIdArrayNotify
// Size: 0x40 (Inherited: 0x18)
struct FMsgAccountLinkSkillIdArrayNotify : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct TArray<struct FPrimaryAssetId> OldSkillIdArray; // 0x20(0x10)
	struct TArray<struct FPrimaryAssetId> NewSkillIdArray; // 0x30(0x10)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkSpellIdArrayNotify
// Size: 0x40 (Inherited: 0x18)
struct FMsgAccountLinkSpellIdArrayNotify : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct TArray<struct FPrimaryAssetId> OldSpellIdArray; // 0x20(0x10)
	struct TArray<struct FPrimaryAssetId> NewSpellIdArray; // 0x30(0x10)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkPartySessionDataNotify
// Size: 0x40 (Inherited: 0x18)
struct FMsgAccountLinkPartySessionDataNotify : FMsgBase {
	struct UAccountLink* AccountLink; // 0x18(0x08)
	struct FPartySessionData PartySessionData; // 0x20(0x20)
};

// ScriptStruct DungeonCrawler.MsgAccountLinkAllAccountDataReplicationNotify
// Size: 0x108 (Inherited: 0x18)
struct FMsgAccountLinkAllAccountDataReplicationNotify : FMsgBase {
	struct FAccountDataReplication AccountDataReplication; // 0x18(0x78)
	struct FAccountDataReplication OldAccountDataReplication; // 0x90(0x78)
};

// ScriptStruct DungeonCrawler.MsgAccountExitReasonRequest
// Size: 0x40 (Inherited: 0x18)
struct FMsgAccountExitReasonRequest : FMsgBase {
	struct FString AccountId; // 0x18(0x10)
	struct FString Reason; // 0x28(0x10)
	bool bNeedBlock; // 0x38(0x01)
	bool bNeedHWBlock; // 0x39(0x01)
	char pad_3A[0x6]; // 0x3a(0x06)
};

// ScriptStruct DungeonCrawler.MsgActorAttachmentChangedNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgActorAttachmentChangedNotify : FMsgBase {
	struct USceneComponent* AttachParentComponent; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgActorSleepNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgActorSleepNotify : FMsgBase {
	bool bSleep; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgAnimationChangePlayerCharacterAnimSet
// Size: 0x38 (Inherited: 0x18)
struct FMsgAnimationChangePlayerCharacterAnimSet : FMsgBase {
	struct FLocomotionAnimSet AnimSet; // 0x18(0x18)
	bool bSecondaryItem; // 0x30(0x01)
	bool bTwoHandedItem; // 0x31(0x01)
	char pad_32[0x6]; // 0x32(0x06)
};

// ScriptStruct DungeonCrawler.LocomotionAnimSet
// Size: 0x18 (Inherited: 0x00)
struct FLocomotionAnimSet {
	struct UAnimSequenceBase* StandIdle; // 0x00(0x08)
	struct UAnimSequenceBase* CrouchIdle; // 0x08(0x08)
	struct UBlendSpace* RunUpperBody; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgAnimationStopMontage
// Size: 0x18 (Inherited: 0x18)
struct FMsgAnimationStopMontage : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgAnimationMontageJumpToSection
// Size: 0x20 (Inherited: 0x18)
struct FMsgAnimationMontageJumpToSection : FMsgBase {
	struct FName SectionName; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgAnimationChangeIdle
// Size: 0x20 (Inherited: 0x18)
struct FMsgAnimationChangeIdle : FMsgBase {
	struct FGameplayTag IdleAnimSequenceGameplayTag; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgAnimationHitReaction
// Size: 0x30 (Inherited: 0x18)
struct FMsgAnimationHitReaction : FMsgBase {
	struct FVector HitDirection; // 0x18(0x18)
};

// ScriptStruct DungeonCrawler.MsgAoeAISet
// Size: 0x20 (Inherited: 0x18)
struct FMsgAoeAISet : FMsgBase {
	struct UBehaviorTree* BehaviorTree; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.AoeScaleData
// Size: 0x10 (Inherited: 0x00)
struct FAoeScaleData {
	float OldServerWorldTimeSeconds; // 0x00(0x04)
	float OldScale; // 0x04(0x04)
	float NewServerWorldTimeSeconds; // 0x08(0x04)
	float NewScale; // 0x0c(0x04)
};

// ScriptStruct DungeonCrawler.AnimationSet
// Size: 0x38 (Inherited: 0x00)
struct FAnimationSet {
	struct UAnimMontage* EquipMontage; // 0x00(0x08)
	struct UAnimMontage* UnEquipMontage; // 0x08(0x08)
	struct UAnimMontage* EquipMontageItem; // 0x10(0x08)
	struct UAnimMontage* UnEquipMontageItem; // 0x18(0x08)
	struct FLocomotionAnimSet LocomotionAnimSet; // 0x20(0x18)
};

// ScriptStruct DungeonCrawler.ItemMaterialInfo
// Size: 0x10 (Inherited: 0x00)
struct FItemMaterialInfo {
	struct FName MaterialSlotName; // 0x00(0x08)
	struct UMaterialInterface* MaterialInterface; // 0x08(0x08)
};

// ScriptStruct DungeonCrawler.DCCircle
// Size: 0x18 (Inherited: 0x00)
struct FDCCircle {
	char pad_0[0x18]; // 0x00(0x18)
};

// ScriptStruct DungeonCrawler.DCFloorRuleInfo
// Size: 0xf8 (Inherited: 0x00)
struct FDCFloorRuleInfo {
	struct FDCFloorRuleItemData Data; // 0x00(0x40)
	struct FDCCircle Area; // 0x40(0x18)
	struct TMap<struct AFloorPortalBase*, struct UDCFloorPortalDataAsset*> DisplayPortals; // 0x58(0x50)
	struct TMap<struct AFloorPortalBase*, struct UDCFloorPortalDataAsset*> ShrinkPortals; // 0xa8(0x50)
};

// ScriptStruct DungeonCrawler.DCFloorRuleItemData
// Size: 0x40 (Inherited: 0x00)
struct FDCFloorRuleItemData {
	float DeathSwarmSize; // 0x00(0x04)
	struct FGameplayTag DeathSwarmAbilityTag; // 0x04(0x08)
	int32_t DisplayPhaseDuration; // 0x0c(0x04)
	struct TArray<struct TSoftObjectPtr<UDCFloorPortalDataAsset>> DisplayPhaseFloorPortalArray; // 0x10(0x10)
	int32_t ShrinkPhaseDuration; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct TArray<struct TSoftObjectPtr<UDCFloorPortalDataAsset>> ShrinkPhaseFloorPortalArray; // 0x28(0x10)
	bool HideDeathSwarmTimer; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct DungeonCrawler.DCFloorRuleManager
// Size: 0x38 (Inherited: 0x00)
struct FDCFloorRuleManager {
	struct UDCFloorRuleDataAsset* Data; // 0x00(0x08)
	struct FDCCircle RootArea; // 0x08(0x18)
	struct TArray<struct FDCFloorRuleInfo> Rules; // 0x20(0x10)
	char pad_30[0x8]; // 0x30(0x08)
};

// ScriptStruct DungeonCrawler.MsgCharacterPerspectiveSet
// Size: 0x20 (Inherited: 0x18)
struct FMsgCharacterPerspectiveSet : FMsgBase {
	bool bIsFirstPersonPerspective; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgDefaultBodyPartMapRequest
// Size: 0x18 (Inherited: 0x18)
struct FMsgDefaultBodyPartMapRequest : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgDefaultBodyPartMapResponse
// Size: 0x68 (Inherited: 0x18)
struct FMsgDefaultBodyPartMapResponse : FMsgBase {
	struct TMap<struct FGameplayTag, struct USkeletalMesh*> DefaultBodyPartsMap; // 0x18(0x50)
};

// ScriptStruct DungeonCrawler.MsgHiddenCharacterNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgHiddenCharacterNotify : FMsgBase {
	bool IsHiddenCharacter; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgCharacterResetEquipItemNotify
// Size: 0x50 (Inherited: 0x18)
struct FMsgCharacterResetEquipItemNotify : FMsgBase {
	enum class EDCCharacterClass CharacterClass; // 0x18(0x01)
	enum class EDCGender Gender; // 0x19(0x01)
	char pad_1A[0x6]; // 0x1a(0x06)
	struct TArray<struct FItemData> ItemData; // 0x20(0x10)
	struct FPrimaryAssetId EquipCharacterSkin; // 0x30(0x10)
	struct TArray<struct FPrimaryAssetId> EquipItemSkinList; // 0x40(0x10)
};

// ScriptStruct DungeonCrawler.MsgSetCheckTargetPlayerEquipment
// Size: 0x28 (Inherited: 0x18)
struct FMsgSetCheckTargetPlayerEquipment : FMsgBase {
	struct FString TargetPlayerAccountId; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgRemoveCheckTargetPlayerEquipment
// Size: 0x18 (Inherited: 0x18)
struct FMsgRemoveCheckTargetPlayerEquipment : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgCharacterAddMovementModifier
// Size: 0x28 (Inherited: 0x18)
struct FMsgCharacterAddMovementModifier : FMsgBase {
	struct TArray<struct FPrimaryAssetId> MovementModifiers; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgCharacterRemoveMovementModifier
// Size: 0x28 (Inherited: 0x18)
struct FMsgCharacterRemoveMovementModifier : FMsgBase {
	struct TArray<struct FPrimaryAssetId> MovementModifiers; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.CharacterStatusWidgetData
// Size: 0x180 (Inherited: 0x00)
struct FCharacterStatusWidgetData {
	struct FGameplayAttributeData Strength; // 0x00(0x10)
	struct FGameplayAttributeData Agility; // 0x10(0x10)
	struct FGameplayAttributeData Will; // 0x20(0x10)
	struct FGameplayAttributeData Knowledge; // 0x30(0x10)
	struct FGameplayAttributeData Resourcefulness; // 0x40(0x10)
	struct FGameplayAttributeData Health; // 0x50(0x10)
	struct FGameplayAttributeData MaxHealth; // 0x60(0x10)
	struct FGameplayAttributeData MaxHealthBase; // 0x70(0x10)
	struct FGameplayAttributeData MaxHealthMod; // 0x80(0x10)
	struct FGameplayAttributeData MaxHealthAdd; // 0x90(0x10)
	struct FGameplayAttributeData Weight; // 0xa0(0x10)
	struct FGameplayAttributeData WeightLimit; // 0xb0(0x10)
	struct FGameplayAttributeData WeightLimitBase; // 0xc0(0x10)
	struct FGameplayAttributeData WeightLimitMod; // 0xd0(0x10)
	struct FGameplayAttributeData WeightLimitAdd; // 0xe0(0x10)
	struct FGameplayAttributeData SpellPayload; // 0xf0(0x10)
	struct FGameplayAttributeData SpellCapacity; // 0x100(0x10)
	struct FGameplayAttributeData SpellCapacityBase; // 0x110(0x10)
	struct FGameplayAttributeData SpellCapacityMod; // 0x120(0x10)
	struct FGameplayAttributeData SpellCapacityAdd; // 0x130(0x10)
	struct FGameplayAttributeData UtilityEffectiveness; // 0x140(0x10)
	struct FGameplayAttributeData UtilityEffectivenessBase; // 0x150(0x10)
	struct FGameplayAttributeData UtilityEffectivenessMod; // 0x160(0x10)
	struct FGameplayAttributeData UtilityEffectivenessAdd; // 0x170(0x10)
};

// ScriptStruct DungeonCrawler.CharacterStatusDetailWidgetData
// Size: 0x4a8 (Inherited: 0x180)
struct FCharacterStatusDetailWidgetData : FCharacterStatusWidgetData {
	struct FGameplayAttributeData PhysicalDamageWeaponPrimary; // 0x180(0x10)
	struct FGameplayAttributeData PhysicalDamageWeaponSecondary; // 0x190(0x10)
	struct FGameplayAttributeData PhysicalDamageBase; // 0x1a0(0x10)
	struct FGameplayAttributeData PhysicalPower; // 0x1b0(0x10)
	struct FGameplayAttributeData PhysicalDamageMod; // 0x1c0(0x10)
	struct FGameplayAttributeData PhysicalDamageModPhysicalPower; // 0x1d0(0x10)
	struct FGameplayAttributeData PhysicalDamageModBonus; // 0x1e0(0x10)
	struct FGameplayAttributeData PhysicalDamageAdd; // 0x1f0(0x10)
	struct FGameplayAttributeData PhysicalDamageTrue; // 0x200(0x10)
	struct FGameplayAttributeData ArmorPenetration; // 0x210(0x10)
	struct FGameplayAttributeData ArmorRating; // 0x220(0x10)
	struct FGameplayAttributeData PhysicalReductionArmorRating; // 0x230(0x10)
	struct FGameplayAttributeData PhysicalReductionBonus; // 0x240(0x10)
	struct FGameplayAttributeData PhysicalReduction; // 0x250(0x10)
	struct FGameplayAttributeData PhysicalReductionMod; // 0x260(0x10)
	struct FGameplayAttributeData MagicalDamageBase; // 0x270(0x10)
	struct FGameplayAttributeData MagicalPower; // 0x280(0x10)
	struct FGameplayAttributeData MagicalDamageMod; // 0x290(0x10)
	struct FGameplayAttributeData MagicalDamageModMagicalPower; // 0x2a0(0x10)
	struct FGameplayAttributeData MagicalDamageModBonus; // 0x2b0(0x10)
	struct FGameplayAttributeData MagicalDamageAdd; // 0x2c0(0x10)
	struct FGameplayAttributeData MagicalDamageTrue; // 0x2d0(0x10)
	struct FGameplayAttributeData MagicPenetration; // 0x2e0(0x10)
	struct FGameplayAttributeData MagicResistance; // 0x2f0(0x10)
	struct FGameplayAttributeData MagicalReductionMagicResistance; // 0x300(0x10)
	struct FGameplayAttributeData MagicalReductionBonus; // 0x310(0x10)
	struct FGameplayAttributeData MagicalReduction; // 0x320(0x10)
	struct FGameplayAttributeData MagicalReductionMod; // 0x330(0x10)
	struct FGameplayAttributeData PhysicalHealBase; // 0x340(0x10)
	struct FGameplayAttributeData MagicalHealBase; // 0x350(0x10)
	struct FGameplayAttributeData MoveSpeed; // 0x360(0x10)
	struct FGameplayAttributeData MoveSpeedBase; // 0x370(0x10)
	struct FGameplayAttributeData MoveSpeedMod; // 0x380(0x10)
	struct FGameplayAttributeData MoveSpeedAdd; // 0x390(0x10)
	struct FGameplayAttributeData MoveSpeedWithModifier; // 0x3a0(0x10)
	struct FGameplayAttributeData ActionSpeed; // 0x3b0(0x10)
	struct FGameplayAttributeData SpellCastingSpeed; // 0x3c0(0x10)
	struct FGameplayAttributeData ItemEquipSpeed; // 0x3d0(0x10)
	struct FGameplayAttributeData RegularInteractionSpeedBase; // 0x3e0(0x10)
	struct FGameplayAttributeData RegularInteractionSpeed; // 0x3f0(0x10)
	struct FGameplayAttributeData MagicalInteractionSpeed; // 0x400(0x10)
	struct FGameplayAttributeData BuffDurationMod; // 0x410(0x10)
	struct FGameplayAttributeData DebuffDurationMod; // 0x420(0x10)
	struct FGameplayAttributeData HeadshotReductionMod; // 0x430(0x10)
	struct FGameplayAttributeData ProjectileReductionMod; // 0x440(0x10)
	struct FGameplayAttributeData PhysicalHeadshotPenetration; // 0x450(0x10)
	struct FGameplayAttributeData PrestigeItemDrop; // 0x460(0x10)
	struct FGameplayAttributeData ImpactPower; // 0x470(0x10)
	float PrimaryWeaponImpactPower; // 0x480(0x04)
	float SecondaryWeaponImpactPower; // 0x484(0x04)
	struct TArray<struct UItemTooltipStatWidgetData*> PrimaryAbilityWidgetArray; // 0x488(0x10)
	struct TArray<struct UItemTooltipStatWidgetData*> SecondaryAbilityWidgetArray; // 0x498(0x10)
};

// ScriptStruct DungeonCrawler.ChatDataPieceItemProperty
// Size: 0x18 (Inherited: 0x00)
struct FChatDataPieceItemProperty {
	struct FString Pid; // 0x00(0x10)
	int32_t Pv; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct DungeonCrawler.ChatDataPieceItem
// Size: 0x38 (Inherited: 0x00)
struct FChatDataPieceItem {
	int64_t Uid; // 0x00(0x08)
	struct FString Iid; // 0x08(0x10)
	struct TArray<struct FChatDataPieceItemProperty> Pp; // 0x18(0x10)
	struct TArray<struct FChatDataPieceItemProperty> Sp; // 0x28(0x10)
};

// ScriptStruct DungeonCrawler.ChatDataPiece
// Size: 0x48 (Inherited: 0x00)
struct FChatDataPiece {
	struct FString ChatStr; // 0x00(0x10)
	struct FChatDataPieceItem ChatDataPieceItem; // 0x10(0x38)
};

// ScriptStruct DungeonCrawler.ChatData
// Size: 0x68 (Inherited: 0x00)
struct FChatData {
	struct FString AccountId; // 0x00(0x10)
	struct FString CharacterId; // 0x10(0x10)
	struct FNickname Nickname; // 0x20(0x28)
	struct FString PartyId; // 0x48(0x10)
	struct TArray<struct FChatDataPiece> ChatDataPieceArray; // 0x58(0x10)
};

// ScriptStruct DungeonCrawler.DCChatInfo
// Size: 0x68 (Inherited: 0x00)
struct FDCChatInfo {
	struct FDCAccountId AccountId; // 0x00(0x10)
	struct FDCCharacterId CharacterId; // 0x10(0x10)
	struct FNickname Nickname; // 0x20(0x28)
	struct FDCPartyId PartyId; // 0x48(0x10)
	struct TArray<struct FChatDataPiece> Pieces; // 0x58(0x10)
};

// ScriptStruct DungeonCrawler.DCStringIdBase
// Size: 0x10 (Inherited: 0x00)
struct FDCStringIdBase {
	struct FString _; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DCPartyId
// Size: 0x10 (Inherited: 0x10)
struct FDCPartyId : FDCStringIdBase {
	struct FString _; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DCCharacterId
// Size: 0x10 (Inherited: 0x10)
struct FDCCharacterId : FDCStringIdBase {
	struct FString _; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DCAccountId
// Size: 0x10 (Inherited: 0x10)
struct FDCAccountId : FDCStringIdBase {
	struct FString _; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DCChatLog
// Size: 0x70 (Inherited: 0x00)
struct FDCChatLog {
	int64_t Timestamp; // 0x00(0x08)
	struct FDCChatInfo ChatInfo; // 0x08(0x68)
};

// ScriptStruct DungeonCrawler.TradeChatData
// Size: 0x78 (Inherited: 0x00)
struct FTradeChatData {
	enum class EChatType ChatType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	int64_t Time; // 0x08(0x08)
	struct FChatData ChatData; // 0x10(0x68)
};

// ScriptStruct DungeonCrawler.PartyChatData
// Size: 0x70 (Inherited: 0x00)
struct FPartyChatData {
	int64_t Time; // 0x00(0x08)
	struct FChatData ChatData; // 0x08(0x68)
};

// ScriptStruct DungeonCrawler.ChatAccountData
// Size: 0x48 (Inherited: 0x00)
struct FChatAccountData {
	struct FString ChatAccountId; // 0x00(0x10)
	struct FString ChatCharacterId; // 0x10(0x10)
	struct FNickname ChatNickName; // 0x20(0x28)
};

// ScriptStruct DungeonCrawler.ChatEditWidgetData
// Size: 0x50 (Inherited: 0x00)
struct FChatEditWidgetData {
	int32_t StartIndex; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FChatDataPiece ChatDataPiece; // 0x08(0x48)
};

// ScriptStruct DungeonCrawler.ChatFilterListEntryWidgetData
// Size: 0x18 (Inherited: 0x00)
struct FChatFilterListEntryWidgetData {
	struct FText ChatFilterText; // 0x00(0x18)
};

// ScriptStruct DungeonCrawler.ChatRecord
// Size: 0x78 (Inherited: 0x00)
struct FChatRecord {
	enum class EChatWidgetType ChatWidgetType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FDateTime DateTime; // 0x08(0x08)
	struct FString AccountId; // 0x10(0x10)
	struct FString CharacterId; // 0x20(0x10)
	struct FNickname Nickname; // 0x30(0x28)
	struct FString PartyId; // 0x58(0x10)
	struct FString ChatStr; // 0x68(0x10)
};

// ScriptStruct DungeonCrawler.RequestMsg
// Size: 0x20 (Inherited: 0x18)
struct FRequestMsg : FMsgBase {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgAccountLoginRequest
// Size: 0x90 (Inherited: 0x20)
struct FClientMsgAccountLoginRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x6c]; // 0x24(0x6c)
};

// ScriptStruct DungeonCrawler.ClientMsgAccountLoginResponse
// Size: 0x80 (Inherited: 0x18)
struct FClientMsgAccountLoginResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x60]; // 0x20(0x60)
};

// ScriptStruct DungeonCrawler.ClientMsgAccountCharacterCreateRequest
// Size: 0x48 (Inherited: 0x20)
struct FClientMsgAccountCharacterCreateRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x24]; // 0x24(0x24)
};

// ScriptStruct DungeonCrawler.ClientMsgAccountCharacterCreateResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgAccountCharacterCreateResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgAccountCharacterListRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgAccountCharacterListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgAccountCharacterListResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgAccountCharacterListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgAccountCharacterDeleteRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgAccountCharacterDeleteRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgAccountCharacterDeleteResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgAccountCharacterDeleteResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgLobbyEnterRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgLobbyEnterRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgLobbyEnterResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgLobbyEnterResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgAccountAgreeAnswerRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgAccountAgreeAnswerRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgAccountAgreeAnswerResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgAccountAgreeAnswerResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgClassLevelInfoRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgClassLevelInfoRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgClassLevelInfoResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgClassLevelInfoResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgClassEquipInfoRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgClassEquipInfoRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgClassEquipInfoResponse
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgClassEquipInfoResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgClassPerkListRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgClassPerkListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgClassPerkListResponse
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgClassPerkListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgClassSkillListRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgClassSkillListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgClassSkillListResponse
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgClassSkillListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgClassSpellListRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgClassSpellListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgClassSpellListResponse
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgClassSpellListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgClassSpellSlotMoveRequest
// Size: 0x38 (Inherited: 0x20)
struct FClientMsgClassSpellSlotMoveRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x14]; // 0x24(0x14)
};

// ScriptStruct DungeonCrawler.ClientMsgClassSpellSlotMoveResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgClassSpellSlotMoveResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgClassSpellSequenceChangeRequest
// Size: 0x38 (Inherited: 0x20)
struct FClientMsgClassSpellSequenceChangeRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x14]; // 0x24(0x14)
};

// ScriptStruct DungeonCrawler.ClientMsgClassSpellSequenceChangeResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgClassSpellSequenceChangeResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgClassItemMoveRequest
// Size: 0x60 (Inherited: 0x20)
struct FClientMsgClassItemMoveRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x3c]; // 0x24(0x3c)
};

// ScriptStruct DungeonCrawler.ClientMsgClassItemMoveResponse
// Size: 0x60 (Inherited: 0x18)
struct FClientMsgClassItemMoveResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x40]; // 0x20(0x40)
};

// ScriptStruct DungeonCrawler.ClientMsgMetaLocationRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgMetaLocationRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgMetaLocationResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgMetaLocationResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgBlockCharacterRequest
// Size: 0x40 (Inherited: 0x20)
struct FClientMsgBlockCharacterRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x1c]; // 0x24(0x1c)
};

// ScriptStruct DungeonCrawler.ClientMsgBlockCharacterResponse
// Size: 0x80 (Inherited: 0x18)
struct FClientMsgBlockCharacterResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x60]; // 0x20(0x60)
};

// ScriptStruct DungeonCrawler.ClientMsgUnblockCharacterRequest
// Size: 0x40 (Inherited: 0x20)
struct FClientMsgUnblockCharacterRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x1c]; // 0x24(0x1c)
};

// ScriptStruct DungeonCrawler.ClientMsgUnblockCharacterResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgUnblockCharacterResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgBlockCharacterListRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgBlockCharacterListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgBlockCharacterListResponse
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgBlockCharacterListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgHackLogRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgHackLogRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgHackLogResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgHackLogResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgOperateAnnounceNotify
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgOperateAnnounceNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgServicePolicyNotify
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgServicePolicyNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgReLoginRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgReLoginRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgReLoginResponse
// Size: 0x50 (Inherited: 0x18)
struct FClientMsgReLoginResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x30]; // 0x20(0x30)
};

// ScriptStruct DungeonCrawler.ClientMsgClosedGameNotify
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgClosedGameNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgHackCheckDllListNotify
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgHackCheckDllListNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgUserCharacterInfoRequest
// Size: 0x88 (Inherited: 0x20)
struct FClientMsgUserCharacterInfoRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x64]; // 0x24(0x64)
};

// ScriptStruct DungeonCrawler.ClientMsgUserCharacterInfoResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgUserCharacterInfoResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgGmEnterGameSpectatorRequest
// Size: 0x40 (Inherited: 0x20)
struct FClientMsgGmEnterGameSpectatorRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x1c]; // 0x24(0x1c)
};

// ScriptStruct DungeonCrawler.ClientMsgGmEnterGameSpectatorResponse
// Size: 0x58 (Inherited: 0x18)
struct FClientMsgGmEnterGameSpectatorResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x38]; // 0x20(0x38)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeCharacterInfoRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgCustomizeCharacterInfoRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeCharacterInfoResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgCustomizeCharacterInfoResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeItemInfoRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgCustomizeItemInfoRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeItemInfoResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgCustomizeItemInfoResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeEmoteInfoRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgCustomizeEmoteInfoRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeEmoteInfoResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgCustomizeEmoteInfoResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeActionInfoRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgCustomizeActionInfoRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeActionInfoResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgCustomizeActionInfoResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeLobbyEmoteInfoRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgCustomizeLobbyEmoteInfoRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeLobbyEmoteInfoResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgCustomizeLobbyEmoteInfoResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeCharacterMountRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgCustomizeCharacterMountRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeCharacterMountResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgCustomizeCharacterMountResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeCharacterUnmountRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgCustomizeCharacterUnmountRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeCharacterUnmountResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgCustomizeCharacterUnmountResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeItemMountRequest
// Size: 0x38 (Inherited: 0x20)
struct FClientMsgCustomizeItemMountRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x14]; // 0x24(0x14)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeItemMountResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgCustomizeItemMountResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeItemUnmountRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgCustomizeItemUnmountRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeItemUnmountResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgCustomizeItemUnmountResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeEmoteMountRequest
// Size: 0x38 (Inherited: 0x20)
struct FClientMsgCustomizeEmoteMountRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x14]; // 0x24(0x14)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeEmoteMountResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgCustomizeEmoteMountResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeEmoteUnmountRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgCustomizeEmoteUnmountRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeEmoteUnmountResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgCustomizeEmoteUnmountResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeActionMountRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgCustomizeActionMountRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeActionMountResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgCustomizeActionMountResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeActionUnmountRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgCustomizeActionUnmountRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeActionUnmountResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgCustomizeActionUnmountResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeLobbyEmoteMountRequest
// Size: 0x38 (Inherited: 0x20)
struct FClientMsgCustomizeLobbyEmoteMountRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x14]; // 0x24(0x14)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeLobbyEmoteMountResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgCustomizeLobbyEmoteMountResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeLobbyEmoteUnmountRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgCustomizeLobbyEmoteUnmountRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeLobbyEmoteUnmountResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgCustomizeLobbyEmoteUnmountResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeNewItemCheckRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgCustomizeNewItemCheckRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeNewItemCheckResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgCustomizeNewItemCheckResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgCustomizeNewItemAlertNotify
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgCustomizeNewItemAlertNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgFriendListRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgFriendListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgFriendListResponse
// Size: 0x38 (Inherited: 0x18)
struct FClientMsgFriendListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x18]; // 0x20(0x18)
};

// ScriptStruct DungeonCrawler.ClientMsgFriendListAllRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgFriendListAllRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgFriendListAllResponse
// Size: 0x38 (Inherited: 0x18)
struct FClientMsgFriendListAllResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x18]; // 0x20(0x18)
};

// ScriptStruct DungeonCrawler.ClientMsgFriendFindRequest
// Size: 0x48 (Inherited: 0x20)
struct FClientMsgFriendFindRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x24]; // 0x24(0x24)
};

// ScriptStruct DungeonCrawler.ClientMsgFriendFindResponse
// Size: 0x90 (Inherited: 0x18)
struct FClientMsgFriendFindResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x70]; // 0x20(0x70)
};

// ScriptStruct DungeonCrawler.ClientMsgGatheringHallChannelListRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgGatheringHallChannelListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgGatheringHallChannelListResponse
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgGatheringHallChannelListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgGatheringHallChannelSelectRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgGatheringHallChannelSelectRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgGatheringHallChannelSelectResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgGatheringHallChannelSelectResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgGatheringHallChannelExitRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgGatheringHallChannelExitRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgGatheringHallChannelExitResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgGatheringHallChannelExitResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgGatheringHallChannelUserListRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgGatheringHallChannelUserListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgGatheringHallChannelUserListResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgGatheringHallChannelUserListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgGatheringHallChannelUserUpdateNotify
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgGatheringHallChannelUserUpdateNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgGatheringHallChannelChatRequest
// Size: 0xb0 (Inherited: 0x20)
struct FClientMsgGatheringHallChannelChatRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x8c]; // 0x24(0x8c)
};

// ScriptStruct DungeonCrawler.ClientMsgGatheringHallChannelChatResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgGatheringHallChannelChatResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgGatheringHallChannelChatNotify
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgGatheringHallChannelChatNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgGatheringHallTargetEquippedItemRequest
// Size: 0x48 (Inherited: 0x20)
struct FClientMsgGatheringHallTargetEquippedItemRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x24]; // 0x24(0x24)
};

// ScriptStruct DungeonCrawler.ClientMsgGatheringHallTargetEquippedItemResponse
// Size: 0x90 (Inherited: 0x18)
struct FClientMsgGatheringHallTargetEquippedItemResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x70]; // 0x20(0x70)
};

// ScriptStruct DungeonCrawler.ClientMsgGmPartyAllRandomRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgGmPartyAllRandomRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgGmPartyAllRandomResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgGmPartyAllRandomResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgEnterGameServerNotify
// Size: 0x80 (Inherited: 0x18)
struct FClientMsgEnterGameServerNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x60]; // 0x20(0x60)
};

// ScriptStruct DungeonCrawler.ClientMsgAutoMatchRegRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgAutoMatchRegRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgAutoMatchRegResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgAutoMatchRegResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgGameEnterCompleteNotify
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgGameEnterCompleteNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgAutoMatchRegTeamNotify
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgAutoMatchRegTeamNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgReconnectIngameRequest
// Size: 0x50 (Inherited: 0x20)
struct FClientMsgReconnectIngameRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x2c]; // 0x24(0x2c)
};

// ScriptStruct DungeonCrawler.ClientMsgReconnectIngameResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgReconnectIngameResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgFloorMatchmakedNotify
// Size: 0x40 (Inherited: 0x18)
struct FClientMsgFloorMatchmakedNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x20]; // 0x20(0x20)
};

// ScriptStruct DungeonCrawler.ClientMsgInventoryInfoRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgInventoryInfoRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgInventoryInfoResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgInventoryInfoResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgInventoryAllUpdateRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgInventoryAllUpdateRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgInventoryAllUpdateResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgInventoryAllUpdateResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgInventoryMoveRequest
// Size: 0x38 (Inherited: 0x20)
struct FClientMsgInventoryMoveRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x14]; // 0x24(0x14)
};

// ScriptStruct DungeonCrawler.ClientMsgInventoryMoveResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgInventoryMoveResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgInventoryMergeRequest
// Size: 0x40 (Inherited: 0x20)
struct FClientMsgInventoryMergeRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x1c]; // 0x24(0x1c)
};

// ScriptStruct DungeonCrawler.ClientMsgInventoryMergeResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgInventoryMergeResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgInventorySwapRequest
// Size: 0x50 (Inherited: 0x20)
struct FClientMsgInventorySwapRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x2c]; // 0x24(0x2c)
};

// ScriptStruct DungeonCrawler.ClientMsgInventorySwapResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgInventorySwapResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgInventorySplitMoveRequest
// Size: 0x40 (Inherited: 0x20)
struct FClientMsgInventorySplitMoveRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x1c]; // 0x24(0x1c)
};

// ScriptStruct DungeonCrawler.ClientMsgInventorySplitMoveResponse
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgInventorySplitMoveResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgInventorySplitMergeRequest
// Size: 0x48 (Inherited: 0x20)
struct FClientMsgInventorySplitMergeRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x24]; // 0x24(0x24)
};

// ScriptStruct DungeonCrawler.ClientMsgInventorySplitMergeResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgInventorySplitMergeResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgInventorySplitSwapRequest
// Size: 0x50 (Inherited: 0x20)
struct FClientMsgInventorySplitSwapRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x2c]; // 0x24(0x2c)
};

// ScriptStruct DungeonCrawler.ClientMsgInventorySplitSwapResponse
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgInventorySplitSwapResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgInventoryTwoHandedWeaponSwapRequest
// Size: 0x48 (Inherited: 0x20)
struct FClientMsgInventoryTwoHandedWeaponSwapRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x24]; // 0x24(0x24)
};

// ScriptStruct DungeonCrawler.ClientMsgInventoryTwoHandedWeaponSwapResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgInventoryTwoHandedWeaponSwapResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgInventorySingleUpdateRequest
// Size: 0x48 (Inherited: 0x20)
struct FClientMsgInventorySingleUpdateRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x24]; // 0x24(0x24)
};

// ScriptStruct DungeonCrawler.ClientMsgInventorySingleUpdateResponse
// Size: 0x40 (Inherited: 0x18)
struct FClientMsgInventorySingleUpdateResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x20]; // 0x20(0x20)
};

// ScriptStruct DungeonCrawler.ClientMsgStorageInfoRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgStorageInfoRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgStorageInfoResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgStorageInfoResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgKarmaReportListRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgKarmaReportListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgKarmaReportListResponse
// Size: 0x38 (Inherited: 0x18)
struct FClientMsgKarmaReportListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x18]; // 0x20(0x18)
};

// ScriptStruct DungeonCrawler.ClientMsgKarmaReportActionRequest
// Size: 0x50 (Inherited: 0x20)
struct FClientMsgKarmaReportActionRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x2c]; // 0x24(0x2c)
};

// ScriptStruct DungeonCrawler.ClientMsgKarmaReportActionResponse
// Size: 0x98 (Inherited: 0x18)
struct FClientMsgKarmaReportActionResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x78]; // 0x20(0x78)
};

// ScriptStruct DungeonCrawler.ClientMsgKarmaRatingUpdateNotify
// Size: 0x40 (Inherited: 0x18)
struct FClientMsgKarmaRatingUpdateNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x20]; // 0x20(0x20)
};

// ScriptStruct DungeonCrawler.ClientMsgCharacterSelectEnterRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgCharacterSelectEnterRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgCharacterSelectEnterResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgCharacterSelectEnterResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgLobbyCharacterInfoRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgLobbyCharacterInfoRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgLobbyCharacterInfoResponse
// Size: 0xb0 (Inherited: 0x18)
struct FClientMsgLobbyCharacterInfoResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x90]; // 0x20(0x90)
};

// ScriptStruct DungeonCrawler.ClientMsgOpenLobbyMapRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgOpenLobbyMapRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgOpenLobbyMapResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgOpenLobbyMapResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgLobbyRegionSelectRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgLobbyRegionSelectRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgLobbyRegionSelectResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgLobbyRegionSelectResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgLobbyEnterFromGameRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgLobbyEnterFromGameRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgLobbyEnterFromGameResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgLobbyEnterFromGameResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgLobbyGameDifficultySelectRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgLobbyGameDifficultySelectRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgLobbyGameDifficultySelectResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgLobbyGameDifficultySelectResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgLobbyAccountCurrencyListNotify
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgLobbyAccountCurrencyListNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgLobbyCharacterLobbyEmoteNotify
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgLobbyCharacterLobbyEmoteNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgLobbyReportPunishListNotify
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgLobbyReportPunishListNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgLobbyEnterCouponCodeRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgLobbyEnterCouponCodeRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgLobbyEnterCouponCodeResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgLobbyEnterCouponCodeResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgMerchantListRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgMerchantListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgMerchantListResponse
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgMerchantListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgMerchantStockBuyItemListRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgMerchantStockBuyItemListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgMerchantStockBuyItemListResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgMerchantStockBuyItemListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgMerchantStockSellBackItemListRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgMerchantStockSellBackItemListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgMerchantStockSellBackItemListResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgMerchantStockSellBackItemListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgMerchantStockBuyRequest
// Size: 0x58 (Inherited: 0x20)
struct FClientMsgMerchantStockBuyRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x34]; // 0x24(0x34)
};

// ScriptStruct DungeonCrawler.ClientMsgMerchantStockBuyResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgMerchantStockBuyResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgMerchantStockSellBackRequest
// Size: 0x40 (Inherited: 0x20)
struct FClientMsgMerchantStockSellBackRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x1c]; // 0x24(0x1c)
};

// ScriptStruct DungeonCrawler.ClientMsgMerchantStockSellBackResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgMerchantStockSellBackResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgMerchantServiceCraftListRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgMerchantServiceCraftListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgMerchantServiceCraftListResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgMerchantServiceCraftListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgMerchantServiceCraftRequest
// Size: 0x70 (Inherited: 0x20)
struct FClientMsgMerchantServiceCraftRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4c]; // 0x24(0x4c)
};

// ScriptStruct DungeonCrawler.ClientMsgMerchantServiceCraftResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgMerchantServiceCraftResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyInviteRequest
// Size: 0x68 (Inherited: 0x20)
struct FClientMsgPartyInviteRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x44]; // 0x24(0x44)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyInviteResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgPartyInviteResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyInviteNotify
// Size: 0x60 (Inherited: 0x18)
struct FClientMsgPartyInviteNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x40]; // 0x20(0x40)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyInviteAnswerRequest
// Size: 0x38 (Inherited: 0x20)
struct FClientMsgPartyInviteAnswerRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x14]; // 0x24(0x14)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyInviteAnswerResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgPartyInviteAnswerResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyInviteAnswerResultNotify
// Size: 0x48 (Inherited: 0x18)
struct FClientMsgPartyInviteAnswerResultNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x28]; // 0x20(0x28)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyExitRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgPartyExitRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyExitResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgPartyExitResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyMemberInfoNotify
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgPartyMemberInfoNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyReadyRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgPartyReadyRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyReadyResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgPartyReadyResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyEquipItemChangeNotify
// Size: 0x58 (Inherited: 0x18)
struct FClientMsgPartyEquipItemChangeNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x38]; // 0x20(0x38)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyRegionChangeNotify
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgPartyRegionChangeNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyLocationUpdateNotify
// Size: 0x40 (Inherited: 0x18)
struct FClientMsgPartyLocationUpdateNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x20]; // 0x20(0x20)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyCharacterSkinListNotify
// Size: 0x48 (Inherited: 0x18)
struct FClientMsgPartyCharacterSkinListNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x28]; // 0x20(0x28)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyCharacterSkinChangeNotify
// Size: 0x58 (Inherited: 0x18)
struct FClientMsgPartyCharacterSkinChangeNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x38]; // 0x20(0x38)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyItemSkinListNotify
// Size: 0x48 (Inherited: 0x18)
struct FClientMsgPartyItemSkinListNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x28]; // 0x20(0x28)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyItemSkinChangeNotify
// Size: 0x58 (Inherited: 0x18)
struct FClientMsgPartyItemSkinChangeNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x38]; // 0x20(0x38)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyGameDifficultyChangeNotify
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgPartyGameDifficultyChangeNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyMemberKickRequest
// Size: 0x40 (Inherited: 0x20)
struct FClientMsgPartyMemberKickRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x1c]; // 0x24(0x1c)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyMemberKickResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgPartyMemberKickResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyChatRequest
// Size: 0x88 (Inherited: 0x20)
struct FClientMsgPartyChatRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x64]; // 0x24(0x64)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyChatResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgPartyChatResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyChatNotify
// Size: 0x88 (Inherited: 0x18)
struct FClientMsgPartyChatNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x68]; // 0x20(0x68)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyReadyChangeNotify
// Size: 0x40 (Inherited: 0x18)
struct FClientMsgPartyReadyChangeNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x20]; // 0x20(0x20)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyKickedOutNotify
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgPartyKickedOutNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyMemberLobbyEmoteNotify
// Size: 0x48 (Inherited: 0x18)
struct FClientMsgPartyMemberLobbyEmoteNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x28]; // 0x20(0x28)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyStartLobbyEmoteRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgPartyStartLobbyEmoteRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyStartLobbyEmoteResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgPartyStartLobbyEmoteResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgPartyStartLobbyEmoteNotify
// Size: 0x48 (Inherited: 0x18)
struct FClientMsgPartyStartLobbyEmoteNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x28]; // 0x20(0x28)
};

// ScriptStruct DungeonCrawler.ClientMsgRankingRangeRequest
// Size: 0x40 (Inherited: 0x20)
struct FClientMsgRankingRangeRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x1c]; // 0x24(0x1c)
};

// ScriptStruct DungeonCrawler.ClientMsgRankingRangeResponse
// Size: 0x50 (Inherited: 0x18)
struct FClientMsgRankingRangeResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x30]; // 0x20(0x30)
};

// ScriptStruct DungeonCrawler.ClientMsgRankingNearbyRequest
// Size: 0x40 (Inherited: 0x20)
struct FClientMsgRankingNearbyRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x1c]; // 0x24(0x1c)
};

// ScriptStruct DungeonCrawler.ClientMsgRankingNearbyResponse
// Size: 0x50 (Inherited: 0x18)
struct FClientMsgRankingNearbyResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x30]; // 0x20(0x30)
};

// ScriptStruct DungeonCrawler.ClientMsgRankingCharacterRequest
// Size: 0x60 (Inherited: 0x20)
struct FClientMsgRankingCharacterRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x3c]; // 0x24(0x3c)
};

// ScriptStruct DungeonCrawler.ClientMsgRankingCharacterResponse
// Size: 0x90 (Inherited: 0x18)
struct FClientMsgRankingCharacterResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x70]; // 0x20(0x70)
};

// ScriptStruct DungeonCrawler.ClientMsgShopCharacterSkinListRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgShopCharacterSkinListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgShopCharacterSkinListResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgShopCharacterSkinListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgShopItemSkinListRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgShopItemSkinListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgShopItemSkinListResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgShopItemSkinListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgShopEmoteListRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgShopEmoteListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgShopEmoteListResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgShopEmoteListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgShopActionListRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgShopActionListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgShopActionListResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgShopActionListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgShopLobbyEmoteListRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgShopLobbyEmoteListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgShopLobbyEmoteListResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgShopLobbyEmoteListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgShopCharacterSkinBuyRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgShopCharacterSkinBuyRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgShopCharacterSkinBuyResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgShopCharacterSkinBuyResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgShopItemSkinBuyRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgShopItemSkinBuyRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgShopItemSkinBuyResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgShopItemSkinBuyResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgShopEmoteBuyRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgShopEmoteBuyRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgShopEmoteBuyResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgShopEmoteBuyResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgShopActionBuyRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgShopActionBuyRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgShopActionBuyResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgShopActionBuyResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgShopLobbyEmoteBuyRequest
// Size: 0x30 (Inherited: 0x20)
struct FClientMsgShopLobbyEmoteBuyRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
};

// ScriptStruct DungeonCrawler.ClientMsgShopLobbyEmoteBuyResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgShopLobbyEmoteBuyResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeChannelListRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgTradeChannelListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeChannelListResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgTradeChannelListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeChannelSelectRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgTradeChannelSelectRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeChannelSelectResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgTradeChannelSelectResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeChannelExitRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgTradeChannelExitRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeChannelExitResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgTradeChannelExitResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeChannelUserListRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgTradeChannelUserListRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeChannelUserListResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgTradeChannelUserListResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeChannelUserUpdateNotify
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgTradeChannelUserUpdateNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeChannelChatRequest
// Size: 0xb0 (Inherited: 0x20)
struct FClientMsgTradeChannelChatRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x8c]; // 0x24(0x8c)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeChannelChatResponse
// Size: 0x30 (Inherited: 0x18)
struct FClientMsgTradeChannelChatResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeChannelChatTextRangeRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgTradeChannelChatTextRangeRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeChannelChatTextRangeResponse
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgTradeChannelChatTextRangeResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeMembershipRequirementRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgTradeMembershipRequirementRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeMembershipRequirementResponse
// Size: 0x28 (Inherited: 0x18)
struct FClientMsgTradeMembershipRequirementResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeMembershipRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgTradeMembershipRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeMembershipResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgTradeMembershipResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeRequestRequest
// Size: 0x68 (Inherited: 0x20)
struct FClientMsgTradeRequestRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x44]; // 0x24(0x44)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeRequestResponse
// Size: 0x48 (Inherited: 0x18)
struct FClientMsgTradeRequestResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x28]; // 0x20(0x28)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeRequestNotify
// Size: 0x50 (Inherited: 0x18)
struct FClientMsgTradeRequestNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x30]; // 0x20(0x30)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeAnswerRequest
// Size: 0x60 (Inherited: 0x20)
struct FClientMsgTradeAnswerRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x3c]; // 0x24(0x3c)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeAnswerResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgTradeAnswerResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgTradeAnswerRefusalNotify
// Size: 0x50 (Inherited: 0x18)
struct FClientMsgTradeAnswerRefusalNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x30]; // 0x20(0x30)
};

// ScriptStruct DungeonCrawler.ClientMsgTradingBeginNotify
// Size: 0x90 (Inherited: 0x18)
struct FClientMsgTradingBeginNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x70]; // 0x20(0x70)
};

// ScriptStruct DungeonCrawler.ClientMsgTradingCloseRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgTradingCloseRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgTradingCloseResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgTradingCloseResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgTradingChatRequest
// Size: 0xb0 (Inherited: 0x20)
struct FClientMsgTradingChatRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x8c]; // 0x24(0x8c)
};

// ScriptStruct DungeonCrawler.ClientMsgTradingChatResponse
// Size: 0xa0 (Inherited: 0x18)
struct FClientMsgTradingChatResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x80]; // 0x20(0x80)
};

// ScriptStruct DungeonCrawler.ClientMsgTradingItemUpdateRequest
// Size: 0x38 (Inherited: 0x20)
struct FClientMsgTradingItemUpdateRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x14]; // 0x24(0x14)
};

// ScriptStruct DungeonCrawler.ClientMsgTradingItemUpdateResponse
// Size: 0x100 (Inherited: 0x18)
struct FClientMsgTradingItemUpdateResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0xe0]; // 0x20(0xe0)
};

// ScriptStruct DungeonCrawler.ClientMsgTradingReadyRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgTradingReadyRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgTradingReadyResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgTradingReadyResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgTradingReadyNotify
// Size: 0x58 (Inherited: 0x18)
struct FClientMsgTradingReadyNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x38]; // 0x20(0x38)
};

// ScriptStruct DungeonCrawler.ClientMsgTradingConfirmNotify
// Size: 0xa8 (Inherited: 0x18)
struct FClientMsgTradingConfirmNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x88]; // 0x20(0x88)
};

// ScriptStruct DungeonCrawler.ClientMsgTradingConfirmReadyRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgTradingConfirmReadyRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgTradingConfirmReadyResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgTradingConfirmReadyResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgTradingConfirmReadyNotify
// Size: 0x58 (Inherited: 0x18)
struct FClientMsgTradingConfirmReadyNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x38]; // 0x20(0x38)
};

// ScriptStruct DungeonCrawler.ClientMsgTradingConfirmCancelRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgTradingConfirmCancelRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgTradingConfirmCancelResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgTradingConfirmCancelResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgTradingResultNotify
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgTradingResultNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgAliveRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgAliveRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgAliveResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgAliveResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.ClientMsgReconnectRequest
// Size: 0x28 (Inherited: 0x20)
struct FClientMsgReconnectRequest : FRequestMsg {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.ClientMsgReconnectResponse
// Size: 0x20 (Inherited: 0x18)
struct FClientMsgReconnectResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.PopupSWidgetData
// Size: 0x20 (Inherited: 0x00)
struct FPopupSWidgetData {
	enum class EPopupButtonType PopupButtonType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FText DescMessage; // 0x08(0x18)
};

// ScriptStruct DungeonCrawler.ContainerSlotArrayData
// Size: 0x10 (Inherited: 0x00)
struct FContainerSlotArrayData {
	struct TArray<struct UContainerSlotWidget*> SlotWidgetArray; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.GameplayEffectDescData
// Size: 0x0c (Inherited: 0x00)
struct FGameplayEffectDescData {
	struct FGameplayTag GameplayTag; // 0x00(0x08)
	int32_t EffectValue; // 0x08(0x04)
};

// ScriptStruct DungeonCrawler.ActorDieData
// Size: 0x1d8 (Inherited: 0x00)
struct FActorDieData {
	bool bAlive; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct UGameplayEffect* GameplayEffectClass; // 0x08(0x08)
	struct FDCGameplayEffectContext EffectContext; // 0x10(0x1c8)
};

// ScriptStruct DungeonCrawler.ImpactEnduranceExhaustedData
// Size: 0x1d8 (Inherited: 0x00)
struct FImpactEnduranceExhaustedData {
	bool bNotExhausted; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct UGameplayEffect* GameplayEffectClass; // 0x08(0x08)
	struct FDCGameplayEffectContext EffectContext; // 0x10(0x1c8)
};

// ScriptStruct DungeonCrawler.DCGameplayEffectSetByCallerData
// Size: 0x0c (Inherited: 0x00)
struct FDCGameplayEffectSetByCallerData {
	struct FGameplayTag SetByCallerTag; // 0x00(0x08)
	float SetByCallerValue; // 0x08(0x04)
};

// ScriptStruct DungeonCrawler.DCGameplayEffectData
// Size: 0x48 (Inherited: 0x00)
struct FDCGameplayEffectData {
	struct FPrimaryAssetId EffectId; // 0x00(0x10)
	struct UGameplayEffect* GameplayEffectClass; // 0x10(0x08)
	struct TArray<struct FDCGameplayEffectSetByCallerData> SetByCallerArray; // 0x18(0x10)
	struct FGameplayTagContainer DynamicGrantedTagContainer; // 0x28(0x20)
};

// ScriptStruct DungeonCrawler.DCGameplayEffectContainer
// Size: 0x58 (Inherited: 0x00)
struct FDCGameplayEffectContainer {
	struct FGameplayTag EventTag; // 0x00(0x08)
	struct UDCTargetType* TargetType; // 0x08(0x08)
	struct FDCGameplayEffectData GameplayEffectData; // 0x10(0x48)
};

// ScriptStruct DungeonCrawler.DCGameplayAbilityData
// Size: 0x28 (Inherited: 0x00)
struct FDCGameplayAbilityData {
	struct FPrimaryAssetId AbilityId; // 0x00(0x10)
	struct UGameplayAbility* GameplayAbilityClass; // 0x10(0x08)
	struct TArray<struct FDCGameplayEffectContainer> GameplayEffectContainerArray; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.DCGameplayAbilityHandleData
// Size: 0x30 (Inherited: 0x00)
struct FDCGameplayAbilityHandleData {
	struct FGameplayAbilitySpecHandle AbilitySpecHandle; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FDCGameplayAbilityData GameplayAbilityData; // 0x08(0x28)
};

// ScriptStruct DungeonCrawler.DCGameplayEffectContainerSpec
// Size: 0x48 (Inherited: 0x00)
struct FDCGameplayEffectContainerSpec {
	struct UDCTargetType* TargetType; // 0x00(0x08)
	struct FGameplayAbilityTargetDataHandle TargetDataHandle; // 0x08(0x28)
	struct TArray<struct FGameplayEffectSpecHandle> TargetGameplayEffectSpecHandles; // 0x30(0x10)
	struct FGameplayTag ContainerTag; // 0x40(0x08)
};

// ScriptStruct DungeonCrawler.InstigatorData
// Size: 0x50 (Inherited: 0x00)
struct FInstigatorData {
	struct FString InstigatorAccountId; // 0x00(0x10)
	struct FNickname InstigatorNickName; // 0x10(0x28)
	struct FText InstigatorName; // 0x38(0x18)
};

// ScriptStruct DungeonCrawler.EffectCauserData
// Size: 0x18 (Inherited: 0x00)
struct FEffectCauserData {
	struct FText EffectCauserName; // 0x00(0x18)
};

// ScriptStruct DungeonCrawler.GameplayAbilityTargetData_SingleTargetHitWithTag
// Size: 0x180 (Inherited: 0x08)
struct FGameplayAbilityTargetData_SingleTargetHitWithTag : FGameplayAbilityTargetData {
	struct FHitResult HitResult; // 0x08(0xe8)
	bool bHitReplaced; // 0xf0(0x01)
	char pad_F1[0x3]; // 0xf1(0x03)
	struct FGameplayTag TargetTag; // 0xf4(0x08)
	struct FGameplayTag ChannelTag; // 0xfc(0x08)
	char pad_104[0x4]; // 0x104(0x04)
	struct FString SocketName; // 0x108(0x10)
	char pad_118[0x8]; // 0x118(0x08)
	struct FTransform ActorPrevTickTransform; // 0x120(0x60)
};

// ScriptStruct DungeonCrawler.DCPropertyEffectData
// Size: 0x1c (Inherited: 0x00)
struct FDCPropertyEffectData {
	struct FGameplayTag PropertyType; // 0x00(0x08)
	struct FPrimaryAssetId PropertyId; // 0x08(0x10)
	int32_t PropertyValue; // 0x18(0x04)
};

// ScriptStruct DungeonCrawler.DCPropertyAttributePerk
// Size: 0x14 (Inherited: 0x00)
struct FDCPropertyAttributePerk {
	struct FPrimaryAssetId PerkId; // 0x00(0x10)
	int32_t PerkValue; // 0x10(0x04)
};

// ScriptStruct DungeonCrawler.DCPropertyAttributeSkill
// Size: 0x14 (Inherited: 0x00)
struct FDCPropertyAttributeSkill {
	struct FPrimaryAssetId SkillId; // 0x00(0x10)
	int32_t SkillValue; // 0x10(0x04)
};

// ScriptStruct DungeonCrawler.DCPropertyAttributeSpell
// Size: 0x14 (Inherited: 0x00)
struct FDCPropertyAttributeSpell {
	struct FPrimaryAssetId SpellId; // 0x00(0x10)
	int32_t SpellValue; // 0x10(0x04)
};

// ScriptStruct DungeonCrawler.DCPropertyAttribute
// Size: 0x30 (Inherited: 0x00)
struct FDCPropertyAttribute {
	struct TArray<struct FDCPropertyAttributePerk> PerkAttributeArray; // 0x00(0x10)
	struct TArray<struct FDCPropertyAttributeSkill> SkillAttributeArray; // 0x10(0x10)
	struct TArray<struct FDCPropertyAttributeSpell> SpellAttributeArray; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataActionSkinTableRow
// Size: 0xa8 (Inherited: 0x08)
struct FDesignDataActionSkinTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDCDesignDataActionSkin> ActionSkin; // 0x08(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayAbility> ActionSkinAbility; // 0x58(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataGameplayAbility
// Size: 0x58 (Inherited: 0x00)
struct FDesignDataGameplayAbility {
	struct FText Name; // 0x00(0x18)
	struct FGameplayTag AttackType; // 0x18(0x08)
	struct UGameplayAbility* Class; // 0x20(0x08)
	struct TArray<struct FPrimaryAssetId> Effects; // 0x28(0x10)
	struct FPrimaryAssetId Desc; // 0x38(0x10)
	struct TArray<struct FPrimaryAssetId> MovementModifiers; // 0x48(0x10)
};

// ScriptStruct DungeonCrawler.DCDesignDataActionSkin
// Size: 0x68 (Inherited: 0x00)
struct FDCDesignDataActionSkin {
	struct FText Name; // 0x00(0x18)
	struct FText FlavorText; // 0x18(0x18)
	enum class EDCActionSkinType ActionSkinType; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	struct FPrimaryAssetId Art; // 0x34(0x10)
	struct FPrimaryAssetId TargetAction; // 0x44(0x10)
	struct FPrimaryAssetId SkinAction; // 0x54(0x10)
	char pad_64[0x4]; // 0x64(0x04)
};

// ScriptStruct DungeonCrawler.DCActionSkinInfo
// Size: 0x10 (Inherited: 0x00)
struct FDCActionSkinInfo {
	struct UDCActionSkinDataAsset* Data; // 0x00(0x08)
	bool bIsEquipped; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct DungeonCrawler.LoadPrimaryAssetType
// Size: 0x10 (Inherited: 0x00)
struct FLoadPrimaryAssetType {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.LoadPrimaryAssetData
// Size: 0x38 (Inherited: 0x10)
struct FLoadPrimaryAssetData : FLoadPrimaryAssetType {
	struct FMulticastInlineDelegate LoadPrimaryAssetDynamicMulticastDelegate; // 0x10(0x10)
	char pad_20[0x18]; // 0x20(0x18)
};

// ScriptStruct DungeonCrawler.DCInventoryBoxView
// Size: 0x20 (Inherited: 0x00)
struct FDCInventoryBoxView {
	struct UDCBoxInventory* Inventory; // 0x00(0x08)
	struct FIntPoint StartPos; // 0x08(0x08)
	struct FIntPoint Size; // 0x10(0x08)
	bool bValid; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.DCChannelPlayerInfo
// Size: 0x58 (Inherited: 0x00)
struct FDCChannelPlayerInfo {
	struct FDCAccountId AccountId; // 0x00(0x10)
	struct FNickname Nickname; // 0x10(0x28)
	enum class EDCCharacterClass CharacterClass; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct FDCCharacterId CharacterId; // 0x40(0x10)
	enum class EDCGender Gender; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	uint32_t Level; // 0x54(0x04)
};

// ScriptStruct DungeonCrawler.DCChannelPlayerWidgetInfo
// Size: 0x68 (Inherited: 0x00)
struct FDCChannelPlayerWidgetInfo {
	struct FDCChannelPlayerInfo ChannelPlayer; // 0x00(0x58)
	struct TArray<enum class EContextOptionType> ContextOptions; // 0x58(0x10)
};

// ScriptStruct DungeonCrawler.AggroRate
// Size: 0x10 (Inherited: 0x00)
struct FAggroRate {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DCPlayerCharacterKey
// Size: 0x02 (Inherited: 0x00)
struct FDCPlayerCharacterKey {
	enum class EDCCharacterClass CharacterClass; // 0x00(0x01)
	enum class EDCGender Gender; // 0x01(0x01)
};

// ScriptStruct DungeonCrawler.DCPlayerCharacterData
// Size: 0x18 (Inherited: 0x00)
struct FDCPlayerCharacterData {
	struct UDesignDataAssetPlayerCharacter* DesignData; // 0x00(0x08)
	struct UDCCharacterPartsArtData* PartsResourceData; // 0x08(0x08)
	struct UArtDataPlayerCharacter* ArtData; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.DesignDataCharacterSkinTableRow
// Size: 0x58 (Inherited: 0x08)
struct FDesignDataCharacterSkinTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataCharacterSkin> CharacterSkin; // 0x08(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataCharacterSkin
// Size: 0x80 (Inherited: 0x00)
struct FDesignDataCharacterSkin {
	struct FText Name; // 0x00(0x18)
	struct FPrimaryAssetId Desc; // 0x18(0x10)
	struct FText FlavorText; // 0x28(0x18)
	struct FPrimaryAssetId Art; // 0x40(0x10)
	struct TArray<struct FPrimaryAssetId> TargetCharacterClasses; // 0x50(0x10)
	struct TArray<struct FPrimaryAssetId> Abilities; // 0x60(0x10)
	struct TArray<struct FPrimaryAssetId> Effects; // 0x70(0x10)
};

// ScriptStruct DungeonCrawler.DCCharacterSkinInfo
// Size: 0x10 (Inherited: 0x00)
struct FDCCharacterSkinInfo {
	struct UDCCharacterSkinDataAsset* Data; // 0x00(0x08)
	bool bIsEquipped; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct DungeonCrawler.DCClientAccountInfo
// Size: 0x1a0 (Inherited: 0x00)
struct FDCClientAccountInfo {
	struct FDCAccountId AccountId; // 0x00(0x10)
	struct TMap<struct FPrimaryAssetId, struct FDCCharacterSkinInfo> CharacterSkins; // 0x10(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDCItemSkinInfo> ItemSkins; // 0x60(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDCEmoteInfo> Emotes; // 0xb0(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDCLobbyEmoteInfo> LobbyEmotes; // 0x100(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDCActionSkinInfo> ActionSkins; // 0x150(0x50)
};

// ScriptStruct DungeonCrawler.DCLobbyEmoteInfo
// Size: 0x10 (Inherited: 0x00)
struct FDCLobbyEmoteInfo {
	struct UDCLobbyEmoteDataAsset* Data; // 0x00(0x08)
	bool bIsEquipped; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	int32_t SlotIndex; // 0x0c(0x04)
};

// ScriptStruct DungeonCrawler.DCEmoteInfo
// Size: 0x10 (Inherited: 0x00)
struct FDCEmoteInfo {
	struct UDCEmoteDataAsset* Data; // 0x00(0x08)
	bool bIsEquipped; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	int32_t SlotIndex; // 0x0c(0x04)
};

// ScriptStruct DungeonCrawler.DCItemSkinInfo
// Size: 0x10 (Inherited: 0x00)
struct FDCItemSkinInfo {
	struct UDCItemSkinDataAsset* Data; // 0x00(0x08)
	bool bIsEquipped; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct DungeonCrawler.DCClientShopInfo
// Size: 0x1e0 (Inherited: 0x00)
struct FDCClientShopInfo {
	struct TMap<struct FPrimaryAssetId, struct FDCCharacterSkinShopItemInfo> CharacterSkinShopItems; // 0x00(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDCItemSkinShopItemInfo> ItemSkinShopItems; // 0x50(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDCEmoteShopItemInfo> EmoteShopItems; // 0xa0(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDCLobbyEmoteShopItemInfo> LobbyEmoteShopItems; // 0xf0(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDCActionSkinShopItemInfo> ActionSkinShopItems; // 0x140(0x50)
	struct TMap<int32_t, int32_t> CurrencyMap; // 0x190(0x50)
};

// ScriptStruct DungeonCrawler.DCActionSkinShopItemInfo
// Size: 0x10 (Inherited: 0x00)
struct FDCActionSkinShopItemInfo {
	struct UDCActionSkinShopDataAsset* Data; // 0x00(0x08)
	bool bIsOwnedItem; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct DungeonCrawler.DCLobbyEmoteShopItemInfo
// Size: 0x10 (Inherited: 0x00)
struct FDCLobbyEmoteShopItemInfo {
	struct UDCLobbyEmoteShopDataAsset* Data; // 0x00(0x08)
	bool bIsOwnedItem; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct DungeonCrawler.DCEmoteShopItemInfo
// Size: 0x10 (Inherited: 0x00)
struct FDCEmoteShopItemInfo {
	struct UDCEmoteShopDataAsset* Data; // 0x00(0x08)
	bool bIsOwnedItem; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct DungeonCrawler.DCItemSkinShopItemInfo
// Size: 0x10 (Inherited: 0x00)
struct FDCItemSkinShopItemInfo {
	struct UDCItemSkinShopDataAsset* Data; // 0x00(0x08)
	bool bIsOwnedItem; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct DungeonCrawler.DCCharacterSkinShopItemInfo
// Size: 0x10 (Inherited: 0x00)
struct FDCCharacterSkinShopItemInfo {
	struct UDCCharacterSkinShopDataAsset* Data; // 0x00(0x08)
	bool bIsOwnedItem; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct DungeonCrawler.DCCommunityCharacterInfo
// Size: 0x50 (Inherited: 0x00)
struct FDCCommunityCharacterInfo {
	struct FDCAccountId AccountId; // 0x00(0x10)
	struct FDCCharacterId CharacterId; // 0x10(0x10)
	struct FNickname Nickname; // 0x20(0x28)
	enum class EDCCharacterClass CharacterClass; // 0x48(0x01)
	enum class EDCGender Gender; // 0x49(0x01)
	char pad_4A[0x6]; // 0x4a(0x06)
};

// ScriptStruct DungeonCrawler.DCMouseClickInfo
// Size: 0xe0 (Inherited: 0x00)
struct FDCMouseClickInfo {
	struct FGeometry Geometry; // 0x00(0x40)
	struct FPointerEvent MouseEvent; // 0x40(0x98)
	bool bIsValid; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
};

// ScriptStruct DungeonCrawler.DesignDataItemSkin
// Size: 0x58 (Inherited: 0x00)
struct FDesignDataItemSkin {
	struct FText Name; // 0x00(0x18)
	struct FText FlavorText; // 0x18(0x18)
	struct AItemActor* ItemActor; // 0x30(0x08)
	struct AProjectileActor* ProjectileActor; // 0x38(0x08)
	struct FPrimaryAssetId Art; // 0x40(0x10)
	struct FGameplayTag TargetItem; // 0x50(0x08)
};

// ScriptStruct DungeonCrawler.DesignDataLobbyEmote
// Size: 0x78 (Inherited: 0x00)
struct FDesignDataLobbyEmote {
	struct FText Name; // 0x00(0x18)
	struct FPrimaryAssetId Desc; // 0x18(0x10)
	struct FText FlavorText; // 0x28(0x18)
	struct FGameplayTag LobbyEmoteTag; // 0x40(0x08)
	struct FPrimaryAssetId ArtData; // 0x48(0x10)
	struct TArray<struct FPrimaryAssetId> Abilities; // 0x58(0x10)
	struct TArray<struct FPrimaryAssetId> Effects; // 0x68(0x10)
};

// ScriptStruct DungeonCrawler.PlayerPointData
// Size: 0x70 (Inherited: 0x00)
struct FPlayerPointData {
	struct AActor* PlayerStartPIE; // 0x00(0x08)
	char pad_8[0x68]; // 0x08(0x68)
};

// ScriptStruct DungeonCrawler.ServerInfo
// Size: 0x30 (Inherited: 0x00)
struct FServerInfo {
	struct FString ServerAddress; // 0x00(0x10)
	struct FString ServerName; // 0x10(0x10)
	struct FString ServerDescription; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.LineCollisionMarkerSocket
// Size: 0x48 (Inherited: 0x00)
struct FLineCollisionMarkerSocket {
	struct USkeletalMeshSocket* Socket; // 0x00(0x08)
	struct FString SocketName; // 0x08(0x10)
	struct FVector PrevSocketLocation; // 0x18(0x18)
	struct FGameplayTag EffectTag; // 0x30(0x08)
	struct FGameplayTag ChannelTag; // 0x38(0x08)
	enum class ECollisionChannel CollisionChannel; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// ScriptStruct DungeonCrawler.DCIdTagGroupItemData
// Size: 0x08 (Inherited: 0x00)
struct FDCIdTagGroupItemData {
	struct FGameplayTag IdTag; // 0x00(0x08)
};

// ScriptStruct DungeonCrawler.DCIngameUser
// Size: 0x150 (Inherited: 0x00)
struct FDCIngameUser {
	char pad_0[0x30]; // 0x00(0x30)
	struct UDCCharacterSkinDataAsset* CharacterSkin; // 0x30(0x08)
	struct TArray<struct UDCItemSkinDataAsset*> ItemSkins; // 0x38(0x10)
	struct TMap<int32_t, struct UDCEmoteDataAsset*> Emotes; // 0x48(0x50)
	struct TArray<struct UDCActionSkinDataAsset*> ActionSkins; // 0x98(0x10)
	struct TArray<struct FDCReportedInfo> ReportedInfoArray; // 0xa8(0x10)
	char pad_B8[0x98]; // 0xb8(0x98)
};

// ScriptStruct DungeonCrawler.DCReportedInfo
// Size: 0x18 (Inherited: 0x00)
struct FDCReportedInfo {
	struct FDCAccountId TargetAccountId; // 0x00(0x10)
	enum class EDCReportPlayerCategory ReportCategory; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	int32_t ReportCount; // 0x14(0x04)
};

// ScriptStruct DungeonCrawler.DCInputAction
// Size: 0x10 (Inherited: 0x00)
struct FDCInputAction {
	struct UInputAction* InputAction; // 0x00(0x08)
	struct FGameplayTag InputTag; // 0x08(0x08)
};

// ScriptStruct DungeonCrawler.DCInventoryData
// Size: 0x20 (Inherited: 0x00)
struct FDCInventoryData {
	struct TArray<int32_t> Indexes; // 0x00(0x10)
	struct TArray<struct FDCItemInfo> Values; // 0x10(0x10)
};

// ScriptStruct DungeonCrawler.DCItemInfo
// Size: 0x118 (Inherited: 0x00)
struct FDCItemInfo {
	struct FDCItemId ID; // 0x00(0x08)
	struct UDCItemDataAsset* DataAsset; // 0x08(0x08)
	int32_t Stack; // 0x10(0x04)
	int32_t InnerStack; // 0x14(0x04)
	struct FDCAccountId OwnerAccountId; // 0x18(0x10)
	struct TArray<struct FDCGameplayAbilityData> SelfAbilities; // 0x28(0x10)
	struct TArray<struct FDCGameplayEffectData> SelfEffects; // 0x38(0x10)
	struct TArray<struct FDCGameplayAbilityData> OwnerAbilities; // 0x48(0x10)
	struct TArray<struct FDCGameplayEffectData> OwnerEffects; // 0x58(0x10)
	struct TArray<struct FDCPropertyEffectData> Properties; // 0x68(0x10)
	struct FItemData ItemData; // 0x78(0xa0)
};

// ScriptStruct DungeonCrawler.DCInt64IdBase
// Size: 0x08 (Inherited: 0x00)
struct FDCInt64IdBase {
	int64_t _; // 0x00(0x08)
};

// ScriptStruct DungeonCrawler.DCItemId
// Size: 0x08 (Inherited: 0x08)
struct FDCItemId : FDCInt64IdBase {
	int64_t _; // 0x00(0x08)
};

// ScriptStruct DungeonCrawler.DCInventoryBuilder
// Size: 0x20 (Inherited: 0x00)
struct FDCInventoryBuilder {
	struct TArray<struct UDCInventoryBase*> InventoryList; // 0x00(0x10)
	struct TArray<struct FDCInventoryTask> InventoryTasks; // 0x10(0x10)
};

// ScriptStruct DungeonCrawler.DCInventoryTask
// Size: 0x178 (Inherited: 0x00)
struct FDCInventoryTask {
	enum class EDCInventoryTaskType TaskType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FDCInventoryTaskSourceInfo Source; // 0x08(0x128)
	struct FDCInventoryTaskTargetInfo Target; // 0x130(0x10)
	struct FDCInventoryTaskTargetAuxInfo TargetAux; // 0x140(0x38)
};

// ScriptStruct DungeonCrawler.DCInventoryTaskTargetAuxInfo
// Size: 0x38 (Inherited: 0x00)
struct FDCInventoryTaskTargetAuxInfo {
	char pad_0[0x38]; // 0x00(0x38)
};

// ScriptStruct DungeonCrawler.DCInventoryTaskTargetInfo
// Size: 0x10 (Inherited: 0x00)
struct FDCInventoryTaskTargetInfo {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DCInventoryTaskSourceInfo
// Size: 0x128 (Inherited: 0x00)
struct FDCInventoryTaskSourceInfo {
	char pad_0[0x128]; // 0x00(0x128)
};

// ScriptStruct DungeonCrawler.DDCItemBundleInfoItem
// Size: 0x38 (Inherited: 0x00)
struct FDDCItemBundleInfoItem {
	struct TSoftObjectPtr<UArtDataItem> BundleArtData; // 0x00(0x30)
	int32_t BundleGrade; // 0x30(0x04)
	int32_t ItemMinCount; // 0x34(0x04)
};

// ScriptStruct DungeonCrawler.DDCItemPropertyItem
// Size: 0x40 (Inherited: 0x00)
struct FDDCItemPropertyItem {
	struct TSoftObjectPtr<UDCItemPropertyTypeDataAsset> PropertyTypeId; // 0x00(0x30)
	int32_t MinValue; // 0x30(0x04)
	int32_t MaxValue; // 0x34(0x04)
	int32_t PropertyRate; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataItemSkinTableRow
// Size: 0x58 (Inherited: 0x08)
struct FDesignDataItemSkinTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataItemSkin> ItemSkin; // 0x08(0x50)
};

// ScriptStruct DungeonCrawler.DCLobbyEmoteSlotInfo
// Size: 0x14 (Inherited: 0x00)
struct FDCLobbyEmoteSlotInfo {
	struct FPrimaryAssetId LobbyEmoteId; // 0x00(0x10)
	int32_t SlotIndex; // 0x10(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataLobbyEmoteTableRow
// Size: 0xf8 (Inherited: 0x08)
struct FDesignDataLobbyEmoteTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataLobbyEmote> LobbyEmote; // 0x08(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayAbility> LobbyEmoteAbility; // 0x58(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayEffect> LobbyEmoteEffect; // 0xa8(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataGameplayEffect
// Size: 0x188 (Inherited: 0x00)
struct FDesignDataGameplayEffect {
	struct UGameplayEffect* EffectClass; // 0x00(0x08)
	struct FGameplayTag EventTag; // 0x08(0x08)
	enum class EGameplayEffectTargetType TargetType; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	int32_t Duration; // 0x14(0x04)
	int32_t StrengthBase; // 0x18(0x04)
	int32_t StrengthMod; // 0x1c(0x04)
	int32_t AgilityBase; // 0x20(0x04)
	int32_t AgilityMod; // 0x24(0x04)
	int32_t WillBase; // 0x28(0x04)
	int32_t WillMod; // 0x2c(0x04)
	int32_t KnowledgeBase; // 0x30(0x04)
	int32_t KnowledgeMod; // 0x34(0x04)
	int32_t ResourcefulnessBase; // 0x38(0x04)
	int32_t ResourcefulnessMod; // 0x3c(0x04)
	int32_t ExecDamageWeaponRatio; // 0x40(0x04)
	int32_t PhysicalDamageWeapon; // 0x44(0x04)
	int32_t PhysicalDamageBase; // 0x48(0x04)
	int32_t ExecPhysicalDamageBase; // 0x4c(0x04)
	int32_t PhysicalPower; // 0x50(0x04)
	int32_t PhysicalDamageMod; // 0x54(0x04)
	int32_t PhysicalDamageAdd; // 0x58(0x04)
	int32_t PhysicalDamageTrue; // 0x5c(0x04)
	int32_t ExecPhysicalDamageTrue; // 0x60(0x04)
	int32_t PhysicalBackstabPower; // 0x64(0x04)
	int32_t PhysicalHeadshotPower; // 0x68(0x04)
	int32_t PhysicalHeadshotPenetration; // 0x6c(0x04)
	int32_t ArmorPenetration; // 0x70(0x04)
	int32_t ExecArmorPenetration; // 0x74(0x04)
	int32_t ArmorRating; // 0x78(0x04)
	int32_t ItemArmorRatingMod; // 0x7c(0x04)
	int32_t PhysicalReduction; // 0x80(0x04)
	int32_t PhysicalReductionMod; // 0x84(0x04)
	int32_t PhysicalAbsoluteReduction; // 0x88(0x04)
	int32_t MagicalDamageWeapon; // 0x8c(0x04)
	int32_t MagicalDamageBase; // 0x90(0x04)
	int32_t ExecMagicalDamageBase; // 0x94(0x04)
	int32_t MagicalPower; // 0x98(0x04)
	int32_t MagicalDamageMod; // 0x9c(0x04)
	int32_t MagicalDamageAdd; // 0xa0(0x04)
	int32_t MagicalDamageTrue; // 0xa4(0x04)
	int32_t ExecMagicalDamageTrue; // 0xa8(0x04)
	int32_t MagicPenetration; // 0xac(0x04)
	int32_t ExecMagicPenetration; // 0xb0(0x04)
	int32_t MagicalFireDamageBase; // 0xb4(0x04)
	int32_t MagicalFireDamageMod; // 0xb8(0x04)
	int32_t MagicalFireDamageAdd; // 0xbc(0x04)
	int32_t MagicalArcaneDamageBase; // 0xc0(0x04)
	int32_t MagicalArcaneDamageMod; // 0xc4(0x04)
	int32_t MagicalArcaneDamageAdd; // 0xc8(0x04)
	int32_t MagicResistance; // 0xcc(0x04)
	int32_t MagicalReduction; // 0xd0(0x04)
	int32_t MagicalReductionMod; // 0xd4(0x04)
	int32_t MagicalAbsoluteReduction; // 0xd8(0x04)
	int32_t HeadshotReductionMod; // 0xdc(0x04)
	int32_t ProjectileReductionMod; // 0xe0(0x04)
	int32_t ImpactPower; // 0xe4(0x04)
	int32_t ExecImpactPower; // 0xe8(0x04)
	int32_t ExecImpactEnduranceRestore; // 0xec(0x04)
	int32_t ImpactResistance; // 0xf0(0x04)
	int32_t MaxImpactEndurance; // 0xf4(0x04)
	int32_t ExecAddHealthByCurHealthRatio; // 0xf8(0x04)
	int32_t ExecAddHealthByMaxHealthRatio; // 0xfc(0x04)
	int32_t PhysicalHealBase; // 0x100(0x04)
	int32_t ExecPhysicalHealBase; // 0x104(0x04)
	int32_t MagicalHealBase; // 0x108(0x04)
	int32_t ExecMagicalHealBase; // 0x10c(0x04)
	int32_t ExecRecoveryHealBase; // 0x110(0x04)
	int32_t MaxHealthMod; // 0x114(0x04)
	int32_t MaxHealthAdd; // 0x118(0x04)
	int32_t AddtionalAggroMod; // 0x11c(0x04)
	int32_t MaxPhysicalShield; // 0x120(0x04)
	int32_t MaxMagicalShield; // 0x124(0x04)
	int32_t MaxTotalShield; // 0x128(0x04)
	int32_t SpellCapacityMod; // 0x12c(0x04)
	int32_t SpellCapacityAdd; // 0x130(0x04)
	int32_t MoveSpeedBase; // 0x134(0x04)
	int32_t MoveSpeedMod; // 0x138(0x04)
	int32_t MoveSpeedAdd; // 0x13c(0x04)
	int32_t MoveSpeedArmorPenaltyMod; // 0x140(0x04)
	int32_t ActionSpeed; // 0x144(0x04)
	int32_t SpellCastingSpeed; // 0x148(0x04)
	int32_t ItemEquipSpeed; // 0x14c(0x04)
	int32_t RegularInteractionSpeed; // 0x150(0x04)
	int32_t MagicalInteractionSpeed; // 0x154(0x04)
	int32_t BuffDurationMod; // 0x158(0x04)
	int32_t DebuffDurationMod; // 0x15c(0x04)
	int32_t UtilityEffectivenessMod; // 0x160(0x04)
	int32_t UtilityEffectivenessAdd; // 0x164(0x04)
	int32_t WeightLimitMod; // 0x168(0x04)
	int32_t WeightLimitAdd; // 0x16c(0x04)
	int32_t PrestigeItemDrop; // 0x170(0x04)
	char pad_174[0x4]; // 0x174(0x04)
	struct TArray<struct FGameplayTag> Tags; // 0x178(0x10)
};

// ScriptStruct DungeonCrawler.DCLogEventInfo
// Size: 0x30 (Inherited: 0x00)
struct FDCLogEventInfo {
	int64_t Timestamp; // 0x00(0x08)
	struct FDCAccountId AccountId; // 0x08(0x10)
	enum class EDCLogEventType LogEventType; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct TArray<struct FString> Params; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.DCLootDropItemData
// Size: 0x38 (Inherited: 0x00)
struct FDCLootDropItemData {
	struct TSoftObjectPtr<UDCItemDataAsset> ItemId; // 0x00(0x30)
	int32_t ItemCount; // 0x30(0x04)
	int32_t ItemRate; // 0x34(0x04)
};

// ScriptStruct DungeonCrawler.LoadedMappableConfigPair
// Size: 0x10 (Inherited: 0x00)
struct FLoadedMappableConfigPair {
	struct UPlayerMappableInputConfig* Config; // 0x00(0x08)
	enum class ECommonInputType Type; // 0x08(0x01)
	bool bIsActive; // 0x09(0x01)
	char pad_A[0x6]; // 0x0a(0x06)
};

// ScriptStruct DungeonCrawler.MappableConfigPair
// Size: 0x58 (Inherited: 0x00)
struct FMappableConfigPair {
	struct UPlayerMappableInputConfig* Config; // 0x00(0x08)
	enum class ECommonInputType Type; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct FGameplayTagContainer DependentPlatformTraits; // 0x10(0x20)
	struct FGameplayTagContainer ExcludedPlatformTraits; // 0x30(0x20)
	bool bShouldActivateAutomatically; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
};

// ScriptStruct DungeonCrawler.DCMerchantAssetManager
// Size: 0x140 (Inherited: 0x00)
struct FDCMerchantAssetManager {
	struct TMap<struct FDCMerchantSaleItemId, struct UDCStockBuyDataAsset*> SaleDataAssets; // 0x00(0x50)
	struct TMap<struct FDCMerchantWishItemId, struct UDCStockSellBackDataAsset*> WishDataAssets; // 0x50(0x50)
	struct TMap<struct FDCMerchantCraftItemId, struct UDCStockCraftDataAsset*> CraftDataAssets; // 0xa0(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDCMerchantWishItemId> WishListItemDataAssetIds; // 0xf0(0x50)
};

// ScriptStruct DungeonCrawler.DCMerchantWishItemId
// Size: 0x08 (Inherited: 0x08)
struct FDCMerchantWishItemId : FDCInt64IdBase {
	int64_t _; // 0x00(0x08)
};

// ScriptStruct DungeonCrawler.DCMerchantCraftItemId
// Size: 0x08 (Inherited: 0x08)
struct FDCMerchantCraftItemId : FDCInt64IdBase {
	int64_t _; // 0x00(0x08)
};

// ScriptStruct DungeonCrawler.DCMerchantSaleItemId
// Size: 0x08 (Inherited: 0x08)
struct FDCMerchantSaleItemId : FDCInt64IdBase {
	int64_t _; // 0x00(0x08)
};

// ScriptStruct DungeonCrawler.DCStockSellBackItemData
// Size: 0x100 (Inherited: 0x00)
struct FDCStockSellBackItemData {
	int64_t UniqueId; // 0x00(0x08)
	struct FText ConversationText; // 0x08(0x18)
	struct TSoftObjectPtr<UDCItemDataAsset> ItemId; // 0x20(0x30)
	int32_t ItemCount; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
	struct TSoftObjectPtr<UDCItemDataAsset> ReceivedItemId_01; // 0x58(0x30)
	int32_t ReceivedAmount01; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
	struct TSoftObjectPtr<UDCItemDataAsset> ReceivedItemId_02; // 0x90(0x30)
	int32_t ReceivedAmount02; // 0xc0(0x04)
	char pad_C4[0x4]; // 0xc4(0x04)
	struct TSoftObjectPtr<UDCItemDataAsset> ReceivedItemId_03; // 0xc8(0x30)
	int32_t ReceivedAmount03; // 0xf8(0x04)
	char pad_FC[0x4]; // 0xfc(0x04)
};

// ScriptStruct DungeonCrawler.DCStockBuyItemData
// Size: 0x180 (Inherited: 0x00)
struct FDCStockBuyItemData {
	int64_t UniqueId; // 0x00(0x08)
	struct FText ConversationText; // 0x08(0x18)
	struct FText SaleCompleteText; // 0x20(0x18)
	struct TSoftObjectPtr<UDCItemDataAsset> ItemId; // 0x38(0x30)
	struct TSoftObjectPtr<UDCItemDataAsset> RequiredItemId_01; // 0x68(0x30)
	int32_t RequiredAmount01; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
	struct TSoftObjectPtr<UDCItemDataAsset> RequiredItemId_02; // 0xa0(0x30)
	int32_t RequiredAmount02; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)
	struct TSoftObjectPtr<UDCItemDataAsset> RequiredItemId_03; // 0xd8(0x30)
	int32_t RequiredAmount03; // 0x108(0x04)
	char pad_10C[0x4]; // 0x10c(0x04)
	struct TSoftObjectPtr<UDCItemDataAsset> RequiredItemId_04; // 0x110(0x30)
	int32_t RequiredAmount04; // 0x140(0x04)
	char pad_144[0x4]; // 0x144(0x04)
	struct TSoftObjectPtr<UDCItemDataAsset> RequiredItemId_05; // 0x148(0x30)
	int32_t RequiredAmount05; // 0x178(0x04)
	char pad_17C[0x4]; // 0x17c(0x04)
};

// ScriptStruct DungeonCrawler.DCStockCraftItemData
// Size: 0x180 (Inherited: 0x00)
struct FDCStockCraftItemData {
	int64_t UniqueId; // 0x00(0x08)
	struct FText ConversationText; // 0x08(0x18)
	struct FText CraftCompleteText; // 0x20(0x18)
	struct TSoftObjectPtr<UDCItemDataAsset> ItemId; // 0x38(0x30)
	struct TSoftObjectPtr<UDCItemDataAsset> RequiredItemId_01; // 0x68(0x30)
	int32_t RequiredAmount01; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
	struct TSoftObjectPtr<UDCItemDataAsset> RequiredItemId_02; // 0xa0(0x30)
	int32_t RequiredAmount02; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)
	struct TSoftObjectPtr<UDCItemDataAsset> RequiredItemId_03; // 0xd8(0x30)
	int32_t RequiredAmount03; // 0x108(0x04)
	char pad_10C[0x4]; // 0x10c(0x04)
	struct TSoftObjectPtr<UDCItemDataAsset> RequiredItemId_04; // 0x110(0x30)
	int32_t RequiredAmount04; // 0x140(0x04)
	char pad_144[0x4]; // 0x144(0x04)
	struct TSoftObjectPtr<UDCItemDataAsset> RequiredItemId_05; // 0x148(0x30)
	int32_t RequiredAmount05; // 0x178(0x04)
	char pad_17C[0x4]; // 0x17c(0x04)
};

// ScriptStruct DungeonCrawler.DCMerchantInfo
// Size: 0x18 (Inherited: 0x00)
struct FDCMerchantInfo {
	struct FDCMerchantId MerchantId; // 0x00(0x10)
	int32_t Faction; // 0x10(0x04)
	float ExpireTime; // 0x14(0x04)
};

// ScriptStruct DungeonCrawler.DCMerchantId
// Size: 0x10 (Inherited: 0x10)
struct FDCMerchantId : FDCStringIdBase {
	struct FString _; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.AggroInfo
// Size: 0x10 (Inherited: 0x00)
struct FAggroInfo {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DCMovementModiferContainer
// Size: 0x10 (Inherited: 0x00)
struct FDCMovementModiferContainer {
	struct TArray<struct FPrimaryAssetId> MovementModifierArray; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DCPartyInfo
// Size: 0x30 (Inherited: 0x00)
struct FDCPartyInfo {
	struct FDCPartyId PartyId; // 0x00(0x10)
	struct TArray<struct FDCAccountId> MemberAccounts; // 0x10(0x10)
	struct FDCAccountId LeaderAccount; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.DCPlayerInfo
// Size: 0x90 (Inherited: 0x00)
struct FDCPlayerInfo {
	struct FDCAccountId AccountId; // 0x00(0x10)
	int32_t AccountIdx; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FNickname Nickname; // 0x18(0x28)
	enum class EDCCharacterClass CharacterClass; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct FDCPartyId PartyId; // 0x48(0x10)
	char pad_58[0x10]; // 0x58(0x10)
	enum class EDCGender Gender; // 0x68(0x01)
	char pad_69[0x3]; // 0x69(0x03)
	int32_t Level; // 0x6c(0x04)
	enum class EDCOnlineState OnlineState; // 0x70(0x01)
	enum class EDCDungeonState DungeonState; // 0x71(0x01)
	bool bAlive; // 0x72(0x01)
	bool bDataLoad; // 0x73(0x01)
	char pad_74[0x4]; // 0x74(0x04)
	struct TArray<struct FActorStatusData> ActorStatuses; // 0x78(0x10)
	float HealthRate; // 0x88(0x04)
	float RecoverableHealthRate; // 0x8c(0x04)
};

// ScriptStruct DungeonCrawler.DCRecruitChannelInfo
// Size: 0x18 (Inherited: 0x00)
struct FDCRecruitChannelInfo {
	struct FDCRecruitChannelIndex Index; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct UDCChatRoomDataAsset* Data; // 0x08(0x08)
	int32_t GroupIndex; // 0x10(0x04)
	uint32_t NumMembers; // 0x14(0x04)
};

// ScriptStruct DungeonCrawler.DCInt32IdBase
// Size: 0x04 (Inherited: 0x00)
struct FDCInt32IdBase {
	int32_t _; // 0x00(0x04)
};

// ScriptStruct DungeonCrawler.DCRecruitChannelIndex
// Size: 0x04 (Inherited: 0x04)
struct FDCRecruitChannelIndex : FDCInt32IdBase {
	int32_t _; // 0x00(0x04)
};

// ScriptStruct DungeonCrawler.DCRecruitInspectInfo
// Size: 0x68 (Inherited: 0x00)
struct FDCRecruitInspectInfo {
	struct FDCChannelPlayerInfo ChannelPlayer; // 0x00(0x58)
	struct TArray<struct FDCItemInfo> Items; // 0x58(0x10)
};

// ScriptStruct DungeonCrawler.DCConnectionAlwaysRelevantNodePair
// Size: 0x10 (Inherited: 0x00)
struct FDCConnectionAlwaysRelevantNodePair {
	struct UNetConnection* NetConnection; // 0x00(0x08)
	struct UReplicationGraphNode_AlwaysRelevant_ForConnection* Node; // 0x08(0x08)
};

// ScriptStruct DungeonCrawler.DCReportPlayerInfo
// Size: 0x70 (Inherited: 0x00)
struct FDCReportPlayerInfo {
	struct FDCAccountId ReporterAccountId; // 0x00(0x10)
	struct FDCAccountId TargetAccountId; // 0x10(0x10)
	struct FNickname TargetNickname; // 0x20(0x28)
	struct FDCCharacterId TargetCharacterId; // 0x48(0x10)
	enum class EDCReportPlayerCategory ReportCategory; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct FString ReportText; // 0x60(0x10)
};

// ScriptStruct DungeonCrawler.DCReportPlayerResultInfo
// Size: 0x30 (Inherited: 0x00)
struct FDCReportPlayerResultInfo {
	struct FNickname TargetNickname; // 0x00(0x28)
	struct FDateTime ProcessedDate; // 0x28(0x08)
};

// ScriptStruct DungeonCrawler.DCSpawnerItemData
// Size: 0x98 (Inherited: 0x00)
struct FDCSpawnerItemData {
	struct TSoftObjectPtr<UDCLootDropDataAsset> ItemHolderLootDropId; // 0x00(0x30)
	struct TSoftObjectPtr<UDCMonsterDataAsset> MonsterId; // 0x30(0x30)
	struct TSoftObjectPtr<UDCPropsDataAsset> PropsId; // 0x60(0x30)
	int32_t SpawnRate; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
};

// ScriptStruct DungeonCrawler.DCGameLiftSessionId
// Size: 0x10 (Inherited: 0x10)
struct FDCGameLiftSessionId : FDCStringIdBase {
	struct FString _; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DCRecruitChannelId
// Size: 0x10 (Inherited: 0x10)
struct FDCRecruitChannelId : FDCStringIdBase {
	struct FString _; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DCConstantDataType
// Size: 0x02 (Inherited: 0x00)
struct FDCConstantDataType {
	enum class EDesignDataConstantType ConstantType; // 0x00(0x01)
	bool UseABS; // 0x01(0x01)
};

// ScriptStruct DungeonCrawler.DCAbilityDataAsset
// Size: 0x14 (Inherited: 0x00)
struct FDCAbilityDataAsset {
	struct FPrimaryAssetId AbilityAssetId; // 0x00(0x10)
	enum class EAbilityDataAssetType AbilityDataParam; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
};

// ScriptStruct DungeonCrawler.DesignDataPlayerCharacter
// Size: 0xd0 (Inherited: 0x00)
struct FDesignDataPlayerCharacter {
	struct FText Name; // 0x00(0x18)
	struct FPrimaryAssetId Dialog; // 0x18(0x10)
	struct FPrimaryAssetId ClassInfo; // 0x28(0x10)
	struct FPrimaryAssetId ArtData; // 0x38(0x10)
	struct FPrimaryAssetId SoundData; // 0x48(0x10)
	bool CanUse; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct TArray<struct FPrimaryAssetId> BaseItems; // 0x60(0x10)
	struct TArray<struct FPrimaryAssetId> Skills; // 0x70(0x10)
	struct TArray<struct FPrimaryAssetId> Spells; // 0x80(0x10)
	struct TArray<struct FPrimaryAssetId> Emotes; // 0x90(0x10)
	struct TArray<struct FPrimaryAssetId> Abilities; // 0xa0(0x10)
	struct TArray<struct FPrimaryAssetId> Effects; // 0xb0(0x10)
	struct TArray<struct FPrimaryAssetId> Perks; // 0xc0(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataMonster
// Size: 0x68 (Inherited: 0x00)
struct FDesignDataMonster {
	struct FText Name; // 0x00(0x18)
	struct FPrimaryAssetId ArtData; // 0x18(0x10)
	struct FPrimaryAssetId SoundData; // 0x28(0x10)
	struct ADCMonsterBase* ActorClass; // 0x38(0x08)
	struct TArray<struct FPrimaryAssetId> Abilities; // 0x40(0x10)
	struct TArray<struct FPrimaryAssetId> Effects; // 0x50(0x10)
	int32_t AdvPoint; // 0x60(0x04)
	int32_t ExpPoint; // 0x64(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataAoe
// Size: 0x58 (Inherited: 0x00)
struct FDesignDataAoe {
	struct FText Name; // 0x00(0x18)
	struct FPrimaryAssetId ArtData; // 0x18(0x10)
	struct FPrimaryAssetId SoundData; // 0x28(0x10)
	struct TArray<struct FPrimaryAssetId> Abilities; // 0x38(0x10)
	struct TArray<struct FPrimaryAssetId> Effects; // 0x48(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataProps
// Size: 0x90 (Inherited: 0x00)
struct FDesignDataProps {
	struct FText Name; // 0x00(0x18)
	struct FPrimaryAssetId ArtData; // 0x18(0x10)
	struct FPrimaryAssetId SoundData; // 0x28(0x10)
	struct APropsActorBase* ActorClass; // 0x38(0x08)
	int32_t InteractionMinCount; // 0x40(0x04)
	int32_t InteractionMaxCount; // 0x44(0x04)
	struct TArray<struct FPrimaryAssetId> InteractionSettingDatas; // 0x48(0x10)
	struct TArray<struct FPrimaryAssetId> DestructibleTagQueryData; // 0x58(0x10)
	struct TArray<struct FPrimaryAssetId> Abilities; // 0x68(0x10)
	struct TArray<struct FPrimaryAssetId> Effects; // 0x78(0x10)
	int32_t AdvPoint; // 0x88(0x04)
	int32_t ExpPoint; // 0x8c(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataPropsInteract
// Size: 0xa0 (Inherited: 0x00)
struct FDesignDataPropsInteract {
	struct FText InteractionName; // 0x00(0x18)
	struct FText InteractionText; // 0x18(0x18)
	struct FPrimaryAssetId InteractData; // 0x30(0x10)
	struct TArray<struct FGameplayTag> InteractTypes; // 0x40(0x10)
	float Duration; // 0x50(0x04)
	struct FGameplayTag InteractableTag; // 0x54(0x08)
	struct FGameplayTag TriggerTag; // 0x5c(0x08)
	struct FGameplayTag AbilityTriggerTag; // 0x64(0x08)
	struct FPrimaryAssetId DetectTagQueryData; // 0x6c(0x10)
	struct FPrimaryAssetId InteractTagQueryData; // 0x7c(0x10)
	struct FPrimaryAssetId SkillCheckData; // 0x8c(0x10)
	char pad_9C[0x4]; // 0x9c(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataPropsSkillCheck
// Size: 0x30 (Inherited: 0x00)
struct FDesignDataPropsSkillCheck {
	struct FGameplayTag SkillCheckType; // 0x00(0x08)
	float MinDuration; // 0x08(0x04)
	float MaxDuration; // 0x0c(0x04)
	float MinSkillCheckInterval; // 0x10(0x04)
	float MaxSkillCheckInterval; // 0x14(0x04)
	float MinSucceedSectionStartTime; // 0x18(0x04)
	float SucceedSectionSizeSeconds; // 0x1c(0x04)
	float SucceedBonusTimeRatio; // 0x20(0x04)
	float PerfectSucceedSectionSizeSeconds; // 0x24(0x04)
	float PerfectSucceedBonusTimeRatio; // 0x28(0x04)
	float FailedBonusTimeRatio; // 0x2c(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataItem
// Size: 0x188 (Inherited: 0x00)
struct FDesignDataItem {
	struct FGameplayTag IdTag; // 0x00(0x08)
	struct FPrimaryAssetId OriginId; // 0x08(0x10)
	struct FText Name; // 0x18(0x18)
	struct FText FlavorText; // 0x30(0x18)
	struct FGameplayTag SlotType; // 0x48(0x08)
	struct FGameplayTag HandType; // 0x50(0x08)
	struct TArray<struct FGameplayTag> WeaponTypes; // 0x58(0x10)
	struct FGameplayTag ArmorType; // 0x68(0x08)
	struct FGameplayTag UtilityType; // 0x70(0x08)
	struct FGameplayTag AccessoryType; // 0x78(0x08)
	struct FGameplayTag MiscType; // 0x80(0x08)
	struct FGameplayTag RarityType; // 0x88(0x08)
	int32_t MaxCount; // 0x90(0x04)
	int32_t MaxAmmoCount; // 0x94(0x04)
	bool CanDrop; // 0x98(0x01)
	bool CanSaveIntoDatabase; // 0x99(0x01)
	char pad_9A[0x2]; // 0x9a(0x02)
	struct FPrimaryAssetId ArtData; // 0x9c(0x10)
	struct FPrimaryAssetId SoundData; // 0xac(0x10)
	struct FPrimaryAssetId ConsumeData; // 0xbc(0x10)
	char pad_CC[0x4]; // 0xcc(0x04)
	struct AItemActor* ActorClass; // 0xd0(0x08)
	struct AItemHolderActorBase* ItemHolderActorClass; // 0xd8(0x08)
	int32_t InventoryWidth; // 0xe0(0x04)
	int32_t InventoryHeight; // 0xe4(0x04)
	float WearingDelayTime; // 0xe8(0x04)
	char pad_EC[0x4]; // 0xec(0x04)
	struct TArray<struct FPrimaryAssetId> SelfAbilities; // 0xf0(0x10)
	struct TArray<struct FPrimaryAssetId> SelfEffects; // 0x100(0x10)
	struct TArray<struct FPrimaryAssetId> Abilities; // 0x110(0x10)
	struct TArray<struct FPrimaryAssetId> Effects; // 0x120(0x10)
	struct FPrimaryAssetId PrimaryProperty; // 0x130(0x10)
	struct TArray<struct FPrimaryAssetId> SecondaryProperties; // 0x140(0x10)
	struct FPrimaryAssetId Requirement; // 0x150(0x10)
	struct FPrimaryAssetId BundleInfo; // 0x160(0x10)
	struct FPrimaryAssetId ContainerData; // 0x170(0x10)
	int32_t AdvPoint; // 0x180(0x04)
	int32_t ExpPoint; // 0x184(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataItemPropertyType
// Size: 0x58 (Inherited: 0x00)
struct FDesignDataItemPropertyType {
	struct FGameplayTag PropertyType; // 0x00(0x08)
	struct FPrimaryAssetId PerkId; // 0x08(0x10)
	struct FPrimaryAssetId SkillId; // 0x18(0x10)
	struct FPrimaryAssetId SpellId; // 0x28(0x10)
	struct UGameplayEffect* EffectClass; // 0x38(0x08)
	struct FGameplayTag EffectType; // 0x40(0x08)
	float ValueRatio; // 0x48(0x04)
	int32_t PrimaryTooltipPriority; // 0x4c(0x04)
	int32_t SecondaryTooltipPriority; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataItemPropertyItem
// Size: 0x1c (Inherited: 0x00)
struct FDesignDataItemPropertyItem {
	struct FPrimaryAssetId PropertyTypeId; // 0x00(0x10)
	int32_t MinValue; // 0x10(0x04)
	int32_t MaxValue; // 0x14(0x04)
	int32_t PropertyRate; // 0x18(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataItemProperty
// Size: 0x10 (Inherited: 0x00)
struct FDesignDataItemProperty {
	struct TArray<struct FDesignDataItemPropertyItem> ItemPropertyItemArray; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataItemConsume
// Size: 0x20 (Inherited: 0x00)
struct FDesignDataItemConsume {
	struct FText ConsumeText; // 0x00(0x18)
	float ConsumeDuration; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataItemRequirement
// Size: 0x38 (Inherited: 0x00)
struct FDesignDataItemRequirement {
	struct TArray<struct FPrimaryAssetId> ClassRequirements; // 0x00(0x10)
	int32_t StrengthRequirement; // 0x10(0x04)
	int32_t AgilityRequirement; // 0x14(0x04)
	int32_t WillRequirement; // 0x18(0x04)
	int32_t KnowledgeRequirement; // 0x1c(0x04)
	int32_t ResourcefulRequirement; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct TArray<struct FPrimaryAssetId> PerkRequirements; // 0x28(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataItemBundleInfoItem
// Size: 0x18 (Inherited: 0x00)
struct FDesignDataItemBundleInfoItem {
	struct FPrimaryAssetId BundleArtData; // 0x00(0x10)
	int32_t BundleGrade; // 0x10(0x04)
	int32_t ItemMinCount; // 0x14(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataItemBundleInfo
// Size: 0x10 (Inherited: 0x00)
struct FDesignDataItemBundleInfo {
	struct TArray<struct FDesignDataItemBundleInfoItem> ItemBundleInfoItemArray; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataItemContainer
// Size: 0x14 (Inherited: 0x00)
struct FDesignDataItemContainer {
	struct FPrimaryAssetId ContentsItemId; // 0x00(0x10)
	int32_t MaxContentsCount; // 0x10(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataLootDropItem
// Size: 0x18 (Inherited: 0x00)
struct FDesignDataLootDropItem {
	struct FPrimaryAssetId ItemId; // 0x00(0x10)
	int32_t ItemCount; // 0x10(0x04)
	int32_t ItemRate; // 0x14(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataLootDrop
// Size: 0x10 (Inherited: 0x00)
struct FDesignDataLootDrop {
	struct TArray<struct FDesignDataLootDropItem> LootDropItemArray; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataSkill
// Size: 0xc0 (Inherited: 0x00)
struct FDesignDataSkill {
	struct FText Name; // 0x00(0x18)
	struct FPrimaryAssetId DescData; // 0x18(0x10)
	bool CanUse; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct TArray<struct FPrimaryAssetId> Classes; // 0x30(0x10)
	struct FGameplayTag SkillType; // 0x40(0x08)
	int32_t SkillTier; // 0x48(0x04)
	bool CanRecharge; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	int32_t MaxCount; // 0x50(0x04)
	float CastingTime; // 0x54(0x04)
	float ChannelingDuration; // 0x58(0x04)
	float ChannelingInterval; // 0x5c(0x04)
	int32_t Range; // 0x60(0x04)
	bool UseMoving; // 0x64(0x01)
	bool NeedAimTarget; // 0x65(0x01)
	char pad_66[0x2]; // 0x66(0x02)
	struct FGameplayTag SkillTag; // 0x68(0x08)
	struct FGameplayTag SkillCooldownTag; // 0x70(0x08)
	struct ASkillActor* ActorClass; // 0x78(0x08)
	struct FPrimaryAssetId ArtData; // 0x80(0x10)
	struct FPrimaryAssetId SoundData; // 0x90(0x10)
	struct TArray<struct FPrimaryAssetId> Abilities; // 0xa0(0x10)
	struct TArray<struct FPrimaryAssetId> Effects; // 0xb0(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataSpawnerItem
// Size: 0x34 (Inherited: 0x00)
struct FDesignDataSpawnerItem {
	struct FPrimaryAssetId ItemHolderLootDropId; // 0x00(0x10)
	struct FPrimaryAssetId MonsterId; // 0x10(0x10)
	struct FPrimaryAssetId PropsId; // 0x20(0x10)
	int32_t SpawnRate; // 0x30(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataSpawner
// Size: 0x10 (Inherited: 0x00)
struct FDesignDataSpawner {
	struct TArray<struct FDesignDataSpawnerItem> SpawnerItemArray; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataProjectile
// Size: 0x68 (Inherited: 0x00)
struct FDesignDataProjectile {
	struct FText Name; // 0x00(0x18)
	struct FGameplayTag SourceType; // 0x18(0x08)
	struct FPrimaryAssetId ArtData; // 0x20(0x10)
	struct FPrimaryAssetId SoundData; // 0x30(0x10)
	struct AProjectileActor* ActorClass; // 0x40(0x08)
	struct TArray<struct FPrimaryAssetId> Abilities; // 0x48(0x10)
	struct TArray<struct FPrimaryAssetId> Effects; // 0x58(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataSpell
// Size: 0xb8 (Inherited: 0x00)
struct FDesignDataSpell {
	struct FText Name; // 0x00(0x18)
	struct FPrimaryAssetId Desc; // 0x18(0x10)
	struct TArray<struct FPrimaryAssetId> Classes; // 0x28(0x10)
	struct FGameplayTag CastingType; // 0x38(0x08)
	struct FGameplayTag SourceType; // 0x40(0x08)
	int32_t SpellTier; // 0x48(0x04)
	int32_t MaxCount; // 0x4c(0x04)
	float CastingTime; // 0x50(0x04)
	float ChannelingDuration; // 0x54(0x04)
	float ChannelingInterval; // 0x58(0x04)
	int32_t Range; // 0x5c(0x04)
	float AreaRange; // 0x60(0x04)
	struct FGameplayTag SpellTag; // 0x64(0x08)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct ASpellActor* ActorClass; // 0x70(0x08)
	struct FPrimaryAssetId ArtData; // 0x78(0x10)
	struct FPrimaryAssetId SoundData; // 0x88(0x10)
	struct TArray<struct FPrimaryAssetId> Abilities; // 0x98(0x10)
	struct TArray<struct FPrimaryAssetId> Effects; // 0xa8(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataMusic
// Size: 0xa8 (Inherited: 0x00)
struct FDesignDataMusic {
	struct FText Name; // 0x00(0x18)
	struct FPrimaryAssetId Desc; // 0x18(0x10)
	struct FGameplayTag PlayType; // 0x28(0x08)
	struct FGameplayTag SourceType; // 0x30(0x08)
	float PlayTime; // 0x38(0x04)
	float ChannelingDuration; // 0x3c(0x04)
	float ChannelingInterval; // 0x40(0x04)
	int32_t Range; // 0x44(0x04)
	struct FGameplayTag MusicTag; // 0x48(0x08)
	struct AMusicActor* ActorClass; // 0x50(0x08)
	struct FPrimaryAssetId ArtData; // 0x58(0x10)
	struct FPrimaryAssetId SoundData; // 0x68(0x10)
	struct FPrimaryAssetId PlayMusicData; // 0x78(0x10)
	struct TArray<struct FPrimaryAssetId> Abilities; // 0x88(0x10)
	struct TArray<struct FPrimaryAssetId> Effects; // 0x98(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataPerk
// Size: 0x88 (Inherited: 0x00)
struct FDesignDataPerk {
	struct FText Name; // 0x00(0x18)
	struct FPrimaryAssetId DescData; // 0x18(0x10)
	bool CanUse; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct TArray<struct FPrimaryAssetId> Classes; // 0x30(0x10)
	float Radius; // 0x40(0x04)
	struct FPrimaryAssetId IdTagGroup; // 0x44(0x10)
	struct FPrimaryAssetId ArtData; // 0x54(0x10)
	char pad_64[0x4]; // 0x64(0x04)
	struct TArray<struct FPrimaryAssetId> Abilities; // 0x68(0x10)
	struct TArray<struct FPrimaryAssetId> Effects; // 0x78(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataDesc
// Size: 0x68 (Inherited: 0x00)
struct FDesignDataDesc {
	struct FText DescFormat; // 0x00(0x18)
	struct FString DescParam1; // 0x18(0x10)
	struct FString DescParam2; // 0x28(0x10)
	struct FString DescParam3; // 0x38(0x10)
	struct FString DescParam4; // 0x48(0x10)
	struct FString DescParam5; // 0x58(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataMeleeAttack
// Size: 0x54 (Inherited: 0x00)
struct FDesignDataMeleeAttack {
	float DamageRatio; // 0x00(0x04)
	float HitPlayRate; // 0x04(0x04)
	float HitPlayRateDuration; // 0x08(0x04)
	bool CanStuckByHitBox; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	float CharacterStuckPlayRate; // 0x10(0x04)
	float CharacterStuckPlayRateDuration; // 0x14(0x04)
	float CharacterStuckBlendOutTime; // 0x18(0x04)
	bool CanStuckByShield; // 0x1c(0x01)
	char pad_1D[0x3]; // 0x1d(0x03)
	float WeakShieldStuckPlayRate; // 0x20(0x04)
	float WeakShieldStuckPlayRateDuration; // 0x24(0x04)
	float WeakShieldStuckBlendOutTime; // 0x28(0x04)
	float MidShieldStuckPlayRate; // 0x2c(0x04)
	float MidShieldStuckPlayRateDuration; // 0x30(0x04)
	float MidShieldStuckBlendOutTime; // 0x34(0x04)
	float HeavyShieldStuckPlayRate; // 0x38(0x04)
	float HeavyShieldStuckPlayRateDuration; // 0x3c(0x04)
	float HeavyShieldStuckBlendOutTime; // 0x40(0x04)
	bool CanStuckByStaticObject; // 0x44(0x01)
	char pad_45[0x3]; // 0x45(0x03)
	float StaticObjectStuckPlayRate; // 0x48(0x04)
	float StaticObjectStuckPlayRateDuration; // 0x4c(0x04)
	float StaticObjectStuckBlendOutTime; // 0x50(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataBaseItem
// Size: 0xa0 (Inherited: 0x00)
struct FDesignDataBaseItem {
	struct FPrimaryAssetId BaseItem1Id; // 0x00(0x10)
	int32_t BaseItem1Count; // 0x10(0x04)
	struct FPrimaryAssetId BaseItem2Id; // 0x14(0x10)
	int32_t BaseItem2Count; // 0x24(0x04)
	struct FPrimaryAssetId BaseItem3Id; // 0x28(0x10)
	int32_t BaseItem3Count; // 0x38(0x04)
	struct FPrimaryAssetId BaseItem4Id; // 0x3c(0x10)
	int32_t BaseItem4Count; // 0x4c(0x04)
	struct FPrimaryAssetId BaseItem5Id; // 0x50(0x10)
	int32_t BaseItem5Count; // 0x60(0x04)
	struct FPrimaryAssetId BaseItem6Id; // 0x64(0x10)
	int32_t BaseItem6Count; // 0x74(0x04)
	struct FPrimaryAssetId BaseItem7Id; // 0x78(0x10)
	int32_t BaseItem7Count; // 0x88(0x04)
	struct FPrimaryAssetId BaseItem8Id; // 0x8c(0x10)
	int32_t BaseItem8Count; // 0x9c(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataFloorRuleItem
// Size: 0x40 (Inherited: 0x00)
struct FDesignDataFloorRuleItem {
	float DeathSwarmSize; // 0x00(0x04)
	struct FGameplayTag DeathSwarmAbilityTag; // 0x04(0x08)
	int32_t DisplayPhaseDuration; // 0x0c(0x04)
	struct TArray<struct FPrimaryAssetId> DisplayPhaseFloorPortalArray; // 0x10(0x10)
	int32_t ShrinkPhaseDuration; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct TArray<struct FPrimaryAssetId> ShrinkPhaseFloorPortalArray; // 0x28(0x10)
	bool HideDeathSwarmTimer; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct DungeonCrawler.DesignDataFloorRule
// Size: 0x10 (Inherited: 0x00)
struct FDesignDataFloorRule {
	struct TArray<struct FDesignDataFloorRuleItem> FloorRuleItemArray; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataFloorPortal
// Size: 0x0c (Inherited: 0x00)
struct FDesignDataFloorPortal {
	struct FGameplayTag PortalType; // 0x00(0x08)
	int32_t PortalScrollNum; // 0x08(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataMovementModifier
// Size: 0x08 (Inherited: 0x00)
struct FDesignDataMovementModifier {
	int32_t Add; // 0x00(0x04)
	float Multiply; // 0x04(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataMerchant
// Size: 0x40 (Inherited: 0x00)
struct FDesignDataMerchant {
	struct FText Name; // 0x00(0x18)
	struct FText GreetingText; // 0x18(0x18)
	struct FPrimaryAssetId ArtData; // 0x30(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataMerchantSchedule
// Size: 0x01 (Inherited: 0x00)
struct FDesignDataMerchantSchedule {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct DungeonCrawler.DesignDataStockBuyItem
// Size: 0xb0 (Inherited: 0x00)
struct FDesignDataStockBuyItem {
	int64_t UniqueId; // 0x00(0x08)
	struct FText ConversationText; // 0x08(0x18)
	struct FText SaleCompleteText; // 0x20(0x18)
	struct FPrimaryAssetId ItemId; // 0x38(0x10)
	struct FPrimaryAssetId RequiredItemId_01; // 0x48(0x10)
	int32_t RequiredAmount01; // 0x58(0x04)
	struct FPrimaryAssetId RequiredItemId_02; // 0x5c(0x10)
	int32_t RequiredAmount02; // 0x6c(0x04)
	struct FPrimaryAssetId RequiredItemId_03; // 0x70(0x10)
	int32_t RequiredAmount03; // 0x80(0x04)
	struct FPrimaryAssetId RequiredItemId_04; // 0x84(0x10)
	int32_t RequiredAmount04; // 0x94(0x04)
	struct FPrimaryAssetId RequiredItemId_05; // 0x98(0x10)
	int32_t RequiredAmount05; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataStockBuy
// Size: 0x10 (Inherited: 0x00)
struct FDesignDataStockBuy {
	struct TArray<struct FDesignDataStockBuyItem> StockBuyItemArray; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataStockSellBackItem
// Size: 0x70 (Inherited: 0x00)
struct FDesignDataStockSellBackItem {
	int64_t UniqueId; // 0x00(0x08)
	struct FText ConversationText; // 0x08(0x18)
	struct FPrimaryAssetId ItemId; // 0x20(0x10)
	int32_t ItemCount; // 0x30(0x04)
	struct FPrimaryAssetId ReceivedItemId_01; // 0x34(0x10)
	int32_t ReceivedAmount01; // 0x44(0x04)
	struct FPrimaryAssetId ReceivedItemId_02; // 0x48(0x10)
	int32_t ReceivedAmount02; // 0x58(0x04)
	struct FPrimaryAssetId ReceivedItemId_03; // 0x5c(0x10)
	int32_t ReceivedAmount03; // 0x6c(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataStockSellBack
// Size: 0x10 (Inherited: 0x00)
struct FDesignDataStockSellBack {
	struct TArray<struct FDesignDataStockSellBackItem> StockSellBackItemArray; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataStockCraftItem
// Size: 0xb0 (Inherited: 0x00)
struct FDesignDataStockCraftItem {
	int64_t UniqueId; // 0x00(0x08)
	struct FText ConversationText; // 0x08(0x18)
	struct FText CraftCompleteText; // 0x20(0x18)
	struct FPrimaryAssetId ItemId; // 0x38(0x10)
	struct FPrimaryAssetId RequiredItemId_01; // 0x48(0x10)
	int32_t RequiredAmount01; // 0x58(0x04)
	struct FPrimaryAssetId RequiredItemId_02; // 0x5c(0x10)
	int32_t RequiredAmount02; // 0x6c(0x04)
	struct FPrimaryAssetId RequiredItemId_03; // 0x70(0x10)
	int32_t RequiredAmount03; // 0x80(0x04)
	struct FPrimaryAssetId RequiredItemId_04; // 0x84(0x10)
	int32_t RequiredAmount04; // 0x94(0x04)
	struct FPrimaryAssetId RequiredItemId_05; // 0x98(0x10)
	int32_t RequiredAmount05; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataStockCraft
// Size: 0x10 (Inherited: 0x00)
struct FDesignDataStockCraft {
	struct TArray<struct FDesignDataStockCraftItem> StockCraftItemArray; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataConstant
// Size: 0x08 (Inherited: 0x00)
struct FDesignDataConstant {
	float FloatValue; // 0x00(0x04)
	int32_t Int32Value; // 0x04(0x04)
};

// ScriptStruct DungeonCrawler.DesignDataEmote
// Size: 0x78 (Inherited: 0x00)
struct FDesignDataEmote {
	struct FText Name; // 0x00(0x18)
	struct FPrimaryAssetId Desc; // 0x18(0x10)
	struct FText FlavorText; // 0x28(0x18)
	struct FGameplayTag EmoteTag; // 0x40(0x08)
	struct FPrimaryAssetId ArtData; // 0x48(0x10)
	struct TArray<struct FPrimaryAssetId> Abilities; // 0x58(0x10)
	struct TArray<struct FPrimaryAssetId> Effects; // 0x68(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataIdTagGroupItem
// Size: 0x08 (Inherited: 0x00)
struct FDesignDataIdTagGroupItem {
	struct FGameplayTag IdTag; // 0x00(0x08)
};

// ScriptStruct DungeonCrawler.DesignDataIdTagGroup
// Size: 0x10 (Inherited: 0x00)
struct FDesignDataIdTagGroup {
	struct TArray<struct FDesignDataIdTagGroupItem> IdTagGroupItemArray; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataDungeon
// Size: 0x60 (Inherited: 0x00)
struct FDesignDataDungeon {
	struct FText Name; // 0x00(0x18)
	enum class EGameDifficultyType GameDifficultyType; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	int32_t Floor; // 0x1c(0x04)
	struct FPrimaryAssetId FloorRule; // 0x20(0x10)
	struct TSoftObjectPtr<UWorld> LevelAsset; // 0x30(0x30)
};

// ScriptStruct DungeonCrawler.DesignDataShop
// Size: 0x24 (Inherited: 0x00)
struct FDesignDataShop {
	struct FPrimaryAssetId StockData; // 0x00(0x10)
	int32_t Price; // 0x10(0x04)
	struct FPrimaryAssetId ArtData; // 0x14(0x10)
};

// ScriptStruct DungeonCrawler.DesignDataChatRoom
// Size: 0x58 (Inherited: 0x00)
struct FDesignDataChatRoom {
	struct FText Name; // 0x00(0x18)
	int32_t Order; // 0x18(0x04)
	enum class EChatRoomCategoryType ChatRoomCategoryType; // 0x1c(0x01)
	char pad_1D[0x3]; // 0x1d(0x03)
	struct TArray<struct FGameplayTag> AllowedItemLinkTypes; // 0x20(0x10)
	struct TArray<struct FPrimaryAssetId> AllowedItemLinkClassIds; // 0x30(0x10)
	struct FText AllowedAllowedItemLinkDesc; // 0x40(0x18)
};

// ScriptStruct DungeonCrawler.DesignDataPlayerCharacterTableRow
// Size: 0x148 (Inherited: 0x08)
struct FDesignDataPlayerCharacterTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataPlayerCharacter> PlayerCharacter; // 0x08(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayAbility> PlayerCharacterAbility; // 0x58(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayEffect> PlayerCharacterEffect; // 0xa8(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataBaseItem> PlayerCharacterBaseItem; // 0xf8(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataMonsterTableRow
// Size: 0xf8 (Inherited: 0x08)
struct FDesignDataMonsterTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataMonster> Monster; // 0x08(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayAbility> MonsterAbility; // 0x58(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayEffect> MonsterEffect; // 0xa8(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataAoeTableRow
// Size: 0xf8 (Inherited: 0x08)
struct FDesignDataAoeTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataAoe> Aoe; // 0x08(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayAbility> AoeAbility; // 0x58(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayEffect> AoeEffect; // 0xa8(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataPropsTableRow
// Size: 0x198 (Inherited: 0x08)
struct FDesignDataPropsTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataProps> Props; // 0x08(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayAbility> PropsAbility; // 0x58(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayEffect> PropsEffect; // 0xa8(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataPropsInteract> PropsInteract; // 0xf8(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataPropsSkillCheck> PropsSkillCheck; // 0x148(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataItemTableRow
// Size: 0x238 (Inherited: 0x08)
struct FDesignDataItemTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataItem> Item; // 0x08(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayAbility> ItemAbility; // 0x58(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayEffect> ItemEffect; // 0xa8(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataItemConsume> ItemConsume; // 0xf8(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataItemRequirement> ItemRequirement; // 0x148(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataItemBundleInfo> ItemBundleInfo; // 0x198(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataItemContainer> ItemContainer; // 0x1e8(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataItemPropertyTableRow
// Size: 0xa8 (Inherited: 0x08)
struct FDesignDataItemPropertyTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataItemProperty> ItemProperty; // 0x08(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataItemPropertyType> ItemPropertyType; // 0x58(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataLootDropTableRow
// Size: 0x58 (Inherited: 0x08)
struct FDesignDataLootDropTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataLootDrop> LootDrop; // 0x08(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataSpawnerTableRow
// Size: 0x58 (Inherited: 0x08)
struct FDesignDataSpawnerTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataSpawner> Spawner; // 0x08(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataProjectileTableRow
// Size: 0xf8 (Inherited: 0x08)
struct FDesignDataProjectileTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataProjectile> Projectile; // 0x08(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayAbility> ProjectileAbility; // 0x58(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayEffect> ProjectileEffect; // 0xa8(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataMeleeAttackTableRow
// Size: 0x58 (Inherited: 0x08)
struct FDesignDataMeleeAttackTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataMeleeAttack> MeleeAttack; // 0x08(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataSkillTableRow
// Size: 0xf8 (Inherited: 0x08)
struct FDesignDataSkillTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataSkill> Skill; // 0x08(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayAbility> SkillAbility; // 0x58(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayEffect> SkillEffect; // 0xa8(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataSpellTableRow
// Size: 0xf8 (Inherited: 0x08)
struct FDesignDataSpellTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataSpell> Spell; // 0x08(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayAbility> SpellAbility; // 0x58(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayEffect> SpellEffect; // 0xa8(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataPerkTableRow
// Size: 0xf8 (Inherited: 0x08)
struct FDesignDataPerkTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataPerk> Perk; // 0x08(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayAbility> PerkAbility; // 0x58(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayEffect> PerkEffect; // 0xa8(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataActorStatusTableRow
// Size: 0x58 (Inherited: 0x08)
struct FDesignDataActorStatusTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayEffect> StatusEffect; // 0x08(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataMusicTableRow
// Size: 0xf8 (Inherited: 0x08)
struct FDesignDataMusicTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataMusic> Music; // 0x08(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayAbility> MusicAbility; // 0x58(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayEffect> MusicEffect; // 0xa8(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataMovementModifierTableRow
// Size: 0x58 (Inherited: 0x08)
struct FDesignDataMovementModifierTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataMovementModifier> MovementModifier; // 0x08(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataMerchantTableRow
// Size: 0x198 (Inherited: 0x08)
struct FDesignDataMerchantTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataMerchant> Merchant; // 0x08(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataMerchantSchedule> MerchantSchedule; // 0x58(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataStockBuy> StockBuy; // 0xa8(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataStockSellBack> StockSellBack; // 0xf8(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataStockCraft> StockCraft; // 0x148(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataFloorRuleTableRow
// Size: 0xa8 (Inherited: 0x08)
struct FDesignDataFloorRuleTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataFloorRule> FloorRule; // 0x08(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataFloorPortal> FloorPortal; // 0x58(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataConstantTableRow
// Size: 0x58 (Inherited: 0x08)
struct FDesignDataConstantTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataConstant> Constant; // 0x08(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataEmoteTableRow
// Size: 0xf8 (Inherited: 0x08)
struct FDesignDataEmoteTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataEmote> Emote; // 0x08(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayAbility> EmoteAbility; // 0x58(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataGameplayEffect> EmoteEffect; // 0xa8(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataIdTagGroupTableRow
// Size: 0x58 (Inherited: 0x08)
struct FDesignDataIdTagGroupTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataIdTagGroup> IdTagGroup; // 0x08(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataDungeonTableRow
// Size: 0x58 (Inherited: 0x08)
struct FDesignDataDungeonTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataDungeon> Dungeon; // 0x08(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataShopTableRow
// Size: 0x198 (Inherited: 0x08)
struct FDesignDataShopTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataShop> ShopCharacterSkin; // 0x08(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataShop> ShopItemSkin; // 0x58(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataShop> ShopEmote; // 0xa8(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataShop> ShopLobbyEmote; // 0xf8(0x50)
	struct TMap<struct FPrimaryAssetId, struct FDesignDataShop> ShopActionSkin; // 0x148(0x50)
};

// ScriptStruct DungeonCrawler.DesignDataChatTableRow
// Size: 0x58 (Inherited: 0x08)
struct FDesignDataChatTableRow : FTableRowBase {
	struct TMap<struct FPrimaryAssetId, struct FDesignDataChatRoom> ChatRoom; // 0x08(0x50)
};

// ScriptStruct DungeonCrawler.DevMsgGm
// Size: 0x38 (Inherited: 0x18)
struct FDevMsgGm : FMsgBase {
	struct FString Cmd; // 0x18(0x10)
	struct FString AccountId; // 0x28(0x10)
};

// ScriptStruct DungeonCrawler.DevMsgUIToggle
// Size: 0x18 (Inherited: 0x18)
struct FDevMsgUIToggle : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.DCEmoteSlotInfo
// Size: 0x14 (Inherited: 0x00)
struct FDCEmoteSlotInfo {
	struct FPrimaryAssetId EmoteId; // 0x00(0x10)
	int32_t SlotIndex; // 0x10(0x04)
};

// ScriptStruct DungeonCrawler.EquipmentQuickSlotInfo
// Size: 0x20 (Inherited: 0x00)
struct FEquipmentQuickSlotInfo {
	int32_t CurrentSlotIndex; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<struct UEquipmentSlot*> SlotArray; // 0x08(0x10)
	bool bActive; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgSample
// Size: 0x18 (Inherited: 0x18)
struct FMsgSample : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgSampleRequest
// Size: 0x18 (Inherited: 0x18)
struct FMsgSampleRequest : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgSampleResponse
// Size: 0x18 (Inherited: 0x18)
struct FMsgSampleResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.FriendInfo
// Size: 0x20 (Inherited: 0x00)
struct FFriendInfo {
	int32_t TotalCount; // 0x00(0x04)
	int32_t LobbyCount; // 0x04(0x04)
	int32_t DungeonCount; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct TArray<struct FInvitePartyUserSlot> InvitePartyUserSlotArray; // 0x10(0x10)
};

// ScriptStruct DungeonCrawler.FunctionTrigger
// Size: 0x70 (Inherited: 0x00)
struct FFunctionTrigger {
	char pad_0[0x70]; // 0x00(0x70)
};

// ScriptStruct DungeonCrawler.GameActorStatusSlotWidgetData
// Size: 0x20 (Inherited: 0x00)
struct FGameActorStatusSlotWidgetData {
	struct FActorStatusData ActorStatusData; // 0x00(0x20)
};

// ScriptStruct DungeonCrawler.GameInteractionDescriptionWidgetData
// Size: 0x78 (Inherited: 0x00)
struct FGameInteractionDescriptionWidgetData {
	struct FInteractTargetData InteractTargetData; // 0x00(0x20)
	struct TMap<struct FGameplayTag, struct FInteractionData> InteractableDataByStateMap; // 0x20(0x50)
	enum class ECommonInputType InputType; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// ScriptStruct DungeonCrawler.InteractionData
// Size: 0x90 (Inherited: 0x00)
struct FInteractionData {
	struct FText InteractionName; // 0x00(0x18)
	struct FText InteractionText; // 0x18(0x18)
	struct UInteractData* InteractDataAsset; // 0x30(0x08)
	float Duration; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FGameplayTagContainer InteractTypes; // 0x40(0x20)
	struct FGameplayTag TriggerTag; // 0x60(0x08)
	struct FGameplayTag AbilityTriggerTag; // 0x68(0x08)
	struct UTagQueryData* DetectTagQueryData; // 0x70(0x08)
	struct UTagQueryData* InteractTagQueryData; // 0x78(0x08)
	struct FPrimaryAssetId SkillCheckDataId; // 0x80(0x10)
};

// ScriptStruct DungeonCrawler.InteractTargetData
// Size: 0x20 (Inherited: 0x00)
struct FInteractTargetData {
	struct FText InteractTargetName; // 0x00(0x18)
	struct FGameplayTag RarityType; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.KeyboardInputBinding
// Size: 0xa8 (Inherited: 0x00)
struct FKeyboardInputBinding {
	struct FEnhancedActionKeyMapping InputMapping; // 0x00(0x88)
	char pad_88[0x20]; // 0x88(0x20)
};

// ScriptStruct DungeonCrawler.MiniMapDeathSwarmData
// Size: 0x38 (Inherited: 0x00)
struct FMiniMapDeathSwarmData {
	enum class EFloorRulePhase FloorRulePhase; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float LerpRatio; // 0x04(0x04)
	struct FVector2D PosLerpFrom; // 0x08(0x10)
	float SizeLerpFrom; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FVector2D PosLerpTo; // 0x20(0x10)
	float SizeLerpTo; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct DungeonCrawler.MsgGameAISet
// Size: 0x20 (Inherited: 0x18)
struct FMsgGameAISet : FMsgBase {
	struct UBehaviorTree* BehaviorTree; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgGameAnnounceNotify
// Size: 0xa8 (Inherited: 0x18)
struct FMsgGameAnnounceNotify : FMsgBase {
	struct FGameAnnounceData GameAnnounceData; // 0x18(0x90)
};

// ScriptStruct DungeonCrawler.GameAnnounceData
// Size: 0x90 (Inherited: 0x00)
struct FGameAnnounceData {
	struct FText FormatText; // 0x00(0x18)
	struct FText ParamText_1; // 0x18(0x18)
	struct FText ParamText_2; // 0x30(0x18)
	struct FText ParamText_3; // 0x48(0x18)
	struct FText ParamText_4; // 0x60(0x18)
	struct FText ParamText_5; // 0x78(0x18)
};

// ScriptStruct DungeonCrawler.MsgGameStateNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgGameStateNotify : FMsgBase {
	struct FGameStateData GameStateData; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.GameStateData
// Size: 0x08 (Inherited: 0x00)
struct FGameStateData {
	enum class EGameStateType GameState; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float ServerWorldTime; // 0x04(0x04)
};

// ScriptStruct DungeonCrawler.MsgGameKillLogNotify
// Size: 0x100 (Inherited: 0x18)
struct FMsgGameKillLogNotify : FMsgBase {
	struct FGameKillLogData GameKillLogData; // 0x18(0xe8)
};

// ScriptStruct DungeonCrawler.GameKillLogData
// Size: 0xe8 (Inherited: 0x00)
struct FGameKillLogData {
	struct FAccountDataReplication AccountDataReplication; // 0x00(0x78)
	struct FInstigatorData InstigatorData; // 0x78(0x50)
	struct FEffectCauserData EffectCauserData; // 0xc8(0x18)
	enum class EHitBoxType HitBoxType; // 0xe0(0x01)
	char pad_E1[0x7]; // 0xe1(0x07)
};

// ScriptStruct DungeonCrawler.MsgGameFloorLogNotify
// Size: 0x98 (Inherited: 0x18)
struct FMsgGameFloorLogNotify : FMsgBase {
	struct FGameFloorLogData GameFloorLogData; // 0x18(0x80)
};

// ScriptStruct DungeonCrawler.GameFloorLogData
// Size: 0x80 (Inherited: 0x00)
struct FGameFloorLogData {
	struct FAccountDataReplication AccountDataReplication; // 0x00(0x78)
	enum class EFloorLogType FloorLogType; // 0x78(0x01)
	char pad_79[0x3]; // 0x79(0x03)
	int32_t Count; // 0x7c(0x04)
};

// ScriptStruct DungeonCrawler.MsgGameFloorRuleNotify
// Size: 0x78 (Inherited: 0x18)
struct FMsgGameFloorRuleNotify : FMsgBase {
	struct FGameFloorRuleData GameFloorRuleData; // 0x18(0x60)
};

// ScriptStruct DungeonCrawler.GameFloorRuleData
// Size: 0x60 (Inherited: 0x00)
struct FGameFloorRuleData {
	int32_t FloorRuleIndex; // 0x00(0x04)
	float FloorRulePhaseServerWorldTime; // 0x04(0x04)
	enum class EFloorRulePhase FloorRulePhase; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float FloorRulePhaseDuration; // 0x0c(0x04)
	struct FGameDeathSwarmData GameDeathSwarmData; // 0x10(0x40)
	struct TArray<struct FGameFloorPortalData> ActiveFloorPortalDataArray; // 0x50(0x10)
};

// ScriptStruct DungeonCrawler.GameFloorPortalData
// Size: 0x18 (Inherited: 0x00)
struct FGameFloorPortalData {
	struct FGameplayTag PortalType; // 0x00(0x08)
	int32_t PortalScrollNum; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct AFloorPortalBase* FloorPortal; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.GameDeathSwarmData
// Size: 0x40 (Inherited: 0x00)
struct FGameDeathSwarmData {
	struct ADeathSwarmBase* DeathSwarm; // 0x00(0x08)
	float PrevDeathSwarmSize; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FVector2D PrevDeathSwarmPos; // 0x10(0x10)
	float DeathSwarmSize; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct FVector2D DeathSwarmPos; // 0x28(0x10)
	struct FGameplayTag DeathSwarmAbilityTag; // 0x38(0x08)
};

// ScriptStruct DungeonCrawler.MsgDungeonInfoNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgDungeonInfoNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgGASAttributeSetRequest
// Size: 0x18 (Inherited: 0x18)
struct FMsgGASAttributeSetRequest : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgGASAttributeSetResponse
// Size: 0x20 (Inherited: 0x18)
struct FMsgGASAttributeSetResponse : FMsgBase {
	struct UDCAttributeSet* AttributeSet; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgGASAttributeNotify
// Size: 0x4c8 (Inherited: 0x18)
struct FMsgGASAttributeNotify : FMsgBase {
	struct UDCAttributeSet* AttributeSet; // 0x18(0x08)
	struct FGameplayAttribute Attribute; // 0x20(0x38)
	float NewValue; // 0x58(0x04)
	float OldValue; // 0x5c(0x04)
	struct UGameplayEffect* GameplayEffectClass; // 0x60(0x08)
	struct FDCGameplayEffectContext EffectContext; // 0x68(0x1c8)
	struct FGameplayEffectSpec EffectSpec; // 0x230(0x298)
};

// ScriptStruct DungeonCrawler.MsgGASGameplayTagContainerRequest
// Size: 0x18 (Inherited: 0x18)
struct FMsgGASGameplayTagContainerRequest : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgGASGameplayTagContainerResponse
// Size: 0x38 (Inherited: 0x18)
struct FMsgGASGameplayTagContainerResponse : FMsgBase {
	struct FGameplayTagContainer GameplayTagContainer; // 0x18(0x20)
};

// ScriptStruct DungeonCrawler.MsgGASGameplayTagNotify
// Size: 0x48 (Inherited: 0x18)
struct FMsgGASGameplayTagNotify : FMsgBase {
	struct FGameplayTagContainer GameplayTagContainer; // 0x18(0x20)
	struct FGameplayTag GameplayTag; // 0x38(0x08)
	int32_t Count; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// ScriptStruct DungeonCrawler.MsgGASActorDieNotify
// Size: 0x1f0 (Inherited: 0x18)
struct FMsgGASActorDieNotify : FMsgBase {
	bool bIsBegin; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct UGameplayEffect* GameplayEffectClass; // 0x20(0x08)
	struct FDCGameplayEffectContext EffectContext; // 0x28(0x1c8)
};

// ScriptStruct DungeonCrawler.MsgGASImpactEnduranceExhaustedNotify
// Size: 0x1f0 (Inherited: 0x18)
struct FMsgGASImpactEnduranceExhaustedNotify : FMsgBase {
	bool bIsBegin; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct UGameplayEffect* GameplayEffectClass; // 0x20(0x08)
	struct FDCGameplayEffectContext EffectContext; // 0x28(0x1c8)
};

// ScriptStruct DungeonCrawler.MsgGASInstigatorDataRequest
// Size: 0x18 (Inherited: 0x18)
struct FMsgGASInstigatorDataRequest : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgGASInstigatorDataResponse
// Size: 0x68 (Inherited: 0x18)
struct FMsgGASInstigatorDataResponse : FMsgBase {
	struct FInstigatorData InstigatorData; // 0x18(0x50)
};

// ScriptStruct DungeonCrawler.MsgGASEffectCauserDataRequest
// Size: 0x18 (Inherited: 0x18)
struct FMsgGASEffectCauserDataRequest : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgGASEffectCauserDataResponse
// Size: 0x30 (Inherited: 0x18)
struct FMsgGASEffectCauserDataResponse : FMsgBase {
	struct FEffectCauserData EffectCauserData; // 0x18(0x18)
};

// ScriptStruct DungeonCrawler.MsgGASActorStatusRequest
// Size: 0x18 (Inherited: 0x18)
struct FMsgGASActorStatusRequest : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgGASActorStatusResponse
// Size: 0x28 (Inherited: 0x18)
struct FMsgGASActorStatusResponse : FMsgBase {
	struct TArray<struct FActorStatusData> ActorStatusDatas; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgGASActorStatusUpdated
// Size: 0x28 (Inherited: 0x18)
struct FMsgGASActorStatusUpdated : FMsgBase {
	struct TArray<struct FActorStatusData> ActorStatusDatas; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgDamageIndicatorPhysicalNotify
// Size: 0x58 (Inherited: 0x18)
struct FMsgDamageIndicatorPhysicalNotify : FMsgBase {
	struct AActor* SourceActor; // 0x18(0x08)
	float DamageValues; // 0x20(0x04)
	bool IsIgnoreReducation; // 0x24(0x01)
	bool IsHitHead; // 0x25(0x01)
	char pad_26[0x2]; // 0x26(0x02)
	struct FVector HitLocation; // 0x28(0x18)
	struct FVector HitDirection; // 0x40(0x18)
};

// ScriptStruct DungeonCrawler.MsgDamageIndicatorMagicalNotify
// Size: 0x58 (Inherited: 0x18)
struct FMsgDamageIndicatorMagicalNotify : FMsgBase {
	struct AActor* SourceActor; // 0x18(0x08)
	float DamageValues; // 0x20(0x04)
	bool IsIgnoreReducation; // 0x24(0x01)
	bool IsHitHead; // 0x25(0x01)
	char pad_26[0x2]; // 0x26(0x02)
	struct FVector HitLocation; // 0x28(0x18)
	struct FVector HitDirection; // 0x40(0x18)
};

// ScriptStruct DungeonCrawler.GameplayAbilityRelationshipItem
// Size: 0xa8 (Inherited: 0x00)
struct FGameplayAbilityRelationshipItem {
	struct FGameplayTag AbilityTag; // 0x00(0x08)
	struct FGameplayTagContainer AbilityTagsToBlock; // 0x08(0x20)
	struct FGameplayTagContainer AbilityTagsToCancel; // 0x28(0x20)
	struct FGameplayTagContainer ActivationRequiredTags; // 0x48(0x20)
	struct FGameplayTagContainer ActivationBlockedTags; // 0x68(0x20)
	struct FGameplayTagContainer ActivationCancelingTags; // 0x88(0x20)
};

// ScriptStruct DungeonCrawler.SkillCooldownInfo
// Size: 0x08 (Inherited: 0x00)
struct FSkillCooldownInfo {
	float RemainDuration; // 0x00(0x04)
	float MaxDuration; // 0x04(0x04)
};

// ScriptStruct DungeonCrawler.MsgGameTestChangePlayerCharacterClassRequest
// Size: 0x28 (Inherited: 0x18)
struct FMsgGameTestChangePlayerCharacterClassRequest : FMsgBase {
	struct FPrimaryAssetId PlayerCharacterId; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgGameTestChangePlayerCharacterClassResponse
// Size: 0x18 (Inherited: 0x18)
struct FMsgGameTestChangePlayerCharacterClassResponse : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgGameClassMoveInfo
// Size: 0x38 (Inherited: 0x18)
struct FMsgGameClassMoveInfo : FMsgBase {
	int32_t Index; // 0x18(0x04)
	int32_t Type; // 0x1c(0x04)
	struct FString MoveId; // 0x20(0x10)
	int32_t Move; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct DungeonCrawler.MsgGameTestClassLevelInfoRequest
// Size: 0x20 (Inherited: 0x18)
struct FMsgGameTestClassLevelInfoRequest : FMsgBase {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.MsgGameTestClassLevelInfoResponse
// Size: 0x30 (Inherited: 0x18)
struct FMsgGameTestClassLevelInfoResponse : FMsgBase {
	int32_t Level; // 0x18(0x04)
	int32_t Exp; // 0x1c(0x04)
	int32_t ExpBegin; // 0x20(0x04)
	int32_t ExpLimit; // 0x24(0x04)
	int32_t RewardPoint; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct DungeonCrawler.MsgGameTestClassPerkListRequest
// Size: 0x20 (Inherited: 0x18)
struct FMsgGameTestClassPerkListRequest : FMsgBase {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.MsgGameTestClassPerkListResponse
// Size: 0x28 (Inherited: 0x18)
struct FMsgGameTestClassPerkListResponse : FMsgBase {
	struct TArray<struct FAccountDataPerk> Perks; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgGameTestClassSkillListRequest
// Size: 0x20 (Inherited: 0x18)
struct FMsgGameTestClassSkillListRequest : FMsgBase {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.MsgGameTestClassSkillListResponse
// Size: 0x28 (Inherited: 0x18)
struct FMsgGameTestClassSkillListResponse : FMsgBase {
	struct TArray<struct FAccountDataSkill> Skills; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgGameTestClassSpellListRequest
// Size: 0x20 (Inherited: 0x18)
struct FMsgGameTestClassSpellListRequest : FMsgBase {
	int32_t RequestCommand; // 0x18(0x04)
	int32_t MaxSpellMemory; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.MsgGameTestClassSpellListResponse
// Size: 0x28 (Inherited: 0x18)
struct FMsgGameTestClassSpellListResponse : FMsgBase {
	struct TArray<struct FAccountDataSpell> Spells; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgGameTestClassSpellSlotMoveRequest
// Size: 0x38 (Inherited: 0x18)
struct FMsgGameTestClassSpellSlotMoveRequest : FMsgBase {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FString SpellId; // 0x20(0x10)
	int32_t DstSlotIndex; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct DungeonCrawler.MsgGameTestClassSpellSlotMoveResponse
// Size: 0x30 (Inherited: 0x18)
struct FMsgGameTestClassSpellSlotMoveResponse : FMsgBase {
	int32_t Result; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct TArray<struct FAccountDataSpell> EquipSpellList; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.MsgGameTestClassSpellSequenceChangeRequest
// Size: 0x38 (Inherited: 0x18)
struct FMsgGameTestClassSpellSequenceChangeRequest : FMsgBase {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FString SpellId; // 0x20(0x10)
	int32_t DstSequenceIndex; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct DungeonCrawler.MsgGameTestClassSpellSequenceChangeResponse
// Size: 0x30 (Inherited: 0x18)
struct FMsgGameTestClassSpellSequenceChangeResponse : FMsgBase {
	int32_t Result; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct TArray<struct FAccountDataSpell> EquipSpellList; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.MsgGameTestClassItemMoveRequest
// Size: 0x90 (Inherited: 0x18)
struct FMsgGameTestClassItemMoveRequest : FMsgBase {
	int32_t RequestCommand; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FMsgGameClassMoveInfo OldMove; // 0x20(0x38)
	struct FMsgGameClassMoveInfo NewMove; // 0x58(0x38)
};

// ScriptStruct DungeonCrawler.MsgGameTestClassItemMoveResponse
// Size: 0x90 (Inherited: 0x18)
struct FMsgGameTestClassItemMoveResponse : FMsgBase {
	int32_t Result; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FMsgGameClassMoveInfo OldMove; // 0x20(0x38)
	struct FMsgGameClassMoveInfo NewMove; // 0x58(0x38)
};

// ScriptStruct DungeonCrawler.DCGameInfo
// Size: 0x48 (Inherited: 0x00)
struct FDCGameInfo {
	int64_t GameId; // 0x00(0x08)
	bool bWithGameLift; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	int32_t MaxGameUser; // 0x0c(0x04)
	int32_t WaitGameTimeSec; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FString TavernMapName; // 0x18(0x10)
	enum class EGameDifficultyType GameDifficultyType; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct TArray<struct UDCDungeonDataAsset*> DungeonDraws; // 0x30(0x10)
	bool bFloorMatch; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// ScriptStruct DungeonCrawler.DCServerPolicyInfo
// Size: 0x01 (Inherited: 0x00)
struct FDCServerPolicyInfo {
	bool bGmEnabled; // 0x00(0x01)
};

// ScriptStruct DungeonCrawler.GameAnnounceInfo
// Size: 0x98 (Inherited: 0x00)
struct FGameAnnounceInfo {
	struct FName WinnerPlayerCharacterBlackboardKey; // 0x00(0x08)
	struct FGameAnnounceData AnnounceData; // 0x08(0x90)
};

// ScriptStruct DungeonCrawler.DCDungeonInfo
// Size: 0x0c (Inherited: 0x00)
struct FDCDungeonInfo {
	int32_t GameTimeSec; // 0x00(0x04)
	float GameTimeSecServerWorldTime; // 0x04(0x04)
	bool HideDeathSwarmTimer; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
};

// ScriptStruct DungeonCrawler.ObjectLinkResponeEvent
// Size: 0x60 (Inherited: 0x00)
struct FObjectLinkResponeEvent {
	struct FGameplayTag SrcTypeTag; // 0x00(0x08)
	struct FObjectLinkMetaData MetaData; // 0x08(0x58)
};

// ScriptStruct DungeonCrawler.GameUserSettingControls
// Size: 0x28 (Inherited: 0x00)
struct FGameUserSettingControls {
	float MouseSensitivity; // 0x00(0x04)
	bool IsInvertVerticalAxis; // 0x04(0x01)
	bool IsInvertHorizontalAxis; // 0x05(0x01)
	char pad_6[0x2]; // 0x06(0x02)
	struct FString culture; // 0x08(0x10)
	bool bIgnoreInvitation; // 0x18(0x01)
	bool bStreamingMode; // 0x19(0x01)
	char pad_1A[0x2]; // 0x1a(0x02)
	int32_t RegionIndex; // 0x1c(0x04)
	int32_t GameDifficultyTypeIndex; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.GameUserSettingVideoDisplay
// Size: 0x18 (Inherited: 0x00)
struct FGameUserSettingVideoDisplay {
	int32_t DisplayMode; // 0x00(0x04)
	int32_t ResolutionIndex; // 0x04(0x04)
	float FrameRateLimit; // 0x08(0x04)
	float GammaValue; // 0x0c(0x04)
	float RenderScale; // 0x10(0x04)
	int32_t DynamicResolutionMode; // 0x14(0x04)
};

// ScriptStruct DungeonCrawler.BindAccountUserData
// Size: 0x28 (Inherited: 0x00)
struct FBindAccountUserData {
	struct AActor* DummyActor; // 0x00(0x08)
	char pad_8[0x20]; // 0x08(0x20)
};

// ScriptStruct DungeonCrawler.DCDrinkItemConsumeData
// Size: 0x28 (Inherited: 0x00)
struct FDCDrinkItemConsumeData {
	struct FPrimaryAssetId DurationConstantId; // 0x00(0x10)
	enum class EDesignDataConstantType DurationConstantType; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	struct FPrimaryAssetId EffectConstantId; // 0x14(0x10)
	enum class EDesignDataConstantType EffecConstantType; // 0x24(0x01)
	char pad_25[0x3]; // 0x25(0x03)
};

// ScriptStruct DungeonCrawler.LobbyEmoteAnimationSet
// Size: 0x10 (Inherited: 0x00)
struct FLobbyEmoteAnimationSet {
	struct UAnimMontage* EmoteMontage; // 0x00(0x08)
	struct FName EmoteObjectSocket; // 0x08(0x08)
};

// ScriptStruct DungeonCrawler.ComboTriggerStep
// Size: 0x10 (Inherited: 0x00)
struct FComboTriggerStep {
	struct UInputAction* DependentAction; // 0x00(0x08)
	float ActivationThreshold; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct DungeonCrawler.MsgInteractStart
// Size: 0x28 (Inherited: 0x18)
struct FMsgInteractStart : FMsgBase {
	struct AActor* Interacter; // 0x18(0x08)
	struct FGameplayTag CurrentStateTag; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.MsgInteractStarted
// Size: 0x28 (Inherited: 0x18)
struct FMsgInteractStarted : FMsgBase {
	struct AActor* Interacter; // 0x18(0x08)
	struct FGameplayTag EventTag; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.MsgInteractEnd
// Size: 0x118 (Inherited: 0x18)
struct FMsgInteractEnd : FMsgBase {
	struct AActor* Interacter; // 0x18(0x08)
	bool bIsSucceed; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
	struct FGameplayTag EventTag; // 0x24(0x08)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct FHitResult HitResult; // 0x30(0xe8)
};

// ScriptStruct DungeonCrawler.MsgInteractSucceed
// Size: 0x118 (Inherited: 0x18)
struct FMsgInteractSucceed : FMsgBase {
	struct AActor* Interacter; // 0x18(0x08)
	struct FGameplayTag StateTag; // 0x20(0x08)
	struct FGameplayTag TriggerTag; // 0x28(0x08)
	struct FHitResult HitResult; // 0x30(0xe8)
};

// ScriptStruct DungeonCrawler.MsgInteractFailed
// Size: 0x28 (Inherited: 0x18)
struct FMsgInteractFailed : FMsgBase {
	struct AActor* Interacter; // 0x18(0x08)
	struct FGameplayTag EventTag; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.MsgInteractFound
// Size: 0x28 (Inherited: 0x18)
struct FMsgInteractFound : FMsgBase {
	struct AActor* Interacter; // 0x18(0x08)
	struct UPrimitiveComponent* InteractPart; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.MsgInteractLost
// Size: 0x20 (Inherited: 0x18)
struct FMsgInteractLost : FMsgBase {
	struct AActor* Interacter; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgInteractDataSet
// Size: 0x88 (Inherited: 0x18)
struct FMsgInteractDataSet : FMsgBase {
	struct FInteractTargetData InteractTargetData; // 0x18(0x20)
	struct TMap<struct FGameplayTag, struct FInteractionData> InteractableDataByStateMap; // 0x38(0x50)
};

// ScriptStruct DungeonCrawler.MsgInteractSkillCheckStart
// Size: 0x38 (Inherited: 0x18)
struct FMsgInteractSkillCheckStart : FMsgBase {
	struct FSkillCheckData SkillCheckData; // 0x18(0x1c)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct DungeonCrawler.SkillCheckData
// Size: 0x1c (Inherited: 0x00)
struct FSkillCheckData {
	struct FGameplayTag SkillCheckType; // 0x00(0x08)
	float Duration; // 0x08(0x04)
	float SucceedSectionStartTime; // 0x0c(0x04)
	float SucceedSectionEndTime; // 0x10(0x04)
	float PerfectSucceedSectionStartTime; // 0x14(0x04)
	float PerfectSucceedSectionEndTime; // 0x18(0x04)
};

// ScriptStruct DungeonCrawler.MsgInteractSkillCheckEnd
// Size: 0x20 (Inherited: 0x18)
struct FMsgInteractSkillCheckEnd : FMsgBase {
	enum class ESkillCheckResult Result; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgInteractableHighlightNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgInteractableHighlightNotify : FMsgBase {
	int32_t HighlightDepthValue; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.MsgRemoveContainingItemRequest
// Size: 0x28 (Inherited: 0x18)
struct FMsgRemoveContainingItemRequest : FMsgBase {
	int32_t InventoryId; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	int64_t ItemUniqueId; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.MsgRemoveContainingItemResponse
// Size: 0x20 (Inherited: 0x18)
struct FMsgRemoveContainingItemResponse : FMsgBase {
	bool bSuccess; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgReduceContainingItemRequest
// Size: 0x30 (Inherited: 0x18)
struct FMsgReduceContainingItemRequest : FMsgBase {
	int32_t InventoryId; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	int64_t ItemUniqueId; // 0x20(0x08)
	int32_t ReduceCount; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct DungeonCrawler.MsgReduceContainingItemResponse
// Size: 0x20 (Inherited: 0x18)
struct FMsgReduceContainingItemResponse : FMsgBase {
	bool bSucceed; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgReduceItemContentsCountRequest
// Size: 0x30 (Inherited: 0x18)
struct FMsgReduceItemContentsCountRequest : FMsgBase {
	int32_t InventoryId; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	int64_t ItemUniqueId; // 0x20(0x08)
	int32_t ReduceContentsCount; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct DungeonCrawler.MsgReduceItemContentsCountResponse
// Size: 0x20 (Inherited: 0x18)
struct FMsgReduceItemContentsCountResponse : FMsgBase {
	bool bSucceed; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgAddContainingItemRequest
// Size: 0xc8 (Inherited: 0x18)
struct FMsgAddContainingItemRequest : FMsgBase {
	int32_t InventoryId; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FItemData ItemData; // 0x20(0xa0)
	bool BySystem; // 0xc0(0x01)
	bool bNoStack; // 0xc1(0x01)
	char pad_C2[0x6]; // 0xc2(0x06)
};

// ScriptStruct DungeonCrawler.MsgAddContainingItemResponse
// Size: 0x20 (Inherited: 0x18)
struct FMsgAddContainingItemResponse : FMsgBase {
	bool bSuccess; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	int32_t SlotId; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.MsgRemoveAllContainingItem
// Size: 0x20 (Inherited: 0x18)
struct FMsgRemoveAllContainingItem : FMsgBase {
	int32_t InventoryId; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.MsgSlotItemDataRequest
// Size: 0x20 (Inherited: 0x18)
struct FMsgSlotItemDataRequest : FMsgBase {
	int32_t InventoryId; // 0x18(0x04)
	int32_t SlotId; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.MsgSlotItemDataResponse
// Size: 0x30 (Inherited: 0x18)
struct FMsgSlotItemDataResponse : FMsgBase {
	bool bItemSet; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct TArray<struct FItemData> ItemDataArray; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.MsgAddEquippedItemActor
// Size: 0x20 (Inherited: 0x18)
struct FMsgAddEquippedItemActor : FMsgBase {
	struct AItemActor* EquippedItemActor; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgAddSheathItemActor
// Size: 0x20 (Inherited: 0x18)
struct FMsgAddSheathItemActor : FMsgBase {
	struct AItemActor* SheathItemActor; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgItemDataNotify
// Size: 0x160 (Inherited: 0x18)
struct FMsgItemDataNotify : FMsgBase {
	struct UInventoryComponent* InventoryComponent; // 0x18(0x08)
	struct FItemData OldItemData; // 0x20(0xa0)
	struct FItemData NewItemData; // 0xc0(0xa0)
};

// ScriptStruct DungeonCrawler.MsgTotalGoldCountNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgTotalGoldCountNotify : FMsgBase {
	struct UInventoryComponent* InventoryComponent; // 0x18(0x08)
	int64_t TotalGoldCount; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.MsgInventoryItemDataArrayRequest
// Size: 0x18 (Inherited: 0x18)
struct FMsgInventoryItemDataArrayRequest : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgInventoryItemDataArrayResponse
// Size: 0x38 (Inherited: 0x18)
struct FMsgInventoryItemDataArrayResponse : FMsgBase {
	struct UInventoryComponent* InventoryComponent; // 0x18(0x08)
	enum class EInventoryType InventoryType; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct TArray<struct FItemData> ItemDataArray; // 0x28(0x10)
};

// ScriptStruct DungeonCrawler.MsgContainingItemDataRequest
// Size: 0x20 (Inherited: 0x18)
struct FMsgContainingItemDataRequest : FMsgBase {
	int64_t ItemUniqueId; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgContainingItemDataResponse
// Size: 0xd0 (Inherited: 0x18)
struct FMsgContainingItemDataResponse : FMsgBase {
	struct UEquipmentInventoryComponent* EquipmentInventoryComponent; // 0x18(0x08)
	enum class EEquipmentQuickSlotType EquipmentQuickSlotType; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct UInventoryComponent* InventoryComponent; // 0x28(0x08)
	struct FItemData ItemData; // 0x30(0xa0)
};

// ScriptStruct DungeonCrawler.MsgSetEquippedWeaponsVisibility
// Size: 0x40 (Inherited: 0x18)
struct FMsgSetEquippedWeaponsVisibility : FMsgBase {
	struct FGameplayTagContainer IgnoreTypes; // 0x18(0x20)
	bool bIsHide; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct DungeonCrawler.MsgSetLootingTargetPlayerInventory
// Size: 0x30 (Inherited: 0x18)
struct FMsgSetLootingTargetPlayerInventory : FMsgBase {
	struct FLootingTargetPlayerInventory TargetPlayerInventory; // 0x18(0x18)
};

// ScriptStruct DungeonCrawler.LootingTargetPlayerInventory
// Size: 0x18 (Inherited: 0x00)
struct FLootingTargetPlayerInventory {
	struct UEquipmentInventoryComponent* EquipmentInventory; // 0x00(0x08)
	struct TArray<struct UInventoryComponent*> ContainerInventoryArray; // 0x08(0x10)
};

// ScriptStruct DungeonCrawler.MsgLootingTargetPlayerInventoryNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgLootingTargetPlayerInventoryNotify : FMsgBase {
	struct FLootingTargetPlayerInventory TargetPlayerInventory; // 0x18(0x18)
};

// ScriptStruct DungeonCrawler.MsgEnableAddItemRequest
// Size: 0x30 (Inherited: 0x18)
struct FMsgEnableAddItemRequest : FMsgBase {
	int32_t TargetInventoryId; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct TArray<struct FItemData> AddItemDataArray; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.MsgEnableAddItemResponse
// Size: 0x30 (Inherited: 0x18)
struct FMsgEnableAddItemResponse : FMsgBase {
	bool bCanAdd; // 0x18(0x01)
	bool bInvalidRequest; // 0x19(0x01)
	char pad_1A[0x6]; // 0x1a(0x06)
	struct TArray<struct FItemData> ResultItemDataArray; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.MsgEnableSwapItemRequest
// Size: 0xd0 (Inherited: 0x18)
struct FMsgEnableSwapItemRequest : FMsgBase {
	int32_t TargetInventoryId; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FItemData RemoveItemData; // 0x20(0xa0)
	struct TArray<struct FItemData> AddItemDataArray; // 0xc0(0x10)
};

// ScriptStruct DungeonCrawler.MsgEnableSwapItemResponse
// Size: 0x30 (Inherited: 0x18)
struct FMsgEnableSwapItemResponse : FMsgBase {
	bool bCanSwap; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct TArray<struct FItemData> SwapItemDataArray; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.MsgInventoryItemAmmoAddRequest
// Size: 0x30 (Inherited: 0x18)
struct FMsgInventoryItemAmmoAddRequest : FMsgBase {
	int32_t InventoryId; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	int64_t ItemUniqueId; // 0x20(0x08)
	int32_t Count; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct DungeonCrawler.MsgInventoryItemAmmoAddResponse
// Size: 0x20 (Inherited: 0x18)
struct FMsgInventoryItemAmmoAddResponse : FMsgBase {
	bool bIsSucceed; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgInventoryItemAmmoReduceRequest
// Size: 0x30 (Inherited: 0x18)
struct FMsgInventoryItemAmmoReduceRequest : FMsgBase {
	int32_t InventoryId; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	int64_t ItemUniqueId; // 0x20(0x08)
	int32_t Count; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct DungeonCrawler.MsgInventoryItemAmmoReduceResponse
// Size: 0x20 (Inherited: 0x18)
struct FMsgInventoryItemAmmoReduceResponse : FMsgBase {
	bool bIsSucceed; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgMoveItem
// Size: 0xd8 (Inherited: 0x18)
struct FMsgMoveItem : FMsgBase {
	struct AActor* OldOwner; // 0x18(0x08)
	struct FItemData OldItemData; // 0x20(0xa0)
	struct AActor* NewOwner; // 0xc0(0x08)
	struct TArray<struct FItemData> NewItemDataArray; // 0xc8(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetMoveItem
// Size: 0xd8 (Inherited: 0x18)
struct FMsgWidgetMoveItem : FMsgBase {
	struct AActor* OldOwner; // 0x18(0x08)
	struct FItemData OldItemData; // 0x20(0xa0)
	struct AActor* NewOwner; // 0xc0(0x08)
	struct TArray<struct FItemData> NewItemDataArray; // 0xc8(0x10)
};

// ScriptStruct DungeonCrawler.MsgSucceedWidgetMoveItem
// Size: 0x28 (Inherited: 0x18)
struct FMsgSucceedWidgetMoveItem : FMsgBase {
	struct TArray<struct FItemData> ItemDataArray; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgUpdateCurrentEquipSlotWidget
// Size: 0xb8 (Inherited: 0x18)
struct FMsgUpdateCurrentEquipSlotWidget : FMsgBase {
	struct FItemData UpdatedItemData; // 0x18(0xa0)
};

// ScriptStruct DungeonCrawler.MsgEquippedItemActors
// Size: 0x28 (Inherited: 0x18)
struct FMsgEquippedItemActors : FMsgBase {
	struct TArray<struct AItemActor*> EquippedItemActors; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgCurrentEquippedItemActorsRequest
// Size: 0x18 (Inherited: 0x18)
struct FMsgCurrentEquippedItemActorsRequest : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgCurrentEquippedItemActorsResponse
// Size: 0x28 (Inherited: 0x18)
struct FMsgCurrentEquippedItemActorsResponse : FMsgBase {
	struct TArray<struct AItemActor*> EquippedItemActors; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgItemIdNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgItemIdNotify : FMsgBase {
	struct FDCItemId ItemId; // 0x18(0x08)
	enum class EDCInventoryId Inventory; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
	int32_t Index; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.MsgUsingItemUniqueFunction
// Size: 0x28 (Inherited: 0x18)
struct FMsgUsingItemUniqueFunction : FMsgBase {
	int32_t InventoryId; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	int64_t ItemUniqueId; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.InventoryStatusWidgetData
// Size: 0x18 (Inherited: 0x00)
struct FInventoryStatusWidgetData {
	struct FText PlayerCharacterName; // 0x00(0x18)
};

// ScriptStruct DungeonCrawler.CallData
// Size: 0x10 (Inherited: 0x00)
struct FCallData {
	struct TArray<char> Data; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.MsgAddToInventory
// Size: 0x30 (Inherited: 0x18)
struct FMsgAddToInventory : FMsgBase {
	struct AActor* Owner; // 0x18(0x08)
	bool bEquipped; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
	int32_t InventoryId; // 0x24(0x04)
	int32_t InventorySlotId; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct DungeonCrawler.MsgEquip
// Size: 0x18 (Inherited: 0x18)
struct FMsgEquip : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgGiveAbility
// Size: 0x20 (Inherited: 0x18)
struct FMsgGiveAbility : FMsgBase {
	struct AActor* TargetActor; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgRemoveAbility
// Size: 0x20 (Inherited: 0x18)
struct FMsgRemoveAbility : FMsgBase {
	struct AActor* TargetActor; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgItemDataUpdateNotify
// Size: 0xb8 (Inherited: 0x18)
struct FMsgItemDataUpdateNotify : FMsgBase {
	struct FItemData ItemData; // 0x18(0xa0)
};

// ScriptStruct DungeonCrawler.MsgRemoveFromInventory
// Size: 0x18 (Inherited: 0x18)
struct FMsgRemoveFromInventory : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgItemDropRequest
// Size: 0x28 (Inherited: 0x18)
struct FMsgItemDropRequest : FMsgBase {
	int32_t DropItemCount; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct AActor* DropActingActor; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.MsgItemDropResponse
// Size: 0x20 (Inherited: 0x18)
struct FMsgItemDropResponse : FMsgBase {
	bool bSuccess; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgChangedItemRequirementFulfillmentStatus
// Size: 0x20 (Inherited: 0x18)
struct FMsgChangedItemRequirementFulfillmentStatus : FMsgBase {
	bool bFulfilled; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgFinishedLoadItemArtData
// Size: 0x20 (Inherited: 0x18)
struct FMsgFinishedLoadItemArtData : FMsgBase {
	struct UItem* Item; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgChangedItemArtData
// Size: 0x28 (Inherited: 0x18)
struct FMsgChangedItemArtData : FMsgBase {
	struct UItem* Item; // 0x18(0x08)
	struct UArtDataItem* NewItemArtData; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.MsgItemConsumeDataRequest
// Size: 0x18 (Inherited: 0x18)
struct FMsgItemConsumeDataRequest : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgItemConsumeDataResponse
// Size: 0xd8 (Inherited: 0x18)
struct FMsgItemConsumeDataResponse : FMsgBase {
	struct FItemData ItemData; // 0x18(0xa0)
	struct FDesignDataItemConsume ItemConsumeData; // 0xb8(0x20)
};

// ScriptStruct DungeonCrawler.MsgItemWearingStart
// Size: 0xe0 (Inherited: 0x18)
struct FMsgItemWearingStart : FMsgBase {
	struct FItemData WearingItemData; // 0x18(0xa0)
	struct TWeakObjectPtr<struct AActor> WearingActor; // 0xb8(0x08)
	float Duration; // 0xc0(0x04)
	char pad_C4[0x4]; // 0xc4(0x04)
	struct FText Description; // 0xc8(0x18)
};

// ScriptStruct DungeonCrawler.MsgItemWearingEnd
// Size: 0x20 (Inherited: 0x18)
struct FMsgItemWearingEnd : FMsgBase {
	bool bIsSucceed; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgUpdateMeshEvent
// Size: 0x20 (Inherited: 0x18)
struct FMsgUpdateMeshEvent : FMsgBase {
	struct UMeshComponent* MeshComponent; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.ItemRandomGenerateData
// Size: 0x20 (Inherited: 0x00)
struct FItemRandomGenerateData {
	struct UDesignDataAssetLootDrop* DesignDataAssetLootDrop; // 0x00(0x08)
	struct FDesignDataLootDrop DesignDataLootDrop; // 0x08(0x10)
	int32_t GenerateCount; // 0x18(0x04)
	bool bGenerateAll; // 0x1c(0x01)
	char pad_1D[0x3]; // 0x1d(0x03)
};

// ScriptStruct DungeonCrawler.ItemTooltipWidgetData
// Size: 0xa0 (Inherited: 0x00)
struct FItemTooltipWidgetData {
	struct FItemData ItemData; // 0x00(0xa0)
};

// ScriptStruct DungeonCrawler.ItemDataGameplayEffectValue
// Size: 0x0c (Inherited: 0x00)
struct FItemDataGameplayEffectValue {
	struct FGameplayTag EffectTag; // 0x00(0x08)
	int32_t EffectValue; // 0x08(0x04)
};

// ScriptStruct DungeonCrawler.ItemDataGameplayEffect
// Size: 0x20 (Inherited: 0x00)
struct FItemDataGameplayEffect {
	struct FPrimaryAssetId EffectId; // 0x00(0x10)
	struct TArray<struct FItemDataGameplayEffectValue> ItemDataGameplayEffectValueArray; // 0x10(0x10)
};

// ScriptStruct DungeonCrawler.ItemDataGameplayAbility
// Size: 0x20 (Inherited: 0x00)
struct FItemDataGameplayAbility {
	struct FPrimaryAssetId AbilityId; // 0x00(0x10)
	struct TArray<struct FItemDataGameplayEffect> ItemDataGameplayEffectArray; // 0x10(0x10)
};

// ScriptStruct DungeonCrawler.ItemInventorySize
// Size: 0x08 (Inherited: 0x00)
struct FItemInventorySize {
	int32_t Width; // 0x00(0x04)
	int32_t Height; // 0x04(0x04)
};

// ScriptStruct DungeonCrawler.ItemWidgetData
// Size: 0xa0 (Inherited: 0x00)
struct FItemWidgetData {
	struct FItemData ItemData; // 0x00(0xa0)
};

// ScriptStruct DungeonCrawler.MsgSetLootTarget
// Size: 0x128 (Inherited: 0x18)
struct FMsgSetLootTarget : FMsgBase {
	struct UInventoryComponent* LootTargetComponent; // 0x18(0x08)
	struct TArray<struct FItemData> ContainingItemDataArray; // 0x20(0x10)
	struct TArray<struct FSlotInfo> SlotInfoArray; // 0x30(0x10)
	struct FHitResult LootTargetHitResult; // 0x40(0xe8)
};

// ScriptStruct DungeonCrawler.MsgLootContainingItemsNotify
// Size: 0x40 (Inherited: 0x18)
struct FMsgLootContainingItemsNotify : FMsgBase {
	int32_t InventoryId; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct TArray<struct FItemData> ContainingItemDataArray; // 0x20(0x10)
	struct TArray<struct FSlotInfo> SlotInfoArray; // 0x30(0x10)
};

// ScriptStruct DungeonCrawler.MsgRemoveLootTarget
// Size: 0x30 (Inherited: 0x18)
struct FMsgRemoveLootTarget : FMsgBase {
	struct UInventoryComponent* LootTargetComponent; // 0x18(0x08)
	struct TArray<struct FItemData> ContainingItemDataArray; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.MsgClearLootingTargets
// Size: 0x18 (Inherited: 0x18)
struct FMsgClearLootingTargets : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgLootComponentNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgLootComponentNotify : FMsgBase {
	struct ULootComponent* LootComponent; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgAddLooter
// Size: 0x108 (Inherited: 0x18)
struct FMsgAddLooter : FMsgBase {
	struct AActor* Looter; // 0x18(0x08)
	struct FHitResult HitResult; // 0x20(0xe8)
};

// ScriptStruct DungeonCrawler.MsgRemoveLooter
// Size: 0x20 (Inherited: 0x18)
struct FMsgRemoveLooter : FMsgBase {
	struct AActor* Looter; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgRemoveAllLooters
// Size: 0x18 (Inherited: 0x18)
struct FMsgRemoveAllLooters : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MerchantInfo
// Size: 0x28 (Inherited: 0x00)
struct FMerchantInfo {
	struct FPrimaryAssetId MerchantId; // 0x00(0x10)
	int32_t Faction; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FTimespan RemainTime; // 0x18(0x08)
	int32_t IsUnidentified; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.StockBuyTradeItemInfo
// Size: 0x10 (Inherited: 0x00)
struct FStockBuyTradeItemInfo {
	int64_t ItemUniqueId; // 0x00(0x08)
	int32_t ItemCount; // 0x08(0x04)
	int32_t ItemContentsCount; // 0x0c(0x04)
};

// ScriptStruct DungeonCrawler.StockCraftTradeItemInfo
// Size: 0x10 (Inherited: 0x00)
struct FStockCraftTradeItemInfo {
	int64_t ItemUniqueId; // 0x00(0x08)
	int32_t ItemCount; // 0x08(0x04)
	int32_t ItemContentsCount; // 0x0c(0x04)
};

// ScriptStruct DungeonCrawler.MerchantTradeResultItemSlotInfo
// Size: 0x28 (Inherited: 0x00)
struct FMerchantTradeResultItemSlotInfo {
	int32_t InventoryId; // 0x00(0x04)
	int32_t SlotId; // 0x04(0x04)
	struct FString ItemId; // 0x08(0x10)
	int64_t ItemUniqueId; // 0x18(0x08)
	int32_t ItemCount; // 0x20(0x04)
	int32_t ItemContentsCount; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.MetaBindAccountUserData
// Size: 0x08 (Inherited: 0x00)
struct FMetaBindAccountUserData {
	struct AActor* DummyActor; // 0x00(0x08)
};

// ScriptStruct DungeonCrawler.DCMiniMapDataContainer
// Size: 0x10 (Inherited: 0x00)
struct FDCMiniMapDataContainer {
	struct UTexture2D* Texture2D; // 0x00(0x08)
	float OrthoWidth; // 0x08(0x04)
	float Zoom; // 0x0c(0x04)
};

// ScriptStruct DungeonCrawler.MsgMonsterAISet
// Size: 0x20 (Inherited: 0x18)
struct FMsgMonsterAISet : FMsgBase {
	struct UBehaviorTree* BehaviorTree; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgMonsterAIStart
// Size: 0x18 (Inherited: 0x18)
struct FMsgMonsterAIStart : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgMonsterIdRequest
// Size: 0x18 (Inherited: 0x18)
struct FMsgMonsterIdRequest : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgMonsterIdResponse
// Size: 0x28 (Inherited: 0x18)
struct FMsgMonsterIdResponse : FMsgBase {
	struct FPrimaryAssetId MonsterId; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgGameplaytagNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgGameplaytagNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgMusicPlayStart
// Size: 0x40 (Inherited: 0x18)
struct FMsgMusicPlayStart : FMsgBase {
	float Duration; // 0x18(0x04)
	float JudgementThreshold; // 0x1c(0x04)
	struct FText Description; // 0x20(0x18)
	struct UPlayMusicData* PlayMusicData; // 0x38(0x08)
};

// ScriptStruct DungeonCrawler.MsgMusicPlaySucceed
// Size: 0x18 (Inherited: 0x18)
struct FMsgMusicPlaySucceed : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgMusicPlayEnd
// Size: 0x18 (Inherited: 0x18)
struct FMsgMusicPlayEnd : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgMusicChannelingStart
// Size: 0x38 (Inherited: 0x18)
struct FMsgMusicChannelingStart : FMsgBase {
	float Duration; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FText Description; // 0x20(0x18)
};

// ScriptStruct DungeonCrawler.MsgMusicChannelingEnd
// Size: 0x18 (Inherited: 0x18)
struct FMsgMusicChannelingEnd : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgMusicJudgeNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgMusicJudgeNotify : FMsgBase {
	enum class EMusicPlaySectionJudgement Judge; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	float ElapsedTime; // 0x1c(0x04)
	float PastSectionRatio; // 0x20(0x04)
	float NextSectionRatio; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.MusicData
// Size: 0x1c (Inherited: 0x00)
struct FMusicData {
	struct FPrimaryAssetId MusicId; // 0x00(0x10)
	struct FGameplayTag MusicTag; // 0x10(0x08)
	int32_t SlotIndex; // 0x18(0x04)
};

// ScriptStruct DungeonCrawler.NickNameWidgetData
// Size: 0x10 (Inherited: 0x00)
struct FNickNameWidgetData {
	struct FString NickNameStr; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.DCSteamAuthTicket
// Size: 0x18 (Inherited: 0x00)
struct FDCSteamAuthTicket {
	struct FString SessionTicket; // 0x00(0x10)
	bool bUseSteamSystem; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	int32_t LocalSteamBuildId; // 0x14(0x04)
};

// ScriptStruct DungeonCrawler.PartyChatWidgetData
// Size: 0x48 (Inherited: 0x00)
struct FPartyChatWidgetData {
	struct FChatAccountData ChatAccountData; // 0x00(0x48)
};

// ScriptStruct DungeonCrawler.MsgPartyDataRequest
// Size: 0x18 (Inherited: 0x18)
struct FMsgPartyDataRequest : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgPartyDataResponse
// Size: 0x68 (Inherited: 0x18)
struct FMsgPartyDataResponse : FMsgBase {
	struct TMap<struct FString, struct FPartyData> PartyDataMap; // 0x18(0x50)
};

// ScriptStruct DungeonCrawler.MsgPartyDataNotify
// Size: 0x38 (Inherited: 0x18)
struct FMsgPartyDataNotify : FMsgBase {
	struct FPartyData PartyData; // 0x18(0x20)
};

// ScriptStruct DungeonCrawler.MsgPartyLinkRequest
// Size: 0x28 (Inherited: 0x18)
struct FMsgPartyLinkRequest : FMsgBase {
	struct FString PartyId; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgPartyLinkResponse
// Size: 0x20 (Inherited: 0x18)
struct FMsgPartyLinkResponse : FMsgBase {
	struct UPartySession* PartySession; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgPartySessionDataNotify
// Size: 0x38 (Inherited: 0x18)
struct FMsgPartySessionDataNotify : FMsgBase {
	struct FPartySessionData PartySessionData; // 0x18(0x20)
};

// ScriptStruct DungeonCrawler.MsgPartySessionArrayRequest
// Size: 0x18 (Inherited: 0x18)
struct FMsgPartySessionArrayRequest : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgPartySessionArrayResponse
// Size: 0x28 (Inherited: 0x18)
struct FMsgPartySessionArrayResponse : FMsgBase {
	struct TArray<struct UPartySession*> PartySessionArray; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgPartySessionNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgPartySessionNotify : FMsgBase {
	struct UPartySession* PartySession; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgPartyLinkAllPartyDataNotify
// Size: 0x58 (Inherited: 0x18)
struct FMsgPartyLinkAllPartyDataNotify : FMsgBase {
	struct FPartyData PartyData; // 0x18(0x20)
	struct FPartyData OldPartyData; // 0x38(0x20)
};

// ScriptStruct DungeonCrawler.MsgPerkIdArrayNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgPerkIdArrayNotify : FMsgBase {
	struct TArray<struct FPrimaryAssetId> PerkIdArray; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.PerkWidgetData
// Size: 0x30 (Inherited: 0x00)
struct FPerkWidgetData {
	struct FText PerkName; // 0x00(0x18)
	struct FText PerkDescription; // 0x18(0x18)
};

// ScriptStruct DungeonCrawler.MsgPlayerLogoutNotify
// Size: 0x90 (Inherited: 0x18)
struct FMsgPlayerLogoutNotify : FMsgBase {
	struct FAccountDataReplication AccountDataReplication; // 0x18(0x78)
};

// ScriptStruct DungeonCrawler.MsgPlayerTargetNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgPlayerTargetNotify : FMsgBase {
	struct FString AccountId; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgPlayerDieNotify
// Size: 0x2d8 (Inherited: 0x18)
struct FMsgPlayerDieNotify : FMsgBase {
	struct FAccountSessionData AccountSessionData; // 0x18(0xf0)
	struct UGameplayEffect* GameplayEffectClass; // 0x108(0x08)
	struct FDCGameplayEffectContext EffectContext; // 0x110(0x1c8)
};

// ScriptStruct DungeonCrawler.MsgPlayerReturnToCharacterSelectRequest
// Size: 0x18 (Inherited: 0x18)
struct FMsgPlayerReturnToCharacterSelectRequest : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgCharacterResurrectionRequest
// Size: 0xc0 (Inherited: 0x18)
struct FMsgCharacterResurrectionRequest : FMsgBase {
	struct FString ID; // 0x18(0x10)
	char pad_28[0x8]; // 0x28(0x08)
	struct FTransform Transform; // 0x30(0x60)
	float SpawnDelay; // 0x90(0x04)
	bool bIsRemoveAllItem; // 0x94(0x01)
	char pad_95[0x3]; // 0x95(0x03)
	struct ACharacter* CharacterProduction; // 0x98(0x08)
	struct ADCCharacterBase* DCCharacterBase; // 0xa0(0x08)
	struct TArray<struct FDCGameplayEffectSetByCallerData> InitGameplayEffectSetByCallerDataArray; // 0xa8(0x10)
	char pad_B8[0x8]; // 0xb8(0x08)
};

// ScriptStruct DungeonCrawler.MsgCharacterResurrectionResponse
// Size: 0x20 (Inherited: 0x18)
struct FMsgCharacterResurrectionResponse : FMsgBase {
	struct ADCCharacterBase* DCCharacterBase; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgPlayerRestartNotify
// Size: 0x90 (Inherited: 0x18)
struct FMsgPlayerRestartNotify : FMsgBase {
	struct FAccountDataReplication AccountDataReplication; // 0x18(0x78)
};

// ScriptStruct DungeonCrawler.MsgShowSystemMessage
// Size: 0x30 (Inherited: 0x18)
struct FMsgShowSystemMessage : FMsgBase {
	struct FText MessageToShow; // 0x18(0x18)
};

// ScriptStruct DungeonCrawler.DCPlayMusicDataContainer
// Size: 0x18 (Inherited: 0x00)
struct FDCPlayMusicDataContainer {
	struct UAkSwitchValue* AkSwitch; // 0x00(0x08)
	struct FName MontageSectionName; // 0x08(0x08)
	float SectionPlayTime; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct DungeonCrawler.MsgProjectileHit
// Size: 0x190 (Inherited: 0x18)
struct FMsgProjectileHit : FMsgBase {
	struct FGameplayAbilityTargetDataHandle TargetDataHandle; // 0x18(0x28)
	struct FHitResult Hit; // 0x40(0xe8)
	char pad_128[0x8]; // 0x128(0x08)
	struct FTransform ActorPrevTickTransform; // 0x130(0x60)
};

// ScriptStruct DungeonCrawler.MsgProjectileHitByTarget
// Size: 0x38 (Inherited: 0x18)
struct FMsgProjectileHitByTarget : FMsgBase {
	struct AActor* SourceActor; // 0x18(0x08)
	struct FVector HitLocation; // 0x20(0x18)
};

// ScriptStruct DungeonCrawler.MsgProjectileSetFireData
// Size: 0x100 (Inherited: 0x18)
struct FMsgProjectileSetFireData : FMsgBase {
	struct FHitResult Hit; // 0x18(0xe8)
};

// ScriptStruct DungeonCrawler.MsgPropsFloorPortalScrollNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgPropsFloorPortalScrollNotify : FMsgBase {
	bool bActive; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.StartGameSessionState
// Size: 0x01 (Inherited: 0x00)
struct FStartGameSessionState {
	bool Status; // 0x00(0x01)
};

// ScriptStruct DungeonCrawler.ProcessTerminateState
// Size: 0x08 (Inherited: 0x00)
struct FProcessTerminateState {
	bool Status; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
};

// ScriptStruct DungeonCrawler.UpdateGameSessionState
// Size: 0x01 (Inherited: 0x00)
struct FUpdateGameSessionState {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct DungeonCrawler.HealthCheckState
// Size: 0x01 (Inherited: 0x00)
struct FHealthCheckState {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct DungeonCrawler.DCGameEnterUser
// Size: 0x70 (Inherited: 0x00)
struct FDCGameEnterUser {
	struct FString ServiceUrl; // 0x00(0x10)
	struct FNickname Nickname; // 0x10(0x28)
	struct FString CharacterClassStr; // 0x38(0x10)
	struct FDCCharacterId CharacterId; // 0x48(0x10)
	enum class EDCGender Gender; // 0x58(0x01)
	char pad_59[0x3]; // 0x59(0x03)
	uint32_t Level; // 0x5c(0x04)
	struct FDCPartyId PartyId; // 0x60(0x10)
};

// ScriptStruct DungeonCrawler.ServerMsgLobbyCharacterNotify
// Size: 0xa8 (Inherited: 0x18)
struct FServerMsgLobbyCharacterNotify : FMsgBase {
	struct FLobbyCharacterInfo LobbyCharacterData; // 0x18(0x90)
};

// ScriptStruct DungeonCrawler.ServerMsgReConnectGameInfoRequest
// Size: 0xf8 (Inherited: 0x18)
struct FServerMsgReConnectGameInfoRequest : FMsgBase {
	struct FAccountData AccountData; // 0x18(0xe0)
};

// ScriptStruct DungeonCrawler.ServerMsgReConnectGameInfoResponse
// Size: 0x100 (Inherited: 0x18)
struct FServerMsgReConnectGameInfoResponse : FMsgBase {
	struct FAccountData AccountData; // 0x18(0xe0)
	bool isSuccess; // 0xf8(0x01)
	char pad_F9[0x7]; // 0xf9(0x07)
};

// ScriptStruct DungeonCrawler.ServerMsgEndNotify
// Size: 0x18 (Inherited: 0x18)
struct FServerMsgEndNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.SkillDataInfo
// Size: 0x24 (Inherited: 0x00)
struct FSkillDataInfo {
	struct FActiveGameplayEffectHandle EffectHandle; // 0x00(0x08)
	struct FGameplayTag SkillTag; // 0x08(0x08)
	struct FGameplayTag CooldownTag; // 0x10(0x08)
	float RemainDuration; // 0x18(0x04)
	float MaxDuration; // 0x1c(0x04)
	float StartTime; // 0x20(0x04)
};

// ScriptStruct DungeonCrawler.MsgSkillIdArrayNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgSkillIdArrayNotify : FMsgBase {
	struct TArray<struct FPrimaryAssetId> SkillIdArray; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgSkillDataUpdateNotify
// Size: 0x50 (Inherited: 0x18)
struct FMsgSkillDataUpdateNotify : FMsgBase {
	enum class ESkillIndex SlotIndex; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	struct FSkillData SkillData; // 0x1c(0x30)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// ScriptStruct DungeonCrawler.SkillData
// Size: 0x30 (Inherited: 0x00)
struct FSkillData {
	struct FPrimaryAssetId SkillId; // 0x00(0x10)
	struct FGameplayTag SkillTag; // 0x10(0x08)
	struct FGameplayTag SkillCooldownTag; // 0x18(0x08)
	int32_t Count; // 0x20(0x04)
	int32_t RequiredChargeAmount; // 0x24(0x04)
	int32_t ChargeAmount; // 0x28(0x04)
	int32_t SlotIndex; // 0x2c(0x04)
};

// ScriptStruct DungeonCrawler.MsgSkillRechargeRequest
// Size: 0x20 (Inherited: 0x18)
struct FMsgSkillRechargeRequest : FMsgBase {
	int32_t RechargeAmount; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.SkillWidgetData
// Size: 0x30 (Inherited: 0x00)
struct FSkillWidgetData {
	struct FText SkillName; // 0x00(0x18)
	struct FText SkillDescription; // 0x18(0x18)
};

// ScriptStruct DungeonCrawler.DCSoundDataContainer
// Size: 0x50 (Inherited: 0x00)
struct FDCSoundDataContainer {
	struct TMap<enum class EPhysicalSurface, struct UAkSwitchValue*> AkSwitchBySurfaceType; // 0x00(0x50)
};

// ScriptStruct DungeonCrawler.MsgSoundEvent
// Size: 0x20 (Inherited: 0x18)
struct FMsgSoundEvent : FMsgBase {
	struct FGameplayTag EventTag; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgSoundVolumeEnter
// Size: 0x58 (Inherited: 0x18)
struct FMsgSoundVolumeEnter : FMsgBase {
	struct FAkAudioVolumeInfo AkVolumeInfo; // 0x18(0x40)
};

// ScriptStruct DungeonCrawler.AkAudioVolumeInfo
// Size: 0x40 (Inherited: 0x00)
struct FAkAudioVolumeInfo {
	float Priority; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct UAkAudioEvent* AkEventBeginOverlap; // 0x08(0x08)
	struct UAkStateValue* AkStateValueBeginOverlap; // 0x10(0x08)
	struct UAkAudioEvent* AkEventEndOverlap; // 0x18(0x08)
	struct UAkStateValue* AkStateValueEndOverlap; // 0x20(0x08)
	struct UAkRtpc* Rtpc; // 0x28(0x08)
	float RtpcValue; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct UPrimitiveComponent* Volume; // 0x38(0x08)
};

// ScriptStruct DungeonCrawler.MsgSoundVolumeExit
// Size: 0x20 (Inherited: 0x18)
struct FMsgSoundVolumeExit : FMsgBase {
	struct UPrimitiveComponent* Volume; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgUpdateSoundDataEvent
// Size: 0x20 (Inherited: 0x18)
struct FMsgUpdateSoundDataEvent : FMsgBase {
	struct USoundData* Data; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgSpellSetCurrentSpellData
// Size: 0x48 (Inherited: 0x18)
struct FMsgSpellSetCurrentSpellData : FMsgBase {
	struct FSpellData SpellData; // 0x18(0x30)
};

// ScriptStruct DungeonCrawler.SpellData
// Size: 0x30 (Inherited: 0x00)
struct FSpellData {
	struct FPrimaryAssetId SpellId; // 0x00(0x10)
	struct FGameplayTag SpellTag; // 0x10(0x08)
	int32_t Count; // 0x18(0x04)
	int32_t RequiredChargeAmount; // 0x1c(0x04)
	int32_t ChargeAmount; // 0x20(0x04)
	int32_t SlotIndex; // 0x24(0x04)
	int32_t SequenceIndex; // 0x28(0x04)
	bool bIsCapacityOverloaded; // 0x2c(0x01)
	char pad_2D[0x3]; // 0x2d(0x03)
};

// ScriptStruct DungeonCrawler.MsgSpellRecharge
// Size: 0x20 (Inherited: 0x18)
struct FMsgSpellRecharge : FMsgBase {
	int32_t RechargeAmount; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.MsgSpellDataUpdateNotify
// Size: 0x48 (Inherited: 0x18)
struct FMsgSpellDataUpdateNotify : FMsgBase {
	struct FSpellData SpellData; // 0x18(0x30)
};

// ScriptStruct DungeonCrawler.MsgSpellCapacityChangedNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgSpellCapacityChangedNotify : FMsgBase {
	float SpellCurrentCapacity; // 0x18(0x04)
	float SpellMaxCapacity; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.MsgSpellCastStart
// Size: 0x38 (Inherited: 0x18)
struct FMsgSpellCastStart : FMsgBase {
	float Duration; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FText Description; // 0x20(0x18)
};

// ScriptStruct DungeonCrawler.MsgSpellCastSucceed
// Size: 0x18 (Inherited: 0x18)
struct FMsgSpellCastSucceed : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgSpellCastEnd
// Size: 0x18 (Inherited: 0x18)
struct FMsgSpellCastEnd : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgSpellChannelingStart
// Size: 0x38 (Inherited: 0x18)
struct FMsgSpellChannelingStart : FMsgBase {
	float Duration; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FText Description; // 0x20(0x18)
};

// ScriptStruct DungeonCrawler.MsgSpellChannelingEnd
// Size: 0x18 (Inherited: 0x18)
struct FMsgSpellChannelingEnd : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.TimerWidgetData
// Size: 0x10 (Inherited: 0x00)
struct FTimerWidgetData {
	int32_t LeftHour; // 0x00(0x04)
	int32_t LeftMinute; // 0x04(0x04)
	int32_t LeftSecond; // 0x08(0x04)
	float Progress; // 0x0c(0x04)
};

// ScriptStruct DungeonCrawler.TradeChannelChatWidgetData
// Size: 0x50 (Inherited: 0x00)
struct FTradeChannelChatWidgetData {
	enum class EChatType ChatType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FChatAccountData ChatAccountData; // 0x08(0x48)
};

// ScriptStruct DungeonCrawler.TradeChatWidgetData
// Size: 0x48 (Inherited: 0x00)
struct FTradeChatWidgetData {
	struct FChatAccountData ChatAccountData; // 0x00(0x48)
};

// ScriptStruct DungeonCrawler.VoipAkComponentData
// Size: 0x04 (Inherited: 0x00)
struct FVoipAkComponentData {
	char pad_0[0x4]; // 0x00(0x04)
};

// ScriptStruct DungeonCrawler.VoipUserData
// Size: 0x08 (Inherited: 0x00)
struct FVoipUserData {
	char pad_0[0x4]; // 0x00(0x04)
	float ReceiveVolume; // 0x04(0x04)
};

// ScriptStruct DungeonCrawler.VoipPartyMemberData
// Size: 0x38 (Inherited: 0x00)
struct FVoipPartyMemberData {
	struct FDCAccountId AccountId; // 0x00(0x10)
	struct FNickname Nickname; // 0x10(0x28)
};

// ScriptStruct DungeonCrawler.VoipPartyData
// Size: 0x20 (Inherited: 0x00)
struct FVoipPartyData {
	struct FDCPartyId PartyId; // 0x00(0x10)
	struct TArray<struct FVoipPartyMemberData> VoipPartyMemberDataArray; // 0x10(0x10)
};

// ScriptStruct DungeonCrawler.VoipUserWidgetData
// Size: 0x38 (Inherited: 0x00)
struct FVoipUserWidgetData {
	struct FDCAccountId AccountId; // 0x00(0x10)
	struct FVoipUserData VoipUserData; // 0x10(0x08)
	struct FVoipPartyData VoipPartyData; // 0x18(0x20)
};

// ScriptStruct DungeonCrawler.MsgWidgetCharacterSelectGroupToggleRequest
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetCharacterSelectGroupToggleRequest : FMsgBase {
	enum class EWidgetCharacterSelectGroupType WidgetCharacterSelectGroupType; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetCharacterSelectGroupToggleNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetCharacterSelectGroupToggleNotify : FMsgBase {
	enum class EWidgetCharacterSelectGroupType WidgetCharacterSelectGroupType; // 0x18(0x01)
	enum class ESlateVisibility NewVisibility; // 0x19(0x01)
	char pad_1A[0x6]; // 0x1a(0x06)
};

// ScriptStruct DungeonCrawler.MsgWidgetEnterCreateCharacterPageNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetEnterCreateCharacterPageNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetExitCreateCharacterPageNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetExitCreateCharacterPageNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetDeleteCharacterNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetDeleteCharacterNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetRequestCharacterListNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetRequestCharacterListNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetUpdatePageNumberNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetUpdatePageNumberNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetCreateCharacterErrorMessageNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgetCreateCharacterErrorMessageNotify : FMsgBase {
	struct FText CreateCharacterErrorMessage; // 0x18(0x18)
};

// ScriptStruct DungeonCrawler.MsgWidgetGameGroupHideUIbyNonCoexistWidgetRequest
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetGameGroupHideUIbyNonCoexistWidgetRequest : FMsgBase {
	enum class EWidgetGameGroupType WidgetGameGroupType; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetGameGroupHideUIbyNonCoexistWidgetResponse
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetGameGroupHideUIbyNonCoexistWidgetResponse : FMsgBase {
	enum class EWidgetGameGroupType WidgetGameGroupType; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetGameGroupToggleRequest
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetGameGroupToggleRequest : FMsgBase {
	enum class EWidgetGameGroupType WidgetGameGroupType; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetGameGroupToggleNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetGameGroupToggleNotify : FMsgBase {
	enum class EWidgetGameGroupType WidgetGameGroupType; // 0x18(0x01)
	enum class ESlateVisibility NewVisibility; // 0x19(0x01)
	char pad_1A[0x6]; // 0x1a(0x06)
};

// ScriptStruct DungeonCrawler.MsgWidgetGameGroupVisibilityRequest
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetGameGroupVisibilityRequest : FMsgBase {
	enum class EWidgetGameGroupType WidgetGameGroupType; // 0x18(0x01)
	enum class ESlateVisibility NewVisibility; // 0x19(0x01)
	char pad_1A[0x6]; // 0x1a(0x06)
};

// ScriptStruct DungeonCrawler.MsgWidgetHitDirectionInfoNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgetHitDirectionInfoNotify : FMsgBase {
	struct FVector HitDirection; // 0x18(0x18)
};

// ScriptStruct DungeonCrawler.MsgWidgetHitDirectionHealingNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetHitDirectionHealingNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetChangeCrossHairEachWeaponNotify
// Size: 0x40 (Inherited: 0x18)
struct FMsgWidgetChangeCrossHairEachWeaponNotify : FMsgBase {
	struct TArray<struct FGameplayTag> WeaponTypeTags; // 0x18(0x10)
	struct FGameplayTag ItemUtilityTag; // 0x28(0x08)
	struct FGameplayTag ItemSlotTypeTag; // 0x30(0x08)
	bool IsAttackEnable; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetChangeCrossHairInfoNotify
// Size: 0x38 (Inherited: 0x18)
struct FMsgWidgetChangeCrossHairInfoNotify : FMsgBase {
	struct TArray<struct FGameplayTag> WeaponTypeTags; // 0x18(0x10)
	float ChangeAngle; // 0x28(0x04)
	bool OnPinPoint; // 0x2c(0x01)
	char pad_2D[0x3]; // 0x2d(0x03)
	float RotateTime; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetInitCrossHairNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetInitCrossHairNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetChangeCrossHairWhenThrowingNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgetChangeCrossHairWhenThrowingNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetPlayPullingCrossHairNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetPlayPullingCrossHairNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetPlayShootCrossHairNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetPlayShootCrossHairNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetOnActivateSpellCrossHairNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetOnActivateSpellCrossHairNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetSkillCooldownStartWidgetNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgWidgetSkillCooldownStartWidgetNotify : FMsgBase {
	struct FGameplayTag SkillTag; // 0x18(0x08)
	float RemainDuration; // 0x20(0x04)
	float MaxDuration; // 0x24(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetSkillCooldownEndWidgetNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgWidgetSkillCooldownEndWidgetNotify : FMsgBase {
	struct FGameplayTag SkillSlotKeyTag; // 0x18(0x08)
	struct FGameplayTag SkillTag; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetSkillCooldownClearWidgetNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetSkillCooldownClearWidgetNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetGameCancelTipVisibilityRequest
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetGameCancelTipVisibilityRequest : FMsgBase {
	enum class ESlateVisibility NewVisibility; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetShowVideoDisplayApplyAlarmWndNotity
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetShowVideoDisplayApplyAlarmWndNotity : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetOptionVideoDisplayApplyedNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetOptionVideoDisplayApplyedNotify : FMsgBase {
	bool IsApplyed; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetLobbyGroupHideUIbyNonCoexistWidgetRequest
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetLobbyGroupHideUIbyNonCoexistWidgetRequest : FMsgBase {
	enum class EWidgetLobbyGroupType WidgetLobbyGroupType; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	int32_t LobbyGroupWidgetPriority; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetLobbyGroupHideUIbyNonCoexistWidgetResponse
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetLobbyGroupHideUIbyNonCoexistWidgetResponse : FMsgBase {
	enum class EWidgetLobbyGroupType WidgetLobbyGroupType; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetLobbyGroupToggleRequest
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetLobbyGroupToggleRequest : FMsgBase {
	enum class EWidgetLobbyGroupType WidgetLobbyGroupType; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetLobbyGroupVisibilityRequest
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetLobbyGroupVisibilityRequest : FMsgBase {
	enum class EWidgetLobbyGroupType WidgetLobbyGroupType; // 0x18(0x01)
	enum class ESlateVisibility NewVisibility; // 0x19(0x01)
	char pad_1A[0x6]; // 0x1a(0x06)
};

// ScriptStruct DungeonCrawler.MsgWidgetLobbyGroupToggleNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetLobbyGroupToggleNotify : FMsgBase {
	enum class EWidgetLobbyGroupType WidgetLobbyGroupType; // 0x18(0x01)
	enum class ESlateVisibility NewVisibility; // 0x19(0x01)
	char pad_1A[0x6]; // 0x1a(0x06)
};

// ScriptStruct DungeonCrawler.MsgWidgetLobbyGroupHideRequest
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetLobbyGroupHideRequest : FMsgBase {
	enum class EWidgetLobbyGroupType WidgetLobbyGroupType; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetLobbyGroupHideResponse
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetLobbyGroupHideResponse : FMsgBase {
	enum class EWidgetLobbyGroupType WidgetLobbyGroupType; // 0x18(0x01)
	bool bCanHide; // 0x19(0x01)
	char pad_1A[0x6]; // 0x1a(0x06)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassGroupHideUIbyNonCoexistWidgetRequest
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetClassGroupHideUIbyNonCoexistWidgetRequest : FMsgBase {
	enum class EWidgetClassGroupType WidgetClassGroupType; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassGroupToggleRequest
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetClassGroupToggleRequest : FMsgBase {
	enum class EWidgetClassGroupType WidgetClassGroupType; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassGroupToggleNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetClassGroupToggleNotify : FMsgBase {
	enum class EWidgetClassGroupType WidgetClassGroupType; // 0x18(0x01)
	enum class ESlateVisibility NewVisibility; // 0x19(0x01)
	char pad_1A[0x6]; // 0x1a(0x06)
};

// ScriptStruct DungeonCrawler.MsgWidgetPlayerInventoryTabActiveNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetPlayerInventoryTabActiveNotify : FMsgBase {
	enum class EWidgetPlayerInventoryTabType WidgetPlayerInventoryTabType; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetLeaderBoardBeginNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetLeaderBoardBeginNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetLeaderBoardSelectNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgetLeaderBoardSelectNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetLeaderBoardClassIconButtonClickNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetLeaderBoardClassIconButtonClickNotify : FMsgBase {
	struct ULeaderBoardClassIconWidgetData* ClickData; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgeLobbyPopupSWidgetNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgeLobbyPopupSWidgetNotify : FMsgBase {
	struct FText DescText; // 0x18(0x18)
};

// ScriptStruct DungeonCrawler.WidgetPartyCharacterVisibleBody
// Size: 0x02 (Inherited: 0x00)
struct FWidgetPartyCharacterVisibleBody {
	enum class EWidgetPartyUserLocate WidgetPartyUserLocate; // 0x00(0x01)
	bool Visible; // 0x01(0x01)
};

// ScriptStruct DungeonCrawler.MsgPartyMemberEnter
// Size: 0xb0 (Inherited: 0x18)
struct FMsgPartyMemberEnter : FMsgBase {
	enum class EWidgetPartyUserLocate WidgetLocate; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FPlayPartyUserInfo UserInfo; // 0x20(0x90)
};

// ScriptStruct DungeonCrawler.PlayPartyUserInfo
// Size: 0x90 (Inherited: 0x00)
struct FPlayPartyUserInfo {
	enum class EWidgetPlayUserPartyState PartyState; // 0x00(0x01)
	enum class EWidgetPartyUserLocate WidgetLocate; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct FCharacterPartyInfoWidget PartyCharacterInfo; // 0x08(0x88)
};

// ScriptStruct DungeonCrawler.CharacterPartyInfoWidget
// Size: 0x88 (Inherited: 0x00)
struct FCharacterPartyInfoWidget {
	struct FString AccountId; // 0x00(0x10)
	struct FNickname Nickname; // 0x10(0x28)
	struct FString CharacterClass; // 0x38(0x10)
	struct FString CharacterId; // 0x48(0x10)
	int32_t Gender; // 0x58(0x04)
	int32_t Level; // 0x5c(0x04)
	int32_t IsPartyLeader; // 0x60(0x04)
	int32_t IsReady; // 0x64(0x04)
	int32_t IsInGame; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct TArray<struct FAccountDataItem> EquipItemList; // 0x70(0x10)
	int32_t PartyIdx; // 0x80(0x04)
	char pad_84[0x4]; // 0x84(0x04)
};

// ScriptStruct DungeonCrawler.MsgPartyMemberLeave
// Size: 0x20 (Inherited: 0x18)
struct FMsgPartyMemberLeave : FMsgBase {
	enum class EWidgetPartyUserLocate WidgetLocate; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgLobbyCharacterResetEquipItemNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgLobbyCharacterResetEquipItemNotify : FMsgBase {
	enum class EWidgetPartyUserLocate WidgetPartyUserLocate; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct TArray<struct FItemData> ItemData; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetLoadoutBeginNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetLoadoutBeginNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgLobbyCharacterInfoNotify
// Size: 0xb0 (Inherited: 0x18)
struct FMsgLobbyCharacterInfoNotify : FMsgBase {
	enum class EWidgetPartyUserLocate WidgetPartyUserLocate; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FLobbyCharacterInfo LobbyCharacterData; // 0x20(0x90)
};

// ScriptStruct DungeonCrawler.MsgPlayPartyReadyStateChangedNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgPlayPartyReadyStateChangedNotify : FMsgBase {
	enum class EWidgetPartyUserLocate WidgetPartyUserLocate; // 0x18(0x01)
	bool bLeader; // 0x19(0x01)
	bool bReady; // 0x1a(0x01)
	char pad_1B[0x5]; // 0x1b(0x05)
};

// ScriptStruct DungeonCrawler.MsgPlayMatchingStateChangedNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgPlayMatchingStateChangedNotify : FMsgBase {
	bool bMatching; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetStorageBeginNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetStorageBeginNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetPlayBeginNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetPlayBeginNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetCustomizeBeginNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetCustomizeBeginNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetShopBeginNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetShopBeginNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetLobbySystemMessageNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgetLobbySystemMessageNotify : FMsgBase {
	struct FText AnnounceText; // 0x18(0x18)
};

// ScriptStruct DungeonCrawler.MsgWidgetMerchantListBeginNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetMerchantListBeginNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetAddItemOnDealTableSuccessNotify
// Size: 0xb8 (Inherited: 0x18)
struct FMsgWidgetAddItemOnDealTableSuccessNotify : FMsgBase {
	struct FItemData ItemData; // 0x18(0xa0)
};

// ScriptStruct DungeonCrawler.MsgWidgetRemoveItemFromDealTable
// Size: 0xb8 (Inherited: 0x18)
struct FMsgWidgetRemoveItemFromDealTable : FMsgBase {
	struct FItemData ItemData; // 0x18(0xa0)
};

// ScriptStruct DungeonCrawler.MsgWidgetRemoveItemFromDealTableSuccessNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetRemoveItemFromDealTableSuccessNotify : FMsgBase {
	int64_t ItemUniqueId; // 0x18(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetLeaderBoardRankRangeNotify
// Size: 0x50 (Inherited: 0x18)
struct FMsgWidgetLeaderBoardRankRangeNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x30]; // 0x20(0x30)
};

// ScriptStruct DungeonCrawler.MsgWidgetLeaderBoardRankNearByNotify
// Size: 0x50 (Inherited: 0x18)
struct FMsgWidgetLeaderBoardRankNearByNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x30]; // 0x20(0x30)
};

// ScriptStruct DungeonCrawler.MsgWidgetLeaderBoardRankCharacterNotify
// Size: 0x90 (Inherited: 0x18)
struct FMsgWidgetLeaderBoardRankCharacterNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x70]; // 0x20(0x70)
};

// ScriptStruct DungeonCrawler.MsgWidgetPlayCharacterRefreshNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetPlayCharacterRefreshNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetPlayRegionNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetPlayRegionNotify : FMsgBase {
	int32_t Region; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradeChannelChatRequest
// Size: 0xa8 (Inherited: 0x18)
struct FMsgWidgetTradeChannelChatRequest : FMsgBase {
	enum class EChatType ChatType; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FString ChatTargetAccountId; // 0x20(0x10)
	struct FString ChatTargetCharacterId; // 0x30(0x10)
	struct FChatData ChatData; // 0x40(0x68)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradeChannelChatResponse
// Size: 0x28 (Inherited: 0x18)
struct FMsgWidgetTradeChannelChatResponse : FMsgBase {
	enum class EMsgWidgetChatResult Result; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FTimespan TimeLeft; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradeChannelChatNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgetTradeChannelChatNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x10]; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradeChannelListBeginNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetTradeChannelListBeginNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradingChatRequest
// Size: 0xa8 (Inherited: 0x18)
struct FMsgWidgetTradingChatRequest : FMsgBase {
	enum class EChatType ChatType; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FString ChatTargetAccountId; // 0x20(0x10)
	struct FString ChatTargetCharacterId; // 0x30(0x10)
	struct FChatData ChatData; // 0x40(0x68)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradingChatResponse
// Size: 0x28 (Inherited: 0x18)
struct FMsgWidgetTradingChatResponse : FMsgBase {
	enum class EMsgWidgetChatResult Result; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FTimespan TimeLeft; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradingChatNotify
// Size: 0x90 (Inherited: 0x18)
struct FMsgWidgetTradingChatNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x70]; // 0x20(0x70)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradeChannelListNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgetTradeChannelListNotify : FMsgBase {
	bool bIsTrader; // 0x18(0x01)
	char pad_19[0x17]; // 0x19(0x17)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradeSubscriptionBeginNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetTradeSubscriptionBeginNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradeSubscriptionButtonClicked
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetTradeSubscriptionButtonClicked : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradeSubscriptionSuccessNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetTradeSubscriptionSuccessNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradeSubscriptionFailedNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetTradeSubscriptionFailedNotify : FMsgBase {
	int32_t Reason; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradeChannelButtonClicked
// Size: 0x40 (Inherited: 0x18)
struct FMsgWidgetTradeChannelButtonClicked : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x20]; // 0x20(0x20)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradeChannelBeginNotify
// Size: 0x40 (Inherited: 0x18)
struct FMsgWidgetTradeChannelBeginNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x20]; // 0x20(0x20)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradeChannelEndNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetTradeChannelEndNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradeChatUserListAddNotify
// Size: 0x38 (Inherited: 0x18)
struct FMsgWidgetTradeChatUserListAddNotify : FMsgBase {
	bool bIsStart; // 0x18(0x01)
	char pad_19[0x17]; // 0x19(0x17)
	bool bIsFinish; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradeChatUserListUpdateNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgWidgetTradeChatUserListUpdateNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradeRequestSelected
// Size: 0x80 (Inherited: 0x18)
struct FMsgWidgetTradeRequestSelected : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x60]; // 0x20(0x60)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassTopMenuBeginNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetClassTopMenuBeginNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradeBeginNotify
// Size: 0x50 (Inherited: 0x18)
struct FMsgWidgetTradeBeginNotify : FMsgBase {
	struct FText MyNickName; // 0x18(0x18)
	struct FText TargetNickname; // 0x30(0x18)
	int32_t TradeFee; // 0x48(0x04)
	int32_t ResetDuration; // 0x4c(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradeEndNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetTradeEndNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradeConfirmBeginNotify
// Size: 0x50 (Inherited: 0x18)
struct FMsgWidgetTradeConfirmBeginNotify : FMsgBase {
	struct FText MyNickName; // 0x18(0x18)
	struct FText TargetNickname; // 0x30(0x18)
	int32_t TradeFee; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetTradingCanMoveItemStateNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetTradingCanMoveItemStateNotify : FMsgBase {
	bool bCanMove; // 0x18(0x01)
	bool bIsMine; // 0x19(0x01)
	char pad_1A[0x6]; // 0x1a(0x06)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassBeginNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetClassBeginNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassLevelNotifyBody
// Size: 0x14 (Inherited: 0x00)
struct FMsgWidgetClassLevelNotifyBody {
	int32_t Level; // 0x00(0x04)
	int32_t Exp; // 0x04(0x04)
	int32_t ExpBegin; // 0x08(0x04)
	int32_t ExpLimit; // 0x0c(0x04)
	int32_t RewardPoint; // 0x10(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassLevelNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgetClassLevelNotify : FMsgBase {
	struct FMsgWidgetClassLevelNotifyBody ClassLevelInfo; // 0x18(0x14)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassSlotUnLockLevelNotify
// Size: 0x38 (Inherited: 0x18)
struct FMsgWidgetClassSlotUnLockLevelNotify : FMsgBase {
	struct TArray<int32_t> IndexArray; // 0x18(0x10)
	struct TArray<int32_t> UnLockLevelArray; // 0x28(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassEquipNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgWidgetClassEquipNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x8]; // 0x20(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassEquipInfoBeginNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetClassEquipInfoBeginNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassPerkBeginNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetClassPerkBeginNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassPerkListNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgWidgetClassPerkListNotify : FMsgBase {
	struct TArray<struct FPerkData> PerkIdArray; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassSkillBeginNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetClassSkillBeginNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassSkillListNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgWidgetClassSkillListNotify : FMsgBase {
	struct TArray<struct FDataSkill> SkillIdArray; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassSpellBeginNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetClassSpellBeginNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassSpellEquippedListNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgWidgetClassSpellEquippedListNotify : FMsgBase {
	struct TArray<struct FSpellData> SpellArray; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassSpellUnequippedListNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgWidgetClassSpellUnequippedListNotify : FMsgBase {
	struct TArray<struct FSpellData> SpellArray; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassItemMoveRequestNotify
// Size: 0x58 (Inherited: 0x18)
struct FMsgWidgetClassItemMoveRequestNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
	char pad_20[0x38]; // 0x20(0x38)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassItemMoveResponseNotify
// Size: 0x60 (Inherited: 0x18)
struct FMsgWidgetClassItemMoveResponseNotify : FMsgBase {
	int32_t Result; // 0x18(0x04)
	char pad_1C[0x44]; // 0x1c(0x44)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassSpellSlotMoveRequestNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgetClassSpellSlotMoveRequestNotify : FMsgBase {
	int32_t Index; // 0x18(0x04)
	struct FPrimaryAssetId SpellId; // 0x1c(0x10)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassSpellSequenceChangeRequestNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgetClassSpellSequenceChangeRequestNotify : FMsgBase {
	int32_t SequenceIndex; // 0x18(0x04)
	struct FPrimaryAssetId SpellId; // 0x1c(0x10)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassUnEquipmentTypeChangeNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetClassUnEquipmentTypeChangeNotify : FMsgBase {
	int32_t Index; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassAddEquipPerkNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgetClassAddEquipPerkNotify : FMsgBase {
	int32_t Index; // 0x18(0x04)
	struct FPrimaryAssetId PerkId; // 0x1c(0x10)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassAddUnEquipPerkNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgWidgetClassAddUnEquipPerkNotify : FMsgBase {
	struct FPrimaryAssetId PerkId; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassRemoveEquipPerkNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgetClassRemoveEquipPerkNotify : FMsgBase {
	int32_t Index; // 0x18(0x04)
	struct FPrimaryAssetId PerkId; // 0x1c(0x10)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassRemoveUnEquipPerkNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgWidgetClassRemoveUnEquipPerkNotify : FMsgBase {
	struct FPrimaryAssetId PerkId; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassAddEquipSkillNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgetClassAddEquipSkillNotify : FMsgBase {
	int32_t Index; // 0x18(0x04)
	struct FPrimaryAssetId SkillId; // 0x1c(0x10)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassAddUnEquipSkillNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgWidgetClassAddUnEquipSkillNotify : FMsgBase {
	struct FPrimaryAssetId SkillId; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassRemoveEquipSkillNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgetClassRemoveEquipSkillNotify : FMsgBase {
	int32_t Index; // 0x18(0x04)
	struct FPrimaryAssetId SkillId; // 0x1c(0x10)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassRemoveUnEquipSkillNotify
// Size: 0x28 (Inherited: 0x18)
struct FMsgWidgetClassRemoveUnEquipSkillNotify : FMsgBase {
	struct FPrimaryAssetId SkillId; // 0x18(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassPerkEventNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgetClassPerkEventNotify : FMsgBase {
	int32_t Move; // 0x18(0x04)
	int32_t Index; // 0x1c(0x04)
	struct FPrimaryAssetId PerkId; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassSkillEventNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgetClassSkillEventNotify : FMsgBase {
	int32_t Move; // 0x18(0x04)
	int32_t Index; // 0x1c(0x04)
	struct FPrimaryAssetId SkillId; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassPerkSwapEventNotify
// Size: 0x40 (Inherited: 0x18)
struct FMsgWidgetClassPerkSwapEventNotify : FMsgBase {
	int32_t SrcIndex; // 0x18(0x04)
	struct FPrimaryAssetId SrcPerkId; // 0x1c(0x10)
	int32_t DstIndex; // 0x2c(0x04)
	struct FPrimaryAssetId DstPerkId; // 0x30(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassSkillSwapEventNotify
// Size: 0x40 (Inherited: 0x18)
struct FMsgWidgetClassSkillSwapEventNotify : FMsgBase {
	int32_t SrcIndex; // 0x18(0x04)
	struct FPrimaryAssetId SrcSkillId; // 0x1c(0x10)
	int32_t DstIndex; // 0x2c(0x04)
	struct FPrimaryAssetId DstSkillId; // 0x30(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassSpellUnequipNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgetClassSpellUnequipNotify : FMsgBase {
	int32_t Index; // 0x18(0x04)
	struct FPrimaryAssetId SpellId; // 0x1c(0x10)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassSpellEquipNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgetClassSpellEquipNotify : FMsgBase {
	int32_t Index; // 0x18(0x04)
	struct FPrimaryAssetId SpellId; // 0x1c(0x10)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassUnEquipmentClearSelectedItemNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetClassUnEquipmentClearSelectedItemNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassEquipablePerkEmptySlotsMarkNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetClassEquipablePerkEmptySlotsMarkNotify : FMsgBase {
	bool bMark; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassEquipableSkillEmptySlotsMarkNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetClassEquipableSkillEmptySlotsMarkNotify : FMsgBase {
	bool bMark; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassSpellShowEquippableSlotNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetClassSpellShowEquippableSlotNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetClassSpellHideEquippableSlotNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetClassSpellHideEquippableSlotNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetSelectRegionButtonNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetSelectRegionButtonNotify : FMsgBase {
	int32_t Region; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetStashRefreshNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetStashRefreshNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetInvitePartyNotify
// Size: 0x60 (Inherited: 0x18)
struct FMsgWidgetInvitePartyNotify : FMsgBase {
	struct FNickname InviteeNickName; // 0x18(0x28)
	struct FString InviteeAccountId; // 0x40(0x10)
	struct FString InviteeCharacterId; // 0x50(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetMailBoxNewAlarmNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetMailBoxNewAlarmNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetKarmaBeginNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetKarmaBeginNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetKarmaReportInfoNotify
// Size: 0x38 (Inherited: 0x18)
struct FMsgWidgetKarmaReportInfoNotify : FMsgBase {
	struct TArray<struct FKarmaMatchInfo> MatchInfoArray; // 0x18(0x10)
	int32_t CurrentTicketCount; // 0x28(0x04)
	int32_t CollectionStepCount; // 0x2c(0x04)
	int32_t MaxCollectionCount; // 0x30(0x04)
	int32_t MaxTicketCount; // 0x34(0x04)
};

// ScriptStruct DungeonCrawler.KarmaMatchInfo
// Size: 0x18 (Inherited: 0x00)
struct FKarmaMatchInfo {
	int32_t MatchIdx; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<struct FKarmaMemberInfo> MemberInfoArray; // 0x08(0x10)
};

// ScriptStruct DungeonCrawler.KarmaMemberInfo
// Size: 0x58 (Inherited: 0x00)
struct FKarmaMemberInfo {
	struct FString AccountId; // 0x00(0x10)
	struct FString CharacterId; // 0x10(0x10)
	struct FNickname Nickname; // 0x20(0x28)
	enum class EDCCharacterClass DCCharacterClass; // 0x48(0x01)
	enum class EDCGender DCGender; // 0x49(0x01)
	bool IsVote; // 0x4a(0x01)
	char pad_4B[0x1]; // 0x4b(0x01)
	int32_t KarmaAction; // 0x4c(0x04)
	int32_t KarmaStatus; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetKarmaReportActionRequest
// Size: 0x48 (Inherited: 0x18)
struct FMsgWidgetKarmaReportActionRequest : FMsgBase {
	int32_t MatchIdx; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FString AccountId; // 0x20(0x10)
	struct FString CharacterId; // 0x30(0x10)
	int32_t Action; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetKarmaReportActionResponse
// Size: 0x88 (Inherited: 0x18)
struct FMsgWidgetKarmaReportActionResponse : FMsgBase {
	int32_t Result; // 0x18(0x04)
	int32_t MatchIdx; // 0x1c(0x04)
	struct FKarmaMemberInfo UpdatedMemberInfo; // 0x20(0x58)
	int32_t CurrentTicketCount; // 0x78(0x04)
	int32_t CollectionStepCount; // 0x7c(0x04)
	int32_t MaxCollectionCount; // 0x80(0x04)
	int32_t MaxTicketCount; // 0x84(0x04)
};

// ScriptStruct DungeonCrawler.PlayPartyUserInfoData
// Size: 0x10 (Inherited: 0x00)
struct FPlayPartyUserInfoData {
	struct TArray<struct FPlayPartyUserInfo> PlayPartyData; // 0x00(0x10)
};

// ScriptStruct DungeonCrawler.MsgSystemMessageNotify
// Size: 0x38 (Inherited: 0x18)
struct FMsgSystemMessageNotify : FMsgBase {
	struct FText OutputMessage; // 0x18(0x18)
	float Duration; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct DungeonCrawler.MsgPopup
// Size: 0x30 (Inherited: 0x18)
struct FMsgPopup : FMsgBase {
	enum class EPopupResult PopupResult; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct UDCCommonActivatableWidgetBase* WidgetClass; // 0x20(0x08)
	struct UPopupDataBase* PopupData; // 0x28(0x08)
};

// ScriptStruct DungeonCrawler.MsgPopupBaseNotify
// Size: 0x38 (Inherited: 0x30)
struct FMsgPopupBaseNotify : FMsgPopup {
	enum class EPopupResult PopupResult; // 0x18(0x01)
	struct UDCCommonActivatableWidgetBase* WidgetClass; // 0x20(0x08)
	struct UPopupDataBase* PopupData; // 0x28(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetPopupMessageNotify
// Size: 0x30 (Inherited: 0x30)
struct FMsgWidgetPopupMessageNotify : FMsgPopup {
	enum class EPopupResult PopupResult; // 0x18(0x01)
	struct UDCCommonActivatableWidgetBase* WidgetClass; // 0x20(0x08)
	struct UPopupDataBase* PopupData; // 0x28(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetPopupMessageReqeust
// Size: 0x30 (Inherited: 0x30)
struct FMsgWidgetPopupMessageReqeust : FMsgPopup {
	enum class EPopupResult PopupResult; // 0x18(0x01)
	struct UDCCommonActivatableWidgetBase* WidgetClass; // 0x20(0x08)
	struct UPopupDataBase* PopupData; // 0x28(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetPopupMessageResponse
// Size: 0x30 (Inherited: 0x30)
struct FMsgWidgetPopupMessageResponse : FMsgPopup {
	enum class EPopupResult PopupResult; // 0x18(0x01)
	struct UDCCommonActivatableWidgetBase* WidgetClass; // 0x20(0x08)
	struct UPopupDataBase* PopupData; // 0x28(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetPopupCloseRequest
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetPopupCloseRequest : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetPopupCloseResponse
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetPopupCloseResponse : FMsgBase {
	bool bSucceedClose; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetProgressBarStart
// Size: 0x38 (Inherited: 0x18)
struct FMsgWidgetProgressBarStart : FMsgBase {
	struct FText Description; // 0x18(0x18)
	float Duration; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetProgressBarPause
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetProgressBarPause : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetProgressBarResume
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetProgressBarResume : FMsgBase {
	float AdditionalElapsedTimeRatio; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct DungeonCrawler.MsgWidgetProgressBarEnd
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetProgressBarEnd : FMsgBase {
	bool IsSucceed; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetCommemorativePlaqueTextNotify
// Size: 0x40 (Inherited: 0x18)
struct FMsgWidgetCommemorativePlaqueTextNotify : FMsgBase {
	struct FPrimaryAssetId ScriptId; // 0x18(0x10)
	struct FVector Location; // 0x28(0x18)
};

// ScriptStruct DungeonCrawler.MsgWidgetContextMenuOpenNotify
// Size: 0x30 (Inherited: 0x18)
struct FMsgWidgetContextMenuOpenNotify : FMsgBase {
	struct UObject* ContextMenuHolder; // 0x18(0x08)
	struct TArray<enum class EContextOptionType> ContextOptions; // 0x20(0x10)
};

// ScriptStruct DungeonCrawler.MsgWidgetContextMenuCloseNotify
// Size: 0x18 (Inherited: 0x18)
struct FMsgWidgetContextMenuCloseNotify : FMsgBase {
	struct UMsgBaseNode* ReplyMsgDelegateBlueprint; // 0x10(0x08)
};

// ScriptStruct DungeonCrawler.MsgWidgetContextOptionSelectedNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetContextOptionSelectedNotify : FMsgBase {
	enum class EContextOptionType ContextOptionType; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct DungeonCrawler.MsgWidgetStreamingModeNotify
// Size: 0x20 (Inherited: 0x18)
struct FMsgWidgetStreamingModeNotify : FMsgBase {
	bool bCurrentStreamingMode; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

