// BlueprintGeneratedClass BP_VoipAkComponent.BP_VoipAkComponent_C
// Size: 0x540 (Inherited: 0x540)
struct UBP_VoipAkComponent_C : UVoipAkComponent {
	struct UAkAudioEvent* SendPlayEvent; // 0x498(0x08)
	struct UAkAudioEvent* SendStopEvent; // 0x4a0(0x08)
	struct UAkAudioEvent* Receive2dPlayEvent; // 0x4a8(0x08)
	struct UAkAudioEvent* Receive3dPlayEvent; // 0x4b0(0x08)
	struct UAkAudioEvent* ReceiveStopEvent; // 0x4b8(0x08)
	struct UAkRtpc* ReceiveSensitivityRtpc; // 0x4c0(0x08)
	float ReceiveSensitivityMargin; // 0x4c8(0x04)
	struct UAkRtpc* SendSensitivityRtpc; // 0x4d0(0x08)
	float SendSensitivityMargin; // 0x4d8(0x04)
	struct UAkRtpc* GlobalInputVolumeRtpc; // 0x4e0(0x08)
	struct UAkRtpc* GlobalOutputVolumeRtpc; // 0x4e8(0x08)
	struct UAkRtpc* ReceiveVolumeRtpc; // 0x4f0(0x08)
};

