// BlueprintGeneratedClass BP_DoorBase.BP_DoorBase_C
// Size: 0x4b8 (Inherited: 0x488)
struct ABP_DoorBase_C : ABP_PropsActorBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x488(0x08)
	struct UAkPortalComponent* AkPortal; // 0x490(0x08)
	struct UStaticMeshComponent* Cube_AkPortal; // 0x498(0x08)
	struct UDCGameObjectLinkComponent* DCGameObjectLink; // 0x4a0(0x08)
	struct UDCSkeletalMeshComponent* Mesh; // 0x4a8(0x08)
	struct FGameplayTag AbilityTriggerTag; // 0x4b0(0x08)

	void IsInteracterForward(struct AActor* Interacter, bool& IsForward); // Function BP_DoorBase.BP_DoorBase_C.IsInteracterForward // (None) // @ game+0xffff8009df830000
};

