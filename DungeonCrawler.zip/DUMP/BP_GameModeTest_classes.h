// BlueprintGeneratedClass BP_GameModeTest.BP_GameModeTest_C
// Size: 0x520 (Inherited: 0x518)
struct ABP_GameModeTest_C : ADCTestGameMode {
	struct USceneComponent* DefaultSceneRoot; // 0x518(0x08)
};

