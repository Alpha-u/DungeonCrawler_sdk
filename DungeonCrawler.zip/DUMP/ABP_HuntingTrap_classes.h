// AnimBlueprintGeneratedClass ABP_HuntingTrap.ABP_HuntingTrap_C
// Size: 0x770 (Inherited: 0x400)
struct UABP_HuntingTrap_C : UDCAnimInstanceBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x400(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess; // 0x408(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base; // 0x410(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x418(0x20)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x438(0x48)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6; // 0x480(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5; // 0x4a8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4; // 0x4d0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // 0x4f8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x520(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x548(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0x570(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0x5b8(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x5d8(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x620(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x640(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x688(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x6a8(0xc8)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_HuntingTrap.ABP_HuntingTrap_C.AnimGraph // (None) // @ game+0xffff800902622002
};

