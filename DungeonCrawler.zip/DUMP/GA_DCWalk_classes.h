// BlueprintGeneratedClass GA_DCWalk.GA_DCWalk_C
// Size: 0x560 (Inherited: 0x558)
struct UGA_DCWalk_C : UDCGameplayAbilityBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x558(0x08)

	void EventReceived_482BF8EA45A716B472BF488779217213(struct FGameplayTag EventTag, struct FGameplayEventData EventData); // Function GA_DCWalk.GA_DCWalk_C.EventReceived_482BF8EA45A716B472BF488779217213 // (None) // @ game+0xe141dfab0001
};

