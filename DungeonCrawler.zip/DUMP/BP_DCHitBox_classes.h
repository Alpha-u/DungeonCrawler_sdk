// BlueprintGeneratedClass BP_DCHitBox.BP_DCHitBox_C
// Size: 0x580 (Inherited: 0x580)
struct UBP_DCHitBox_C : UDCHitBoxComponent {
	enum class EHitBoxType HitBoxType; // 0x578(0x01)
	float DamageMultiplier; // 0x57c(0x04)
};

