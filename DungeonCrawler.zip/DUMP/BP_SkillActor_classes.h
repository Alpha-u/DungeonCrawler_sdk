// BlueprintGeneratedClass BP_SkillActor.BP_SkillActor_C
// Size: 0x400 (Inherited: 0x3f8)
struct ABP_SkillActor_C : ASkillActor {
	struct USceneComponent* DefaultSceneRoot; // 0x3f8(0x08)
};

