// AnimBlueprintGeneratedClass ABP_Lantern.ABP_Lantern_C
// Size: 0x898 (Inherited: 0x530)
struct UABP_Lantern_C : UItemWeaponAnimInstanceBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x530(0x08)
	struct FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables; // 0x538(0x10)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess; // 0x548(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base; // 0x550(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x558(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x578(0x48)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x5c0(0x48)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0x608(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x650(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x670(0xc8)
	struct FAnimNode_RotationOffsetBlendSpace AnimGraphNode_RotationOffsetBlendSpace; // 0x738(0x118)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x850(0x48)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Lantern.ABP_Lantern_C.AnimGraph // (None) // @ game+0xffff8009df830000
};

