// Class BlockoutToolsPlugin.BlockoutToolsParent
// Size: 0x328 (Inherited: 0x290)
struct ABlockoutToolsParent : AActor {
	struct USceneComponent* Root; // 0x290(0x08)
	struct UBillboardComponent* Billboard; // 0x298(0x08)
	struct UMaterialInterface* BlockoutGridParent; // 0x2a0(0x08)
	struct UMaterialInstanceDynamic* BlockoutGridMID; // 0x2a8(0x08)
	struct UMaterialInterface* BlockoutCurrentMaterial; // 0x2b0(0x08)
	struct TArray<struct UStaticMeshComponent*> BlockoutMeshComponents; // 0x2b8(0x10)
	enum class EBlockoutMaterialType BlockoutMaterialType; // 0x2c8(0x01)
	char pad_2C9[0x3]; // 0x2c9(0x03)
	struct FLinearColor BlockoutMaterialColor; // 0x2cc(0x10)
	bool bBlockoutMaterialUseGrid; // 0x2dc(0x01)
	bool bBlockoutWorldAligned; // 0x2dd(0x01)
	char pad_2DE[0x2]; // 0x2de(0x02)
	float BlockoutMaterialGridSize; // 0x2e0(0x04)
	float BlockoutMaterialCheckerLuminance; // 0x2e4(0x04)
	float BlockoutMaterialRoughness; // 0x2e8(0x04)
	bool bBlockoutMaterialUseTopColor; // 0x2ec(0x01)
	char pad_2ED[0x3]; // 0x2ed(0x03)
	struct FLinearColor BlockoutMaterialTopColor; // 0x2f0(0x10)
	bool bUseCustomMaterial; // 0x300(0x01)
	char pad_301[0x7]; // 0x301(0x07)
	struct UMaterialInterface* CustomMaterial; // 0x308(0x08)
	struct UMaterialInterface* BlockoutCustomMaterial; // 0x310(0x08)
	bool bBlockoutEnableCollisions; // 0x318(0x01)
	bool bBlockoutEnableCustomCollision; // 0x319(0x01)
	char pad_31A[0x2]; // 0x31a(0x02)
	struct FName BlockoutCustomCollisionProfileName; // 0x31c(0x08)
	bool bBlockoutCastShadows; // 0x324(0x01)
	char pad_325[0x3]; // 0x325(0x03)

	void RerunConstructionScript(); // Function BlockoutToolsPlugin.BlockoutToolsParent.RerunConstructionScript // (None) // @ game+0xffffaf6edf830041
};

// Class BlockoutToolsPlugin.BlockoutToolsSettings
// Size: 0x60 (Inherited: 0x28)
struct UBlockoutToolsSettings : UObject {
	enum class EBlockoutMaterialType BlockoutMaterialType; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	struct FLinearColor BlockoutMaterialColor; // 0x2c(0x10)
	bool bBlockoutMaterialUseGrid; // 0x3c(0x01)
	bool bBlockoutWorldAligned; // 0x3d(0x01)
	char pad_3E[0x2]; // 0x3e(0x02)
	float BlockoutMaterialGridSize; // 0x40(0x04)
	float BlockoutMaterialCheckerLuminance; // 0x44(0x04)
	float BlockoutMaterialRoughness; // 0x48(0x04)
	bool bBlockoutMaterialUseTopColor; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	struct FLinearColor BlockoutMaterialTopColor; // 0x50(0x10)
};

