// BlueprintGeneratedClass BP_ProtectionPotion.BP_ProtectionPotion_C
// Size: 0x5d8 (Inherited: 0x5d8)
struct ABP_ProtectionPotion_C : ABP_DrinkPotionActor_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x578(0x08)
	struct UMaterialBillboardComponent* FakeCaustics; // 0x580(0x08)
	struct UMaterialBillboardComponent* Glow; // 0x588(0x08)
	struct UMaterialInstanceDynamic* LiquidMaterialInstance; // 0x590(0x08)
	double RemainDrinkingDuration; // 0x598(0x08)
	double CurrentLiquidAmount; // 0x5a0(0x08)
	double ReducingAmount; // 0x5a8(0x08)
	double InitialAmount; // 0x5b0(0x08)
	double Initial Drinking Duration; // 0x5b8(0x08)
	struct UMaterialInstanceDynamic* GlowBillboardMaterialInstance; // 0x5c0(0x08)
	struct UMaterialInterface* CorkMaterial; // 0x5c8(0x08)
	struct FName Height Control Variable Name; // 0x5d0(0x08)
};

