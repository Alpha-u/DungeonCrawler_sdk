// BlueprintGeneratedClass BP_BattleAxe.BP_BattleAxe_C
// Size: 0x578 (Inherited: 0x578)
struct ABP_BattleAxe_C : ABP_DCItemActor_C {
	struct UDCAkComponent* DCAk; // 0x570(0x08)
};

