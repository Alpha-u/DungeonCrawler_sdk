// BlueprintGeneratedClass BP_FloorPortal.BP_FloorPortal_C
// Size: 0x418 (Inherited: 0x3f0)
struct ABP_FloorPortal_C : AFloorPortalBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3f0(0x08)
	struct UArrowComponent* FloorPortalScrollHolder2; // 0x3f8(0x08)
	struct UArrowComponent* FloorPortalScrollHolder1; // 0x400(0x08)
	struct UArrowComponent* FloorPortalScrollHolder; // 0x408(0x08)
	struct USceneComponent* Root; // 0x410(0x08)

	void UserConstructionScript(); // Function BP_FloorPortal.BP_FloorPortal_C.UserConstructionScript // (None) // @ game+0xdd83dfab0001
};

