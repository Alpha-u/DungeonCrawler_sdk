// BlueprintGeneratedClass BP_DungeonDown.BP_DungeonDown_C
// Size: 0x4e1 (Inherited: 0x4e1)
struct ABP_DungeonDown_C : ABP_DungeonExitBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4a8(0x08)
	struct UBoxComponent* Box; // 0x4b0(0x08)
	double DelaySecToOpen; // 0x4b8(0x08)
	struct TArray<double> TimeRange; // 0x4c0(0x10)
	int32_t MaxPlayerCount; // 0x4d0(0x04)
	int32_t CurPlayerCount; // 0x4d4(0x04)
	enum class EFloorRulePhase TriggerFloorRulePhase; // 0x4d8(0x01)
	int32_t TriggerFloorRuleIndex; // 0x4dc(0x04)
	bool bExitOpened; // 0x4e0(0x01)

	void OnDungeonExitOverlapped(struct ADCPlayerCharacterBase* PlayerCharacter, bool& bResult); // Function BP_DungeonDown.BP_DungeonDown_C.OnDungeonExitOverlapped // (None) // @ game+0x13bfddfab0001
};

