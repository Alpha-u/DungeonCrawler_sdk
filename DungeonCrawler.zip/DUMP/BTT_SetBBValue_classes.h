// BlueprintGeneratedClass BTT_SetBBValue.BTT_SetBBValue_C
// Size: 0x120 (Inherited: 0xa8)
struct UBTT_SetBBValue_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	enum class E_Variables Variable Type; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
	struct FBlackboardKeySelector Select Key; // 0xb8(0x28)
	bool TRUE; // 0xe0(0x01)
	enum class E_FloatValueCalculate FloatCalculate; // 0xe1(0x01)
	char pad_E2[0x6]; // 0xe2(0x06)
	double Float Value; // 0xe8(0x08)
	double Random Range Float; // 0xf0(0x08)
	enum class E_FloatValueCalculate IntCalculate; // 0xf8(0x01)
	char pad_F9[0x3]; // 0xf9(0x03)
	int32_t Int Value; // 0xfc(0x04)
	int32_t Random Range Int; // 0x100(0x04)
	char pad_104[0x4]; // 0x104(0x04)
	double BlackBoardFloatValue; // 0x108(0x08)
	int32_t BlackBoardIntValue; // 0x110(0x04)
	int32_t Temp_Int Value; // 0x114(0x04)
	double Temp_Float Value; // 0x118(0x08)

	void IntSet(); // Function BTT_SetBBValue.BTT_SetBBValue_C.IntSet // (None) // @ game+0xbd6ddfab0001
};

