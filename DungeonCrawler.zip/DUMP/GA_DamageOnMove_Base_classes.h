// BlueprintGeneratedClass GA_DamageOnMove_Base.GA_DamageOnMove_Base_C
// Size: 0x570 (Inherited: 0x558)
struct UGA_DamageOnMove_Base_C : UGA_ActivateOnAbilityHandleData_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x558(0x08)
	struct FGameplayTag WaitGameplayTagRemove; // 0x560(0x08)
	struct FGameplayTag ApplyGameplayTagEffect; // 0x568(0x08)

	void EventReceived_BF6EE2BE40B27897C742FF9F58A960DF(struct FGameplayEventData Payload); // Function GA_DamageOnMove_Base.GA_DamageOnMove_Base_C.EventReceived_BF6EE2BE40B27897C742FF9F58A960DF // (None) // @ game+0xffff8009df830000
};

