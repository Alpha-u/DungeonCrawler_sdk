// BlueprintGeneratedClass BP_TrainingDummy.BP_TrainingDummy_C
// Size: 0x4d8 (Inherited: 0x488)
struct ABP_TrainingDummy_C : ABP_PropsActorBase_C {
	struct UBP_DCHitBox_C* BP_DCHitBox_Foot; // 0x488(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox_Hand_Arm_L; // 0x490(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox_Hand_Arm_R; // 0x498(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox_Hand_L; // 0x4a0(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox_Hand_R; // 0x4a8(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox_Head; // 0x4b0(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox_Body; // 0x4b8(0x08)
	struct UDCDamageIndicatorComponent* DCDamageIndicator; // 0x4c0(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox_Leg; // 0x4c8(0x08)
	struct UStaticMeshComponent* SM_Dummy_A; // 0x4d0(0x08)
};

