// BlueprintGeneratedClass GA_ChestMediumOpen.GA_ChestMediumOpen_C
// Size: 0x588 (Inherited: 0x588)
struct UGA_ChestMediumOpen_C : UGA_ChestOpen_C {
	struct TSoftObjectPtr<UAnimMontage> MontageToPlay; // 0x558(0x30)
};

