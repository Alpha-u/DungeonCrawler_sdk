// BlueprintGeneratedClass AN_PauseAnims.AN_PauseAnims_C
// Size: 0x39 (Inherited: 0x38)
struct UAN_PauseAnims_C : UAnimNotify {
	bool Pause; // 0x38(0x01)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, struct FAnimNotifyEventReference& EventReference); // Function AN_PauseAnims.AN_PauseAnims_C.Received_Notify // (None) // @ game+0xffff8009df830000
};

