// BlueprintGeneratedClass GA_ArmingSwordAttack03.GA_ArmingSwordAttack03_C
// Size: 0x688 (Inherited: 0x688)
struct UGA_ArmingSwordAttack03_C : UGA_PlayerCharMeleeAttack_C {
	struct FPrimaryAssetId ComboInputQueueConstantTime; // 0x640(0x10)
	float ComboInputQueueTime; // 0x654(0x04)
	struct FTimerHandle ComboIACompletedHandle; // 0x658(0x08)
	struct FTimerHandle OtherHandIACompletedHandle; // 0x660(0x08)
	struct FTimerHandle AddLooseTagNextTickTimerHandle; // 0x668(0x08)
	struct FGameplayTag ComboTriggerTag; // 0x670(0x08)
	struct FGameplayTag OtherHandTriggerEventTag; // 0x678(0x08)
	struct FGameplayTag OtherHandEnablingEventTag; // 0x680(0x08)
};

