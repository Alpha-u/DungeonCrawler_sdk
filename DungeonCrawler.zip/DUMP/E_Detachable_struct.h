// UserDefinedEnum E_Detachable.E_Detachable
enum class E_Detachable : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	E_MAX = 2
};

