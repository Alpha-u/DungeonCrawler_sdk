// BlueprintGeneratedClass BP_LobbyCaputreViewer.BP_LobbyCaputreViewer_C
// Size: 0x4d0 (Inherited: 0x498)
struct ABP_LobbyCaputreViewer_C : ADCLobbyCaptureViewerActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x498(0x08)
	struct UDCLobbyEmoteComponent* DCLobbyEmote; // 0x4a0(0x08)
	struct UStaticMeshComponent* Chair; // 0x4a8(0x08)
	struct UStaticMeshComponent* Table; // 0x4b0(0x08)
	struct UPointLightComponent* PointLight; // 0x4b8(0x08)
	struct USpringArmComponent* SpringArm; // 0x4c0(0x08)
	struct USceneCaptureComponent2D* SceneCaptureComponent2D; // 0x4c8(0x08)

	void SetActiveSceneCapture(bool bActive); // Function BP_LobbyCaputreViewer.BP_LobbyCaputreViewer_C.SetActiveSceneCapture // (None) // @ game+0xffff82067d7b8080
};

