// BlueprintGeneratedClass BP_DungeonKillLogItemData.BP_DungeonKillLogItemData_C
// Size: 0x191 (Inherited: 0x28)
struct UBP_DungeonKillLogItemData_C : UObject {
	struct FGameKillLogData GameKillLogData; // 0x28(0xe8)
	struct FGameFloorLogData GameFloorLogData; // 0x110(0x80)
	enum class BP_DungeonKillLogItemEnum LogEnum; // 0x190(0x01)
};

