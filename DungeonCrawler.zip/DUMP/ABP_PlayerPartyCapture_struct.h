// ScriptStruct ABP_PlayerPartyCapture.ABP_PlayerPartyCapture_C.AnimBlueprintGeneratedMutableData
// Size: 0x01 (Inherited: 0x01)
struct FAnimBlueprintGeneratedMutableData : FAnimBlueprintMutableData {
};

// ScriptStruct ABP_PlayerPartyCapture.ABP_PlayerPartyCapture_C.AnimBlueprintGeneratedConstantData
// Size: 0x110 (Inherited: 0x01)
struct FAnimBlueprintGeneratedConstantData : FAnimBlueprintConstantData {
	char pad_1[0x3]; // 0x01(0x03)
	struct FName __NameProperty_11; // 0x04(0x08)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FAnimNodeFunctionRef __StructProperty_12; // 0x10(0x20)
	bool __BoolProperty_13; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	float __FloatProperty_14; // 0x34(0x04)
	struct FInputScaleBiasClampConstants __StructProperty_15; // 0x38(0x2c)
	float __FloatProperty_16; // 0x64(0x04)
	bool __BoolProperty_17; // 0x68(0x01)
	enum class EAnimSyncMethod __EnumProperty_18; // 0x69(0x01)
	enum class EAnimGroupRole __ByteProperty_19; // 0x6a(0x01)
	char pad_6B[0x1]; // 0x6b(0x01)
	struct FName __NameProperty_20; // 0x6c(0x08)
	char pad_74[0x4]; // 0x74(0x04)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess; // 0x78(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base; // 0xf8(0x18)
};

