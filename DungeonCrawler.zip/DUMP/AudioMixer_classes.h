// Class AudioMixer.SynthComponent
// Size: 0x790 (Inherited: 0x2a0)
struct USynthComponent : USceneComponent {
	char bAutoDestroy : 1; // 0x2a0(0x01)
	char bStopWhenOwnerDestroyed : 1; // 0x2a0(0x01)
	char bAllowSpatialization : 1; // 0x2a0(0x01)
	char bOverrideAttenuation : 1; // 0x2a0(0x01)
	char pad_2A0_4 : 4; // 0x2a0(0x01)
	char pad_2A1[0x3]; // 0x2a1(0x03)
	char bEnableBusSends : 1; // 0x2a4(0x01)
	char bEnableBaseSubmix : 1; // 0x2a4(0x01)
	char bEnableSubmixSends : 1; // 0x2a4(0x01)
	char pad_2A4_3 : 5; // 0x2a4(0x01)
	char pad_2A5[0x3]; // 0x2a5(0x03)
	struct USoundAttenuation* AttenuationSettings; // 0x2a8(0x08)
	struct FSoundAttenuationSettings AttenuationOverrides; // 0x2b0(0x3c8)
	struct USoundConcurrency* ConcurrencySettings; // 0x678(0x08)
	struct TSet<struct USoundConcurrency*> ConcurrencySet; // 0x680(0x50)
	struct USoundClass* SoundClass; // 0x6d0(0x08)
	struct USoundEffectSourcePresetChain* SourceEffectChain; // 0x6d8(0x08)
	struct USoundSubmixBase* SoundSubmix; // 0x6e0(0x08)
	struct TArray<struct FSoundSubmixSendInfo> SoundSubmixSends; // 0x6e8(0x10)
	struct TArray<struct FSoundSourceBusSendInfo> BusSends; // 0x6f8(0x10)
	struct TArray<struct FSoundSourceBusSendInfo> PreEffectBusSends; // 0x708(0x10)
	char bIsUISound : 1; // 0x718(0x01)
	char bIsPreviewSound : 1; // 0x718(0x01)
	char pad_718_2 : 6; // 0x718(0x01)
	char pad_719[0x3]; // 0x719(0x03)
	int32_t EnvelopeFollowerAttackTime; // 0x71c(0x04)
	int32_t EnvelopeFollowerReleaseTime; // 0x720(0x04)
	char pad_724[0x4]; // 0x724(0x04)
	struct FMulticastInlineDelegate OnAudioEnvelopeValue; // 0x728(0x10)
	char pad_738[0x20]; // 0x738(0x20)
	struct USynthSound* Synth; // 0x758(0x08)
	struct UAudioComponent* AudioComponent; // 0x760(0x08)
	char pad_768[0x28]; // 0x768(0x28)

	void Stop(); // Function AudioMixer.SynthComponent.Stop // (None) // @ game+0xffffb07ddf830041
};

// Class AudioMixer.AudioGenerator
// Size: 0xa8 (Inherited: 0x28)
struct UAudioGenerator : UObject {
	char pad_28[0x80]; // 0x28(0x80)
};

// Class AudioMixer.AudioDeviceNotificationSubsystem
// Size: 0x128 (Inherited: 0x30)
struct UAudioDeviceNotificationSubsystem : UEngineSubsystem {
	char pad_30[0x8]; // 0x30(0x08)
	struct FMulticastInlineDelegate DefaultCaptureDeviceChanged; // 0x38(0x10)
	char pad_48[0x18]; // 0x48(0x18)
	struct FMulticastInlineDelegate DefaultRenderDeviceChanged; // 0x60(0x10)
	char pad_70[0x18]; // 0x70(0x18)
	struct FMulticastInlineDelegate DeviceAdded; // 0x88(0x10)
	char pad_98[0x18]; // 0x98(0x18)
	struct FMulticastInlineDelegate DeviceRemoved; // 0xb0(0x10)
	char pad_C0[0x18]; // 0xc0(0x18)
	struct FMulticastInlineDelegate DeviceStateChanged; // 0xd8(0x10)
	char pad_E8[0x18]; // 0xe8(0x18)
	struct FMulticastInlineDelegate DeviceSwitched; // 0x100(0x10)
	char pad_110[0x18]; // 0x110(0x18)
};

// Class AudioMixer.AudioMixerBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAudioMixerBlueprintLibrary : UBlueprintFunctionLibrary {

	float TrimAudioCache(float InMegabytesToFree); // Function AudioMixer.AudioMixerBlueprintLibrary.TrimAudioCache // (None) // @ game+0xffffc892df830041
};

// Class AudioMixer.SynthSound
// Size: 0x4c0 (Inherited: 0x4a0)
struct USynthSound : USoundWaveProcedural {
	struct TWeakObjectPtr<struct USynthComponent> OwningSynthComponent; // 0x4a0(0x08)
	char pad_4A8[0x18]; // 0x4a8(0x18)
};

// Class AudioMixer.SubmixEffectDynamicsProcessorPreset
// Size: 0x150 (Inherited: 0x68)
struct USubmixEffectDynamicsProcessorPreset : USoundEffectSubmixPreset {
	char pad_68[0x88]; // 0x68(0x88)
	struct FSubmixEffectDynamicsProcessorSettings Settings; // 0xf0(0x60)

	void SetSettings(struct FSubmixEffectDynamicsProcessorSettings& Settings); // Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetSettings // (None) // @ game+0xffffc896df830041
};

// Class AudioMixer.SubmixEffectSubmixEQPreset
// Size: 0xb0 (Inherited: 0x68)
struct USubmixEffectSubmixEQPreset : USoundEffectSubmixPreset {
	char pad_68[0x38]; // 0x68(0x38)
	struct FSubmixEffectSubmixEQSettings Settings; // 0xa0(0x10)

	void SetSettings(struct FSubmixEffectSubmixEQSettings& InSettings); // Function AudioMixer.SubmixEffectSubmixEQPreset.SetSettings // (None) // @ game+0xffffc897df830041
};

// Class AudioMixer.SubmixEffectReverbPreset
// Size: 0x110 (Inherited: 0x68)
struct USubmixEffectReverbPreset : USoundEffectSubmixPreset {
	char pad_68[0x68]; // 0x68(0x68)
	struct FSubmixEffectReverbSettings Settings; // 0xd0(0x40)

	void SetSettingsWithReverbEffect(struct UReverbEffect* InReverbEffect, float WetLevel, float DryLevel); // Function AudioMixer.SubmixEffectReverbPreset.SetSettingsWithReverbEffect // (None) // @ game+0xffffc899df830041
};

// Class AudioMixer.QuartzClockHandle
// Size: 0x1e8 (Inherited: 0x28)
struct UQuartzClockHandle : UObject {
	char pad_28[0x1c0]; // 0x28(0x1c0)

	void UnsubscribeFromTimeDivision(struct UObject* WorldContextObject, enum class EQuartzCommandQuantization InQuantizationBoundary, struct UQuartzClockHandle*& ClockHandle); // Function AudioMixer.QuartzClockHandle.UnsubscribeFromTimeDivision // (None) // @ game+0xffffc8b2df830041
};

// Class AudioMixer.QuartzSubsystem
// Size: 0x60 (Inherited: 0x40)
struct UQuartzSubsystem : UTickableWorldSubsystem {
	char pad_40[0x20]; // 0x40(0x20)

	bool IsQuartzEnabled(); // Function AudioMixer.QuartzSubsystem.IsQuartzEnabled // (None) // @ game+0xffffc8c5df830041
};

