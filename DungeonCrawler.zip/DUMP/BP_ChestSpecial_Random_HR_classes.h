// BlueprintGeneratedClass BP_ChestSpecial_Random_HR.BP_ChestSpecial_Random_HR_C
// Size: 0x4b0 (Inherited: 0x4b0)
struct ABP_ChestSpecial_Random_HR_C : ABP_ChestSpecial_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4a0(0x08)
	struct UDCSkeletalMeshComponent* DCSkeletalMesh; // 0x4a8(0x08)
};

