// BlueprintGeneratedClass BP_AbilityActor_Decal.BP_AbilityActor_Decal_C
// Size: 0x308 (Inherited: 0x2d8)
struct ABP_AbilityActor_Decal_C : AGameplayAbilityWorldReticle_ActorVisualization {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d8(0x08)
	struct UDecalComponent* Decal; // 0x2e0(0x08)
	struct UObject*   ; // 0x2e8(0x08)
	struct FVector CurColor; // 0x2f0(0x18)

	void ReceiveBeginPlay(); // Function BP_AbilityActor_Decal.BP_AbilityActor_Decal_C.ReceiveBeginPlay // (None) // @ game+0xb0c4dfab0001
};

