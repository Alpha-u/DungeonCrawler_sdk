// BlueprintGeneratedClass BP_PlayerCharacterDungeon.BP_PlayerCharacterDungeon_C
// Size: 0xab0 (Inherited: 0xaa0)
struct ABP_PlayerCharacterDungeon_C : ABP_PlayerCharacter_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xaa0(0x08)
	struct UDesignDataAssetItem* SoulHeart; // 0xaa8(0x08)

	void EventFMsgGASActorDieNotify(struct FMsgGASActorDieNotify Msg); // Function BP_PlayerCharacterDungeon.BP_PlayerCharacterDungeon_C.EventFMsgGASActorDieNotify // (None) // @ game+0x13a31dfab0008
};

