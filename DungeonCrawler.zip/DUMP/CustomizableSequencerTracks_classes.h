// Class CustomizableSequencerTracks.SequencerSectionBP
// Size: 0xf8 (Inherited: 0xf0)
struct USequencerSectionBP : UMovieSceneSection {
	struct FMovieSceneSectionEvalOptions EvalOptions; // 0x58(0x02)
	struct FMovieSceneEasingSettings Easing; // 0x60(0x38)
	struct FMovieSceneFrameRange SectionRange; // 0x98(0x10)
	struct FFrameNumber PreRollFrames; // 0xa8(0x04)
	struct FFrameNumber PostRollFrames; // 0xac(0x04)
	int32_t RowIndex; // 0xb0(0x04)
	int32_t OverlapPriority; // 0xb4(0x04)
	char bIsActive : 1; // 0xb8(0x01)
	char bIsLocked : 1; // 0xb8(0x01)
	float StartTime; // 0xbc(0x04)
	float EndTime; // 0xc0(0x04)
	float PrerollTime; // 0xc4(0x04)
	float PostrollTime; // 0xc8(0x04)
	char bIsInfinite : 1; // 0xcc(0x01)
	bool bSupportsInfiniteRange; // 0xd0(0x01)
	struct FOptionalMovieSceneBlendType BlendType; // 0xd1(0x02)
};

// Class CustomizableSequencerTracks.SequencerTrackBP
// Size: 0x1b0 (Inherited: 0x98)
struct USequencerTrackBP : UMovieSceneNameableTrack {
	bool bSupportsMultipleRows; // 0x98(0x01)
	bool bSupportsBlending; // 0x99(0x01)
	char pad_9A[0x2]; // 0x9a(0x02)
	enum class ECustomSequencerTrackType TrackType; // 0x9c(0x04)
	ClassPtrProperty SupportedObjectType; // 0xa0(0x08)
	struct USequencerSectionBP* DefaultSectionType; // 0xa8(0x08)
	struct TArray<struct USequencerSectionBP*> SupportedSections; // 0xb0(0x10)
	struct USequencerTrackInstanceBP* TrackInstanceType; // 0xc0(0x08)
	char pad_C8[0x8]; // 0xc8(0x08)
	struct FSlateBrush Icon; // 0xd0(0xd0)
	struct TArray<struct UMovieSceneSection*> Sections; // 0x1a0(0x10)
};

// Class CustomizableSequencerTracks.SequencerTrackInstanceBP
// Size: 0x50 (Inherited: 0x50)
struct USequencerTrackInstanceBP : UMovieSceneTrackInstance {
	struct UObject* AnimatedObject; // 0x28(0x08)
	bool bIsMasterTrackInstance; // 0x30(0x01)
	struct UMovieSceneEntitySystemLinker* PrivateLinker; // 0x38(0x08)
	struct TArray<struct FMovieSceneTrackInstanceInput> Inputs; // 0x40(0x10)

	void K2_OnUpdate(); // Function CustomizableSequencerTracks.SequencerTrackInstanceBP.K2_OnUpdate // (None) // @ game+0xffffb330df830041
};

