// BlueprintGeneratedClass GA_Drop.GA_Drop_C
// Size: 0x588 (Inherited: 0x588)
struct UGA_Drop_C : UGA_Drop {
	struct UItem* DropItem; // 0x558(0x08)
	int32_t DropSlotId; // 0x560(0x04)
	bool bFailedDropItem; // 0x564(0x01)
	struct FLocomotionAnimSet DropResultAnimSet; // 0x568(0x18)
	bool bWasCurrentActiveSlot; // 0x580(0x01)
	bool bBeingEmptySlot; // 0x581(0x01)
};

