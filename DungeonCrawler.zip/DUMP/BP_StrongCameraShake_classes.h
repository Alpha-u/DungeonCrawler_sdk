// BlueprintGeneratedClass BP_StrongCameraShake.BP_StrongCameraShake_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBP_StrongCameraShake_C : UCameraShakeBase {
	bool bSingleInstance; // 0x28(0x01)
	float ShakeScale; // 0x2c(0x04)
	struct UCameraShakePattern* RootShakePattern; // 0x30(0x08)
	struct APlayerCameraManager* CameraManager; // 0x38(0x08)
};

