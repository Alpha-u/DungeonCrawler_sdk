// Class DungeonCrawler.AccountLink
// Size: 0x2d0 (Inherited: 0x28)
struct UAccountLink : UObject {
	char pad_28[0x2a8]; // 0x28(0x2a8)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.AccountLink.UnbindMsgAll // (None) // @ game+0xffffb9b7df830041
};

// Class DungeonCrawler.AccountLinkAll
// Size: 0xd8 (Inherited: 0x28)
struct UAccountLinkAll : UObject {
	char pad_28[0xb0]; // 0x28(0xb0)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.AccountLinkAll.UnbindMsgAll // (None) // @ game+0xffffb9bbdf830041
};

// Class DungeonCrawler.AccountSession
// Size: 0x178 (Inherited: 0x28)
struct UAccountSession : UObject {
	char pad_28[0x58]; // 0x28(0x58)
	struct UBaseObject* BaseObject; // 0x80(0x08)
	char pad_88[0xf0]; // 0x88(0xf0)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.AccountSession.UnbindMsgAll // (None) // @ game+0xffffb9bfdf830041
};

// Class DungeonCrawler.DCDataAssetBase
// Size: 0x38 (Inherited: 0x30)
struct UDCDataAssetBase : UPrimaryDataAsset {
	struct FPrimaryAssetType AssetType; // 0x30(0x08)
};

// Class DungeonCrawler.ActorStatusUIData
// Size: 0x40 (Inherited: 0x38)
struct UActorStatusUIData : UDCDataAssetBase {
	struct UTexture2D* IconTexture; // 0x38(0x08)
};

// Class DungeonCrawler.ArtDataPlayerCharacter
// Size: 0x70 (Inherited: 0x38)
struct UArtDataPlayerCharacter : UDCDataAssetBase {
	struct UTexture2D* PlayerCharacterIconTexture; // 0x38(0x08)
	struct UTexture2D* PlayerCharacterImageTexture; // 0x40(0x08)
	struct UTexture2D* PlayerCharacterManIllustImageTexture; // 0x48(0x08)
	struct UTexture2D* PlayerCharacterWomanIllustImageTexture; // 0x50(0x08)
	struct UTexture2D* Icon; // 0x58(0x08)
	struct UTexture2D* Portrait; // 0x60(0x08)
	struct UTexture2D* Illustration; // 0x68(0x08)
};

// Class DungeonCrawler.ArtDataMonster
// Size: 0x40 (Inherited: 0x38)
struct UArtDataMonster : UDCDataAssetBase {
	struct UBehaviorTree* BehaviorTree; // 0x38(0x08)
};

// Class DungeonCrawler.ArtDataAoe
// Size: 0x40 (Inherited: 0x38)
struct UArtDataAoe : UDCDataAssetBase {
	struct UBehaviorTree* BehaviorTree; // 0x38(0x08)
};

// Class DungeonCrawler.ArtDataProps
// Size: 0x38 (Inherited: 0x38)
struct UArtDataProps : UDCDataAssetBase {
	struct FPrimaryAssetType AssetType; // 0x30(0x08)
};

// Class DungeonCrawler.ArtDataItem
// Size: 0x80 (Inherited: 0x38)
struct UArtDataItem : UDCDataAssetBase {
	enum class EItemType ItemType; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct UTexture2D* ItemIconTexture; // 0x40(0x08)
	struct USkeletalMesh* ItemSkeletalMesh; // 0x48(0x08)
	struct TArray<struct FItemMaterialInfo> ItemSkeletalMeshMaterialInfoArray; // 0x50(0x10)
	struct UStaticMesh* ItemStaticMesh; // 0x60(0x08)
	struct TArray<struct FItemMaterialInfo> ItemStaticMeshMaterialInfoArray; // 0x68(0x10)
	struct UAnimInstance* ItemAnimInstanceClass; // 0x78(0x08)
};

// Class DungeonCrawler.ArtDataAnimatedItem
// Size: 0x118 (Inherited: 0x80)
struct UArtDataAnimatedItem : UArtDataItem {
	struct FAnimationSet AnimationSet; // 0x80(0x38)
	struct TMap<struct FGameplayTag, struct FAnimationSet> ConditionalAnimationSet; // 0xb8(0x50)
	struct FName EquipmentSocket; // 0x108(0x08)
	struct FName SheathSocket; // 0x110(0x08)
};

// Class DungeonCrawler.ArtDataWeapon
// Size: 0x118 (Inherited: 0x118)
struct UArtDataWeapon : UArtDataAnimatedItem {
	struct FAnimationSet AnimationSet; // 0x80(0x38)
	struct TMap<struct FGameplayTag, struct FAnimationSet> ConditionalAnimationSet; // 0xb8(0x50)
	struct FName EquipmentSocket; // 0x108(0x08)
	struct FName SheathSocket; // 0x110(0x08)
};

// Class DungeonCrawler.ArtDataArmor
// Size: 0x90 (Inherited: 0x80)
struct UArtDataArmor : UArtDataItem {
	struct TArray<enum class EDCMorphTarget> MorphTargets; // 0x80(0x10)
};

// Class DungeonCrawler.ArtDataUtility
// Size: 0x118 (Inherited: 0x118)
struct UArtDataUtility : UArtDataAnimatedItem {
	struct FAnimationSet AnimationSet; // 0x80(0x38)
	struct TMap<struct FGameplayTag, struct FAnimationSet> ConditionalAnimationSet; // 0xb8(0x50)
	struct FName EquipmentSocket; // 0x108(0x08)
	struct FName SheathSocket; // 0x110(0x08)
};

// Class DungeonCrawler.ArtDataAccessory
// Size: 0x80 (Inherited: 0x80)
struct UArtDataAccessory : UArtDataItem {
	enum class EItemType ItemType; // 0x38(0x01)
	struct UTexture2D* ItemIconTexture; // 0x40(0x08)
	struct USkeletalMesh* ItemSkeletalMesh; // 0x48(0x08)
	struct TArray<struct FItemMaterialInfo> ItemSkeletalMeshMaterialInfoArray; // 0x50(0x10)
	struct UStaticMesh* ItemStaticMesh; // 0x60(0x08)
	struct TArray<struct FItemMaterialInfo> ItemStaticMeshMaterialInfoArray; // 0x68(0x10)
	struct UAnimInstance* ItemAnimInstanceClass; // 0x78(0x08)
};

// Class DungeonCrawler.ArtDataMisc
// Size: 0x80 (Inherited: 0x80)
struct UArtDataMisc : UArtDataItem {
	enum class EItemType ItemType; // 0x38(0x01)
	struct UTexture2D* ItemIconTexture; // 0x40(0x08)
	struct USkeletalMesh* ItemSkeletalMesh; // 0x48(0x08)
	struct TArray<struct FItemMaterialInfo> ItemSkeletalMeshMaterialInfoArray; // 0x50(0x10)
	struct UStaticMesh* ItemStaticMesh; // 0x60(0x08)
	struct TArray<struct FItemMaterialInfo> ItemStaticMeshMaterialInfoArray; // 0x68(0x10)
	struct UAnimInstance* ItemAnimInstanceClass; // 0x78(0x08)
};

// Class DungeonCrawler.ArtDataProjectile
// Size: 0x40 (Inherited: 0x38)
struct UArtDataProjectile : UDCDataAssetBase {
	float DestroyTime; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class DungeonCrawler.ArtDataSkill
// Size: 0x60 (Inherited: 0x38)
struct UArtDataSkill : UDCDataAssetBase {
	struct UTexture2D* SkillIconTexture; // 0x38(0x08)
	struct UNiagaraSystem* CastStart; // 0x40(0x08)
	struct UNiagaraSystem* CastReady; // 0x48(0x08)
	struct UNiagaraSystem* CastFire; // 0x50(0x08)
	struct UNiagaraSystem* ChannelingStart; // 0x58(0x08)
};

// Class DungeonCrawler.ArtDataSpell
// Size: 0x68 (Inherited: 0x38)
struct UArtDataSpell : UDCDataAssetBase {
	struct UTexture2D* SpellIconTexture; // 0x38(0x08)
	struct UNiagaraSystem* CastStart; // 0x40(0x08)
	struct UNiagaraSystem* CastReady; // 0x48(0x08)
	struct UNiagaraSystem* CastFire; // 0x50(0x08)
	struct UNiagaraSystem* ChannelingStart; // 0x58(0x08)
	struct UNiagaraSystem* ChannelingStartOnCharacter; // 0x60(0x08)
};

// Class DungeonCrawler.ArtDataMusic
// Size: 0x80 (Inherited: 0x38)
struct UArtDataMusic : UDCDataAssetBase {
	struct UTexture2D* MusicIconTexture; // 0x38(0x08)
	struct UNiagaraSystem* PlayStart; // 0x40(0x08)
	struct UNiagaraSystem* PlayStartOnCharacter; // 0x48(0x08)
	struct UNiagaraSystem* PlayReady; // 0x50(0x08)
	struct UNiagaraSystem* PlayReadyOnCharacter; // 0x58(0x08)
	struct UNiagaraSystem* PlayFire; // 0x60(0x08)
	struct UNiagaraSystem* PlayFireOnCharacter; // 0x68(0x08)
	struct UNiagaraSystem* ChannelingStart; // 0x70(0x08)
	struct UNiagaraSystem* ChannelingStartOnCharacter; // 0x78(0x08)
};

// Class DungeonCrawler.ArtDataPerk
// Size: 0x40 (Inherited: 0x38)
struct UArtDataPerk : UDCDataAssetBase {
	struct UTexture2D* PerkIconTexture; // 0x38(0x08)
};

// Class DungeonCrawler.ArtDataMerchant
// Size: 0x40 (Inherited: 0x38)
struct UArtDataMerchant : UDCDataAssetBase {
	struct UTexture2D* MerchantIconTexture; // 0x38(0x08)
};

// Class DungeonCrawler.ArtDataEmote
// Size: 0x40 (Inherited: 0x38)
struct UArtDataEmote : UDCDataAssetBase {
	struct UTexture2D* EmoteIconTexture; // 0x38(0x08)
};

// Class DungeonCrawler.AsyncTaskAttributeChanged
// Size: 0x90 (Inherited: 0x30)
struct UAsyncTaskAttributeChanged : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate OnAttributeChanged; // 0x30(0x10)
	struct UAbilitySystemComponent* ASC; // 0x40(0x08)
	char pad_48[0x48]; // 0x48(0x48)

	struct UAsyncTaskAttributeChanged* ListenForAttributesChange(struct UAbilitySystemComponent* AbilitySystemComponent, struct TArray<struct FGameplayAttribute> Attributes); // Function DungeonCrawler.AsyncTaskAttributeChanged.ListenForAttributesChange // (None) // @ game+0xffffb9c2df830041
};

// Class DungeonCrawler.AsyncTaskCooldownChanged
// Size: 0x80 (Inherited: 0x30)
struct UAsyncTaskCooldownChanged : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate OnCooldownBegin; // 0x30(0x10)
	struct FMulticastInlineDelegate OnCooldownEnd; // 0x40(0x10)
	struct UAbilitySystemComponent* ASC; // 0x50(0x08)
	char pad_58[0x28]; // 0x58(0x28)

	struct UAsyncTaskCooldownChanged* ListenForCooldownChange(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTagContainer CooldownTags, bool UseServerCooldown); // Function DungeonCrawler.AsyncTaskCooldownChanged.ListenForCooldownChange // (None) // @ game+0xffffb9c4df830041
};

// Class DungeonCrawler.AsyncTaskEffectInhibitionChanged
// Size: 0x50 (Inherited: 0x30)
struct UAsyncTaskEffectInhibitionChanged : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate OnGameplayEffectInhibitionChange; // 0x30(0x10)
	struct UAbilitySystemComponent* ASC; // 0x40(0x08)
	char pad_48[0x8]; // 0x48(0x08)

	struct UAsyncTaskEffectInhibitionChanged* ListenForGameplayInhibitionChange(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTag EffectGameplayTag); // Function DungeonCrawler.AsyncTaskEffectInhibitionChanged.ListenForGameplayInhibitionChange // (None) // @ game+0xffffb9c6df830041
};

// Class DungeonCrawler.AsyncTaskEffectStackChanged
// Size: 0x50 (Inherited: 0x30)
struct UAsyncTaskEffectStackChanged : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate OnGameplayEffectStackChange; // 0x30(0x10)
	struct UAbilitySystemComponent* ASC; // 0x40(0x08)
	char pad_48[0x8]; // 0x48(0x08)

	struct UAsyncTaskEffectStackChanged* ListenForGameplayEffectStackChange(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTag EffectGameplayTag); // Function DungeonCrawler.AsyncTaskEffectStackChanged.ListenForGameplayEffectStackChange // (None) // @ game+0xffffb9c8df830041
};

// Class DungeonCrawler.AsyncTaskWaitGAActivated
// Size: 0xf8 (Inherited: 0x38)
struct UAsyncTaskWaitGAActivated : UAbilityAsync {
	char pad_38[0xa0]; // 0x38(0xa0)
	struct FMulticastInlineDelegate OnActivate; // 0xd8(0x10)
	char pad_E8[0x10]; // 0xe8(0x10)

	struct UAsyncTaskWaitGAActivated* WaitForAbilityActivateWithTagRequirements(struct AActor* TargetActor, struct FGameplayTagRequirements TagRequirements, bool IncludeTriggeredAbilities, bool TriggerOnce); // Function DungeonCrawler.AsyncTaskWaitGAActivated.WaitForAbilityActivateWithTagRequirements // (None) // @ game+0xffffb9ccdf830041
};

// Class DungeonCrawler.AsyncTaskWaitGAEnded
// Size: 0xf8 (Inherited: 0x38)
struct UAsyncTaskWaitGAEnded : UAbilityAsync {
	char pad_38[0xa0]; // 0x38(0xa0)
	struct FMulticastInlineDelegate OnAbilityEndedDelegate; // 0xd8(0x10)
	char pad_E8[0x10]; // 0xe8(0x10)

	struct UAsyncTaskWaitGAEnded* WaitForAbilityEndWithTagRequirements(struct AActor* TargetActor, struct FGameplayTagRequirements TagRequirements, bool TriggerOnce); // Function DungeonCrawler.AsyncTaskWaitGAEnded.WaitForAbilityEndWithTagRequirements // (None) // @ game+0xffffb9d0df830041
};

// Class DungeonCrawler.AsyncTaskWaitGameplayEvent
// Size: 0x60 (Inherited: 0x38)
struct UAsyncTaskWaitGameplayEvent : UAbilityAsync {
	struct FMulticastInlineDelegate EventReceived; // 0x38(0x10)
	char pad_48[0x18]; // 0x48(0x18)

	struct UAsyncTaskWaitGameplayEvent* WaitGameplayEventToActor(struct AActor* TargetActor, struct FGameplayTag EventTag, bool OnlyTriggerOnce, bool OnlyMatchExact); // Function DungeonCrawler.AsyncTaskWaitGameplayEvent.WaitGameplayEventToActor // (None) // @ game+0xffff982ddf830041
};

// Class DungeonCrawler.AttackInputManagerComponent
// Size: 0x108 (Inherited: 0xa0)
struct UAttackInputManagerComponent : UActorComponent {
	struct UAsyncTaskWaitGameplayEvent* AsyncGameplayEventWaitTask; // 0xa0(0x08)
	struct UAsyncTaskWaitGAActivated* AsyncGAActivateTask; // 0xa8(0x08)
	struct UAsyncTaskWaitGAEnded* AsyncGAEndTask; // 0xb0(0x08)
	struct TMap<struct FGameplayTag, struct FGameplayTag> CurrentTriggerMap; // 0xb8(0x50)

	void SetAttackEnabled(bool bIsAttackEnabled); // Function DungeonCrawler.AttackInputManagerComponent.SetAttackEnabled // (None) // @ game+0xffffb9d6df830041
};

// Class DungeonCrawler.BTDecorator_DCGameBlackboard
// Size: 0x120 (Inherited: 0xc0)
struct UBTDecorator_DCGameBlackboard : UBTDecorator_Blackboard {
	int32_t IntValue; // 0x90(0x04)
	float FloatValue; // 0x94(0x04)
	struct FString StringValue; // 0x98(0x10)
	struct FString CachedDescription; // 0xa8(0x10)
	char OperationType; // 0xb8(0x01)
	enum class EBTBlackboardRestart NotifyObserver; // 0xb9(0x01)
	char pad_EA[0x36]; // 0xea(0x36)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.BTDecorator_DCGameBlackboard.UnbindMsgAll // (None) // @ game+0xffffb9dadf830041
};

// Class DungeonCrawler.BTDecorator_DCGameCheckGameState
// Size: 0x128 (Inherited: 0x120)
struct UBTDecorator_DCGameCheckGameState : UBTDecorator_DCGameBlackboard {
	enum class EGameStateType PrevGameStateType; // 0x120(0x01)
	char pad_121[0x7]; // 0x121(0x07)
};

// Class DungeonCrawler.BTD_CheckGameplayTagsOnActorAbortObservers
// Size: 0xd8 (Inherited: 0xc8)
struct UBTD_CheckGameplayTagsOnActorAbortObservers : UBTDecorator_CheckGameplayTagsOnActor {
	struct FBlackboardKeySelector ActorToCheck; // 0x68(0x28)
	enum class EGameplayContainerMatchType TagsToMatch; // 0x90(0x01)
	struct FGameplayTagContainer GameplayTags; // 0x98(0x20)
	struct FString CachedDescription; // 0xb8(0x10)
};

// Class DungeonCrawler.BTD_RandomCooldown
// Size: 0x78 (Inherited: 0x68)
struct UBTD_RandomCooldown : UBTDecorator {
	float MinCoolDownTime; // 0x68(0x04)
	float MaxCoolDownTime; // 0x6c(0x04)
	float InitCoolDownTime; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// Class DungeonCrawler.BTService_DCGameBase
// Size: 0xd0 (Inherited: 0x70)
struct UBTService_DCGameBase : UBTService {
	float Interval; // 0x60(0x04)
	float RandomDeviation; // 0x64(0x04)
	char bCallTickOnSearchStart : 1; // 0x68(0x01)
	char bRestartTimerOnEachActivation : 1; // 0x68(0x01)
	char pad_78_2 : 6; // 0x78(0x01)
	char pad_79[0x57]; // 0x79(0x57)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.BTService_DCGameBase.UnbindMsgAll // (None) // @ game+0xffffb9dedf830041
};

// Class DungeonCrawler.BTTask_DCGameBase
// Size: 0xe0 (Inherited: 0x70)
struct UBTTask_DCGameBase : UBTTaskNode {
	char pad_70[0x58]; // 0x70(0x58)
	enum class EBTNodeResult Result; // 0xc8(0x01)
	char pad_C9[0x3]; // 0xc9(0x03)
	struct FIntervalCountdown TickInterval; // 0xcc(0x08)
	char pad_D4[0xc]; // 0xd4(0x0c)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.BTTask_DCGameBase.UnbindMsgAll // (None) // @ game+0xffffb9e2df830041
};

// Class DungeonCrawler.BTTask_DCGameAnnounce
// Size: 0x178 (Inherited: 0xe0)
struct UBTTask_DCGameAnnounce : UBTTask_DCGameBase {
	struct FGameAnnounceInfo GameAnnounceInfo; // 0xe0(0x98)
};

// Class DungeonCrawler.BTTask_DCGameAnnounceArray
// Size: 0xf8 (Inherited: 0xe0)
struct UBTTask_DCGameAnnounceArray : UBTTask_DCGameBase {
	struct TArray<struct FGameAnnounceInfo> GameAnnounceInfoArray; // 0xe0(0x10)
	char pad_F0[0x8]; // 0xf0(0x08)
};

// Class DungeonCrawler.BTTask_DCGameCheckGameStart
// Size: 0xe0 (Inherited: 0xe0)
struct UBTTask_DCGameCheckGameStart : UBTTask_DCGameBase {
	enum class EBTNodeResult Result; // 0xc8(0x01)
	struct FIntervalCountdown TickInterval; // 0xcc(0x08)
};

// Class DungeonCrawler.BTTask_DCGameExecuteGameResult
// Size: 0xe0 (Inherited: 0xe0)
struct UBTTask_DCGameExecuteGameResult : UBTTask_DCGameBase {
	enum class EBTNodeResult Result; // 0xc8(0x01)
	struct FIntervalCountdown TickInterval; // 0xcc(0x08)
};

// Class DungeonCrawler.BTTask_DCGameExitAllPlayer
// Size: 0xe0 (Inherited: 0xe0)
struct UBTTask_DCGameExitAllPlayer : UBTTask_DCGameBase {
	enum class EBTNodeResult Result; // 0xc8(0x01)
	struct FIntervalCountdown TickInterval; // 0xcc(0x08)
};

// Class DungeonCrawler.BTTask_DCGameFloorRule
// Size: 0x140 (Inherited: 0xe0)
struct UBTTask_DCGameFloorRule : UBTTask_DCGameBase {
	struct UDCFloorRuleDataAsset* RuleData; // 0xe0(0x08)
	float WarmupDuration; // 0xe8(0x04)
	char pad_EC[0x4]; // 0xec(0x04)
	struct ADeathSwarmBase* DeathSwarm; // 0xf0(0x08)
	struct FDCFloorRuleManager FloorRuleManager; // 0xf8(0x38)
	char pad_130[0x10]; // 0x130(0x10)
};

// Class DungeonCrawler.BTTask_DCGameKillAllPlayer
// Size: 0xe0 (Inherited: 0xe0)
struct UBTTask_DCGameKillAllPlayer : UBTTask_DCGameBase {
	enum class EBTNodeResult Result; // 0xc8(0x01)
	struct FIntervalCountdown TickInterval; // 0xcc(0x08)
};

// Class DungeonCrawler.BTTask_DCGameServerTravel
// Size: 0xf0 (Inherited: 0xe0)
struct UBTTask_DCGameServerTravel : UBTTask_DCGameBase {
	struct FString ServerTravelURL; // 0xe0(0x10)
};

// Class DungeonCrawler.BTTask_DCGameState
// Size: 0xe8 (Inherited: 0xe0)
struct UBTTask_DCGameState : UBTTask_DCGameBase {
	enum class EGameStateType GameState; // 0xe0(0x01)
	char pad_E1[0x7]; // 0xe1(0x07)
};

// Class DungeonCrawler.BTT_BlueprintBase
// Size: 0xa8 (Inherited: 0xa8)
struct UBTT_BlueprintBase : UBTTask_BlueprintBase {
	struct AAIController* AIOwner; // 0x70(0x08)
	struct AActor* ActorOwner; // 0x78(0x08)
	struct FIntervalCountdown TickInterval; // 0x80(0x08)
	char bShowPropertyDetails : 1; // 0xa0(0x01)

	void OnTaskFinished(struct AAIController* OwnerController, struct APawn* ControlledPawn, enum class EBTNodeResult TaskResult); // Function DungeonCrawler.BTT_BlueprintBase.OnTaskFinished // (None) // @ game+0xffffb9efdf830041
};

// Class DungeonCrawler.BTT_CustomRunBehavior
// Size: 0x78 (Inherited: 0x78)
struct UBTT_CustomRunBehavior : UBTTask_RunBehavior {
	struct UBehaviorTree* BehaviorAsset; // 0x70(0x08)
};

// Class DungeonCrawler.CharacterCreateAttributeWidgetData
// Size: 0x38 (Inherited: 0x28)
struct UCharacterCreateAttributeWidgetData : UObject {
	struct FGameplayEffectDescData AttrributeEffectDescData; // 0x28(0x0c)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class DungeonCrawler.DCWidgetBase
// Size: 0x300 (Inherited: 0x2a0)
struct UDCWidgetBase : UCommonUserWidget {
	char pad_2A0[0x58]; // 0x2a0(0x58)
	struct UBaseObject* BaseObject; // 0x2f8(0x08)

	void UnbindMsgOwner(struct UScriptStruct* InMsgType); // Function DungeonCrawler.DCWidgetBase.UnbindMsgOwner // (None) // @ game+0xffffb9f8df830041
};

// Class DungeonCrawler.CharacterCreateAttributeWidget
// Size: 0x308 (Inherited: 0x300)
struct UCharacterCreateAttributeWidget : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)
};

// Class DungeonCrawler.CharacterCreateClassItemWidgetData
// Size: 0x30 (Inherited: 0x28)
struct UCharacterCreateClassItemWidgetData : UObject {
	enum class EDCCharacterClass CharacterClass; // 0x28(0x01)
	enum class EDCGender Gender; // 0x29(0x01)
	bool bSelected; // 0x2a(0x01)
	char pad_2B[0x5]; // 0x2b(0x05)
};

// Class DungeonCrawler.CharacterCreateClassItemWidget
// Size: 0x338 (Inherited: 0x300)
struct UCharacterCreateClassItemWidget : UDCWidgetBase {
	char pad_300[0x8]; // 0x300(0x08)
	struct FText Title; // 0x308(0x18)
	struct UTexture2D* Icon; // 0x320(0x08)
	struct UTexture2D* Portrait; // 0x328(0x08)
	bool bSelected; // 0x330(0x01)
	bool bCanCreate; // 0x331(0x01)
	char pad_332[0x6]; // 0x332(0x06)
};

// Class DungeonCrawler.CharacterCreatePerkItemWidget
// Size: 0x300 (Inherited: 0x300)
struct UCharacterCreatePerkItemWidget : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)
};

// Class DungeonCrawler.DCCommonActivatableWidgetBase
// Size: 0x440 (Inherited: 0x3c8)
struct UDCCommonActivatableWidgetBase : UCommonActivatableWidget {
	char pad_3C8[0x58]; // 0x3c8(0x58)
	struct UBaseObject* BaseObject; // 0x420(0x08)
	struct FDataTableRowHandle VirtualCursorModeInputActionData; // 0x428(0x10)
	char pad_438[0x8]; // 0x438(0x08)

	void UnbindMsgOwner(struct UScriptStruct* InMsgType); // Function DungeonCrawler.DCCommonActivatableWidgetBase.UnbindMsgOwner // (None) // @ game+0xffffba03df830041
};

// Class DungeonCrawler.CharacterCreateWidget
// Size: 0x4b0 (Inherited: 0x440)
struct UCharacterCreateWidget : UDCCommonActivatableWidgetBase {
	enum class EDCCharacterClass SelectedCharacterClass; // 0x440(0x01)
	enum class EDCGender SelectedGender; // 0x441(0x01)
	char pad_442[0x6]; // 0x442(0x06)
	struct FText SelectedCharacterClassName; // 0x448(0x18)
	struct FText SelectedCharacterClassDialog; // 0x460(0x18)
	struct FText SelectedCharacterClassInfo; // 0x478(0x18)
	struct UTexture2D* SelectedCharacterIllustration; // 0x490(0x08)
	struct UTileView* ClassSelectTileView; // 0x498(0x08)
	struct UTileView* ClassAttributeTileView; // 0x4a0(0x08)
	struct UEditableTextBox* NickNameTextBox; // 0x4a8(0x08)

	void OnTextChangedNickName(struct FText& InNickName); // Function DungeonCrawler.CharacterCreateWidget.OnTextChangedNickName // (None) // @ game+0xffffba08df830041
};

// Class DungeonCrawler.DCDataComponent
// Size: 0xd0 (Inherited: 0xa0)
struct UDCDataComponent : UActorComponent {
	char pad_A0[0x18]; // 0xa0(0x18)
	struct FPrimaryAssetId AssetId; // 0xb8(0x10)
	struct UDCDataAssetBase* DataAsset; // 0xc8(0x08)

	void OnRep_AssetId(struct FPrimaryAssetId PrevAssetId); // Function DungeonCrawler.DCDataComponent.OnRep_AssetId // (None) // @ game+0xffffba09df830041
};

// Class DungeonCrawler.DCCharacterDataComponent
// Size: 0xf0 (Inherited: 0xd0)
struct UDCCharacterDataComponent : UDCDataComponent {
	struct FPrimaryAssetId AssetId; // 0xb8(0x10)
	struct UDCDataAssetBase* DataAsset; // 0xc8(0x08)
	char pad_E8[0x8]; // 0xe8(0x08)
};

// Class DungeonCrawler.DCCharacterPartsComponent
// Size: 0x250 (Inherited: 0xa0)
struct UDCCharacterPartsComponent : UActorComponent {
	struct UDCCharacterPartsArtData* Data; // 0xa0(0x08)
	struct TMap<struct FGameplayTag, struct USkeletalMeshComponent*> BodyParts; // 0xa8(0x50)
	struct TMap<struct FGameplayTag, struct USkeletalMeshComponent*> ArmorParts; // 0xf8(0x50)
	struct TMap<struct FGameplayTag, struct FDesignDataItem> ArmorItems; // 0x148(0x50)
	struct TMap<struct FDCItemId, struct FDCItemInfo> ArmorItemInfos; // 0x198(0x50)
	char pad_1E8[0x68]; // 0x1e8(0x68)
};

// Class DungeonCrawler.CharacterSelectCharacterListWidgetData
// Size: 0x38 (Inherited: 0x28)
struct UCharacterSelectCharacterListWidgetData : UObject {
	struct FCharacterSlotData CharacterSlotData; // 0x28(0x10)
};

// Class DungeonCrawler.CharacterSelectCharListWidget
// Size: 0x330 (Inherited: 0x300)
struct UCharacterSelectCharListWidget : UDCWidgetBase {
	char pad_300[0x8]; // 0x300(0x08)
	struct UListView* CharacterSlotListView; // 0x308(0x08)
	int32_t CurrentPageIndex; // 0x310(0x04)
	int32_t MaxCharacterCount; // 0x314(0x04)
	int32_t MaxPageIndex; // 0x318(0x04)
	char pad_31C[0x14]; // 0x31c(0x14)

	void OnSelectedCharacterId(struct FString CharacterId); // Function DungeonCrawler.CharacterSelectCharListWidget.OnSelectedCharacterId // (None) // @ game+0xffffba12df830041
};

// Class DungeonCrawler.CharacterSelectCharacterSlotWidgetData
// Size: 0xc0 (Inherited: 0x28)
struct UCharacterSelectCharacterSlotWidgetData : UObject {
	struct FCharacterSlot CharacterSlot; // 0x28(0x98)
};

// Class DungeonCrawler.CharacterSelectCharSlotWidget
// Size: 0x3a0 (Inherited: 0x300)
struct UCharacterSelectCharSlotWidget : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)
	char pad_308[0x98]; // 0x308(0x98)

	void OnFMsgWidgetStreamingModeNotifyBlueprint(struct FMsgWidgetStreamingModeNotify& InMsg); // Function DungeonCrawler.CharacterSelectCharSlotWidget.OnFMsgWidgetStreamingModeNotifyBlueprint // (None) // @ game+0xffffba14df830041
};

// Class DungeonCrawler.CharacterSelectGroupWidgetBase
// Size: 0x320 (Inherited: 0x300)
struct UCharacterSelectGroupWidgetBase : UDCWidgetBase {
	enum class EWidgetCharacterSelectGroupType WidgetCharacterSelectGroupType; // 0x300(0x01)
	char pad_301[0x7]; // 0x301(0x07)
	struct TArray<enum class EWidgetCharacterSelectGroupType> NonCoexistWidgetCharacterSelectGroupTypeArray; // 0x308(0x10)
	char pad_318[0x8]; // 0x318(0x08)
};

// Class DungeonCrawler.CharacterSelectWidget
// Size: 0x448 (Inherited: 0x440)
struct UCharacterSelectWidget : UDCCommonActivatableWidgetBase {
	struct UCharacterSelectCharListWidget* CharacterSelectCharListWidget; // 0x440(0x08)

	void HandleOptionButtonClicked(); // Function DungeonCrawler.CharacterSelectWidget.HandleOptionButtonClicked // (None) // @ game+0xffffba18df830041
};

// Class DungeonCrawler.CharacterStatusDetailWidget
// Size: 0x940 (Inherited: 0x300)
struct UCharacterStatusDetailWidget : UDCWidgetBase {
	struct FCharacterStatusDetailWidgetData WidgetData; // 0x300(0x4a8)
	struct UAccountLink* AccountLink; // 0x7a8(0x08)
	char pad_7B0[0x150]; // 0x7b0(0x150)
	struct FString LinkedAccountId; // 0x900(0x10)
	struct FString CheckTargetAccountId; // 0x910(0x10)
	struct UCurveTable* CurveTablePhysicalPower; // 0x920(0x08)
	struct UCurveTable* CurveTableArmorRating; // 0x928(0x08)
	struct UCurveTable* CurveTableMagicalPower; // 0x930(0x08)
	struct UCurveTable* CurveTableMagicResistance; // 0x938(0x08)

	void OnWill(struct FGameplayAttributeData& NewValue, struct FGameplayAttributeData& OldValue); // Function DungeonCrawler.CharacterStatusDetailWidget.OnWill // (None) // @ game+0xffffba64df830041
};

// Class DungeonCrawler.CharacterStatusWidget
// Size: 0x4b0 (Inherited: 0x300)
struct UCharacterStatusWidget : UDCWidgetBase {
	struct FCharacterStatusWidgetData WidgetData; // 0x300(0x180)
	struct UAccountLink* AccountLink; // 0x480(0x08)
	char pad_488[0x8]; // 0x488(0x08)
	struct FString LinkedAccountId; // 0x490(0x10)
	struct FString CheckTargetAccountId; // 0x4a0(0x10)

	void OnWill(struct FGameplayAttributeData& NewValue, struct FGameplayAttributeData& OldValue); // Function DungeonCrawler.CharacterStatusWidget.OnWill // (None) // @ game+0xffffba7cdf830041
};

// Class DungeonCrawler.ChatEditWidgetBase
// Size: 0x378 (Inherited: 0x300)
struct UChatEditWidgetBase : UDCWidgetBase {
	struct URichTextBlock* RichTextBlock; // 0x300(0x08)
	struct UDCEditableText* EditableText; // 0x308(0x08)
	char pad_310[0x68]; // 0x310(0x68)

	void OnTextCommitted(struct FText& InText, enum class ETextCommit InCommitMethod); // Function DungeonCrawler.ChatEditWidgetBase.OnTextCommitted // (None) // @ game+0xffffba7edf830041
};

// Class DungeonCrawler.ChatFilterListEntryWidgetObject
// Size: 0x40 (Inherited: 0x28)
struct UChatFilterListEntryWidgetObject : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FGameplayTag ChatFilterTag; // 0x30(0x08)
	bool bChecked; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// Class DungeonCrawler.ChatFilterListEntryWidget
// Size: 0x330 (Inherited: 0x300)
struct UChatFilterListEntryWidget : UDCWidgetBase {
	char pad_300[0x8]; // 0x300(0x08)
	struct UCheckBox* FilterCheckBox; // 0x308(0x08)
	char pad_310[0x8]; // 0x310(0x08)
	struct FChatFilterListEntryWidgetData WidgetData; // 0x318(0x18)

	void OnCheckStateChanged(bool bIsChecked); // Function DungeonCrawler.ChatFilterListEntryWidget.OnCheckStateChanged // (None) // @ game+0xffffba80df830041
};

// Class DungeonCrawler.ChatFilterWidget
// Size: 0x370 (Inherited: 0x300)
struct UChatFilterWidget : UDCWidgetBase {
	struct UListView* ChatFilterListView; // 0x300(0x08)
	struct UEditableText* EditableSearchText; // 0x308(0x08)
	char pad_310[0x60]; // 0x310(0x60)

	void SetChatFilterListVisible(bool InbVisible); // Function DungeonCrawler.ChatFilterWidget.SetChatFilterListVisible // (None) // @ game+0xffffba83df830041
};

// Class DungeonCrawler.ChatSetWidgetBase
// Size: 0x408 (Inherited: 0x300)
struct UChatSetWidgetBase : UDCWidgetBase {
	struct UListView* ChatListView; // 0x300(0x08)
	struct UChatEditWidgetBase* ChatEditWidget; // 0x308(0x08)
	struct UAccountLink* AccountLink; // 0x310(0x08)
	char pad_318[0x90]; // 0x318(0x90)
	struct TArray<struct UChatWidgetData*> ChatWidgetDataArray; // 0x3a8(0x10)
	char pad_3B8[0x50]; // 0x3b8(0x50)

	void SetChatKeyboardFocus(); // Function DungeonCrawler.ChatSetWidgetBase.SetChatKeyboardFocus // (None) // @ game+0xffffba89df830041
};

// Class DungeonCrawler.ChatWidgetData
// Size: 0xb8 (Inherited: 0x28)
struct UChatWidgetData : UObject {
	int64_t ChatIndex; // 0x28(0x08)
	enum class EChatWidgetType ChatWidgetType; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FDateTime DateTime; // 0x38(0x08)
	struct FString AccountId; // 0x40(0x10)
	struct FString CharacterId; // 0x50(0x10)
	struct FNickname Nickname; // 0x60(0x28)
	struct FString PartyId; // 0x88(0x10)
	struct TArray<struct FChatDataPiece> ChatDataPieceArray; // 0x98(0x10)
	struct TArray<enum class EContextOptionType> ContextOptionArray; // 0xa8(0x10)
};

// Class DungeonCrawler.ChatWidgetBase
// Size: 0x398 (Inherited: 0x300)
struct UChatWidgetBase : UDCWidgetBase {
	char pad_300[0x10]; // 0x300(0x10)
	struct UChatWidgetData* ChatWidgetData; // 0x310(0x08)
	char pad_318[0x80]; // 0x318(0x80)

	void OnRightClicked(); // Function DungeonCrawler.ChatWidgetBase.OnRightClicked // (None) // @ game+0xffffba8cdf830041
};

// Class DungeonCrawler.ClassGroupWidgetBase
// Size: 0x460 (Inherited: 0x440)
struct UClassGroupWidgetBase : UDCCommonActivatableWidgetBase {
	enum class EWidgetClassGroupType WidgetClassGroupType; // 0x440(0x01)
	char pad_441[0x7]; // 0x441(0x07)
	struct TArray<enum class EWidgetClassGroupType> NonCoexistWidgetWidgetClassGroupTypeArray; // 0x448(0x10)
	char pad_458[0x8]; // 0x458(0x08)
};

// Class DungeonCrawler.ClassIconGroupWidget
// Size: 0x318 (Inherited: 0x300)
struct UClassIconGroupWidget : UDCWidgetBase {
	struct UCommonTileView* ClassIconCommonTileView; // 0x300(0x08)
	struct FMulticastInlineDelegate ClassIconSelectedDelegate; // 0x308(0x10)
};

// Class DungeonCrawler.ClassIconWidgetData
// Size: 0x110 (Inherited: 0x28)
struct UClassIconWidgetData : UObject {
	int32_t ItemIndex; // 0x28(0x04)
	struct FPrimaryAssetId CharacterClassId; // 0x2c(0x10)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FDesignDataPlayerCharacter DesignDataPlayerCharacter; // 0x40(0xd0)
};

// Class DungeonCrawler.ClassIconWidget
// Size: 0x308 (Inherited: 0x300)
struct UClassIconWidget : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)

	void OnClickedClassIconButton(); // Function DungeonCrawler.ClassIconWidget.OnClickedClassIconButton // (None) // @ game+0xffffba8ddf830041
};

// Class DungeonCrawler.PerkListWidgetBase
// Size: 0x328 (Inherited: 0x300)
struct UPerkListWidgetBase : UDCWidgetBase {
	struct UAccountLink* AccountLink; // 0x300(0x08)
	struct FString LinkedAccountId; // 0x308(0x10)
	struct FString CheckTargetAccountId; // 0x318(0x10)
};

// Class DungeonCrawler.ClassPerkListWidgetBase
// Size: 0x370 (Inherited: 0x328)
struct UClassPerkListWidgetBase : UPerkListWidgetBase {
	struct TArray<struct UPerkWidget*> PerkWidgetArray; // 0x328(0x10)
	char pad_338[0x4]; // 0x338(0x04)
	struct FPrimaryAssetId MaxPerkSlotCountConstant; // 0x33c(0x10)
	char pad_34C[0x24]; // 0x34c(0x24)

	void SetSelectedSlotIndex(int32_t InSlotIndex); // Function DungeonCrawler.ClassPerkListWidgetBase.SetSelectedSlotIndex // (None) // @ game+0xffffba93df830041
};

// Class DungeonCrawler.ClassSelectAttributeItemWidgetData
// Size: 0x38 (Inherited: 0x28)
struct UClassSelectAttributeItemWidgetData : UObject {
	struct FGameplayEffectDescData AttrributeEffectDescData; // 0x28(0x0c)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class DungeonCrawler.ClassSelectAttributeItemWidget
// Size: 0x308 (Inherited: 0x300)
struct UClassSelectAttributeItemWidget : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)
};

// Class DungeonCrawler.ClassSelectItemWidgetData
// Size: 0x110 (Inherited: 0x28)
struct UClassSelectItemWidgetData : UObject {
	struct FPrimaryAssetId PlayerCharacterId; // 0x28(0x10)
	struct FDesignDataPlayerCharacter DesignDataPlayerCharacter; // 0x38(0xd0)
	bool bSelected; // 0x108(0x01)
	char pad_109[0x7]; // 0x109(0x07)
};

// Class DungeonCrawler.ClassSelectItemWidget
// Size: 0x308 (Inherited: 0x300)
struct UClassSelectItemWidget : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)
};

// Class DungeonCrawler.ClassSelectPerkItemWidgetData
// Size: 0x38 (Inherited: 0x28)
struct UClassSelectPerkItemWidgetData : UObject {
	struct FString PerkId; // 0x28(0x10)
};

// Class DungeonCrawler.ClassSelectPerkItemWidget
// Size: 0x308 (Inherited: 0x300)
struct UClassSelectPerkItemWidget : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)
};

// Class DungeonCrawler.ClassSelectWidget
// Size: 0x338 (Inherited: 0x300)
struct UClassSelectWidget : UDCWidgetBase {
	struct UTileView* ClassSelectTileView; // 0x300(0x08)
	struct UTileView* ClassAttributeTileView; // 0x308(0x08)
	struct UListView* ClassPerkTileView; // 0x310(0x08)
	struct UButton* ClassSelectButton; // 0x318(0x08)
	char pad_320[0x10]; // 0x320(0x10)
	struct UAccountLink* AccountLink; // 0x330(0x08)

	void OnPlayerCharacterId(struct FPrimaryAssetId& NewValue, struct FPrimaryAssetId& OldValue); // Function DungeonCrawler.ClassSelectWidget.OnPlayerCharacterId // (None) // @ game+0xffffba95df830041
};

// Class DungeonCrawler.SkillListWidgetBase
// Size: 0x328 (Inherited: 0x300)
struct USkillListWidgetBase : UDCWidgetBase {
	struct UAccountLink* AccountLink; // 0x300(0x08)
	struct FString LinkedAccountId; // 0x308(0x10)
	struct FString CheckTargetAccountId; // 0x318(0x10)
};

// Class DungeonCrawler.ClassSkillListWidgetBase
// Size: 0x360 (Inherited: 0x328)
struct UClassSkillListWidgetBase : USkillListWidgetBase {
	struct TArray<struct USkillWidget*> SkillWidgetArray; // 0x328(0x10)
	char pad_338[0x4]; // 0x338(0x04)
	struct FPrimaryAssetId MaxPerkSlotCountConstant; // 0x33c(0x10)
	struct FPrimaryAssetId MaxSkillSlotCountConstant; // 0x34c(0x10)
	char pad_35C[0x4]; // 0x35c(0x04)

	void SetSelectedSlotIndex(int32_t InSlotIndex); // Function DungeonCrawler.ClassSkillListWidgetBase.SetSelectedSlotIndex // (None) // @ game+0xffffba9bdf830041
};

// Class DungeonCrawler.SpellSlotWidgetBase
// Size: 0x408 (Inherited: 0x300)
struct USpellSlotWidgetBase : UDCWidgetBase {
	struct FSpellData SpellData; // 0x300(0x30)
	struct FDesignDataSpell DesignDataSpell; // 0x330(0xb8)
	struct TArray<struct FText> DescTextArray; // 0x3e8(0x10)
	struct UArtDataSpell* ArtData; // 0x3f8(0x08)
	int32_t SlotIndex; // 0x400(0x04)
	char pad_404[0x4]; // 0x404(0x04)

	void SetSpellData(struct FSpellData& InSpellData, struct FDesignDataSpell& InDesignDataSpell); // Function DungeonCrawler.SpellSlotWidgetBase.SetSpellData // (None) // @ game+0xffffbaa0df830041
};

// Class DungeonCrawler.SpellCapacitySlotWidget
// Size: 0x410 (Inherited: 0x408)
struct USpellCapacitySlotWidget : USpellSlotWidgetBase {
	int32_t SequenceIndex; // 0x408(0x04)
	char pad_40C[0x4]; // 0x40c(0x04)
};

// Class DungeonCrawler.ClassSpellCapacitySlotWidget
// Size: 0x428 (Inherited: 0x410)
struct UClassSpellCapacitySlotWidget : USpellCapacitySlotWidget {
	struct FText SequenceText; // 0x410(0x18)
};

// Class DungeonCrawler.SpellCapacityWidgetBase
// Size: 0x4a8 (Inherited: 0x440)
struct USpellCapacityWidgetBase : UDCCommonActivatableWidgetBase {
	struct USpellCapacitySlotWidget* SpellCapacitySlot_2; // 0x440(0x08)
	struct USpellCapacitySlotWidget* SpellCapacitySlot_3; // 0x448(0x08)
	struct USpellCapacitySlotWidget* SpellCapacitySlot_4; // 0x450(0x08)
	struct USpellCapacitySlotWidget* SpellCapacitySlot_5; // 0x458(0x08)
	struct USpellCapacitySlotWidget* SpellCapacitySlot_6; // 0x460(0x08)
	struct USpellCapacitySlotWidget* SpellCapacitySlot_7; // 0x468(0x08)
	struct USpellCapacitySlotWidget* SpellCapacitySlot_8; // 0x470(0x08)
	struct USpellCapacitySlotWidget* SpellCapacitySlot_9; // 0x478(0x08)
	struct USpellCapacitySlotWidget* SpellCapacitySlot_10; // 0x480(0x08)
	struct USpellCapacitySlotWidget* SpellCapacitySlot_11; // 0x488(0x08)
	struct TArray<struct USpellCapacitySlotWidget*> SpellCapacitySlots; // 0x490(0x10)
	float SpellCurrentCapacity; // 0x4a0(0x04)
	float SpellMaxCapacity; // 0x4a4(0x04)

	void OnSpellCapacityChanged(float InSpellCurrentCapacity, float InSpellMaxCapacity); // Function DungeonCrawler.SpellCapacityWidgetBase.OnSpellCapacityChanged // (None) // @ game+0xffffbaa1df830041
};

// Class DungeonCrawler.ClassSpellCapacityWidget
// Size: 0x560 (Inherited: 0x4a8)
struct UClassSpellCapacityWidget : USpellCapacityWidgetBase {
	struct UImage* CapacityGauge_2; // 0x4a8(0x08)
	struct UImage* CapacityGauge_3; // 0x4b0(0x08)
	struct UImage* CapacityGauge_4; // 0x4b8(0x08)
	struct UImage* CapacityGauge_5; // 0x4c0(0x08)
	struct UImage* CapacityGauge_6; // 0x4c8(0x08)
	struct UImage* CapacityGauge_7; // 0x4d0(0x08)
	struct UImage* CapacityGauge_8; // 0x4d8(0x08)
	struct UImage* CapacityGauge_9; // 0x4e0(0x08)
	struct UImage* CapacityGauge_10; // 0x4e8(0x08)
	struct UImage* CapacityGauge_11; // 0x4f0(0x08)
	struct TArray<struct UImage*> CapacityGauges; // 0x4f8(0x10)
	struct USpacer* CapacitySpacer_2; // 0x508(0x08)
	struct USpacer* CapacitySpacer_3; // 0x510(0x08)
	struct USpacer* CapacitySpacer_4; // 0x518(0x08)
	struct USpacer* CapacitySpacer_5; // 0x520(0x08)
	struct USpacer* CapacitySpacer_6; // 0x528(0x08)
	struct USpacer* CapacitySpacer_7; // 0x530(0x08)
	struct USpacer* CapacitySpacer_8; // 0x538(0x08)
	struct USpacer* CapacitySpacer_9; // 0x540(0x08)
	struct USpacer* CapacitySpacer_10; // 0x548(0x08)
	struct TArray<struct USpacer*> CapacitySpacers; // 0x550(0x10)

	void OnSpellListChanged(struct TArray<struct FSpellData>& InSpellDataArray); // Function DungeonCrawler.ClassSpellCapacityWidget.OnSpellListChanged // (None) // @ game+0xffffbaa2df830041
};

// Class DungeonCrawler.ClassSpellEquippedWidget
// Size: 0x440 (Inherited: 0x440)
struct UClassSpellEquippedWidget : UDCCommonActivatableWidgetBase {
	struct UBaseObject* BaseObject; // 0x420(0x08)
	struct FDataTableRowHandle VirtualCursorModeInputActionData; // 0x428(0x10)
};

// Class DungeonCrawler.GameGroupWidgetBase
// Size: 0x460 (Inherited: 0x440)
struct UGameGroupWidgetBase : UDCCommonActivatableWidgetBase {
	bool bShowCursor; // 0x440(0x01)
	enum class EWidgetGameGroupType WidgetGameGroupType; // 0x441(0x01)
	char pad_442[0x6]; // 0x442(0x06)
	struct TArray<enum class EWidgetGameGroupType> NonCoexistWidgetGameGroupTypeArray; // 0x448(0x10)
	char pad_458[0x8]; // 0x458(0x08)

	void OnVisible(); // Function DungeonCrawler.GameGroupWidgetBase.OnVisible // (None) // @ game+0xffffbaa5df830041
};

// Class DungeonCrawler.SpellListWidgetBase
// Size: 0x4a0 (Inherited: 0x460)
struct USpellListWidgetBase : UGameGroupWidgetBase {
	struct USpellSlotWidgetBase* SpellSlot_2; // 0x460(0x08)
	struct USpellSlotWidgetBase* SpellSlot_3; // 0x468(0x08)
	struct USpellSlotWidgetBase* SpellSlot_4; // 0x470(0x08)
	struct USpellSlotWidgetBase* SpellSlot_5; // 0x478(0x08)
	struct USpellSlotWidgetBase* SpellSlot_6; // 0x480(0x08)
	struct TArray<struct USpellSlotWidgetBase*> SpellSlots; // 0x488(0x10)
	enum class EWidgetSpellSlotsType WidgetSlotType; // 0x498(0x01)
	char pad_499[0x7]; // 0x499(0x07)
};

// Class DungeonCrawler.ClassSpellListWidget
// Size: 0x4a0 (Inherited: 0x4a0)
struct UClassSpellListWidget : USpellListWidgetBase {
	struct USpellSlotWidgetBase* SpellSlot_2; // 0x460(0x08)
	struct USpellSlotWidgetBase* SpellSlot_3; // 0x468(0x08)
	struct USpellSlotWidgetBase* SpellSlot_4; // 0x470(0x08)
	struct USpellSlotWidgetBase* SpellSlot_5; // 0x478(0x08)
	struct USpellSlotWidgetBase* SpellSlot_6; // 0x480(0x08)
	struct TArray<struct USpellSlotWidgetBase*> SpellSlots; // 0x488(0x10)
	enum class EWidgetSpellSlotsType WidgetSlotType; // 0x498(0x01)

	void OnShowEquippableSlot(); // Function DungeonCrawler.ClassSpellListWidget.OnShowEquippableSlot // (None) // @ game+0xffffbaa7df830041
};

// Class DungeonCrawler.ClassSpellSkillListWidgetBase
// Size: 0x358 (Inherited: 0x328)
struct UClassSpellSkillListWidgetBase : USkillListWidgetBase {
	struct TArray<struct USkillWidget*> SkillWidgetArray; // 0x328(0x10)
	struct FPrimaryAssetId MaxPerkSlotCountConstant; // 0x338(0x10)
	struct FPrimaryAssetId MaxSkillSlotCountConstant; // 0x348(0x10)

	void OnFMsgWidgetClassSlotUnLockLevelNotifyBlueprint(struct FMsgWidgetClassSlotUnLockLevelNotify& InMsg); // Function DungeonCrawler.ClassSpellSkillListWidgetBase.OnFMsgWidgetClassSlotUnLockLevelNotifyBlueprint // (None) // @ game+0xffffbaa9df830041
};

// Class DungeonCrawler.ClassTabMenuWidget
// Size: 0x1500 (Inherited: 0x14f0)
struct UClassTabMenuWidget : UCommonButtonBase {
	struct TArray<struct FPrimaryAssetId> ShowSpellTabClasses; // 0x14f0(0x10)

	void OnLobbyCharacterInfoUpdated_BP(struct FPrimaryAssetId& CharacterClassId); // Function DungeonCrawler.ClassTabMenuWidget.OnLobbyCharacterInfoUpdated_BP // (None) // @ game+0xffffbaabdf830041
};

// Class DungeonCrawler.ClassUnEquipmentPerkandSkillItemWidgetData
// Size: 0x48 (Inherited: 0x28)
struct UClassUnEquipmentPerkandSkillItemWidgetData : UObject {
	struct FPrimaryAssetId ID; // 0x28(0x10)
	bool Selected; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct UUserWidget* Widget; // 0x40(0x08)
};

// Class DungeonCrawler.ClassUnEquipmentPerkandSkillListWidget
// Size: 0x450 (Inherited: 0x440)
struct UClassUnEquipmentPerkandSkillListWidget : UDCCommonActivatableWidgetBase {
	struct UTileView* PerkTileView; // 0x440(0x08)
	struct UTileView* SkillTileView; // 0x448(0x08)

	void OnSetCompletedSkillTileView(); // Function DungeonCrawler.ClassUnEquipmentPerkandSkillListWidget.OnSetCompletedSkillTileView // (None) // @ game+0xffffbab1df830041
};

// Class DungeonCrawler.ClassUnEquipmentSpellItemWidgetData
// Size: 0x40 (Inherited: 0x28)
struct UClassUnEquipmentSpellItemWidgetData : UObject {
	struct FPrimaryAssetId ID; // 0x28(0x10)
	bool Selected; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// Class DungeonCrawler.ClassUnEquipmentSpellListWidget
// Size: 0x448 (Inherited: 0x440)
struct UClassUnEquipmentSpellListWidget : UDCCommonActivatableWidgetBase {
	struct UListView* SpellListView; // 0x440(0x08)
};

// Class DungeonCrawler.ClassUnEquipmentSpellTierItemWidgetData
// Size: 0x40 (Inherited: 0x28)
struct UClassUnEquipmentSpellTierItemWidgetData : UObject {
	int32_t Tier; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct TArray<struct FPrimaryAssetId> SpellIds; // 0x30(0x10)
};

// Class DungeonCrawler.ClassUnEquipmentSpellTierListWidget
// Size: 0x320 (Inherited: 0x300)
struct UClassUnEquipmentSpellTierListWidget : UDCWidgetBase {
	char pad_300[0x8]; // 0x300(0x08)
	struct UTextBlock* TierNumber; // 0x308(0x08)
	struct UTextBlock* CostNumber; // 0x310(0x08)
	struct UTileView* SpellTileView; // 0x318(0x08)
};

// Class DungeonCrawler.SubSystemReplyMsg
// Size: 0x48 (Inherited: 0x28)
struct USubSystemReplyMsg : UObject {
	char pad_28[0x18]; // 0x28(0x18)
	float CreateAt; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class DungeonCrawler.ClientAccountSubsystem
// Size: 0x4b0 (Inherited: 0x30)
struct UClientAccountSubsystem : UGameInstanceSubsystem {
	char pad_30[0x2e8]; // 0x30(0x2e8)
	struct TMap<int16_t, struct USubSystemReplyMsg*> ResponseLambdaPointerMap; // 0x318(0x50)
	char pad_368[0x18]; // 0x368(0x18)
	struct UTcpSocket* TcpSocketObject; // 0x380(0x08)
	char pad_388[0x128]; // 0x388(0x128)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.ClientAccountSubsystem.UnbindMsgAll // (None) // @ game+0xffffbab5df830041
};

// Class DungeonCrawler.ClientPartySubsystem
// Size: 0x1c0 (Inherited: 0x30)
struct UClientPartySubsystem : UGameInstanceSubsystem {
	char pad_30[0x190]; // 0x30(0x190)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.ClientPartySubsystem.UnbindMsgAll // (None) // @ game+0xffffbab9df830041
};

// Class DungeonCrawler.ClientShopSubsystem
// Size: 0x90 (Inherited: 0x30)
struct UClientShopSubsystem : UGameInstanceSubsystem {
	char pad_30[0x60]; // 0x30(0x60)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.ClientShopSubsystem.UnbindMsgAll // (None) // @ game+0xffffbabddf830041
};

// Class DungeonCrawler.CommemorativePlaqueTextWidget
// Size: 0x300 (Inherited: 0x300)
struct UCommemorativePlaqueTextWidget : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)

	void UpdateCommenorativePlaqueText(struct TArray<struct FText>& InText, struct FVector Location); // Function DungeonCrawler.CommemorativePlaqueTextWidget.UpdateCommenorativePlaqueText // (None) // @ game+0xffffbac0df830041
};

// Class DungeonCrawler.DCCommonButtonBase
// Size: 0x320 (Inherited: 0x300)
struct UDCCommonButtonBase : UDCWidgetBase {
	struct UCommonButtonBase* Btn_Common; // 0x300(0x08)
	struct FMulticastInlineDelegate OnCommonButtonClick; // 0x308(0x10)
	struct UAkAudioEvent* ClickSound; // 0x318(0x08)

	void SetButtonText(struct FText& InButtonText); // Function DungeonCrawler.DCCommonButtonBase.SetButtonText // (None) // @ game+0xffffbac3df830041
};

// Class DungeonCrawler.CommonButtonLWidget
// Size: 0x320 (Inherited: 0x320)
struct UCommonButtonLWidget : UDCCommonButtonBase {
	struct UCommonButtonBase* Btn_Common; // 0x300(0x08)
	struct FMulticastInlineDelegate OnCommonButtonClick; // 0x308(0x10)
	struct UAkAudioEvent* ClickSound; // 0x318(0x08)

	void SetSwitchOn(bool bSetOn); // Function DungeonCrawler.CommonButtonLWidget.SetSwitchOn // (None) // @ game+0xffffbac5df830041
};

// Class DungeonCrawler.CommonButtonMWidget
// Size: 0x320 (Inherited: 0x320)
struct UCommonButtonMWidget : UDCCommonButtonBase {
	struct UCommonButtonBase* Btn_Common; // 0x300(0x08)
	struct FMulticastInlineDelegate OnCommonButtonClick; // 0x308(0x10)
	struct UAkAudioEvent* ClickSound; // 0x318(0x08)

	void SetAllText(struct FText TextTitle); // Function DungeonCrawler.CommonButtonMWidget.SetAllText // (None) // @ game+0xffffbac6df830041
};

// Class DungeonCrawler.CommonButtonPopupWidget
// Size: 0x320 (Inherited: 0x320)
struct UCommonButtonPopupWidget : UDCCommonButtonBase {
	struct UCommonButtonBase* Btn_Common; // 0x300(0x08)
	struct FMulticastInlineDelegate OnCommonButtonClick; // 0x308(0x10)
	struct UAkAudioEvent* ClickSound; // 0x318(0x08)

	void SetAllText(struct FText TextTitle); // Function DungeonCrawler.CommonButtonPopupWidget.SetAllText // (None) // @ game+0xffffbac7df830041
};

// Class DungeonCrawler.CommonButtonSWidget
// Size: 0x320 (Inherited: 0x320)
struct UCommonButtonSWidget : UDCCommonButtonBase {
	struct UCommonButtonBase* Btn_Common; // 0x300(0x08)
	struct FMulticastInlineDelegate OnCommonButtonClick; // 0x308(0x10)
	struct UAkAudioEvent* ClickSound; // 0x318(0x08)

	void SetAllText(struct FText TextTitle); // Function DungeonCrawler.CommonButtonSWidget.SetAllText // (None) // @ game+0xffffbac8df830041
};

// Class DungeonCrawler.CommonButtonXLWidget
// Size: 0x320 (Inherited: 0x320)
struct UCommonButtonXLWidget : UDCCommonButtonBase {
	struct UCommonButtonBase* Btn_Common; // 0x300(0x08)
	struct FMulticastInlineDelegate OnCommonButtonClick; // 0x308(0x10)
	struct UAkAudioEvent* ClickSound; // 0x318(0x08)

	void SetAllText(struct FText TextTitle); // Function DungeonCrawler.CommonButtonXLWidget.SetAllText // (None) // @ game+0xffffbac9df830041
};

// Class DungeonCrawler.PopupDataBase
// Size: 0x30 (Inherited: 0x28)
struct UPopupDataBase : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class DungeonCrawler.CommonPopupBase
// Size: 0x440 (Inherited: 0x440)
struct UCommonPopupBase : UDCCommonActivatableWidgetBase {
	struct UBaseObject* BaseObject; // 0x420(0x08)
	struct FDataTableRowHandle VirtualCursorModeInputActionData; // 0x428(0x10)
};

// Class DungeonCrawler.CommonPopupManageWidget
// Size: 0x378 (Inherited: 0x300)
struct UCommonPopupManageWidget : UDCWidgetBase {
	struct UCanvasPanel* PopupCanvas; // 0x300(0x08)
	struct UDCCommonActivatableWidgetBase* DefaultPopupWidgetClass; // 0x308(0x08)
	struct TMap<int32_t, struct FMsgPopup> ReplyPointerMap; // 0x310(0x50)
	char pad_360[0x18]; // 0x360(0x18)
};

// Class DungeonCrawler.PopupDataSWidget
// Size: 0x68 (Inherited: 0x30)
struct UPopupDataSWidget : UPopupDataBase {
	enum class EPopupButtonType PopupButtonType; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FText DescMessage; // 0x38(0x18)
	struct FString Nickname; // 0x50(0x10)
	char pad_60[0x8]; // 0x60(0x08)

	bool Cancel(); // Function DungeonCrawler.PopupDataSWidget.Cancel // (None) // @ game+0xffffbacadf830041
};

// Class DungeonCrawler.CommonPopupSWidget
// Size: 0x478 (Inherited: 0x440)
struct UCommonPopupSWidget : UCommonPopupBase {
	struct UCommonButtonPopupWidget* Btn_Two_Left; // 0x440(0x08)
	struct UCommonButtonPopupWidget* Btn_Two_Right; // 0x448(0x08)
	struct UCommonButtonPopupWidget* Btn_Single; // 0x450(0x08)
	struct UCommonButtonPopupWidget* Btn_Two_Left_DeleteCharacter; // 0x458(0x08)
	struct UCommonButtonPopupWidget* Btn_Two_Right_DeleteCharacter; // 0x460(0x08)
	struct UEditableText* NicknameText; // 0x468(0x08)
	struct UPopupDataSWidget* PopupDataSWidget; // 0x470(0x08)

	void OnRemovePopup(); // Function DungeonCrawler.CommonPopupSWidget.OnRemovePopup // (None) // @ game+0xffffbad1df830041
};

// Class DungeonCrawler.ContainerInventoryGroupWidget
// Size: 0x3c0 (Inherited: 0x300)
struct UContainerInventoryGroupWidget : UDCWidgetBase {
	struct UAccountLink* AccountLink; // 0x300(0x08)
	struct FString LinkedAccountId; // 0x308(0x10)
	struct FString CheckTargetAccountId; // 0x318(0x10)
	struct TArray<struct TWeakObjectPtr<struct UInventoryComponent>> InventoryArray; // 0x328(0x10)
	char pad_338[0x18]; // 0x338(0x18)
	struct UPanelWidget* ContainerInventoryParent; // 0x350(0x08)
	struct TSoftClassPtr<UObject> ItemCountSelectWidgetClass; // 0x358(0x30)
	struct TArray<struct UContainerInventoryWidget*> ContainerInventoryWidgetArray; // 0x388(0x10)
	struct UContainerInventoryWidget* ContainerInventoryWidgetClass; // 0x398(0x08)
	struct UContainerInventoryWidget* ReadOnlyContainerInventoryWidgetClass; // 0x3a0(0x08)
	enum class EWidgetInventoryGroupType InventoryGroupType; // 0x3a8(0x01)
	char pad_3A9[0x7]; // 0x3a9(0x07)
	struct FMulticastInlineDelegate OnInventoryCountChanged; // 0x3b0(0x10)

	void ResetContainerInventoryWidgets(); // Function DungeonCrawler.ContainerInventoryGroupWidget.ResetContainerInventoryWidgets // (None) // @ game+0xffffbad4df830041
};

// Class DungeonCrawler.ContainerInventoryWidget
// Size: 0x408 (Inherited: 0x300)
struct UContainerInventoryWidget : UDCWidgetBase {
	struct UGridPanel* ContainerSlotGridPanel; // 0x300(0x08)
	struct UOverlay* ContainerItemOvelay; // 0x308(0x08)
	struct UContainerSlotWidget* ContainerSlotWidgetClass; // 0x310(0x08)
	float ContainerSlotSize; // 0x318(0x04)
	char pad_31C[0x4]; // 0x31c(0x04)
	struct TMap<int32_t, struct FContainerSlotArrayData> ContainerSlotWidgetMap; // 0x320(0x50)
	struct TWeakObjectPtr<struct UInventoryComponent> InventoryComponent; // 0x370(0x08)
	struct UItemWidget* ItemWidgetClass; // 0x378(0x08)
	struct UAccountLink* AccountLink; // 0x380(0x08)
	struct FPrimaryAssetId PlayerCharacterId; // 0x388(0x10)
	struct TMap<int64_t, struct UItemWidget*> ItemWidgetMap; // 0x398(0x50)
	int32_t ContainerRowCount; // 0x3e8(0x04)
	int32_t ContainerColumnCount; // 0x3ec(0x04)
	int32_t DragDetectedContainerSlotId; // 0x3f0(0x04)
	char pad_3F4[0x4]; // 0x3f4(0x04)
	struct TArray<struct UContainerSlotWidget*> OverlapContainerSlots; // 0x3f8(0x10)

	void UpdateItemCanBeSet(struct FItemData& InItemData, int32_t SlotId); // Function DungeonCrawler.ContainerInventoryWidget.UpdateItemCanBeSet // (None) // @ game+0xffffbadddf830041
};

// Class DungeonCrawler.ContainerSlotWidget
// Size: 0x338 (Inherited: 0x300)
struct UContainerSlotWidget : UDCWidgetBase {
	struct FLinearColor ItemSetColor; // 0x300(0x10)
	struct FLinearColor InvalidSlotColor; // 0x310(0x10)
	struct FLinearColor ValidSlotColor; // 0x320(0x10)
	bool bHasItem; // 0x330(0x01)
	char pad_331[0x7]; // 0x331(0x07)

	void OnSetNewItem(bool bFullfilledAll); // Function DungeonCrawler.ContainerSlotWidget.OnSetNewItem // (None) // @ game+0xffffbae1df830041
};

// Class DungeonCrawler.ContextMenuHolderInterface
// Size: 0x28 (Inherited: 0x28)
struct UContextMenuHolderInterface : UInterface {

	void OnRightClicked(); // Function DungeonCrawler.ContextMenuHolderInterface.OnRightClicked // (None) // @ game+0xffffbae2df830041
};

// Class DungeonCrawler.ContextMenuWidgetBase
// Size: 0x318 (Inherited: 0x300)
struct UContextMenuWidgetBase : UDCWidgetBase {
	struct UListView* ListView_ContextOptions; // 0x300(0x08)
	struct UOverlay* Overlay_ContextMenu; // 0x308(0x08)
	bool bSetPosition; // 0x310(0x01)
	char pad_311[0x7]; // 0x311(0x07)

	void SetContextMenuWidgetPosition(); // Function DungeonCrawler.ContextMenuWidgetBase.SetContextMenuWidgetPosition // (None) // @ game+0xffffbae4df830041
};

// Class DungeonCrawler.ContextOptionListEntryWidgetData
// Size: 0x30 (Inherited: 0x28)
struct UContextOptionListEntryWidgetData : UObject {
	enum class EContextOptionType ContextOption; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// Class DungeonCrawler.ContextOptionListEntryWidgetBase
// Size: 0x328 (Inherited: 0x320)
struct UContextOptionListEntryWidgetBase : UDCCommonButtonBase {
	struct UCommonButtonBase* Btn_Common; // 0x300(0x08)
	struct FMulticastInlineDelegate OnCommonButtonClick; // 0x308(0x10)
	struct UAkAudioEvent* ClickSound; // 0x318(0x08)

	void OnSelect(); // Function DungeonCrawler.ContextOptionListEntryWidgetBase.OnSelect // (None) // @ game+0xffffbae5df830041
};

// Class DungeonCrawler.ItemWidget
// Size: 0x3d0 (Inherited: 0x300)
struct UItemWidget : UDCWidgetBase {
	struct UImage* ItemIconImage; // 0x300(0x08)
	struct USizeBox* ItemIconSizeBox; // 0x308(0x08)
	struct TWeakObjectPtr<struct AActor> ItemOwnedActor; // 0x310(0x08)
	float WidgetOriginalSize; // 0x318(0x04)
	char pad_31C[0x14]; // 0x31c(0x14)
	struct FItemWidgetData WidgetData; // 0x330(0xa0)

	void SetItemOwnerActor(struct AActor* InItemOwnedActor); // Function DungeonCrawler.ItemWidget.SetItemOwnerActor // (None) // @ game+0xffffbaebdf830041
};

// Class DungeonCrawler.ControllableItemWidget
// Size: 0x3d0 (Inherited: 0x3d0)
struct UControllableItemWidget : UItemWidget {
	struct UImage* ItemIconImage; // 0x300(0x08)
	struct USizeBox* ItemIconSizeBox; // 0x308(0x08)
	struct TWeakObjectPtr<struct AActor> ItemOwnedActor; // 0x310(0x08)
	float WidgetOriginalSize; // 0x318(0x04)
	struct FItemWidgetData WidgetData; // 0x330(0xa0)

	void QuickMoveItem(); // Function DungeonCrawler.ControllableItemWidget.QuickMoveItem // (None) // @ game+0xffffbaf1df830041
};

// Class DungeonCrawler.DCActorBase
// Size: 0x2f0 (Inherited: 0x290)
struct ADCActorBase : AActor {
	char pad_290[0x58]; // 0x290(0x58)
	struct UBaseObject* BaseObject; // 0x2e8(0x08)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCActorBase.UnbindMsgAll // (None) // @ game+0xffffbaf6df830041
};

// Class DungeonCrawler.DCAbilityActorBase
// Size: 0x300 (Inherited: 0x2f0)
struct ADCAbilityActorBase : ADCActorBase {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	struct UAbilitySystemComponent* AbilitySystemComponent; // 0x2f8(0x08)
};

// Class DungeonCrawler.DCInteractableActorBase
// Size: 0x300 (Inherited: 0x2f0)
struct ADCInteractableActorBase : ADCActorBase {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	struct UInteractableTargetComponent* InteractableTargetComponent; // 0x2f8(0x08)

	void InteractSucceed(struct AActor* Interacter, struct FGameplayTag StateTag, struct FGameplayTag TriggerTag, struct FHitResult HitResult); // Function DungeonCrawler.DCInteractableActorBase.InteractSucceed // (None) // @ game+0xffffbafbdf830041
};

// Class DungeonCrawler.DCAbilityInteractableActorBase
// Size: 0x310 (Inherited: 0x300)
struct ADCAbilityInteractableActorBase : ADCInteractableActorBase {
	char pad_300[0x8]; // 0x300(0x08)
	struct UAbilitySystemComponent* AbilitySystemComponent; // 0x308(0x08)
};

// Class DungeonCrawler.DCAbilitySystemBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UDCAbilitySystemBlueprintLibrary : UAbilitySystemBlueprintLibrary {

	bool SetMovementStateGameplayTag(struct AActor* InActor, struct FGameplayTag InGameplayTag); // Function DungeonCrawler.DCAbilitySystemBlueprintLibrary.SetMovementStateGameplayTag // (None) // @ game+0xffffbb41df830041
};

// Class DungeonCrawler.DCAbilitySystemComponent
// Size: 0x18f8 (Inherited: 0x13a0)
struct UDCAbilitySystemComponent : UAbilitySystemComponent {
	char pad_13A0[0xa8]; // 0x13a0(0xa8)
	struct FActorDieData ActorDieData; // 0x1448(0x1d8)
	struct FImpactEnduranceExhaustedData ImpactEnduranceExhaustedData; // 0x1620(0x1d8)
	char pad_17F8[0x70]; // 0x17f8(0x70)
	struct TArray<struct FDCGameplayAbilityHandleData> AbilityHandleDataArray; // 0x1868(0x10)
	char pad_1878[0x50]; // 0x1878(0x50)
	struct UGameplayAbilityRelationshipData* AbilityTagRelationship; // 0x18c8(0x08)
	struct UGameplayTagMessageRelationshipData* GameplayTagMessageRelationshipData; // 0x18d0(0x08)
	struct UGameplayCueRelationshipData* GameplayCueRelationship; // 0x18d8(0x08)
	struct UGameplayCueRelationshipData* OverrideGameplayCueRelationship; // 0x18e0(0x08)
	struct TArray<struct FDCGameplayEffectContainerSpec> PremadeContainerSpecArray; // 0x18e8(0x10)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCAbilitySystemComponent.UnbindMsgAll // (None) // @ game+0xffffbb4ddf830041
};

// Class DungeonCrawler.DCAbilitySystemGlobals
// Size: 0x2b8 (Inherited: 0x298)
struct UDCAbilitySystemGlobals : UAbilitySystemGlobals {
	struct UGameplayEffect* GameplayEffectClassMMC; // 0x298(0x08)
	struct UGameplayEffect* GameplayEffectClassMMCSimple; // 0x2a0(0x08)
	struct UGameplayEffect* GameplayEffectClassInfiniteTagOnly; // 0x2a8(0x08)
	struct UGameplayEffect* GameplayEffectClassDurationTagOnly; // 0x2b0(0x08)
};

// Class DungeonCrawler.DCActionSkinArtData
// Size: 0x40 (Inherited: 0x38)
struct UDCActionSkinArtData : UDCDataAssetBase {
	struct UTexture2D* IconTexture; // 0x38(0x08)
};

// Class DungeonCrawler.DCActionSkinComponent
// Size: 0x100 (Inherited: 0xa0)
struct UDCActionSkinComponent : UActorComponent {
	struct TArray<struct UDCActionSkinDataAsset*> Datas; // 0xa0(0x10)
	char pad_B0[0x50]; // 0xb0(0x50)

	void OnRep_Datas(struct TArray<struct UDCActionSkinDataAsset*>& OldDatas); // Function DungeonCrawler.DCActionSkinComponent.OnRep_Datas // (None) // @ game+0xffffbb4edf830041
};

// Class DungeonCrawler.DCDataAsset
// Size: 0x38 (Inherited: 0x30)
struct UDCDataAsset : UPrimaryDataAsset {
	struct FPrimaryAssetType AssetType; // 0x30(0x08)
};

// Class DungeonCrawler.DCActionSkinDataAsset
// Size: 0x100 (Inherited: 0x38)
struct UDCActionSkinDataAsset : UDCDataAsset {
	struct FText Name; // 0x38(0x18)
	struct FText FlavorText; // 0x50(0x18)
	enum class EDCActionSkinType ActionSkinType; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
	struct TSoftObjectPtr<UDCActionSkinArtData> Art; // 0x70(0x30)
	struct TSoftObjectPtr<UDCGameplayAbilityDataAsset> TargetAction; // 0xa0(0x30)
	struct TSoftObjectPtr<UDCGameplayAbilityDataAsset> SkinAction; // 0xd0(0x30)
};

// Class DungeonCrawler.DCActionSkinListEntryWidgetData
// Size: 0x38 (Inherited: 0x28)
struct UDCActionSkinListEntryWidgetData : UObject {
	struct FDCActionSkinInfo ActionSkinInfo; // 0x28(0x10)
};

// Class DungeonCrawler.DCControlWidgetBase
// Size: 0x368 (Inherited: 0x278)
struct UDCControlWidgetBase : UUserWidget {
	bool bCanClick; // 0x278(0x01)
	bool bCanDrag; // 0x279(0x01)
	char pad_27A[0x6]; // 0x27a(0x06)
	struct FDCMouseClickInfo PrevMouseInfo; // 0x280(0xe0)
	struct FTimerHandle TimerHandle; // 0x360(0x08)

	void OnClickTimer(); // Function DungeonCrawler.DCControlWidgetBase.OnClickTimer // (None) // @ game+0xffffbb4fdf830041
};

// Class DungeonCrawler.DCActionSkinWidget
// Size: 0x3e0 (Inherited: 0x368)
struct UDCActionSkinWidget : UDCControlWidgetBase {
	char pad_368[0x18]; // 0x368(0x18)
	struct FText ActionSkinName; // 0x380(0x18)
	struct FText ActionSkinFlavorText; // 0x398(0x18)
	struct UTexture2D* ActionSkinIconTexture; // 0x3b0(0x08)
	struct FPrimaryAssetId ActionSkinId; // 0x3b8(0x10)
	bool bIsEquipped; // 0x3c8(0x01)
	char pad_3C9[0x7]; // 0x3c9(0x07)
	struct UDCSkinTooltipWidget* TooltipWidgetClass; // 0x3d0(0x08)
	struct UUserWidget* SkinTooltipWidget; // 0x3d8(0x08)

	struct UUserWidget* GetActionSkinTooltipWidget(); // Function DungeonCrawler.DCActionSkinWidget.GetActionSkinTooltipWidget // (None) // @ game+0xffffbb50df830041
};

// Class DungeonCrawler.DCActionSkinListEntryWidget
// Size: 0x3f0 (Inherited: 0x3e0)
struct UDCActionSkinListEntryWidget : UDCActionSkinWidget {
	struct FText ActionSkinName; // 0x380(0x18)
	struct FText ActionSkinFlavorText; // 0x398(0x18)
	struct UTexture2D* ActionSkinIconTexture; // 0x3b0(0x08)
	struct FPrimaryAssetId ActionSkinId; // 0x3b8(0x10)
	bool bIsEquipped; // 0x3c8(0x01)
	struct UDCSkinTooltipWidget* TooltipWidgetClass; // 0x3d0(0x08)
	struct UUserWidget* SkinTooltipWidget; // 0x3d8(0x08)

	void OnRightClicked(); // Function DungeonCrawler.DCActionSkinListEntryWidget.OnRightClicked // (None) // @ game+0xffffbb51df830041
};

// Class DungeonCrawler.DCActorReferenceCounterInterface
// Size: 0x28 (Inherited: 0x28)
struct UDCActorReferenceCounterInterface : UInterface {
};

// Class DungeonCrawler.DCActorStatusComponent
// Size: 0x118 (Inherited: 0xa0)
struct UDCActorStatusComponent : UActorComponent {
	char pad_A0[0x58]; // 0xa0(0x58)
	struct UAsyncTaskEffectStackChanged* EffectStackAsyncTask; // 0xf8(0x08)
	struct UAsyncTaskEffectInhibitionChanged* EffectInhibitAsyncTask; // 0x100(0x08)
	struct TArray<struct FActorStatusData> ActorStatusDatas; // 0x108(0x10)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCActorStatusComponent.UnbindMsgAll // (None) // @ game+0xffffbb58df830041
};

// Class DungeonCrawler.DCAIPerceptionComponent
// Size: 0x180 (Inherited: 0x180)
struct UDCAIPerceptionComponent : UAIPerceptionComponent {
	struct TArray<struct UAISenseConfig*> SensesConfig; // 0xa0(0x10)
	struct UAISense* DominantSense; // 0xb0(0x08)
	struct AAIController* AIOwner; // 0xc8(0x08)
	struct FMulticastInlineDelegate OnPerceptionUpdated; // 0x150(0x10)
	struct FMulticastInlineDelegate OnTargetPerceptionUpdated; // 0x160(0x10)
	struct FMulticastInlineDelegate OnTargetPerceptionInfoUpdated; // 0x170(0x10)
};

// Class DungeonCrawler.DCAkAcousticPortal
// Size: 0x2d8 (Inherited: 0x2d8)
struct ADCAkAcousticPortal : AAkAcousticPortal {
	struct UAkPortalComponent* Portal; // 0x2c8(0x08)
	enum class AkAcousticPortalState InitialState; // 0x2d0(0x01)
	bool bRequiresStateMigration; // 0x2d1(0x01)
};

// Class DungeonCrawler.DCAkComponent
// Size: 0x660 (Inherited: 0x4a0)
struct UDCAkComponent : UAkComponent {
	char pad_4A0[0x58]; // 0x4a0(0x58)
	struct TMap<uint32_t, struct FAkAudioVolumeInfo> CurrentVolumeIdMap; // 0x4f8(0x50)
	uint32_t CurrentVolumeId; // 0x548(0x04)
	char pad_54C[0x4]; // 0x54c(0x04)
	struct TMap<struct FGameplayTag, struct UAkAudioEvent*> AkEvents; // 0x550(0x50)
	struct TMap<struct FGameplayTag, struct FDCSoundDataContainer> AkSwitches; // 0x5a0(0x50)
	struct TMap<struct FGameplayTag, struct FGameplayTagQuery> SoundPlayableCondition; // 0x5f0(0x50)
	struct FPrimaryAssetId SoundDataId; // 0x640(0x10)
	char pad_650[0x10]; // 0x650(0x10)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCAkComponent.UnbindMsgAll // (None) // @ game+0xffffbb68df830041
};

// Class DungeonCrawler.DCAkSpatialAudioVolume
// Size: 0x388 (Inherited: 0x2e0)
struct ADCAkSpatialAudioVolume : AAkSpatialAudioVolume {
	char pad_2E0[0x58]; // 0x2e0(0x58)
	struct UBaseObject* BaseObject; // 0x338(0x08)
	float Priority; // 0x340(0x04)
	char pad_344[0x4]; // 0x344(0x04)
	struct UAkAudioEvent* AkEventBeginOverlap; // 0x348(0x08)
	struct UAkStateValue* AkStateValueBeginOverlap; // 0x350(0x08)
	struct UAkRtpc* RtpcBeginOverlap; // 0x358(0x08)
	float RtpcValueBeginOverlap; // 0x360(0x04)
	char pad_364[0x4]; // 0x364(0x04)
	struct UAkAudioEvent* AkEventEndOverlap; // 0x368(0x08)
	struct UAkStateValue* AkStateValueEndOverlap; // 0x370(0x08)
	struct UAccountLink* AccountLink; // 0x378(0x08)
	char pad_380[0x8]; // 0x380(0x08)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCAkSpatialAudioVolume.UnbindMsgAll // (None) // @ game+0xffffbb70df830041
};

// Class DungeonCrawler.DCAnimInstanceBase
// Size: 0x400 (Inherited: 0x350)
struct UDCAnimInstanceBase : UAnimInstance {
	char pad_350[0x50]; // 0x350(0x50)
	struct FVector NativeVelocity; // 0x3a0(0x18)
	struct FVector NativeRelativeHorizontalVelocity; // 0x3b8(0x18)
	float NativeSpeed; // 0x3d0(0x04)
	float NativeHorizontalSpeed; // 0x3d4(0x04)
	float NativeDirectionAngle; // 0x3d8(0x04)
	bool bIsMontagePlaying; // 0x3dc(0x01)
	char pad_3DD[0x3]; // 0x3dd(0x03)
	struct FGameplayTag IdleAnimSequenceGameplayTag; // 0x3e0(0x08)
	struct FGameplayTag PendingIdleAnimSequenceGameplayTag; // 0x3e8(0x08)
	char bNoSkeletonUpdateIdle; // 0x3f0(0x01)
	char pad_3F1[0xf]; // 0x3f1(0x0f)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCAnimInstanceBase.UnbindMsgAll // (None) // @ game+0xffffbb77df830041
};

// Class DungeonCrawler.DCAnimInstanceV2
// Size: 0x3a0 (Inherited: 0x350)
struct UDCAnimInstanceV2 : UAnimInstance {
	struct TMap<struct FDCPlayerCharacterKey, struct UAnimSequence*> IdleAnims; // 0x348(0x50)

	struct UAnimSequence* GetIdleAnim(); // Function DungeonCrawler.DCAnimInstanceV2.GetIdleAnim // (None) // @ game+0xffffbb78df830041
};

// Class DungeonCrawler.DCAnimNotify_SendGameplayEventTagToSelf
// Size: 0x40 (Inherited: 0x38)
struct UDCAnimNotify_SendGameplayEventTagToSelf : UAnimNotify {
	struct FGameplayTag EventTag; // 0x38(0x08)
};

// Class DungeonCrawler.DCAnimNotify_MontageJumpToSectionOnSourceObject
// Size: 0x40 (Inherited: 0x38)
struct UDCAnimNotify_MontageJumpToSectionOnSourceObject : UAnimNotify {
	struct FName SectionName; // 0x38(0x08)
};

// Class DungeonCrawler.DCAnimNotify_PreReduceAmmoCountOnSourceObject
// Size: 0x40 (Inherited: 0x38)
struct UDCAnimNotify_PreReduceAmmoCountOnSourceObject : UAnimNotify {
	int32_t ReduceCount; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class DungeonCrawler.DCAnimNotify_SoundEvent
// Size: 0x40 (Inherited: 0x38)
struct UDCAnimNotify_SoundEvent : UAnimNotify {
	struct FGameplayTag EventTag; // 0x38(0x08)
};

// Class DungeonCrawler.DCAnimNotify_UnHideEquippedWeapons
// Size: 0x38 (Inherited: 0x38)
struct UDCAnimNotify_UnHideEquippedWeapons : UAnimNotify {
};

// Class DungeonCrawler.DCAnimNotify_SendGameplayEventTagsToSelf
// Size: 0x48 (Inherited: 0x30)
struct UDCAnimNotify_SendGameplayEventTagsToSelf : UAnimNotifyState {
	struct FGameplayTag BeginEventTag; // 0x30(0x08)
	struct FGameplayTag EndEventTag; // 0x38(0x08)
	struct FGameplayTag EventTag; // 0x40(0x08)
};

// Class DungeonCrawler.DCAoeAIControllerBase
// Size: 0x418 (Inherited: 0x3b8)
struct ADCAoeAIControllerBase : AAIController {
	char pad_3B8[0x58]; // 0x3b8(0x58)
	struct UBaseObject* BaseObject; // 0x410(0x08)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCAoeAIControllerBase.UnbindMsgAll // (None) // @ game+0xffffbbaddf830041
};

// Class DungeonCrawler.DCAoeBase
// Size: 0x6b0 (Inherited: 0x620)
struct ADCAoeBase : ACharacter {
	char pad_620[0x60]; // 0x620(0x60)
	struct UBaseObject* BaseObject; // 0x680(0x08)
	char pad_688[0x8]; // 0x688(0x08)
	struct UDCAoeDataAsset* AoeDataAsset; // 0x690(0x08)
	bool IsDestroyedWhenOwnerDie; // 0x698(0x01)
	bool ApplyContinuosDamage; // 0x699(0x01)
	char pad_69A[0x6]; // 0x69a(0x06)
	struct TArray<struct TWeakObjectPtr<struct ADCCharacterBase>> TargetArray; // 0x6a0(0x10)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCAoeBase.UnbindMsgAll // (None) // @ game+0xffffbbb4df830041
};

// Class DungeonCrawler.DCAoeDataAsset
// Size: 0xd0 (Inherited: 0x38)
struct UDCAoeDataAsset : UDCDataAsset {
	struct FText Name; // 0x38(0x18)
	struct TSoftObjectPtr<UArtDataAoe> ArtData; // 0x50(0x30)
	struct TSoftObjectPtr<USoundData> SoundData; // 0x80(0x30)
	struct TArray<struct TSoftObjectPtr<UDCGameplayAbilityDataAsset>> Abilities; // 0xb0(0x10)
	struct TArray<struct TSoftObjectPtr<UDCGameplayEffectDataAsset>> Effects; // 0xc0(0x10)
};

// Class DungeonCrawler.DCAoeSystemBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UDCAoeSystemBlueprintLibrary : UBlueprintFunctionLibrary {

	struct ADCAoeBase* SpawnAoeDeferred(struct ADCCharacterBase*& DCCharacterBase, struct ADCAoeBase* AoeClass, struct UDCGameplayAbilityBase* DCGameplayAbilityBase, struct FGameplayEventData EventData, bool& bSuccessfully); // Function DungeonCrawler.DCAoeSystemBlueprintLibrary.SpawnAoeDeferred // (None) // @ game+0xffffbbc6df830041
};

// Class DungeonCrawler.DCGameModeBase
// Size: 0x3a0 (Inherited: 0x330)
struct ADCGameModeBase : AGameModeBase {
	char pad_330[0x58]; // 0x330(0x58)
	struct UBaseObject* BaseObject; // 0x388(0x08)
	struct ADCGameModeAIControllerBase* GameModeAIControllerClass; // 0x390(0x08)
	struct ADCGameModeAIControllerBase* GameModeAIController; // 0x398(0x08)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCGameModeBase.UnbindMsgAll // (None) // @ game+0xffffbbe7df830041
};

// Class DungeonCrawler.DCIngameGameMode
// Size: 0x4c0 (Inherited: 0x3a0)
struct ADCIngameGameMode : ADCGameModeBase {
	char pad_3A0[0x68]; // 0x3a0(0x68)
	struct TArray<struct ADCPlayerStart*> StartPoints; // 0x408(0x10)
	char pad_418[0xa8]; // 0x418(0xa8)
};

// Class DungeonCrawler.DCArenaGameMode
// Size: 0x4c0 (Inherited: 0x4c0)
struct ADCArenaGameMode : ADCIngameGameMode {
	struct TArray<struct ADCPlayerStart*> StartPoints; // 0x408(0x10)
};

// Class DungeonCrawler.DCAssetManager
// Size: 0x588 (Inherited: 0x4e8)
struct UDCAssetManager : UAssetManager {
	struct TMap<struct FPrimaryAssetId, struct FLoadPrimaryAssetData> LoadPrimaryAssetDataMap; // 0x4e8(0x50)
	struct TMap<struct FPrimaryAssetType, struct FLoadPrimaryAssetType> LoadPrimaryAssetTypeMap; // 0x538(0x50)
};

// Class DungeonCrawler.DCAttributeModMagnitudeCalculationStrength
// Size: 0xc0 (Inherited: 0x40)
struct UDCAttributeModMagnitudeCalculationStrength : UGameplayModMagnitudeCalculation {
	bool bAllowNonNetAuthorityDependencyRegistration; // 0x38(0x01)
	char pad_41[0x7f]; // 0x41(0x7f)
};

// Class DungeonCrawler.DCAttributeModMagnitudeCalculationAgility
// Size: 0xc0 (Inherited: 0x40)
struct UDCAttributeModMagnitudeCalculationAgility : UGameplayModMagnitudeCalculation {
	bool bAllowNonNetAuthorityDependencyRegistration; // 0x38(0x01)
	char pad_41[0x7f]; // 0x41(0x7f)
};

// Class DungeonCrawler.DCAttributeModMagnitudeCalculationWill
// Size: 0xc0 (Inherited: 0x40)
struct UDCAttributeModMagnitudeCalculationWill : UGameplayModMagnitudeCalculation {
	bool bAllowNonNetAuthorityDependencyRegistration; // 0x38(0x01)
	char pad_41[0x7f]; // 0x41(0x7f)
};

// Class DungeonCrawler.DCAttributeModMagnitudeCalculationKnowledge
// Size: 0xc0 (Inherited: 0x40)
struct UDCAttributeModMagnitudeCalculationKnowledge : UGameplayModMagnitudeCalculation {
	bool bAllowNonNetAuthorityDependencyRegistration; // 0x38(0x01)
	char pad_41[0x7f]; // 0x41(0x7f)
};

// Class DungeonCrawler.DCAttributeModMagnitudeCalculationResourcefulness
// Size: 0xc0 (Inherited: 0x40)
struct UDCAttributeModMagnitudeCalculationResourcefulness : UGameplayModMagnitudeCalculation {
	bool bAllowNonNetAuthorityDependencyRegistration; // 0x38(0x01)
	char pad_41[0x7f]; // 0x41(0x7f)
};

// Class DungeonCrawler.DCAttributeModMagnitudeCalculationMaxHealth
// Size: 0x100 (Inherited: 0x40)
struct UDCAttributeModMagnitudeCalculationMaxHealth : UGameplayModMagnitudeCalculation {
	bool bAllowNonNetAuthorityDependencyRegistration; // 0x38(0x01)
	char pad_41[0xbf]; // 0x41(0xbf)
};

// Class DungeonCrawler.DCAttributeModMagnitudeCalculationItemArmorRating
// Size: 0xc0 (Inherited: 0x40)
struct UDCAttributeModMagnitudeCalculationItemArmorRating : UGameplayModMagnitudeCalculation {
	bool bAllowNonNetAuthorityDependencyRegistration; // 0x38(0x01)
	char pad_41[0x7f]; // 0x41(0x7f)
};

// Class DungeonCrawler.DCAttributeModMagnitudeCalculationSpellCapacity
// Size: 0x100 (Inherited: 0x40)
struct UDCAttributeModMagnitudeCalculationSpellCapacity : UGameplayModMagnitudeCalculation {
	bool bAllowNonNetAuthorityDependencyRegistration; // 0x38(0x01)
	char pad_41[0xbf]; // 0x41(0xbf)
};

// Class DungeonCrawler.DCAttributeModMagnitudeCalculationMoveSpeed
// Size: 0x1c0 (Inherited: 0x40)
struct UDCAttributeModMagnitudeCalculationMoveSpeed : UGameplayModMagnitudeCalculation {
	bool bAllowNonNetAuthorityDependencyRegistration; // 0x38(0x01)
	char pad_41[0x17f]; // 0x41(0x17f)
};

// Class DungeonCrawler.DCAttributeModMagnitudeCalculationRegularInteractionSpeedBase
// Size: 0xc0 (Inherited: 0x40)
struct UDCAttributeModMagnitudeCalculationRegularInteractionSpeedBase : UGameplayModMagnitudeCalculation {
	bool bAllowNonNetAuthorityDependencyRegistration; // 0x38(0x01)
	char pad_41[0x7f]; // 0x41(0x7f)
};

// Class DungeonCrawler.DCAttributeModMagnitudeCalculationUtilityEffectiveness
// Size: 0x100 (Inherited: 0x40)
struct UDCAttributeModMagnitudeCalculationUtilityEffectiveness : UGameplayModMagnitudeCalculation {
	bool bAllowNonNetAuthorityDependencyRegistration; // 0x38(0x01)
	char pad_41[0xbf]; // 0x41(0xbf)
};

// Class DungeonCrawler.DCAttributeModMagnitudeCalculationWeightLimit
// Size: 0x100 (Inherited: 0x40)
struct UDCAttributeModMagnitudeCalculationWeightLimit : UGameplayModMagnitudeCalculation {
	bool bAllowNonNetAuthorityDependencyRegistration; // 0x38(0x01)
	char pad_41[0xbf]; // 0x41(0xbf)
};

// Class DungeonCrawler.DCAttributeModMagnitudeCalculationPerkBerSerker
// Size: 0xc0 (Inherited: 0x40)
struct UDCAttributeModMagnitudeCalculationPerkBerSerker : UGameplayModMagnitudeCalculation {
	bool bAllowNonNetAuthorityDependencyRegistration; // 0x38(0x01)
	char pad_41[0x7f]; // 0x41(0x7f)
};

// Class DungeonCrawler.DCAttributeModMagnitudeCalculationSkillVictoryStrike
// Size: 0xc0 (Inherited: 0x40)
struct UDCAttributeModMagnitudeCalculationSkillVictoryStrike : UGameplayModMagnitudeCalculation {
	bool bAllowNonNetAuthorityDependencyRegistration; // 0x38(0x01)
	char pad_41[0x7f]; // 0x41(0x7f)
};

// Class DungeonCrawler.DCAttributeSet
// Size: 0x680 (Inherited: 0x30)
struct UDCAttributeSet : UAttributeSet {
	struct FGameplayAttributeData Strength; // 0x30(0x10)
	struct FGameplayAttributeData StrengthBase; // 0x40(0x10)
	struct FGameplayAttributeData StrengthMod; // 0x50(0x10)
	struct FGameplayAttributeData Agility; // 0x60(0x10)
	struct FGameplayAttributeData AgilityBase; // 0x70(0x10)
	struct FGameplayAttributeData AgilityMod; // 0x80(0x10)
	struct FGameplayAttributeData Will; // 0x90(0x10)
	struct FGameplayAttributeData WillBase; // 0xa0(0x10)
	struct FGameplayAttributeData WillMod; // 0xb0(0x10)
	struct FGameplayAttributeData Knowledge; // 0xc0(0x10)
	struct FGameplayAttributeData KnowledgeBase; // 0xd0(0x10)
	struct FGameplayAttributeData KnowledgeMod; // 0xe0(0x10)
	struct FGameplayAttributeData Resourcefulness; // 0xf0(0x10)
	struct FGameplayAttributeData ResourcefulnessBase; // 0x100(0x10)
	struct FGameplayAttributeData ResourcefulnessMod; // 0x110(0x10)
	struct FGameplayAttributeData PhysicalDamageWeaponPrimary; // 0x120(0x10)
	struct FGameplayAttributeData PhysicalDamageWeaponSecondary; // 0x130(0x10)
	struct FGameplayAttributeData PhysicalDamageBase; // 0x140(0x10)
	struct FGameplayAttributeData PhysicalPower; // 0x150(0x10)
	struct FGameplayAttributeData PhysicalDamageMod; // 0x160(0x10)
	struct FGameplayAttributeData PhysicalDamageAdd; // 0x170(0x10)
	struct FGameplayAttributeData PhysicalDamageTrue; // 0x180(0x10)
	struct FGameplayAttributeData PhysicalBackstabPower; // 0x190(0x10)
	struct FGameplayAttributeData PhysicalHeadshotPower; // 0x1a0(0x10)
	struct FGameplayAttributeData PhysicalHeadshotPenetration; // 0x1b0(0x10)
	struct FGameplayAttributeData ArmorPenetration; // 0x1c0(0x10)
	struct FGameplayAttributeData ArmorRating; // 0x1d0(0x10)
	struct FGameplayAttributeData ItemArmorRating; // 0x1e0(0x10)
	struct FGameplayAttributeData ItemArmorRatingMod; // 0x1f0(0x10)
	struct FGameplayAttributeData PhysicalReduction; // 0x200(0x10)
	struct FGameplayAttributeData PhysicalReductionMod; // 0x210(0x10)
	struct FGameplayAttributeData PhysicalAbsoluteReduction; // 0x220(0x10)
	struct FGameplayAttributeData MagicalDamageWeaponPrimary; // 0x230(0x10)
	struct FGameplayAttributeData MagicalDamageWeaponSecondary; // 0x240(0x10)
	struct FGameplayAttributeData MagicalDamageBase; // 0x250(0x10)
	struct FGameplayAttributeData MagicalPower; // 0x260(0x10)
	struct FGameplayAttributeData MagicalDamageMod; // 0x270(0x10)
	struct FGameplayAttributeData MagicalDamageAdd; // 0x280(0x10)
	struct FGameplayAttributeData MagicalDamageTrue; // 0x290(0x10)
	struct FGameplayAttributeData MagicPenetration; // 0x2a0(0x10)
	struct FGameplayAttributeData MagicalFireDamageBase; // 0x2b0(0x10)
	struct FGameplayAttributeData MagicalFireDamageMod; // 0x2c0(0x10)
	struct FGameplayAttributeData MagicalFireDamageAdd; // 0x2d0(0x10)
	struct FGameplayAttributeData MagicalArcaneDamageBase; // 0x2e0(0x10)
	struct FGameplayAttributeData MagicalArcaneDamageMod; // 0x2f0(0x10)
	struct FGameplayAttributeData MagicalArcaneDamageAdd; // 0x300(0x10)
	struct FGameplayAttributeData MagicResistance; // 0x310(0x10)
	struct FGameplayAttributeData MagicalReduction; // 0x320(0x10)
	struct FGameplayAttributeData MagicalReductionMod; // 0x330(0x10)
	struct FGameplayAttributeData MagicalAbsoluteReduction; // 0x340(0x10)
	struct FGameplayAttributeData HeadshotReductionMod; // 0x350(0x10)
	struct FGameplayAttributeData ProjectileReductionMod; // 0x360(0x10)
	struct FGameplayAttributeData ImpactPower; // 0x370(0x10)
	struct FGameplayAttributeData ImpactResistance; // 0x380(0x10)
	struct FGameplayAttributeData ImpactEndurance; // 0x390(0x10)
	struct FGameplayAttributeData MaxImpactEndurance; // 0x3a0(0x10)
	char pad_3B0[0x8]; // 0x3b0(0x08)
	struct FGameplayAttributeData PhysicalHealBase; // 0x3b8(0x10)
	struct FGameplayAttributeData MagicalHealBase; // 0x3c8(0x10)
	struct FGameplayAttributeData RecoverableHealth; // 0x3d8(0x10)
	struct FGameplayAttributeData Health; // 0x3e8(0x10)
	struct FGameplayAttributeData MaxHealth; // 0x3f8(0x10)
	char pad_408[0x8]; // 0x408(0x08)
	struct FGameplayAttributeData MaxHealthBase; // 0x410(0x10)
	struct FGameplayAttributeData MaxHealthMod; // 0x420(0x10)
	struct FGameplayAttributeData MaxHealthAdd; // 0x430(0x10)
	struct FGameplayAttributeData PhysicalShield; // 0x440(0x10)
	struct FGameplayAttributeData MaxPhysicalShield; // 0x450(0x10)
	struct FGameplayAttributeData MagicalShield; // 0x460(0x10)
	struct FGameplayAttributeData MaxMagicalShield; // 0x470(0x10)
	struct FGameplayAttributeData TotalShield; // 0x480(0x10)
	struct FGameplayAttributeData MaxTotalShield; // 0x490(0x10)
	struct FGameplayAttributeData SpellPayload; // 0x4a0(0x10)
	struct FGameplayAttributeData SpellCapacity; // 0x4b0(0x10)
	struct FGameplayAttributeData SpellCapacityBase; // 0x4c0(0x10)
	struct FGameplayAttributeData SpellCapacityMod; // 0x4d0(0x10)
	struct FGameplayAttributeData SpellCapacityAdd; // 0x4e0(0x10)
	struct FGameplayAttributeData MoveSpeed; // 0x4f0(0x10)
	struct FGameplayAttributeData MoveSpeedBase; // 0x500(0x10)
	struct FGameplayAttributeData MoveSpeedMod; // 0x510(0x10)
	struct FGameplayAttributeData MoveSpeedAdd; // 0x520(0x10)
	struct FGameplayAttributeData MoveSpeedArmorPenalty; // 0x530(0x10)
	struct FGameplayAttributeData MoveSpeedArmorPenaltyMod; // 0x540(0x10)
	struct FGameplayAttributeData MoveSpeedWithModifier; // 0x550(0x10)
	struct FGameplayAttributeData ActionSpeed; // 0x560(0x10)
	struct FGameplayAttributeData SpellCastingSpeed; // 0x570(0x10)
	struct FGameplayAttributeData ItemEquipSpeed; // 0x580(0x10)
	struct FGameplayAttributeData RegularInteractionSpeedBase; // 0x590(0x10)
	struct FGameplayAttributeData RegularInteractionSpeed; // 0x5a0(0x10)
	struct FGameplayAttributeData MagicalInteractionSpeed; // 0x5b0(0x10)
	struct FGameplayAttributeData BuffDurationMod; // 0x5c0(0x10)
	struct FGameplayAttributeData DebuffDurationMod; // 0x5d0(0x10)
	struct FGameplayAttributeData UtilityEffectiveness; // 0x5e0(0x10)
	struct FGameplayAttributeData UtilityEffectivenessBase; // 0x5f0(0x10)
	struct FGameplayAttributeData UtilityEffectivenessMod; // 0x600(0x10)
	struct FGameplayAttributeData UtilityEffectivenessAdd; // 0x610(0x10)
	struct FGameplayAttributeData Weight; // 0x620(0x10)
	struct FGameplayAttributeData WeightLimit; // 0x630(0x10)
	struct FGameplayAttributeData WeightLimitBase; // 0x640(0x10)
	struct FGameplayAttributeData WeightLimitMod; // 0x650(0x10)
	struct FGameplayAttributeData WeightLimitAdd; // 0x660(0x10)
	struct FGameplayAttributeData PrestigeItemDrop; // 0x670(0x10)

	void OnRep_WillMod(struct FGameplayAttributeData& OldValue); // Function DungeonCrawler.DCAttributeSet.OnRep_WillMod // (None) // @ game+0xffffbc4bdf830041
};

// Class DungeonCrawler.DCAT_DashToLocation
// Size: 0xb8 (Inherited: 0x80)
struct UDCAT_DashToLocation : UAbilityTask {
	struct FMulticastInlineDelegate OnFinish; // 0x80(0x10)
	char pad_90[0x28]; // 0x90(0x28)

	struct UDCAT_DashToLocation* DashToLocation(struct UGameplayAbility* OwningAbility, struct FVector DestLocation, float AllowedDistance, float Speed, bool Teleport); // Function DungeonCrawler.DCAT_DashToLocation.DashToLocation // (None) // @ game+0xffffbc4cdf830041
};

// Class DungeonCrawler.DCAT_InteractionSkillCheck
// Size: 0xe8 (Inherited: 0x80)
struct UDCAT_InteractionSkillCheck : UAbilityTask {
	struct FMulticastInlineDelegate OnPerfectSucceed; // 0x80(0x10)
	struct FMulticastInlineDelegate OnSucceed; // 0x90(0x10)
	struct FMulticastInlineDelegate OnFailed; // 0xa0(0x10)
	char pad_B0[0x38]; // 0xb0(0x38)

	struct UDCAT_InteractionSkillCheck* InteractionSkillCheck(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, float Duration, float SucceedSectionStartTime, float SucceedSectionEndTime, float PerfectSucceedSectionStartTime, float PerfectSucceedSectionEndTime); // Function DungeonCrawler.DCAT_InteractionSkillCheck.InteractionSkillCheck // (None) // @ game+0xffffbc4ddf830041
};

// Class DungeonCrawler.DCAT_JudgeMusicPlay
// Size: 0xf0 (Inherited: 0x80)
struct UDCAT_JudgeMusicPlay : UAbilityTask {
	struct FMulticastInlineDelegate OnPerfect; // 0x80(0x10)
	struct FMulticastInlineDelegate OnGood; // 0x90(0x10)
	struct FMulticastInlineDelegate OnBad; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnMiss; // 0xb0(0x10)
	struct UInputAction* InputAction; // 0xc0(0x08)
	char pad_C8[0x28]; // 0xc8(0x28)

	struct UDCAT_JudgeMusicPlay* JudgeMusicPlay(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct UInputAction* InInputAction, float Duration, float GoodSectionStartTime, float GoodSectionEndTime, float PerfectSectionStartTime, float PerfectSectionEndTime); // Function DungeonCrawler.DCAT_JudgeMusicPlay.JudgeMusicPlay // (None) // @ game+0xffffbc4edf830041
};

// Class DungeonCrawler.DCAT_MoveWithInputVectorCurve
// Size: 0x150 (Inherited: 0x80)
struct UDCAT_MoveWithInputVectorCurve : UAbilityTask {
	struct FMulticastInlineDelegate OnFinish; // 0x80(0x10)
	char pad_90[0x20]; // 0x90(0x20)
	struct UCurveVector* VelocityVector; // 0xb0(0x08)
	struct FTimeline VelocityTimeline; // 0xb8(0x98)

	struct UDCAT_MoveWithInputVectorCurve* MoveWithInputVectorCurve(struct UGameplayAbility* OwningAbility, struct FVector DestLocation, struct UCurveVector* InVelocityVector, float DistanceTolerance, bool bShouldTeleportWhenFinished); // Function DungeonCrawler.DCAT_MoveWithInputVectorCurve.MoveWithInputVectorCurve // (None) // @ game+0xffffbc51df830041
};

// Class DungeonCrawler.DCAT_OverlapActorsInRadius
// Size: 0xc0 (Inherited: 0x80)
struct UDCAT_OverlapActorsInRadius : UAbilityTask {
	struct FMulticastInlineDelegate OnTargetActorOverlapBegin; // 0x80(0x10)
	struct FMulticastInlineDelegate OnTargetActorOverlapEnd; // 0x90(0x10)
	char pad_A0[0x20]; // 0xa0(0x20)

	struct UDCAT_OverlapActorsInRadius* OverlapActorsInRadius(struct UGameplayAbility* OwningAbility, float Radius, struct FName CollisionProfileName, struct UObject* OverlapTargetClass); // Function DungeonCrawler.DCAT_OverlapActorsInRadius.OverlapActorsInRadius // (None) // @ game+0xffffbc54df830041
};

// Class DungeonCrawler.DCAT_PlayMontageAndWaitForEvent
// Size: 0x140 (Inherited: 0x80)
struct UDCAT_PlayMontageAndWaitForEvent : UAbilityTask {
	struct FMulticastInlineDelegate OnCompleted; // 0x80(0x10)
	struct FMulticastInlineDelegate OnBlendOut; // 0x90(0x10)
	struct FMulticastInlineDelegate OnInterrupted; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnCancelled; // 0xb0(0x10)
	struct FMulticastInlineDelegate EventReceived; // 0xc0(0x10)
	struct UAnimMontage* MontageToPlay; // 0xd0(0x08)
	struct FGameplayTagContainer EventTags; // 0xd8(0x20)
	float Rate; // 0xf8(0x04)
	struct FName StartSection; // 0xfc(0x08)
	float StartTimeSeconds; // 0x104(0x04)
	float AnimRootMotionTranslationScale; // 0x108(0x04)
	bool bStopWhenAbilityEnds; // 0x10c(0x01)
	char pad_10D[0x33]; // 0x10d(0x33)

	struct UDCAT_PlayMontageAndWaitForEvent* PlayMontageAndWaitForEvent(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct UAnimMontage* MontageToPlay, struct FGameplayTagContainer EventTags, float Rate, struct FName StartSection, bool bStopWhenAbilityEnds, float AnimRootMotionTranslationScale, float StartTimeSeconds); // Function DungeonCrawler.DCAT_PlayMontageAndWaitForEvent.PlayMontageAndWaitForEvent // (None) // @ game+0xffffbc55df830041
};

// Class DungeonCrawler.DCAT_RotateToActor
// Size: 0x98 (Inherited: 0x80)
struct UDCAT_RotateToActor : UAbilityTask {
	struct UGameplayAbility* Ability; // 0x68(0x08)
	struct TWeakObjectPtr<struct UAbilitySystemComponent> AbilitySystemComponent; // 0x70(0x08)
	char pad_90[0x8]; // 0x90(0x08)

	struct UDCAT_RotateToActor* RotateToActor(struct UGameplayAbility* OwningAbility, struct AActor* Actor, enum class EHitBoxType HitBox, float Speed, bool WithoutPitch); // Function DungeonCrawler.DCAT_RotateToActor.RotateToActor // (None) // @ game+0xffffbc56df830041
};

// Class DungeonCrawler.DCAT_ServerWaitClientTargetData
// Size: 0x98 (Inherited: 0x80)
struct UDCAT_ServerWaitClientTargetData : UAbilityTask {
	struct FMulticastInlineDelegate ValidData; // 0x80(0x10)
	char pad_90[0x8]; // 0x90(0x08)

	struct UDCAT_ServerWaitClientTargetData* ServerWaitForClientTargetData(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, bool TriggerOnce); // Function DungeonCrawler.DCAT_ServerWaitClientTargetData.ServerWaitForClientTargetData // (None) // @ game+0xffffbc58df830041
};

// Class DungeonCrawler.DCAT_SpawnProjectile
// Size: 0x110 (Inherited: 0x80)
struct UDCAT_SpawnProjectile : UAbilityTask {
	struct FMulticastInlineDelegate OnSuccess; // 0x80(0x10)
	char pad_90[0x80]; // 0x90(0x80)

	struct UDCAT_SpawnProjectile* SpawnProjectile(struct UGameplayAbility* OwningAbility, struct UObject* SpawnClass, struct FTransform SpawnTransform, float FirePower); // Function DungeonCrawler.DCAT_SpawnProjectile.SpawnProjectile // (None) // @ game+0xffffbc59df830041
};

// Class DungeonCrawler.DCAT_TargetActorRadius
// Size: 0xa0 (Inherited: 0x80)
struct UDCAT_TargetActorRadius : UAbilityTask {
	struct FMulticastInlineDelegate OnTargetActorOverlap; // 0x80(0x10)
	char pad_90[0x10]; // 0x90(0x10)

	struct UDCAT_TargetActorRadius* TargetActorRadius(struct UGameplayAbility* OwningAbility, float Radius, enum class ECollisionChannel CollisionChannel, struct UObject* TargetingClass); // Function DungeonCrawler.DCAT_TargetActorRadius.TargetActorRadius // (None) // @ game+0xffffbc5adf830041
};

// Class DungeonCrawler.DCAT_WaitAimDirChangedFromLoc
// Size: 0xc0 (Inherited: 0x80)
struct UDCAT_WaitAimDirChangedFromLoc : UAbilityTask {
	struct FMulticastInlineDelegate OnDirectionChanged; // 0x80(0x10)
	char pad_90[0x30]; // 0x90(0x30)

	struct UDCAT_WaitAimDirChangedFromLoc* WaitAimDirectionChangedFromLocation(struct UGameplayAbility* OwningAbility, struct FVector InitialAimTargetLocation); // Function DungeonCrawler.DCAT_WaitAimDirChangedFromLoc.WaitAimDirectionChangedFromLocation // (None) // @ game+0xffffbc5bdf830041
};

// Class DungeonCrawler.DCAT_WaitAimDirectionChanged
// Size: 0xa8 (Inherited: 0x80)
struct UDCAT_WaitAimDirectionChanged : UAbilityTask {
	struct FMulticastInlineDelegate OnDirectionChanged; // 0x80(0x10)
	char pad_90[0x18]; // 0x90(0x18)

	struct UDCAT_WaitAimDirectionChanged* WaitAimDirectionChanged(struct UGameplayAbility* OwningAbility); // Function DungeonCrawler.DCAT_WaitAimDirectionChanged.WaitAimDirectionChanged // (None) // @ game+0xffffbc5cdf830041
};

// Class DungeonCrawler.DCAT_WaitAttributeChangeByExecution
// Size: 0xb0 (Inherited: 0x80)
struct UDCAT_WaitAttributeChangeByExecution : UAbilityTask {
	struct FMulticastInlineDelegate OnChange; // 0x80(0x10)
	char pad_90[0x18]; // 0x90(0x18)
	struct UAbilitySystemComponent* ExternalOwner; // 0xa8(0x08)

	struct UDCAT_WaitAttributeChangeByExecution* WaitForAttributesChange(struct UGameplayAbility* OwningAbility, struct TArray<struct FGameplayAttribute> Attributes, bool TriggerOnce, struct AActor* OptionalExternalOwner); // Function DungeonCrawler.DCAT_WaitAttributeChangeByExecution.WaitForAttributesChange // (None) // @ game+0xffffbc5edf830041
};

// Class DungeonCrawler.DCAT_WaitDelayPausable
// Size: 0xb0 (Inherited: 0x80)
struct UDCAT_WaitDelayPausable : UAbilityTask {
	struct FMulticastInlineDelegate OnFinish; // 0x80(0x10)
	struct FMulticastInlineDelegate OnCancelled; // 0x90(0x10)
	char pad_A0[0x10]; // 0xa0(0x10)

	struct UDCAT_WaitDelayPausable* WaitDelay(struct UGameplayAbility* OwningAbility, float Duration); // Function DungeonCrawler.DCAT_WaitDelayPausable.WaitDelay // (None) // @ game+0xffffbc63df830041
};

// Class DungeonCrawler.DCAT_WaitDelayRestartable
// Size: 0xa0 (Inherited: 0x80)
struct UDCAT_WaitDelayRestartable : UAbilityTask {
	struct FMulticastInlineDelegate OnFinish; // 0x80(0x10)
	char pad_90[0x10]; // 0x90(0x10)

	struct UDCAT_WaitDelayRestartable* WaitDelay(struct UGameplayAbility* OwningAbility, float Time); // Function DungeonCrawler.DCAT_WaitDelayRestartable.WaitDelay // (None) // @ game+0xffffbc65df830041
};

// Class DungeonCrawler.DCAT_WaitDistChangeFromActor
// Size: 0x110 (Inherited: 0x80)
struct UDCAT_WaitDistChangeFromActor : UAbilityTask {
	struct FMulticastInlineDelegate OnDistanceChange; // 0x80(0x10)
	char pad_90[0x80]; // 0x90(0x80)

	struct UDCAT_WaitDistChangeFromActor* WaitDistanceChange(struct UGameplayAbility* OwningAbility, struct AActor* TargetActor, float MaximumDistance, enum class ECollisionChannel CollisionChannel); // Function DungeonCrawler.DCAT_WaitDistChangeFromActor.WaitDistanceChange // (None) // @ game+0xffffbc66df830041
};

// Class DungeonCrawler.DCAT_WaitDistChangeFromLocation
// Size: 0xb0 (Inherited: 0x80)
struct UDCAT_WaitDistChangeFromLocation : UAbilityTask {
	struct FMulticastInlineDelegate OnDistanceChange; // 0x80(0x10)
	char pad_90[0x20]; // 0x90(0x20)

	struct UDCAT_WaitDistChangeFromLocation* WaitDistanceChange(struct UGameplayAbility* OwningAbility, struct FVector TargetLocation, float MaximumDistance); // Function DungeonCrawler.DCAT_WaitDistChangeFromLocation.WaitDistanceChange // (None) // @ game+0xffffbc67df830041
};

// Class DungeonCrawler.DCAT_WaitDistChangeFromView
// Size: 0x140 (Inherited: 0x80)
struct UDCAT_WaitDistChangeFromView : UAbilityTask {
	struct FMulticastInlineDelegate OnDistanceChange; // 0x80(0x10)
	struct FPrimaryAssetId InteractionAdditionalSphereRadiusConstant; // 0x90(0x10)
	char pad_A0[0xa0]; // 0xa0(0xa0)

	struct UDCAT_WaitDistChangeFromView* WaitDistanceChange(struct UGameplayAbility* OwningAbility, struct AActor* TargetActor, struct FVector TargetLocation, float MaximumDistance, float CollisionRadius, enum class ECollisionChannel CollisionChannel); // Function DungeonCrawler.DCAT_WaitDistChangeFromView.WaitDistanceChange // (None) // @ game+0xffffbc68df830041
};

// Class DungeonCrawler.DCAT_WaitForCharacterUnCrouch
// Size: 0x98 (Inherited: 0x80)
struct UDCAT_WaitForCharacterUnCrouch : UAbilityTask {
	struct FMulticastInlineDelegate OnUnCrouch; // 0x80(0x10)
	struct UCharacterMovementComponent* CachedMovementComponent; // 0x90(0x08)

	struct UDCAT_WaitForCharacterUnCrouch* WaitForCharacterUnCrouch(struct UGameplayAbility* OwningAbility); // Function DungeonCrawler.DCAT_WaitForCharacterUnCrouch.WaitForCharacterUnCrouch // (None) // @ game+0xffffbc69df830041
};

// Class DungeonCrawler.DCAT_WaitForGameplayEvents
// Size: 0xb8 (Inherited: 0x80)
struct UDCAT_WaitForGameplayEvents : UAbilityTask {
	struct FMulticastInlineDelegate EventReceived; // 0x80(0x10)
	struct FGameplayTagContainer EventTags; // 0x90(0x20)
	char pad_B0[0x8]; // 0xb0(0x08)

	struct UDCAT_WaitForGameplayEvents* WaitForGameplayEvents(struct UGameplayAbility* OwningAbility, struct FGameplayTagContainer InEventTags); // Function DungeonCrawler.DCAT_WaitForGameplayEvents.WaitForGameplayEvents // (None) // @ game+0xffffbc6adf830041
};

// Class DungeonCrawler.DCAT_WaitForInputAction
// Size: 0xc8 (Inherited: 0x80)
struct UDCAT_WaitForInputAction : UAbilityTask {
	struct FMulticastInlineDelegate InputActionStarted; // 0x80(0x10)
	struct FMulticastInlineDelegate InputActionCompleted; // 0x90(0x10)
	struct UInputAction* InputAction; // 0xa0(0x08)
	char pad_A8[0x20]; // 0xa8(0x20)

	struct UDCAT_WaitForInputAction* WaitForInputAction(struct UGameplayAbility* OwningAbility, struct UInputAction* InInputAction, bool OnlyTriggerOnce); // Function DungeonCrawler.DCAT_WaitForInputAction.WaitForInputAction // (None) // @ game+0xffffbc6bdf830041
};

// Class DungeonCrawler.DCAT_WaitGameplayAbilityActivateOrEnd
// Size: 0x160 (Inherited: 0x80)
struct UDCAT_WaitGameplayAbilityActivateOrEnd : UAbilityTask {
	char pad_80[0xa0]; // 0x80(0xa0)
	struct FMulticastInlineDelegate OnAbilityActivated; // 0x120(0x10)
	struct FMulticastInlineDelegate OnAbilityEnded; // 0x130(0x10)
	struct UAbilitySystemComponent* OptionalExternalTarget; // 0x140(0x08)
	char pad_148[0x18]; // 0x148(0x18)

	struct UDCAT_WaitGameplayAbilityActivateOrEnd* WaitForAbilityActivateOrEndWithTagRequirements(struct UGameplayAbility* OwningAbility, struct FGameplayTagRequirements TagRequirements, struct AActor* InOptionalExternalTarget, bool TriggerOnce); // Function DungeonCrawler.DCAT_WaitGameplayAbilityActivateOrEnd.WaitForAbilityActivateOrEndWithTagRequirements // (None) // @ game+0xffffbcb2df830041
};

// Class DungeonCrawler.DCAT_WaitGameplayEffectAdd
// Size: 0xa0 (Inherited: 0x80)
struct UDCAT_WaitGameplayEffectAdd : UAbilityTask {
	struct FMulticastInlineDelegate OnApplied; // 0x80(0x10)
	char pad_90[0x10]; // 0x90(0x10)

	struct UDCAT_WaitGameplayEffectAdd* WaitGameplayEffectAdded(struct UGameplayAbility* OwningAbility, bool TriggerOnce); // Function DungeonCrawler.DCAT_WaitGameplayEffectAdd.WaitGameplayEffectAdded // (None) // @ game+0xffffbc72df830041
};

// Class DungeonCrawler.DCAT_WaitGenericGameplayTagEvent
// Size: 0xc0 (Inherited: 0x80)
struct UDCAT_WaitGenericGameplayTagEvent : UAbilityTask {
	struct FMulticastInlineDelegate Added; // 0x80(0x10)
	struct FMulticastInlineDelegate Removed; // 0x90(0x10)
	char pad_A0[0x8]; // 0xa0(0x08)
	struct UAbilitySystemComponent* OptionalExternalTarget; // 0xa8(0x08)
	char pad_B0[0x10]; // 0xb0(0x10)

	struct UDCAT_WaitGenericGameplayTagEvent* WaitGenericGameplayTagEvent(struct UGameplayAbility* OwningAbility, struct AActor* InOptionalExternalTarget); // Function DungeonCrawler.DCAT_WaitGenericGameplayTagEvent.WaitGenericGameplayTagEvent // (None) // @ game+0xffffbc73df830041
};

// Class DungeonCrawler.DCAT_WaitInteractableTarget
// Size: 0xa8 (Inherited: 0x80)
struct UDCAT_WaitInteractableTarget : UAbilityTask {
	struct FMulticastInlineDelegate FoundNewInteractableTarget; // 0x80(0x10)
	struct FMulticastInlineDelegate LostInteractableTarget; // 0x90(0x10)
	struct ADCGATA_LineTraceInteractable* InteractableTargetActor; // 0xa0(0x08)

	struct UDCAT_WaitInteractableTarget* WaitInteractableTarget(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct ADCGATA_LineTraceInteractable* InTargetActor); // Function DungeonCrawler.DCAT_WaitInteractableTarget.WaitInteractableTarget // (None) // @ game+0xffffbc79df830041
};

// Class DungeonCrawler.DCAT_WaitSocketBlockedStateChange
// Size: 0xa8 (Inherited: 0x80)
struct UDCAT_WaitSocketBlockedStateChange : UAbilityTask {
	struct FMulticastInlineDelegate SocketSightBlocked; // 0x80(0x10)
	struct FMulticastInlineDelegate SocketSightUnblocked; // 0x90(0x10)
	struct ADCGATA_AimTraceToSocket* AimTraceActor; // 0xa0(0x08)

	struct UDCAT_WaitSocketBlockedStateChange* WaitSocketBlockedStateChange(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct ADCGATA_AimTraceToSocket* InTargetActor); // Function DungeonCrawler.DCAT_WaitSocketBlockedStateChange.WaitSocketBlockedStateChange // (None) // @ game+0xffffbc7fdf830041
};

// Class DungeonCrawler.DCAT_WaitTargetData
// Size: 0xc0 (Inherited: 0xc0)
struct UDCAT_WaitTargetData : UAbilityTask_WaitTargetData {
	struct FMulticastInlineDelegate ValidData; // 0x80(0x10)
	struct FMulticastInlineDelegate Cancelled; // 0x90(0x10)
	struct AGameplayAbilityTargetActor* TargetClass; // 0xa0(0x08)
	struct AGameplayAbilityTargetActor* TargetActor; // 0xa8(0x08)

	struct UDCAT_WaitTargetData* DCWaitTargetData(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, enum class EGameplayTargetingConfirmation ConfirmationType, struct AGameplayAbilityTargetActor* InTargetActor); // Function DungeonCrawler.DCAT_WaitTargetData.DCWaitTargetData // (None) // @ game+0xffffbc80df830041
};

// Class DungeonCrawler.DCAT_WaitTargetGameplayTagEvent
// Size: 0xe0 (Inherited: 0x80)
struct UDCAT_WaitTargetGameplayTagEvent : UAbilityTask {
	struct FMulticastInlineDelegate Added; // 0x80(0x10)
	struct FMulticastInlineDelegate OnCountChanged; // 0x90(0x10)
	struct FMulticastInlineDelegate Removed; // 0xa0(0x10)
	char pad_B0[0x10]; // 0xb0(0x10)
	struct UAbilitySystemComponent* OptionalExternalTarget; // 0xc0(0x08)
	char pad_C8[0x18]; // 0xc8(0x18)

	struct UDCAT_WaitTargetGameplayTagEvent* WaitTargetGameplayTagEvent(struct UGameplayAbility* OwningAbility, struct FGameplayTag InTargetTag, struct AActor* InOptionalExternalTarget); // Function DungeonCrawler.DCAT_WaitTargetGameplayTagEvent.WaitTargetGameplayTagEvent // (None) // @ game+0xffffbc81df830041
};

// Class DungeonCrawler.DCAT_WaitVelocityChange
// Size: 0xa0 (Inherited: 0x80)
struct UDCAT_WaitVelocityChange : UAbilityTask {
	struct FMulticastInlineDelegate OnVelocityChange; // 0x80(0x10)
	struct UMovementComponent* CachedMovementComponent; // 0x90(0x08)
	char pad_98[0x8]; // 0x98(0x08)

	struct UDCAT_WaitVelocityChange* WaitVelocityChange(struct UGameplayAbility* OwningAbility, float MinimumMagnitude); // Function DungeonCrawler.DCAT_WaitVelocityChange.WaitVelocityChange // (None) // @ game+0xffffbc82df830041
};

// Class DungeonCrawler.DCBagSlotWidget
// Size: 0x288 (Inherited: 0x278)
struct UDCBagSlotWidget : UUserWidget {
	bool bOccupied; // 0x278(0x01)
	bool bCanEquip; // 0x279(0x01)
	enum class EDCItemDropPreview ItemDropPreview; // 0x27a(0x01)
	char pad_27B[0x5]; // 0x27b(0x05)
	struct USizeBox* SlotSizeBox; // 0x280(0x08)
};

// Class DungeonCrawler.DCItemWidgetBase
// Size: 0x4c8 (Inherited: 0x368)
struct UDCItemWidgetBase : UDCControlWidgetBase {
	char pad_368[0x30]; // 0x368(0x30)
	struct FDCItemInfo ItemInfo; // 0x398(0x118)
	int32_t Count; // 0x4b0(0x04)
	bool bIsLocked; // 0x4b4(0x01)
	char pad_4B5[0x3]; // 0x4b5(0x03)
	struct UDCItemDataAsset* DataAsset; // 0x4b8(0x08)
	bool bSet; // 0x4c0(0x01)
	char pad_4C1[0x7]; // 0x4c1(0x07)

	bool IsSet(); // Function DungeonCrawler.DCItemWidgetBase.IsSet // (None) // @ game+0xffffbc83df830041
};

// Class DungeonCrawler.DCItemCommonWidget
// Size: 0x4f0 (Inherited: 0x4c8)
struct UDCItemCommonWidget : UDCItemWidgetBase {
	struct UDCItemTooltipWidget* ItemTooltipWidgetClass; // 0x4c8(0x08)
	struct UUserWidget* InvalidItemTooltipWidgetClass; // 0x4d0(0x08)
	struct UDCItemDragVisualWidget* ItemDragVisualWidgetClass; // 0x4d8(0x08)
	bool bIsDragging; // 0x4e0(0x01)
	char pad_4E1[0x7]; // 0x4e1(0x07)
	struct UImage* ItemImage; // 0x4e8(0x08)

	void OnDragDropFinished(struct UDragDropOperation* Operation); // Function DungeonCrawler.DCItemCommonWidget.OnDragDropFinished // (None) // @ game+0xffffbc85df830041
};

// Class DungeonCrawler.DCBagItemWidget
// Size: 0x4f8 (Inherited: 0x4f0)
struct UDCBagItemWidget : UDCItemCommonWidget {
	struct USizeBox* ItemSizeBox; // 0x4f0(0x08)

	bool IsGold(); // Function DungeonCrawler.DCBagItemWidget.IsGold // (None) // @ game+0xffffbc86df830041
};

// Class DungeonCrawler.DCInventoryWidgetBase
// Size: 0x2c0 (Inherited: 0x278)
struct UDCInventoryWidgetBase : UUserWidget {
	char pad_278[0x30]; // 0x278(0x30)
	bool bReadOnly; // 0x2a8(0x01)
	char pad_2A9[0x7]; // 0x2a9(0x07)
	struct TArray<struct UDCInventoryWidgetBase*> ChildInventoryWidgets; // 0x2b0(0x10)

	void OnWidgetVisibilityChanged(enum class ESlateVisibility Invisibility); // Function DungeonCrawler.DCInventoryWidgetBase.OnWidgetVisibilityChanged // (None) // @ game+0xffffbc89df830041
};

// Class DungeonCrawler.DCBagWidget
// Size: 0x3b0 (Inherited: 0x2c0)
struct UDCBagWidget : UDCInventoryWidgetBase {
	struct UDCBagSlotWidget* SlotWidgetClass; // 0x2c0(0x08)
	struct UDCBagItemWidget* ItemWidgetClass; // 0x2c8(0x08)
	struct UDCInputNumberWidget* SplitWidgetClass; // 0x2d0(0x08)
	struct UInputAction* SplitInputAction; // 0x2d8(0x08)
	struct UVerticalBox* SlotRowsVerticalBox; // 0x2e0(0x08)
	struct UCanvasPanel* ItemAreaCanvas; // 0x2e8(0x08)
	struct UDCBoxInventory* Inventory; // 0x2f0(0x08)
	struct UDCInputNumberWidget* SplitWidget; // 0x2f8(0x08)
	struct TMap<struct FDCItemId, struct UDCBagItemWidget*> ItemWidgets; // 0x300(0x50)
	char pad_350[0x60]; // 0x350(0x60)

	void OnItemsUpdated(); // Function DungeonCrawler.DCBagWidget.OnItemsUpdated // (None) // @ game+0xffffbc90df830041
};

// Class DungeonCrawler.DCInventoryBase
// Size: 0x1c0 (Inherited: 0x28)
struct UDCInventoryBase : UObject {
	char pad_28[0x18]; // 0x28(0x18)
	enum class EDCInventoryId InventoryId; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct TArray<int32_t> Indexes; // 0x48(0x10)
	struct TMap<int32_t, struct FDCItemId> KeyByIndex; // 0x58(0x50)
	struct TMap<struct FDCItemId, struct FDCItemInfo> Values; // 0xa8(0x50)
	struct ACharacter* OwnerCharacter; // 0xf8(0x08)
	char pad_100[0x50]; // 0x100(0x50)
	struct FDCInventoryData InitData; // 0x150(0x20)
	struct TMap<enum class EDCInventoryValidatorType, struct UDCInventoryValidatorBase*> Validators; // 0x170(0x50)

	void OnRep_InitData(struct FDCInventoryData& OldInitData); // Function DungeonCrawler.DCInventoryBase.OnRep_InitData // (None) // @ game+0xffffbc93df830041
};

// Class DungeonCrawler.DCBoxInventory
// Size: 0x1c8 (Inherited: 0x1c0)
struct UDCBoxInventory : UDCInventoryBase {
	struct FIntPoint BoxSize; // 0x1c0(0x08)
};

// Class DungeonCrawler.DCChannelChatWidget
// Size: 0x468 (Inherited: 0x408)
struct UDCChannelChatWidget : UChatSetWidgetBase {
	char pad_408[0x10]; // 0x408(0x10)
	struct FText Title; // 0x418(0x18)
	struct FString Nickname; // 0x430(0x10)
	struct TArray<enum class EContextOptionType> ContextOptions; // 0x440(0x10)
	char pad_450[0x18]; // 0x450(0x18)

	void OnNickname(); // Function DungeonCrawler.DCChannelChatWidget.OnNickname // (None) // @ game+0xffffbc94df830041
};

// Class DungeonCrawler.DCChannelPlayerListEntryWidgetData
// Size: 0x90 (Inherited: 0x28)
struct UDCChannelPlayerListEntryWidgetData : UObject {
	struct FDCChannelPlayerWidgetInfo Info; // 0x28(0x68)
};

// Class DungeonCrawler.LobbyUserSlotBase
// Size: 0x388 (Inherited: 0x320)
struct ULobbyUserSlotBase : UDCCommonButtonBase {
	struct FNickname Nickname; // 0x320(0x28)
	struct FText LevelText; // 0x348(0x18)
	struct FText ClassNameText; // 0x360(0x18)
	struct UTexture2D* ClassIconImage; // 0x378(0x08)
	struct UTexture2D* ClassPortraitImage; // 0x380(0x08)

	void SetNicknameBlueprint(struct FNickname InNickName); // Function DungeonCrawler.LobbyUserSlotBase.SetNicknameBlueprint // (None) // @ game+0xffffbc99df830041
};

// Class DungeonCrawler.DCChannelPlayerListEntryWidget
// Size: 0x400 (Inherited: 0x388)
struct UDCChannelPlayerListEntryWidget : ULobbyUserSlotBase {
	char pad_388[0x10]; // 0x388(0x10)
	struct FDCChannelPlayerWidgetInfo Info; // 0x398(0x68)

	void OnRightClicked(); // Function DungeonCrawler.DCChannelPlayerListEntryWidget.OnRightClicked // (None) // @ game+0xffffbc9adf830041
};

// Class DungeonCrawler.DCChannelPlayerListWidget
// Size: 0x2f8 (Inherited: 0x278)
struct UDCChannelPlayerListWidget : UUserWidget {
	struct UVerticalBox* LocalPlayersVerticalBox; // 0x278(0x08)
	struct UDCChannelPlayerListEntryWidget* ChannelPlayerListEntryWidgetClass; // 0x280(0x08)
	struct UListView* PlayerListView; // 0x288(0x08)
	struct UEditableTextBox* SearchTextBox; // 0x290(0x08)
	struct TMap<struct FDCAccountId, struct UDCChannelPlayerListEntryWidgetData*> ListItems; // 0x298(0x50)
	char pad_2E8[0x10]; // 0x2e8(0x10)

	void OnSearchTextChanged(struct FText& Keyword); // Function DungeonCrawler.DCChannelPlayerListWidget.OnSearchTextChanged // (None) // @ game+0xffffbc9bdf830041
};

// Class DungeonCrawler.DCCharacterAnimInstanceBase
// Size: 0x470 (Inherited: 0x400)
struct UDCCharacterAnimInstanceBase : UDCAnimInstanceBase {
	float NativeYaw; // 0x400(0x04)
	float NativePitch; // 0x404(0x04)
	bool bIsFlying; // 0x408(0x01)
	bool bIsFalling; // 0x409(0x01)
	bool bIsCrouching; // 0x40a(0x01)
	bool bIsDead; // 0x40b(0x01)
	char pad_40C[0x4]; // 0x40c(0x04)
	struct FVector HitDirection; // 0x410(0x18)
	bool bShouldTransitionToHit; // 0x428(0x01)
	bool bShouldTransitionToHitReactionFlipFlop; // 0x429(0x01)
	char pad_42A[0x2]; // 0x42a(0x02)
	struct FName HitReactionStateMachineName; // 0x42c(0x08)
	struct FName HitReactionStateName; // 0x434(0x08)
	struct FName HitReactionFlipFlopStateName; // 0x43c(0x08)
	char pad_444[0x2c]; // 0x444(0x2c)
};

// Class DungeonCrawler.DCCharacterBase
// Size: 0x880 (Inherited: 0x620)
struct ADCCharacterBase : ACharacter {
	char pad_620[0x70]; // 0x620(0x70)
	struct UBaseObject* BaseObject; // 0x690(0x08)
	char pad_698[0x18]; // 0x698(0x18)
	struct UAbilitySystemComponent* AbilitySystemComponent; // 0x6b0(0x08)
	char pad_6B8[0x8]; // 0x6b8(0x08)
	struct FGenericTeamId GenericTeamId; // 0x6c0(0x01)
	char pad_6C1[0x7]; // 0x6c1(0x07)
	struct UAttackInputManagerComponent* AttackInputManager; // 0x6c8(0x08)
	struct USkillComponent* SkillComponent; // 0x6d0(0x08)
	char pad_6D8[0x38]; // 0x6d8(0x38)
	struct FString AccountId; // 0x710(0x10)
	struct UAccountLink* AccountLink; // 0x720(0x08)
	struct FAccountDataReplication AccountDataReplication; // 0x728(0x78)
	bool bIsFirstPersonPerspective; // 0x7a0(0x01)
	bool bIsDead; // 0x7a1(0x01)
	char pad_7A2[0x6]; // 0x7a2(0x06)
	struct TArray<struct TWeakObjectPtr<struct ADCAoeBase>> AoeArray; // 0x7a8(0x10)
	struct FNickname NickNameCached; // 0x7b8(0x28)
	char pad_7E0[0x10]; // 0x7e0(0x10)
	char RemoteViewYaw; // 0x7f0(0x01)
	char pad_7F1[0x67]; // 0x7f1(0x67)
	struct FGameplayTagContainer AimRotationLockTags; // 0x858(0x20)
	struct UDCInventoryComponent* InventoryComponentV2; // 0x878(0x08)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCCharacterBase.UnbindMsgAll // (None) // @ game+0xffffbcbcdf830041
};

// Class DungeonCrawler.DCCharacterLobbyCapture
// Size: 0x820 (Inherited: 0x620)
struct ADCCharacterLobbyCapture : ACharacter {
	char pad_620[0x58]; // 0x620(0x58)
	struct UBaseObject* BaseObject; // 0x678(0x08)
	struct USkeletalMeshComponent* PartHead; // 0x680(0x08)
	struct USkeletalMeshComponent* PartHelmet; // 0x688(0x08)
	struct USkeletalMeshComponent* PartAnimObject; // 0x690(0x08)
	struct USkeletalMeshComponent* PartGloves; // 0x698(0x08)
	struct USkeletalMeshComponent* PartChest; // 0x6a0(0x08)
	struct USkeletalMeshComponent* PartPants; // 0x6a8(0x08)
	struct USkeletalMeshComponent* PartBoots; // 0x6b0(0x08)
	struct USkeletalMeshComponent* PartBack; // 0x6b8(0x08)
	struct UAbilitySystemComponent* AbilitySystemComponent; // 0x6c0(0x08)
	struct FGameplayAbilitySpecHandle LobbyPoseAbilitySpecHandle; // 0x6c8(0x04)
	char pad_6CC[0x4]; // 0x6cc(0x04)
	struct UDCPerkDataComponent* PerkDataComponent; // 0x6d0(0x08)
	enum class EWidgetPartyUserLocate PartyUserLocate; // 0x6d8(0x01)
	char pad_6D9[0x7]; // 0x6d9(0x07)
	struct UDCCharacterDataComponent* DataComponent; // 0x6e0(0x08)
	struct UDCCharacterPartsComponent* PartsComponent; // 0x6e8(0x08)
	struct UDCInventoryComponent* InventoryComponent; // 0x6f0(0x08)
	char pad_6F8[0xa0]; // 0x6f8(0xa0)
	struct UAccountLink* AccountLink; // 0x798(0x08)
	struct TArray<struct FPrimaryAssetId> OwnedPerkIdArray; // 0x7a0(0x10)
	struct TMap<int64_t, struct AActor*> ContainingActorMap; // 0x7b0(0x50)
	char pad_800[0x20]; // 0x800(0x20)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCCharacterLobbyCapture.UnbindMsgAll // (None) // @ game+0xffffbcc4df830041
};

// Class DungeonCrawler.DCCharacterLobbyCaptureMine
// Size: 0x820 (Inherited: 0x820)
struct ADCCharacterLobbyCaptureMine : ADCCharacterLobbyCapture {
	struct UBaseObject* BaseObject; // 0x678(0x08)
	struct USkeletalMeshComponent* PartHead; // 0x680(0x08)
	struct USkeletalMeshComponent* PartHelmet; // 0x688(0x08)
	struct USkeletalMeshComponent* PartAnimObject; // 0x690(0x08)
	struct USkeletalMeshComponent* PartGloves; // 0x698(0x08)
	struct USkeletalMeshComponent* PartChest; // 0x6a0(0x08)
	struct USkeletalMeshComponent* PartPants; // 0x6a8(0x08)
	struct USkeletalMeshComponent* PartBoots; // 0x6b0(0x08)
	struct USkeletalMeshComponent* PartBack; // 0x6b8(0x08)
	struct UAbilitySystemComponent* AbilitySystemComponent; // 0x6c0(0x08)
	struct FGameplayAbilitySpecHandle LobbyPoseAbilitySpecHandle; // 0x6c8(0x04)
	struct UDCPerkDataComponent* PerkDataComponent; // 0x6d0(0x08)
	enum class EWidgetPartyUserLocate PartyUserLocate; // 0x6d8(0x01)
	struct UDCCharacterDataComponent* DataComponent; // 0x6e0(0x08)
	struct UDCCharacterPartsComponent* PartsComponent; // 0x6e8(0x08)
	struct UDCInventoryComponent* InventoryComponent; // 0x6f0(0x08)
	struct UAccountLink* AccountLink; // 0x798(0x08)
	struct TArray<struct FPrimaryAssetId> OwnedPerkIdArray; // 0x7a0(0x10)
	struct TMap<int64_t, struct AActor*> ContainingActorMap; // 0x7b0(0x50)
};

// Class DungeonCrawler.DCCharacterMovementComponent
// Size: 0xf10 (Inherited: 0xf00)
struct UDCCharacterMovementComponent : UCharacterMovementComponent {
	char pad_F00[0x8]; // 0xf00(0x08)
	struct UCannotMoveGameplayTagData* CannotMoveGameplayTagData; // 0xf08(0x08)
};

// Class DungeonCrawler.DCCharacterPartsArtData
// Size: 0xd8 (Inherited: 0x38)
struct UDCCharacterPartsArtData : UDCDataAssetBase {
	struct TMap<struct FGameplayTag, struct USkeletalMesh*> BodyParts; // 0x38(0x50)
	struct TMap<struct FGameplayTag, struct USkeletalMesh*> DefaultParts; // 0x88(0x50)
};

// Class DungeonCrawler.DCCharacterProduction
// Size: 0x670 (Inherited: 0x620)
struct ADCCharacterProduction : ACharacter {
	struct USkeletalMeshComponent* PartHead; // 0x618(0x08)
	struct USkeletalMeshComponent* PartHelmet; // 0x620(0x08)
	struct USkeletalMeshComponent* PartGloves; // 0x628(0x08)
	struct USkeletalMeshComponent* PartChest; // 0x630(0x08)
	struct USkeletalMeshComponent* PartPants; // 0x638(0x08)
	struct USkeletalMeshComponent* PartBoots; // 0x640(0x08)
	struct USkeletalMeshComponent* PartBack; // 0x648(0x08)
	struct TArray<struct FString> ItemAssetIDList; // 0x650(0x10)
	struct USkeletalMesh* SkelMesh; // 0x660(0x08)

	void OnRep_ItemDataList(struct TArray<struct FString>& OldItemAssetIDList); // Function DungeonCrawler.DCCharacterProduction.OnRep_ItemDataList // (None) // @ game+0xffffbcc7df830041
};

// Class DungeonCrawler.DCCharacterSelectCapture
// Size: 0x820 (Inherited: 0x820)
struct ADCCharacterSelectCapture : ADCCharacterLobbyCapture {
	bool bIsEmpty; // 0x818(0x01)
};

// Class DungeonCrawler.DCCharacterSkinArtData
// Size: 0xe0 (Inherited: 0xd8)
struct UDCCharacterSkinArtData : UDCCharacterPartsArtData {
	struct UTexture2D* CharacterSkinIconTexture; // 0xd8(0x08)
};

// Class DungeonCrawler.DCCharacterSkinComponent
// Size: 0xc8 (Inherited: 0xa0)
struct UDCCharacterSkinComponent : UActorComponent {
	struct UDCCharacterSkinDataAsset* Data; // 0xa0(0x08)
	struct TArray<struct FGameplayAbilitySpecHandle> OwnerGameplayAbilitySpecHandles; // 0xa8(0x10)
	struct TArray<struct FActiveGameplayEffectHandle> OwnerGameplayEffectHandles; // 0xb8(0x10)

	void SetDataForDebug_Server(struct UDCCharacterSkinDataAsset* InData); // Function DungeonCrawler.DCCharacterSkinComponent.SetDataForDebug_Server // (None) // @ game+0xffffbcc9df830041
};

// Class DungeonCrawler.DCCharacterSkinDataAsset
// Size: 0xf8 (Inherited: 0x38)
struct UDCCharacterSkinDataAsset : UDCDataAsset {
	struct FText Name; // 0x38(0x18)
	struct TSoftObjectPtr<UDescData> Desc; // 0x50(0x30)
	struct FText FlavorText; // 0x80(0x18)
	struct TSoftObjectPtr<UDCCharacterSkinArtData> Art; // 0x98(0x30)
	struct TArray<enum class EDCCharacterClass> TargetCharacterClasses; // 0xc8(0x10)
	struct TArray<struct TSoftObjectPtr<UDCGameplayAbilityDataAsset>> Abilities; // 0xd8(0x10)
	struct TArray<struct TSoftObjectPtr<UDCGameplayEffectDataAsset>> Effects; // 0xe8(0x10)
};

// Class DungeonCrawler.DCCharacterSkinListEntryWidgetData
// Size: 0x38 (Inherited: 0x28)
struct UDCCharacterSkinListEntryWidgetData : UObject {
	struct FDCCharacterSkinInfo CharacterSkinInfo; // 0x28(0x10)
};

// Class DungeonCrawler.DCCharacterSkinWidget
// Size: 0x3f0 (Inherited: 0x368)
struct UDCCharacterSkinWidget : UDCControlWidgetBase {
	char pad_368[0x18]; // 0x368(0x18)
	struct FText CharacterSkinName; // 0x380(0x18)
	struct TArray<struct FText> CharacterSkinDescTextArray; // 0x398(0x10)
	struct FText CharacterSkinFlavorText; // 0x3a8(0x18)
	struct UTexture2D* CharacterSkinIconTexture; // 0x3c0(0x08)
	struct FPrimaryAssetId CharacterSkinId; // 0x3c8(0x10)
	bool bIsEquipped; // 0x3d8(0x01)
	char pad_3D9[0x7]; // 0x3d9(0x07)
	struct UDCSkinTooltipWidget* TooltipWidgetClass; // 0x3e0(0x08)
	struct UUserWidget* SkinTooltipWidget; // 0x3e8(0x08)

	struct UUserWidget* GetTooltipWidget(); // Function DungeonCrawler.DCCharacterSkinWidget.GetTooltipWidget // (None) // @ game+0xffffbccadf830041
};

// Class DungeonCrawler.DCCharacterSkinListEntryWidget
// Size: 0x400 (Inherited: 0x3f0)
struct UDCCharacterSkinListEntryWidget : UDCCharacterSkinWidget {
	struct FText CharacterSkinName; // 0x380(0x18)
	struct TArray<struct FText> CharacterSkinDescTextArray; // 0x398(0x10)
	struct FText CharacterSkinFlavorText; // 0x3a8(0x18)
	struct UTexture2D* CharacterSkinIconTexture; // 0x3c0(0x08)
	struct FPrimaryAssetId CharacterSkinId; // 0x3c8(0x10)
	bool bIsEquipped; // 0x3d8(0x01)
	struct UDCSkinTooltipWidget* TooltipWidgetClass; // 0x3e0(0x08)
	struct UUserWidget* SkinTooltipWidget; // 0x3e8(0x08)

	void OnRightClicked(); // Function DungeonCrawler.DCCharacterSkinListEntryWidget.OnRightClicked // (None) // @ game+0xffffbccbdf830041
};

// Class DungeonCrawler.DCCharacterV2
// Size: 0x680 (Inherited: 0x620)
struct ADCCharacterV2 : ACharacter {
	struct USkeletalMeshComponent* PartHead; // 0x618(0x08)
	struct USkeletalMeshComponent* PartGloves; // 0x620(0x08)
	struct FDCPlayerCharacterKey CharacterKey; // 0x628(0x02)
	struct USkeletalMeshComponent* PartHelmet; // 0x630(0x08)
	struct USkeletalMeshComponent* PartChest; // 0x638(0x08)
	struct USkeletalMeshComponent* PartPants; // 0x640(0x08)
	struct USkeletalMeshComponent* PartBoots; // 0x648(0x08)
	struct USkeletalMeshComponent* PartBack; // 0x650(0x08)
	struct UDCCharacterDataComponent* CharacterDataComponent; // 0x658(0x08)
	struct UDCCharacterPartsComponent* CharacterPartsComponent; // 0x660(0x08)
	struct UDCInventoryComponent* InventoryComponent; // 0x668(0x08)
	struct UDCEquipmentComponent* EquipmentComponent; // 0x670(0x08)
	char pad_67A[0x6]; // 0x67a(0x06)
};

// Class DungeonCrawler.DCChatRoomDataAsset
// Size: 0x90 (Inherited: 0x38)
struct UDCChatRoomDataAsset : UDCDataAsset {
	struct FText Name; // 0x38(0x18)
	int32_t Order; // 0x50(0x04)
	enum class EChatRoomCategoryType ChatRoomCategoryType; // 0x54(0x01)
	char pad_55[0x3]; // 0x55(0x03)
	struct TArray<struct FGameplayTag> AllowedItemLinkTypes; // 0x58(0x10)
	struct TArray<struct FPrimaryAssetId> AllowedItemLinkClassIds; // 0x68(0x10)
	struct FText AllowedAllowedItemLinkDesc; // 0x78(0x18)
};

// Class DungeonCrawler.DCUserInfoManagerBase
// Size: 0x30 (Inherited: 0x28)
struct UDCUserInfoManagerBase : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class DungeonCrawler.DCClientAccountManager
// Size: 0xf8 (Inherited: 0x30)
struct UDCClientAccountManager : UDCUserInfoManagerBase {
	char pad_30[0x10]; // 0x30(0x10)
	struct TMap<struct FDCAccountId, struct FDCClientAccountInfo> Infos; // 0x40(0x50)
	char pad_90[0x68]; // 0x90(0x68)
};

// Class DungeonCrawler.DCClientReportPlayerManager
// Size: 0xf0 (Inherited: 0x30)
struct UDCClientReportPlayerManager : UDCUserInfoManagerBase {
	char pad_30[0x30]; // 0x30(0x30)
	struct FDCReportPlayerInfo ReportInfo; // 0x60(0x70)
	struct TArray<struct FDCReportedInfo> ReportedInfoArray; // 0xd0(0x10)
	struct TArray<struct FDCReportPlayerResultInfo> ReportResultInfoArray; // 0xe0(0x10)
};

// Class DungeonCrawler.DCClientShopManager
// Size: 0x228 (Inherited: 0x30)
struct UDCClientShopManager : UDCUserInfoManagerBase {
	char pad_30[0x1f8]; // 0x30(0x1f8)
};

// Class DungeonCrawler.DCCommunityBlockEntryWidgetData
// Size: 0x78 (Inherited: 0x28)
struct UDCCommunityBlockEntryWidgetData : UObject {
	struct FDCCommunityCharacterInfo Info; // 0x28(0x50)
};

// Class DungeonCrawler.DCCommunityBlockEntryWidget
// Size: 0x2e8 (Inherited: 0x278)
struct UDCCommunityBlockEntryWidget : UUserWidget {
	char pad_278[0x8]; // 0x278(0x08)
	struct FNickname Nickname; // 0x280(0x28)
	struct FText CharacterClassName; // 0x2a8(0x18)
	enum class EDCGender Gender; // 0x2c0(0x01)
	char pad_2C1[0x7]; // 0x2c1(0x07)
	struct UTexture2D* Icon; // 0x2c8(0x08)
	struct UTexture2D* Portrait; // 0x2d0(0x08)
	bool bSelect; // 0x2d8(0x01)
	char pad_2D9[0x7]; // 0x2d9(0x07)
	struct UDCContextMenuWidget* ContextMenuWidget; // 0x2e0(0x08)

	void ExecuteContextMenu(enum class EContextOptionType Option); // Function DungeonCrawler.DCCommunityBlockEntryWidget.ExecuteContextMenu // (None) // @ game+0xffffbccddf830041
};

// Class DungeonCrawler.LobbyGroupWidgetBase
// Size: 0x470 (Inherited: 0x440)
struct ULobbyGroupWidgetBase : UDCCommonActivatableWidgetBase {
	enum class EWidgetLobbyGroupType WidgetLobbyGroupType; // 0x440(0x01)
	char pad_441[0x7]; // 0x441(0x07)
	struct TArray<enum class EWidgetLobbyGroupType> NonCoexistWidgetLobbyGroupTypeArray; // 0x448(0x10)
	int32_t GroupWidgetPriority; // 0x458(0x04)
	bool bShouldWaitResponseOnHide; // 0x45c(0x01)
	bool bShowConfirmPopupOnHide; // 0x45d(0x01)
	char pad_45E[0x2]; // 0x45e(0x02)
	struct UCommonPopupSWidget* CommonPopupWidget; // 0x460(0x08)
	char pad_468[0x8]; // 0x468(0x08)
};

// Class DungeonCrawler.DCCommunityBlockWidget
// Size: 0x498 (Inherited: 0x470)
struct UDCCommunityBlockWidget : ULobbyGroupWidgetBase {
	int32_t PageIndex; // 0x470(0x04)
	char pad_474[0x4]; // 0x474(0x04)
	struct UTileView* TileView; // 0x478(0x08)
	struct UButton* ButtonBack; // 0x480(0x08)
	struct UDCCommonButtonBase* ButtonPageLeft; // 0x488(0x08)
	struct UDCCommonButtonBase* ButtonPageRight; // 0x490(0x08)

	void OnEntryHovered(struct UObject* WidgetData, bool bIsHovered); // Function DungeonCrawler.DCCommunityBlockWidget.OnEntryHovered // (None) // @ game+0xffffbcd5df830041
};

// Class DungeonCrawler.DCCommunityManager
// Size: 0xa0 (Inherited: 0x30)
struct UDCCommunityManager : UDCUserInfoManagerBase {
	char pad_30[0x18]; // 0x30(0x18)
	int32_t MaxBlockCount; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct TMap<struct FDCCharacterId, struct FDCCommunityCharacterInfo> BlockInfos; // 0x50(0x50)
};

// Class DungeonCrawler.DCConstantDataAsset
// Size: 0x40 (Inherited: 0x38)
struct UDCConstantDataAsset : UDCDataAsset {
	float FloatValue; // 0x38(0x04)
	int32_t Int32Value; // 0x3c(0x04)
};

// Class DungeonCrawler.DCContextComponent
// Size: 0x110 (Inherited: 0xa0)
struct UDCContextComponent : UActorComponent {
	char pad_A0[0x58]; // 0xa0(0x58)
	struct UContextMenuWidgetBase* ContextMenuWidgetClass; // 0xf8(0x08)
	char pad_100[0x10]; // 0x100(0x10)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCContextComponent.UnbindMsgAll // (None) // @ game+0xffffbcdadf830041
};

// Class DungeonCrawler.DCContextMenuEntryWidgetData
// Size: 0x38 (Inherited: 0x28)
struct UDCContextMenuEntryWidgetData : UObject {
	enum class EContextOptionType ContextOption; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct UDCContextMenuWidget* ContextMenuWidget; // 0x30(0x08)
};

// Class DungeonCrawler.DCContextMenuEntryWidget
// Size: 0x288 (Inherited: 0x278)
struct UDCContextMenuEntryWidget : UUserWidget {
	char pad_278[0x8]; // 0x278(0x08)
	enum class EContextOptionType ContextOption; // 0x280(0x01)
	char pad_281[0x7]; // 0x281(0x07)

	void Execute(); // Function DungeonCrawler.DCContextMenuEntryWidget.Execute // (None) // @ game+0xffffbcdbdf830041
};

// Class DungeonCrawler.DCContextMenuWidget
// Size: 0x2a8 (Inherited: 0x278)
struct UDCContextMenuWidget : UUserWidget {
	char pad_278[0x20]; // 0x278(0x20)
	struct UOverlay* RootOverlay; // 0x298(0x08)
	struct UListView* ListView; // 0x2a0(0x08)
};

// Class DungeonCrawler.DCCustomizeActionSkinListWidget
// Size: 0x328 (Inherited: 0x300)
struct UDCCustomizeActionSkinListWidget : UDCWidgetBase {
	char pad_300[0x18]; // 0x300(0x18)
	struct UTileView* TileView_ActionSkinList; // 0x318(0x08)
	enum class EDCActionSkinType ActionSkinType; // 0x320(0x01)
	char pad_321[0x7]; // 0x321(0x07)

	void OnSetActionSkinInfoArray(struct TArray<struct FDCActionSkinInfo> ActionSkinInfoArray); // Function DungeonCrawler.DCCustomizeActionSkinListWidget.OnSetActionSkinInfoArray // (None) // @ game+0xffffbcdcdf830041
};

// Class DungeonCrawler.DCCustomizeCharacterSkinListWidget
// Size: 0x320 (Inherited: 0x300)
struct UDCCustomizeCharacterSkinListWidget : UDCWidgetBase {
	char pad_300[0x18]; // 0x300(0x18)
	struct UTileView* TileView_CharacterSkinList; // 0x318(0x08)

	void OnSetCharacterSkinInfoArray(struct TArray<struct FDCCharacterSkinInfo> CharacterSkinInfoArray); // Function DungeonCrawler.DCCustomizeCharacterSkinListWidget.OnSetCharacterSkinInfoArray // (None) // @ game+0xffffbcdddf830041
};

// Class DungeonCrawler.DCCustomizeComponent
// Size: 0x1b0 (Inherited: 0xa0)
struct UDCCustomizeComponent : UActorComponent {
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x30(0x30)
	struct TArray<struct FName> ComponentTags; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	int32_t UCSSerializationIndex; // 0x84(0x04)
	char pad_F4_0 : 3; // 0xf4(0x01)
	char bNetAddressable : 1; // 0x88(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x88(0x01)
	char bReplicates : 1; // 0x88(0x01)
	char bAutoActivate : 1; // 0x8a(0x01)
	char bIsActive : 1; // 0x8a(0x01)
	char pad_F5_0 : 3; // 0xf5(0x01)
	char bEditableWhenInherited : 1; // 0x8a(0x01)
	char pad_F5_4 : 1; // 0xf5(0x01)
	char bCanEverAffectNavigation : 1; // 0x8a(0x01)
	char pad_F5_6 : 1; // 0xf5(0x01)
	char bIsEditorOnly : 1; // 0x8a(0x01)
	enum class EComponentCreationMethod CreationMethod; // 0x8d(0x01)
	struct FMulticastSparseDelegate OnComponentActivated; // 0x8e(0x01)
	struct FMulticastSparseDelegate OnComponentDeactivated; // 0x8f(0x01)
	char pad_F9[0xb7]; // 0xf9(0xb7)
};

// Class DungeonCrawler.DCCustomizeDragVisualWidget
// Size: 0x308 (Inherited: 0x300)
struct UDCCustomizeDragVisualWidget : UDCWidgetBase {
	struct UTexture2D* CustomizeItemTexture; // 0x300(0x08)
};

// Class DungeonCrawler.DCCustomizeEmoteListWidget
// Size: 0x320 (Inherited: 0x300)
struct UDCCustomizeEmoteListWidget : UDCWidgetBase {
	char pad_300[0x18]; // 0x300(0x18)
	struct UTileView* TileView_EmoteList; // 0x318(0x08)

	void OnSetEmoteIdArray(struct TArray<struct FDCEmoteInfo> EmoteIdArray); // Function DungeonCrawler.DCCustomizeEmoteListWidget.OnSetEmoteIdArray // (None) // @ game+0xffffbcdedf830041
};

// Class DungeonCrawler.DCCustomizeEmoteRadialSlotWidget
// Size: 0x410 (Inherited: 0x368)
struct UDCCustomizeEmoteRadialSlotWidget : UDCControlWidgetBase {
	char pad_368[0x30]; // 0x368(0x30)
	struct UTexture2D* EmoteIconTexture; // 0x398(0x08)
	struct UImage* EmoteIconImage; // 0x3a0(0x08)
	struct UTexture2D* PreviewEmoteIconTexture; // 0x3a8(0x08)
	float EmoteIconAngle; // 0x3b0(0x04)
	char pad_3B4[0x4]; // 0x3b4(0x04)
	struct FText EmoteName; // 0x3b8(0x18)
	struct FText EmoteFlavorText; // 0x3d0(0x18)
	struct UDCSkinTooltipWidget* TooltipWidgetClass; // 0x3e8(0x08)
	struct UUserWidget* SkinTooltipWidget; // 0x3f0(0x08)
	char pad_3F8[0x18]; // 0x3f8(0x18)

	void SetEmoteIconImageAngle(float NewAngle); // Function DungeonCrawler.DCCustomizeEmoteRadialSlotWidget.SetEmoteIconImageAngle // (None) // @ game+0xffffbce4df830041
};

// Class DungeonCrawler.DCCustomizeEmoteRadialWidget
// Size: 0x3c0 (Inherited: 0x300)
struct UDCCustomizeEmoteRadialWidget : UDCWidgetBase {
	struct UDCCustomizeEmoteRadialSlotWidget* EmoteRadialSlotWidget_2; // 0x300(0x08)
	struct UDCCustomizeEmoteRadialSlotWidget* EmoteRadialSlotWidget_3; // 0x308(0x08)
	struct UDCCustomizeEmoteRadialSlotWidget* EmoteRadialSlotWidget_4; // 0x310(0x08)
	struct UDCCustomizeEmoteRadialSlotWidget* EmoteRadialSlotWidget_5; // 0x318(0x08)
	struct UDCCustomizeEmoteRadialSlotWidget* EmoteRadialSlotWidget_6; // 0x320(0x08)
	struct UDCCustomizeEmoteRadialSlotWidget* EmoteRadialSlotWidget_7; // 0x328(0x08)
	struct UDCCustomizeEmoteRadialSlotWidget* EmoteRadialSlotWidget_8; // 0x330(0x08)
	struct UDCCustomizeEmoteRadialSlotWidget* EmoteRadialSlotWidget_9; // 0x338(0x08)
	char pad_340[0x80]; // 0x340(0x80)
};

// Class DungeonCrawler.DCCustomizeItemSkinListWidget
// Size: 0x320 (Inherited: 0x300)
struct UDCCustomizeItemSkinListWidget : UDCWidgetBase {
	char pad_300[0x18]; // 0x300(0x18)
	struct UTileView* TileView_ItemSkinList; // 0x318(0x08)

	void OnSetItemSkinInfoArray(struct TArray<struct FDCItemSkinInfo> ItemSkinInfoArray); // Function DungeonCrawler.DCCustomizeItemSkinListWidget.OnSetItemSkinInfoArray // (None) // @ game+0xffffbce5df830041
};

// Class DungeonCrawler.DCCustomizeLobbyEmoteListWidget
// Size: 0x320 (Inherited: 0x300)
struct UDCCustomizeLobbyEmoteListWidget : UDCWidgetBase {
	char pad_300[0x18]; // 0x300(0x18)
	struct UTileView* TileView_LobbyEmoteList; // 0x318(0x08)

	void OnSetLobbyEmoteIdArray(struct TArray<struct FDCLobbyEmoteInfo> LobbyEmoteIdArray); // Function DungeonCrawler.DCCustomizeLobbyEmoteListWidget.OnSetLobbyEmoteIdArray // (None) // @ game+0xffffbce6df830041
};

// Class DungeonCrawler.DCCustomizeLobbyEmoteRadialSlotWidget
// Size: 0x410 (Inherited: 0x368)
struct UDCCustomizeLobbyEmoteRadialSlotWidget : UDCControlWidgetBase {
	char pad_368[0x30]; // 0x368(0x30)
	struct UTexture2D* LobbyEmoteIconTexture; // 0x398(0x08)
	struct UImage* LobbyEmoteIconImage; // 0x3a0(0x08)
	struct UTexture2D* PreviewLobbyEmoteIconTexture; // 0x3a8(0x08)
	float LobbyEmoteIconAngle; // 0x3b0(0x04)
	char pad_3B4[0x4]; // 0x3b4(0x04)
	struct FText LobbyEmoteName; // 0x3b8(0x18)
	struct FText LobbyEmoteFlavorText; // 0x3d0(0x18)
	struct UDCSkinTooltipWidget* TooltipWidgetClass; // 0x3e8(0x08)
	struct UUserWidget* SkinTooltipWidget; // 0x3f0(0x08)
	char pad_3F8[0x18]; // 0x3f8(0x18)

	void SetLobbyEmoteIconImageAngle(float NewAngle); // Function DungeonCrawler.DCCustomizeLobbyEmoteRadialSlotWidget.SetLobbyEmoteIconImageAngle // (None) // @ game+0xffffbcecdf830041
};

// Class DungeonCrawler.DCCustomizeLobbyEmoteRadialWidget
// Size: 0x3c0 (Inherited: 0x300)
struct UDCCustomizeLobbyEmoteRadialWidget : UDCWidgetBase {
	struct UDCCustomizeLobbyEmoteRadialSlotWidget* LobbyEmoteRadialSlotWidget_2; // 0x300(0x08)
	struct UDCCustomizeLobbyEmoteRadialSlotWidget* LobbyEmoteRadialSlotWidget_3; // 0x308(0x08)
	struct UDCCustomizeLobbyEmoteRadialSlotWidget* LobbyEmoteRadialSlotWidget_4; // 0x310(0x08)
	struct UDCCustomizeLobbyEmoteRadialSlotWidget* LobbyEmoteRadialSlotWidget_5; // 0x318(0x08)
	struct UDCCustomizeLobbyEmoteRadialSlotWidget* LobbyEmoteRadialSlotWidget_6; // 0x320(0x08)
	struct UDCCustomizeLobbyEmoteRadialSlotWidget* LobbyEmoteRadialSlotWidget_7; // 0x328(0x08)
	struct UDCCustomizeLobbyEmoteRadialSlotWidget* LobbyEmoteRadialSlotWidget_8; // 0x330(0x08)
	struct UDCCustomizeLobbyEmoteRadialSlotWidget* LobbyEmoteRadialSlotWidget_9; // 0x338(0x08)
	char pad_340[0x80]; // 0x340(0x80)
};

// Class DungeonCrawler.DCCustomizeWidgetBase
// Size: 0x328 (Inherited: 0x300)
struct UDCCustomizeWidgetBase : UDCWidgetBase {
	struct UDCTabMenuWidgetBase* CustomizeTabWidget; // 0x300(0x08)
	struct UDCCustomizeEmoteRadialWidget* CustomizeEmoteRadialWidget; // 0x308(0x08)
	struct UWidgetSwitcher* PreviewSwitcher; // 0x310(0x08)
	char pad_318[0x10]; // 0x318(0x10)

	void OnRestSkinTabSelected(); // Function DungeonCrawler.DCCustomizeWidgetBase.OnRestSkinTabSelected // (None) // @ game+0xffffbcf8df830041
};

// Class DungeonCrawler.DCDamageExecCalculation
// Size: 0x40 (Inherited: 0x40)
struct UDCDamageExecCalculation : UGameplayEffectExecutionCalculation {
	bool bRequiresPassedInTags; // 0x38(0x01)
};

// Class DungeonCrawler.DCDamageIndicatorComponent
// Size: 0x110 (Inherited: 0xa0)
struct UDCDamageIndicatorComponent : UActorComponent {
	char pad_A0[0x58]; // 0xa0(0x58)
	struct FVector IsZeroLocationByOffset; // 0xf8(0x18)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCDamageIndicatorComponent.UnbindMsgAll // (None) // @ game+0xffffbcfcdf830041
};

// Class DungeonCrawler.DCDataBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UDCDataBlueprintLibrary : UBlueprintFunctionLibrary {

	int64_t MakeUniqueId(); // Function DungeonCrawler.DCDataBlueprintLibrary.MakeUniqueId // (None) // @ game+0xffffbd48df830041
};

// Class DungeonCrawler.DCDefaultCharacterV2
// Size: 0x680 (Inherited: 0x680)
struct ADCDefaultCharacterV2 : ADCCharacterV2 {
	struct USkeletalMeshComponent* PartHead; // 0x618(0x08)
	struct USkeletalMeshComponent* PartGloves; // 0x620(0x08)
	struct FDCPlayerCharacterKey CharacterKey; // 0x628(0x02)
	struct USkeletalMeshComponent* PartHelmet; // 0x630(0x08)
	struct USkeletalMeshComponent* PartChest; // 0x638(0x08)
	struct USkeletalMeshComponent* PartPants; // 0x640(0x08)
	struct USkeletalMeshComponent* PartBoots; // 0x648(0x08)
	struct USkeletalMeshComponent* PartBack; // 0x650(0x08)
	struct UDCCharacterDataComponent* CharacterDataComponent; // 0x658(0x08)
	struct UDCCharacterPartsComponent* CharacterPartsComponent; // 0x660(0x08)
	struct UDCInventoryComponent* InventoryComponent; // 0x668(0x08)
	struct UDCEquipmentComponent* EquipmentComponent; // 0x670(0x08)
};

// Class DungeonCrawler.DCDungeonDataAsset
// Size: 0xb8 (Inherited: 0x38)
struct UDCDungeonDataAsset : UDCDataAsset {
	struct FText Name; // 0x38(0x18)
	enum class EGameDifficultyType GameDifficultyType; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	int32_t Floor; // 0x54(0x04)
	struct TSoftObjectPtr<UDCFloorRuleDataAsset> FloorRule; // 0x58(0x30)
	struct TSoftObjectPtr<UWorld> LevelAsset; // 0x88(0x30)
};

// Class DungeonCrawler.DCDungeonGameMode
// Size: 0x518 (Inherited: 0x4c0)
struct ADCDungeonGameMode : ADCIngameGameMode {
	float WarmupDuration; // 0x4c0(0x04)
	char pad_4C4[0x4]; // 0x4c4(0x04)
	struct ADeathSwarmBase* DeathSwarm; // 0x4c8(0x08)
	struct FDCFloorRuleManager FloorRuleManager; // 0x4d0(0x38)
	char pad_508[0x10]; // 0x508(0x10)
};

// Class DungeonCrawler.DCGameStateBase
// Size: 0x6d8 (Inherited: 0x2e0)
struct ADCGameStateBase : AGameStateBase {
	char pad_2E0[0x58]; // 0x2e0(0x58)
	struct UBaseObject* BaseObject; // 0x338(0x08)
	char pad_340[0x18]; // 0x340(0x18)
	enum class EGameStateType State; // 0x358(0x01)
	char pad_359[0x87]; // 0x359(0x87)
	struct TArray<struct FGameStateData> GameStateDataArray; // 0x3e0(0x10)
	struct TArray<struct FAccountDataReplication> AccountDataReplicationArray; // 0x3f0(0x10)
	struct TMap<struct FString, struct UAccountSession*> AccountSessionMap; // 0x400(0x50)
	struct TMap<struct FString, struct TWeakObjectPtr<struct ADCCharacterBase>> PlayerCharacters; // 0x450(0x50)
	char pad_4A0[0xf0]; // 0x4a0(0xf0)
	struct TArray<struct FPartyData> PartyDataArray; // 0x590(0x10)
	struct TMap<struct FString, struct UPartySession*> PartySessionMap; // 0x5a0(0x50)
	struct ADeathSwarmBase* DeathSwarm; // 0x5f0(0x08)
	struct FGameFloorRuleData GameFloorRuleData; // 0x5f8(0x60)
	struct FDCGameInfo GameInfo; // 0x658(0x48)
	char pad_6A0[0x18]; // 0x6a0(0x18)
	struct FDCDungeonInfo DungeonInfo; // 0x6b8(0x0c)
	float ServerAverageFps; // 0x6c4(0x04)
	float ServerAverageMs; // 0x6c8(0x04)
	int32_t MonsterActive; // 0x6cc(0x04)
	int32_t PropsActive; // 0x6d0(0x04)
	int32_t NavTestCall; // 0x6d4(0x04)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCGameStateBase.UnbindMsgAll // (None) // @ game+0xffffbd66df830041
};

// Class DungeonCrawler.DCDungeonGameState
// Size: 0x800 (Inherited: 0x6d8)
struct ADCDungeonGameState : ADCGameStateBase {
	struct FGameAnnounceData AnnounceForDown; // 0x6d8(0x90)
	struct FGameAnnounceData AnnounceForResult; // 0x768(0x90)
	int32_t NumPlayers; // 0x7f8(0x04)
	char pad_7FC[0x4]; // 0x7fc(0x04)

	void OnRep_NumPlayers(int32_t OldNumPlayers); // Function DungeonCrawler.DCDungeonGameState.OnRep_NumPlayers // (None) // @ game+0xffffbd67df830041
};

// Class DungeonCrawler.DCEditableText
// Size: 0x520 (Inherited: 0x4e0)
struct UDCEditableText : UEditableText {
	struct FText Text; // 0x150(0x18)
	struct FDelegate TextDelegate; // 0x168(0x10)
	struct FText HintText; // 0x178(0x18)
	struct FDelegate HintTextDelegate; // 0x190(0x10)
	struct FEditableTextStyle WidgetStyle; // 0x1a0(0x2f0)
	bool IsReadOnly; // 0x490(0x01)
	bool IsPassword; // 0x491(0x01)
	float MinimumDesiredWidth; // 0x494(0x04)
	bool IsCaretMovedWhenGainFocus; // 0x498(0x01)
	bool SelectAllTextWhenFocused; // 0x499(0x01)
	bool RevertTextOnEscape; // 0x49a(0x01)
	bool ClearKeyboardFocusOnCommit; // 0x49b(0x01)
	bool SelectAllTextOnCommit; // 0x49c(0x01)
	bool AllowContextMenu; // 0x49d(0x01)
	enum class EVirtualKeyboardType KeyboardType; // 0x49e(0x01)
	struct FVirtualKeyboardOptions VirtualKeyboardOptions; // 0x49f(0x01)
	enum class EVirtualKeyboardTrigger VirtualKeyboardTrigger; // 0x4a0(0x01)
	enum class EVirtualKeyboardDismissAction VirtualKeyboardDismissAction; // 0x4a1(0x01)
	enum class ETextJustify Justification; // 0x4a2(0x01)
	enum class ETextOverflowPolicy OverflowPolicy; // 0x4a3(0x01)
	struct FShapedTextOptions ShapedTextOptions; // 0x4a4(0x03)
	struct FMulticastInlineDelegate OnTextChanged; // 0x4a8(0x10)
	struct FMulticastInlineDelegate OnTextCommitted; // 0x4b8(0x10)
};

// Class DungeonCrawler.DCEmoteDataAsset
// Size: 0xf0 (Inherited: 0x38)
struct UDCEmoteDataAsset : UDCDataAsset {
	struct FText Name; // 0x38(0x18)
	struct TSoftObjectPtr<UDescData> Desc; // 0x50(0x30)
	struct FText FlavorText; // 0x80(0x18)
	struct FGameplayTag EmoteTag; // 0x98(0x08)
	struct TSoftObjectPtr<UArtDataEmote> ArtData; // 0xa0(0x30)
	struct TArray<struct TSoftObjectPtr<UDCGameplayAbilityDataAsset>> Abilities; // 0xd0(0x10)
	struct TArray<struct TSoftObjectPtr<UDCGameplayEffectDataAsset>> Effects; // 0xe0(0x10)
};

// Class DungeonCrawler.DCEmoteListEntryWidgetData
// Size: 0x40 (Inherited: 0x28)
struct UDCEmoteListEntryWidgetData : UObject {
	struct FDCEmoteInfo EmoteInfo; // 0x28(0x10)
	bool bIsSelected; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// Class DungeonCrawler.DCEmoteWidget
// Size: 0x3f8 (Inherited: 0x368)
struct UDCEmoteWidget : UDCControlWidgetBase {
	char pad_368[0x18]; // 0x368(0x18)
	struct FText EmoteName; // 0x380(0x18)
	struct TArray<struct FText> EmoteDescTextArray; // 0x398(0x10)
	struct FText EmoteFlavorText; // 0x3a8(0x18)
	struct UTexture2D* EmoteIconTexture; // 0x3c0(0x08)
	struct FPrimaryAssetId EmoteId; // 0x3c8(0x10)
	bool bIsEquipped; // 0x3d8(0x01)
	char pad_3D9[0x7]; // 0x3d9(0x07)
	struct UDCSkinTooltipWidget* TooltipWidgetClass; // 0x3e0(0x08)
	struct UUserWidget* SkinTooltipWidget; // 0x3e8(0x08)
	struct UDCCustomizeDragVisualWidget* EmoteDragVisualWidgetClass; // 0x3f0(0x08)

	struct UUserWidget* GetTooltipWidget(); // Function DungeonCrawler.DCEmoteWidget.GetTooltipWidget // (None) // @ game+0xffffbd68df830041
};

// Class DungeonCrawler.DCEmoteListEntryWidget
// Size: 0x408 (Inherited: 0x3f8)
struct UDCEmoteListEntryWidget : UDCEmoteWidget {
	struct FText EmoteName; // 0x380(0x18)
	struct TArray<struct FText> EmoteDescTextArray; // 0x398(0x10)
	struct FText EmoteFlavorText; // 0x3a8(0x18)
	struct UTexture2D* EmoteIconTexture; // 0x3c0(0x08)
	struct FPrimaryAssetId EmoteId; // 0x3c8(0x10)
	bool bIsEquipped; // 0x3d8(0x01)
	struct UDCSkinTooltipWidget* TooltipWidgetClass; // 0x3e0(0x08)
	struct UUserWidget* SkinTooltipWidget; // 0x3e8(0x08)
	struct UDCCustomizeDragVisualWidget* EmoteDragVisualWidgetClass; // 0x3f0(0x08)

	void OnRightClicked(); // Function DungeonCrawler.DCEmoteListEntryWidget.OnRightClicked // (None) // @ game+0xffffbd6adf830041
};

// Class DungeonCrawler.DCEnhancedInputLibrary
// Size: 0x28 (Inherited: 0x28)
struct UDCEnhancedInputLibrary : UBlueprintFunctionLibrary {

	void RemovePlayerMappableConfigByTagContainer(struct UObject* WorldContextObject, struct FGameplayTagContainer InputConfigTags); // Function DungeonCrawler.DCEnhancedInputLibrary.RemovePlayerMappableConfigByTagContainer // (None) // @ game+0xffffbd77df830041
};

// Class DungeonCrawler.DCEnhancedInputLocalPlayerSubsystem
// Size: 0x1e0 (Inherited: 0x1e0)
struct UDCEnhancedInputLocalPlayerSubsystem : UEnhancedInputLocalPlayerSubsystem {
	struct FMulticastInlineDelegate ControlMappingsRebuiltDelegate; // 0x1d0(0x10)

	void RemovePlayerMappableConfigByTag(struct FGameplayTag InputConfigTag, struct FModifyContextOptions& Options); // Function DungeonCrawler.DCEnhancedInputLocalPlayerSubsystem.RemovePlayerMappableConfigByTag // (None) // @ game+0xffffbd7bdf830041
};

// Class DungeonCrawler.DCEntryGameMode
// Size: 0x3a0 (Inherited: 0x3a0)
struct ADCEntryGameMode : ADCGameModeBase {
	struct UBaseObject* BaseObject; // 0x388(0x08)
	struct ADCGameModeAIControllerBase* GameModeAIControllerClass; // 0x390(0x08)
	struct ADCGameModeAIControllerBase* GameModeAIController; // 0x398(0x08)
};

// Class DungeonCrawler.DCEquipInventory
// Size: 0x1c0 (Inherited: 0x1c0)
struct UDCEquipInventory : UDCInventoryBase {
	enum class EDCInventoryId InventoryId; // 0x40(0x01)
	struct TArray<int32_t> Indexes; // 0x48(0x10)
	struct TMap<int32_t, struct FDCItemId> KeyByIndex; // 0x58(0x50)
	struct TMap<struct FDCItemId, struct FDCItemInfo> Values; // 0xa8(0x50)
	struct ACharacter* OwnerCharacter; // 0xf8(0x08)
	struct FDCInventoryData InitData; // 0x150(0x20)
	struct TMap<enum class EDCInventoryValidatorType, struct UDCInventoryValidatorBase*> Validators; // 0x170(0x50)
};

// Class DungeonCrawler.DCItemActor
// Size: 0x3b0 (Inherited: 0x290)
struct ADCItemActor : AActor {
	struct FDCItemInfo ItemInfo; // 0x290(0x118)
	struct USkeletalMeshComponent* ItemMeshComponent; // 0x3a8(0x08)
};

// Class DungeonCrawler.DCEquipItemActor
// Size: 0x3b0 (Inherited: 0x3b0)
struct ADCEquipItemActor : ADCItemActor {
	struct FDCItemInfo ItemInfo; // 0x290(0x118)
	struct USkeletalMeshComponent* ItemMeshComponent; // 0x3a8(0x08)
};

// Class DungeonCrawler.DCEquipmentComponent
// Size: 0x160 (Inherited: 0xa0)
struct UDCEquipmentComponent : UActorComponent {
	struct ADCEquipItemActor* ItemActorClass; // 0xa0(0x08)
	struct UDCEquipInventory* Inventory; // 0xa8(0x08)
	struct TMap<enum class EDCEquipmentSlotIndex, struct FDCItemId> ItemIdByEquipSlot; // 0xb0(0x50)
	struct TArray<struct FDCItemId> ArmorItemIds; // 0x100(0x10)
	struct TMap<struct FDCItemId, struct ADCEquipItemActor*> WeaponItemActors; // 0x110(0x50)

	void SetInventory(struct UDCInventoryBase* InInventory); // Function DungeonCrawler.DCEquipmentComponent.SetInventory // (None) // @ game+0xffffbd7ddf830041
};

// Class DungeonCrawler.DCEquipmentSlotWidget
// Size: 0x520 (Inherited: 0x4f0)
struct UDCEquipmentSlotWidget : UDCItemCommonWidget {
	bool bCanEquip; // 0x4f0(0x01)
	bool bPairSlot; // 0x4f1(0x01)
	bool bDropPreview; // 0x4f2(0x01)
	char pad_4F3[0x5]; // 0x4f3(0x05)
	struct UImage* DropPreviewImage; // 0x4f8(0x08)
	float WearingDurationTime; // 0x500(0x04)
	float WearingRemainTime; // 0x504(0x04)
	struct USizeBox* ItemSizeBox; // 0x508(0x08)
	struct USizeBox* DropPreviewSizeBox; // 0x510(0x08)
	enum class EDCEquipmentSlotIndex EquipSlot; // 0x518(0x01)
	char pad_519[0x7]; // 0x519(0x07)

	bool IsWeapon(); // Function DungeonCrawler.DCEquipmentSlotWidget.IsWeapon // (None) // @ game+0xffffbd80df830041
};

// Class DungeonCrawler.DCEquipmentWidget
// Size: 0x3c8 (Inherited: 0x2c0)
struct UDCEquipmentWidget : UDCInventoryWidgetBase {
	bool bShowSoulHeart; // 0x2c0(0x01)
	char pad_2C1[0x7]; // 0x2c1(0x07)
	struct UDCEquipInventory* Inventory; // 0x2c8(0x08)
	struct UDCEquipmentSlotWidget* WeaponL1SlotWidget; // 0x2d0(0x08)
	struct UDCEquipmentSlotWidget* WeaponL2SlotWidget; // 0x2d8(0x08)
	struct UDCEquipmentSlotWidget* WeaponR1SlotWidget; // 0x2e0(0x08)
	struct UDCEquipmentSlotWidget* WeaponR2SlotWidget; // 0x2e8(0x08)
	struct UDCEquipmentSlotWidget* UtilityL1SlotWidget; // 0x2f0(0x08)
	struct UDCEquipmentSlotWidget* UtilityL2SlotWidget; // 0x2f8(0x08)
	struct UDCEquipmentSlotWidget* UtilityL3SlotWidget; // 0x300(0x08)
	struct UDCEquipmentSlotWidget* UtilityR1SlotWidget; // 0x308(0x08)
	struct UDCEquipmentSlotWidget* UtilityR2SlotWidget; // 0x310(0x08)
	struct UDCEquipmentSlotWidget* UtilityR3SlotWidget; // 0x318(0x08)
	struct UDCEquipmentSlotWidget* ArmorHeadSlotWidget; // 0x320(0x08)
	struct UDCEquipmentSlotWidget* ArmorChestSlotWidget; // 0x328(0x08)
	struct UDCEquipmentSlotWidget* ArmorHandsSlotWidget; // 0x330(0x08)
	struct UDCEquipmentSlotWidget* ArmorLegsSlotWidget; // 0x338(0x08)
	struct UDCEquipmentSlotWidget* ArmorFootSlotWidget; // 0x340(0x08)
	struct UDCEquipmentSlotWidget* ArmorBackSlotWidget; // 0x348(0x08)
	struct UDCEquipmentSlotWidget* AccessoryNecklaceSlotWidget; // 0x350(0x08)
	struct UDCEquipmentSlotWidget* AccessoryRing1SlotWidget; // 0x358(0x08)
	struct UDCEquipmentSlotWidget* AccessoryRing2SlotWidget; // 0x360(0x08)
	struct UDCEquipmentSlotWidget* SoulHeartSlotWidget; // 0x368(0x08)
	struct TMap<enum class EDCEquipmentSlotIndex, struct UDCEquipmentSlotWidget*> SlotWidgets; // 0x370(0x50)
	enum class EDCEquipmentSlotIndex PrevDropPreview; // 0x3c0(0x01)
	char pad_3C1[0x7]; // 0x3c1(0x07)

	void OnItemsUpdated(); // Function DungeonCrawler.DCEquipmentWidget.OnItemsUpdated // (None) // @ game+0xffffbd84df830041
};

// Class DungeonCrawler.DCFloorMatchmakedGameMode
// Size: 0x520 (Inherited: 0x4c0)
struct ADCFloorMatchmakedGameMode : ADCIngameGameMode {
	struct UDCFloorRuleDataAsset* RuleData; // 0x4c0(0x08)
	float WarmupDuration; // 0x4c8(0x04)
	char pad_4CC[0x4]; // 0x4cc(0x04)
	struct ADeathSwarmBase* DeathSwarm; // 0x4d0(0x08)
	struct FDCFloorRuleManager FloorRuleManager; // 0x4d8(0x38)
	char pad_510[0x10]; // 0x510(0x10)
};

// Class DungeonCrawler.DCFloorMatchmakedGameState
// Size: 0x800 (Inherited: 0x800)
struct ADCFloorMatchmakedGameState : ADCDungeonGameState {
	struct FGameAnnounceData AnnounceForDown; // 0x6d8(0x90)
	struct FGameAnnounceData AnnounceForResult; // 0x768(0x90)
	int32_t NumPlayers; // 0x7f8(0x04)
};

// Class DungeonCrawler.DCFloorMatchmakingGameMode
// Size: 0x3a0 (Inherited: 0x3a0)
struct ADCFloorMatchmakingGameMode : ADCGameModeBase {
	struct UBaseObject* BaseObject; // 0x388(0x08)
	struct ADCGameModeAIControllerBase* GameModeAIControllerClass; // 0x390(0x08)
	struct ADCGameModeAIControllerBase* GameModeAIController; // 0x398(0x08)
};

// Class DungeonCrawler.DCFloorPortalDataAsset
// Size: 0x48 (Inherited: 0x38)
struct UDCFloorPortalDataAsset : UDCDataAsset {
	struct FGameplayTag PortalType; // 0x38(0x08)
	int32_t PortalScrollNum; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class DungeonCrawler.DCFloorRuleDataAsset
// Size: 0x48 (Inherited: 0x38)
struct UDCFloorRuleDataAsset : UDCDataAsset {
	struct TArray<struct FDCFloorRuleItemData> FloorRuleItemArray; // 0x38(0x10)
};

// Class DungeonCrawler.DCFriendInterface
// Size: 0x28 (Inherited: 0x28)
struct UDCFriendInterface : UInterface {
};

// Class DungeonCrawler.DCGameInstance
// Size: 0x3a0 (Inherited: 0x1c0)
struct UDCGameInstance : UGameInstance {
	char pad_1C0[0x58]; // 0x1c0(0x58)
	struct UDCLoadingScreenWidget* LoadingScreenClass; // 0x218(0x08)
	struct UDCLoadingScreenWidget* LoadingScreenWidget; // 0x220(0x08)
	struct UDCLoadingScreenWidget* PreLoadingScreenWidget; // 0x228(0x08)
	struct UBaseObject* BaseObject; // 0x230(0x08)
	struct UDCGameSettings* GameSettings; // 0x238(0x08)
	struct TSoftObjectPtr<UWorld> LoginLevel; // 0x240(0x30)
	struct TSoftObjectPtr<UWorld> CharacterSelectLevel; // 0x270(0x30)
	struct TSoftObjectPtr<UWorld> LobbyLevel; // 0x2a0(0x30)
	struct TSoftObjectPtr<UWorld> TavernLevel; // 0x2d0(0x30)
	struct UDCResource* ResourceClass; // 0x300(0x08)
	struct UDCResource* Resource; // 0x308(0x08)
	struct FDCGameInfo GameInfo; // 0x310(0x48)
	struct UDCClientAccountManager* ClientAccountManager; // 0x358(0x08)
	struct UDCClientShopManager* ClientShopManager; // 0x360(0x08)
	struct UDCIngameUserManager* IngameUserManager; // 0x368(0x08)
	struct UDCPlayerManager* PlayerManager; // 0x370(0x08)
	struct UDCPartyManager* PartyManager; // 0x378(0x08)
	struct UDCCommunityManager* CommunityManager; // 0x380(0x08)
	struct UDCClientReportPlayerManager* ClientReportPlayerManager; // 0x388(0x08)
	struct UDCLogEventManager* LogEventManager; // 0x390(0x08)
	struct UDCReportSystem* ReportSystem; // 0x398(0x08)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCGameInstance.UnbindMsgAll // (None) // @ game+0xffffbd8adf830041
};

// Class DungeonCrawler.DCGameModeAIControllerBase
// Size: 0x428 (Inherited: 0x3b8)
struct ADCGameModeAIControllerBase : AAIController {
	char bStartAILogicOnPossess : 1; // 0x360(0x01)
	char bStopAILogicOnUnposses : 1; // 0x360(0x01)
	char bLOSflag : 1; // 0x360(0x01)
	char bSkipExtraLOSChecks : 1; // 0x360(0x01)
	char bAllowStrafe : 1; // 0x360(0x01)
	char bWantsPlayerState : 1; // 0x360(0x01)
	char bSetControlRotationFromPawnOrientation : 1; // 0x360(0x01)
	struct UPathFollowingComponent* PathFollowingComponent; // 0x368(0x08)
	struct UBrainComponent* BrainComponent; // 0x370(0x08)
	struct UAIPerceptionComponent* PerceptionComponent; // 0x378(0x08)
	struct UPawnActionsComponent* ActionsComp; // 0x380(0x08)
	struct UBlackboardComponent* Blackboard; // 0x388(0x08)
	struct UGameplayTasksComponent* CachedGameplayTasksComponent; // 0x390(0x08)
	struct UNavigationQueryFilter* DefaultNavigationFilterClass; // 0x398(0x08)
	struct FMulticastInlineDelegate ReceiveMoveCompleted; // 0x3a0(0x10)
	char pad_400_7 : 1; // 0x400(0x01)
	char pad_401[0x27]; // 0x401(0x27)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCGameModeAIControllerBase.UnbindMsgAll // (None) // @ game+0xffffbd8fdf830041
};

// Class DungeonCrawler.DCGameModeAIControllerGameBase
// Size: 0x430 (Inherited: 0x428)
struct ADCGameModeAIControllerGameBase : ADCGameModeAIControllerBase {
	struct UAccountLinkAll* AccountLinkAll; // 0x428(0x08)
};

// Class DungeonCrawler.DCGameModeAIControllerArenaBase
// Size: 0x430 (Inherited: 0x430)
struct ADCGameModeAIControllerArenaBase : ADCGameModeAIControllerGameBase {
	struct UAccountLinkAll* AccountLinkAll; // 0x428(0x08)
};

// Class DungeonCrawler.DCGameModeAIControllerDungeonBase
// Size: 0x430 (Inherited: 0x430)
struct ADCGameModeAIControllerDungeonBase : ADCGameModeAIControllerGameBase {
	struct UAccountLinkAll* AccountLinkAll; // 0x428(0x08)
};

// Class DungeonCrawler.DCGameModeAIControllerDungeonBattleRoyalBase
// Size: 0x430 (Inherited: 0x430)
struct ADCGameModeAIControllerDungeonBattleRoyalBase : ADCGameModeAIControllerDungeonBase {
	struct UAccountLinkAll* AccountLinkAll; // 0x428(0x08)
};

// Class DungeonCrawler.DCGameModeAIControllerDungeonCrawlBase
// Size: 0x4a0 (Inherited: 0x430)
struct ADCGameModeAIControllerDungeonCrawlBase : ADCGameModeAIControllerDungeonBase {
	struct FPlayerPointData DownPlayerPointData; // 0x430(0x70)
};

// Class DungeonCrawler.DCGameModeAIControllerMetaBase
// Size: 0x428 (Inherited: 0x428)
struct ADCGameModeAIControllerMetaBase : ADCGameModeAIControllerBase {
	char bStartAILogicOnPossess : 1; // 0x360(0x01)
	char bStopAILogicOnUnposses : 1; // 0x360(0x01)
	char bLOSflag : 1; // 0x360(0x01)
	char bSkipExtraLOSChecks : 1; // 0x360(0x01)
	char bAllowStrafe : 1; // 0x360(0x01)
	char bWantsPlayerState : 1; // 0x360(0x01)
	char bSetControlRotationFromPawnOrientation : 1; // 0x360(0x01)
	struct UPathFollowingComponent* PathFollowingComponent; // 0x368(0x08)
	struct UBrainComponent* BrainComponent; // 0x370(0x08)
	struct UAIPerceptionComponent* PerceptionComponent; // 0x378(0x08)
	struct UPawnActionsComponent* ActionsComp; // 0x380(0x08)
	struct UBlackboardComponent* Blackboard; // 0x388(0x08)
	struct UGameplayTasksComponent* CachedGameplayTasksComponent; // 0x390(0x08)
	struct UNavigationQueryFilter* DefaultNavigationFilterClass; // 0x398(0x08)
	struct FMulticastInlineDelegate ReceiveMoveCompleted; // 0x3a0(0x10)
};

// Class DungeonCrawler.DCGameModeAIControllerMetaLobbyBase
// Size: 0x428 (Inherited: 0x428)
struct ADCGameModeAIControllerMetaLobbyBase : ADCGameModeAIControllerMetaBase {
	char bStartAILogicOnPossess : 1; // 0x360(0x01)
	char bStopAILogicOnUnposses : 1; // 0x360(0x01)
	char bLOSflag : 1; // 0x360(0x01)
	char bSkipExtraLOSChecks : 1; // 0x360(0x01)
	char bAllowStrafe : 1; // 0x360(0x01)
	char bWantsPlayerState : 1; // 0x360(0x01)
	char bSetControlRotationFromPawnOrientation : 1; // 0x360(0x01)
	struct UPathFollowingComponent* PathFollowingComponent; // 0x368(0x08)
	struct UBrainComponent* BrainComponent; // 0x370(0x08)
	struct UAIPerceptionComponent* PerceptionComponent; // 0x378(0x08)
	struct UPawnActionsComponent* ActionsComp; // 0x380(0x08)
	struct UBlackboardComponent* Blackboard; // 0x388(0x08)
	struct UGameplayTasksComponent* CachedGameplayTasksComponent; // 0x390(0x08)
	struct UNavigationQueryFilter* DefaultNavigationFilterClass; // 0x398(0x08)
	struct FMulticastInlineDelegate ReceiveMoveCompleted; // 0x3a0(0x10)
};

// Class DungeonCrawler.DCGameModeAIControllerTestBase
// Size: 0x430 (Inherited: 0x430)
struct ADCGameModeAIControllerTestBase : ADCGameModeAIControllerGameBase {
	struct UAccountLinkAll* AccountLinkAll; // 0x428(0x08)
};

// Class DungeonCrawler.ObjectLinkMetaDataBlueprint
// Size: 0x80 (Inherited: 0x28)
struct UObjectLinkMetaDataBlueprint : UObject {
	struct FObjectLinkMetaData MetaData; // 0x28(0x58)
};

// Class DungeonCrawler.DCGameObjectLinkComponent
// Size: 0xb8 (Inherited: 0xa0)
struct UDCGameObjectLinkComponent : UActorComponent {
	char pad_A0[0x8]; // 0xa0(0x08)
	struct FGameplayTag TypeTag; // 0xa8(0x08)
	struct FMulticastSparseDelegate OnGameObjectLinkEvent; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)

	struct TArray<struct FObjectLinkResponeEvent> RequestToLinkers(struct FObjectLinkRequestEvent& ObjectLinkRequestEvent); // Function DungeonCrawler.DCGameObjectLinkComponent.RequestToLinkers // (None) // @ game+0xffffbd90df830041
};

// Class DungeonCrawler.DCGameObjectLinker
// Size: 0x300 (Inherited: 0x2f0)
struct ADCGameObjectLinker : ADCActorBase {
	struct UBaseObject* BaseObject; // 0x2e8(0x08)
	char pad_2F8[0x8]; // 0x2f8(0x08)
};

// Class DungeonCrawler.DCGameplayAbilityBase
// Size: 0x558 (Inherited: 0x3b8)
struct UDCGameplayAbilityBase : UGameplayAbility {
	char pad_3B8[0xe0]; // 0x3b8(0xe0)
	struct TArray<struct FDCGameplayEffectContainer> EffectContainerArray; // 0x498(0x10)
	struct TArray<struct FDCGameplayEffectData> OverrideGameplayEffectDataArray; // 0x4a8(0x10)
	struct TArray<struct FActiveGameplayEffectHandle> ActiveEffectHandles; // 0x4b8(0x10)
	struct FGameplayTag IdleAnimSequenceGameplayTag; // 0x4c8(0x08)
	struct UDCMovementModifierContainerData* MovementModifierContainer; // 0x4d0(0x08)
	struct FDesignDataGameplayAbility DesignDataGameplayAbility; // 0x4d8(0x58)
	struct FGameplayTagContainer AppliedMovementModifierTags; // 0x530(0x20)
	bool bIsDefaultMovementModifierApplied; // 0x550(0x01)
	char pad_551[0x7]; // 0x551(0x07)

	void RemoveMovementModifier(struct FGameplayTagContainer& ContainerTags); // Function DungeonCrawler.DCGameplayAbilityBase.RemoveMovementModifier // (None) // @ game+0xffffbda8df830041
};

// Class DungeonCrawler.DCGameplayEffectDataAsset
// Size: 0x1c0 (Inherited: 0x38)
struct UDCGameplayEffectDataAsset : UDCDataAsset {
	struct UGameplayEffect* EffectClass; // 0x38(0x08)
	struct FGameplayTag EventTag; // 0x40(0x08)
	enum class EGameplayEffectTargetType TargetType; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	int32_t Duration; // 0x4c(0x04)
	int32_t StrengthBase; // 0x50(0x04)
	int32_t StrengthMod; // 0x54(0x04)
	int32_t AgilityBase; // 0x58(0x04)
	int32_t AgilityMod; // 0x5c(0x04)
	int32_t WillBase; // 0x60(0x04)
	int32_t WillMod; // 0x64(0x04)
	int32_t KnowledgeBase; // 0x68(0x04)
	int32_t KnowledgeMod; // 0x6c(0x04)
	int32_t ResourcefulnessBase; // 0x70(0x04)
	int32_t ResourcefulnessMod; // 0x74(0x04)
	int32_t ExecDamageWeaponRatio; // 0x78(0x04)
	int32_t PhysicalDamageWeapon; // 0x7c(0x04)
	int32_t PhysicalDamageBase; // 0x80(0x04)
	int32_t ExecPhysicalDamageBase; // 0x84(0x04)
	int32_t PhysicalPower; // 0x88(0x04)
	int32_t PhysicalDamageMod; // 0x8c(0x04)
	int32_t PhysicalDamageAdd; // 0x90(0x04)
	int32_t PhysicalDamageTrue; // 0x94(0x04)
	int32_t ExecPhysicalDamageTrue; // 0x98(0x04)
	int32_t PhysicalBackstabPower; // 0x9c(0x04)
	int32_t PhysicalHeadshotPower; // 0xa0(0x04)
	int32_t PhysicalHeadshotPenetration; // 0xa4(0x04)
	int32_t ArmorPenetration; // 0xa8(0x04)
	int32_t ExecArmorPenetration; // 0xac(0x04)
	int32_t ArmorRating; // 0xb0(0x04)
	int32_t ItemArmorRatingMod; // 0xb4(0x04)
	int32_t PhysicalReduction; // 0xb8(0x04)
	int32_t PhysicalReductionMod; // 0xbc(0x04)
	int32_t PhysicalAbsoluteReduction; // 0xc0(0x04)
	int32_t MagicalDamageWeapon; // 0xc4(0x04)
	int32_t MagicalDamageBase; // 0xc8(0x04)
	int32_t ExecMagicalDamageBase; // 0xcc(0x04)
	int32_t MagicalPower; // 0xd0(0x04)
	int32_t MagicalDamageMod; // 0xd4(0x04)
	int32_t MagicalDamageAdd; // 0xd8(0x04)
	int32_t MagicalDamageTrue; // 0xdc(0x04)
	int32_t ExecMagicalDamageTrue; // 0xe0(0x04)
	int32_t MagicPenetration; // 0xe4(0x04)
	int32_t ExecMagicPenetration; // 0xe8(0x04)
	int32_t MagicalFireDamageBase; // 0xec(0x04)
	int32_t MagicalFireDamageMod; // 0xf0(0x04)
	int32_t MagicalFireDamageAdd; // 0xf4(0x04)
	int32_t MagicalArcaneDamageBase; // 0xf8(0x04)
	int32_t MagicalArcaneDamageMod; // 0xfc(0x04)
	int32_t MagicalArcaneDamageAdd; // 0x100(0x04)
	int32_t MagicResistance; // 0x104(0x04)
	int32_t MagicalReduction; // 0x108(0x04)
	int32_t MagicalReductionMod; // 0x10c(0x04)
	int32_t MagicalAbsoluteReduction; // 0x110(0x04)
	int32_t HeadshotReductionMod; // 0x114(0x04)
	int32_t ProjectileReductionMod; // 0x118(0x04)
	int32_t ImpactPower; // 0x11c(0x04)
	int32_t ExecImpactPower; // 0x120(0x04)
	int32_t ExecImpactEnduranceRestore; // 0x124(0x04)
	int32_t ImpactResistance; // 0x128(0x04)
	int32_t MaxImpactEndurance; // 0x12c(0x04)
	int32_t ExecAddHealthByCurHealthRatio; // 0x130(0x04)
	int32_t ExecAddHealthByMaxHealthRatio; // 0x134(0x04)
	int32_t PhysicalHealBase; // 0x138(0x04)
	int32_t ExecPhysicalHealBase; // 0x13c(0x04)
	int32_t MagicalHealBase; // 0x140(0x04)
	int32_t ExecMagicalHealBase; // 0x144(0x04)
	int32_t ExecRecoveryHealBase; // 0x148(0x04)
	int32_t MaxHealthMod; // 0x14c(0x04)
	int32_t MaxHealthAdd; // 0x150(0x04)
	int32_t AddtionalAggroMod; // 0x154(0x04)
	int32_t MaxPhysicalShield; // 0x158(0x04)
	int32_t MaxMagicalShield; // 0x15c(0x04)
	int32_t MaxTotalShield; // 0x160(0x04)
	int32_t SpellCapacityMod; // 0x164(0x04)
	int32_t SpellCapacityAdd; // 0x168(0x04)
	int32_t MoveSpeedBase; // 0x16c(0x04)
	int32_t MoveSpeedMod; // 0x170(0x04)
	int32_t MoveSpeedAdd; // 0x174(0x04)
	int32_t MoveSpeedArmorPenaltyMod; // 0x178(0x04)
	int32_t ActionSpeed; // 0x17c(0x04)
	int32_t SpellCastingSpeed; // 0x180(0x04)
	int32_t ItemEquipSpeed; // 0x184(0x04)
	int32_t RegularInteractionSpeed; // 0x188(0x04)
	int32_t MagicalInteractionSpeed; // 0x18c(0x04)
	int32_t BuffDurationMod; // 0x190(0x04)
	int32_t DebuffDurationMod; // 0x194(0x04)
	int32_t UtilityEffectivenessMod; // 0x198(0x04)
	int32_t UtilityEffectivenessAdd; // 0x19c(0x04)
	int32_t WeightLimitMod; // 0x1a0(0x04)
	int32_t WeightLimitAdd; // 0x1a4(0x04)
	int32_t PrestigeItemDrop; // 0x1a8(0x04)
	char pad_1AC[0x4]; // 0x1ac(0x04)
	struct TArray<struct FGameplayTag> Tags; // 0x1b0(0x10)
};

// Class DungeonCrawler.DCMovementModifierDataAsset
// Size: 0x40 (Inherited: 0x38)
struct UDCMovementModifierDataAsset : UDCDataAsset {
	int32_t Add; // 0x38(0x04)
	float Multiply; // 0x3c(0x04)
};

// Class DungeonCrawler.DCGameplayAbilityDataAsset
// Size: 0xb0 (Inherited: 0x38)
struct UDCGameplayAbilityDataAsset : UDCDataAsset {
	struct FText Name; // 0x38(0x18)
	struct FGameplayTag AttackType; // 0x50(0x08)
	struct UGameplayAbility* Class; // 0x58(0x08)
	struct TArray<struct TSoftObjectPtr<UDCGameplayEffectDataAsset>> Effects; // 0x60(0x10)
	struct TSoftObjectPtr<UDescData> Desc; // 0x70(0x30)
	struct TArray<struct TSoftObjectPtr<UDCMovementModifierDataAsset>> MovementModifiers; // 0xa0(0x10)
};

// Class DungeonCrawler.DCGameplayCueManager
// Size: 0x310 (Inherited: 0x310)
struct UDCGameplayCueManager : UGameplayCueManager {
	struct FGameplayCueObjectLibrary RuntimeGameplayCueObjectLibrary; // 0x48(0x50)
	struct FGameplayCueObjectLibrary EditorGameplayCueObjectLibrary; // 0x98(0x50)
	struct TArray<ClassPtrProperty> LoadedGameplayCueNotifyClasses; // 0x2b0(0x10)
	struct TArray<struct AGameplayCueNotify_Actor*> GameplayCueClassesForPreallocation; // 0x2c0(0x10)
	struct TArray<struct FGameplayCuePendingExecute> PendingExecuteCues; // 0x2d0(0x10)
	int32_t GameplayCueSendContextCount; // 0x2e0(0x04)
	struct TArray<struct FPreallocationInfo> PreallocationInfoList_Internal; // 0x2e8(0x10)
};

// Class DungeonCrawler.DCGameplayCueNotify_Actor
// Size: 0x308 (Inherited: 0x2f0)
struct ADCGameplayCueNotify_Actor : AGameplayCueNotify_Actor {
	bool bAutoDestroyOnRemove; // 0x290(0x01)
	float AutoDestroyDelay; // 0x294(0x04)
	bool WarnIfTimelineIsStillRunning; // 0x298(0x01)
	bool WarnIfLatentActionIsStillRunning; // 0x299(0x01)
	struct FGameplayTag GameplayCueTag; // 0x29c(0x08)
	struct FName GameplayCueName; // 0x2a4(0x08)
	bool bAutoAttachToOwner; // 0x2ac(0x01)
	bool IsOverride; // 0x2ad(0x01)
	bool bUniqueInstancePerInstigator; // 0x2ae(0x01)
	bool bUniqueInstancePerSourceObject; // 0x2af(0x01)
	bool bAllowMultipleOnActiveEvents; // 0x2b0(0x01)
	bool bAllowMultipleWhileActiveEvents; // 0x2b1(0x01)
	int32_t NumPreallocatedInstances; // 0x2b4(0x04)

	void SetAkComponentRTPCValue(struct UAkComponent* AkComponent, struct UAkRtpc* RtpcValue, float InTickValue, float InTotalValue, float InMaxRTPCValue); // Function DungeonCrawler.DCGameplayCueNotify_Actor.SetAkComponentRTPCValue // (None) // @ game+0xffffbdaadf830041
};

// Class DungeonCrawler.DCGameplayEffectUIData
// Size: 0x30 (Inherited: 0x28)
struct UDCGameplayEffectUIData : UGameplayEffectUIData {
	struct UActorStatusUIData* UIDataAsset; // 0x28(0x08)
};

// Class DungeonCrawler.DCGameplayTagCollider
// Size: 0x3e0 (Inherited: 0x2f0)
struct ADCGameplayTagCollider : ADCActorBase {
	struct UAccountLink* OwnerAccountLink; // 0x2f0(0x08)
	struct FString OwnerAccountId; // 0x2f8(0x10)
	struct FString TargetAccountId; // 0x308(0x10)
	struct UAccountLink* TargetAccountLink; // 0x318(0x08)
	struct TWeakObjectPtr<struct APawn> TargetPlayerPawn; // 0x320(0x08)
	struct FAccountDataReplication TargetAccountDataReplication; // 0x328(0x78)
	struct FGameplayTagContainer TargetOwnedGameplayeTags; // 0x3a0(0x20)
	float ColliderRadius; // 0x3c0(0x04)
	char pad_3C4[0x4]; // 0x3c4(0x04)
	struct USphereComponent* GameplayTagOverlapSphere; // 0x3c8(0x08)
	struct TArray<struct UDCTagCollisionDetectorComponent*> OverlapDetectorComponentArray; // 0x3d0(0x10)

	void OnRep_TargetAccountId(struct FString InOldTargetAccountId); // Function DungeonCrawler.DCGameplayTagCollider.OnRep_TargetAccountId // (None) // @ game+0xffffbdaedf830041
};

// Class DungeonCrawler.DCGameSession
// Size: 0x488 (Inherited: 0x2a8)
struct ADCGameSession : AGameSession {
	char pad_2A8[0xf8]; // 0x2a8(0xf8)
	struct FDCGameplayEffectData RespawnGameplayEffectData; // 0x3a0(0x48)
	char pad_3E8[0x50]; // 0x3e8(0x50)
	struct FPrimaryAssetId MaxPerkSlotCountConstant; // 0x438(0x10)
	struct FPrimaryAssetId MaxSkillSlotCountConstant; // 0x448(0x10)
	struct FPrimaryAssetId AdvPointPlayerKillConstant; // 0x458(0x10)
	struct FPrimaryAssetId AdvPointDungeonDownConstant; // 0x468(0x10)
	struct FPrimaryAssetId ExpPointDungeonDownConstant; // 0x478(0x10)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCGameSession.UnbindMsgAll // (None) // @ game+0xffffbdb3df830041
};

// Class DungeonCrawler.DCGameSettings
// Size: 0x48 (Inherited: 0x38)
struct UDCGameSettings : UDeveloperSettings {
	struct TArray<struct FServerInfo> ServerList; // 0x38(0x10)
};

// Class DungeonCrawler.DCGameSpawner
// Size: 0x368 (Inherited: 0x2f0)
struct ADCGameSpawner : ADCActorBase {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	struct UDesignDataAssetSpawner* DesignDataAssetSpawner; // 0x2f8(0x08)
	float RandomScaleMin; // 0x300(0x04)
	float RandomScaleMax; // 0x304(0x04)
	struct TArray<struct ATargetPoint*> TargetPoints; // 0x308(0x10)
	struct FDesignDataSpawnerItem DesignDataSpawnerItem; // 0x318(0x34)
	int32_t PreviewIdx; // 0x34c(0x04)
	struct FPrimaryAssetId PreviewAssetId; // 0x350(0x10)
	struct AActor* PreviewActor; // 0x360(0x08)

	void UpdateGameState(struct FGameStateData& InGameStateData); // Function DungeonCrawler.DCGameSpawner.UpdateGameState // (None) // @ game+0xffffbdbadf830041
};

// Class DungeonCrawler.DCGameSpawnerGroup
// Size: 0x2f8 (Inherited: 0x2f0)
struct ADCGameSpawnerGroup : ADCActorBase {
	int32_t Count; // 0x2f0(0x04)
	char pad_2F4[0x4]; // 0x2f4(0x04)
};

// Class DungeonCrawler.DCGameUserSettings
// Size: 0x3d0 (Inherited: 0x148)
struct UDCGameUserSettings : UGameUserSettings {
	char pad_148[0x8]; // 0x148(0x08)
	struct FMulticastInlineDelegate OnAudioChanged; // 0x150(0x10)
	char pad_160[0x68]; // 0x160(0x68)
	struct FName InputConfigName; // 0x1c8(0x08)
	struct TArray<struct FLoadedMappableConfigPair> RegisteredInputConfigs; // 0x1d0(0x10)
	struct TMap<struct FName, struct FKey> CustomKeyboardConfig; // 0x1e0(0x50)
	struct TMap<struct FName, struct FKey> PendingCustomKeyboardConfig; // 0x230(0x50)
	struct FString LastConnectedServerAddress; // 0x280(0x10)
	struct FGameUserSettingControls GameUserSettingControls; // 0x290(0x28)
	char pad_2B8[0x28]; // 0x2b8(0x28)
	struct FGameUserSettingAudios GameUserSettingAudios; // 0x2e0(0x28)
	char pad_308[0x50]; // 0x308(0x50)
	struct FGameUserSettingVideoDisplay UserSettingVideoDisplay; // 0x358(0x18)
	char pad_370[0x60]; // 0x370(0x60)

	struct UPlayerMappableInputConfig* GetInputConfigByName(struct FName ConfigName); // Function DungeonCrawler.DCGameUserSettings.GetInputConfigByName // (None) // @ game+0xffffbe05df830041
};

// Class DungeonCrawler.DCGATA_AimTrace
// Size: 0x3f0 (Inherited: 0x3e0)
struct ADCGATA_AimTrace : AGameplayAbilityTargetActor {
	float MaxRange; // 0x3e0(0x04)
	enum class ECollisionChannel TraceChannel; // 0x3e4(0x01)
	char pad_3E5[0xb]; // 0x3e5(0x0b)
};

// Class DungeonCrawler.DCGATA_AimTraceOnServer
// Size: 0x3f0 (Inherited: 0x3f0)
struct ADCGATA_AimTraceOnServer : ADCGATA_AimTrace {
	float MaxRange; // 0x3e0(0x04)
	enum class ECollisionChannel TraceChannel; // 0x3e4(0x01)
};

// Class DungeonCrawler.DCGATA_AimTraceWithSphere
// Size: 0x3f0 (Inherited: 0x3e0)
struct ADCGATA_AimTraceWithSphere : AGameplayAbilityTargetActor {
	float MaxRange; // 0x3e0(0x04)
	float Radius; // 0x3e4(0x04)
	enum class ECollisionChannel TraceChannel; // 0x3e8(0x01)
	char pad_3E9[0x7]; // 0x3e9(0x07)
};

// Class DungeonCrawler.DCGATA_AimTraceSphereOnServer
// Size: 0x3f0 (Inherited: 0x3f0)
struct ADCGATA_AimTraceSphereOnServer : ADCGATA_AimTraceWithSphere {
	float MaxRange; // 0x3e0(0x04)
	float Radius; // 0x3e4(0x04)
	enum class ECollisionChannel TraceChannel; // 0x3e8(0x01)
};

// Class DungeonCrawler.DCGATA_AimTraceToSocket
// Size: 0x440 (Inherited: 0x3f0)
struct ADCGATA_AimTraceToSocket : ADCGATA_AimTrace {
	struct FMulticastInlineDelegate SocketSightBlocked; // 0x3e8(0x10)
	struct FMulticastInlineDelegate SocketSightUnblocked; // 0x3f8(0x10)
	struct USkeletalMeshComponent* SkeletalMeshComponent; // 0x408(0x08)
	struct FName SocketName; // 0x410(0x08)
	struct FGameplayAbilityTargetDataHandle TargetData; // 0x418(0x28)
};

// Class DungeonCrawler.DCGATA_GroundTraceWithMaxHeight
// Size: 0x420 (Inherited: 0x420)
struct ADCGATA_GroundTraceWithMaxHeight : AGameplayAbilityTargetActor_GroundTrace {
	float MaxHeight; // 0x418(0x04)
};

// Class DungeonCrawler.DCGATA_LineCollision
// Size: 0x500 (Inherited: 0x3e0)
struct ADCGATA_LineCollision : AGameplayAbilityTargetActor {
	struct FCollisionProfileName TraceProfile; // 0x3e0(0x08)
	bool bIgnoreBlockingHits; // 0x3e8(0x01)
	bool bShowDebug; // 0x3e9(0x01)
	char pad_3EA[0x2]; // 0x3ea(0x02)
	float DebugLineDrawTime; // 0x3ec(0x04)
	char pad_3F0[0x110]; // 0x3f0(0x110)
};

// Class DungeonCrawler.DCGATA_LineTraceInteractable
// Size: 0x4c0 (Inherited: 0x3e0)
struct ADCGATA_LineTraceInteractable : AGameplayAbilityTargetActor {
	struct FMulticastInlineDelegate FoundNewInteractableTarget; // 0x3e0(0x10)
	struct FMulticastInlineDelegate LostInteractableTarget; // 0x3f0(0x10)
	float MaxRange; // 0x400(0x04)
	float Radius; // 0x404(0x04)
	char pad_408[0xb8]; // 0x408(0xb8)
};

// Class DungeonCrawler.DCGeometryCollectionComponent
// Size: 0xb10 (Inherited: 0xb10)
struct UDCGeometryCollectionComponent : UGeometryCollectionComponent {
	struct AChaosSolverActor* ChaosSolverActor; // 0x578(0x08)
	struct UGeometryCollection* RestCollection; // 0x668(0x08)
	struct TArray<struct AFieldSystemActor*> InitializationFields; // 0x670(0x10)
	bool Simulating; // 0x680(0x01)
	enum class EObjectStateTypeEnum ObjectType; // 0x688(0x01)
	bool bForceMotionBlur; // 0x689(0x01)
	bool EnableClustering; // 0x68a(0x01)
	int32_t ClusterGroupIndex; // 0x68c(0x04)
	int32_t MaxClusterLevel; // 0x690(0x04)
	struct TArray<float> DamageThreshold; // 0x698(0x10)
	bool bUseSizeSpecificDamageThreshold; // 0x6a8(0x01)
	struct FGeometryCollectionDamagePropagationData DamagePropagationData; // 0x6ac(0x0c)
	bool bAllowRemovalOnSleep; // 0x6b8(0x01)
	bool bAllowRemovalOnBreak; // 0x6b9(0x01)
	enum class EClusterConnectionTypeEnum ClusterConnectionType; // 0x6ba(0x01)
	int32_t CollisionGroup; // 0x6bc(0x04)
	float CollisionSampleFraction; // 0x6c0(0x04)
	float LinearEtherDrag; // 0x6c4(0x04)
	float AngularEtherDrag; // 0x6c8(0x04)
	struct UChaosPhysicalMaterial* PhysicalMaterial; // 0x6d0(0x08)
	enum class EInitialVelocityTypeEnum InitialVelocityType; // 0x6d8(0x01)
	struct FVector InitialLinearVelocity; // 0x6e0(0x18)
	struct FVector InitialAngularVelocity; // 0x6f8(0x18)
	struct UPhysicalMaterial* PhysicalMaterialOverride; // 0x710(0x08)
	struct FGeomComponentCacheParameters CacheParameters; // 0x718(0x50)
	struct TArray<struct FTransform> RestTransforms; // 0x768(0x10)
	struct FMulticastInlineDelegate NotifyGeometryCollectionPhysicsStateChange; // 0x778(0x10)
	struct FMulticastInlineDelegate NotifyGeometryCollectionPhysicsLoadingStateChange; // 0x788(0x10)
	struct FMulticastInlineDelegate OnChaosBreakEvent; // 0x7b0(0x10)
	struct FMulticastInlineDelegate OnChaosRemovalEvent; // 0x7c0(0x10)
	struct FMulticastInlineDelegate OnChaosCrumblingEvent; // 0x7d0(0x10)
	float DesiredCacheTime; // 0x7e0(0x04)
	bool CachePlayback; // 0x7e4(0x01)
	struct FMulticastInlineDelegate OnChaosPhysicsCollision; // 0x7e8(0x10)
	bool bNotifyBreaks; // 0x7f8(0x01)
	bool bNotifyCollisions; // 0x7f9(0x01)
	bool bNotifyTrailing; // 0x7fa(0x01)
	bool bNotifyRemovals; // 0x7fb(0x01)
	bool bNotifyCrumblings; // 0x7fc(0x01)
	bool bCrumblingEventIncludesChildren; // 0x7fd(0x01)
	bool bStoreVelocities; // 0x7fe(0x01)
	bool bShowBoneColors; // 0x7ff(0x01)
	struct AGeometryCollectionISMPoolActor* ISMPool; // 0x800(0x08)
	bool bEnableReplication; // 0x80c(0x01)
	bool bEnableAbandonAfterLevel; // 0x80d(0x01)
	int32_t ReplicationAbandonClusterLevel; // 0x810(0x04)
	int32_t ReplicationAbandonAfterLevel; // 0x814(0x04)
	struct FGeometryCollectionRepData RepData; // 0x818(0x28)
	struct UBodySetup* DummyBodySetup; // 0xac8(0x08)
	struct TArray<struct UInstancedStaticMeshComponent*> EmbeddedGeometryComponents; // 0xad8(0x10)
};

// Class DungeonCrawler.DCGhostTrailActor
// Size: 0x3e8 (Inherited: 0x2f0)
struct ADCGhostTrailActor : ADCActorBase {
	struct UMaterialInterface* GhostTrailMaterial; // 0x2f0(0x08)
	struct FName ScalarParameterName; // 0x2f8(0x08)
	struct UCurveFloat* OpacityCurve; // 0x300(0x08)
	struct ACharacter* CharacterRef; // 0x308(0x08)
	struct FLinearColor Color; // 0x310(0x10)
	bool bAutoActive; // 0x320(0x01)
	char pad_321[0x7]; // 0x321(0x07)
	struct UPoseableMeshComponent* PoseableMeshComp; // 0x328(0x08)
	struct TArray<struct UMeshComponent*> AttachedMeshComp; // 0x330(0x10)
	struct USceneComponent* SceneRootComp; // 0x340(0x08)
	struct FTimeline OpacityTimeline; // 0x348(0x98)
	struct UMaterialInstanceDynamic* DynamicMatInstance; // 0x3e0(0x08)

	void SetGhostMaterial(struct TArray<struct UMeshComponent*> Components); // Function DungeonCrawler.DCGhostTrailActor.SetGhostMaterial // (None) // @ game+0xffffbe09df830041
};

// Class DungeonCrawler.DCGiftCodeEditableText
// Size: 0x500 (Inherited: 0x4e0)
struct UDCGiftCodeEditableText : UEditableText {
	char pad_4E0[0x18]; // 0x4e0(0x18)
	int32_t Index; // 0x4f8(0x04)
	char pad_4FC[0x4]; // 0x4fc(0x04)

	void OnGiftCodeWipedEvent__DelegateSignature(int32_t& Index); // DelegateFunction DungeonCrawler.DCGiftCodeEditableText.OnGiftCodeWipedEvent__DelegateSignature // (None) // @ game+0xffff9831df830041
};

// Class DungeonCrawler.DCGiftCodePopupData
// Size: 0x30 (Inherited: 0x30)
struct UDCGiftCodePopupData : UPopupDataBase {
};

// Class DungeonCrawler.DCGiftCodePopupBase
// Size: 0x498 (Inherited: 0x440)
struct UDCGiftCodePopupBase : UCommonPopupBase {
	struct UDCGiftCodeEditableText* EnterCode_2; // 0x440(0x08)
	struct UDCGiftCodeEditableText* EnterCode_3; // 0x448(0x08)
	struct UDCGiftCodeEditableText* EnterCode_4; // 0x450(0x08)
	struct UDCGiftCodeEditableText* EnterCode_5; // 0x458(0x08)
	struct UCommonButtonPopupWidget* Btn_Two_Close; // 0x460(0x08)
	struct UCommonButtonPopupWidget* Btn_Two_Accept; // 0x468(0x08)
	char pad_470[0x8]; // 0x470(0x08)
	struct TArray<struct UDCGiftCodeEditableText*> EnterCodeList; // 0x478(0x10)
	char pad_488[0x10]; // 0x488(0x10)

	void OnAcceptButtonClicked(); // Function DungeonCrawler.DCGiftCodePopupBase.OnAcceptButtonClicked // (None) // @ game+0xffffbe0edf830041
};

// Class DungeonCrawler.DCHitBoxComponent
// Size: 0x580 (Inherited: 0x580)
struct UDCHitBoxComponent : UBoxComponent {
	enum class EHitBoxType HitBoxType; // 0x578(0x01)
	float DamageMultiplier; // 0x57c(0x04)

	struct FHitResult GetHitResultFromClosestLocationTraceOnMesh(struct FHitResult& InHitResult, struct AActor* Instigator); // Function DungeonCrawler.DCHitBoxComponent.GetHitResultFromClosestLocationTraceOnMesh // (None) // @ game+0xffffbe11df830041
};

// Class DungeonCrawler.DCHudWidgetBase
// Size: 0x300 (Inherited: 0x300)
struct UDCHudWidgetBase : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)
};

// Class DungeonCrawler.DCIdTagGroupItemDataAsset
// Size: 0x48 (Inherited: 0x38)
struct UDCIdTagGroupItemDataAsset : UDCDataAsset {
	struct TArray<struct FDCIdTagGroupItemData> IdTagGroupItemArray; // 0x38(0x10)
};

// Class DungeonCrawler.DCIngameGameSession
// Size: 0x488 (Inherited: 0x488)
struct ADCIngameGameSession : ADCGameSession {
	struct FDCGameplayEffectData RespawnGameplayEffectData; // 0x3a0(0x48)
	struct FPrimaryAssetId MaxPerkSlotCountConstant; // 0x438(0x10)
	struct FPrimaryAssetId MaxSkillSlotCountConstant; // 0x448(0x10)
	struct FPrimaryAssetId AdvPointPlayerKillConstant; // 0x458(0x10)
	struct FPrimaryAssetId AdvPointDungeonDownConstant; // 0x468(0x10)
	struct FPrimaryAssetId ExpPointDungeonDownConstant; // 0x478(0x10)
};

// Class DungeonCrawler.DCInventoryContainerComponent
// Size: 0x180 (Inherited: 0xa0)
struct UDCInventoryContainerComponent : UActorComponent {
	char pad_A0[0xd0]; // 0xa0(0xd0)
	struct TArray<struct UDCInventoryBase*> InventoryList; // 0x170(0x10)

	void RemoveInventory_Server(enum class EDCInventoryId ID); // Function DungeonCrawler.DCInventoryContainerComponent.RemoveInventory_Server // (None) // @ game+0xffffbe17df830041
};

// Class DungeonCrawler.DCInventoryComponent
// Size: 0x180 (Inherited: 0x180)
struct UDCInventoryComponent : UDCInventoryContainerComponent {
	struct TArray<struct UDCInventoryBase*> InventoryList; // 0x170(0x10)

	void InitFromData_Server(struct TArray<struct FAccountDataItem> ItemDatas); // Function DungeonCrawler.DCInventoryComponent.InitFromData_Server // (None) // @ game+0xffffbe19df830041
};

// Class DungeonCrawler.DCIngameInventoryComponent
// Size: 0x180 (Inherited: 0x180)
struct UDCIngameInventoryComponent : UDCInventoryComponent {
	struct TArray<struct UDCInventoryBase*> InventoryList; // 0x170(0x10)
};

// Class DungeonCrawler.DCInventoryControllerComponent
// Size: 0xc0 (Inherited: 0xa0)
struct UDCInventoryControllerComponent : UActorComponent {
	struct UDCInventoryComponent* InventoryComponent; // 0xa0(0x08)
	char pad_A8[0x18]; // 0xa8(0x18)

	void OnItemMoveEvent_Client(enum class EDCInventoryId SourceInventoryId, struct FDCItemInfo SourceItemInfo, enum class EDCInventoryId TargetInventoryId, int32_t TargetIndex, int32_t TargetStack); // Function DungeonCrawler.DCInventoryControllerComponent.OnItemMoveEvent_Client // (None) // @ game+0xffffbe1bdf830041
};

// Class DungeonCrawler.DCIngameInventoryControllerComponent
// Size: 0xc0 (Inherited: 0xc0)
struct UDCIngameInventoryControllerComponent : UDCInventoryControllerComponent {
	struct UDCInventoryComponent* InventoryComponent; // 0xa0(0x08)
};

// Class DungeonCrawler.DCIngameInventoryPageWidget
// Size: 0x480 (Inherited: 0x460)
struct UDCIngameInventoryPageWidget : UGameGroupWidgetBase {
	struct UDCInventoryWidget* PlayerInventoryWidget; // 0x460(0x08)
	struct UDCInventoryWidget* LootInventoryWidget; // 0x468(0x08)
	struct UDCStorageWidget* LootStorageWidget; // 0x470(0x08)
	struct UInvalidationBox* ItemDropAreaWidget; // 0x478(0x08)

	void OnTargetCharacterRegistered(struct ADCCharacterBase* InCharacter); // Function DungeonCrawler.DCIngameInventoryPageWidget.OnTargetCharacterRegistered // (None) // @ game+0xffffbe20df830041
};

// Class DungeonCrawler.DCIngameUserManager
// Size: 0x178 (Inherited: 0x30)
struct UDCIngameUserManager : UDCUserInfoManagerBase {
	struct TMap<struct FDCAccountId, struct FDCIngameUser> IngameUsers; // 0x30(0x50)
	char pad_80[0xf8]; // 0x80(0xf8)
};

// Class DungeonCrawler.DCInputComponent
// Size: 0x160 (Inherited: 0x160)
struct UDCInputComponent : UEnhancedInputComponent {
	struct TArray<struct FCachedKeyToActionInfo> CachedKeyToActionInfo; // 0x110(0x10)
};

// Class DungeonCrawler.DCInputConfig
// Size: 0x40 (Inherited: 0x30)
struct UDCInputConfig : UDataAsset {
	struct TArray<struct FDCInputAction> NativeInputActions; // 0x30(0x10)
};

// Class DungeonCrawler.DCInputConfigData
// Size: 0xd0 (Inherited: 0x30)
struct UDCInputConfigData : UDataAsset {
	struct TMap<struct FGameplayTag, struct UPlayerMappableInputConfig*> PlayerMappableInputConfigMap; // 0x30(0x50)
	struct TMap<struct FGameplayTag, struct UDCInputConfig*> InputConfigMap; // 0x80(0x50)
};

// Class DungeonCrawler.DCInputNumberWidget
// Size: 0x2b0 (Inherited: 0x278)
struct UDCInputNumberWidget : UUserWidget {
	char pad_278[0x20]; // 0x278(0x20)
	struct USlider* Slider; // 0x298(0x08)
	struct UCommonButtonPopupWidget* ButtonAccept; // 0x2a0(0x08)
	struct UCommonButtonPopupWidget* ButtonCancel; // 0x2a8(0x08)

	void OnCancelled(); // Function DungeonCrawler.DCInputNumberWidget.OnCancelled // (None) // @ game+0xffffbe24df830041
};

// Class DungeonCrawler.DCInteractTargetInterface
// Size: 0x28 (Inherited: 0x28)
struct UDCInteractTargetInterface : UInterface {

	void InteractTargetInfoRarity(struct FGameplayTag& RarityTag); // Function DungeonCrawler.DCInteractTargetInterface.InteractTargetInfoRarity // (None) // @ game+0xffffbe26df830041
};

// Class DungeonCrawler.DCInventorySetWidget
// Size: 0x2e8 (Inherited: 0x2c0)
struct UDCInventorySetWidget : UDCInventoryWidgetBase {
	struct UDCPlayerInventoryWidget* PlayerInventoryWidgetClass; // 0x2c0(0x08)
	struct UDCBagWidget* StorageWidgetClass; // 0x2c8(0x08)
	struct UDCInventoryTabButtonWidget* TabButtonWidgetClass; // 0x2d0(0x08)
	struct UWidgetSwitcher* WidgetSwitcher; // 0x2d8(0x08)
	struct UVerticalBox* TabBox; // 0x2e0(0x08)

	void SetIndex(int32_t InIndex); // Function DungeonCrawler.DCInventorySetWidget.SetIndex // (None) // @ game+0xffffbe27df830041
};

// Class DungeonCrawler.DCStateButtonWidgetBase
// Size: 0x338 (Inherited: 0x320)
struct UDCStateButtonWidgetBase : UDCCommonButtonBase {
	struct UCommonButtonBase* Btn_Common; // 0x300(0x08)
	struct FMulticastInlineDelegate OnCommonButtonClick; // 0x308(0x10)
	struct UAkAudioEvent* ClickSound; // 0x318(0x08)

	void SetActive(bool bState); // Function DungeonCrawler.DCStateButtonWidgetBase.SetActive // (None) // @ game+0xffffbe29df830041
};

// Class DungeonCrawler.DCInventoryTabButtonWidget
// Size: 0x338 (Inherited: 0x338)
struct UDCInventoryTabButtonWidget : UDCStateButtonWidgetBase {
	struct UCommonButtonBase* Btn_Common; // 0x300(0x08)
	struct FMulticastInlineDelegate OnCommonButtonClick; // 0x308(0x10)
	struct UAkAudioEvent* ClickSound; // 0x318(0x08)

	void SetEquipment(bool bState); // Function DungeonCrawler.DCInventoryTabButtonWidget.SetEquipment // (None) // @ game+0xffffbe2adf830041
};

// Class DungeonCrawler.DCInventoryWidget
// Size: 0x2d0 (Inherited: 0x2c0)
struct UDCInventoryWidget : UDCInventoryWidgetBase {
	struct UDCEquipmentWidget* EquipWidget; // 0x2c0(0x08)
	struct UDCBagWidget* BagWidget; // 0x2c8(0x08)
};

// Class DungeonCrawler.DCItemActorAttributeSet
// Size: 0x680 (Inherited: 0x680)
struct UDCItemActorAttributeSet : UDCAttributeSet {
	struct FGameplayAttributeData Strength; // 0x30(0x10)
	struct FGameplayAttributeData StrengthBase; // 0x40(0x10)
	struct FGameplayAttributeData StrengthMod; // 0x50(0x10)
	struct FGameplayAttributeData Agility; // 0x60(0x10)
	struct FGameplayAttributeData AgilityBase; // 0x70(0x10)
	struct FGameplayAttributeData AgilityMod; // 0x80(0x10)
	struct FGameplayAttributeData Will; // 0x90(0x10)
	struct FGameplayAttributeData WillBase; // 0xa0(0x10)
	struct FGameplayAttributeData WillMod; // 0xb0(0x10)
	struct FGameplayAttributeData Knowledge; // 0xc0(0x10)
	struct FGameplayAttributeData KnowledgeBase; // 0xd0(0x10)
	struct FGameplayAttributeData KnowledgeMod; // 0xe0(0x10)
	struct FGameplayAttributeData Resourcefulness; // 0xf0(0x10)
	struct FGameplayAttributeData ResourcefulnessBase; // 0x100(0x10)
	struct FGameplayAttributeData ResourcefulnessMod; // 0x110(0x10)
	struct FGameplayAttributeData PhysicalDamageWeaponPrimary; // 0x120(0x10)
	struct FGameplayAttributeData PhysicalDamageWeaponSecondary; // 0x130(0x10)
	struct FGameplayAttributeData PhysicalDamageBase; // 0x140(0x10)
	struct FGameplayAttributeData PhysicalPower; // 0x150(0x10)
	struct FGameplayAttributeData PhysicalDamageMod; // 0x160(0x10)
	struct FGameplayAttributeData PhysicalDamageAdd; // 0x170(0x10)
	struct FGameplayAttributeData PhysicalDamageTrue; // 0x180(0x10)
	struct FGameplayAttributeData PhysicalBackstabPower; // 0x190(0x10)
	struct FGameplayAttributeData PhysicalHeadshotPower; // 0x1a0(0x10)
	struct FGameplayAttributeData PhysicalHeadshotPenetration; // 0x1b0(0x10)
	struct FGameplayAttributeData ArmorPenetration; // 0x1c0(0x10)
	struct FGameplayAttributeData ArmorRating; // 0x1d0(0x10)
	struct FGameplayAttributeData ItemArmorRating; // 0x1e0(0x10)
	struct FGameplayAttributeData ItemArmorRatingMod; // 0x1f0(0x10)
	struct FGameplayAttributeData PhysicalReduction; // 0x200(0x10)
	struct FGameplayAttributeData PhysicalReductionMod; // 0x210(0x10)
	struct FGameplayAttributeData PhysicalAbsoluteReduction; // 0x220(0x10)
	struct FGameplayAttributeData MagicalDamageWeaponPrimary; // 0x230(0x10)
	struct FGameplayAttributeData MagicalDamageWeaponSecondary; // 0x240(0x10)
	struct FGameplayAttributeData MagicalDamageBase; // 0x250(0x10)
	struct FGameplayAttributeData MagicalPower; // 0x260(0x10)
	struct FGameplayAttributeData MagicalDamageMod; // 0x270(0x10)
	struct FGameplayAttributeData MagicalDamageAdd; // 0x280(0x10)
	struct FGameplayAttributeData MagicalDamageTrue; // 0x290(0x10)
	struct FGameplayAttributeData MagicPenetration; // 0x2a0(0x10)
	struct FGameplayAttributeData MagicalFireDamageBase; // 0x2b0(0x10)
	struct FGameplayAttributeData MagicalFireDamageMod; // 0x2c0(0x10)
	struct FGameplayAttributeData MagicalFireDamageAdd; // 0x2d0(0x10)
	struct FGameplayAttributeData MagicalArcaneDamageBase; // 0x2e0(0x10)
	struct FGameplayAttributeData MagicalArcaneDamageMod; // 0x2f0(0x10)
	struct FGameplayAttributeData MagicalArcaneDamageAdd; // 0x300(0x10)
	struct FGameplayAttributeData MagicResistance; // 0x310(0x10)
	struct FGameplayAttributeData MagicalReduction; // 0x320(0x10)
	struct FGameplayAttributeData MagicalReductionMod; // 0x330(0x10)
	struct FGameplayAttributeData MagicalAbsoluteReduction; // 0x340(0x10)
	struct FGameplayAttributeData HeadshotReductionMod; // 0x350(0x10)
	struct FGameplayAttributeData ProjectileReductionMod; // 0x360(0x10)
	struct FGameplayAttributeData ImpactPower; // 0x370(0x10)
	struct FGameplayAttributeData ImpactResistance; // 0x380(0x10)
	struct FGameplayAttributeData ImpactEndurance; // 0x390(0x10)
	struct FGameplayAttributeData MaxImpactEndurance; // 0x3a0(0x10)
	struct FGameplayAttributeData PhysicalHealBase; // 0x3b8(0x10)
	struct FGameplayAttributeData MagicalHealBase; // 0x3c8(0x10)
	struct FGameplayAttributeData RecoverableHealth; // 0x3d8(0x10)
	struct FGameplayAttributeData Health; // 0x3e8(0x10)
	struct FGameplayAttributeData MaxHealth; // 0x3f8(0x10)
	struct FGameplayAttributeData MaxHealthBase; // 0x410(0x10)
	struct FGameplayAttributeData MaxHealthMod; // 0x420(0x10)
	struct FGameplayAttributeData MaxHealthAdd; // 0x430(0x10)
	struct FGameplayAttributeData PhysicalShield; // 0x440(0x10)
	struct FGameplayAttributeData MaxPhysicalShield; // 0x450(0x10)
	struct FGameplayAttributeData MagicalShield; // 0x460(0x10)
	struct FGameplayAttributeData MaxMagicalShield; // 0x470(0x10)
	struct FGameplayAttributeData TotalShield; // 0x480(0x10)
	struct FGameplayAttributeData MaxTotalShield; // 0x490(0x10)
	struct FGameplayAttributeData SpellPayload; // 0x4a0(0x10)
	struct FGameplayAttributeData SpellCapacity; // 0x4b0(0x10)
	struct FGameplayAttributeData SpellCapacityBase; // 0x4c0(0x10)
	struct FGameplayAttributeData SpellCapacityMod; // 0x4d0(0x10)
	struct FGameplayAttributeData SpellCapacityAdd; // 0x4e0(0x10)
	struct FGameplayAttributeData MoveSpeed; // 0x4f0(0x10)
	struct FGameplayAttributeData MoveSpeedBase; // 0x500(0x10)
	struct FGameplayAttributeData MoveSpeedMod; // 0x510(0x10)
	struct FGameplayAttributeData MoveSpeedAdd; // 0x520(0x10)
	struct FGameplayAttributeData MoveSpeedArmorPenalty; // 0x530(0x10)
	struct FGameplayAttributeData MoveSpeedArmorPenaltyMod; // 0x540(0x10)
	struct FGameplayAttributeData MoveSpeedWithModifier; // 0x550(0x10)
	struct FGameplayAttributeData ActionSpeed; // 0x560(0x10)
	struct FGameplayAttributeData SpellCastingSpeed; // 0x570(0x10)
	struct FGameplayAttributeData ItemEquipSpeed; // 0x580(0x10)
	struct FGameplayAttributeData RegularInteractionSpeedBase; // 0x590(0x10)
	struct FGameplayAttributeData RegularInteractionSpeed; // 0x5a0(0x10)
	struct FGameplayAttributeData MagicalInteractionSpeed; // 0x5b0(0x10)
	struct FGameplayAttributeData BuffDurationMod; // 0x5c0(0x10)
	struct FGameplayAttributeData DebuffDurationMod; // 0x5d0(0x10)
	struct FGameplayAttributeData UtilityEffectiveness; // 0x5e0(0x10)
	struct FGameplayAttributeData UtilityEffectivenessBase; // 0x5f0(0x10)
	struct FGameplayAttributeData UtilityEffectivenessMod; // 0x600(0x10)
	struct FGameplayAttributeData UtilityEffectivenessAdd; // 0x610(0x10)
	struct FGameplayAttributeData Weight; // 0x620(0x10)
	struct FGameplayAttributeData WeightLimit; // 0x630(0x10)
	struct FGameplayAttributeData WeightLimitBase; // 0x640(0x10)
	struct FGameplayAttributeData WeightLimitMod; // 0x650(0x10)
	struct FGameplayAttributeData WeightLimitAdd; // 0x660(0x10)
	struct FGameplayAttributeData PrestigeItemDrop; // 0x670(0x10)
};

// Class DungeonCrawler.DCItemContainerDataAsset
// Size: 0x70 (Inherited: 0x38)
struct UDCItemContainerDataAsset : UDCDataAsset {
	struct TSoftObjectPtr<UDCItemDataAsset> ContentsItemId; // 0x38(0x30)
	int32_t MaxContentsCount; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// Class DungeonCrawler.DCItemBundleInfoDataAsset
// Size: 0x48 (Inherited: 0x38)
struct UDCItemBundleInfoDataAsset : UDCDataAsset {
	struct TArray<struct FDDCItemBundleInfoItem> ItemBundleInfoItemArray; // 0x38(0x10)
};

// Class DungeonCrawler.DCItemRequirementDataAsset
// Size: 0x70 (Inherited: 0x38)
struct UDCItemRequirementDataAsset : UDCDataAsset {
	struct TArray<struct FPrimaryAssetId> ClassRequirements; // 0x38(0x10)
	int32_t StrengthRequirement; // 0x48(0x04)
	int32_t AgilityRequirement; // 0x4c(0x04)
	int32_t WillRequirement; // 0x50(0x04)
	int32_t KnowledgeRequirement; // 0x54(0x04)
	int32_t ResourcefulRequirement; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct TArray<struct FPrimaryAssetId> PerkRequirements; // 0x60(0x10)
};

// Class DungeonCrawler.DCItemPropertyTypeDataAsset
// Size: 0x90 (Inherited: 0x38)
struct UDCItemPropertyTypeDataAsset : UDCDataAsset {
	struct FGameplayTag PropertyType; // 0x38(0x08)
	struct FPrimaryAssetId PerkId; // 0x40(0x10)
	struct FPrimaryAssetId SkillId; // 0x50(0x10)
	struct FPrimaryAssetId SpellId; // 0x60(0x10)
	struct UGameplayEffect* EffectClass; // 0x70(0x08)
	struct FGameplayTag EffectType; // 0x78(0x08)
	float ValueRatio; // 0x80(0x04)
	int32_t PrimaryTooltipPriority; // 0x84(0x04)
	int32_t SecondaryTooltipPriority; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
};

// Class DungeonCrawler.DCItemPropertyDataAsset
// Size: 0x48 (Inherited: 0x38)
struct UDCItemPropertyDataAsset : UDCDataAsset {
	struct TArray<struct FDDCItemPropertyItem> ItemPropertyItemArray; // 0x38(0x10)
};

// Class DungeonCrawler.DCItemConsumeDataAsset
// Size: 0x58 (Inherited: 0x38)
struct UDCItemConsumeDataAsset : UDCDataAsset {
	struct FText ConsumeText; // 0x38(0x18)
	float ConsumeDuration; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// Class DungeonCrawler.DCItemDataAsset
// Size: 0x288 (Inherited: 0x38)
struct UDCItemDataAsset : UDCDataAsset {
	struct FGameplayTag IdTag; // 0x38(0x08)
	struct FText Name; // 0x40(0x18)
	struct FText FlavorText; // 0x58(0x18)
	struct FGameplayTag SlotType; // 0x70(0x08)
	struct FGameplayTag HandType; // 0x78(0x08)
	struct TArray<struct FGameplayTag> WeaponTypes; // 0x80(0x10)
	struct FGameplayTag ArmorType; // 0x90(0x08)
	struct FGameplayTag UtilityType; // 0x98(0x08)
	struct FGameplayTag AccessoryType; // 0xa0(0x08)
	struct FGameplayTag MiscType; // 0xa8(0x08)
	struct FGameplayTag RarityType; // 0xb0(0x08)
	int32_t MaxCount; // 0xb8(0x04)
	int32_t MaxAmmoCount; // 0xbc(0x04)
	bool CanDrop; // 0xc0(0x01)
	bool CanSaveIntoDatabase; // 0xc1(0x01)
	char pad_C2[0x6]; // 0xc2(0x06)
	struct TSoftObjectPtr<UArtDataItem> ArtData; // 0xc8(0x30)
	struct TSoftObjectPtr<USoundData> SoundData; // 0xf8(0x30)
	struct TSoftObjectPtr<UDCItemConsumeDataAsset> ConsumeData; // 0x128(0x30)
	struct AItemActor* ActorClass; // 0x158(0x08)
	int32_t InventoryWidth; // 0x160(0x04)
	int32_t InventoryHeight; // 0x164(0x04)
	float WearingDelayTime; // 0x168(0x04)
	char pad_16C[0x4]; // 0x16c(0x04)
	struct TArray<struct TSoftObjectPtr<UDCGameplayAbilityDataAsset>> SelfAbilities; // 0x170(0x10)
	struct TArray<struct TSoftObjectPtr<UDCGameplayEffectDataAsset>> SelfEffects; // 0x180(0x10)
	struct TArray<struct TSoftObjectPtr<UDCGameplayAbilityDataAsset>> Abilities; // 0x190(0x10)
	struct TArray<struct TSoftObjectPtr<UDCGameplayEffectDataAsset>> Effects; // 0x1a0(0x10)
	struct TSoftObjectPtr<UDCItemPropertyDataAsset> PrimaryProperty; // 0x1b0(0x30)
	struct TArray<struct TSoftObjectPtr<UDCItemPropertyDataAsset>> SecondaryProperties; // 0x1e0(0x10)
	struct TSoftObjectPtr<UDCItemRequirementDataAsset> Requirement; // 0x1f0(0x30)
	struct TSoftObjectPtr<UDCItemBundleInfoDataAsset> BundleInfo; // 0x220(0x30)
	struct TSoftObjectPtr<UDCItemContainerDataAsset> ContainerData; // 0x250(0x30)
	int32_t AdvPoint; // 0x280(0x04)
	int32_t ExpPoint; // 0x284(0x04)
};

// Class DungeonCrawler.DCItemDragDropOperation
// Size: 0x1c0 (Inherited: 0x90)
struct UDCItemDragDropOperation : UDragDropOperation {
	enum class EDCInventoryId InventoryId; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
	struct FDCItemInfo ItemInfo; // 0x98(0x118)
	struct FVector2D DragOffset; // 0x1b0(0x10)
};

// Class DungeonCrawler.DCItemDragVisualWidget
// Size: 0x4f8 (Inherited: 0x4f0)
struct UDCItemDragVisualWidget : UDCItemCommonWidget {
	struct USizeBox* ItemSizeBox; // 0x4f0(0x08)
};

// Class DungeonCrawler.DCItemSkinArtData
// Size: 0x120 (Inherited: 0x118)
struct UDCItemSkinArtData : UArtDataUtility {
	struct UTexture2D* ItemSkinIconTexture; // 0x118(0x08)
};

// Class DungeonCrawler.DCItemSkinComponent
// Size: 0x100 (Inherited: 0xa0)
struct UDCItemSkinComponent : UActorComponent {
	struct TArray<struct UDCItemSkinDataAsset*> Datas; // 0xa0(0x10)
	char pad_B0[0x50]; // 0xb0(0x50)

	void RemoveDataForDebug_Server(struct FPrimaryAssetId ID); // Function DungeonCrawler.DCItemSkinComponent.RemoveDataForDebug_Server // (None) // @ game+0xffffbe30df830041
};

// Class DungeonCrawler.DCItemSkinDataAsset
// Size: 0xb0 (Inherited: 0x38)
struct UDCItemSkinDataAsset : UDCDataAsset {
	struct FText Name; // 0x38(0x18)
	struct FText FlavorText; // 0x50(0x18)
	struct AItemActor* ItemActor; // 0x68(0x08)
	struct AProjectileActor* ProjectileActor; // 0x70(0x08)
	struct TSoftObjectPtr<UDCItemSkinArtData> Art; // 0x78(0x30)
	struct FGameplayTag TargetItem; // 0xa8(0x08)
};

// Class DungeonCrawler.DCItemSkinListEntryWidgetData
// Size: 0x38 (Inherited: 0x28)
struct UDCItemSkinListEntryWidgetData : UObject {
	struct FDCItemSkinInfo ItemSkinInfo; // 0x28(0x10)
};

// Class DungeonCrawler.DCItemSkinWidget
// Size: 0x3e0 (Inherited: 0x368)
struct UDCItemSkinWidget : UDCControlWidgetBase {
	char pad_368[0x18]; // 0x368(0x18)
	struct FText ItemSkinName; // 0x380(0x18)
	struct FText ItemSkinFlavorText; // 0x398(0x18)
	struct UTexture2D* ItemSkinIconTexture; // 0x3b0(0x08)
	struct FPrimaryAssetId ItemSkinId; // 0x3b8(0x10)
	bool bIsEquipped; // 0x3c8(0x01)
	char pad_3C9[0x7]; // 0x3c9(0x07)
	struct UDCSkinTooltipWidget* TooltipWidgetClass; // 0x3d0(0x08)
	struct UUserWidget* SkinTooltipWidget; // 0x3d8(0x08)

	struct UUserWidget* GetTooltipWidget(); // Function DungeonCrawler.DCItemSkinWidget.GetTooltipWidget // (None) // @ game+0xffffbe31df830041
};

// Class DungeonCrawler.DCItemSkinListEntryWidget
// Size: 0x3f0 (Inherited: 0x3e0)
struct UDCItemSkinListEntryWidget : UDCItemSkinWidget {
	struct FText ItemSkinName; // 0x380(0x18)
	struct FText ItemSkinFlavorText; // 0x398(0x18)
	struct UTexture2D* ItemSkinIconTexture; // 0x3b0(0x08)
	struct FPrimaryAssetId ItemSkinId; // 0x3b8(0x10)
	bool bIsEquipped; // 0x3c8(0x01)
	struct UDCSkinTooltipWidget* TooltipWidgetClass; // 0x3d0(0x08)
	struct UUserWidget* SkinTooltipWidget; // 0x3d8(0x08)

	void OnRightClicked(); // Function DungeonCrawler.DCItemSkinListEntryWidget.OnRightClicked // (None) // @ game+0xffffbe32df830041
};

// Class DungeonCrawler.DCItemTooltipNameWidget
// Size: 0x4e8 (Inherited: 0x4c8)
struct UDCItemTooltipNameWidget : UDCItemWidgetBase {
	struct FGameplayTag Rarity; // 0x4c8(0x08)
	bool bIsSoulHeart; // 0x4d0(0x01)
	char pad_4D1[0x7]; // 0x4d1(0x07)
	struct UTextBlock* ItemNameTextBlock; // 0x4d8(0x08)
	struct UTextBlock* SoulHeartOwnerNameTextBlock; // 0x4e0(0x08)
};

// Class DungeonCrawler.DCItemTooltipStatElementWidget
// Size: 0x288 (Inherited: 0x278)
struct UDCItemTooltipStatElementWidget : UUserWidget {
	struct UDCItemPropertyTypeDataAsset* Data; // 0x278(0x08)
	int32_t Value; // 0x280(0x04)
	char pad_284[0x4]; // 0x284(0x04)
};

// Class DungeonCrawler.DCItemTooltipStatWidget
// Size: 0x4e0 (Inherited: 0x4c8)
struct UDCItemTooltipStatWidget : UDCItemWidgetBase {
	struct UVerticalBox* VerticalBox; // 0x4c8(0x08)
	struct UDCItemTooltipStatElementWidget* PrimaryChildWidgetClass; // 0x4d0(0x08)
	struct UDCItemTooltipStatElementWidget* SecondaryChildWidgetClass; // 0x4d8(0x08)

	bool IsEmpty(); // Function DungeonCrawler.DCItemTooltipStatWidget.IsEmpty // (None) // @ game+0xffffbe33df830041
};

// Class DungeonCrawler.DCItemTooltipAbilityElementWidget
// Size: 0x280 (Inherited: 0x278)
struct UDCItemTooltipAbilityElementWidget : UUserWidget {
	struct URichTextBlock* RichTextBlock; // 0x278(0x08)
};

// Class DungeonCrawler.DCItemTooltipAbilityWidget
// Size: 0x4d8 (Inherited: 0x4c8)
struct UDCItemTooltipAbilityWidget : UDCItemWidgetBase {
	struct UVerticalBox* VerticalBox; // 0x4c8(0x08)
	struct UDCItemTooltipAbilityElementWidget* ChildWidgetClass; // 0x4d0(0x08)

	bool IsEmpty(); // Function DungeonCrawler.DCItemTooltipAbilityWidget.IsEmpty // (None) // @ game+0xffffbe34df830041
};

// Class DungeonCrawler.DCItemTooltipRequirementWidget
// Size: 0x4e0 (Inherited: 0x4c8)
struct UDCItemTooltipRequirementWidget : UDCItemWidgetBase {
	struct TArray<struct FPrimaryAssetId> ClassIds; // 0x4c8(0x10)
	bool bRequired; // 0x4d8(0x01)
	char pad_4D9[0x7]; // 0x4d9(0x07)

	bool IsEmpty(); // Function DungeonCrawler.DCItemTooltipRequirementWidget.IsEmpty // (None) // @ game+0xffffbe35df830041
};

// Class DungeonCrawler.DCItemTooltipInfoWidget
// Size: 0x500 (Inherited: 0x4c8)
struct UDCItemTooltipInfoWidget : UDCItemWidgetBase {
	enum class EItemType ItemType; // 0x4c8(0x01)
	char pad_4C9[0x3]; // 0x4c9(0x03)
	struct FGameplayTag SlotType; // 0x4cc(0x08)
	char pad_4D4[0x4]; // 0x4d4(0x04)
	struct TArray<struct FGameplayTag> WeaponTypes; // 0x4d8(0x10)
	struct FGameplayTag HandType; // 0x4e8(0x08)
	struct FGameplayTag ArmorType; // 0x4f0(0x08)
	struct FGameplayTag UtilityType; // 0x4f8(0x08)
};

// Class DungeonCrawler.DCItemInfoWidgetData
// Size: 0x140 (Inherited: 0x28)
struct UDCItemInfoWidgetData : UObject {
	char pad_28[0x118]; // 0x28(0x118)
};

// Class DungeonCrawler.DCItemInfoEntryWidget
// Size: 0x4f8 (Inherited: 0x4f0)
struct UDCItemInfoEntryWidget : UDCItemCommonWidget {
	struct UDCItemTooltipWidget* ItemTooltipWidgetClass; // 0x4c8(0x08)
	struct UUserWidget* InvalidItemTooltipWidgetClass; // 0x4d0(0x08)
	struct UDCItemDragVisualWidget* ItemDragVisualWidgetClass; // 0x4d8(0x08)
	bool bIsDragging; // 0x4e0(0x01)
	struct UImage* ItemImage; // 0x4e8(0x08)
};

// Class DungeonCrawler.DCItemTooltipWidget
// Size: 0x510 (Inherited: 0x4c8)
struct UDCItemTooltipWidget : UDCItemWidgetBase {
	struct UDCItemTooltipNameWidget* NameWidget; // 0x4c8(0x08)
	struct UDCItemTooltipStatWidget* StatWidget; // 0x4d0(0x08)
	struct UDCItemTooltipAbilityWidget* AbilityWidget; // 0x4d8(0x08)
	struct UDCItemTooltipRequirementWidget* RequirementWidget; // 0x4e0(0x08)
	struct UDCItemTooltipInfoWidget* InfoWidget; // 0x4e8(0x08)
	struct UListView* PriceListWidget; // 0x4f0(0x08)
	struct UTextBlock* DescTextBlock; // 0x4f8(0x08)
	struct TArray<struct UDCItemWidgetBase*> ChildWidgets; // 0x500(0x10)
};

// Class DungeonCrawler.DCInventoryValidatorBase
// Size: 0x30 (Inherited: 0x28)
struct UDCInventoryValidatorBase : UObject {
	enum class EDCInventoryValidatorType ValidatorType; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// Class DungeonCrawler.DCReadOnlyValidator
// Size: 0x30 (Inherited: 0x30)
struct UDCReadOnlyValidator : UDCInventoryValidatorBase {
	enum class EDCInventoryValidatorType ValidatorType; // 0x28(0x01)
};

// Class DungeonCrawler.DCMerchantWishListValidator
// Size: 0x38 (Inherited: 0x30)
struct UDCMerchantWishListValidator : UDCInventoryValidatorBase {
	struct UDCMerchantComponent* MerchantComponent; // 0x30(0x08)
};

// Class DungeonCrawler.DCJunkItemFilterValidator
// Size: 0x30 (Inherited: 0x30)
struct UDCJunkItemFilterValidator : UDCInventoryValidatorBase {
	enum class EDCInventoryValidatorType ValidatorType; // 0x28(0x01)
};

// Class DungeonCrawler.DCLockedItemFilterValidator
// Size: 0x40 (Inherited: 0x30)
struct UDCLockedItemFilterValidator : UDCInventoryValidatorBase {
	struct UDCMerchantComponent* MerchantComponent; // 0x30(0x08)
	struct UDCMetaTradeComponent* TradeComponent; // 0x38(0x08)
};

// Class DungeonCrawler.DCItemViewerActor
// Size: 0x320 (Inherited: 0x2f0)
struct ADCItemViewerActor : ADCActorBase {
	struct FRotator DefaultItemActorRotation; // 0x2f0(0x18)
	float StartRotateLocation; // 0x308(0x04)
	char pad_30C[0xc]; // 0x30c(0x0c)
	struct AActor* ItemActor; // 0x318(0x08)

	void SetStartRotateLocation(float InStartPosition); // Function DungeonCrawler.DCItemViewerActor.SetStartRotateLocation // (None) // @ game+0xffffbe38df830041
};

// Class DungeonCrawler.DCLevelSequenceActor
// Size: 0x328 (Inherited: 0x308)
struct ADCLevelSequenceActor : ALevelSequenceActor {
	struct FGameplayTag PauseTag; // 0x308(0x08)
	struct FGameplayTag PlayTag; // 0x310(0x08)
	struct FGameplayTag PlayReverseTag; // 0x318(0x08)
	bool bPlayOnce; // 0x320(0x01)
	char pad_321[0x7]; // 0x321(0x07)

	void ProcessSequence(struct FGameplayTag& InEventTag); // Function DungeonCrawler.DCLevelSequenceActor.ProcessSequence // (None) // @ game+0xffffbe7bdf830041
};

// Class DungeonCrawler.DCLoadingScreenWidget
// Size: 0x280 (Inherited: 0x278)
struct UDCLoadingScreenWidget : UUserWidget {
	int32_t ImageIndex; // 0x278(0x04)
	int32_t DescIndex; // 0x27c(0x04)

	void OnUpdated(); // Function DungeonCrawler.DCLoadingScreenWidget.OnUpdated // (None) // @ game+0xffffbe3cdf830041
};

// Class DungeonCrawler.DCLoadoutPageWidget
// Size: 0x488 (Inherited: 0x470)
struct UDCLoadoutPageWidget : ULobbyGroupWidgetBase {
	struct UDCPlayerInventoryWidget* InventoryWidget; // 0x470(0x08)
	struct UDCInventorySetWidget* StorageSetWidget; // 0x478(0x08)
	struct UInventoryStatusWidget* StatusWidget; // 0x480(0x08)

	void OnInventoryComponentChanged(struct UDCInventoryComponent* Comp); // Function DungeonCrawler.DCLoadoutPageWidget.OnInventoryComponentChanged // (None) // @ game+0xffffbe3ddf830041
};

// Class DungeonCrawler.DCLobbyCaptureViewerActor
// Size: 0x498 (Inherited: 0x2f0)
struct ADCLobbyCaptureViewerActor : ADCActorBase {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	struct FRotator DefaultActorRotation; // 0x2f8(0x18)
	float StartRotateLocation; // 0x310(0x04)
	char pad_314[0x4]; // 0x314(0x04)
	struct UAbilitySystemComponent* AbilitySystemComponent; // 0x318(0x08)
	struct USceneComponent* CharacterRootScene; // 0x320(0x08)
	struct USkeletalMeshComponent* CharacterMesh; // 0x328(0x08)
	struct USkeletalMeshComponent* PartHead; // 0x330(0x08)
	struct USkeletalMeshComponent* PartHelmet; // 0x338(0x08)
	struct USkeletalMeshComponent* PartAnimObject; // 0x340(0x08)
	struct USkeletalMeshComponent* PartGloves; // 0x348(0x08)
	struct USkeletalMeshComponent* PartChest; // 0x350(0x08)
	struct USkeletalMeshComponent* PartPants; // 0x358(0x08)
	struct USkeletalMeshComponent* PartBoots; // 0x360(0x08)
	struct USkeletalMeshComponent* PartBack; // 0x368(0x08)
	struct UDCCharacterDataComponent* DataComponent; // 0x370(0x08)
	struct UDCCharacterPartsComponent* PartsComponent; // 0x378(0x08)
	char pad_380[0x98]; // 0x380(0x98)
	struct UAccountLink* AccountLink; // 0x418(0x08)
	char pad_420[0x10]; // 0x420(0x10)
	struct TMap<int64_t, struct AActor*> ContainingActorMap; // 0x430(0x50)
	char pad_480[0x18]; // 0x480(0x18)

	void SetStartRotateLocation(float InStartPosition); // Function DungeonCrawler.DCLobbyCaptureViewerActor.SetStartRotateLocation // (None) // @ game+0xffffbe40df830041
};

// Class DungeonCrawler.DCLobbyEmoteArtData
// Size: 0x40 (Inherited: 0x38)
struct UDCLobbyEmoteArtData : UDCDataAssetBase {
	struct UTexture2D* LobbyEmoteIconTexture; // 0x38(0x08)
};

// Class DungeonCrawler.DCLobbyEmoteComponent
// Size: 0x138 (Inherited: 0xa0)
struct UDCLobbyEmoteComponent : UActorComponent {
	char pad_A0[0x18]; // 0xa0(0x18)
	struct TArray<struct FDCLobbyEmoteSlotInfo> LobbyEmoteSlotInfoArray; // 0xb8(0x10)
	struct TMap<int32_t, struct FPrimaryAssetId> LobbyEmoteSlotMap; // 0xc8(0x50)
	struct TArray<struct FGameplayAbilitySpecHandle> OwnerGameplayAbilitySpecHandles; // 0x118(0x10)
	struct TArray<struct FActiveGameplayEffectHandle> OwnerGameplayEffectHandles; // 0x128(0x10)
};

// Class DungeonCrawler.DCLobbyEmoteDataAsset
// Size: 0xf0 (Inherited: 0x38)
struct UDCLobbyEmoteDataAsset : UDCDataAsset {
	struct FText Name; // 0x38(0x18)
	struct TSoftObjectPtr<UDescData> Desc; // 0x50(0x30)
	struct FText FlavorText; // 0x80(0x18)
	struct FGameplayTag LobbyEmoteTag; // 0x98(0x08)
	struct TSoftObjectPtr<UDCLobbyEmoteArtData> ArtData; // 0xa0(0x30)
	struct TArray<struct TSoftObjectPtr<UDCGameplayAbilityDataAsset>> Abilities; // 0xd0(0x10)
	struct TArray<struct TSoftObjectPtr<UDCGameplayEffectDataAsset>> Effects; // 0xe0(0x10)
};

// Class DungeonCrawler.DCLobbyEmoteGroupWidgetBase
// Size: 0x4f8 (Inherited: 0x470)
struct UDCLobbyEmoteGroupWidgetBase : ULobbyGroupWidgetBase {
	char pad_470[0x10]; // 0x470(0x10)
	struct ADCCharacterLobbyCapture* CharacterLobbyCapture; // 0x480(0x08)
	int32_t SelectedEmoteIndex; // 0x488(0x04)
	char pad_48C[0x4]; // 0x48c(0x04)
	struct UDCLobbyEmoteSlotWidget* LobbyEmoteSlot_2; // 0x490(0x08)
	struct UDCLobbyEmoteSlotWidget* LobbyEmoteSlot_3; // 0x498(0x08)
	struct UDCLobbyEmoteSlotWidget* LobbyEmoteSlot_4; // 0x4a0(0x08)
	struct UDCLobbyEmoteSlotWidget* LobbyEmoteSlot_5; // 0x4a8(0x08)
	struct UDCLobbyEmoteSlotWidget* LobbyEmoteSlot_6; // 0x4b0(0x08)
	struct UDCLobbyEmoteSlotWidget* LobbyEmoteSlot_7; // 0x4b8(0x08)
	struct UDCLobbyEmoteSlotWidget* LobbyEmoteSlot_8; // 0x4c0(0x08)
	struct UDCLobbyEmoteSlotWidget* LobbyEmoteSlot_9; // 0x4c8(0x08)
	struct FText LobbyEmoteNameText; // 0x4d0(0x18)
	struct TArray<struct UDCLobbyEmoteSlotWidget*> LobbyEmoteSlots; // 0x4e8(0x10)

	void OnSelectedEmoteIndexChanged(); // Function DungeonCrawler.DCLobbyEmoteGroupWidgetBase.OnSelectedEmoteIndexChanged // (None) // @ game+0xffffbe44df830041
};

// Class DungeonCrawler.DCLobbyEmoteListEntryWidgetData
// Size: 0x40 (Inherited: 0x28)
struct UDCLobbyEmoteListEntryWidgetData : UObject {
	struct FDCLobbyEmoteInfo LobbyEmoteInfo; // 0x28(0x10)
	bool bIsSelected; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// Class DungeonCrawler.DCLobbyEmoteWidget
// Size: 0x3f8 (Inherited: 0x368)
struct UDCLobbyEmoteWidget : UDCControlWidgetBase {
	char pad_368[0x18]; // 0x368(0x18)
	struct FText LobbyEmoteName; // 0x380(0x18)
	struct TArray<struct FText> LobbyEmoteDescTextArray; // 0x398(0x10)
	struct FText LobbyEmoteFlavorText; // 0x3a8(0x18)
	struct UTexture2D* LobbyEmoteIconTexture; // 0x3c0(0x08)
	struct FPrimaryAssetId LobbyEmoteId; // 0x3c8(0x10)
	bool bIsEquipped; // 0x3d8(0x01)
	char pad_3D9[0x7]; // 0x3d9(0x07)
	struct UDCSkinTooltipWidget* TooltipWidgetClass; // 0x3e0(0x08)
	struct UUserWidget* SkinTooltipWidget; // 0x3e8(0x08)
	struct UDCCustomizeDragVisualWidget* LobbyEmoteDragVisualWidgetClass; // 0x3f0(0x08)

	struct UUserWidget* GetTooltipWidget(); // Function DungeonCrawler.DCLobbyEmoteWidget.GetTooltipWidget // (None) // @ game+0xffffbe45df830041
};

// Class DungeonCrawler.DCLobbyEmoteListEntryWidget
// Size: 0x408 (Inherited: 0x3f8)
struct UDCLobbyEmoteListEntryWidget : UDCLobbyEmoteWidget {
	struct FText LobbyEmoteName; // 0x380(0x18)
	struct TArray<struct FText> LobbyEmoteDescTextArray; // 0x398(0x10)
	struct FText LobbyEmoteFlavorText; // 0x3a8(0x18)
	struct UTexture2D* LobbyEmoteIconTexture; // 0x3c0(0x08)
	struct FPrimaryAssetId LobbyEmoteId; // 0x3c8(0x10)
	bool bIsEquipped; // 0x3d8(0x01)
	struct UDCSkinTooltipWidget* TooltipWidgetClass; // 0x3e0(0x08)
	struct UUserWidget* SkinTooltipWidget; // 0x3e8(0x08)
	struct UDCCustomizeDragVisualWidget* LobbyEmoteDragVisualWidgetClass; // 0x3f0(0x08)

	void OnRightClicked(); // Function DungeonCrawler.DCLobbyEmoteListEntryWidget.OnRightClicked // (None) // @ game+0xffffbe47df830041
};

// Class DungeonCrawler.DCLobbyEmoteSlotWidget
// Size: 0x330 (Inherited: 0x300)
struct UDCLobbyEmoteSlotWidget : UDCWidgetBase {
	char pad_300[0x8]; // 0x300(0x08)
	struct FText LobbyEmoteName; // 0x308(0x18)
	struct UTexture2D* LobbyEmoteIconTexture; // 0x320(0x08)
	char pad_328[0x8]; // 0x328(0x08)

	void SetLobbyEmoteData(struct UDCLobbyEmoteDataAsset* InDesignDataLobbyEmote); // Function DungeonCrawler.DCLobbyEmoteSlotWidget.SetLobbyEmoteData // (None) // @ game+0xffffbe4cdf830041
};

// Class DungeonCrawler.DCMetaGameMode
// Size: 0x3a0 (Inherited: 0x3a0)
struct ADCMetaGameMode : ADCGameModeBase {
	struct UBaseObject* BaseObject; // 0x388(0x08)
	struct ADCGameModeAIControllerBase* GameModeAIControllerClass; // 0x390(0x08)
	struct ADCGameModeAIControllerBase* GameModeAIController; // 0x398(0x08)
};

// Class DungeonCrawler.DCLobbyGameMode
// Size: 0x3a0 (Inherited: 0x3a0)
struct ADCLobbyGameMode : ADCMetaGameMode {
	struct UBaseObject* BaseObject; // 0x388(0x08)
	struct ADCGameModeAIControllerBase* GameModeAIControllerClass; // 0x390(0x08)
	struct ADCGameModeAIControllerBase* GameModeAIController; // 0x398(0x08)
};

// Class DungeonCrawler.DCLobbyGameState
// Size: 0x6d8 (Inherited: 0x6d8)
struct ADCLobbyGameState : ADCGameStateBase {
	struct UBaseObject* BaseObject; // 0x338(0x08)
	enum class EGameStateType State; // 0x358(0x01)
	struct TArray<struct FGameStateData> GameStateDataArray; // 0x3e0(0x10)
	struct TArray<struct FAccountDataReplication> AccountDataReplicationArray; // 0x3f0(0x10)
	struct TMap<struct FString, struct UAccountSession*> AccountSessionMap; // 0x400(0x50)
	struct TMap<struct FString, struct TWeakObjectPtr<struct ADCCharacterBase>> PlayerCharacters; // 0x450(0x50)
	struct TArray<struct FPartyData> PartyDataArray; // 0x590(0x10)
	struct TMap<struct FString, struct UPartySession*> PartySessionMap; // 0x5a0(0x50)
	struct ADeathSwarmBase* DeathSwarm; // 0x5f0(0x08)
	struct FGameFloorRuleData GameFloorRuleData; // 0x5f8(0x60)
	struct FDCGameInfo GameInfo; // 0x658(0x48)
	struct FDCDungeonInfo DungeonInfo; // 0x6b8(0x0c)
	float ServerAverageFps; // 0x6c4(0x04)
	float ServerAverageMs; // 0x6c8(0x04)
	int32_t MonsterActive; // 0x6cc(0x04)
	int32_t PropsActive; // 0x6d0(0x04)
	int32_t NavTestCall; // 0x6d4(0x04)
};

// Class DungeonCrawler.DCLogEventManager
// Size: 0xd0 (Inherited: 0x30)
struct UDCLogEventManager : UDCUserInfoManagerBase {
	char pad_30[0xa0]; // 0x30(0xa0)
};

// Class DungeonCrawler.DCLoginGameMode
// Size: 0x428 (Inherited: 0x3a0)
struct ADCLoginGameMode : ADCGameModeBase {
	char pad_3A0[0x80]; // 0x3a0(0x80)
	struct UDCCommonActivatableWidgetBase* SecretTokenPopupWidgetClass; // 0x420(0x08)
};

// Class DungeonCrawler.DCLootComponent
// Size: 0xf0 (Inherited: 0xa0)
struct UDCLootComponent : UActorComponent {
	struct AActor* LootTargetActor; // 0xa0(0x08)
	char pad_A8[0x48]; // 0xa8(0x48)
};

// Class DungeonCrawler.DCLootDropDataAsset
// Size: 0x48 (Inherited: 0x38)
struct UDCLootDropDataAsset : UDCDataAsset {
	struct TArray<struct FDCLootDropItemData> LootDropItemArray; // 0x38(0x10)
};

// Class DungeonCrawler.DCMeleeAttackDataAsset
// Size: 0x90 (Inherited: 0x38)
struct UDCMeleeAttackDataAsset : UDCDataAsset {
	float DamageRatio; // 0x38(0x04)
	float HitPlayRate; // 0x3c(0x04)
	float HitPlayRateDuration; // 0x40(0x04)
	bool CanStuckByHitBox; // 0x44(0x01)
	char pad_45[0x3]; // 0x45(0x03)
	float CharacterStuckPlayRate; // 0x48(0x04)
	float CharacterStuckPlayRateDuration; // 0x4c(0x04)
	float CharacterStuckBlendOutTime; // 0x50(0x04)
	bool CanStuckByShield; // 0x54(0x01)
	char pad_55[0x3]; // 0x55(0x03)
	float WeakShieldStuckPlayRate; // 0x58(0x04)
	float WeakShieldStuckPlayRateDuration; // 0x5c(0x04)
	float WeakShieldStuckBlendOutTime; // 0x60(0x04)
	float MidShieldStuckPlayRate; // 0x64(0x04)
	float MidShieldStuckPlayRateDuration; // 0x68(0x04)
	float MidShieldStuckBlendOutTime; // 0x6c(0x04)
	float HeavyShieldStuckPlayRate; // 0x70(0x04)
	float HeavyShieldStuckPlayRateDuration; // 0x74(0x04)
	float HeavyShieldStuckBlendOutTime; // 0x78(0x04)
	bool CanStuckByStaticObject; // 0x7c(0x01)
	char pad_7D[0x3]; // 0x7d(0x03)
	float StaticObjectStuckPlayRate; // 0x80(0x04)
	float StaticObjectStuckPlayRateDuration; // 0x84(0x04)
	float StaticObjectStuckBlendOutTime; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
};

// Class DungeonCrawler.DCMerchantComponent
// Size: 0x2b0 (Inherited: 0x180)
struct UDCMerchantComponent : UDCInventoryContainerComponent {
	char pad_180[0x50]; // 0x180(0x50)
	struct UDCInventoryComponent* InventoryComponent; // 0x1d0(0x08)
	enum class EWidgetMerchantServiceType ServiceType; // 0x1d8(0x01)
	char pad_1D9[0x7]; // 0x1d9(0x07)
	struct FDCMerchantId MerchantId; // 0x1e0(0x10)
	struct TArray<struct FDCMerchantInfo> MerchantInfos; // 0x1f0(0x10)
	struct TMap<struct FDCItemId, struct FDCMerchantSaleItemId> SaleItemMap; // 0x200(0x50)
	struct TMap<struct FDCItemId, struct FDCMerchantCraftItemId> CraftItemMap; // 0x250(0x50)
	struct TArray<struct FPrimaryAssetId> WishList; // 0x2a0(0x10)

	void OnMerchantSellFinished(); // Function DungeonCrawler.DCMerchantComponent.OnMerchantSellFinished // (None) // @ game+0xffffbe53df830041
};

// Class DungeonCrawler.DCStockSellBackDataAsset
// Size: 0x48 (Inherited: 0x38)
struct UDCStockSellBackDataAsset : UDCDataAsset {
	struct TArray<struct FDCStockSellBackItemData> StockSellBackItemArray; // 0x38(0x10)
};

// Class DungeonCrawler.DCStockBuyDataAsset
// Size: 0x48 (Inherited: 0x38)
struct UDCStockBuyDataAsset : UDCDataAsset {
	struct TArray<struct FDCStockBuyItemData> StockBuyItemArray; // 0x38(0x10)
};

// Class DungeonCrawler.DCStockCraftDataAsset
// Size: 0x48 (Inherited: 0x38)
struct UDCStockCraftDataAsset : UDCDataAsset {
	struct TArray<struct FDCStockCraftItemData> StockCraftItemArray; // 0x38(0x10)
};

// Class DungeonCrawler.DCMerchantDataAsset
// Size: 0x98 (Inherited: 0x38)
struct UDCMerchantDataAsset : UDCDataAsset {
	struct FText Name; // 0x38(0x18)
	struct FText GreetingText; // 0x50(0x18)
	struct TSoftObjectPtr<UArtDataMerchant> ArtData; // 0x68(0x30)
};

// Class DungeonCrawler.DCMerchantDealTablePurchaseWidget
// Size: 0x2a8 (Inherited: 0x278)
struct UDCMerchantDealTablePurchaseWidget : UUserWidget {
	struct UDCCommonButtonBase* ButtonFill; // 0x278(0x08)
	struct UDCCommonButtonBase* ButtonDeal; // 0x280(0x08)
	bool bBuy; // 0x288(0x01)
	char pad_289[0x7]; // 0x289(0x07)
	struct UDCMerchantInfoWidget* MerchantInfoWidget; // 0x290(0x08)
	struct UDCMerchantItemWidget* TargetItemWidget; // 0x298(0x08)
	struct UListView* RequiredListView; // 0x2a0(0x08)

	void OnButtonFill(); // Function DungeonCrawler.DCMerchantDealTablePurchaseWidget.OnButtonFill // (None) // @ game+0xffffbe57df830041
};

// Class DungeonCrawler.DCMerchantDealTableSellWidget
// Size: 0x2e8 (Inherited: 0x2c0)
struct UDCMerchantDealTableSellWidget : UDCInventoryWidgetBase {
	struct UDCCommonButtonBase* ButtonDeal; // 0x2c0(0x08)
	struct UDCMerchantInfoWidget* MerchantInfoWidget; // 0x2c8(0x08)
	struct UDCBagWidget* DealTableWidget; // 0x2d0(0x08)
	struct TArray<struct FDCItemId> PrevItems; // 0x2d8(0x10)

	void OnInventoryUpdated(); // Function DungeonCrawler.DCMerchantDealTableSellWidget.OnInventoryUpdated // (None) // @ game+0xffffbe5bdf830041
};

// Class DungeonCrawler.DCMerchantInfoWidget
// Size: 0x2d0 (Inherited: 0x278)
struct UDCMerchantInfoWidget : UUserWidget {
	struct FText Name; // 0x278(0x18)
	struct FText Text; // 0x290(0x18)
	struct UImage* Portrait; // 0x2a8(0x08)
	struct UDCMerchantStatWidget* StatWidget; // 0x2b0(0x08)
	struct FText GreetingText; // 0x2b8(0x18)
};

// Class DungeonCrawler.DCMerchantItemWidget
// Size: 0x4e8 (Inherited: 0x4c8)
struct UDCMerchantItemWidget : UDCItemWidgetBase {
	struct UDCItemTooltipWidget* ItemTooltipWidgetClass; // 0x4c8(0x08)
	int32_t DealTableCount; // 0x4d0(0x04)
	char pad_4D4[0x4]; // 0x4d4(0x04)
	struct UImage* ItemImage; // 0x4d8(0x08)
	struct USizeBox* ItemSizeBox; // 0x4e0(0x08)

	struct UDCItemTooltipWidget* GetTooltipWidget(); // Function DungeonCrawler.DCMerchantItemWidget.GetTooltipWidget // (None) // @ game+0xffffbe5cdf830041
};

// Class DungeonCrawler.DCMerchantListEntryWidgetData
// Size: 0x50 (Inherited: 0x28)
struct UDCMerchantListEntryWidgetData : UObject {
	struct FDCMerchantInfo Info; // 0x28(0x18)
	struct UDCMerchantDataAsset* DataAsset; // 0x40(0x08)
	struct UUserWidget* Widget; // 0x48(0x08)
};

// Class DungeonCrawler.DCMerchantListEntryWidget
// Size: 0x2c0 (Inherited: 0x278)
struct UDCMerchantListEntryWidget : UUserWidget {
	char pad_278[0x8]; // 0x278(0x08)
	struct FText Name; // 0x280(0x18)
	struct UImage* Portrait; // 0x298(0x08)
	struct UDCMerchantStatWidget* StatWidget; // 0x2a0(0x08)
	struct FDCMerchantId ID; // 0x2a8(0x10)
	bool bMouseButtonDown; // 0x2b8(0x01)
	char pad_2B9[0x7]; // 0x2b9(0x07)
};

// Class DungeonCrawler.DCMerchantListPageWidget
// Size: 0x478 (Inherited: 0x470)
struct UDCMerchantListPageWidget : ULobbyGroupWidgetBase {
	struct UTileView* TileView; // 0x470(0x08)

	void OnSetCompletedTileView(); // Function DungeonCrawler.DCMerchantListPageWidget.OnSetCompletedTileView // (None) // @ game+0xffffbe5ddf830041
};

// Class DungeonCrawler.DCMerchantMenuWidget
// Size: 0x278 (Inherited: 0x278)
struct UDCMerchantMenuWidget : UUserWidget {
	struct FLinearColor ColorAndOpacity; // 0x158(0x10)
	struct FDelegate ColorAndOpacityDelegate; // 0x168(0x10)
	struct FSlateColor ForegroundColor; // 0x178(0x14)
	struct FDelegate ForegroundColorDelegate; // 0x18c(0x10)
	struct FMulticastInlineDelegate OnVisibilityChanged; // 0x1a0(0x10)
	struct FMargin Padding; // 0x1c8(0x10)
	struct TArray<struct UUMGSequencePlayer*> ActiveSequencePlayers; // 0x1d8(0x10)
	struct UUMGSequenceTickManager* AnimationTickManager; // 0x1e8(0x08)
	struct TArray<struct UUMGSequencePlayer*> StoppedSequencePlayers; // 0x1f0(0x10)
	struct TArray<struct FNamedSlotBinding> NamedSlotBindings; // 0x200(0x10)
	struct TArray<struct UUserWidgetExtension*> Extensions; // 0x210(0x10)
	struct UWidgetTree* WidgetTree; // 0x220(0x08)
	int32_t Priority; // 0x228(0x04)
	char bIsFocusable : 1; // 0x22c(0x01)
	char bStopAction : 1; // 0x22c(0x01)
	char bHasScriptImplementedTick : 1; // 0x22c(0x01)
	char bHasScriptImplementedPaint : 1; // 0x22c(0x01)
	enum class EWidgetTickFrequency TickFrequency; // 0x240(0x01)
	struct UInputComponent* InputComponent; // 0x248(0x08)
	struct TArray<struct FAnimationEventBinding> AnimationCallbacks; // 0x250(0x10)
};

// Class DungeonCrawler.DCMerchantPageWidget
// Size: 0x4b8 (Inherited: 0x470)
struct UDCMerchantPageWidget : ULobbyGroupWidgetBase {
	struct UButton* ButtonBack; // 0x470(0x08)
	struct UDCBagWidget* InventorySale; // 0x478(0x08)
	struct UDCBagWidget* InventoryWish; // 0x480(0x08)
	struct UDCBagWidget* InventoryCraft; // 0x488(0x08)
	struct UDCInventorySetWidget* PlayerInventorySet; // 0x490(0x08)
	struct UDCMerchantDealTablePurchaseWidget* DealTableBuyWidget; // 0x498(0x08)
	struct UDCMerchantDealTableSellWidget* DealTableSellWidget; // 0x4a0(0x08)
	struct UDCMerchantDealTablePurchaseWidget* DealTableCraftWidget; // 0x4a8(0x08)
	struct UDCBoxInventory* DummyInventory; // 0x4b0(0x08)

	void SelectItems(struct TArray<struct FDCItemId>& ItemIds, bool bState); // Function DungeonCrawler.DCMerchantPageWidget.SelectItems // (None) // @ game+0xffffbe64df830041
};

// Class DungeonCrawler.DCMerchantRequiredItemData
// Size: 0x88 (Inherited: 0x28)
struct UDCMerchantRequiredItemData : UObject {
	struct UDCItemDataAsset* DataAsset; // 0x28(0x08)
	int32_t MaxStack; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct TMap<struct FDCItemInfo, int32_t> FilledInfos; // 0x38(0x50)
};

// Class DungeonCrawler.DCMerchantRequiredEntryWidget
// Size: 0x4f0 (Inherited: 0x4e8)
struct UDCMerchantRequiredEntryWidget : UDCMerchantItemWidget {
	struct UDCItemTooltipWidget* ItemTooltipWidgetClass; // 0x4c8(0x08)
	int32_t DealTableCount; // 0x4d0(0x04)
	struct UImage* ItemImage; // 0x4d8(0x08)
	struct USizeBox* ItemSizeBox; // 0x4e0(0x08)

	bool IsFilled(); // Function DungeonCrawler.DCMerchantRequiredEntryWidget.IsFilled // (None) // @ game+0xffffbe67df830041
};

// Class DungeonCrawler.DCMerchantStatWidget
// Size: 0x288 (Inherited: 0x278)
struct UDCMerchantStatWidget : UUserWidget {
	int32_t Faction; // 0x278(0x04)
	char pad_27C[0x4]; // 0x27c(0x04)
	struct FTimespan RemainTime; // 0x280(0x08)
};

// Class DungeonCrawler.DCMetaCustomizeComponent
// Size: 0x1b0 (Inherited: 0x1b0)
struct UDCMetaCustomizeComponent : UDCCustomizeComponent {
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x30(0x30)
	struct TArray<struct FName> ComponentTags; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	int32_t UCSSerializationIndex; // 0x84(0x04)
	char pad_204_0 : 3; // 0x204(0x01)
	char bNetAddressable : 1; // 0x88(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x88(0x01)
	char bReplicates : 1; // 0x88(0x01)
	char bAutoActivate : 1; // 0x8a(0x01)
	char bIsActive : 1; // 0x8a(0x01)
	char pad_205_0 : 3; // 0x205(0x01)
	char bEditableWhenInherited : 1; // 0x8a(0x01)
	char pad_205_4 : 1; // 0x205(0x01)
	char bCanEverAffectNavigation : 1; // 0x8a(0x01)
	char pad_205_6 : 1; // 0x205(0x01)
	char bIsEditorOnly : 1; // 0x8a(0x01)
	enum class EComponentCreationMethod CreationMethod; // 0x8d(0x01)
	struct FMulticastSparseDelegate OnComponentActivated; // 0x8e(0x01)
	struct FMulticastSparseDelegate OnComponentDeactivated; // 0x8f(0x01)
};

// Class DungeonCrawler.DCMetaGameSession
// Size: 0x488 (Inherited: 0x488)
struct ADCMetaGameSession : ADCGameSession {
	struct FDCGameplayEffectData RespawnGameplayEffectData; // 0x3a0(0x48)
	struct FPrimaryAssetId MaxPerkSlotCountConstant; // 0x438(0x10)
	struct FPrimaryAssetId MaxSkillSlotCountConstant; // 0x448(0x10)
	struct FPrimaryAssetId AdvPointPlayerKillConstant; // 0x458(0x10)
	struct FPrimaryAssetId AdvPointDungeonDownConstant; // 0x468(0x10)
	struct FPrimaryAssetId ExpPointDungeonDownConstant; // 0x478(0x10)
};

// Class DungeonCrawler.DCMetaInventoryComponent
// Size: 0x180 (Inherited: 0x180)
struct UDCMetaInventoryComponent : UDCInventoryComponent {
	struct TArray<struct UDCInventoryBase*> InventoryList; // 0x170(0x10)

	void UpdateItemId(struct FDCItemId ItemId, enum class EDCInventoryId InventoryId, int32_t SlotIndex); // Function DungeonCrawler.DCMetaInventoryComponent.UpdateItemId // (None) // @ game+0xffffbe69df830041
};

// Class DungeonCrawler.DCMetaInventoryControllerComponent
// Size: 0xc0 (Inherited: 0xc0)
struct UDCMetaInventoryControllerComponent : UDCInventoryControllerComponent {
	struct UDCInventoryComponent* InventoryComponent; // 0xa0(0x08)
};

// Class DungeonCrawler.DCMetaPlayerController
// Size: 0x940 (Inherited: 0x850)
struct ADCMetaPlayerController : APlayerController {
	char pad_850[0x58]; // 0x850(0x58)
	struct UBaseObject* BaseObject; // 0x8a8(0x08)
	struct UAccountLink* AccountLink; // 0x8b0(0x08)
	struct FString TargetAccountId; // 0x8b8(0x10)
	char pad_8C8[0x38]; // 0x8c8(0x38)
	struct FPrimaryAssetId MaxPerkSlotCountConstant; // 0x900(0x10)
	struct FPrimaryAssetId MaxSkillSlotCountConstant; // 0x910(0x10)
	struct UDCMerchantComponent* MerchantComponent; // 0x920(0x08)
	struct UDCRecruitComponent* RecruitComponent; // 0x928(0x08)
	struct UDCInventoryControllerComponent* InventoryControllerComponent; // 0x930(0x08)
	struct APlayerCharacterCaptureActor* CharacterCapture; // 0x938(0x08)

	void UpdateGameState(struct FGameStateData& InGameStateData); // Function DungeonCrawler.DCMetaPlayerController.UpdateGameState // (None) // @ game+0xffffbf14df830041
};

// Class DungeonCrawler.MetaComponentBase
// Size: 0x100 (Inherited: 0xa0)
struct UMetaComponentBase : UActorComponent {
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x30(0x30)
	struct TArray<struct FName> ComponentTags; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	int32_t UCSSerializationIndex; // 0x84(0x04)
	char pad_F4_0 : 3; // 0xf4(0x01)
	char bNetAddressable : 1; // 0x88(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x88(0x01)
	char bReplicates : 1; // 0x88(0x01)
	char bAutoActivate : 1; // 0x8a(0x01)
	char bIsActive : 1; // 0x8a(0x01)
	char pad_F5_0 : 3; // 0xf5(0x01)
	char bEditableWhenInherited : 1; // 0x8a(0x01)
	char pad_F5_4 : 1; // 0xf5(0x01)
	char bCanEverAffectNavigation : 1; // 0x8a(0x01)
	char pad_F5_6 : 1; // 0xf5(0x01)
	char bIsEditorOnly : 1; // 0x8a(0x01)
	enum class EComponentCreationMethod CreationMethod; // 0x8d(0x01)
	struct FMulticastSparseDelegate OnComponentActivated; // 0x8e(0x01)
	struct FMulticastSparseDelegate OnComponentDeactivated; // 0x8f(0x01)
	char pad_F9[0x7]; // 0xf9(0x07)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.MetaComponentBase.UnbindMsgAll // (None) // @ game+0xffffbf18df830041
};

// Class DungeonCrawler.DCMetaTradeComponent
// Size: 0x240 (Inherited: 0x100)
struct UDCMetaTradeComponent : UMetaComponentBase {
	struct UCommonPopupSWidget* CommonPopupWidget; // 0x100(0x08)
	char pad_108[0x58]; // 0x108(0x58)
	struct FTimerHandle ResetTimerHandle; // 0x160(0x08)
	char pad_168[0xc8]; // 0x168(0xc8)
	struct UDCBoxInventory* TradingBoxLocal; // 0x230(0x08)
	struct UDCBoxInventory* TradingBoxRemote; // 0x238(0x08)

	void UpdateResetTimer(); // Function DungeonCrawler.DCMetaTradeComponent.UpdateResetTimer // (None) // @ game+0xffffbf5ddf830041
};

// Class DungeonCrawler.DCMonsterAIController
// Size: 0x458 (Inherited: 0x3b8)
struct ADCMonsterAIController : AAIController {
	char pad_3B8[0x58]; // 0x3b8(0x58)
	struct UBaseObject* BaseObject; // 0x410(0x08)
	char pad_418[0x20]; // 0x418(0x20)
	struct FGameplayTagContainer TargetInvisibleStateTagContainer; // 0x438(0x20)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCMonsterAIController.UnbindMsgAll // (None) // @ game+0xffffbf22df830041
};

// Class DungeonCrawler.DCMonsterAISystemBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UDCMonsterAISystemBlueprintLibrary : UBlueprintFunctionLibrary {

	bool SubAggro(struct ADCMonsterBase*& DCMonsterBase, struct ADCCharacterBase*& Target, float Point); // Function DungeonCrawler.DCMonsterAISystemBlueprintLibrary.SubAggro // (None) // @ game+0xffffbf4cdf830041
};

// Class DungeonCrawler.DCMonsterAnimInstanceBase
// Size: 0x490 (Inherited: 0x470)
struct UDCMonsterAnimInstanceBase : UDCCharacterAnimInstanceBase {
	struct FVector ForwardVector; // 0x468(0x18)
	bool bIsStaggered; // 0x480(0x01)
	char pad_489[0x7]; // 0x489(0x07)
};

// Class DungeonCrawler.DCMonsterBase
// Size: 0xbe0 (Inherited: 0x880)
struct ADCMonsterBase : ADCCharacterBase {
	char pad_880[0x10]; // 0x880(0x10)
	bool bIsRepRootMotionActive; // 0x890(0x01)
	char pad_891[0x7]; // 0x891(0x07)
	struct UCapsuleComponent* PlayerCharacterOverlapComponent; // 0x898(0x08)
	char pad_8A0[0x70]; // 0x8a0(0x70)
	struct FPrimaryAssetId MonsterId; // 0x910(0x10)
	char pad_920[0x68]; // 0x920(0x68)
	struct UArtDataMonster* ArtDataMonster; // 0x988(0x08)
	char OrientRotationToMovement; // 0x990(0x01)
	char pad_991[0x77]; // 0x991(0x77)
	char MonsterCollisionProfile; // 0xa08(0x01)
	char pad_A09[0x77]; // 0xa09(0x77)
	char PauseAnims; // 0xa80(0x01)
	char pad_A81[0x7]; // 0xa81(0x07)
	struct TScriptInterface<IMonsterSpawnableInterface> MonsterSpawnableInterface; // 0xa88(0x10)
	struct UDesignDataAssetMonster* DesignDataAssetMonster; // 0xa98(0x08)
	float MinAcceleration; // 0xaa0(0x04)
	float NormalAcceleration; // 0xaa4(0x04)
	float MaxAcceleration; // 0xaa8(0x04)
	char pad_AAC[0x4]; // 0xaac(0x04)
	struct FVector SpawnedPoint; // 0xab0(0x18)
	struct TArray<struct ATargetPoint*> TargetPoints; // 0xac8(0x10)
	bool bAggressive; // 0xad8(0x01)
	enum class EMonsterCollisionProfile DefaultMonsterCollisionProfile; // 0xad9(0x01)
	char pad_ADA[0x6]; // 0xada(0x06)
	struct UBehaviorTree* BehaviorAsset; // 0xae0(0x08)
	bool bRagdollDeath; // 0xae8(0x01)
	char pad_AE9[0x3]; // 0xae9(0x03)
	float AddtionalPlayerCharacterOverlapCapsuleComponentHalfHeight; // 0xaec(0x04)
	float AddtionalPlayerCharacterOverlapCapsuleComponentRadius; // 0xaf0(0x04)
	float AggroPerTime; // 0xaf4(0x04)
	float AddtionalAggro; // 0xaf8(0x04)
	float MaxAggroPoint; // 0xafc(0x04)
	float DecreaseAggroSec; // 0xb00(0x04)
	float DecreaseAggroPointRate; // 0xb04(0x04)
	struct TMap<struct TWeakObjectPtr<struct AActor>, struct FAggroInfo> AggroInfoMap; // 0xb08(0x50)
	struct TArray<struct TWeakObjectPtr<struct ADCCharacterBase>> SightTargets; // 0xb58(0x10)
	struct TArray<struct TWeakObjectPtr<struct ADCCharacterBase>> HearingTargets; // 0xb68(0x10)
	struct TArray<struct TWeakObjectPtr<struct ADCCharacterBase>> Slaves; // 0xb78(0x10)
	char pad_B88[0x50]; // 0xb88(0x50)
	bool bPreview; // 0xbd8(0x01)
	char pad_BD9[0x7]; // 0xbd9(0x07)

	void SetMonsterId(struct FPrimaryAssetId& InMonsterId); // Function DungeonCrawler.DCMonsterBase.SetMonsterId // (None) // @ game+0xffffbf68df830041
};

// Class DungeonCrawler.DCMonsterDataAsset
// Size: 0xe0 (Inherited: 0x38)
struct UDCMonsterDataAsset : UDCDataAsset {
	struct FText Name; // 0x38(0x18)
	struct TSoftObjectPtr<UArtDataMonster> ArtData; // 0x50(0x30)
	struct TSoftObjectPtr<USoundData> SoundData; // 0x80(0x30)
	struct ADCMonsterBase* ActorClass; // 0xb0(0x08)
	struct TArray<struct TSoftObjectPtr<UDCGameplayAbilityDataAsset>> Abilities; // 0xb8(0x10)
	struct TArray<struct TSoftObjectPtr<UDCGameplayEffectDataAsset>> Effects; // 0xc8(0x10)
	int32_t AdvPoint; // 0xd8(0x04)
	int32_t ExpPoint; // 0xdc(0x04)
};

// Class DungeonCrawler.DCMonsterGameplayAbilityBase
// Size: 0x560 (Inherited: 0x558)
struct UDCMonsterGameplayAbilityBase : UDCGameplayAbilityBase {
	struct UAnimMontage* MontageToPlay; // 0x558(0x08)

	void AbilityActivated(struct FGameplayEventData TriggerEventData); // Function DungeonCrawler.DCMonsterGameplayAbilityBase.AbilityActivated // (None) // @ game+0xffffbf69df830041
};

// Class DungeonCrawler.DCMonsterSpawner
// Size: 0x360 (Inherited: 0x290)
struct ADCMonsterSpawner : AActor {
	char pad_290[0x60]; // 0x290(0x60)
	struct UBaseObject* BaseObject; // 0x2f0(0x08)
	struct UBillboardComponent* BillboardComponent; // 0x2f8(0x08)
	struct UArrowComponent* ArrowComponent; // 0x300(0x08)
	enum class EMonsterSpawnerType BoundType; // 0x308(0x01)
	bool IsLinked; // 0x309(0x01)
	enum class EMonsterCollisionProfile MonsterCollisionProfile; // 0x30a(0x01)
	char pad_30B[0x5]; // 0x30b(0x05)
	struct TArray<struct ADCMonsterBase*> Monsters; // 0x310(0x10)
	float Range; // 0x320(0x04)
	int32_t Count; // 0x324(0x04)
	struct TArray<struct ATargetPoint*> TargetPoints; // 0x328(0x10)
	char pad_338[0x28]; // 0x338(0x28)

	void UpdateGameState(struct FGameStateData& InGameStateData); // Function DungeonCrawler.DCMonsterSpawner.UpdateGameState // (None) // @ game+0xffffbf6fdf830041
};

// Class DungeonCrawler.DCMovementModifierContainerData
// Size: 0x80 (Inherited: 0x30)
struct UDCMovementModifierContainerData : UDataAsset {
	struct TMap<struct FGameplayTag, struct FDCMovementModiferContainer> MovementModifierContainer; // 0x30(0x50)
};

// Class DungeonCrawler.DCMultiLineEditableTextBox
// Size: 0x1090 (Inherited: 0x1070)
struct UDCMultiLineEditableTextBox : UMultiLineEditableTextBox {
	struct FMulticastInlineDelegate OnCursorMoved; // 0x1068(0x10)
	struct FMulticastInlineDelegate OnUserScrolled; // 0x1078(0x10)

	void InsertTextAtCursor(struct FString InText); // Function DungeonCrawler.DCMultiLineEditableTextBox.InsertTextAtCursor // (None) // @ game+0xffffbf72df830041
};

// Class DungeonCrawler.DCNetReplicationGraphConnection
// Size: 0x328 (Inherited: 0x2d8)
struct UDCNetReplicationGraphConnection : UNetReplicationGraphConnection {
	struct TSet<struct AActor*> ActorSet; // 0x2d8(0x50)
};

// Class DungeonCrawler.DCPartyChatInterface
// Size: 0x28 (Inherited: 0x28)
struct UDCPartyChatInterface : UInterface {
};

// Class DungeonCrawler.DCPartyManager
// Size: 0x138 (Inherited: 0x30)
struct UDCPartyManager : UDCUserInfoManagerBase {
	char pad_30[0x18]; // 0x30(0x18)
	struct TMap<struct FDCPartyId, struct FDCPartyInfo> PartyInfos; // 0x48(0x50)
	struct TMap<struct FDCAccountId, struct FDCPartyId> AccountPartyMap; // 0x98(0x50)
	char pad_E8[0x50]; // 0xe8(0x50)

	void Update(struct FDCPlayerInfo& Info); // Function DungeonCrawler.DCPartyManager.Update // (None) // @ game+0xffffbf7bdf830041
};

// Class DungeonCrawler.DCPartyMemberActorStatusRow
// Size: 0x2a0 (Inherited: 0x278)
struct UDCPartyMemberActorStatusRow : UUserWidget {
	struct UGameActorStatusSlotWidget* PartyMemberActorStatusEntry1; // 0x278(0x08)
	struct UGameActorStatusSlotWidget* PartyMemberActorStatusEntry2; // 0x280(0x08)
	struct UGameActorStatusSlotWidget* PartyMemberActorStatusEntry3; // 0x288(0x08)
	struct TArray<struct UGameActorStatusSlotWidget*> PartyMemberActorStatusEntries; // 0x290(0x10)
};

// Class DungeonCrawler.DCPerkDataAsset
// Size: 0x100 (Inherited: 0x38)
struct UDCPerkDataAsset : UDCDataAsset {
	struct FText Name; // 0x38(0x18)
	struct TSoftObjectPtr<UDescData> DescData; // 0x50(0x30)
	bool CanUse; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
	struct TArray<struct FPrimaryAssetId> Classes; // 0x88(0x10)
	float Radius; // 0x98(0x04)
	struct FPrimaryAssetId IdTagGroup; // 0x9c(0x10)
	char pad_AC[0x4]; // 0xac(0x04)
	struct TSoftObjectPtr<UArtDataPerk> ArtData; // 0xb0(0x30)
	struct TArray<struct TSoftObjectPtr<UDCGameplayAbilityDataAsset>> Abilities; // 0xe0(0x10)
	struct TArray<struct TSoftObjectPtr<UDCGameplayEffectDataAsset>> Effects; // 0xf0(0x10)
};

// Class DungeonCrawler.DCPerkDataComponent
// Size: 0xe0 (Inherited: 0xa0)
struct UDCPerkDataComponent : UActorComponent {
	struct FGameplayTagContainer WearableWeaponList; // 0xa0(0x20)
	struct FGameplayTagContainer RestrictedItemList; // 0xc0(0x20)

	void RemoveWearableWeaponList(struct FGameplayTagContainer& InWeaponList); // Function DungeonCrawler.DCPerkDataComponent.RemoveWearableWeaponList // (None) // @ game+0xffffbf7fdf830041
};

// Class DungeonCrawler.DCPlayerBlueprintFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UDCPlayerBlueprintFunctionLibrary : UBlueprintFunctionLibrary {

	struct APawn* GetCurrentPlayerPawn(struct UObject* WorldContextObject); // Function DungeonCrawler.DCPlayerBlueprintFunctionLibrary.GetCurrentPlayerPawn // (None) // @ game+0xffffbf80df830041
};

// Class DungeonCrawler.DCPlayerCharacterAnimInstanceBase
// Size: 0x520 (Inherited: 0x470)
struct UDCPlayerCharacterAnimInstanceBase : UDCCharacterAnimInstanceBase {
	bool bHoldingTwoHandedItem; // 0x468(0x01)
	bool bIsInFirstPersonPerspective; // 0x469(0x01)
	bool bIsResting; // 0x46a(0x01)
	bool bIsMontageLooping; // 0x46b(0x01)
	bool bIsFullbodyAnimating; // 0x46c(0x01)
	bool bIsPrimaryMontagePlaying; // 0x46d(0x01)
	bool bIsSecondaryMontagePlaying; // 0x46e(0x01)
	bool bIsTwoHandedMontagePlaying; // 0x46f(0x01)
	bool bIsSkillMontagePlaying; // 0x470(0x01)
	bool bIsEmotePlaying; // 0x471(0x01)
	struct FLocomotionAnimSet ItemAnimationSet; // 0x478(0x18)
	struct FLocomotionAnimSet SecondaryItemAnimationSet; // 0x490(0x18)
	struct FGameplayTagContainer PrimaryMontageTagContainer; // 0x4a8(0x20)
	struct FGameplayTagContainer SecondaryMontageTagContainer; // 0x4c8(0x20)
	struct FGameplayTagContainer TwoHandedMontageTagContainer; // 0x4e8(0x20)
	struct TArray<struct FName> LoopSectionNames; // 0x508(0x10)
	char pad_51A[0x6]; // 0x51a(0x06)
};

// Class DungeonCrawler.DCPlayerCharacterBase
// Size: 0x930 (Inherited: 0x880)
struct ADCPlayerCharacterBase : ADCCharacterBase {
	struct USkeletalMeshComponent* PartHead; // 0x880(0x08)
	struct USkeletalMeshComponent* PartHelmet; // 0x888(0x08)
	struct USkeletalMeshComponent* PartGloves; // 0x890(0x08)
	struct USkeletalMeshComponent* PartChest; // 0x898(0x08)
	struct USkeletalMeshComponent* PartPants; // 0x8a0(0x08)
	struct USkeletalMeshComponent* PartBoots; // 0x8a8(0x08)
	struct USkeletalMeshComponent* PartBack; // 0x8b0(0x08)
	struct FPrimaryAssetId MaxPerkSlotCountConstant; // 0x8b8(0x10)
	struct FPrimaryAssetId MaxSkillSlotCountConstant; // 0x8c8(0x10)
	struct TArray<struct FPrimaryAssetId> OwnedPerkIdArray; // 0x8d8(0x10)
	struct TArray<struct FPrimaryAssetId> OwnedSkillIdArray; // 0x8e8(0x10)
	struct UDCCharacterDataComponent* DataComponent; // 0x8f8(0x08)
	struct UDCCharacterPartsComponent* PartsComponent; // 0x900(0x08)
	struct UDCPerkDataComponent* PerkDataComponent; // 0x908(0x08)
	char pad_910[0x20]; // 0x910(0x20)

	void UpdateMeshHalfTranslucent(bool IsTranslucent, struct UMaterialInterface* Material); // Function DungeonCrawler.DCPlayerCharacterBase.UpdateMeshHalfTranslucent // (None) // @ game+0xffffbf89df830041
};

// Class DungeonCrawler.DCPlayerCharacterDataAsset
// Size: 0x150 (Inherited: 0x38)
struct UDCPlayerCharacterDataAsset : UDCDataAsset {
	struct FText Name; // 0x38(0x18)
	struct TSoftObjectPtr<UDescData> Dialog; // 0x50(0x30)
	struct TSoftObjectPtr<UDescData> ClassInfo; // 0x80(0x30)
	struct TSoftObjectPtr<UArtDataPlayerCharacter> ArtData; // 0xb0(0x30)
	struct TSoftObjectPtr<USoundData> SoundData; // 0xe0(0x30)
	struct TArray<struct TSoftObjectPtr<UDCEmoteDataAsset>> Emotes; // 0x110(0x10)
	struct TArray<struct TSoftObjectPtr<UDCGameplayAbilityDataAsset>> Abilities; // 0x120(0x10)
	struct TArray<struct TSoftObjectPtr<UDCGameplayEffectDataAsset>> Effects; // 0x130(0x10)
	struct TArray<struct TSoftObjectPtr<UDCPerkDataAsset>> Perks; // 0x140(0x10)
};

// Class DungeonCrawler.DCPlayerCharacterLobbyAnimInstanceBase
// Size: 0x350 (Inherited: 0x350)
struct UDCPlayerCharacterLobbyAnimInstanceBase : UAnimInstance {
	struct UAnimSequenceBase* Idle; // 0x348(0x08)
};

// Class DungeonCrawler.DCPlayerCharMovementComponent
// Size: 0xf60 (Inherited: 0xf10)
struct UDCPlayerCharMovementComponent : UDCCharacterMovementComponent {
	struct FPrimaryAssetId DoubleJumpAirControlConstantId; // 0xf10(0x10)
	char pad_F20[0x40]; // 0xf20(0x40)

	void SetIsTrapped(bool InbIsTrapped, struct FVector& InTrapPinnedLocation, float InTrapRange); // Function DungeonCrawler.DCPlayerCharMovementComponent.SetIsTrapped // (None) // @ game+0xffffbf8adf830041
};

// Class DungeonCrawler.DCPlayerChatComponent
// Size: 0x158 (Inherited: 0xa0)
struct UDCPlayerChatComponent : UActorComponent {
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x30(0x30)
	struct TArray<struct FName> ComponentTags; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	int32_t UCSSerializationIndex; // 0x84(0x04)
	char pad_F4_0 : 3; // 0xf4(0x01)
	char bNetAddressable : 1; // 0x88(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x88(0x01)
	char bReplicates : 1; // 0x88(0x01)
	char bAutoActivate : 1; // 0x8a(0x01)
	char bIsActive : 1; // 0x8a(0x01)
	char pad_F5_0 : 3; // 0xf5(0x01)
	char bEditableWhenInherited : 1; // 0x8a(0x01)
	char pad_F5_4 : 1; // 0xf5(0x01)
	char bCanEverAffectNavigation : 1; // 0x8a(0x01)
	char pad_F5_6 : 1; // 0xf5(0x01)
	char bIsEditorOnly : 1; // 0x8a(0x01)
	enum class EComponentCreationMethod CreationMethod; // 0x8d(0x01)
	struct FMulticastSparseDelegate OnComponentActivated; // 0x8e(0x01)
	struct FMulticastSparseDelegate OnComponentDeactivated; // 0x8f(0x01)
	char pad_F9[0x5f]; // 0xf9(0x5f)
};

// Class DungeonCrawler.DCPlayerController
// Size: 0xa28 (Inherited: 0x850)
struct ADCPlayerController : APlayerController {
	char pad_850[0x58]; // 0x850(0x58)
	struct UBaseObject* BaseObject; // 0x8a8(0x08)
	char pad_8B0[0x18]; // 0x8b0(0x18)
	struct ADCPortraitCharacter* PortraitCharacterClass; // 0x8c8(0x08)
	struct TArray<struct ADCPortraitCharacter*> PortraitCharacters; // 0x8d0(0x10)
	char pad_8E0[0x18]; // 0x8e0(0x18)
	struct FString AccountId; // 0x8f8(0x10)
	struct UAccountLink* AccountLink; // 0x908(0x08)
	struct FString TargetAccountId; // 0x910(0x10)
	char pad_920[0xf0]; // 0x920(0xf0)
	struct UDCLootComponent* LootComponent; // 0xa10(0x08)
	struct UDCInventoryControllerComponent* InventoryControllerComponent; // 0xa18(0x08)
	struct UDCReportSystem* ReportSystem; // 0xa20(0x08)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCPlayerController.UnbindMsgAll // (None) // @ game+0xffffbfb7df830041
};

// Class DungeonCrawler.DCPlayerInfoHolder
// Size: 0x320 (Inherited: 0x290)
struct ADCPlayerInfoHolder : AInfo {
	struct FDCPlayerInfo PlayerInfo; // 0x290(0x90)

	void OnRep_PlayerInfo(struct FDCPlayerInfo& OldPlayerInfo); // Function DungeonCrawler.DCPlayerInfoHolder.OnRep_PlayerInfo // (None) // @ game+0xffffbfb9df830041
};

// Class DungeonCrawler.DCPlayerInventoryWidget
// Size: 0x300 (Inherited: 0x2c0)
struct UDCPlayerInventoryWidget : UDCInventoryWidgetBase {
	bool bBagValid; // 0x2c0(0x01)
	char pad_2C1[0x7]; // 0x2c1(0x07)
	struct UDCEquipmentWidget* EquipWidget; // 0x2c8(0x08)
	struct UDCBagWidget* BagWidget; // 0x2d0(0x08)
	struct FNickname Nickname; // 0x2d8(0x28)

	struct FLinearColor GetTitleColor(); // Function DungeonCrawler.DCPlayerInventoryWidget.GetTitleColor // (None) // @ game+0xffffbffddf830041
};

// Class DungeonCrawler.DCPlayerManager
// Size: 0x1f0 (Inherited: 0x30)
struct UDCPlayerManager : UDCUserInfoManagerBase {
	char pad_30[0xc0]; // 0x30(0xc0)
	struct TMap<struct FDCAccountId, struct FDCPlayerInfo> PlayerInfos; // 0xf0(0x50)
	char pad_140[0xb0]; // 0x140(0xb0)
};

// Class DungeonCrawler.DCPlayerPoint
// Size: 0x2f0 (Inherited: 0x2c0)
struct ADCPlayerPoint : APlayerStart {
	float SpawningDistance; // 0x2c0(0x04)
	float SpawnTickAngle; // 0x2c4(0x04)
	char pad_2C8[0x10]; // 0x2c8(0x10)
	float SpawnAngle; // 0x2d8(0x04)
	char pad_2DC[0x14]; // 0x2dc(0x14)
};

// Class DungeonCrawler.DCPlayerStart
// Size: 0x2f0 (Inherited: 0x2f0)
struct ADCPlayerStart : ADCPlayerPoint {
	float SpawningDistance; // 0x2c0(0x04)
	float SpawnTickAngle; // 0x2c4(0x04)
	float SpawnAngle; // 0x2d8(0x04)
};

// Class DungeonCrawler.DCPlayerDown
// Size: 0x2f0 (Inherited: 0x2f0)
struct ADCPlayerDown : ADCPlayerPoint {
	float SpawningDistance; // 0x2c0(0x04)
	float SpawnTickAngle; // 0x2c4(0x04)
	float SpawnAngle; // 0x2d8(0x04)
};

// Class DungeonCrawler.DCPlayerSpectator
// Size: 0x388 (Inherited: 0x340)
struct ADCPlayerSpectator : ASpectatorPawn {
	char pad_340[0x30]; // 0x340(0x30)
	struct ADCCharacterBase* TargetPlayerCharacter; // 0x370(0x08)
	char pad_378[0x10]; // 0x378(0x10)
};

// Class DungeonCrawler.DCPortraitCharacter
// Size: 0x6b0 (Inherited: 0x680)
struct ADCPortraitCharacter : ADCCharacterV2 {
	struct FUint32Point Size; // 0x678(0x08)
	struct USceneCaptureComponent2D* PortraitCaptureComponent; // 0x680(0x08)
	struct UTextureRenderTarget2D* PortraitRenderTarget; // 0x688(0x08)
	char pad_698[0x8]; // 0x698(0x08)
	struct ADCPlayerCharacterBase* PlayerCharacter; // 0x6a0(0x08)
	char pad_6A8[0x8]; // 0x6a8(0x08)
};

// Class DungeonCrawler.DCPostProcessingComponent
// Size: 0x178 (Inherited: 0xa0)
struct UDCPostProcessingComponent : UActorComponent {
	struct FMulticastInlineDelegate OnPostProcessTimelineUpdate; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnPostProcessTimelineFinished; // 0xb0(0x10)
	struct UMaterialInstanceDynamic* DynamicMaterialTimeline; // 0xc0(0x08)
	struct UCurveFloat* TimelineCurve; // 0xc8(0x08)
	struct FTimeline PostProcessTimeline; // 0xd0(0x98)
	enum class ETimelineDirection TimelineDirection; // 0x168(0x01)
	char pad_169[0xf]; // 0x169(0x0f)

	bool UpdatePostProcessTimelineMaterial(); // Function DungeonCrawler.DCPostProcessingComponent.UpdatePostProcessTimelineMaterial // (None) // @ game+0xffffbfc3df830041
};

// Class DungeonCrawler.DCPreLobbyGameMode
// Size: 0x430 (Inherited: 0x3a0)
struct ADCPreLobbyGameMode : ADCMetaGameMode {
	struct ADCCharacterV2* PreviewCharacterClass; // 0x3a0(0x08)
	char pad_3A8[0x8]; // 0x3a8(0x08)
	struct FTransform PreviewCharacterTransform; // 0x3b0(0x60)
	struct ADCCharacterV2* PreviewCharacter; // 0x410(0x08)
	struct ACameraActor* SelectCharacterCameraActor; // 0x418(0x08)
	enum class EDCPreLobbyMenu Menu; // 0x420(0x01)
	char pad_421[0xf]; // 0x421(0x0f)

	void SetPreviewCharacter(enum class EDCCharacterClass CharacterClass, enum class EDCGender Gender); // Function DungeonCrawler.DCPreLobbyGameMode.SetPreviewCharacter // (None) // @ game+0xffffbfc5df830041
};

// Class DungeonCrawler.DCProjectileAttributeSet
// Size: 0x680 (Inherited: 0x680)
struct UDCProjectileAttributeSet : UDCAttributeSet {
	struct FGameplayAttributeData Strength; // 0x30(0x10)
	struct FGameplayAttributeData StrengthBase; // 0x40(0x10)
	struct FGameplayAttributeData StrengthMod; // 0x50(0x10)
	struct FGameplayAttributeData Agility; // 0x60(0x10)
	struct FGameplayAttributeData AgilityBase; // 0x70(0x10)
	struct FGameplayAttributeData AgilityMod; // 0x80(0x10)
	struct FGameplayAttributeData Will; // 0x90(0x10)
	struct FGameplayAttributeData WillBase; // 0xa0(0x10)
	struct FGameplayAttributeData WillMod; // 0xb0(0x10)
	struct FGameplayAttributeData Knowledge; // 0xc0(0x10)
	struct FGameplayAttributeData KnowledgeBase; // 0xd0(0x10)
	struct FGameplayAttributeData KnowledgeMod; // 0xe0(0x10)
	struct FGameplayAttributeData Resourcefulness; // 0xf0(0x10)
	struct FGameplayAttributeData ResourcefulnessBase; // 0x100(0x10)
	struct FGameplayAttributeData ResourcefulnessMod; // 0x110(0x10)
	struct FGameplayAttributeData PhysicalDamageWeaponPrimary; // 0x120(0x10)
	struct FGameplayAttributeData PhysicalDamageWeaponSecondary; // 0x130(0x10)
	struct FGameplayAttributeData PhysicalDamageBase; // 0x140(0x10)
	struct FGameplayAttributeData PhysicalPower; // 0x150(0x10)
	struct FGameplayAttributeData PhysicalDamageMod; // 0x160(0x10)
	struct FGameplayAttributeData PhysicalDamageAdd; // 0x170(0x10)
	struct FGameplayAttributeData PhysicalDamageTrue; // 0x180(0x10)
	struct FGameplayAttributeData PhysicalBackstabPower; // 0x190(0x10)
	struct FGameplayAttributeData PhysicalHeadshotPower; // 0x1a0(0x10)
	struct FGameplayAttributeData PhysicalHeadshotPenetration; // 0x1b0(0x10)
	struct FGameplayAttributeData ArmorPenetration; // 0x1c0(0x10)
	struct FGameplayAttributeData ArmorRating; // 0x1d0(0x10)
	struct FGameplayAttributeData ItemArmorRating; // 0x1e0(0x10)
	struct FGameplayAttributeData ItemArmorRatingMod; // 0x1f0(0x10)
	struct FGameplayAttributeData PhysicalReduction; // 0x200(0x10)
	struct FGameplayAttributeData PhysicalReductionMod; // 0x210(0x10)
	struct FGameplayAttributeData PhysicalAbsoluteReduction; // 0x220(0x10)
	struct FGameplayAttributeData MagicalDamageWeaponPrimary; // 0x230(0x10)
	struct FGameplayAttributeData MagicalDamageWeaponSecondary; // 0x240(0x10)
	struct FGameplayAttributeData MagicalDamageBase; // 0x250(0x10)
	struct FGameplayAttributeData MagicalPower; // 0x260(0x10)
	struct FGameplayAttributeData MagicalDamageMod; // 0x270(0x10)
	struct FGameplayAttributeData MagicalDamageAdd; // 0x280(0x10)
	struct FGameplayAttributeData MagicalDamageTrue; // 0x290(0x10)
	struct FGameplayAttributeData MagicPenetration; // 0x2a0(0x10)
	struct FGameplayAttributeData MagicalFireDamageBase; // 0x2b0(0x10)
	struct FGameplayAttributeData MagicalFireDamageMod; // 0x2c0(0x10)
	struct FGameplayAttributeData MagicalFireDamageAdd; // 0x2d0(0x10)
	struct FGameplayAttributeData MagicalArcaneDamageBase; // 0x2e0(0x10)
	struct FGameplayAttributeData MagicalArcaneDamageMod; // 0x2f0(0x10)
	struct FGameplayAttributeData MagicalArcaneDamageAdd; // 0x300(0x10)
	struct FGameplayAttributeData MagicResistance; // 0x310(0x10)
	struct FGameplayAttributeData MagicalReduction; // 0x320(0x10)
	struct FGameplayAttributeData MagicalReductionMod; // 0x330(0x10)
	struct FGameplayAttributeData MagicalAbsoluteReduction; // 0x340(0x10)
	struct FGameplayAttributeData HeadshotReductionMod; // 0x350(0x10)
	struct FGameplayAttributeData ProjectileReductionMod; // 0x360(0x10)
	struct FGameplayAttributeData ImpactPower; // 0x370(0x10)
	struct FGameplayAttributeData ImpactResistance; // 0x380(0x10)
	struct FGameplayAttributeData ImpactEndurance; // 0x390(0x10)
	struct FGameplayAttributeData MaxImpactEndurance; // 0x3a0(0x10)
	struct FGameplayAttributeData PhysicalHealBase; // 0x3b8(0x10)
	struct FGameplayAttributeData MagicalHealBase; // 0x3c8(0x10)
	struct FGameplayAttributeData RecoverableHealth; // 0x3d8(0x10)
	struct FGameplayAttributeData Health; // 0x3e8(0x10)
	struct FGameplayAttributeData MaxHealth; // 0x3f8(0x10)
	struct FGameplayAttributeData MaxHealthBase; // 0x410(0x10)
	struct FGameplayAttributeData MaxHealthMod; // 0x420(0x10)
	struct FGameplayAttributeData MaxHealthAdd; // 0x430(0x10)
	struct FGameplayAttributeData PhysicalShield; // 0x440(0x10)
	struct FGameplayAttributeData MaxPhysicalShield; // 0x450(0x10)
	struct FGameplayAttributeData MagicalShield; // 0x460(0x10)
	struct FGameplayAttributeData MaxMagicalShield; // 0x470(0x10)
	struct FGameplayAttributeData TotalShield; // 0x480(0x10)
	struct FGameplayAttributeData MaxTotalShield; // 0x490(0x10)
	struct FGameplayAttributeData SpellPayload; // 0x4a0(0x10)
	struct FGameplayAttributeData SpellCapacity; // 0x4b0(0x10)
	struct FGameplayAttributeData SpellCapacityBase; // 0x4c0(0x10)
	struct FGameplayAttributeData SpellCapacityMod; // 0x4d0(0x10)
	struct FGameplayAttributeData SpellCapacityAdd; // 0x4e0(0x10)
	struct FGameplayAttributeData MoveSpeed; // 0x4f0(0x10)
	struct FGameplayAttributeData MoveSpeedBase; // 0x500(0x10)
	struct FGameplayAttributeData MoveSpeedMod; // 0x510(0x10)
	struct FGameplayAttributeData MoveSpeedAdd; // 0x520(0x10)
	struct FGameplayAttributeData MoveSpeedArmorPenalty; // 0x530(0x10)
	struct FGameplayAttributeData MoveSpeedArmorPenaltyMod; // 0x540(0x10)
	struct FGameplayAttributeData MoveSpeedWithModifier; // 0x550(0x10)
	struct FGameplayAttributeData ActionSpeed; // 0x560(0x10)
	struct FGameplayAttributeData SpellCastingSpeed; // 0x570(0x10)
	struct FGameplayAttributeData ItemEquipSpeed; // 0x580(0x10)
	struct FGameplayAttributeData RegularInteractionSpeedBase; // 0x590(0x10)
	struct FGameplayAttributeData RegularInteractionSpeed; // 0x5a0(0x10)
	struct FGameplayAttributeData MagicalInteractionSpeed; // 0x5b0(0x10)
	struct FGameplayAttributeData BuffDurationMod; // 0x5c0(0x10)
	struct FGameplayAttributeData DebuffDurationMod; // 0x5d0(0x10)
	struct FGameplayAttributeData UtilityEffectiveness; // 0x5e0(0x10)
	struct FGameplayAttributeData UtilityEffectivenessBase; // 0x5f0(0x10)
	struct FGameplayAttributeData UtilityEffectivenessMod; // 0x600(0x10)
	struct FGameplayAttributeData UtilityEffectivenessAdd; // 0x610(0x10)
	struct FGameplayAttributeData Weight; // 0x620(0x10)
	struct FGameplayAttributeData WeightLimit; // 0x630(0x10)
	struct FGameplayAttributeData WeightLimitBase; // 0x640(0x10)
	struct FGameplayAttributeData WeightLimitMod; // 0x650(0x10)
	struct FGameplayAttributeData WeightLimitAdd; // 0x660(0x10)
	struct FGameplayAttributeData PrestigeItemDrop; // 0x670(0x10)
};

// Class DungeonCrawler.DCProjectileDataAsset
// Size: 0xe0 (Inherited: 0x38)
struct UDCProjectileDataAsset : UDCDataAsset {
	struct FText Name; // 0x38(0x18)
	struct FGameplayTag SourceType; // 0x50(0x08)
	struct TSoftObjectPtr<UArtDataProjectile> ArtData; // 0x58(0x30)
	struct TSoftObjectPtr<USoundData> SoundData; // 0x88(0x30)
	struct AProjectileActor* ActorClass; // 0xb8(0x08)
	struct TArray<struct TSoftObjectPtr<UDCGameplayAbilityDataAsset>> Abilities; // 0xc0(0x10)
	struct TArray<struct TSoftObjectPtr<UDCGameplayEffectDataAsset>> Effects; // 0xd0(0x10)
};

// Class DungeonCrawler.DCProjectSettings
// Size: 0x118 (Inherited: 0x118)
struct UDCProjectSettings : UGeneralProjectSettings {
	struct FString CompanyName; // 0x28(0x10)
	struct FString CompanyDistinguishedName; // 0x38(0x10)
	struct FString CopyrightNotice; // 0x48(0x10)
	struct FString Description; // 0x58(0x10)
	struct FString Homepage; // 0x68(0x10)
	struct FString LicensingTerms; // 0x78(0x10)
	struct FString PrivacyPolicy; // 0x88(0x10)
	struct FGuid ProjectID; // 0x98(0x10)
	struct FString ProjectName; // 0xa8(0x10)
	struct FString ProjectVersion; // 0xb8(0x10)
	struct FString SupportContact; // 0xc8(0x10)
	struct FText ProjectDisplayedTitle; // 0xd8(0x18)
	struct FText ProjectDebugTitleInfo; // 0xf0(0x18)
	bool bShouldWindowPreserveAspectRatio; // 0x108(0x01)
	bool bUseBorderlessWindow; // 0x109(0x01)
	bool bStartInVR; // 0x10a(0x01)
	bool bAllowWindowResize; // 0x10b(0x01)
	bool bAllowClose; // 0x10c(0x01)
	bool bAllowMaximize; // 0x10d(0x01)
	bool bAllowMinimize; // 0x10e(0x01)
	float EyeOffsetForFakeStereoRenderingDevice; // 0x110(0x04)
	float FOVForFakeStereoRenderingDevice; // 0x114(0x04)
};

// Class DungeonCrawler.DCPropAttributeSet
// Size: 0x680 (Inherited: 0x680)
struct UDCPropAttributeSet : UDCAttributeSet {
	struct FGameplayAttributeData Strength; // 0x30(0x10)
	struct FGameplayAttributeData StrengthBase; // 0x40(0x10)
	struct FGameplayAttributeData StrengthMod; // 0x50(0x10)
	struct FGameplayAttributeData Agility; // 0x60(0x10)
	struct FGameplayAttributeData AgilityBase; // 0x70(0x10)
	struct FGameplayAttributeData AgilityMod; // 0x80(0x10)
	struct FGameplayAttributeData Will; // 0x90(0x10)
	struct FGameplayAttributeData WillBase; // 0xa0(0x10)
	struct FGameplayAttributeData WillMod; // 0xb0(0x10)
	struct FGameplayAttributeData Knowledge; // 0xc0(0x10)
	struct FGameplayAttributeData KnowledgeBase; // 0xd0(0x10)
	struct FGameplayAttributeData KnowledgeMod; // 0xe0(0x10)
	struct FGameplayAttributeData Resourcefulness; // 0xf0(0x10)
	struct FGameplayAttributeData ResourcefulnessBase; // 0x100(0x10)
	struct FGameplayAttributeData ResourcefulnessMod; // 0x110(0x10)
	struct FGameplayAttributeData PhysicalDamageWeaponPrimary; // 0x120(0x10)
	struct FGameplayAttributeData PhysicalDamageWeaponSecondary; // 0x130(0x10)
	struct FGameplayAttributeData PhysicalDamageBase; // 0x140(0x10)
	struct FGameplayAttributeData PhysicalPower; // 0x150(0x10)
	struct FGameplayAttributeData PhysicalDamageMod; // 0x160(0x10)
	struct FGameplayAttributeData PhysicalDamageAdd; // 0x170(0x10)
	struct FGameplayAttributeData PhysicalDamageTrue; // 0x180(0x10)
	struct FGameplayAttributeData PhysicalBackstabPower; // 0x190(0x10)
	struct FGameplayAttributeData PhysicalHeadshotPower; // 0x1a0(0x10)
	struct FGameplayAttributeData PhysicalHeadshotPenetration; // 0x1b0(0x10)
	struct FGameplayAttributeData ArmorPenetration; // 0x1c0(0x10)
	struct FGameplayAttributeData ArmorRating; // 0x1d0(0x10)
	struct FGameplayAttributeData ItemArmorRating; // 0x1e0(0x10)
	struct FGameplayAttributeData ItemArmorRatingMod; // 0x1f0(0x10)
	struct FGameplayAttributeData PhysicalReduction; // 0x200(0x10)
	struct FGameplayAttributeData PhysicalReductionMod; // 0x210(0x10)
	struct FGameplayAttributeData PhysicalAbsoluteReduction; // 0x220(0x10)
	struct FGameplayAttributeData MagicalDamageWeaponPrimary; // 0x230(0x10)
	struct FGameplayAttributeData MagicalDamageWeaponSecondary; // 0x240(0x10)
	struct FGameplayAttributeData MagicalDamageBase; // 0x250(0x10)
	struct FGameplayAttributeData MagicalPower; // 0x260(0x10)
	struct FGameplayAttributeData MagicalDamageMod; // 0x270(0x10)
	struct FGameplayAttributeData MagicalDamageAdd; // 0x280(0x10)
	struct FGameplayAttributeData MagicalDamageTrue; // 0x290(0x10)
	struct FGameplayAttributeData MagicPenetration; // 0x2a0(0x10)
	struct FGameplayAttributeData MagicalFireDamageBase; // 0x2b0(0x10)
	struct FGameplayAttributeData MagicalFireDamageMod; // 0x2c0(0x10)
	struct FGameplayAttributeData MagicalFireDamageAdd; // 0x2d0(0x10)
	struct FGameplayAttributeData MagicalArcaneDamageBase; // 0x2e0(0x10)
	struct FGameplayAttributeData MagicalArcaneDamageMod; // 0x2f0(0x10)
	struct FGameplayAttributeData MagicalArcaneDamageAdd; // 0x300(0x10)
	struct FGameplayAttributeData MagicResistance; // 0x310(0x10)
	struct FGameplayAttributeData MagicalReduction; // 0x320(0x10)
	struct FGameplayAttributeData MagicalReductionMod; // 0x330(0x10)
	struct FGameplayAttributeData MagicalAbsoluteReduction; // 0x340(0x10)
	struct FGameplayAttributeData HeadshotReductionMod; // 0x350(0x10)
	struct FGameplayAttributeData ProjectileReductionMod; // 0x360(0x10)
	struct FGameplayAttributeData ImpactPower; // 0x370(0x10)
	struct FGameplayAttributeData ImpactResistance; // 0x380(0x10)
	struct FGameplayAttributeData ImpactEndurance; // 0x390(0x10)
	struct FGameplayAttributeData MaxImpactEndurance; // 0x3a0(0x10)
	struct FGameplayAttributeData PhysicalHealBase; // 0x3b8(0x10)
	struct FGameplayAttributeData MagicalHealBase; // 0x3c8(0x10)
	struct FGameplayAttributeData RecoverableHealth; // 0x3d8(0x10)
	struct FGameplayAttributeData Health; // 0x3e8(0x10)
	struct FGameplayAttributeData MaxHealth; // 0x3f8(0x10)
	struct FGameplayAttributeData MaxHealthBase; // 0x410(0x10)
	struct FGameplayAttributeData MaxHealthMod; // 0x420(0x10)
	struct FGameplayAttributeData MaxHealthAdd; // 0x430(0x10)
	struct FGameplayAttributeData PhysicalShield; // 0x440(0x10)
	struct FGameplayAttributeData MaxPhysicalShield; // 0x450(0x10)
	struct FGameplayAttributeData MagicalShield; // 0x460(0x10)
	struct FGameplayAttributeData MaxMagicalShield; // 0x470(0x10)
	struct FGameplayAttributeData TotalShield; // 0x480(0x10)
	struct FGameplayAttributeData MaxTotalShield; // 0x490(0x10)
	struct FGameplayAttributeData SpellPayload; // 0x4a0(0x10)
	struct FGameplayAttributeData SpellCapacity; // 0x4b0(0x10)
	struct FGameplayAttributeData SpellCapacityBase; // 0x4c0(0x10)
	struct FGameplayAttributeData SpellCapacityMod; // 0x4d0(0x10)
	struct FGameplayAttributeData SpellCapacityAdd; // 0x4e0(0x10)
	struct FGameplayAttributeData MoveSpeed; // 0x4f0(0x10)
	struct FGameplayAttributeData MoveSpeedBase; // 0x500(0x10)
	struct FGameplayAttributeData MoveSpeedMod; // 0x510(0x10)
	struct FGameplayAttributeData MoveSpeedAdd; // 0x520(0x10)
	struct FGameplayAttributeData MoveSpeedArmorPenalty; // 0x530(0x10)
	struct FGameplayAttributeData MoveSpeedArmorPenaltyMod; // 0x540(0x10)
	struct FGameplayAttributeData MoveSpeedWithModifier; // 0x550(0x10)
	struct FGameplayAttributeData ActionSpeed; // 0x560(0x10)
	struct FGameplayAttributeData SpellCastingSpeed; // 0x570(0x10)
	struct FGameplayAttributeData ItemEquipSpeed; // 0x580(0x10)
	struct FGameplayAttributeData RegularInteractionSpeedBase; // 0x590(0x10)
	struct FGameplayAttributeData RegularInteractionSpeed; // 0x5a0(0x10)
	struct FGameplayAttributeData MagicalInteractionSpeed; // 0x5b0(0x10)
	struct FGameplayAttributeData BuffDurationMod; // 0x5c0(0x10)
	struct FGameplayAttributeData DebuffDurationMod; // 0x5d0(0x10)
	struct FGameplayAttributeData UtilityEffectiveness; // 0x5e0(0x10)
	struct FGameplayAttributeData UtilityEffectivenessBase; // 0x5f0(0x10)
	struct FGameplayAttributeData UtilityEffectivenessMod; // 0x600(0x10)
	struct FGameplayAttributeData UtilityEffectivenessAdd; // 0x610(0x10)
	struct FGameplayAttributeData Weight; // 0x620(0x10)
	struct FGameplayAttributeData WeightLimit; // 0x630(0x10)
	struct FGameplayAttributeData WeightLimitBase; // 0x640(0x10)
	struct FGameplayAttributeData WeightLimitMod; // 0x650(0x10)
	struct FGameplayAttributeData WeightLimitAdd; // 0x660(0x10)
	struct FGameplayAttributeData PrestigeItemDrop; // 0x670(0x10)
};

// Class DungeonCrawler.DCPropsSkillCheckDataAsset
// Size: 0x68 (Inherited: 0x38)
struct UDCPropsSkillCheckDataAsset : UDCDataAsset {
	struct FGameplayTag SkillCheckType; // 0x38(0x08)
	float MinDuration; // 0x40(0x04)
	float MaxDuration; // 0x44(0x04)
	float MinSkillCheckInterval; // 0x48(0x04)
	float MaxSkillCheckInterval; // 0x4c(0x04)
	float MinSucceedSectionStartTime; // 0x50(0x04)
	float SucceedSectionSizeSeconds; // 0x54(0x04)
	float SucceedBonusTimeRatio; // 0x58(0x04)
	float PerfectSucceedSectionSizeSeconds; // 0x5c(0x04)
	float PerfectSucceedBonusTimeRatio; // 0x60(0x04)
	float FailedBonusTimeRatio; // 0x64(0x04)
};

// Class DungeonCrawler.DCPropsInteractDataAsset
// Size: 0x158 (Inherited: 0x38)
struct UDCPropsInteractDataAsset : UDCDataAsset {
	struct FText InteractionName; // 0x38(0x18)
	struct FText InteractionText; // 0x50(0x18)
	struct TSoftObjectPtr<UInteractData> InteractData; // 0x68(0x30)
	struct TArray<struct FGameplayTag> InteractTypes; // 0x98(0x10)
	float Duration; // 0xa8(0x04)
	struct FGameplayTag InteractableTag; // 0xac(0x08)
	struct FGameplayTag TriggerTag; // 0xb4(0x08)
	struct FGameplayTag AbilityTriggerTag; // 0xbc(0x08)
	char pad_C4[0x4]; // 0xc4(0x04)
	struct TSoftObjectPtr<UTagQueryData> DetectTagQueryData; // 0xc8(0x30)
	struct TSoftObjectPtr<UTagQueryData> InteractTagQueryData; // 0xf8(0x30)
	struct TSoftObjectPtr<UDCPropsSkillCheckDataAsset> SkillCheckData; // 0x128(0x30)
};

// Class DungeonCrawler.DCPropsDataAsset
// Size: 0xd8 (Inherited: 0x38)
struct UDCPropsDataAsset : UDCDataAsset {
	struct FText Name; // 0x38(0x18)
	struct TSoftObjectPtr<USoundData> SoundData; // 0x50(0x30)
	struct APropsActorBase* ActorClass; // 0x80(0x08)
	int32_t InteractionMinCount; // 0x88(0x04)
	int32_t InteractionMaxCount; // 0x8c(0x04)
	struct TArray<struct TSoftObjectPtr<UDCPropsInteractDataAsset>> InteractionSettingDatas; // 0x90(0x10)
	struct TArray<struct TSoftObjectPtr<UTagQueryData>> DestructibleTagQueryData; // 0xa0(0x10)
	struct TArray<struct TSoftObjectPtr<UDCGameplayAbilityDataAsset>> Abilities; // 0xb0(0x10)
	struct TArray<struct TSoftObjectPtr<UDCGameplayEffectDataAsset>> Effects; // 0xc0(0x10)
	int32_t AdvPoint; // 0xd0(0x04)
	int32_t ExpPoint; // 0xd4(0x04)
};

// Class DungeonCrawler.DCRecruitChannelListEntryWidget
// Size: 0x2b0 (Inherited: 0x278)
struct UDCRecruitChannelListEntryWidget : UUserWidget {
	char pad_278[0x18]; // 0x278(0x18)
	struct FText ChannelTitle; // 0x290(0x18)
	int32_t NumMembers; // 0x2a8(0x04)
	char pad_2AC[0x4]; // 0x2ac(0x04)

	void OnClicked(); // Function DungeonCrawler.DCRecruitChannelListEntryWidget.OnClicked // (None) // @ game+0xffffbfc6df830041
};

// Class DungeonCrawler.DCRecruitChannelListWidget
// Size: 0x4a8 (Inherited: 0x470)
struct UDCRecruitChannelListWidget : ULobbyGroupWidgetBase {
	struct TArray<struct FDCRecruitChannelInfo> Channels; // 0x470(0x10)
	struct UVerticalBox* ServerRegionVerticalBox; // 0x480(0x08)
	struct UDCRecruitChannelListEntryWidget* ChannelEntryWidgetClass; // 0x488(0x08)
	struct FText JoinMinLevelText; // 0x490(0x18)
};

// Class DungeonCrawler.DCRecruitChannelWidget
// Size: 0x4c8 (Inherited: 0x470)
struct UDCRecruitChannelWidget : ULobbyGroupWidgetBase {
	struct UDCChannelChatWidget* ChannelChatWidget; // 0x470(0x08)
	struct UDCChannelPlayerListWidget* ChannelPlayersWidget; // 0x478(0x08)
	struct UWidgetSwitcher* InventoryWidgetSwitcher; // 0x480(0x08)
	struct UDCInventorySetWidget* LocalInventorySetWidget; // 0x488(0x08)
	struct UDCPlayerInventoryWidget* InspectingPlayerInventoryWidget; // 0x490(0x08)
	struct FText ChannelTitle; // 0x498(0x18)
	char pad_4B0[0x18]; // 0x4b0(0x18)

	void OnLeaveClicked(); // Function DungeonCrawler.DCRecruitChannelWidget.OnLeaveClicked // (None) // @ game+0xffffbfc9df830041
};

// Class DungeonCrawler.DCRecruitComponent
// Size: 0x248 (Inherited: 0xa0)
struct UDCRecruitComponent : UActorComponent {
	char pad_A0[0x90]; // 0xa0(0x90)
	struct UDCInventoryComponent* InventoryComponent; // 0x130(0x08)
	char pad_138[0x110]; // 0x138(0x110)

	void OnItemMoveEvent(enum class EDCInventoryId SourceInventoryId, struct FDCItemInfo& SourceItemInfo, enum class EDCInventoryId TargetInventoryId, int32_t TargetIndex, int32_t TargetStack); // Function DungeonCrawler.DCRecruitComponent.OnItemMoveEvent // (None) // @ game+0xffffbfcbdf830041
};

// Class DungeonCrawler.DCReplicationGraph
// Size: 0x5a0 (Inherited: 0x570)
struct UDCReplicationGraph : UReplicationGraph {
	struct UReplicationGraphNode_GridSpatialization2D* GridNode; // 0x570(0x08)
	struct UReplicationGraphNode_ActorList* AlwaysRelevantNode; // 0x578(0x08)
	struct TArray<struct FDCConnectionAlwaysRelevantNodePair> AlwaysRelevantForConnectionList; // 0x580(0x10)
	struct TArray<struct AActor*> ActorsWithoutNetConnection; // 0x590(0x10)
};

// Class DungeonCrawler.DCReportPlayerChecklistSlotWidget
// Size: 0x2d8 (Inherited: 0x278)
struct UDCReportPlayerChecklistSlotWidget : UUserWidget {
	char pad_278[0x18]; // 0x278(0x18)
	struct UCheckBox* ReportCheckBox; // 0x290(0x08)
	char pad_298[0x8]; // 0x298(0x08)
	struct FText ReportCategoryTitleText; // 0x2a0(0x18)
	struct FText ReportCategoryDetailText; // 0x2b8(0x18)
	char pad_2D0[0x8]; // 0x2d0(0x08)

	void HandleChangedCheckState(bool bNewState); // Function DungeonCrawler.DCReportPlayerChecklistSlotWidget.HandleChangedCheckState // (None) // @ game+0xffffbfcddf830041
};

// Class DungeonCrawler.DCReportPlayerResultPopupData
// Size: 0x48 (Inherited: 0x30)
struct UDCReportPlayerResultPopupData : UPopupDataBase {
	struct FText TargetNicknameListText; // 0x30(0x18)
};

// Class DungeonCrawler.DCReportPlayerResultPopup
// Size: 0x468 (Inherited: 0x440)
struct UDCReportPlayerResultPopup : UCommonPopupBase {
	struct UDCReportPlayerResultPopupData* ReportPlayerResultPopupData; // 0x440(0x08)
	struct UCommonButtonPopupWidget* Btn_Single; // 0x448(0x08)
	struct FText TargetNicknameListText; // 0x450(0x18)

	void HandleConfirmButtonClicked(); // Function DungeonCrawler.DCReportPlayerResultPopup.HandleConfirmButtonClicked // (None) // @ game+0xffffbfcedf830041
};

// Class DungeonCrawler.DCReportPlayerWidget
// Size: 0x358 (Inherited: 0x278)
struct UDCReportPlayerWidget : UUserWidget {
	struct UDCReportPlayerChecklistSlotWidget* ReportPlayerChecklistWidgetClass; // 0x278(0x08)
	struct UCommonButtonPopupWidget* Btn_Cancel; // 0x280(0x08)
	struct UCommonButtonPopupWidget* Btn_Report; // 0x288(0x08)
	struct UMultiLineEditableTextBox* ReportEditableMultiTextBox; // 0x290(0x08)
	struct UVerticalBox* ReportCategoryCheckList; // 0x298(0x08)
	struct FText SelectReportCategoryText; // 0x2a0(0x18)
	struct FText TargetUserNickname; // 0x2b8(0x18)
	struct FText ReportHintText; // 0x2d0(0x18)
	struct FText ReportTextMaxCountText; // 0x2e8(0x18)
	struct FText ReportTextCurrentCountText; // 0x300(0x18)
	struct FNickname ReportTargetNickname; // 0x318(0x28)
	enum class EDCReportPlayerCategory SelectedCategory; // 0x340(0x01)
	bool bIsReportButtonClicked; // 0x341(0x01)
	char pad_342[0x2]; // 0x342(0x02)
	struct FPrimaryAssetId MaxCharacterCountReportTextConstant; // 0x344(0x10)
	int32_t MaxCharacterCount; // 0x354(0x04)

	void HandleReportTextChanged(struct FText& InText); // Function DungeonCrawler.DCReportPlayerWidget.HandleReportTextChanged // (None) // @ game+0xffffbfd3df830041
};

// Class DungeonCrawler.DCResource
// Size: 0x368 (Inherited: 0x28)
struct UDCResource : UObject {
	struct TMap<enum class EDCGender, struct UDCCharacterPartsArtData*> CharacterPartsDataMap; // 0x28(0x50)
	struct TMap<struct FDCPlayerCharacterKey, struct FDCPlayerCharacterData> PlayerCharacterDataMap; // 0x78(0x50)
	struct TMap<enum class EDCGender, struct TSoftObjectPtr<USoundData>> CharacterSounds; // 0xc8(0x50)
	struct TMap<enum class EDCGender, struct ADCCharacterProduction*> ProductionMap; // 0x118(0x50)
	struct UDCInputConfigData* InputConfigData; // 0x168(0x08)
	struct TArray<struct FMappableConfigPair> MappableConfigPairs; // 0x170(0x10)
	struct UDCContextMenuWidget* ContextMenuWidgetClass; // 0x180(0x08)
	struct TMap<struct FGameplayAttribute, struct FText> AttributeDisplayNameMap; // 0x188(0x50)
	struct FDCMerchantAssetManager MerchantAssetManager; // 0x1d8(0x140)
	struct TMap<enum class EGameDifficultyType, struct TSoftObjectPtr<UWorld>> WaitingMaps; // 0x318(0x50)
};

// Class DungeonCrawler.DCShopArtData
// Size: 0x40 (Inherited: 0x38)
struct UDCShopArtData : UDCDataAssetBase {
	struct UTexture2D* ShopIconTexture; // 0x38(0x08)
};

// Class DungeonCrawler.DCShopDataAsset
// Size: 0x70 (Inherited: 0x38)
struct UDCShopDataAsset : UDCDataAsset {
	struct TSoftObjectPtr<UDCShopArtData> ArtData; // 0x38(0x30)
	int32_t Price; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// Class DungeonCrawler.DCCharacterSkinShopDataAsset
// Size: 0xa0 (Inherited: 0x70)
struct UDCCharacterSkinShopDataAsset : UDCShopDataAsset {
	struct TSoftObjectPtr<UDCCharacterSkinDataAsset> StockData; // 0x70(0x30)
};

// Class DungeonCrawler.DCItemSkinShopDataAsset
// Size: 0xa0 (Inherited: 0x70)
struct UDCItemSkinShopDataAsset : UDCShopDataAsset {
	struct TSoftObjectPtr<UDCItemSkinDataAsset> StockData; // 0x70(0x30)
};

// Class DungeonCrawler.DCEmoteShopDataAsset
// Size: 0xa0 (Inherited: 0x70)
struct UDCEmoteShopDataAsset : UDCShopDataAsset {
	struct TSoftObjectPtr<UDCEmoteDataAsset> StockData; // 0x70(0x30)
};

// Class DungeonCrawler.DCLobbyEmoteShopDataAsset
// Size: 0xa0 (Inherited: 0x70)
struct UDCLobbyEmoteShopDataAsset : UDCShopDataAsset {
	struct TSoftObjectPtr<UDCLobbyEmoteDataAsset> StockData; // 0x70(0x30)
};

// Class DungeonCrawler.DCActionSkinShopDataAsset
// Size: 0xa0 (Inherited: 0x70)
struct UDCActionSkinShopDataAsset : UDCShopDataAsset {
	struct TSoftObjectPtr<UDCActionSkinDataAsset> StockData; // 0x70(0x30)
};

// Class DungeonCrawler.DCShopItemListWidget
// Size: 0x330 (Inherited: 0x300)
struct UDCShopItemListWidget : UDCWidgetBase {
	char pad_300[0x18]; // 0x300(0x18)
	struct UPanelWidget* ShopItemListWidget; // 0x318(0x08)
	char pad_320[0x10]; // 0x320(0x10)
};

// Class DungeonCrawler.DCShopItemSlotWidget
// Size: 0x430 (Inherited: 0x368)
struct UDCShopItemSlotWidget : UDCControlWidgetBase {
	char pad_368[0x18]; // 0x368(0x18)
	struct FText ShopItemNameText; // 0x380(0x18)
	struct TArray<struct FText> ShopItemDescTextArray; // 0x398(0x10)
	struct FText ShopItemFlavorText; // 0x3a8(0x18)
	struct FText ShopItemTypeText; // 0x3c0(0x18)
	struct UTexture2D* ShopItemIconTexture; // 0x3d8(0x08)
	int32_t Price; // 0x3e0(0x04)
	char pad_3E4[0x4]; // 0x3e4(0x04)
	struct UDCSkinTooltipWidget* SkinTooltipWidgetClass; // 0x3e8(0x08)
	struct FSlateColor TooltipColor; // 0x3f0(0x14)
	char pad_404[0x1c]; // 0x404(0x1c)
	struct UUserWidget* EmoteTooltipWidget; // 0x420(0x08)
	struct UUserWidget* SkinTooltipWidget; // 0x428(0x08)

	struct UUserWidget* GetTooltipWidget(); // Function DungeonCrawler.DCShopItemSlotWidget.GetTooltipWidget // (None) // @ game+0xffffbfd7df830041
};

// Class DungeonCrawler.DCShopWidgetBase
// Size: 0x3a0 (Inherited: 0x300)
struct UDCShopWidgetBase : UDCWidgetBase {
	int32_t AdventureCurrencyValue; // 0x300(0x04)
	int32_t CurrentPageIndex; // 0x304(0x04)
	int32_t MaxPageIndex; // 0x308(0x04)
	char pad_30C[0x4]; // 0x30c(0x04)
	struct FText SelectedShopItemName; // 0x310(0x18)
	bool bIsFirstPage; // 0x328(0x01)
	bool bIsLastPage; // 0x329(0x01)
	char pad_32A[0x6]; // 0x32a(0x06)
	struct UDCGiftCodePopupBase* GiftCodePopupClass; // 0x330(0x08)
	struct UDCShopItemListWidget* ShopItemListWidget; // 0x338(0x08)
	struct UDCCommonButtonBase* ButtonArrowL; // 0x340(0x08)
	struct UDCCommonButtonBase* ButtonArrowR; // 0x348(0x08)
	struct UCommonButtonLWidget* ButtonBuy; // 0x350(0x08)
	struct UWidgetSwitcher* PreviewSwitcher; // 0x358(0x08)
	struct UDCCommonButtonBase* Btn_EnterCode; // 0x360(0x08)
	char pad_368[0x38]; // 0x368(0x38)

	void OnWidgetOpen(); // Function DungeonCrawler.DCShopWidgetBase.OnWidgetOpen // (None) // @ game+0xffffbfdddf830041
};

// Class DungeonCrawler.DCShowingKeyWidgetBase
// Size: 0x300 (Inherited: 0x300)
struct UDCShowingKeyWidgetBase : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)

	void OnInputBindChanged(); // Function DungeonCrawler.DCShowingKeyWidgetBase.OnInputBindChanged // (None) // @ game+0xffffbfdfdf830041
};

// Class DungeonCrawler.DCSimpleTooltipWidget
// Size: 0x330 (Inherited: 0x300)
struct UDCSimpleTooltipWidget : UDCWidgetBase {
	struct FText TooltipNameText; // 0x300(0x18)
	struct FSlateColor TooltipColor; // 0x318(0x14)
	char pad_32C[0x4]; // 0x32c(0x04)

	void SetTooltipData(struct FText& Text, struct FSlateColor& TextColor); // Function DungeonCrawler.DCSimpleTooltipWidget.SetTooltipData // (None) // @ game+0xffffbfe1df830041
};

// Class DungeonCrawler.DCSkeletalMeshComponent
// Size: 0xfe0 (Inherited: 0xf80)
struct UDCSkeletalMeshComponent : USkeletalMeshComponent {
	ClassPtrProperty AnimBlueprintGeneratedClass; // 0x8a0(0x08)
	struct UAnimInstance* AnimClass; // 0x8a8(0x08)
	struct UAnimInstance* AnimScriptInstance; // 0x8b0(0x08)
	struct UAnimInstance* PostProcessAnimInstance; // 0x8b8(0x08)
	struct FSingleAnimationPlayData AnimationData; // 0x8c0(0x18)
	struct FVector RootBoneTranslation; // 0x8e8(0x18)
	struct FVector LineCheckBoundsScale; // 0x900(0x18)
	struct TArray<struct UAnimInstance*> LinkedInstances; // 0x948(0x10)
	struct TArray<struct FTransform> CachedBoneSpaceTransforms; // 0x958(0x10)
	struct TArray<struct FTransform> CachedComponentSpaceTransforms; // 0x968(0x10)
	float GlobalAnimRateScale; // 0xa28(0x04)
	enum class EKinematicBonesUpdateToPhysics KinematicBonesUpdateType; // 0xa2c(0x01)
	enum class EPhysicsTransformUpdateMode PhysicsTransformUpdateMode; // 0xa2d(0x01)
	enum class EAnimationMode AnimationMode; // 0xa2f(0x01)
	char bDisablePostProcessBlueprint : 1; // 0xa31(0x01)
	char pad_101F_1 : 1; // 0x101f(0x01)
	char bUpdateOverlapsOnAnimationFinalize : 1; // 0xa31(0x01)
	char pad_101F_3 : 1; // 0x101f(0x01)
	char bHasValidBodies : 1; // 0xa31(0x01)
	char bBlendPhysics : 1; // 0xa31(0x01)
	char bEnablePhysicsOnDedicatedServer : 1; // 0xa31(0x01)
	char bUpdateMeshWhenKinematic : 1; // 0xa31(0x01)
	char bUpdateJointsFromAnimation : 1; // 0xa32(0x01)
	char bAllowClothActors : 1; // 0xa32(0x01)
	char bDisableClothSimulation : 1; // 0xa32(0x01)
	char bDisableRigidBodyAnimNode : 1; // 0xa38(0x01)
	char bAllowAnimCurveEvaluation : 1; // 0xa38(0x01)
	char bDisableAnimCurves : 1; // 0xa38(0x01)
	char bCollideWithEnvironment : 1; // 0xa38(0x01)
	char bCollideWithAttachedChildren : 1; // 0xa38(0x01)
	char bForceCollisionUpdate : 1; // 0xa39(0x01)
	char bLocalSpaceSimulation : 1; // 0xa39(0x01)
	char bResetAfterTeleport : 1; // 0xa39(0x01)
	char pad_1021_3 : 1; // 0x1021(0x01)
	char bDeferKinematicBoneUpdate : 1; // 0xa39(0x01)
	char bNoSkeletonUpdate : 1; // 0xa39(0x01)
	char bPauseAnims : 1; // 0xa39(0x01)
	char bUseRefPoseOnInitAnim : 1; // 0xa39(0x01)
	char bEnablePerPolyCollision : 1; // 0xa3a(0x01)
	char bForceRefpose : 1; // 0xa3a(0x01)
	char bOnlyAllowAutonomousTickPose : 1; // 0xa3a(0x01)
	char bIsAutonomousTickPose : 1; // 0xa3a(0x01)
	char bOldForceRefPose : 1; // 0xa3a(0x01)
	char bShowPrePhysBones : 1; // 0xa3a(0x01)
	char bRequiredBonesUpToDate : 1; // 0xa3a(0x01)
	char bAnimTreeInitialised : 1; // 0xa3a(0x01)
	char bIncludeComponentLocationIntoBounds : 1; // 0xa3b(0x01)
	char bEnableLineCheckWithBounds : 1; // 0xa3b(0x01)
	char bPropagateCurvesToFollowers : 1; // 0xa3b(0x01)
	char bSkipKinematicUpdateWhenInterpolating : 1; // 0xa3b(0x01)
	char bSkipBoundsUpdateWhenInterpolating : 1; // 0xa3b(0x01)
	char pad_1023_5 : 2; // 0x1023(0x01)
	char bNeedsQueuedAnimEventsDispatched : 1; // 0xa3b(0x01)
	uint16_t CachedAnimCurveUidVersion; // 0xa3e(0x02)
	float ClothBlendWeight; // 0xa40(0x04)
	bool bWaitForParallelClothTask; // 0xa44(0x01)
	struct TArray<struct FName> DisallowedAnimCurves; // 0xa48(0x10)
	struct UBodySetup* BodySetup; // 0xa58(0x08)
	float ClothMaxDistanceScale; // 0xa64(0x04)
	struct FMulticastInlineDelegate OnConstraintBroken; // 0xa68(0x10)
	struct FMulticastInlineDelegate OnPlasticDeformation; // 0xa78(0x10)
	struct UClothingSimulationFactory* ClothingSimulationFactory; // 0xa88(0x08)
	float TeleportDistanceThreshold; // 0xb88(0x04)
	float TeleportRotationThreshold; // 0xb8c(0x04)
	uint32_t LastPoseTickFrame; // 0xb98(0x04)
	struct UClothingSimulationInteractor* ClothingInteractor; // 0xc30(0x08)
	struct FMulticastInlineDelegate OnAnimInitialized; // 0xd00(0x10)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCSkeletalMeshComponent.UnbindMsgAll // (None) // @ game+0xffffc07ddf830041
};

// Class DungeonCrawler.DCSkillDataAsset
// Size: 0x158 (Inherited: 0x38)
struct UDCSkillDataAsset : UDCDataAsset {
	struct FText Name; // 0x38(0x18)
	struct TSoftObjectPtr<UDescData> DescData; // 0x50(0x30)
	bool CanUse; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
	struct TArray<struct FPrimaryAssetId> Classes; // 0x88(0x10)
	struct FGameplayTag SkillType; // 0x98(0x08)
	int32_t SkillTier; // 0xa0(0x04)
	bool CanRecharge; // 0xa4(0x01)
	char pad_A5[0x3]; // 0xa5(0x03)
	int32_t MaxCount; // 0xa8(0x04)
	float CastingTime; // 0xac(0x04)
	float ChannelingDuration; // 0xb0(0x04)
	float ChannelingInterval; // 0xb4(0x04)
	int32_t Range; // 0xb8(0x04)
	bool UseMoving; // 0xbc(0x01)
	bool NeedAimTarget; // 0xbd(0x01)
	char pad_BE[0x2]; // 0xbe(0x02)
	struct FGameplayTag SkillTag; // 0xc0(0x08)
	struct FGameplayTag SkillCooldownTag; // 0xc8(0x08)
	struct ASkillActor* ActorClass; // 0xd0(0x08)
	struct TSoftObjectPtr<UArtDataSkill> ArtData; // 0xd8(0x30)
	struct TSoftObjectPtr<USoundData> SoundData; // 0x108(0x30)
	struct TArray<struct TSoftObjectPtr<UDCGameplayAbilityDataAsset>> Abilities; // 0x138(0x10)
	struct TArray<struct TSoftObjectPtr<UDCGameplayEffectDataAsset>> Effects; // 0x148(0x10)
};

// Class DungeonCrawler.DCSkinTooltipWidget
// Size: 0x2c0 (Inherited: 0x278)
struct UDCSkinTooltipWidget : UUserWidget {
	struct FText SkinNameText; // 0x278(0x18)
	struct FText SkinDescriptionText; // 0x290(0x18)
	struct FText SkinFlavorText; // 0x2a8(0x18)

	enum class ESlateVisibility GetDescriptionVisibility(); // Function DungeonCrawler.DCSkinTooltipWidget.GetDescriptionVisibility // (None) // @ game+0xffffc07edf830041
};

// Class DungeonCrawler.DCSpawnerDataAsset
// Size: 0x48 (Inherited: 0x38)
struct UDCSpawnerDataAsset : UDCDataAsset {
	struct TArray<struct FDCSpawnerItemData> SpawnerItemArray; // 0x38(0x10)
};

// Class DungeonCrawler.DCSpellDataAsset
// Size: 0x148 (Inherited: 0x38)
struct UDCSpellDataAsset : UDCDataAsset {
	struct FText Name; // 0x38(0x18)
	struct TSoftObjectPtr<UDescData> Desc; // 0x50(0x30)
	struct TArray<struct FPrimaryAssetId> Classes; // 0x80(0x10)
	struct FGameplayTag CastingType; // 0x90(0x08)
	struct FGameplayTag SourceType; // 0x98(0x08)
	int32_t SpellTier; // 0xa0(0x04)
	int32_t MaxCount; // 0xa4(0x04)
	float CastingTime; // 0xa8(0x04)
	float ChannelingDuration; // 0xac(0x04)
	float ChannelingInterval; // 0xb0(0x04)
	int32_t Range; // 0xb4(0x04)
	struct FGameplayTag SpellTag; // 0xb8(0x08)
	struct ASpellActor* ActorClass; // 0xc0(0x08)
	struct TSoftObjectPtr<UArtDataSpell> ArtData; // 0xc8(0x30)
	struct TSoftObjectPtr<USoundData> SoundData; // 0xf8(0x30)
	struct TArray<struct TSoftObjectPtr<UDCGameplayAbilityDataAsset>> Abilities; // 0x128(0x10)
	struct TArray<struct TSoftObjectPtr<UDCGameplayEffectDataAsset>> Effects; // 0x138(0x10)
};

// Class DungeonCrawler.DCStorageWidget
// Size: 0x2c8 (Inherited: 0x2c0)
struct UDCStorageWidget : UDCInventoryWidgetBase {
	struct UDCBagWidget* BagWidget; // 0x2c0(0x08)
};

// Class DungeonCrawler.DCTabMenuWidgetBase
// Size: 0x368 (Inherited: 0x300)
struct UDCTabMenuWidgetBase : UDCWidgetBase {
	struct UCommonButtonLWidget* TabButtonClass; // 0x300(0x08)
	struct UPanelWidget* ButtonBox; // 0x308(0x08)
	char pad_310[0x58]; // 0x310(0x58)
};

// Class DungeonCrawler.DCTagCollisionDetectorComponent
// Size: 0x5d0 (Inherited: 0x580)
struct UDCTagCollisionDetectorComponent : UBoxComponent {
	struct FMulticastInlineDelegate OnGameplayTagCollisionDetected; // 0x578(0x10)
	struct FGameplayTagQuery GameplayTagQuery; // 0x588(0x48)
};

// Class DungeonCrawler.DCTargetType
// Size: 0x28 (Inherited: 0x28)
struct UDCTargetType : UObject {

	void GetTargets(struct AActor* TargetingOwnerActor, struct AActor* TargetingAvatarActor, struct FGameplayEventData EventData, struct TArray<struct FHitResult>& OutHitResults, struct TArray<struct AActor*>& OutActors); // Function DungeonCrawler.DCTargetType.GetTargets // (None) // @ game+0xffffc07fdf830041
};

// Class DungeonCrawler.DCTargetType_UseOwner
// Size: 0x28 (Inherited: 0x28)
struct UDCTargetType_UseOwner : UDCTargetType {
};

// Class DungeonCrawler.DCTargetType_UseEventData
// Size: 0x28 (Inherited: 0x28)
struct UDCTargetType_UseEventData : UDCTargetType {
};

// Class DungeonCrawler.DCTestGameMode
// Size: 0x518 (Inherited: 0x518)
struct ADCTestGameMode : ADCDungeonGameMode {
	float WarmupDuration; // 0x4c0(0x04)
	struct ADeathSwarmBase* DeathSwarm; // 0x4c8(0x08)
	struct FDCFloorRuleManager FloorRuleManager; // 0x4d0(0x38)
};

// Class DungeonCrawler.DCTradeBoxWidget
// Size: 0x2e8 (Inherited: 0x2c0)
struct UDCTradeBoxWidget : UDCInventoryWidgetBase {
	bool bLocal; // 0x2c0(0x01)
	char pad_2C1[0x7]; // 0x2c1(0x07)
	struct FString TraderName; // 0x2c8(0x10)
	bool bReady; // 0x2d8(0x01)
	char pad_2D9[0x3]; // 0x2d9(0x03)
	float LockRemainTime; // 0x2dc(0x04)
	struct UDCBagWidget* InnerBagWidget; // 0x2e0(0x08)

	void SetReady(bool bState); // Function DungeonCrawler.DCTradeBoxWidget.SetReady // (None) // @ game+0xffffc0c3df830041
};

// Class DungeonCrawler.DCTradeChannelCategoryWidget
// Size: 0x298 (Inherited: 0x278)
struct UDCTradeChannelCategoryWidget : UUserWidget {
	struct FText CategoryNameText; // 0x278(0x18)
	struct UVerticalBox* VerticalBox_ChannelButton; // 0x290(0x08)
};

// Class DungeonCrawler.DCTradeInventoryWidget
// Size: 0x2e8 (Inherited: 0x2c0)
struct UDCTradeInventoryWidget : UDCInventoryWidgetBase {
	struct UDCPlayerInventoryWidget* PlayerInventoryWidget; // 0x2c0(0x08)
	struct UDCBagWidget* StorageWidget; // 0x2c8(0x08)
	struct UInventoryTabWidgetBase* InventoryTabWidget; // 0x2d0(0x08)
	struct UInventoryTabWidgetBase* StorageTabWidget; // 0x2d8(0x08)
	struct UWidgetSwitcher* SwitcherWidget; // 0x2e0(0x08)

	void OnTradeEnd(); // Function DungeonCrawler.DCTradeInventoryWidget.OnTradeEnd // (None) // @ game+0xffffc085df830041
};

// Class DungeonCrawler.DCTradePhaseConfirmWidget
// Size: 0x320 (Inherited: 0x300)
struct UDCTradePhaseConfirmWidget : UDCWidgetBase {
	int32_t TradeFee; // 0x300(0x04)
	char pad_304[0x4]; // 0x304(0x04)
	struct UDCTradeBoxWidget* TradeBoxLocal; // 0x308(0x08)
	struct UDCTradeBoxWidget* TradeBoxRemote; // 0x310(0x08)
	struct UDCCommonButtonBase* CancelTradeButton; // 0x318(0x08)

	void OnResponseLocalTraderConfirmRequestResult(bool bRequestSucceed); // Function DungeonCrawler.DCTradePhaseConfirmWidget.OnResponseLocalTraderConfirmRequestResult // (None) // @ game+0xffffc089df830041
};

// Class DungeonCrawler.DCTradePhaseDealWidget
// Size: 0x320 (Inherited: 0x300)
struct UDCTradePhaseDealWidget : UDCWidgetBase {
	int32_t TradeFee; // 0x300(0x04)
	int32_t LockDuration; // 0x304(0x04)
	struct UDCCommonButtonBase* CancelTradeButton; // 0x308(0x08)
	struct UDCTradeBoxWidget* TradeBoxLocal; // 0x310(0x08)
	struct UDCTradeBoxWidget* TradeBoxRemote; // 0x318(0x08)

	void OnResponseLocalTraderRequestRequestResult(bool bRequestSucceed); // Function DungeonCrawler.DCTradePhaseDealWidget.OnResponseLocalTraderRequestRequestResult // (None) // @ game+0xffffc08cdf830041
};

// Class DungeonCrawler.DCVoipComponent
// Size: 0x1f8 (Inherited: 0xa0)
struct UDCVoipComponent : UActorComponent {
	char pad_A0[0x8]; // 0xa0(0x08)
	struct AActor* DummyVoipReceiveActorClass; // 0xa8(0x08)
	struct UVoipAkComponent* SendVoipAkComponent; // 0xb0(0x08)
	char pad_B8[0x140]; // 0xb8(0x140)

	void OnAudioChanged(struct FGameUserSettingAudios& InGameUserSettingAudios, struct FGameUserSettingAudios& OldGameUserSettingAudios); // Function DungeonCrawler.DCVoipComponent.OnAudioChanged // (None) // @ game+0xffffc08edf830041
};

// Class DungeonCrawler.DCVoipInterface
// Size: 0x28 (Inherited: 0x28)
struct UDCVoipInterface : UInterface {
};

// Class DungeonCrawler.DCWaitingGameMode
// Size: 0x4c0 (Inherited: 0x4c0)
struct ADCWaitingGameMode : ADCIngameGameMode {
	struct TArray<struct ADCPlayerStart*> StartPoints; // 0x408(0x10)
};

// Class DungeonCrawler.DCWaitingGameState
// Size: 0x6f0 (Inherited: 0x6d8)
struct ADCWaitingGameState : ADCGameStateBase {
	struct TArray<struct FGameAnnounceData> AnnounceInfos; // 0x6d8(0x10)
	struct FDateTime StartTimeUtc; // 0x6e8(0x08)
};

// Class DungeonCrawler.DCWidgetBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UDCWidgetBlueprintLibrary : UWidgetBlueprintLibrary {

	struct FDCAccountId StringToAccountId(struct FString InAccountIdStr); // Function DungeonCrawler.DCWidgetBlueprintLibrary.StringToAccountId // (None) // @ game+0xffffc096df830041
};

// Class DungeonCrawler.DCWorldSettings
// Size: 0x4c0 (Inherited: 0x4b8)
struct ADCWorldSettings : AWorldSettings {
	struct UBehaviorTree* GameModeBehaviorTree; // 0x4b8(0x08)
};

// Class DungeonCrawler.PropsActorBase
// Size: 0x3c0 (Inherited: 0x310)
struct APropsActorBase : ADCAbilityInteractableActorBase {
	char pad_310[0x80]; // 0x310(0x80)
	struct UImpactableComponent* ImpactableComponent; // 0x390(0x08)
	struct UDesignDataAssetProps* DesignDataAssetProps; // 0x398(0x08)
	struct TArray<struct FActiveGameplayEffectHandle> ActiveGameplayEffectHandleArray; // 0x3a0(0x10)
	struct UDCPropDataComponent* DataComponent; // 0x3b0(0x08)
	char pad_3B8[0x1]; // 0x3b8(0x01)
	bool bPreview; // 0x3b9(0x01)
	char pad_3BA[0x6]; // 0x3ba(0x06)

	void UpdateInteractDepthValue(int32_t DepthValue); // Function DungeonCrawler.PropsActorBase.UpdateInteractDepthValue // (None) // @ game+0xffffc09ddf830041
};

// Class DungeonCrawler.DeathSwarmBase
// Size: 0x510 (Inherited: 0x3c0)
struct ADeathSwarmBase : APropsActorBase {
	struct UCapsuleComponent* AuraCapsule; // 0x3c0(0x08)
	struct UCapsuleComponent* AntiAuraCapsule; // 0x3c8(0x08)
	char pad_3D0[0x140]; // 0x3d0(0x140)
};

// Class DungeonCrawler.DescDataParam
// Size: 0x28 (Inherited: 0x28)
struct UDescDataParam : UObject {
};

// Class DungeonCrawler.DescData
// Size: 0x50 (Inherited: 0x38)
struct UDescData : UDCDataAssetBase {
	struct FText DescriptionFormatTextId; // 0x38(0x18)

	float GetExecImpactPower(struct UDescDataParam* InDescDataParam); // Function DungeonCrawler.DescData.GetExecImpactPower // (None) // @ game+0xffffc09fdf830041
};

// Class DungeonCrawler.DescDataEffect
// Size: 0x60 (Inherited: 0x50)
struct UDescDataEffect : UDescData {
	struct UDesignDataAssetGameplayEffect* DesignDataGameplayEffect; // 0x50(0x08)
	struct FGameplayTag GameplayTagParam; // 0x58(0x08)
};

// Class DungeonCrawler.DescDataEffectTwoParam
// Size: 0x68 (Inherited: 0x50)
struct UDescDataEffectTwoParam : UDescData {
	struct UDesignDataAssetGameplayEffect* DesignDataGameplayEffect; // 0x50(0x08)
	struct FGameplayTag GameplayTagParam1; // 0x58(0x08)
	struct FGameplayTag GameplayTagParam2; // 0x60(0x08)
};

// Class DungeonCrawler.DescDataConstantParams
// Size: 0xa0 (Inherited: 0x50)
struct UDescDataConstantParams : UDescData {
	struct TMap<struct FPrimaryAssetId, struct FDCConstantDataType> EtcDesignDatas; // 0x50(0x50)
};

// Class DungeonCrawler.DescDataMultiEffectParams
// Size: 0xf0 (Inherited: 0xa0)
struct UDescDataMultiEffectParams : UDescDataConstantParams {
	struct TMap<struct UDesignDataAssetGameplayEffect*, struct FGameplayTagContainer> DesignDataGameplayEffectDataList; // 0xa0(0x50)
};

// Class DungeonCrawler.DescDataAbility
// Size: 0x50 (Inherited: 0x50)
struct UDescDataAbility : UDescData {
	struct FText DescriptionFormatTextId; // 0x38(0x18)
};

// Class DungeonCrawler.DescDataParamAbilityWeapon
// Size: 0x58 (Inherited: 0x28)
struct UDescDataParamAbilityWeapon : UDescDataParam {
	char pad_28[0x8]; // 0x28(0x08)
	struct FDCGameplayAbilityData GameplayAbilityData; // 0x30(0x28)
};

// Class DungeonCrawler.DescDataAbilityWeapon
// Size: 0x58 (Inherited: 0x50)
struct UDescDataAbilityWeapon : UDescDataAbility {
	struct UGlobalData* GlobalData; // 0x50(0x08)
};

// Class DungeonCrawler.DescDataAbilityEffectParams
// Size: 0x118 (Inherited: 0xf0)
struct UDescDataAbilityEffectParams : UDescDataMultiEffectParams {
	struct FDCAbilityDataAsset AbilityData; // 0xf0(0x14)
	char pad_104[0x4]; // 0x104(0x04)
	struct TArray<enum class EAbilityDataAssetOption> AbilityDataAssetOptions; // 0x108(0x10)
};

// Class DungeonCrawler.DesignDataAssetGameplayAbility
// Size: 0x90 (Inherited: 0x38)
struct UDesignDataAssetGameplayAbility : UDCDataAssetBase {
	struct FDesignDataGameplayAbility Item; // 0x38(0x58)
};

// Class DungeonCrawler.DesignDataAssetGameplayEffect
// Size: 0x1c0 (Inherited: 0x38)
struct UDesignDataAssetGameplayEffect : UDCDataAssetBase {
	struct FDesignDataGameplayEffect Item; // 0x38(0x188)
};

// Class DungeonCrawler.DesignDataAssetBaseItem
// Size: 0xd8 (Inherited: 0x38)
struct UDesignDataAssetBaseItem : UDCDataAssetBase {
	struct FDesignDataBaseItem Item; // 0x38(0xa0)
};

// Class DungeonCrawler.DesignDataAssetPlayerCharacter
// Size: 0x108 (Inherited: 0x38)
struct UDesignDataAssetPlayerCharacter : UDCDataAssetBase {
	struct FDesignDataPlayerCharacter Item; // 0x38(0xd0)
};

// Class DungeonCrawler.DesignDataAssetMonster
// Size: 0xa0 (Inherited: 0x38)
struct UDesignDataAssetMonster : UDCDataAssetBase {
	struct FDesignDataMonster Item; // 0x38(0x68)
};

// Class DungeonCrawler.DesignDataAssetProps
// Size: 0xc8 (Inherited: 0x38)
struct UDesignDataAssetProps : UDCDataAssetBase {
	struct FDesignDataProps Item; // 0x38(0x90)
};

// Class DungeonCrawler.DesignDataAssetPropsInteract
// Size: 0xd8 (Inherited: 0x38)
struct UDesignDataAssetPropsInteract : UDCDataAssetBase {
	struct FDesignDataPropsInteract Item; // 0x38(0xa0)
};

// Class DungeonCrawler.DesignDataAssetPropsSkillCheck
// Size: 0x68 (Inherited: 0x38)
struct UDesignDataAssetPropsSkillCheck : UDCDataAssetBase {
	struct FDesignDataPropsSkillCheck Item; // 0x38(0x30)
};

// Class DungeonCrawler.DesignDataAssetItem
// Size: 0x1c0 (Inherited: 0x38)
struct UDesignDataAssetItem : UDCDataAssetBase {
	struct FDesignDataItem Item; // 0x38(0x188)
};

// Class DungeonCrawler.DesignDataAssetItemPropertyType
// Size: 0x90 (Inherited: 0x38)
struct UDesignDataAssetItemPropertyType : UDCDataAssetBase {
	struct FDesignDataItemPropertyType Item; // 0x38(0x58)
};

// Class DungeonCrawler.DesignDataAssetItemProperty
// Size: 0x48 (Inherited: 0x38)
struct UDesignDataAssetItemProperty : UDCDataAssetBase {
	struct FDesignDataItemProperty Item; // 0x38(0x10)
};

// Class DungeonCrawler.DesignDataAssetItemConsume
// Size: 0x58 (Inherited: 0x38)
struct UDesignDataAssetItemConsume : UDCDataAssetBase {
	struct FDesignDataItemConsume Item; // 0x38(0x20)
};

// Class DungeonCrawler.DesignDataAssetItemRequirement
// Size: 0x70 (Inherited: 0x38)
struct UDesignDataAssetItemRequirement : UDCDataAssetBase {
	struct FDesignDataItemRequirement Item; // 0x38(0x38)

	bool IsTargetFulfilledAllRequirements(struct FDesignDataItem DesignDataItem, struct AActor* TargetActor); // Function DungeonCrawler.DesignDataAssetItemRequirement.IsTargetFulfilledAllRequirements // (None) // @ game+0xffffc0a3df830041
};

// Class DungeonCrawler.DesignDataAssetItemBundleInfo
// Size: 0x48 (Inherited: 0x38)
struct UDesignDataAssetItemBundleInfo : UDCDataAssetBase {
	struct FDesignDataItemBundleInfo Item; // 0x38(0x10)

	struct FPrimaryAssetId GetBundleArtAssetByCount(int32_t ItemCount); // Function DungeonCrawler.DesignDataAssetItemBundleInfo.GetBundleArtAssetByCount // (None) // @ game+0xffffc0a4df830041
};

// Class DungeonCrawler.DesignDataAssetItemContainer
// Size: 0x50 (Inherited: 0x38)
struct UDesignDataAssetItemContainer : UDCDataAssetBase {
	struct FDesignDataItemContainer Item; // 0x38(0x14)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class DungeonCrawler.DesignDataAssetLootDrop
// Size: 0x48 (Inherited: 0x38)
struct UDesignDataAssetLootDrop : UDCDataAssetBase {
	struct FDesignDataLootDrop Item; // 0x38(0x10)
};

// Class DungeonCrawler.DesignDataAssetSpawner
// Size: 0x48 (Inherited: 0x38)
struct UDesignDataAssetSpawner : UDCDataAssetBase {
	struct FDesignDataSpawner Item; // 0x38(0x10)
};

// Class DungeonCrawler.DesignDataAssetProjectile
// Size: 0xa0 (Inherited: 0x38)
struct UDesignDataAssetProjectile : UDCDataAssetBase {
	struct FDesignDataProjectile Item; // 0x38(0x68)
};

// Class DungeonCrawler.DesignDataAssetMeleeAttack
// Size: 0x90 (Inherited: 0x38)
struct UDesignDataAssetMeleeAttack : UDCDataAssetBase {
	struct FDesignDataMeleeAttack Item; // 0x38(0x54)
	char pad_8C[0x4]; // 0x8c(0x04)
};

// Class DungeonCrawler.DesignDataAssetSkill
// Size: 0xf8 (Inherited: 0x38)
struct UDesignDataAssetSkill : UDCDataAssetBase {
	struct FDesignDataSkill Item; // 0x38(0xc0)
};

// Class DungeonCrawler.DesignDataAssetSpell
// Size: 0xf0 (Inherited: 0x38)
struct UDesignDataAssetSpell : UDCDataAssetBase {
	struct FDesignDataSpell Item; // 0x38(0xb8)
};

// Class DungeonCrawler.DesignDataAssetMusic
// Size: 0xe0 (Inherited: 0x38)
struct UDesignDataAssetMusic : UDCDataAssetBase {
	struct FDesignDataMusic Item; // 0x38(0xa8)
};

// Class DungeonCrawler.DesignDataAssetPerk
// Size: 0xc0 (Inherited: 0x38)
struct UDesignDataAssetPerk : UDCDataAssetBase {
	struct FDesignDataPerk Item; // 0x38(0x88)
};

// Class DungeonCrawler.DesignDataAssetMovementModifier
// Size: 0x40 (Inherited: 0x38)
struct UDesignDataAssetMovementModifier : UDCDataAssetBase {
	struct FDesignDataMovementModifier Item; // 0x38(0x08)
};

// Class DungeonCrawler.DesignDataAssetMerchant
// Size: 0x78 (Inherited: 0x38)
struct UDesignDataAssetMerchant : UDCDataAssetBase {
	struct FDesignDataMerchant Item; // 0x38(0x40)
};

// Class DungeonCrawler.DesignDataAssetMerchantSchedule
// Size: 0x40 (Inherited: 0x38)
struct UDesignDataAssetMerchantSchedule : UDCDataAssetBase {
	struct FDesignDataMerchantSchedule Item; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// Class DungeonCrawler.DesignDataAssetStockBuy
// Size: 0x48 (Inherited: 0x38)
struct UDesignDataAssetStockBuy : UDCDataAssetBase {
	struct FDesignDataStockBuy Item; // 0x38(0x10)
};

// Class DungeonCrawler.DesignDataAssetStockSellBack
// Size: 0x48 (Inherited: 0x38)
struct UDesignDataAssetStockSellBack : UDCDataAssetBase {
	struct FDesignDataStockSellBack Item; // 0x38(0x10)
};

// Class DungeonCrawler.DesignDataAssetStockCraft
// Size: 0x48 (Inherited: 0x38)
struct UDesignDataAssetStockCraft : UDCDataAssetBase {
	struct FDesignDataStockCraft Item; // 0x38(0x10)
};

// Class DungeonCrawler.DesignDataAssetFloorRule
// Size: 0x48 (Inherited: 0x38)
struct UDesignDataAssetFloorRule : UDCDataAssetBase {
	struct FDesignDataFloorRule Item; // 0x38(0x10)
};

// Class DungeonCrawler.DesignDataAssetFloorPortal
// Size: 0x48 (Inherited: 0x38)
struct UDesignDataAssetFloorPortal : UDCDataAssetBase {
	struct FDesignDataFloorPortal Item; // 0x38(0x0c)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class DungeonCrawler.DesignDataAssetConstant
// Size: 0x40 (Inherited: 0x38)
struct UDesignDataAssetConstant : UDCDataAssetBase {
	struct FDesignDataConstant Item; // 0x38(0x08)
};

// Class DungeonCrawler.DesignDataAssetEmote
// Size: 0xb0 (Inherited: 0x38)
struct UDesignDataAssetEmote : UDCDataAssetBase {
	struct FDesignDataEmote Item; // 0x38(0x78)
};

// Class DungeonCrawler.DesignDataAssetIdTagGroup
// Size: 0x48 (Inherited: 0x38)
struct UDesignDataAssetIdTagGroup : UDCDataAssetBase {
	struct FDesignDataIdTagGroup Item; // 0x38(0x10)
};

// Class DungeonCrawler.DesignDataAssetDungeon
// Size: 0x98 (Inherited: 0x38)
struct UDesignDataAssetDungeon : UDCDataAssetBase {
	struct FDesignDataDungeon Item; // 0x38(0x60)
};

// Class DungeonCrawler.EmoteComponent
// Size: 0x190 (Inherited: 0xa0)
struct UEmoteComponent : UActorComponent {
	char pad_A0[0x70]; // 0xa0(0x70)
	struct TArray<struct FDCEmoteSlotInfo> EmoteSlotInfoArray; // 0x110(0x10)
	struct TMap<int32_t, struct FPrimaryAssetId> EmoteSlotMap; // 0x120(0x50)
	struct TArray<struct FGameplayAbilitySpecHandle> OwnerGameplayAbilitySpecHandles; // 0x170(0x10)
	struct TArray<struct FActiveGameplayEffectHandle> OwnerGameplayEffectHandles; // 0x180(0x10)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.EmoteComponent.UnbindMsgAll // (None) // @ game+0xffffc0a9df830041
};

// Class DungeonCrawler.EquipmentSlot
// Size: 0x48 (Inherited: 0x28)
struct UEquipmentSlot : UObject {
	int32_t SlotId; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct UEquipmentInventoryComponent* Container; // 0x30(0x08)
	struct FGameplayTag ItemSlotType; // 0x38(0x08)
	struct UItem* Item; // 0x40(0x08)

	struct UItem* GetItem(); // Function DungeonCrawler.EquipmentSlot.GetItem // (None) // @ game+0xffffc0aadf830041
};

// Class DungeonCrawler.EquipmentWeaponSlot
// Size: 0x50 (Inherited: 0x48)
struct UEquipmentWeaponSlot : UEquipmentSlot {
	struct TWeakObjectPtr<struct UEquipmentSlot> LinkedSlot; // 0x48(0x08)
};

// Class DungeonCrawler.EquipmentInventoryComponent
// Size: 0x1d8 (Inherited: 0xa0)
struct UEquipmentInventoryComponent : UActorComponent {
	char pad_A0[0x58]; // 0xa0(0x58)
	enum class EInventoryType InventoryType; // 0xf8(0x01)
	enum class EEquipmentQuickSlotType CurrentActiveQuickSlotType; // 0xf9(0x01)
	char pad_FA[0x6]; // 0xfa(0x06)
	struct TMap<int32_t, struct UEquipmentSlot*> SlotMap; // 0x100(0x50)
	struct TMap<enum class EEquipmentQuickSlotType, struct FEquipmentQuickSlotInfo> QuickSlotInfoMap; // 0x150(0x50)
	struct TArray<struct FItemData> ContainingItems; // 0x1a0(0x10)
	enum class EItemEquipState ItemEquipState; // 0x1b0(0x01)
	char pad_1B1[0x7]; // 0x1b1(0x07)
	struct TArray<struct AItemActor*> EquippedItemActors; // 0x1b8(0x10)
	struct TArray<struct AItemActor*> SheathItemActors; // 0x1c8(0x10)

	void UpdateCrossHairWidget(); // Function DungeonCrawler.EquipmentInventoryComponent.UpdateCrossHairWidget // (None) // @ game+0xffffc0c2df830041
};

// Class DungeonCrawler.EquipmentInventoryGroupWidget
// Size: 0x418 (Inherited: 0x300)
struct UEquipmentInventoryGroupWidget : UDCWidgetBase {
	struct UAccountLink* AccountLink; // 0x300(0x08)
	bool bLootingTargetInventory; // 0x308(0x01)
	char pad_309[0x7]; // 0x309(0x07)
	struct UItemWidget* GlobalItemWidgetClass; // 0x310(0x08)
	struct UItemWidget* ReadOnlyItemWidgetClass; // 0x318(0x08)
	struct UEquipmentWeaponSlotSetWidget* WB_Inventory_WeaponSetA; // 0x320(0x08)
	struct UEquipmentWeaponSlotSetWidget* WB_Inventory_WeaponSetB; // 0x328(0x08)
	struct UEquipmentSlotWidget* Helmet; // 0x330(0x08)
	struct UEquipmentSlotWidget* Chest; // 0x338(0x08)
	struct UEquipmentSlotWidget* SoulHeart; // 0x340(0x08)
	struct UEquipmentSlotWidget* Pants; // 0x348(0x08)
	struct UEquipmentSlotWidget* Boots; // 0x350(0x08)
	struct UEquipmentSlotWidget* Glove; // 0x358(0x08)
	struct UEquipmentSlotWidget* Back; // 0x360(0x08)
	struct UEquipmentSlotWidget* Pouch_L_Item_01; // 0x368(0x08)
	struct UEquipmentSlotWidget* Pouch_L_Item_02; // 0x370(0x08)
	struct UEquipmentSlotWidget* Pouch_L_Item_03; // 0x378(0x08)
	struct UEquipmentSlotWidget* Pouch_R_Item_01; // 0x380(0x08)
	struct UEquipmentSlotWidget* Pouch_R_Item_02; // 0x388(0x08)
	struct UEquipmentSlotWidget* Pouch_R_Item_03; // 0x390(0x08)
	struct UEquipmentSlotWidget* Acc_01; // 0x398(0x08)
	struct UEquipmentSlotWidget* Acc_02; // 0x3a0(0x08)
	struct UEquipmentSlotWidget* Acc_03; // 0x3a8(0x08)
	int32_t CurrentActiveWeaponSet; // 0x3b0(0x04)
	char pad_3B4[0x4]; // 0x3b4(0x04)
	struct TArray<struct UEquipmentSlotWidget*> EquipmentSlotWidgetArray; // 0x3b8(0x10)
	struct FString LinkedAccountId; // 0x3c8(0x10)
	struct FString CheckTargetAccountId; // 0x3d8(0x10)
	struct TWeakObjectPtr<struct UEquipmentInventoryComponent> EquipmentInventory; // 0x3e8(0x08)
	struct FString PlayerCharacterId; // 0x3f0(0x10)
	char pad_400[0x8]; // 0x400(0x08)
	struct UEquipmentSlotWidget* PrevDragOverSlotWidget; // 0x408(0x08)
	int32_t PrevDragOverSlotId; // 0x410(0x04)
	char pad_414[0x4]; // 0x414(0x04)

	void OnSwitchChestAndSoulHeart(int32_t ActiveIndex); // Function DungeonCrawler.EquipmentInventoryGroupWidget.OnSwitchChestAndSoulHeart // (None) // @ game+0xffffc0c8df830041
};

// Class DungeonCrawler.EquipmentSlotWidget
// Size: 0x410 (Inherited: 0x300)
struct UEquipmentSlotWidget : UDCWidgetBase {
	enum class EEquipmentQuickSlotType EquipmentQuickSlotType; // 0x300(0x01)
	char pad_301[0x3]; // 0x301(0x03)
	struct FGameplayTag ItemSlotType; // 0x304(0x08)
	enum class EDCEquipmentSlotIndex EquipmentSlot; // 0x30c(0x01)
	char pad_30D[0x3]; // 0x30d(0x03)
	struct FLinearColor ValidSlotColor; // 0x310(0x10)
	struct FLinearColor InvalidSlotColor; // 0x320(0x10)
	struct UScaleBox* ItemWidgetScaleBox; // 0x330(0x08)
	struct UGameItemWearingBarWidget* ItemWearingBarWidget; // 0x338(0x08)
	struct UTextBlock* ItemCountTextBlock; // 0x340(0x08)
	struct UImage* SlotColorImage; // 0x348(0x08)
	char pad_350[0x8]; // 0x350(0x08)
	struct UItemWidget* ItemWidget; // 0x358(0x08)
	struct UItemWidget* ItemWidgetClass; // 0x360(0x08)
	struct FItemData ItemData; // 0x368(0xa0)
	bool bSetPreview; // 0x408(0x01)
	bool bActivated; // 0x409(0x01)
	char pad_40A[0x6]; // 0x40a(0x06)

	void SetPreviewItemWidget(struct FPrimaryAssetId& ItemId, float Duration); // Function DungeonCrawler.EquipmentSlotWidget.SetPreviewItemWidget // (None) // @ game+0xffffc0d1df830041
};

// Class DungeonCrawler.EquipmentWeaponSlotSetWidget
// Size: 0x4e0 (Inherited: 0x410)
struct UEquipmentWeaponSlotSetWidget : UEquipmentSlotWidget {
	struct UScaleBox* SecondaryItemWidgetScaleBox; // 0x410(0x08)
	struct UItemWidget* SecondaryItemWidget; // 0x418(0x08)
	struct UWidget* PrimarySlot; // 0x420(0x08)
	struct UWidget* SecondarySlot; // 0x428(0x08)
	struct FItemData SecondaryItemData; // 0x430(0xa0)
	struct UImage* SecondarySlotColorImage; // 0x4d0(0x08)
	enum class EDCEquipmentSlotIndex SecondaryEquipmentSlotId; // 0x4d8(0x01)
	char pad_4D9[0x7]; // 0x4d9(0x07)

	void SetActiveSecondaryHoverImage(bool bActivate); // Function DungeonCrawler.EquipmentWeaponSlotSetWidget.SetActiveSecondaryHoverImage // (None) // @ game+0xffffc0d4df830041
};

// Class DungeonCrawler.InventoryComponent
// Size: 0x1e0 (Inherited: 0xa0)
struct UInventoryComponent : UActorComponent {
	char pad_A0[0x58]; // 0xa0(0x58)
	enum class EInventoryType InventoryType; // 0xf8(0x01)
	char pad_F9[0x3]; // 0xf9(0x03)
	int32_t MaxHorizontalSlotCount; // 0xfc(0x04)
	int32_t TotalSlotCount; // 0x100(0x04)
	int32_t RowCount; // 0x104(0x04)
	struct TArray<struct FSlotInfo> SlotInfoArray; // 0x108(0x10)
	struct TMap<int32_t, struct FEmptySlotInfoArray> EmptySlotInfoMap; // 0x118(0x50)
	struct TMap<int32_t, struct UItem*> ItemMap; // 0x168(0x50)
	struct TArray<struct FItemData> ContainingItems; // 0x1b8(0x10)
	int64_t TotalGoldCount; // 0x1c8(0x08)
	struct TArray<struct AActor*> LooterArray; // 0x1d0(0x10)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.InventoryComponent.UnbindMsgAll // (None) // @ game+0xffff9840df830041
};

// Class DungeonCrawler.ExpandableInventoryComponent
// Size: 0x1e8 (Inherited: 0x1e0)
struct UExpandableInventoryComponent : UInventoryComponent {
	bool bExpandable; // 0x1e0(0x01)
	char pad_1E1[0x7]; // 0x1e1(0x07)

	void SetExpandable(bool bCanExpand); // Function DungeonCrawler.ExpandableInventoryComponent.SetExpandable // (None) // @ game+0xffffc0d5df830041
};

// Class DungeonCrawler.FloorPortalBase
// Size: 0x3f0 (Inherited: 0x3c0)
struct AFloorPortalBase : APropsActorBase {
	struct AFloorPortalScrollBase* DownFloorPortalScrollClass; // 0x3c0(0x08)
	struct AFloorPortalScrollBase* EscapeFloorPortalScrollClass; // 0x3c8(0x08)
	struct TArray<struct FGameplayTag> FloorPortalScrollActivateAbilityTriggerTagArray; // 0x3d0(0x10)
	struct TArray<struct USceneComponent*> FloorPortalScrollHolderArray; // 0x3e0(0x10)
};

// Class DungeonCrawler.FloorPortalScrollBase
// Size: 0x3d0 (Inherited: 0x3c0)
struct AFloorPortalScrollBase : APropsActorBase {
	enum class EDCPortalScrollType PortalScrollType; // 0x3c0(0x01)
	char pad_3C1[0xf]; // 0x3c1(0x0f)

	void ClosePortalScroll(struct ADCPlayerCharacterBase* Character); // Function DungeonCrawler.FloorPortalScrollBase.ClosePortalScroll // (None) // @ game+0xffffc0d6df830041
};

// Class DungeonCrawler.GameActorStatusSlotItemData
// Size: 0x48 (Inherited: 0x28)
struct UGameActorStatusSlotItemData : UObject {
	struct FActorStatusData ActorStatusData; // 0x28(0x20)
};

// Class DungeonCrawler.GameActorStatusSlotWidget
// Size: 0x338 (Inherited: 0x300)
struct UGameActorStatusSlotWidget : UDCWidgetBase {
	char pad_300[0x8]; // 0x300(0x08)
	struct UImage* TimeGauge; // 0x308(0x08)
	struct FGameActorStatusSlotWidgetData WidgetData; // 0x310(0x20)
	char pad_330[0x8]; // 0x330(0x08)

	void OnActorStatusData(struct FActorStatusData& NewValue, struct FActorStatusData& OldValue); // Function DungeonCrawler.GameActorStatusSlotWidget.OnActorStatusData // (None) // @ game+0xffffc0d7df830041
};

// Class DungeonCrawler.GameActorStatusWidget
// Size: 0x320 (Inherited: 0x300)
struct UGameActorStatusWidget : UDCWidgetBase {
	struct UTileView* ActorStatusTileView; // 0x300(0x08)
	bool bIsAlive; // 0x308(0x01)
	char pad_309[0x17]; // 0x309(0x17)
};

// Class DungeonCrawler.GameAlivePlayerCountWidget
// Size: 0x310 (Inherited: 0x300)
struct UGameAlivePlayerCountWidget : UDCWidgetBase {
	char pad_300[0x8]; // 0x300(0x08)
	struct UAccountLinkAll* AccountLinkAll; // 0x308(0x08)

	void OnTotalPlayerCount(int32_t NewValue, int32_t OldValue); // Function DungeonCrawler.GameAlivePlayerCountWidget.OnTotalPlayerCount // (None) // @ game+0xffffc0d9df830041
};

// Class DungeonCrawler.GameAmmoWidget
// Size: 0x3e8 (Inherited: 0x300)
struct UGameAmmoWidget : UDCWidgetBase {
	struct UTextBlock* CurrentAmmoCount; // 0x300(0x08)
	struct UTextBlock* MaxAmmoCount; // 0x308(0x08)
	struct FSlateColor AmmoEmptyTextColor; // 0x310(0x14)
	struct FSlateColor AmmoDefaultTextColor; // 0x324(0x14)
	struct UAccountLink* AccountLink; // 0x338(0x08)
	struct TWeakObjectPtr<struct UEquipmentInventoryComponent> EquipmentInventory; // 0x340(0x08)
	struct FItemData ItemData; // 0x348(0xa0)
};

// Class DungeonCrawler.GameCancelTipWidget
// Size: 0x300 (Inherited: 0x300)
struct UGameCancelTipWidget : UDCShowingKeyWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)
};

// Class DungeonCrawler.GameCompassWidget
// Size: 0x310 (Inherited: 0x300)
struct UGameCompassWidget : UDCWidgetBase {
	struct UAccountLink* AccountLink; // 0x300(0x08)
	struct APawn* LinkedPawn; // 0x308(0x08)
};

// Class DungeonCrawler.GameCrossHairWidget
// Size: 0x308 (Inherited: 0x300)
struct UGameCrossHairWidget : UDCWidgetBase {
	bool IsMeleeCrossHair; // 0x300(0x01)
	char pad_301[0x7]; // 0x301(0x07)

	void OnPlayShootCrossHair(float Rate); // Function DungeonCrawler.GameCrossHairWidget.OnPlayShootCrossHair // (None) // @ game+0xffffc0e1df830041
};

// Class DungeonCrawler.GameEmoteSelectGroupWidget
// Size: 0x4d0 (Inherited: 0x460)
struct UGameEmoteSelectGroupWidget : UGameGroupWidgetBase {
	int32_t SelectedEmoteIndex; // 0x460(0x04)
	char pad_464[0x14]; // 0x464(0x14)
	struct ADCPlayerCharacterBase* PlayerCharacter; // 0x478(0x08)
	struct UGameEmoteSlotWidget* EmoteSlot_2; // 0x480(0x08)
	struct UGameEmoteSlotWidget* EmoteSlot_3; // 0x488(0x08)
	struct UGameEmoteSlotWidget* EmoteSlot_4; // 0x490(0x08)
	struct UGameEmoteSlotWidget* EmoteSlot_5; // 0x498(0x08)
	struct UGameEmoteSlotWidget* EmoteSlot_6; // 0x4a0(0x08)
	struct UGameEmoteSlotWidget* EmoteSlot_7; // 0x4a8(0x08)
	struct UGameEmoteSlotWidget* EmoteSlot_8; // 0x4b0(0x08)
	struct UGameEmoteSlotWidget* EmoteSlot_9; // 0x4b8(0x08)
	struct TArray<struct UGameEmoteSlotWidget*> EmoteSlots; // 0x4c0(0x10)

	void OnSelectedEmoteIndexChanged(); // Function DungeonCrawler.GameEmoteSelectGroupWidget.OnSelectedEmoteIndexChanged // (None) // @ game+0xffffc0e5df830041
};

// Class DungeonCrawler.GameEmoteSlotWidget
// Size: 0x320 (Inherited: 0x300)
struct UGameEmoteSlotWidget : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)
	char pad_308[0x18]; // 0x308(0x18)

	void SetEmoteData(struct UDCEmoteDataAsset* InDesignDataEmote); // Function DungeonCrawler.GameEmoteSlotWidget.SetEmoteData // (None) // @ game+0xffffc0ebdf830041
};

// Class DungeonCrawler.GameHeadupWidget
// Size: 0x308 (Inherited: 0x300)
struct UGameHeadupWidget : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)
};

// Class DungeonCrawler.GameHeadupAccountWidget
// Size: 0x370 (Inherited: 0x308)
struct UGameHeadupAccountWidget : UGameHeadupWidget {
	char pad_308[0x10]; // 0x308(0x10)
	struct FNickname Nickname; // 0x318(0x28)
	struct UTexture2D* CharacterIconTexture; // 0x340(0x08)
	bool bVisible; // 0x348(0x01)
	char pad_349[0x27]; // 0x349(0x27)

	void OnRefreshNickname(); // Function DungeonCrawler.GameHeadupAccountWidget.OnRefreshNickname // (None) // @ game+0xffffc0ecdf830041
};

// Class DungeonCrawler.GameHeadupWidgetComponent
// Size: 0x710 (Inherited: 0x6b0)
struct UGameHeadupWidgetComponent : UWidgetComponent {
	enum class EWidgetSpace Space; // 0x570(0x01)
	enum class EWidgetTimingPolicy TimingPolicy; // 0x571(0x01)
	struct UUserWidget* WidgetClass; // 0x578(0x08)
	struct FIntPoint DrawSize; // 0x580(0x08)
	bool bManuallyRedraw; // 0x588(0x01)
	bool bRedrawRequested; // 0x589(0x01)
	float RedrawTime; // 0x58c(0x04)
	struct FIntPoint CurrentDrawSize; // 0x598(0x08)
	bool bDrawAtDesiredSize; // 0x5a0(0x01)
	struct FVector2D Pivot; // 0x5a8(0x10)
	bool bReceiveHardwareInput; // 0x5b8(0x01)
	bool bWindowFocusable; // 0x5b9(0x01)
	enum class EWindowVisibility WindowVisibility; // 0x5ba(0x01)
	bool bApplyGammaCorrection; // 0x5bb(0x01)
	struct ULocalPlayer* OwnerPlayer; // 0x5c0(0x08)
	struct FLinearColor BackgroundColor; // 0x5c8(0x10)
	struct FLinearColor TintColorAndOpacity; // 0x5d8(0x10)
	float OpacityFromTexture; // 0x5e8(0x04)
	enum class EWidgetBlendMode BlendMode; // 0x5ec(0x01)
	bool bIsTwoSided; // 0x5ed(0x01)
	bool TickWhenOffscreen; // 0x5ee(0x01)
	struct UBodySetup* BodySetup; // 0x5f0(0x08)
	struct UMaterialInterface* TranslucentMaterial; // 0x5f8(0x08)
	struct UMaterialInterface* TranslucentMaterial_OneSided; // 0x600(0x08)
	struct UMaterialInterface* OpaqueMaterial; // 0x608(0x08)
	struct UMaterialInterface* OpaqueMaterial_OneSided; // 0x610(0x08)
	struct UMaterialInterface* MaskedMaterial; // 0x618(0x08)
	struct UMaterialInterface* MaskedMaterial_OneSided; // 0x620(0x08)
	struct UTextureRenderTarget2D* RenderTarget; // 0x628(0x08)
	struct UMaterialInstanceDynamic* MaterialInstance; // 0x630(0x08)
	bool bAddedToScreen; // 0x638(0x01)
	bool bEditTimeUsable; // 0x639(0x01)
	struct FName SharedLayerName; // 0x63c(0x08)
	int32_t LayerZOrder; // 0x644(0x04)
	enum class EWidgetGeometryMode GeometryMode; // 0x648(0x01)
	float CylinderArcAngle; // 0x64c(0x04)
	enum class ETickMode TickMode; // 0x650(0x01)
	struct UUserWidget* Widget; // 0x680(0x08)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.GameHeadupWidgetComponent.UnbindMsgAll // (None) // @ game+0xffffc116df830041
};

// Class DungeonCrawler.GameHitDirectionManagerWidget
// Size: 0x330 (Inherited: 0x300)
struct UGameHitDirectionManagerWidget : UDCWidgetBase {
	struct TArray<struct UDCWidgetBase*> HitDirectionWidgetList; // 0x300(0x10)
	struct UGameHitDirectionWidget* HitDirectionWidget; // 0x310(0x08)
	struct UGameHitDirectionWidget* AllDirectionWidget; // 0x318(0x08)
	struct UGameHitDirectionWidget* HealingWidget; // 0x320(0x08)
	int32_t SpawnCount; // 0x328(0x04)
	char pad_32C[0x4]; // 0x32c(0x04)
};

// Class DungeonCrawler.GameHitDirectionWidget
// Size: 0x318 (Inherited: 0x300)
struct UGameHitDirectionWidget : UDCWidgetBase {
	struct FVector HitDiection; // 0x300(0x18)

	void SetHitDirection(struct FVector Direction); // Function DungeonCrawler.GameHitDirectionWidget.SetHitDirection // (None) // @ game+0xffffc118df830041
};

// Class DungeonCrawler.GameInteractionDescriptionWidget
// Size: 0x378 (Inherited: 0x300)
struct UGameInteractionDescriptionWidget : UDCShowingKeyWidgetBase {
	struct FGameInteractionDescriptionWidgetData WidgetData; // 0x300(0x78)

	void OnInteractTargetData(struct FInteractTargetData& NewValue, struct FInteractTargetData& OldValue); // Function DungeonCrawler.GameInteractionDescriptionWidget.OnInteractTargetData // (None) // @ game+0xffffc11bdf830041
};

// Class DungeonCrawler.GameInteractionSkillCheckWidget
// Size: 0x310 (Inherited: 0x300)
struct UGameInteractionSkillCheckWidget : UDCShowingKeyWidgetBase {
	struct FGameplayTag SkillCheckType; // 0x300(0x08)
	float Duration; // 0x308(0x04)
	char pad_30C[0x4]; // 0x30c(0x04)

	void OnInteractSkillCheckStart(struct FSkillCheckData& SkillCheckData); // Function DungeonCrawler.GameInteractionSkillCheckWidget.OnInteractSkillCheckStart // (None) // @ game+0xffffc11ddf830041
};

// Class DungeonCrawler.GameInventoryGroupWidget
// Size: 0x498 (Inherited: 0x460)
struct UGameInventoryGroupWidget : UGameGroupWidgetBase {
	struct UAccountLink* AccountLink; // 0x460(0x08)
	struct TSoftClassPtr<UObject> ItemCountSelectWidgetClass; // 0x468(0x30)

	void OnPopItemSelectWidget(struct FItemData ItemData, struct AActor* OldOwnerActor); // Function DungeonCrawler.GameInventoryGroupWidget.OnPopItemSelectWidget // (None) // @ game+0xffffc120df830041
};

// Class DungeonCrawler.GameItemWearingBarWidget
// Size: 0x320 (Inherited: 0x300)
struct UGameItemWearingBarWidget : UDCWidgetBase {
	struct UProgressBar* ItemWearingGauge; // 0x300(0x08)
	float GaugeInterval; // 0x308(0x04)
	char pad_30C[0x14]; // 0x30c(0x14)
};

// Class DungeonCrawler.GameMenuOptionComboBoxWidget
// Size: 0x320 (Inherited: 0x300)
struct UGameMenuOptionComboBoxWidget : UDCWidgetBase {
	struct FMulticastInlineDelegate OnSelectionChanged; // 0x300(0x10)
	struct UComboBoxString* ComboBox; // 0x310(0x08)
	struct UTextBlock* Title; // 0x318(0x08)

	void SetTitle(struct FText InText); // Function DungeonCrawler.GameMenuOptionComboBoxWidget.SetTitle // (None) // @ game+0xffffc128df830041
};

// Class DungeonCrawler.GameMenuOptionPopupWidget
// Size: 0x460 (Inherited: 0x440)
struct UGameMenuOptionPopupWidget : UDCCommonActivatableWidgetBase {
	struct FMulticastInlineDelegate OnClicked; // 0x440(0x10)
	struct UCommonButtonPopupWidget* Btn_Left; // 0x450(0x08)
	struct UCommonButtonPopupWidget* Btn_Right; // 0x458(0x08)

	void UpdateDetailText(struct FText& InDetailText); // Function DungeonCrawler.GameMenuOptionPopupWidget.UpdateDetailText // (None) // @ game+0xffffc12edf830041
};

// Class DungeonCrawler.GameMenuOptionsAudioWidget
// Size: 0x4c0 (Inherited: 0x440)
struct UGameMenuOptionsAudioWidget : UDCCommonActivatableWidgetBase {
	struct UGameMenuOptionSliderWidget* WB_TotalVolume; // 0x440(0x08)
	struct UGameMenuOptionSliderWidget* WB_EffectVolume; // 0x448(0x08)
	struct UGameMenuOptionSliderWidget* WB_MusicVolume; // 0x450(0x08)
	struct UGameMenuOptionToggleSwitchWidget* WB_BackgroundVolume; // 0x458(0x08)
	struct UGameMenuOptionToggleSwitchWidget* WB_VoipOnOff; // 0x460(0x08)
	struct UGameMenuOptionToggleSwitchWidget* WB_VoipMode; // 0x468(0x08)
	struct UGameMenuOptionToggleSwitchWidget* WB_VoipSendMode; // 0x470(0x08)
	struct UGameMenuOptionSliderWidget* WB_VoipInputVolume; // 0x478(0x08)
	struct UGameMenuOptionSliderWidget* WB_VoipOutputVolume; // 0x480(0x08)
	struct FDataTableRowHandle ApplyInputActionData; // 0x488(0x10)
	char pad_498[0x8]; // 0x498(0x08)
	struct FDataTableRowHandle ResetInputActionData; // 0x4a0(0x10)
	char pad_4B0[0x10]; // 0x4b0(0x10)

	void UpdateWindowFocusChanged(bool IsFocus, bool IsBackgroundOption, float TotalVolume); // Function DungeonCrawler.GameMenuOptionsAudioWidget.UpdateWindowFocusChanged // (None) // @ game+0xffffc13cdf830041
};

// Class DungeonCrawler.GameMenuOptionsControlsWidget
// Size: 0x4e0 (Inherited: 0x440)
struct UGameMenuOptionsControlsWidget : UDCCommonActivatableWidgetBase {
	struct UGameMenuOptionSliderWidget* WB_MouseSensitivity; // 0x440(0x08)
	struct UGameMenuOptionToggleSwitchWidget* WB_InvertMouseVerticalAxis; // 0x448(0x08)
	struct UGameMenuOptionToggleSwitchWidget* WB_InvertMouseHorizontalAxis; // 0x450(0x08)
	struct UButton* EnglishButton; // 0x458(0x08)
	struct UButton* KoreanButton; // 0x460(0x08)
	struct UButton* JapaneseButton; // 0x468(0x08)
	struct UGameMenuOptionToggleSwitchWidget* WB_StreamingMode; // 0x470(0x08)
	struct FDataTableRowHandle ApplyInputActionData; // 0x478(0x10)
	char pad_488[0x8]; // 0x488(0x08)
	struct FDataTableRowHandle ResetInputActionData; // 0x490(0x10)
	char pad_4A0[0x40]; // 0x4a0(0x40)

	void OnStreamingModeClicked(bool IsClick); // Function DungeonCrawler.GameMenuOptionsControlsWidget.OnStreamingModeClicked // (None) // @ game+0xffffc144df830041
};

// Class DungeonCrawler.GameMenuOptionsInputBindPopupWidget
// Size: 0x450 (Inherited: 0x440)
struct UGameMenuOptionsInputBindPopupWidget : UDCCommonActivatableWidgetBase {
	struct UBaseObject* BaseObject; // 0x420(0x08)
	struct FDataTableRowHandle VirtualCursorModeInputActionData; // 0x428(0x10)
};

// Class DungeonCrawler.GameMenuOptionInputBindSlotItemData
// Size: 0x200 (Inherited: 0x28)
struct UGameMenuOptionInputBindSlotItemData : UObject {
	struct FEnhancedActionKeyMapping ActionKeyMapping; // 0x28(0x88)
	struct FKeyboardInputBinding FirstMappableBinding; // 0xb0(0xa8)
	struct FKeyboardInputBinding SecondaryMappableBinding; // 0x158(0xa8)
};

// Class DungeonCrawler.GameMenuOptionsInputBindSlotWidget
// Size: 0x338 (Inherited: 0x300)
struct UGameMenuOptionsInputBindSlotWidget : UDCWidgetBase {
	char pad_300[0x8]; // 0x300(0x08)
	struct UTextBlock* InputName; // 0x308(0x08)
	struct UDCCommonButtonBase* PrimaryKeyButton; // 0x310(0x08)
	struct UDCCommonButtonBase* SecondaryKeyButton; // 0x318(0x08)
	struct UDCCommonButtonBase* ClearButton; // 0x320(0x08)
	struct UGameMenuOptionsInputBindPopupWidget* InputBindPressAnyKeyPopupClass; // 0x328(0x08)
	struct UGameMenuOptionsInputBindPopupWidget* InputBindPressAnyKeyPopupWidget; // 0x330(0x08)

	void OnSecondaryKeyBindButtonClicked(); // Function DungeonCrawler.GameMenuOptionsInputBindSlotWidget.OnSecondaryKeyBindButtonClicked // (None) // @ game+0xffffc14bdf830041
};

// Class DungeonCrawler.GameMenuOptionsInputListView
// Size: 0xc20 (Inherited: 0xc20)
struct UGameMenuOptionsInputListView : UListView {
	struct FTableViewStyle WidgetStyle; // 0x340(0xe0)
	struct FScrollBarStyle ScrollBarStyle; // 0x420(0x770)
	enum class EOrientation Orientation; // 0xb90(0x01)
	enum class ESelectionMode SelectionMode; // 0xb91(0x01)
	enum class EConsumeMouseWheel ConsumeMouseWheel; // 0xb92(0x01)
	bool bClearSelectionOnClick; // 0xb93(0x01)
	bool bIsFocusable; // 0xb94(0x01)
	float EntrySpacing; // 0xb98(0x04)
	bool bReturnFocusToSelection; // 0xb9c(0x01)
	struct TArray<struct UObject*> ListItems; // 0xba0(0x10)
	struct FMulticastInlineDelegate BP_OnEntryInitialized; // 0xbc0(0x10)
	struct FMulticastInlineDelegate BP_OnItemClicked; // 0xbd0(0x10)
	struct FMulticastInlineDelegate BP_OnItemDoubleClicked; // 0xbe0(0x10)
	struct FMulticastInlineDelegate BP_OnItemIsHoveredChanged; // 0xbf0(0x10)
	struct FMulticastInlineDelegate BP_OnItemSelectionChanged; // 0xc00(0x10)
	struct FMulticastInlineDelegate BP_OnItemScrolledIntoView; // 0xc10(0x10)
};

// Class DungeonCrawler.GameMenuOptionInputSlotItemData
// Size: 0x38 (Inherited: 0x28)
struct UGameMenuOptionInputSlotItemData : UObject {
	struct FLoadedMappableConfigPair LoadedMappableConfigPair; // 0x28(0x10)
};

// Class DungeonCrawler.GameMenuOptionsInputSlotWidget
// Size: 0x318 (Inherited: 0x300)
struct UGameMenuOptionsInputSlotWidget : UDCWidgetBase {
	char pad_300[0x8]; // 0x300(0x08)
	struct UTextBlock* InputConfigName; // 0x308(0x08)
	struct UListView* InputBindSlotListView; // 0x310(0x08)

	struct UWidget* GetPrimaryGamepadFocusWidget(); // Function DungeonCrawler.GameMenuOptionsInputSlotWidget.GetPrimaryGamepadFocusWidget // (None) // @ game+0xffffc14cdf830041
};

// Class DungeonCrawler.GameMenuOptionsInputWidget
// Size: 0x478 (Inherited: 0x440)
struct UGameMenuOptionsInputWidget : UDCCommonActivatableWidgetBase {
	struct UListView* InputSlotListView; // 0x440(0x08)
	struct FDataTableRowHandle ApplyInputActionData; // 0x448(0x10)
	char pad_458[0x8]; // 0x458(0x08)
	struct FDataTableRowHandle ResetInputActionData; // 0x460(0x10)
	char pad_470[0x8]; // 0x470(0x08)

	void RefreshWidget(); // Function DungeonCrawler.GameMenuOptionsInputWidget.RefreshWidget // (None) // @ game+0xffffc150df830041
};

// Class DungeonCrawler.GameMenuOptionSliderWidget
// Size: 0x330 (Inherited: 0x300)
struct UGameMenuOptionSliderWidget : UDCWidgetBase {
	struct FMulticastInlineDelegate OnSliderValueChanged; // 0x300(0x10)
	struct UTextBlock* Title; // 0x310(0x08)
	float CurValue; // 0x318(0x04)
	float CurPerValue; // 0x31c(0x04)
	float MinValue; // 0x320(0x04)
	float MaxValue; // 0x324(0x04)
	float StepSize; // 0x328(0x04)
	char pad_32C[0x4]; // 0x32c(0x04)

	void UpdateSliderValue(float NewValue); // Function DungeonCrawler.GameMenuOptionSliderWidget.UpdateSliderValue // (None) // @ game+0xffffc15bdf830041
};

// Class DungeonCrawler.GameMenuOptionsVideosSlotWidget
// Size: 0x310 (Inherited: 0x300)
struct UGameMenuOptionsVideosSlotWidget : UDCWidgetBase {
	struct UTextBlock* Title; // 0x300(0x08)
	char pad_308[0x8]; // 0x308(0x08)

	void SetTitle(struct FText InTitle); // Function DungeonCrawler.GameMenuOptionsVideosSlotWidget.SetTitle // (None) // @ game+0xffffc1a5df830041
};

// Class DungeonCrawler.GameMenuOptionsVideoWidget
// Size: 0x4d0 (Inherited: 0x440)
struct UGameMenuOptionsVideoWidget : UDCCommonActivatableWidgetBase {
	struct UGameMenuOptionsVideosSlotWidget* WB_AntiAliasingQuality; // 0x440(0x08)
	struct UGameMenuOptionsVideosSlotWidget* WB_ShadowQuality; // 0x448(0x08)
	struct UGameMenuOptionsVideosSlotWidget* WB_TextureQuality; // 0x450(0x08)
	struct UGameMenuOptionsVideosSlotWidget* WB_PostProcessQuality; // 0x458(0x08)
	struct UGameMenuOptionsVideosSlotWidget* WB_EffectsQuality; // 0x460(0x08)
	struct UGameMenuOptionSliderWidget* WB_RenderScale; // 0x468(0x08)
	struct UGameMenuOptionComboBoxWidget* WB_DisplayMode; // 0x470(0x08)
	struct UGameMenuOptionComboBoxWidget* WB_DisplayResolution; // 0x478(0x08)
	struct UGameMenuOptionSliderWidget* WB_MaxFrameRateLimit; // 0x480(0x08)
	struct UGameMenuOptionSliderWidget* WB_Brightness; // 0x488(0x08)
	struct UGameMenuOptionsVideosSlotWidget* WB_DynamicResolution; // 0x490(0x08)
	struct FDataTableRowHandle ApplyInputActionData; // 0x498(0x10)
	char pad_4A8[0x8]; // 0x4a8(0x08)
	struct FDataTableRowHandle ResetInputActionData; // 0x4b0(0x10)
	char pad_4C0[0x10]; // 0x4c0(0x10)

	void UpdateGammaValue(float NewValue); // Function DungeonCrawler.GameMenuOptionsVideoWidget.UpdateGammaValue // (None) // @ game+0xffffc16bdf830041
};

// Class DungeonCrawler.GameMenuOptionsWidget
// Size: 0x470 (Inherited: 0x440)
struct UGameMenuOptionsWidget : UDCCommonActivatableWidgetBase {
	struct UCheckBox* ControlsCheckBox; // 0x440(0x08)
	struct UCheckBox* GameplayCheckBox; // 0x448(0x08)
	struct UCheckBox* AudioCheckBox; // 0x450(0x08)
	struct UCheckBox* VideoCheckBox; // 0x458(0x08)
	struct UCheckBox* InputCheckBox; // 0x460(0x08)
	struct UWidgetSwitcher* GameMenuOptionsWidgetSwitcher; // 0x468(0x08)

	void OnWidgetToggleNotify(enum class ESlateVisibility Invisibility); // Function DungeonCrawler.GameMenuOptionsWidget.OnWidgetToggleNotify // (None) // @ game+0xffffc172df830041
};

// Class DungeonCrawler.GameMenuOptionToggleSwitchWidget
// Size: 0x320 (Inherited: 0x300)
struct UGameMenuOptionToggleSwitchWidget : UDCWidgetBase {
	struct FMulticastInlineDelegate OnClicked; // 0x300(0x10)
	struct UTextBlock* Title; // 0x310(0x08)
	char pad_318[0x8]; // 0x318(0x08)

	void UpdateButtonText(struct FText& LeftText, struct FText& RightText); // Function DungeonCrawler.GameMenuOptionToggleSwitchWidget.UpdateButtonText // (None) // @ game+0xffffc17bdf830041
};

// Class DungeonCrawler.GameMenuWidget
// Size: 0x490 (Inherited: 0x440)
struct UGameMenuWidget : UDCCommonActivatableWidgetBase {
	struct UButton* ContinueButton; // 0x440(0x08)
	struct UButton* OptionsButton; // 0x448(0x08)
	struct UButton* LobbyButton; // 0x450(0x08)
	struct UButton* CharacterSelectButton; // 0x458(0x08)
	struct UButton* ExitButton; // 0x460(0x08)
	struct UGameMenuOptionsWidget* GameMenuOptionsWidget; // 0x468(0x08)
	struct UGameMenuOptionPopupWidget* WB_DisplayApplyPopup; // 0x470(0x08)
	struct FDataTableRowHandle BackInputActionData; // 0x478(0x10)
	char pad_488[0x8]; // 0x488(0x08)

	void OnOptionsButtonClicked(); // Function DungeonCrawler.GameMenuWidget.OnOptionsButtonClicked // (None) // @ game+0xffffc182df830041
};

// Class DungeonCrawler.GameMiniMapWidget
// Size: 0x398 (Inherited: 0x300)
struct UGameMiniMapWidget : UDCWidgetBase {
	struct UAccountLink* AccountLink; // 0x300(0x08)
	struct APawn* LinkedPawn; // 0x308(0x08)
	char pad_310[0x88]; // 0x310(0x88)

	void OnMiniMapName(struct FString NewMiniMapName, struct FString OldMiniMapName); // Function DungeonCrawler.GameMiniMapWidget.OnMiniMapName // (None) // @ game+0xffffc1c6df830041
};

// Class DungeonCrawler.GameMusicPlayBarWidget
// Size: 0x500 (Inherited: 0x300)
struct UGameMusicPlayBarWidget : UDCShowingKeyWidgetBase {
	struct UTextBlock* PlayText; // 0x300(0x08)
	struct UTextBlock* ChannelingText; // 0x308(0x08)
	struct UTextBlock* ChannelingTimer; // 0x310(0x08)
	struct USlider* PlaySlider; // 0x318(0x08)
	struct UProgressBar* PlayGauge; // 0x320(0x08)
	struct TArray<struct UWidget*> SectionWidgets; // 0x328(0x10)
	struct UHorizontalBox* HorizontalBox; // 0x338(0x08)
	struct UHorizontalBox* HorizontalBox_Perfect; // 0x340(0x08)
	struct USizeBox* SizeBox_Channeling; // 0x348(0x08)
	struct FSlateBrush GoodJudgeAreaBrush; // 0x350(0xd0)
	struct FSlateBrush PerfectJudgeAreaBrush; // 0x420(0xd0)
	char pad_4F0[0x10]; // 0x4f0(0x10)

	void OnMusicPlaySucceed(); // Function DungeonCrawler.GameMusicPlayBarWidget.OnMusicPlaySucceed // (None) // @ game+0xffffc18adf830041
};

// Class DungeonCrawler.MusicListWidgetBase
// Size: 0x498 (Inherited: 0x460)
struct UMusicListWidgetBase : UGameGroupWidgetBase {
	struct UMusicSlotWidgetBase* MusicSlot_2; // 0x460(0x08)
	struct UMusicSlotWidgetBase* MusicSlot_3; // 0x468(0x08)
	struct UMusicSlotWidgetBase* MusicSlot_4; // 0x470(0x08)
	struct UMusicSlotWidgetBase* MusicSlot_5; // 0x478(0x08)
	struct TArray<struct UMusicSlotWidgetBase*> MusicSlots; // 0x480(0x10)
	enum class EWidgetMusicSlotsType WidgetSlotType; // 0x490(0x01)
	char pad_491[0x7]; // 0x491(0x07)
};

// Class DungeonCrawler.GameMusicSelectGroupWidget
// Size: 0x4b8 (Inherited: 0x498)
struct UGameMusicSelectGroupWidget : UMusicListWidgetBase {
	int32_t SelectedMusicIndex; // 0x498(0x04)
	char pad_49C[0x14]; // 0x49c(0x14)
	struct ADCPlayerCharacterBase* PlayerCharacter; // 0x4b0(0x08)

	void OnSelectedMusicIndexChanged(); // Function DungeonCrawler.GameMusicSelectGroupWidget.OnSelectedMusicIndexChanged // (None) // @ game+0xffffc18edf830041
};

// Class DungeonCrawler.MusicSlotWidgetBase
// Size: 0x3e8 (Inherited: 0x300)
struct UMusicSlotWidgetBase : UDCWidgetBase {
	struct FMusicData MusicData; // 0x300(0x1c)
	char pad_31C[0x4]; // 0x31c(0x04)
	struct FDesignDataMusic DesignDataMusic; // 0x320(0xa8)
	struct TArray<struct FText> DescTextArray; // 0x3c8(0x10)
	struct UArtDataMusic* ArtData; // 0x3d8(0x08)
	int32_t SlotIndex; // 0x3e0(0x04)
	char pad_3E4[0x4]; // 0x3e4(0x04)

	void SetMusicData(struct FMusicData& InMusicData, struct FDesignDataMusic& InDesignDataMusic); // Function DungeonCrawler.MusicSlotWidgetBase.SetMusicData // (None) // @ game+0xffffc193df830041
};

// Class DungeonCrawler.GameMusicSlotWidget
// Size: 0x3e8 (Inherited: 0x3e8)
struct UGameMusicSlotWidget : UMusicSlotWidgetBase {
	struct FMusicData MusicData; // 0x300(0x1c)
	struct FDesignDataMusic DesignDataMusic; // 0x320(0xa8)
	struct TArray<struct FText> DescTextArray; // 0x3c8(0x10)
	struct UArtDataMusic* ArtData; // 0x3d8(0x08)
	int32_t SlotIndex; // 0x3e0(0x04)

	void SelectionChange(bool bIsSelected); // Function DungeonCrawler.GameMusicSlotWidget.SelectionChange // (None) // @ game+0xffffc195df830041
};

// Class DungeonCrawler.GamePartyManagePartyMemberWidgetData
// Size: 0x38 (Inherited: 0x28)
struct UGamePartyManagePartyMemberWidgetData : UObject {
	struct FPartyMemberData PartyMemberData; // 0x28(0x10)
};

// Class DungeonCrawler.GamePartyManagePartyMemberWidget
// Size: 0x388 (Inherited: 0x300)
struct UGamePartyManagePartyMemberWidget : UDCWidgetBase {
	char pad_300[0x80]; // 0x300(0x80)
	struct UAccountLink* AccountLink; // 0x380(0x08)

	void OnAccountDataReplication(struct FAccountDataReplication& NewValue, struct FAccountDataReplication& OldValue); // Function DungeonCrawler.GamePartyManagePartyMemberWidget.OnAccountDataReplication // (None) // @ game+0xffffc196df830041
};

// Class DungeonCrawler.GamePartyManagePartyWidgetData
// Size: 0x48 (Inherited: 0x28)
struct UGamePartyManagePartyWidgetData : UObject {
	struct FPartyData PartyData; // 0x28(0x20)
};

// Class DungeonCrawler.GamePartyManagePartyWidget
// Size: 0x338 (Inherited: 0x300)
struct UGamePartyManagePartyWidget : UDCWidgetBase {
	char pad_300[0x8]; // 0x300(0x08)
	struct UButton* PartyJoinButton; // 0x308(0x08)
	struct UListView* PartyMemberListView; // 0x310(0x08)
	char pad_318[0x20]; // 0x318(0x20)

	void PartyJoin(); // Function DungeonCrawler.GamePartyManagePartyWidget.PartyJoin // (None) // @ game+0xffffc198df830041
};

// Class DungeonCrawler.GamePartyManageWidget
// Size: 0x368 (Inherited: 0x300)
struct UGamePartyManageWidget : UDCWidgetBase {
	struct UGamePartyManagePartyWidget* NonPartyWidget; // 0x300(0x08)
	struct UTileView* PartyTileView; // 0x308(0x08)
	struct UAccountLinkAll* AccountLinkAll; // 0x310(0x08)
	struct TMap<struct FString, struct UGamePartyManagePartyWidgetData*> GamePartyManagePartyWidgetDataMap; // 0x318(0x50)
};

// Class DungeonCrawler.GamePartyMemberWidgetData
// Size: 0x40 (Inherited: 0x28)
struct UGamePartyMemberWidgetData : UObject {
	char pad_28[0x18]; // 0x28(0x18)
};

// Class DungeonCrawler.GamePartyMemberWidget
// Size: 0x3a8 (Inherited: 0x300)
struct UGamePartyMemberWidget : UDCWidgetBase {
	char pad_300[0x20]; // 0x300(0x20)
	struct UVerticalBox* PartyMemberActorStatusColumn; // 0x320(0x08)
	struct UVoipUserWidget* VoipUserWidget; // 0x328(0x08)
	int32_t NumActorStatusRows; // 0x330(0x04)
	char pad_334[0x4]; // 0x334(0x04)
	struct UDCPartyMemberActorStatusRow* PartyMemberActorStatusRowClass; // 0x338(0x08)
	char pad_340[0x10]; // 0x340(0x10)
	struct FNickname Nickname; // 0x350(0x28)
	bool bIsAlive; // 0x378(0x01)
	char pad_379[0x3]; // 0x379(0x03)
	float HealthRate; // 0x37c(0x04)
	float RecoverableHealthRate; // 0x380(0x04)
	bool bIsEscaped; // 0x384(0x01)
	bool bIsDisconnected; // 0x385(0x01)
	bool bIsOnline; // 0x386(0x01)
	bool bIsOffline; // 0x387(0x01)
	bool bIsTarget; // 0x388(0x01)
	char pad_389[0x7]; // 0x389(0x07)
	struct UTexture2D* Portrait; // 0x390(0x08)
	struct UTexture2D* ClassIcon; // 0x398(0x08)
	struct UTextureRenderTarget2D* PortraitRenderTarget; // 0x3a0(0x08)

	void OnRefreshNickname(); // Function DungeonCrawler.GamePartyMemberWidget.OnRefreshNickname // (None) // @ game+0xffffc19adf830041
};

// Class DungeonCrawler.GamePartyWidget
// Size: 0x328 (Inherited: 0x300)
struct UGamePartyWidget : UDCWidgetBase {
	struct UTileView* PartyMemberTileView; // 0x300(0x08)
	struct FDCAccountId TargetAccountId; // 0x308(0x10)
	struct FDCPartyId TargetPartyId; // 0x318(0x10)
};

// Class DungeonCrawler.GamePlayerCharacterWidget
// Size: 0x398 (Inherited: 0x300)
struct UGamePlayerCharacterWidget : UDCShowingKeyWidgetBase {
	struct UEquipmentWeaponSlotSetWidget* WeaponSetL; // 0x300(0x08)
	struct UEquipmentWeaponSlotSetWidget* WeaponSetR; // 0x308(0x08)
	struct UEquipmentSlotWidget* UtilityL1; // 0x310(0x08)
	struct UEquipmentSlotWidget* UtilityL2; // 0x318(0x08)
	struct UEquipmentSlotWidget* UtilityL3; // 0x320(0x08)
	struct UEquipmentSlotWidget* UtilityR1; // 0x328(0x08)
	struct UEquipmentSlotWidget* UtilityR2; // 0x330(0x08)
	struct UEquipmentSlotWidget* UtilityR3; // 0x338(0x08)
	struct FNickname Nickname; // 0x340(0x28)
	float HealthRate; // 0x368(0x04)
	float RecoverableHealthRate; // 0x36c(0x04)
	struct FDCAccountId AccountId; // 0x370(0x10)
	struct ADCPlayerCharacterBase* PlayerCharacter; // 0x380(0x08)
	struct TArray<struct UEquipmentSlotWidget*> EquipmentSlotWidgetArray; // 0x388(0x10)

	void OnCurrentActiveSlot(struct UEquipmentSlotWidget* CurrentActiveWidget); // Function DungeonCrawler.GamePlayerCharacterWidget.OnCurrentActiveSlot // (None) // @ game+0xffffc19cdf830041
};

// Class DungeonCrawler.GamePlayerEquipSlotWidget
// Size: 0x368 (Inherited: 0x300)
struct UGamePlayerEquipSlotWidget : UDCWidgetBase {
	struct UEquipmentWeaponSlotSetWidget* WeaponSetL; // 0x300(0x08)
	struct UEquipmentWeaponSlotSetWidget* WeaponSetR; // 0x308(0x08)
	struct UEquipmentSlotWidget* UtilityL1; // 0x310(0x08)
	struct UEquipmentSlotWidget* UtilityL2; // 0x318(0x08)
	struct UEquipmentSlotWidget* UtilityL3; // 0x320(0x08)
	struct UEquipmentSlotWidget* UtilityR1; // 0x328(0x08)
	struct UEquipmentSlotWidget* UtilityR2; // 0x330(0x08)
	struct UEquipmentSlotWidget* UtilityR3; // 0x338(0x08)
	struct FDCAccountId AccountId; // 0x340(0x10)
	struct ADCPlayerCharacterBase* PlayerCharacter; // 0x350(0x08)
	struct TArray<struct UEquipmentSlotWidget*> EquipmentSlotWidgetArray; // 0x358(0x10)

	void OnCurrentActiveSlot(struct UEquipmentSlotWidget* CurrentActiveWidget); // Function DungeonCrawler.GamePlayerEquipSlotWidget.OnCurrentActiveSlot // (None) // @ game+0xffffc19ddf830041
};

// Class DungeonCrawler.GameplayAbilityRelationshipData
// Size: 0x40 (Inherited: 0x30)
struct UGameplayAbilityRelationshipData : UDataAsset {
	struct TArray<struct FGameplayAbilityRelationshipItem> AbilityTagRelationships; // 0x30(0x10)
};

// Class DungeonCrawler.GameplayTagMessageRelationshipData
// Size: 0x80 (Inherited: 0x30)
struct UGameplayTagMessageRelationshipData : UDataAsset {
	struct TMap<struct FGameplayTag, struct FText> GameplayTagMessageRelationshipData; // 0x30(0x50)
};

// Class DungeonCrawler.CannotMoveGameplayTagData
// Size: 0x50 (Inherited: 0x30)
struct UCannotMoveGameplayTagData : UDataAsset {
	struct FGameplayTagContainer TagContainer; // 0x30(0x20)
};

// Class DungeonCrawler.GameplayCueRelationshipData
// Size: 0xd0 (Inherited: 0x30)
struct UGameplayCueRelationshipData : UDataAsset {
	struct TMap<struct FGameplayTag, struct FGameplayCueTag> GameplayCueRelationshipWithStateTag; // 0x30(0x50)
	struct TMap<struct FGameplayTag, struct FGameplayCueTag> OwningClientOnlyGameplayCueRelationshipWithStateTag; // 0x80(0x50)
};

// Class DungeonCrawler.GameplayTagSoundConditionData
// Size: 0x80 (Inherited: 0x30)
struct UGameplayTagSoundConditionData : UDataAsset {
	struct TMap<struct FGameplayTag, struct FGameplayTagQuery> GameplayTagSoundConditionData; // 0x30(0x50)
};

// Class DungeonCrawler.GameProgressBarWidget
// Size: 0x320 (Inherited: 0x300)
struct UGameProgressBarWidget : UDCShowingKeyWidgetBase {
	struct UTextBlock* ProgressText; // 0x300(0x08)
	struct UProgressBar* ProgressGauge; // 0x308(0x08)
	float Percent; // 0x310(0x04)
	char pad_314[0xc]; // 0x314(0x0c)

	void OnPercentUpdated(); // Function DungeonCrawler.GameProgressBarWidget.OnPercentUpdated // (None) // @ game+0xffffc19edf830041
};

// Class DungeonCrawler.GameSkillSlotWidget
// Size: 0x370 (Inherited: 0x300)
struct UGameSkillSlotWidget : UDCShowingKeyWidgetBase {
	struct TMap<int32_t, struct FSkillCooldownInfo> SkillCooldownList; // 0x300(0x50)
	struct TArray<struct FSkillData> SkillDataList; // 0x350(0x10)
	struct UAccountLink* AccountLink; // 0x360(0x08)
	char pad_368[0x8]; // 0x368(0x08)

	void UpdateSkillSlotCooldownData(int32_t Index, struct FGameplayTag SkillTag, float MaxDuration, float RemainDuration); // Function DungeonCrawler.GameSkillSlotWidget.UpdateSkillSlotCooldownData // (None) // @ game+0xffffc1b1df830041
};

// Class DungeonCrawler.GameSpellCastingBarWidget
// Size: 0x320 (Inherited: 0x300)
struct UGameSpellCastingBarWidget : UDCShowingKeyWidgetBase {
	struct UTextBlock* CastingText; // 0x300(0x08)
	struct UProgressBar* CastingGauge; // 0x308(0x08)
	char pad_310[0x10]; // 0x310(0x10)

	void OnSpellChannelingStart(); // Function DungeonCrawler.GameSpellCastingBarWidget.OnSpellChannelingStart // (None) // @ game+0xffffc1b6df830041
};

// Class DungeonCrawler.GameSpellCurrentSlotWidget
// Size: 0x400 (Inherited: 0x300)
struct UGameSpellCurrentSlotWidget : UDCWidgetBase {
	struct FSpellData SpellData; // 0x300(0x30)
	struct FDesignDataSpell DesignDataSpell; // 0x330(0xb8)
	char pad_3E8[0x10]; // 0x3e8(0x10)
	struct ADCPlayerCharacterBase* PlayerCharacter; // 0x3f8(0x08)

	void SetSpellData(struct FSpellData& InSpellData, struct FDesignDataSpell& InDesignDataSpell); // Function DungeonCrawler.GameSpellCurrentSlotWidget.SetSpellData // (None) // @ game+0xffffc1b9df830041
};

// Class DungeonCrawler.GameSpellSelectGroupWidget
// Size: 0x4c0 (Inherited: 0x4a0)
struct UGameSpellSelectGroupWidget : USpellListWidgetBase {
	int32_t SelectedSpellIndex; // 0x4a0(0x04)
	char pad_4A4[0x14]; // 0x4a4(0x14)
	struct ADCPlayerCharacterBase* PlayerCharacter; // 0x4b8(0x08)

	void OnSpellSelectPopup(); // Function DungeonCrawler.GameSpellSelectGroupWidget.OnSpellSelectPopup // (None) // @ game+0xffffc1bddf830041
};

// Class DungeonCrawler.GameSpellSlotWidget
// Size: 0x408 (Inherited: 0x408)
struct UGameSpellSlotWidget : USpellSlotWidgetBase {
	struct FSpellData SpellData; // 0x300(0x30)
	struct FDesignDataSpell DesignDataSpell; // 0x330(0xb8)
	struct TArray<struct FText> DescTextArray; // 0x3e8(0x10)
	struct UArtDataSpell* ArtData; // 0x3f8(0x08)
	int32_t SlotIndex; // 0x400(0x04)

	void SelectionChange(bool bIsSelected); // Function DungeonCrawler.GameSpellSlotWidget.SelectionChange // (None) // @ game+0xffffc1c0df830041
};

// Class DungeonCrawler.TimerWidgetBase
// Size: 0x320 (Inherited: 0x300)
struct UTimerWidgetBase : UDCWidgetBase {
	struct UAccountLink* AccountLink; // 0x300(0x08)
	struct FTimerWidgetData WidgetData; // 0x308(0x10)
	char pad_318[0x8]; // 0x318(0x08)

	void StartTimer(float InEndServerWorldTime); // Function DungeonCrawler.TimerWidgetBase.StartTimer // (None) // @ game+0xffffc203df830041
};

// Class DungeonCrawler.GameTavernStartTimerWidget
// Size: 0x328 (Inherited: 0x320)
struct UGameTavernStartTimerWidget : UTimerWidgetBase {
	int32_t NumCurrentPlayers; // 0x320(0x04)
	int32_t NumMaxPlayers; // 0x324(0x04)

	void OnUpdated(); // Function DungeonCrawler.GameTavernStartTimerWidget.OnUpdated // (None) // @ game+0xffffc1c9df830041
};

// Class DungeonCrawler.GameTestComponent
// Size: 0x108 (Inherited: 0xa0)
struct UGameTestComponent : UActorComponent {
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x30(0x30)
	struct TArray<struct FName> ComponentTags; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	int32_t UCSSerializationIndex; // 0x84(0x04)
	char pad_F4_0 : 3; // 0xf4(0x01)
	char bNetAddressable : 1; // 0x88(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x88(0x01)
	char bReplicates : 1; // 0x88(0x01)
	char bAutoActivate : 1; // 0x8a(0x01)
	char bIsActive : 1; // 0x8a(0x01)
	char pad_F5_0 : 3; // 0xf5(0x01)
	char bEditableWhenInherited : 1; // 0x8a(0x01)
	char pad_F5_4 : 1; // 0xf5(0x01)
	char bCanEverAffectNavigation : 1; // 0x8a(0x01)
	char pad_F5_6 : 1; // 0xf5(0x01)
	char bIsEditorOnly : 1; // 0x8a(0x01)
	enum class EComponentCreationMethod CreationMethod; // 0x8d(0x01)
	struct FMulticastSparseDelegate OnComponentActivated; // 0x8e(0x01)
	struct FMulticastSparseDelegate OnComponentDeactivated; // 0x8f(0x01)
	char pad_F9[0xf]; // 0xf9(0x0f)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.GameTestComponent.UnbindMsgAll // (None) // @ game+0xffffc1dddf830041
};

// Class DungeonCrawler.GameVoipComponent
// Size: 0x270 (Inherited: 0x1f8)
struct UGameVoipComponent : UDCVoipComponent {
	char pad_1F8[0x28]; // 0x1f8(0x28)
	struct TMap<struct FDCAccountId, struct FBindAccountUserData> BindAccountUserDataMap; // 0x220(0x50)
};

// Class DungeonCrawler.GameVoipInterface
// Size: 0x28 (Inherited: 0x28)
struct UGameVoipInterface : UInterface {
};

// Class DungeonCrawler.GA_ActivateItemBase
// Size: 0x598 (Inherited: 0x558)
struct UGA_ActivateItemBase : UDCGameplayAbilityBase {
	struct UAnimMontage* MontageToPlay; // 0x558(0x08)
	struct UAnimMontage* MontageToPlayOnSourceObject; // 0x560(0x08)
	struct FGameplayTag ActivateTag; // 0x568(0x08)
	struct FGameplayTag DeactivateTag; // 0x570(0x08)
	char pad_578[0x8]; // 0x578(0x08)
	struct FTimerHandle OtherHandIACompletedHandle; // 0x580(0x08)
	struct FGameplayTag OtherHandTriggerEventTag; // 0x588(0x08)
	struct FGameplayTag OtherHandEnablingEventTag; // 0x590(0x08)

	void ReceivedEvent(struct FGameplayTag EventTag, struct FGameplayEventData EventData); // Function DungeonCrawler.GA_ActivateItemBase.ReceivedEvent // (None) // @ game+0xffffc1e4df830041
};

// Class DungeonCrawler.GA_AuraBase
// Size: 0x5c0 (Inherited: 0x558)
struct UGA_AuraBase : UDCGameplayAbilityBase {
	struct AActor* TargetActorClass; // 0x558(0x08)
	bool bUsePremadeSpec; // 0x560(0x01)
	char pad_561[0x3]; // 0x561(0x03)
	struct FGameplayCueTag GameplayCueTag; // 0x564(0x08)
	char pad_56C[0x54]; // 0x56c(0x54)

	void OnAuraOverlapEnd(struct UPrimitiveComponent* OverlappedComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function DungeonCrawler.GA_AuraBase.OnAuraOverlapEnd // (None) // @ game+0xffffc1e9df830041
};

// Class DungeonCrawler.GA_RangedAttackBase
// Size: 0x5c0 (Inherited: 0x558)
struct UGA_RangedAttackBase : UDCGameplayAbilityBase {
	struct UAnimMontage* MontageToPlay; // 0x558(0x08)
	struct UAnimMontage* MontageToPlayOnSourceObject; // 0x560(0x08)
	struct AProjectileActor* ProjectileActorClass; // 0x568(0x08)
	struct FName FireSocketName; // 0x570(0x08)
	float ProjectileSpeedMultiplier; // 0x578(0x04)
	char pad_57C[0x4]; // 0x57c(0x04)
	bool IsMultiFireProjectiles; // 0x580(0x01)
	char pad_581[0x7]; // 0x581(0x07)
	struct UCurveFloat* DamageCurve; // 0x588(0x08)
	bool bNeedsAmmoToActivate; // 0x590(0x01)
	bool bNeedsAmmoToFire; // 0x591(0x01)
	char pad_592[0x2]; // 0x592(0x02)
	int32_t AmmoUsage; // 0x594(0x04)
	struct FPrimaryAssetId AmmoItemId; // 0x598(0x10)
	bool bPlayPullOnAnimationActivation; // 0x5a8(0x01)
	char pad_5A9[0x7]; // 0x5a9(0x07)
	struct ADCGATA_AimTraceToSocket* SocketTargetActor; // 0x5b0(0x08)
	char pad_5B8[0x8]; // 0x5b8(0x08)

	void ReceivedEvent(struct FGameplayTag EventTag, struct FGameplayEventData EventData); // Function DungeonCrawler.GA_RangedAttackBase.ReceivedEvent // (None) // @ game+0xffffc1f8df830041
};

// Class DungeonCrawler.GA_ChargedRangedAttackBase
// Size: 0x5c8 (Inherited: 0x5c0)
struct UGA_ChargedRangedAttackBase : UGA_RangedAttackBase {
	struct UAnimMontage* MontageToPlay; // 0x558(0x08)
	struct UAnimMontage* MontageToPlayOnSourceObject; // 0x560(0x08)
	struct AProjectileActor* ProjectileActorClass; // 0x568(0x08)
	struct FName FireSocketName; // 0x570(0x08)
	float ProjectileSpeedMultiplier; // 0x578(0x04)
	bool IsMultiFireProjectiles; // 0x580(0x01)
	struct UCurveFloat* DamageCurve; // 0x588(0x08)
	bool bNeedsAmmoToActivate; // 0x590(0x01)
	bool bNeedsAmmoToFire; // 0x591(0x01)
	int32_t AmmoUsage; // 0x594(0x04)
	struct FPrimaryAssetId AmmoItemId; // 0x598(0x10)
	bool bPlayPullOnAnimationActivation; // 0x5a8(0x01)
	struct ADCGATA_AimTraceToSocket* SocketTargetActor; // 0x5b0(0x08)

	void SendPlayShootCrossHairNotify(); // Function DungeonCrawler.GA_ChargedRangedAttackBase.SendPlayShootCrossHairNotify // (None) // @ game+0xffffc1fddf830041
};

// Class DungeonCrawler.GA_BowAttackBase
// Size: 0x5d8 (Inherited: 0x5c8)
struct UGA_BowAttackBase : UGA_ChargedRangedAttackBase {
	struct UAnimMontage* NimbleHandMontageToPlay; // 0x5c8(0x08)
	struct UAnimMontage* NimbleHandMontageToPlayOnSourceObject; // 0x5d0(0x08)
};

// Class DungeonCrawler.GA_BowQuickShotBase
// Size: 0x5c8 (Inherited: 0x5c0)
struct UGA_BowQuickShotBase : UGA_RangedAttackBase {
	int32_t AmmoWholeUsage; // 0x5c0(0x04)
	char pad_5C4[0x4]; // 0x5c4(0x04)

	void InputActionStarted(); // Function DungeonCrawler.GA_BowQuickShotBase.InputActionStarted // (None) // @ game+0xffffc1ffdf830041
};

// Class DungeonCrawler.GA_ChangeIdle
// Size: 0x588 (Inherited: 0x558)
struct UGA_ChangeIdle : UDCGameplayAbilityBase {
	struct TSoftObjectPtr<UAnimMontage> MontageToPlay; // 0x558(0x30)

	void OnCompleted(struct FGameplayTag EventTag, struct FGameplayEventData EventData); // Function DungeonCrawler.GA_ChangeIdle.OnCompleted // (None) // @ game+0xffffc202df830041
};

// Class DungeonCrawler.GA_CharacterJump
// Size: 0x558 (Inherited: 0x558)
struct UGA_CharacterJump : UDCGameplayAbilityBase {
	struct TArray<struct FDCGameplayEffectContainer> EffectContainerArray; // 0x498(0x10)
	struct TArray<struct FDCGameplayEffectData> OverrideGameplayEffectDataArray; // 0x4a8(0x10)
	struct TArray<struct FActiveGameplayEffectHandle> ActiveEffectHandles; // 0x4b8(0x10)
	struct FGameplayTag IdleAnimSequenceGameplayTag; // 0x4c8(0x08)
	struct UDCMovementModifierContainerData* MovementModifierContainer; // 0x4d0(0x08)
	struct FDesignDataGameplayAbility DesignDataGameplayAbility; // 0x4d8(0x58)
	struct FGameplayTagContainer AppliedMovementModifierTags; // 0x530(0x20)
	bool bIsDefaultMovementModifierApplied; // 0x550(0x01)

	void OnMovementModeChange(enum class EMovementMode MovementMode); // Function DungeonCrawler.GA_CharacterJump.OnMovementModeChange // (None) // @ game+0xffffc204df830041
};

// Class DungeonCrawler.GA_Drop
// Size: 0x588 (Inherited: 0x558)
struct UGA_Drop : UDCGameplayAbilityBase {
	struct UItem* DropItem; // 0x558(0x08)
	int32_t DropSlotId; // 0x560(0x04)
	bool bFailedDropItem; // 0x564(0x01)
	char pad_565[0x3]; // 0x565(0x03)
	struct FLocomotionAnimSet DropResultAnimSet; // 0x568(0x18)
	bool bWasCurrentActiveSlot; // 0x580(0x01)
	bool bBeingEmptySlot; // 0x581(0x01)
	char pad_582[0x6]; // 0x582(0x06)

	void OnEndSync(); // Function DungeonCrawler.GA_Drop.OnEndSync // (None) // @ game+0xffffc205df830041
};

// Class DungeonCrawler.GA_Equip
// Size: 0x590 (Inherited: 0x558)
struct UGA_Equip : UDCGameplayAbilityBase {
	enum class EEquipmentQuickSlotType EquipmentQuickSlotType; // 0x558(0x01)
	bool bTryingEquip; // 0x559(0x01)
	char pad_55A[0x6]; // 0x55a(0x06)
	struct TArray<struct UItem*> EquipItems; // 0x560(0x10)
	struct ADCPlayerCharacterBase* Character; // 0x570(0x08)
	struct UEquipmentInventoryComponent* EquipmentComponent; // 0x578(0x08)
	struct UInventoryComponent* InventoryComponent; // 0x580(0x08)
	struct FGameplayTag GameplayTagToAdd; // 0x588(0x08)

	void OnMontageEventReceived(struct FGameplayTag EventTag, struct FGameplayEventData EventData); // Function DungeonCrawler.GA_Equip.OnMontageEventReceived // (None) // @ game+0xffffc208df830041
};

// Class DungeonCrawler.GA_Interact
// Size: 0x6a0 (Inherited: 0x558)
struct UGA_Interact : UDCGameplayAbilityBase {
	struct UAnimMontage* MontageToPlayBothHandEquipped; // 0x558(0x08)
	struct UAnimMontage* MontageToPlayPrimaryEquipped; // 0x560(0x08)
	struct UAnimMontage* MontageToPlaySecondaryEquipped; // 0x568(0x08)
	struct UAnimMontage* MontageToPlayPrimaryEquippedInstant; // 0x570(0x08)
	struct UAnimMontage* MontageToPlaySecondaryEquippedInstant; // 0x578(0x08)
	struct FPrimaryAssetId CharacterStopMovementThresholdConstant; // 0x580(0x10)
	struct FPrimaryAssetId InteractionStartThresholdConstant; // 0x590(0x10)
	struct UDCAT_WaitDelayPausable* WaitDelayPausableTask; // 0x5a0(0x08)
	struct FRandomStream Stream; // 0x5a8(0x08)
	struct FInteractionData CurrentData; // 0x5b0(0x90)
	struct FDesignDataPropsSkillCheck CurrentSkillCheckData; // 0x640(0x30)
	struct FGameplayTag CurrentInteractTag; // 0x670(0x08)
	struct FGameplayTag CurrentStateTag; // 0x678(0x08)
	struct AActor* InteractTargetActor; // 0x680(0x08)
	char pad_688[0x18]; // 0x688(0x18)

	void OnVelocityChange(); // Function DungeonCrawler.GA_Interact.OnVelocityChange // (None) // @ game+0xffffc217df830041
};

// Class DungeonCrawler.GA_HuntingTrapDisarmInteract
// Size: 0x6a0 (Inherited: 0x6a0)
struct UGA_HuntingTrapDisarmInteract : UGA_Interact {
	struct UAnimMontage* MontageToPlayBothHandEquipped; // 0x558(0x08)
	struct UAnimMontage* MontageToPlayPrimaryEquipped; // 0x560(0x08)
	struct UAnimMontage* MontageToPlaySecondaryEquipped; // 0x568(0x08)
	struct UAnimMontage* MontageToPlayPrimaryEquippedInstant; // 0x570(0x08)
	struct UAnimMontage* MontageToPlaySecondaryEquippedInstant; // 0x578(0x08)
	struct FPrimaryAssetId CharacterStopMovementThresholdConstant; // 0x580(0x10)
	struct FPrimaryAssetId InteractionStartThresholdConstant; // 0x590(0x10)
	struct UDCAT_WaitDelayPausable* WaitDelayPausableTask; // 0x5a0(0x08)
	struct FRandomStream Stream; // 0x5a8(0x08)
	struct FInteractionData CurrentData; // 0x5b0(0x90)
	struct FDesignDataPropsSkillCheck CurrentSkillCheckData; // 0x640(0x30)
	struct FGameplayTag CurrentInteractTag; // 0x670(0x08)
	struct FGameplayTag CurrentStateTag; // 0x678(0x08)
	struct AActor* InteractTargetActor; // 0x680(0x08)
};

// Class DungeonCrawler.GA_StoppablePassiveBase
// Size: 0x570 (Inherited: 0x558)
struct UGA_StoppablePassiveBase : UDCGameplayAbilityBase {
	struct TArray<struct FGameplayTag> PassiveStopStateTags; // 0x558(0x10)
	char pad_568[0x8]; // 0x568(0x08)

	void OnStateTagRemoved(); // Function DungeonCrawler.GA_StoppablePassiveBase.OnStateTagRemoved // (None) // @ game+0xffffc21bdf830041
};

// Class DungeonCrawler.GA_HuntingTrapDisarmPassiveBase
// Size: 0x5d0 (Inherited: 0x570)
struct UGA_HuntingTrapDisarmPassiveBase : UGA_StoppablePassiveBase {
	char pad_570[0x8]; // 0x570(0x08)
	struct TMap<struct FGameplayTag, struct FInteractionData> CurrentInteractableDatas; // 0x578(0x50)
	char pad_5C8[0x8]; // 0x5c8(0x08)

	void SetDisarmTarget(struct APropsActorBase* TargetHuntingTrap); // Function DungeonCrawler.GA_HuntingTrapDisarmPassiveBase.SetDisarmTarget // (None) // @ game+0xffffc21fdf830041
};

// Class DungeonCrawler.GA_InteractPassive
// Size: 0x620 (Inherited: 0x570)
struct UGA_InteractPassive : UGA_StoppablePassiveBase {
	char pad_570[0x8]; // 0x570(0x08)
	struct FPrimaryAssetId InteractionRangeConstant; // 0x578(0x10)
	struct FPrimaryAssetId InteractionAdditionalSphereRadiusConstant; // 0x588(0x10)
	struct ADCGATA_LineTraceInteractable* TargetActor; // 0x598(0x08)
	struct UDCAT_WaitInteractableTarget* WaitInteractableTargetTask; // 0x5a0(0x08)
	struct FGameplayAbilityTargetDataHandle CurrentTargetData; // 0x5a8(0x28)
	struct TMap<struct FGameplayTag, struct FInteractionData> CurrentInteractableDatas; // 0x5d0(0x50)

	void RefreshInteractionData(); // Function DungeonCrawler.GA_InteractPassive.RefreshInteractionData // (None) // @ game+0xffffc266df830041
};

// Class DungeonCrawler.GA_ItemActivateBase
// Size: 0x558 (Inherited: 0x558)
struct UGA_ItemActivateBase : UDCGameplayAbilityBase {
	struct TArray<struct FDCGameplayEffectContainer> EffectContainerArray; // 0x498(0x10)
	struct TArray<struct FDCGameplayEffectData> OverrideGameplayEffectDataArray; // 0x4a8(0x10)
	struct TArray<struct FActiveGameplayEffectHandle> ActiveEffectHandles; // 0x4b8(0x10)
	struct FGameplayTag IdleAnimSequenceGameplayTag; // 0x4c8(0x08)
	struct UDCMovementModifierContainerData* MovementModifierContainer; // 0x4d0(0x08)
	struct FDesignDataGameplayAbility DesignDataGameplayAbility; // 0x4d8(0x58)
	struct FGameplayTagContainer AppliedMovementModifierTags; // 0x530(0x20)
	bool bIsDefaultMovementModifierApplied; // 0x550(0x01)

	void ReceivedEvent(struct FGameplayTag EventTag, struct FGameplayEventData EventData); // Function DungeonCrawler.GA_ItemActivateBase.ReceivedEvent // (None) // @ game+0xffffc228df830041
};

// Class DungeonCrawler.GA_ItemConsumeBase
// Size: 0x640 (Inherited: 0x558)
struct UGA_ItemConsumeBase : UDCGameplayAbilityBase {
	struct UAnimMontage* PreConsumeMontage; // 0x558(0x08)
	struct UAnimMontage* ConsumeMontage; // 0x560(0x08)
	struct UAnimMontage* PreConsumeMontageOnSourceObject; // 0x568(0x08)
	struct UAnimMontage* ConsumeMontageOnSourceObject; // 0x570(0x08)
	struct FItemData ItemData; // 0x578(0xa0)
	struct FDesignDataItemConsume ItemConsumeData; // 0x618(0x20)
	char pad_638[0x8]; // 0x638(0x08)

	void OnStartSync(); // Function DungeonCrawler.GA_ItemConsumeBase.OnStartSync // (None) // @ game+0xffffc231df830041
};

// Class DungeonCrawler.GA_ItemConsumeDrink
// Size: 0x690 (Inherited: 0x640)
struct UGA_ItemConsumeDrink : UGA_ItemConsumeBase {
	struct TMap<struct FGameplayTag, struct FDCDrinkItemConsumeData> DrinkConsumeDatas; // 0x640(0x50)
};

// Class DungeonCrawler.GA_LobbyEmoteBase
// Size: 0x5a0 (Inherited: 0x558)
struct UGA_LobbyEmoteBase : UDCGameplayAbilityBase {
	struct FLobbyEmoteAnimationSet AnimSetCenter; // 0x558(0x10)
	struct FLobbyEmoteAnimationSet AnimSetLeft; // 0x568(0x10)
	struct FLobbyEmoteAnimationSet AnimSetRight; // 0x578(0x10)
	struct USkeletalMesh* EmoteObjectSkeletalMesh; // 0x588(0x08)
	struct FName TransitionSectionName; // 0x590(0x08)
	char pad_598[0x8]; // 0x598(0x08)

	void ReceivedEvent(struct FGameplayTag EventTag, struct FGameplayEventData EventData); // Function DungeonCrawler.GA_LobbyEmoteBase.ReceivedEvent // (None) // @ game+0xffffc235df830041
};

// Class DungeonCrawler.GA_MeleeAttackBase
// Size: 0x640 (Inherited: 0x558)
struct UGA_MeleeAttackBase : UDCGameplayAbilityBase {
	bool ShouldProduceTargetDataOnServer; // 0x558(0x01)
	char pad_559[0x7]; // 0x559(0x07)
	struct TSoftObjectPtr<UAnimMontage> MontageToPlay; // 0x560(0x30)
	struct UDesignDataAssetMeleeAttack* MeleeAttackData; // 0x590(0x08)
	struct FGameplayTag CameraShakeOnStuckStaticObject; // 0x598(0x08)
	struct FGameplayTag CameraShakeOnStuckCharacter; // 0x5a0(0x08)
	struct FGameplayTag CameraShakeOnStuckShield; // 0x5a8(0x08)
	struct FGameplayTag ChangeCrossHairWhenEventTag; // 0x5b0(0x08)
	float ChangeCrossHairAngle; // 0x5b8(0x04)
	bool OnPinPoint; // 0x5bc(0x01)
	char pad_5BD[0x3]; // 0x5bd(0x03)
	float RotateTime; // 0x5c0(0x04)
	char pad_5C4[0x4]; // 0x5c4(0x04)
	struct ADCGATA_LineCollision* TargetActor; // 0x5c8(0x08)
	struct UDCAT_WaitTargetData* TargetingTask; // 0x5d0(0x08)
	struct UAbilityTask_WaitDelay* OnHitTask; // 0x5d8(0x08)
	struct UAbilityTask_WaitDelay* OnStuckTask; // 0x5e0(0x08)
	char pad_5E8[0x58]; // 0x5e8(0x58)

	void ServerTargetDataReceived(struct FGameplayTag EventTag, struct FGameplayTag InChannelTag, struct FGameplayEventData EventData); // Function DungeonCrawler.GA_MeleeAttackBase.ServerTargetDataReceived // (None) // @ game+0xffffc249df830041
};

// Class DungeonCrawler.GA_MonsterRangedAttackBase
// Size: 0x6a8 (Inherited: 0x5c0)
struct UGA_MonsterRangedAttackBase : UGA_RangedAttackBase {
	struct FGameplayTag CancleGameplayTag; // 0x5c0(0x08)
	enum class EHitBoxType HitBoxType; // 0x5c8(0x01)
	char pad_5C9[0x3]; // 0x5c9(0x03)
	float Range; // 0x5cc(0x04)
	float DefaultFirePower; // 0x5d0(0x04)
	float MinimumDistance; // 0x5d4(0x04)
	int32_t MultiShotCount; // 0x5d8(0x04)
	float MultiShotAngle; // 0x5dc(0x04)
	char pad_5E0[0xc8]; // 0x5e0(0xc8)
};

// Class DungeonCrawler.GA_MonsterChargedRangedAttackBase
// Size: 0x6b8 (Inherited: 0x6a8)
struct UGA_MonsterChargedRangedAttackBase : UGA_MonsterRangedAttackBase {
	struct FGameplayTag NextGameplayTag; // 0x6a8(0x08)
	float FireDelay; // 0x6b0(0x04)
	char pad_6B4[0x4]; // 0x6b4(0x04)
};

// Class DungeonCrawler.GA_MonsterMeleeAttackBase
// Size: 0x650 (Inherited: 0x640)
struct UGA_MonsterMeleeAttackBase : UGA_MeleeAttackBase {
	struct FGameplayTag CancleGameplayTag; // 0x640(0x08)
	struct FName TransitionSectionName; // 0x648(0x08)
};

// Class DungeonCrawler.GA_MultiShotBase
// Size: 0x5c0 (Inherited: 0x5c0)
struct UGA_MultiShotBase : UGA_RangedAttackBase {
	struct UAnimMontage* MontageToPlay; // 0x558(0x08)
	struct UAnimMontage* MontageToPlayOnSourceObject; // 0x560(0x08)
	struct AProjectileActor* ProjectileActorClass; // 0x568(0x08)
	struct FName FireSocketName; // 0x570(0x08)
	float ProjectileSpeedMultiplier; // 0x578(0x04)
	bool IsMultiFireProjectiles; // 0x580(0x01)
	struct UCurveFloat* DamageCurve; // 0x588(0x08)
	bool bNeedsAmmoToActivate; // 0x590(0x01)
	bool bNeedsAmmoToFire; // 0x591(0x01)
	int32_t AmmoUsage; // 0x594(0x04)
	struct FPrimaryAssetId AmmoItemId; // 0x598(0x10)
	bool bPlayPullOnAnimationActivation; // 0x5a8(0x01)
	struct ADCGATA_AimTraceToSocket* SocketTargetActor; // 0x5b0(0x08)

	void InputActionStarted(); // Function DungeonCrawler.GA_MultiShotBase.InputActionStarted // (None) // @ game+0xffffc24bdf830041
};

// Class DungeonCrawler.GA_MusicBase
// Size: 0x610 (Inherited: 0x558)
struct UGA_MusicBase : UDCGameplayAbilityBase {
	struct FGameplayEventData CurrentTriggerData; // 0x558(0xb0)
	struct FGameplayTag GameplayCueTagOnTarget; // 0x608(0x08)

	void OnTargetActorEndOverlap(struct AActor* Target); // Function DungeonCrawler.GA_MusicBase.OnTargetActorEndOverlap // (None) // @ game+0xffffc255df830041
};

// Class DungeonCrawler.GA_PaviseInstall
// Size: 0x588 (Inherited: 0x558)
struct UGA_PaviseInstall : UDCGameplayAbilityBase {
	struct UAnimMontage* MontageToPlay; // 0x558(0x08)
	struct UAnimMontage* MontageToPlayOnSourceObject; // 0x560(0x08)
	struct APavisePropBase* InstalledActorClass; // 0x568(0x08)
	struct FPrimaryAssetId CharacterStopMovementThresholdConstant; // 0x570(0x10)
	char pad_580[0x8]; // 0x580(0x08)

	void ReceivedEvent(struct FGameplayTag EventTag, struct FGameplayEventData EventData); // Function DungeonCrawler.GA_PaviseInstall.ReceivedEvent // (None) // @ game+0xffffc25bdf830041
};

// Class DungeonCrawler.GA_Pickpocket
// Size: 0x558 (Inherited: 0x558)
struct UGA_Pickpocket : UDCGameplayAbilityBase {
	struct TArray<struct FDCGameplayEffectContainer> EffectContainerArray; // 0x498(0x10)
	struct TArray<struct FDCGameplayEffectData> OverrideGameplayEffectDataArray; // 0x4a8(0x10)
	struct TArray<struct FActiveGameplayEffectHandle> ActiveEffectHandles; // 0x4b8(0x10)
	struct FGameplayTag IdleAnimSequenceGameplayTag; // 0x4c8(0x08)
	struct UDCMovementModifierContainerData* MovementModifierContainer; // 0x4d0(0x08)
	struct FDesignDataGameplayAbility DesignDataGameplayAbility; // 0x4d8(0x58)
	struct FGameplayTagContainer AppliedMovementModifierTags; // 0x530(0x20)
	bool bIsDefaultMovementModifierApplied; // 0x550(0x01)
};

// Class DungeonCrawler.GA_PickUp
// Size: 0x568 (Inherited: 0x558)
struct UGA_PickUp : UDCGameplayAbilityBase {
	struct TArray<struct FDCGameplayEffectContainer> EffectContainerArray; // 0x498(0x10)
	struct TArray<struct FDCGameplayEffectData> OverrideGameplayEffectDataArray; // 0x4a8(0x10)
	struct TArray<struct FActiveGameplayEffectHandle> ActiveEffectHandles; // 0x4b8(0x10)
	struct FGameplayTag IdleAnimSequenceGameplayTag; // 0x4c8(0x08)
	struct UDCMovementModifierContainerData* MovementModifierContainer; // 0x4d0(0x08)
	struct FDesignDataGameplayAbility DesignDataGameplayAbility; // 0x4d8(0x58)
	struct FGameplayTagContainer AppliedMovementModifierTags; // 0x530(0x20)
	bool bIsDefaultMovementModifierApplied; // 0x550(0x01)

	void OnStartSync(); // Function DungeonCrawler.GA_PickUp.OnStartSync // (None) // @ game+0xffffc25ddf830041
};

// Class DungeonCrawler.GA_PlayerCharMeleeAttackBase
// Size: 0x688 (Inherited: 0x640)
struct UGA_PlayerCharMeleeAttackBase : UGA_MeleeAttackBase {
	struct FPrimaryAssetId ComboInputQueueConstantTime; // 0x640(0x10)
	char pad_650[0x4]; // 0x650(0x04)
	float ComboInputQueueTime; // 0x654(0x04)
	struct FTimerHandle ComboIACompletedHandle; // 0x658(0x08)
	struct FTimerHandle OtherHandIACompletedHandle; // 0x660(0x08)
	struct FTimerHandle AddLooseTagNextTickTimerHandle; // 0x668(0x08)
	struct FGameplayTag ComboTriggerTag; // 0x670(0x08)
	struct FGameplayTag OtherHandTriggerEventTag; // 0x678(0x08)
	struct FGameplayTag OtherHandEnablingEventTag; // 0x680(0x08)

	void OtherHandIAStarted(); // Function DungeonCrawler.GA_PlayerCharMeleeAttackBase.OtherHandIAStarted // (None) // @ game+0xffffc263df830041
};

// Class DungeonCrawler.GA_PlayerMagicWandUseBase
// Size: 0x770 (Inherited: 0x558)
struct UGA_PlayerMagicWandUseBase : UDCGameplayAbilityBase {
	struct UAnimMontage* MontageToPlayOnCasting; // 0x558(0x08)
	struct UAnimMontage* MontageToPlayOnChanneling; // 0x560(0x08)
	struct UAnimMontage* MontageToPlayOnInstant; // 0x568(0x08)
	struct UAnimMontage* MontageToPlayOnCastingSourceObject; // 0x570(0x08)
	struct UAnimMontage* MontageToPlayOnChannelingSourceObject; // 0x578(0x08)
	struct UAnimMontage* MontageToPlayOnInstantSourceObject; // 0x580(0x08)
	float StuckPlayRate; // 0x588(0x04)
	float StuckPlayRateDuration; // 0x58c(0x04)
	float StuckBlendOutTime; // 0x590(0x04)
	struct FName FireSocketName; // 0x594(0x08)
	char pad_59C[0x4]; // 0x59c(0x04)
	struct ADCGATA_LineCollision* TargetActor; // 0x5a0(0x08)
	struct UAbilityTask_Repeat* ChannelingTask; // 0x5a8(0x08)
	char pad_5B0[0x1c0]; // 0x5b0(0x1c0)

	void ServerReceivedTargetData(struct FGameplayTag InEffectTag, struct FGameplayTag InChannelTag, struct FGameplayAbilityTargetDataHandle& InData); // Function DungeonCrawler.GA_PlayerMagicWandUseBase.ServerReceivedTargetData // (None) // @ game+0xffffc274df830041
};

// Class DungeonCrawler.GA_PlayerMusicPlayBase
// Size: 0x7b0 (Inherited: 0x558)
struct UGA_PlayerMusicPlayBase : UDCGameplayAbilityBase {
	struct UAnimMontage* MontageToPlayOnPlaying; // 0x558(0x08)
	struct UAnimMontage* MontageToPlayOnPlayingSourceObject; // 0x560(0x08)
	struct FPrimaryAssetId JudgementThresholdConstant; // 0x568(0x10)
	struct FPrimaryAssetId PerfectScoreConstant; // 0x578(0x10)
	struct FPrimaryAssetId GoodScoreConstant; // 0x588(0x10)
	struct FPrimaryAssetId BadScoreConstant; // 0x598(0x10)
	struct FPrimaryAssetId PerfectPlayThresholdConstant; // 0x5a8(0x10)
	struct FPrimaryAssetId GoodPlayThresholdConstant; // 0x5b8(0x10)
	struct FPrimaryAssetId BadPlayThresholdConstant; // 0x5c8(0x10)
	char pad_5D8[0xc0]; // 0x5d8(0xc0)
	struct FGameplayCueParameters CurrentCueParams; // 0x698(0xd8)
	struct FRandomStream Stream; // 0x770(0x08)
	char pad_778[0x38]; // 0x778(0x38)

	void ReceivedEvent(struct FGameplayTag EventTag, struct FGameplayEventData EventData); // Function DungeonCrawler.GA_PlayerMusicPlayBase.ReceivedEvent // (None) // @ game+0xffffc282df830041
};

// Class DungeonCrawler.GA_PlayerSkillBase
// Size: 0x668 (Inherited: 0x558)
struct UGA_PlayerSkillBase : UDCGameplayAbilityBase {
	bool bShouldHideEquipmentUntilAbilityEnds; // 0x558(0x01)
	bool bShouldHideEquipmentUntilAnimationEnds; // 0x559(0x01)
	char pad_55A[0x6]; // 0x55a(0x06)
	struct FGameplayTagContainer IgnoreTypes; // 0x560(0x20)
	struct AActor* CurrentSkillActor; // 0x580(0x08)
	struct UAsyncTaskEffectStackChanged* EffectStackAsyncTask; // 0x588(0x08)
	char pad_590[0xd0]; // 0x590(0xd0)
	float SkillMessageDuration; // 0x660(0x04)
	char pad_664[0x4]; // 0x664(0x04)

	void SetEquippedItemsHidden(bool bShouldHide); // Function DungeonCrawler.GA_PlayerSkillBase.SetEquippedItemsHidden // (None) // @ game+0xffffc290df830041
};

// Class DungeonCrawler.GA_PlayerSkillCastBase
// Size: 0x750 (Inherited: 0x668)
struct UGA_PlayerSkillCastBase : UGA_PlayerSkillBase {
	struct UAnimMontage* MontageToPlay; // 0x668(0x08)
	char pad_670[0xe0]; // 0x670(0xe0)

	void OnVelocityChange(); // Function DungeonCrawler.GA_PlayerSkillCastBase.OnVelocityChange // (None) // @ game+0xffffc295df830041
};

// Class DungeonCrawler.GA_PlayerSkillChannelingBase
// Size: 0x768 (Inherited: 0x668)
struct UGA_PlayerSkillChannelingBase : UGA_PlayerSkillBase {
	struct FGameplayTag SkillBuffTag; // 0x668(0x08)
	struct UAnimMontage* MontageToPlay; // 0x670(0x08)
	bool bCanMoveWhileChanneling; // 0x678(0x01)
	char pad_679[0xef]; // 0x679(0xef)

	void ServerOnChannelingAction_BP(struct FGameplayEventData EventData, struct FGameplayCueParameters CueParams); // Function DungeonCrawler.GA_PlayerSkillChannelingBase.ServerOnChannelingAction_BP // (None) // @ game+0xffffc29bdf830041
};

// Class DungeonCrawler.GA_PlayerSkillInstantBase
// Size: 0x670 (Inherited: 0x668)
struct UGA_PlayerSkillInstantBase : UGA_PlayerSkillBase {
	struct UAnimMontage* MontageToPlay; // 0x668(0x08)
};

// Class DungeonCrawler.GA_PlayerSkillInstantAndWaitForEndBase
// Size: 0x678 (Inherited: 0x670)
struct UGA_PlayerSkillInstantAndWaitForEndBase : UGA_PlayerSkillInstantBase {
	struct FGameplayTag SkillBuffTag; // 0x670(0x08)

	void ServerBuffRemoved(); // Function DungeonCrawler.GA_PlayerSkillInstantAndWaitForEndBase.ServerBuffRemoved // (None) // @ game+0xffffc29edf830041
};

// Class DungeonCrawler.GA_PlayerSkillRouterBase
// Size: 0x678 (Inherited: 0x668)
struct UGA_PlayerSkillRouterBase : UGA_PlayerSkillBase {
	struct FGameplayTag RouteTriggerTag; // 0x668(0x08)
	struct FGameplayTag CheckItemWeaponTypeTag; // 0x670(0x08)

	void OnRoutedAbilityEnded(struct FAbilityEndedData& AbilityEndedData); // Function DungeonCrawler.GA_PlayerSkillRouterBase.OnRoutedAbilityEnded // (None) // @ game+0xffffc29fdf830041
};

// Class DungeonCrawler.GA_PlayerSpellCastBase
// Size: 0x790 (Inherited: 0x558)
struct UGA_PlayerSpellCastBase : UDCGameplayAbilityBase {
	struct UAnimMontage* MontageToPlayOnCasting; // 0x558(0x08)
	struct UAnimMontage* MontageToPlayOnChanneling; // 0x560(0x08)
	struct UAnimMontage* MontageToPlayOnInstant; // 0x568(0x08)
	struct UAnimMontage* MontageToPlayOnCastingSourceObject; // 0x570(0x08)
	struct UAnimMontage* MontageToPlayOnChannelingSourceObject; // 0x578(0x08)
	struct UAnimMontage* MontageToPlayOnInstantSourceObject; // 0x580(0x08)
	struct FPrimaryAssetId CharacterStopMovementThresholdConstant; // 0x588(0x10)
	struct FPrimaryAssetId IntenseFocusCastTimeConstant; // 0x598(0x10)
	struct FPrimaryAssetId ArcaneMasteryPerkCastTimeConstant; // 0x5a8(0x10)
	float StuckPlayRate; // 0x5b8(0x04)
	float StuckPlayRateDuration; // 0x5bc(0x04)
	float StuckBlendOutTime; // 0x5c0(0x04)
	struct FName FireSocketName; // 0x5c4(0x08)
	char pad_5CC[0x4]; // 0x5cc(0x04)
	struct ADCGATA_LineCollision* TargetActor; // 0x5d0(0x08)
	struct UAbilityTask_Repeat* ChannelingTask; // 0x5d8(0x08)
	char pad_5E0[0x1b0]; // 0x5e0(0x1b0)

	void SpellFireEvent(); // Function DungeonCrawler.GA_PlayerSpellCastBase.SpellFireEvent // (None) // @ game+0xffffc2badf830041
};

// Class DungeonCrawler.GA_PlayMontageAndWaitForEvent
// Size: 0x560 (Inherited: 0x558)
struct UGA_PlayMontageAndWaitForEvent : UDCGameplayAbilityBase {
	struct UAnimMontage* MontageToPlay; // 0x558(0x08)

	void ReceivedEvent(struct FGameplayTag EventTag, struct FGameplayEventData EventData); // Function DungeonCrawler.GA_PlayMontageAndWaitForEvent.ReceivedEvent // (None) // @ game+0xffffc2bfdf830041
};

// Class DungeonCrawler.GA_ProjectileCollision
// Size: 0x578 (Inherited: 0x558)
struct UGA_ProjectileCollision : UDCGameplayAbilityBase {
	struct ADCGATA_LineCollision* TargetActor; // 0x558(0x08)
	struct FGameplayTag GameplayCueOnStuckStaticObject; // 0x560(0x08)
	struct FGameplayTag GameplayCueOnStuckCharacter; // 0x568(0x08)
	struct FGameplayTag GameplayCueOnStuckShield; // 0x570(0x08)

	void TargetDataReceived(struct FHitResult& Hit); // Function DungeonCrawler.GA_ProjectileCollision.TargetDataReceived // (None) // @ game+0xffffc2c1df830041
};

// Class DungeonCrawler.GA_PropsMeleeAttackBase
// Size: 0x648 (Inherited: 0x640)
struct UGA_PropsMeleeAttackBase : UGA_MeleeAttackBase {
	struct FGameplayTag CancleGameplayTag; // 0x640(0x08)
};

// Class DungeonCrawler.GA_ReloadAmmoBase
// Size: 0x580 (Inherited: 0x558)
struct UGA_ReloadAmmoBase : UDCGameplayAbilityBase {
	struct UAnimMontage* MontageToPlay; // 0x558(0x08)
	struct UAnimMontage* MontageToPlayOnSourceObject; // 0x560(0x08)
	struct FPrimaryAssetId AmmoItemId; // 0x568(0x10)
	char pad_578[0x8]; // 0x578(0x08)

	void ReceivedEvent(struct FGameplayTag EventTag, struct FGameplayEventData EventData); // Function DungeonCrawler.GA_ReloadAmmoBase.ReceivedEvent // (None) // @ game+0xffffc2c8df830041
};

// Class DungeonCrawler.GA_ReversibleChangeIdle
// Size: 0x560 (Inherited: 0x558)
struct UGA_ReversibleChangeIdle : UDCGameplayAbilityBase {
	struct UAnimMontage* MontageToPlay; // 0x558(0x08)

	void OnCompleted(struct FGameplayTag EventTag, struct FGameplayEventData EventData); // Function DungeonCrawler.GA_ReversibleChangeIdle.OnCompleted // (None) // @ game+0xffffc2cbdf830041
};

// Class DungeonCrawler.GA_SequenceDamageBase
// Size: 0x570 (Inherited: 0x558)
struct UGA_SequenceDamageBase : UDCGameplayAbilityBase {
	struct AActor* TargetActorClass; // 0x558(0x08)
	bool bUsePremadeSpec; // 0x560(0x01)
	char pad_561[0x3]; // 0x561(0x03)
	struct FGameplayCueTag GameplayCueTag; // 0x564(0x08)
	char pad_56C[0x4]; // 0x56c(0x04)

	void OnDamageOverlapEnd(struct UPrimitiveComponent* OverlappedComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function DungeonCrawler.GA_SequenceDamageBase.OnDamageOverlapEnd // (None) // @ game+0xffffc2cfdf830041
};

// Class DungeonCrawler.GA_SpellBase
// Size: 0x628 (Inherited: 0x558)
struct UGA_SpellBase : UDCGameplayAbilityBase {
	struct FGameplayEventData CurrentTriggerData; // 0x558(0xb0)
	struct FGameplayTag EffectContainerTag; // 0x608(0x08)
	struct FGameplayTag GameplayCueTag; // 0x610(0x08)
	struct FPrimaryAssetId SphereAimRadiusConstant; // 0x618(0x10)

	void OnCasted(struct AActor* InTarget); // Function DungeonCrawler.GA_SpellBase.OnCasted // (None) // @ game+0xffffc2d9df830041
};

// Class DungeonCrawler.GA_WearBase
// Size: 0x608 (Inherited: 0x558)
struct UGA_WearBase : UDCGameplayAbilityBase {
	struct UAnimMontage* ChangingMontage; // 0x558(0x08)
	struct FItemData TargetItemData; // 0x560(0xa0)
	struct TWeakObjectPtr<struct AActor> TargetActor; // 0x600(0x08)

	void OnStartSync(); // Function DungeonCrawler.GA_WearBase.OnStartSync // (None) // @ game+0xffffc2dfdf830041
};

// Class DungeonCrawler.GiftCodeEditableText
// Size: 0x500 (Inherited: 0x4e0)
struct UGiftCodeEditableText : UEditableText {
	char pad_4E0[0x18]; // 0x4e0(0x18)
	int32_t Index; // 0x4f8(0x04)
	char pad_4FC[0x4]; // 0x4fc(0x04)

	void OnGiftCodeWipedEvent__DelegateSignature(int32_t& Index); // DelegateFunction DungeonCrawler.GiftCodeEditableText.OnGiftCodeWipedEvent__DelegateSignature // (None) // @ game+0xffff9835df830041
};

// Class DungeonCrawler.GiftCodePopupBase
// Size: 0x488 (Inherited: 0x440)
struct UGiftCodePopupBase : UCommonPopupBase {
	struct UGiftCodeEditableText* EnterCode_2; // 0x440(0x08)
	struct UGiftCodeEditableText* EnterCode_3; // 0x448(0x08)
	struct UGiftCodeEditableText* EnterCode_4; // 0x450(0x08)
	struct UGiftCodeEditableText* EnterCode_5; // 0x458(0x08)
	struct UCommonButtonPopupWidget* Btn_Two_Close; // 0x460(0x08)
	struct UCommonButtonPopupWidget* Btn_Two_Accept; // 0x468(0x08)
	char pad_470[0x8]; // 0x470(0x08)
	struct TArray<struct UGiftCodeEditableText*> EnterCodeList; // 0x478(0x10)

	void MoveToPrevCodeBlock(int32_t& InCodeBlockIndex); // Function DungeonCrawler.GiftCodePopupBase.MoveToPrevCodeBlock // (None) // @ game+0xffffc2e1df830041
};

// Class DungeonCrawler.DCGlitterComponent
// Size: 0x128 (Inherited: 0xa0)
struct UDCGlitterComponent : UActorComponent {
	char pad_A0[0x58]; // 0xa0(0x58)
	float DurationSeconds; // 0xf8(0x04)
	float IntervalSeconds; // 0xfc(0x04)
	float StartPos; // 0x100(0x04)
	bool bIsEnabled; // 0x104(0x01)
	char pad_105[0x3]; // 0x105(0x03)
	struct TArray<struct UMaterialInstanceDynamic*> DynamicMaterials; // 0x108(0x10)
	char pad_118[0x10]; // 0x118(0x10)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.DCGlitterComponent.UnbindMsgAll // (None) // @ game+0xffffc2e5df830041
};

// Class DungeonCrawler.GlobalData
// Size: 0x88 (Inherited: 0x38)
struct UGlobalData : UDCDataAssetBase {
	struct TMap<struct FGameplayTag, struct FText> AttackTypeTextMap; // 0x38(0x50)

	struct FText GetAttackTypeText(struct FGameplayTag AttackType); // Function DungeonCrawler.GlobalData.GetAttackTypeText // (None) // @ game+0xffffc2e6df830041
};

// Class DungeonCrawler.MonsterSpawnableInterface
// Size: 0x28 (Inherited: 0x28)
struct UMonsterSpawnableInterface : UInterface {

	struct ADCMonsterBase* Spawn(struct ADCMonsterBase* Monster); // Function DungeonCrawler.MonsterSpawnableInterface.Spawn // (None) // @ game+0xffffc2e7df830041
};

// Class DungeonCrawler.ImpactableComponent
// Size: 0x118 (Inherited: 0xa0)
struct UImpactableComponent : UActorComponent {
	char pad_A0[0x58]; // 0xa0(0x58)
	struct FMulticastInlineDelegate ImpactEnduranceExhausted; // 0xf8(0x10)
	struct TArray<struct UTagQueryData*> ImpactableTagQueryArray; // 0x108(0x10)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.ImpactableComponent.UnbindMsgAll // (None) // @ game+0xffffc2eddf830041
};

// Class DungeonCrawler.IMUtilBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UIMUtilBlueprintLibrary : UBlueprintFunctionLibrary {

	struct FText MakeTextwithParam5(struct FText Text, struct FText Param1, struct FText Param2, struct FText Param3, struct FText Param4, struct FText Param5); // Function DungeonCrawler.IMUtilBlueprintLibrary.MakeTextwithParam5 // (None) // @ game+0xffffc2f4df830041
};

// Class DungeonCrawler.InputTriggerComboAction
// Size: 0x68 (Inherited: 0x50)
struct UInputTriggerComboAction : UInputTrigger {
	struct FComboTriggerStep ComboStep; // 0x50(0x10)
	float ActivationCooldown; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
};

// Class DungeonCrawler.InteractableTargetComponent
// Size: 0x168 (Inherited: 0xa0)
struct UInteractableTargetComponent : UActorComponent {
	char pad_A0[0x58]; // 0xa0(0x58)
	struct TMap<struct FGameplayTag, struct FInteractionData> InteractableDataByStateMap; // 0xf8(0x50)
	struct TArray<struct AActor*> Interacters; // 0x148(0x10)
	struct UPrimitiveComponent* CurrentInteractPart; // 0x158(0x08)
	char pad_160[0x8]; // 0x160(0x08)

	void UnregisterInteracter(struct AActor* InteractingActor); // Function DungeonCrawler.InteractableTargetComponent.UnregisterInteracter // (None) // @ game+0xffffc306df830041
};

// Class DungeonCrawler.InteractData
// Size: 0x70 (Inherited: 0x38)
struct UInteractData : UDCDataAssetBase {
	struct UAnimMontage* MontageToPlayBothHandEquipped; // 0x38(0x08)
	struct UAnimMontage* MontageToPlayPrimaryEquipped; // 0x40(0x08)
	struct UAnimMontage* MontageToPlaySecondaryEquipped; // 0x48(0x08)
	struct UAnimMontage* MontageToPlayPrimaryEquippedInstant; // 0x50(0x08)
	struct UAnimMontage* MontageToPlaySecondaryEquippedInstant; // 0x58(0x08)
	struct TArray<struct FGameplayTag> IgnoreTypeArray; // 0x60(0x10)
};

// Class DungeonCrawler.InventoryLootingWidget
// Size: 0x350 (Inherited: 0x300)
struct UInventoryLootingWidget : UDCWidgetBase {
	struct UContainerInventoryGroupWidget* LootingTargetContainerGroup; // 0x300(0x08)
	struct ULootingPlayerInventoryWidget* LootingTargetPlayerInventoryGroup; // 0x308(0x08)
	struct UTextBlock* TargetText; // 0x310(0x08)
	struct FText LootingChestText; // 0x318(0x18)
	struct FText LootingPlayerText; // 0x330(0x18)
	bool bSetLootPlayer; // 0x348(0x01)
	char pad_349[0x3]; // 0x349(0x03)
	int32_t LootingChestCount; // 0x34c(0x04)

	void RequestInventoryWidgetVisible(bool bVisible); // Function DungeonCrawler.InventoryLootingWidget.RequestInventoryWidgetVisible // (None) // @ game+0xffffc309df830041
};

// Class DungeonCrawler.InventoryPerkListWidgetBase
// Size: 0x390 (Inherited: 0x328)
struct UInventoryPerkListWidgetBase : UPerkListWidgetBase {
	struct UPerkWidget* PerkWidgetClass; // 0x328(0x08)
	struct TArray<struct UPanelWidget*> PerkWidgetParentArray; // 0x330(0x10)
	struct TMap<struct UPanelWidget*, struct UPerkWidget*> PerkWidgetMap; // 0x340(0x50)
};

// Class DungeonCrawler.InventorySkillListWidgetBase
// Size: 0x390 (Inherited: 0x328)
struct UInventorySkillListWidgetBase : USkillListWidgetBase {
	struct USkillWidget* SkillWidgetClass; // 0x328(0x08)
	struct TArray<struct UPanelWidget*> SkillWidgetParentArray; // 0x330(0x10)
	struct TMap<struct UPanelWidget*, struct USkillWidget*> SkillWidgetMap; // 0x340(0x50)
};

// Class DungeonCrawler.InventoryStatusWidget
// Size: 0x340 (Inherited: 0x300)
struct UInventoryStatusWidget : UDCWidgetBase {
	struct FInventoryStatusWidgetData WidgetData; // 0x300(0x18)
	struct UAccountLink* AccountLink; // 0x318(0x08)
	struct FString LinkedAccountId; // 0x320(0x10)
	struct FString CheckTargetAccountId; // 0x330(0x10)

	void OnPlayerCharacterName(struct FText& NewValue, struct FText& OldValue); // Function DungeonCrawler.InventoryStatusWidget.OnPlayerCharacterName // (None) // @ game+0xffffc30adf830041
};

// Class DungeonCrawler.InventoryTabWidgetBase
// Size: 0x328 (Inherited: 0x320)
struct UInventoryTabWidgetBase : UDCCommonButtonBase {
	enum class EWidgetPlayerInventoryTabType PlayerInventoryTabType; // 0x320(0x01)
	char pad_321[0x7]; // 0x321(0x07)

	void OnClickedInventoryTab(); // Function DungeonCrawler.InventoryTabWidgetBase.OnClickedInventoryTab // (None) // @ game+0xffffc30cdf830041
};

// Class DungeonCrawler.InvitePartyUserSlotWidget
// Size: 0x3a0 (Inherited: 0x300)
struct UInvitePartyUserSlotWidget : UDCWidgetBase {
	char pad_300[0x10]; // 0x300(0x10)
	struct FString AccountId; // 0x310(0x10)
	struct FString CharacterId; // 0x320(0x10)
	struct FNickname Nickname; // 0x330(0x28)
	struct FText CharacterClassName; // 0x358(0x18)
	int32_t Level; // 0x370(0x04)
	enum class EDCLocationStatus LocationStatus; // 0x374(0x01)
	char pad_375[0x3]; // 0x375(0x03)
	int32_t NumPartyMembers; // 0x378(0x04)
	int32_t MaxNumPartyMembers; // 0x37c(0x04)
	struct UTexture2D* Icon; // 0x380(0x08)
	struct UTexture2D* Portrait; // 0x388(0x08)
	bool bMine; // 0x390(0x01)
	bool bSelected; // 0x391(0x01)
	char pad_392[0xe]; // 0x392(0x0e)

	void OnRightClicked(); // Function DungeonCrawler.InvitePartyUserSlotWidget.OnRightClicked // (None) // @ game+0xffffc30ddf830041
};

// Class DungeonCrawler.InvitePartyMemberSlotWidget
// Size: 0x3a8 (Inherited: 0x3a0)
struct UInvitePartyMemberSlotWidget : UInvitePartyUserSlotWidget {
	struct UVoipUserWidget* VoipUserWidget; // 0x3a0(0x08)
};

// Class DungeonCrawler.InvitePartyUserSlotWidgetData
// Size: 0x180 (Inherited: 0x28)
struct UInvitePartyUserSlotWidgetData : UObject {
	struct FInvitePartyUserSlot InvitePartyUserSlot; // 0x28(0x70)
	struct FPrimaryAssetId CharacterClassId; // 0x98(0x10)
	struct FDesignDataPlayerCharacter DesignDataPlayerCharacter; // 0xa8(0xd0)
	struct UInvitePartyWidget* InvitePartyWidget; // 0x178(0x08)
};

// Class DungeonCrawler.InvitePartyUserSlotListWidgetData
// Size: 0x38 (Inherited: 0x28)
struct UInvitePartyUserSlotListWidgetData : UObject {
	struct FInvitePartyUserSlotData InvitePartyUserSlotData; // 0x28(0x10)
};

// Class DungeonCrawler.InvitePartyWidget
// Size: 0x4f0 (Inherited: 0x300)
struct UInvitePartyWidget : UDCWidgetBase {
	struct UListView* PartySlotListView; // 0x300(0x08)
	struct UTileView* InvitePartySlotTileView; // 0x308(0x08)
	struct UClassIconGroupWidget* ClassIconGroup; // 0x310(0x08)
	int32_t CurrentPageIndex; // 0x318(0x04)
	int32_t MaxCharacterCount; // 0x31c(0x04)
	int32_t MaxPageIndex; // 0x320(0x04)
	char pad_324[0x1c4]; // 0x324(0x1c4)
	struct UDCCommonButtonBase* ButtonShowBlock; // 0x4e8(0x08)

	void TryRequestInviteParty(struct UInvitePartyUserSlotWidgetData* InInvitePartyUserSlotWidgetData); // Function DungeonCrawler.InvitePartyWidget.TryRequestInviteParty // (None) // @ game+0xffffc319df830041
};

// Class DungeonCrawler.Item
// Size: 0x4d0 (Inherited: 0x28)
struct UItem : UObject {
	char pad_28[0x60]; // 0x28(0x60)
	struct UBaseObject* BaseObject; // 0x88(0x08)
	struct FItemInventorySize InventorySize; // 0x90(0x08)
	struct FItemData ItemData; // 0x98(0xa0)
	struct FDesignDataItem ItemDesignData; // 0x138(0x188)
	struct UArtDataItem* ItemArtData; // 0x2c0(0x08)
	struct UDesignDataAssetItemRequirement* DesignDataItemRequirement; // 0x2c8(0x08)
	struct UDesignDataAssetItemBundleInfo* DesignDataItemBundleInfo; // 0x2d0(0x08)
	struct FDesignDataItemContainer DesignDataItemContainer; // 0x2d8(0x14)
	char pad_2EC[0x4]; // 0x2ec(0x04)
	struct USoundData* SoundData; // 0x2f0(0x08)
	struct FFunctionTrigger ItemEquipTrigger; // 0x2f8(0x70)
	struct FFunctionTrigger ChangeAnimSetTrigger; // 0x368(0x70)
	struct FFunctionTrigger ItemSheathTrigger; // 0x3d8(0x70)
	struct TArray<struct FDCGameplayAbilityData> GameplayAbilityDataArray; // 0x448(0x10)
	struct TArray<struct FDCGameplayEffectData> GameplayEffectDataArray; // 0x458(0x10)
	struct TArray<struct FDCGameplayAbilityData> OwnerGameplayAbilityDataArray; // 0x468(0x10)
	struct TArray<struct FDCGameplayEffectData> OwnerGameplayEffectDataArray; // 0x478(0x10)
	struct TArray<struct FDCPropertyEffectData> PropertyEffectDataArray; // 0x488(0x10)
	struct TArray<struct FGameplayAbilitySpecHandle> OwnerGameplayAbilitySpecHandles; // 0x498(0x10)
	struct TArray<struct FActiveGameplayEffectHandle> OwnerGameplayEffectHandles; // 0x4a8(0x10)
	struct TWeakObjectPtr<struct AActor> OwnerActor; // 0x4b8(0x08)
	struct TWeakObjectPtr<struct AItemActor> ItemActor; // 0x4c0(0x08)
	char pad_4C8[0x8]; // 0x4c8(0x08)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.Item.UnbindMsgAll // (None) // @ game+0xffffc329df830041
};

// Class DungeonCrawler.ItemActor
// Size: 0x570 (Inherited: 0x300)
struct AItemActor : ADCAbilityActorBase {
	char pad_300[0x8]; // 0x300(0x08)
	struct USkeletalMeshComponent* Mesh; // 0x308(0x08)
	struct FGameplayTagContainer AttachedInvisibleStateTagContainer; // 0x310(0x20)
	char pad_330[0x188]; // 0x330(0x188)
	struct UDesignDataAssetItemRequirement* DesignDataAssetItemRequirement; // 0x4b8(0x08)
	struct UArtDataItem* ArtDataItem; // 0x4c0(0x08)
	struct USoundData* SoundData; // 0x4c8(0x08)
	struct FItemData ItemData; // 0x4d0(0xa0)

	void SetSheathed(); // Function DungeonCrawler.ItemActor.SetSheathed // (None) // @ game+0xffffc338df830041
};

// Class DungeonCrawler.ItemComponentBase
// Size: 0x100 (Inherited: 0xa0)
struct UItemComponentBase : UActorComponent {
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x30(0x30)
	struct TArray<struct FName> ComponentTags; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	int32_t UCSSerializationIndex; // 0x84(0x04)
	char pad_F4_0 : 3; // 0xf4(0x01)
	char bNetAddressable : 1; // 0x88(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x88(0x01)
	char bReplicates : 1; // 0x88(0x01)
	char bAutoActivate : 1; // 0x8a(0x01)
	char bIsActive : 1; // 0x8a(0x01)
	char pad_F5_0 : 3; // 0xf5(0x01)
	char bEditableWhenInherited : 1; // 0x8a(0x01)
	char pad_F5_4 : 1; // 0xf5(0x01)
	char bCanEverAffectNavigation : 1; // 0x8a(0x01)
	char pad_F5_6 : 1; // 0xf5(0x01)
	char bIsEditorOnly : 1; // 0x8a(0x01)
	enum class EComponentCreationMethod CreationMethod; // 0x8d(0x01)
	struct FMulticastSparseDelegate OnComponentActivated; // 0x8e(0x01)
	struct FMulticastSparseDelegate OnComponentDeactivated; // 0x8f(0x01)
	char pad_F9[0x7]; // 0xf9(0x07)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.ItemComponentBase.UnbindMsgAll // (None) // @ game+0xffffc33ddf830041
};

// Class DungeonCrawler.ItemCountSelectWidgetData
// Size: 0x40 (Inherited: 0x30)
struct UItemCountSelectWidgetData : UPopupDataBase {
	enum class EPopupButtonType PopupButtonType; // 0x30(0x01)
	enum class EItemCountSelectWidgetType ItemCountSelectType; // 0x31(0x01)
	char pad_32[0x2]; // 0x32(0x02)
	int32_t MaxItemCount; // 0x34(0x04)
	int32_t MinItemCount; // 0x38(0x04)
	int32_t SelectedItemCount; // 0x3c(0x04)
};

// Class DungeonCrawler.ItemCountSelectWidget
// Size: 0x478 (Inherited: 0x440)
struct UItemCountSelectWidget : UCommonPopupBase {
	struct UCommonButtonPopupWidget* Btn_Single; // 0x440(0x08)
	struct UCommonButtonPopupWidget* Btn_Two_Left; // 0x448(0x08)
	struct UCommonButtonPopupWidget* Btn_Two_Right; // 0x450(0x08)
	struct USlider* Slider_ItemCount; // 0x458(0x08)
	struct UEditableText* EditableTextBox_ItemCount; // 0x460(0x08)
	struct UTextBlock* Txt_Desc; // 0x468(0x08)
	struct UItemCountSelectWidgetData* ItemCountSelectWidgetData; // 0x470(0x08)

	void OnTextBlockValueChanged(struct FText& Text); // Function DungeonCrawler.ItemCountSelectWidget.OnTextBlockValueChanged // (None) // @ game+0xffffc344df830041
};

// Class DungeonCrawler.DCItemDataComponent
// Size: 0x1b8 (Inherited: 0xd0)
struct UDCItemDataComponent : UDCDataComponent {
	struct FItemData ItemData; // 0xd0(0xa0)
	int32_t ItemCount; // 0x170(0x04)
	char pad_174[0x4]; // 0x174(0x04)
	struct UStaticMeshComponent* StaticMeshComponent; // 0x178(0x08)
	struct USkeletalMeshComponent* SkeletalMeshComponent; // 0x180(0x08)
	char pad_188[0x30]; // 0x188(0x30)

	void OnLoadData_Sound(struct UObject* InLoadedObject); // Function DungeonCrawler.DCItemDataComponent.OnLoadData_Sound // (None) // @ game+0xffffc347df830041
};

// Class DungeonCrawler.ItemGenerateInterface
// Size: 0x28 (Inherited: 0x28)
struct UItemGenerateInterface : UInterface {

	void GenerateItems(float InPrestigeItemDrop); // Function DungeonCrawler.ItemGenerateInterface.GenerateItems // (None) // @ game+0xffffc38adf830041
};

// Class DungeonCrawler.ItemHolderActorBase
// Size: 0x3e0 (Inherited: 0x300)
struct AItemHolderActorBase : ADCInteractableActorBase {
	char pad_300[0x20]; // 0x300(0x20)
	struct UMeshComponent* ItemMeshComponent; // 0x320(0x08)
	struct FPrimaryAssetId ItemId; // 0x328(0x10)
	struct FItemDataMeta ItemMetaData; // 0x338(0x50)
	struct UItem* ItemObject; // 0x388(0x08)
	struct UArtDataItem* ArtDataItem; // 0x390(0x08)
	struct USoundData* SoundData; // 0x398(0x08)
	struct UDCGlitterComponent* GlitterComponent; // 0x3a0(0x08)
	struct FPrimaryAssetId PropInteractId; // 0x3a8(0x10)
	struct FGameplayTagContainer GameplayTagContainer; // 0x3b8(0x20)
	bool bPreview; // 0x3d8(0x01)
	char pad_3D9[0x7]; // 0x3d9(0x07)

	void SetItemObject(struct UItem* Item); // Function DungeonCrawler.ItemHolderActorBase.SetItemObject // (None) // @ game+0xffffc34bdf830041
};

// Class DungeonCrawler.ItemMoveValidatorComponent
// Size: 0x200 (Inherited: 0x100)
struct UItemMoveValidatorComponent : UItemComponentBase {
	struct AActor* MoveItemOldOwner; // 0x100(0x08)
	struct AActor* MoveItemNewOwner; // 0x108(0x08)
	struct FItemData MoveItemOldData; // 0x110(0xa0)
	struct TArray<struct FItemData> MoveItemNewDataArray; // 0x1b0(0x10)
	struct TArray<struct FItemData> SwapItemOldDataArray; // 0x1c0(0x10)
	struct TArray<struct FItemData> SwapItemNewDataArray; // 0x1d0(0x10)
	struct FGameplayTagContainer BlockedTags; // 0x1e0(0x20)

	void ServerMoveItem(struct FItemData OldItemData, struct TArray<struct FItemData> NewItemDataArray, struct AActor* OldOwner, struct AActor* NewOwner, bool bHasDelay); // Function DungeonCrawler.ItemMoveValidatorComponent.ServerMoveItem // (None) // @ game+0xffffc34fdf830041
};

// Class DungeonCrawler.ItemRandomGenerateComponent
// Size: 0x188 (Inherited: 0xa0)
struct UItemRandomGenerateComponent : UActorComponent {
	char pad_A0[0x60]; // 0xa0(0x60)
	struct TArray<struct FItemRandomGenerateData> ItemRandomGenerateDataArray; // 0x100(0x10)
	struct UDesignDataAssetLootDrop* DesignDataAssetLootDrop; // 0x110(0x08)
	struct FDesignDataLootDrop DesignDataLootDrop; // 0x118(0x10)
	int32_t GenerateCount; // 0x128(0x04)
	bool bGenerateAll; // 0x12c(0x01)
	bool bGenerateRepeatedly; // 0x12d(0x01)
	char pad_12E[0x2]; // 0x12e(0x02)
	struct TArray<enum class EItemType> GenerateItemTypeArray; // 0x130(0x10)
	struct FGameplayTagContainer ItemRarityTags; // 0x140(0x20)
	char pad_160[0x10]; // 0x160(0x10)
	struct FMulticastInlineDelegate OnItemGenerationFinished; // 0x170(0x10)
	char pad_180[0x8]; // 0x180(0x08)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.ItemRandomGenerateComponent.UnbindMsgAll // (None) // @ game+0xffffc356df830041
};

// Class DungeonCrawler.ItemRichTextBlockDecorator
// Size: 0x38 (Inherited: 0x28)
struct UItemRichTextBlockDecorator : URichTextBlockDecorator {
	struct UItemTooltipWidget* ItemTooltipWidgetClass; // 0x28(0x08)
	char pad_30[0x8]; // 0x30(0x08)

	struct FTextBlockStyle GetItemTextBlockStyle(struct FGameplayTag InRarityType); // Function DungeonCrawler.ItemRichTextBlockDecorator.GetItemTextBlockStyle // (None) // @ game+0xffffc357df830041
};

// Class DungeonCrawler.ItemTooltipRequirementListEntryWidgetData
// Size: 0x58 (Inherited: 0x28)
struct UItemTooltipRequirementListEntryWidgetData : UObject {
	struct FText RequirementValueText; // 0x28(0x18)
	struct FSlateColor RequirementValueTextColor; // 0x40(0x14)
	char pad_54[0x4]; // 0x54(0x04)
};

// Class DungeonCrawler.ItemTooltipRequirementListWidget
// Size: 0x350 (Inherited: 0x300)
struct UItemTooltipRequirementListWidget : UDCWidgetBase {
	struct TMap<enum class EItemRequirementType, struct UItemTooltipRequirementWidget*> ItemRequirementWidgetMap; // 0x300(0x50)
};

// Class DungeonCrawler.ItemTooltipRequirementWidget
// Size: 0x348 (Inherited: 0x300)
struct UItemTooltipRequirementWidget : UDCWidgetBase {
	char pad_300[0x8]; // 0x300(0x08)
	struct FSlateColor CommonNameColor; // 0x308(0x14)
	struct FSlateColor CommonValueColor; // 0x31c(0x14)
	struct FSlateColor UnmetRequirementColor; // 0x330(0x14)
	char pad_344[0x4]; // 0x344(0x04)

	void OnChangedRequirementStatus(bool bFulfilled); // Function DungeonCrawler.ItemTooltipRequirementWidget.OnChangedRequirementStatus // (None) // @ game+0xffffc358df830041
};

// Class DungeonCrawler.ItemTooltipStatWidgetData
// Size: 0x38 (Inherited: 0x28)
struct UItemTooltipStatWidgetData : UObject {
	struct TArray<struct FText> DescTextArray; // 0x28(0x10)
};

// Class DungeonCrawler.ItemTooltipStatWidget
// Size: 0x308 (Inherited: 0x300)
struct UItemTooltipStatWidget : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)
};

// Class DungeonCrawler.ItemTooltipWidget
// Size: 0x3a0 (Inherited: 0x300)
struct UItemTooltipWidget : UDCWidgetBase {
	struct FItemTooltipWidgetData WidgetData; // 0x300(0xa0)

	void SetItemData(struct FItemData& NewItemData); // Function DungeonCrawler.ItemTooltipWidget.SetItemData // (None) // @ game+0xffffc35bdf830041
};

// Class DungeonCrawler.ItemWeaponAnimInstanceBase
// Size: 0x530 (Inherited: 0x520)
struct UItemWeaponAnimInstanceBase : UDCPlayerCharacterAnimInstanceBase {
	bool bHoldingTwoHandedItem; // 0x468(0x01)
	bool bIsInFirstPersonPerspective; // 0x469(0x01)
	bool bIsResting; // 0x46a(0x01)
	bool bIsMontageLooping; // 0x46b(0x01)
	bool bIsFullbodyAnimating; // 0x46c(0x01)
	bool bIsPrimaryMontagePlaying; // 0x46d(0x01)
	bool bIsSecondaryMontagePlaying; // 0x46e(0x01)
	bool bIsTwoHandedMontagePlaying; // 0x46f(0x01)
	bool bIsSkillMontagePlaying; // 0x470(0x01)
	bool bIsEmotePlaying; // 0x471(0x01)
	struct FLocomotionAnimSet ItemAnimationSet; // 0x478(0x18)
	struct FLocomotionAnimSet SecondaryItemAnimationSet; // 0x490(0x18)
	struct FGameplayTagContainer PrimaryMontageTagContainer; // 0x4a8(0x20)
	struct FGameplayTagContainer SecondaryMontageTagContainer; // 0x4c8(0x20)
	struct FGameplayTagContainer TwoHandedMontageTagContainer; // 0x4e8(0x20)
	struct TArray<struct FName> LoopSectionNames; // 0x508(0x10)

	void OnItemDataUpdated(struct FItemData& ItemData); // Function DungeonCrawler.ItemWeaponAnimInstanceBase.OnItemDataUpdated // (None) // @ game+0xffffc35cdf830041
};

// Class DungeonCrawler.KarmaMemberSlotWidgetBase
// Size: 0x300 (Inherited: 0x300)
struct UKarmaMemberSlotWidgetBase : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)

	void OnFMsgWidgetStreamingModeNotifyBlueprint(struct FMsgWidgetStreamingModeNotify& InMsg); // Function DungeonCrawler.KarmaMemberSlotWidgetBase.OnFMsgWidgetStreamingModeNotifyBlueprint // (None) // @ game+0xffffc35ddf830041
};

// Class DungeonCrawler.KarmaReportWidgetBase
// Size: 0x300 (Inherited: 0x300)
struct UKarmaReportWidgetBase : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)

	void OnFMsgWidgetKarmaReportInfoNotifyBlueprint(struct FMsgWidgetKarmaReportInfoNotify& InMsg); // Function DungeonCrawler.KarmaReportWidgetBase.OnFMsgWidgetKarmaReportInfoNotifyBlueprint // (None) // @ game+0xffffc35fdf830041
};

// Class DungeonCrawler.LeaderBoardClassIconWidgetData
// Size: 0x40 (Inherited: 0x28)
struct ULeaderBoardClassIconWidgetData : UObject {
	int32_t ItemIndex; // 0x28(0x04)
	struct FPrimaryAssetId CharacterClassId; // 0x2c(0x10)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class DungeonCrawler.LeaderBoardRankRecordListWidgetData
// Size: 0x38 (Inherited: 0x28)
struct ULeaderBoardRankRecordListWidgetData : UObject {
	struct FRankData RankData; // 0x28(0x10)
};

// Class DungeonCrawler.LeaderBoardRankRecordListWidget
// Size: 0x320 (Inherited: 0x300)
struct ULeaderBoardRankRecordListWidget : UDCWidgetBase {
	char pad_300[0x8]; // 0x300(0x08)
	struct UListView* RankRecordListView; // 0x308(0x08)
	char pad_310[0x10]; // 0x310(0x10)

	void OnRankData(struct FRankData& NewValue, struct FRankData& OldValue); // Function DungeonCrawler.LeaderBoardRankRecordListWidget.OnRankData // (None) // @ game+0xffffc360df830041
};

// Class DungeonCrawler.LeaderBoardRankRecordMineWidgetData
// Size: 0x80 (Inherited: 0x28)
struct ULeaderBoardRankRecordMineWidgetData : UObject {
	struct FRankRecord RankRecordMineData; // 0x28(0x58)
};

// Class DungeonCrawler.LeaderBoardRankRecordMineWidget
// Size: 0x358 (Inherited: 0x300)
struct ULeaderBoardRankRecordMineWidget : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)
	char pad_308[0x50]; // 0x308(0x50)

	void OnRankRecordMineData(struct FRankRecord& NewValue, struct FRankRecord& OldValue); // Function DungeonCrawler.LeaderBoardRankRecordMineWidget.OnRankRecordMineData // (None) // @ game+0xffffc362df830041
};

// Class DungeonCrawler.LeaderBoardRankRecordWidgetData
// Size: 0xa8 (Inherited: 0x28)
struct ULeaderBoardRankRecordWidgetData : UObject {
	struct FRankRecord RankRecordData; // 0x28(0x58)
	struct FNickname NickNameMine; // 0x80(0x28)
};

// Class DungeonCrawler.LeaderBoardRankRecordWidget
// Size: 0x360 (Inherited: 0x300)
struct ULeaderBoardRankRecordWidget : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)
	char pad_308[0x58]; // 0x308(0x58)

	void OnRankRecordData(struct FRankRecord& NewValue, struct FRankRecord& OldValue); // Function DungeonCrawler.LeaderBoardRankRecordWidget.OnRankRecordData // (None) // @ game+0xffffc365df830041
};

// Class DungeonCrawler.LeaderBoardWidget
// Size: 0x4a0 (Inherited: 0x440)
struct ULeaderBoardWidget : UDCCommonActivatableWidgetBase {
	struct ULeaderBoardRankRecordListWidget* RankRecordListWidget_Gold; // 0x440(0x08)
	struct ULeaderBoardRankRecordMineWidget* RankRecordMineWidget_Gold; // 0x448(0x08)
	struct ULeaderBoardRankRecordListWidget* RankRecordListWidget_Kill; // 0x450(0x08)
	struct ULeaderBoardRankRecordMineWidget* RankRecordMineWidget_Kill; // 0x458(0x08)
	struct ULeaderBoardRankRecordListWidget* RankRecordListWidget_Escape; // 0x460(0x08)
	struct ULeaderBoardRankRecordMineWidget* RankRecordMineWidget_Escape; // 0x468(0x08)
	struct ULeaderBoardRankRecordListWidget* RankRecordListWidget_Adventure; // 0x470(0x08)
	struct ULeaderBoardRankRecordMineWidget* RankRecordMineWidget_Adventure; // 0x478(0x08)
	struct ULeaderBoardRankRecordListWidget* RankRecordListWidget_BossKill_Lich; // 0x480(0x08)
	struct ULeaderBoardRankRecordMineWidget* RankRecordMineWidget_BossKill_Lich; // 0x488(0x08)
	struct ULeaderBoardRankRecordListWidget* RankRecordListWidget_BossKill_GhostKing; // 0x490(0x08)
	struct ULeaderBoardRankRecordMineWidget* RankRecordMineWidget_BossKill_GhostKing; // 0x498(0x08)
};

// Class DungeonCrawler.LoadoutItemWidget
// Size: 0x3d0 (Inherited: 0x3d0)
struct ULoadoutItemWidget : UControllableItemWidget {
	struct UImage* ItemIconImage; // 0x300(0x08)
	struct USizeBox* ItemIconSizeBox; // 0x308(0x08)
	struct TWeakObjectPtr<struct AActor> ItemOwnedActor; // 0x310(0x08)
	float WidgetOriginalSize; // 0x318(0x04)
	struct FItemWidgetData WidgetData; // 0x330(0xa0)
};

// Class DungeonCrawler.LoadoutWidget
// Size: 0x300 (Inherited: 0x300)
struct ULoadoutWidget : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)
};

// Class DungeonCrawler.LobbyGroupTradeChannelWidget
// Size: 0x480 (Inherited: 0x470)
struct ULobbyGroupTradeChannelWidget : ULobbyGroupWidgetBase {
	struct UTopTitleWidgetBase* TopTitle; // 0x470(0x08)
	struct UDCTradeInventoryWidget* TradeUserInventory; // 0x478(0x08)

	void OnReadRulesButtonClicked(); // Function DungeonCrawler.LobbyGroupTradeChannelWidget.OnReadRulesButtonClicked // (None) // @ game+0xffffc367df830041
};

// Class DungeonCrawler.LobbyGroupTradingWidget
// Size: 0x480 (Inherited: 0x470)
struct ULobbyGroupTradingWidget : ULobbyGroupWidgetBase {
	struct UTopTitleWidgetBase* TopTitle; // 0x470(0x08)
	struct UDCTradeInventoryWidget* TradeUserInventory; // 0x478(0x08)

	void OnReadRulesButtonClicked(); // Function DungeonCrawler.LobbyGroupTradingWidget.OnReadRulesButtonClicked // (None) // @ game+0xffffc3abdf830041
};

// Class DungeonCrawler.LobbyWidget
// Size: 0x458 (Inherited: 0x440)
struct ULobbyWidget : UDCCommonActivatableWidgetBase {
	struct FDataTableRowHandle BackInputActionData; // 0x440(0x10)
	char pad_450[0x8]; // 0x450(0x08)

	void OnPlayPartyReadyStateChanged(bool bMine, bool bLeader, bool bReady); // Function DungeonCrawler.LobbyWidget.OnPlayPartyReadyStateChanged // (None) // @ game+0xffffc36ddf830041
};

// Class DungeonCrawler.LoginSecretTokenPopupData
// Size: 0x40 (Inherited: 0x30)
struct ULoginSecretTokenPopupData : UPopupDataBase {
	struct FString SecretToken; // 0x30(0x10)
};

// Class DungeonCrawler.LoginSecretTokenPopup
// Size: 0x458 (Inherited: 0x440)
struct ULoginSecretTokenPopup : UCommonPopupBase {
	struct ULoginSecretTokenPopupData* LoginSecretTokenPopupData; // 0x440(0x08)
	struct UDCCommonButtonBase* Btn_Single; // 0x448(0x08)
	struct UDCCommonButtonBase* Btn_CopyToClipboard; // 0x450(0x08)

	void HandleCopyToClipboardButtonClicked(); // Function DungeonCrawler.LoginSecretTokenPopup.HandleCopyToClipboardButtonClicked // (None) // @ game+0xffffc36fdf830041
};

// Class DungeonCrawler.LoginWidget
// Size: 0x520 (Inherited: 0x440)
struct ULoginWidget : UDCCommonActivatableWidgetBase {
	enum class EDCLoginState LoginState; // 0x440(0x01)
	char pad_441[0x7]; // 0x441(0x07)
	struct UCommonPopupManageWidget* WB_Common_Popup_Manage; // 0x448(0x08)
	struct UCommonPopupSWidget* PopupWidgetClass; // 0x450(0x08)
	struct UCommonPopupSWidget* WB_CommonPopup_S; // 0x458(0x08)
	struct FText WelcomeText; // 0x460(0x18)
	struct FText ConfirmReconnectText; // 0x478(0x18)
	struct FText ConnectText; // 0x490(0x18)
	struct FText PrevGameClosedText; // 0x4a8(0x18)
	struct UComboBoxString* ServerListComboBox; // 0x4c0(0x08)
	struct UOverlay* Overlay_IP; // 0x4c8(0x08)
	struct UOverlay* Overlay_ServerList; // 0x4d0(0x08)
	struct UEditableTextBox* IPTextBox; // 0x4d8(0x08)
	struct UEditableTextBox* IDTextBox; // 0x4e0(0x08)
	struct UEditableTextBox* PasswordTextBox; // 0x4e8(0x08)
	struct UTextBlock* LoginMessage; // 0x4f0(0x08)
	struct FString Password; // 0x4f8(0x10)
	char pad_508[0x18]; // 0x508(0x18)

	void StopLoginSound(); // Function DungeonCrawler.LoginWidget.StopLoginSound // (None) // @ game+0xffffc375df830041
};

// Class DungeonCrawler.LootComponent
// Size: 0x2e8 (Inherited: 0x1e0)
struct ULootComponent : UInventoryComponent {
	struct AActor* LootTargetActor; // 0x1e0(0x08)
	struct FHitResult HitResultTargetData; // 0x1e8(0xe8)
	bool bLootTargetIsPlayer; // 0x2d0(0x01)
	char pad_2D1[0x7]; // 0x2d1(0x07)
	struct FMulticastInlineDelegate OnRemoveLootTarget; // 0x2d8(0x10)

	void ServerRemoveLootTarget(struct UInventoryComponent* InventoryComponent, struct TArray<struct FItemData> InContainingItems); // Function DungeonCrawler.LootComponent.ServerRemoveLootTarget // (None) // @ game+0xffff9849df830041
};

// Class DungeonCrawler.LootingPlayerInventoryWidget
// Size: 0x310 (Inherited: 0x300)
struct ULootingPlayerInventoryWidget : UDCWidgetBase {
	struct FMulticastInlineDelegate OnSetLootTargetPlayer; // 0x300(0x10)
};

// Class DungeonCrawler.MailBoxItemWidgetDataBase
// Size: 0x70 (Inherited: 0x28)
struct UMailBoxItemWidgetDataBase : UObject {
	struct FNickname Nickname; // 0x28(0x28)
	struct FString AccountId; // 0x50(0x10)
	struct FString CharacterId; // 0x60(0x10)
};

// Class DungeonCrawler.MailBoxListWidgetBase
// Size: 0x308 (Inherited: 0x300)
struct UMailBoxListWidgetBase : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)

	void OnPopupSWidgetInvitePartyAnswerResponse(enum class EPopupResult PopupResult, struct FString ReturnAccountID); // Function DungeonCrawler.MailBoxListWidgetBase.OnPopupSWidgetInvitePartyAnswerResponse // (None) // @ game+0xffffc376df830041
};

// Class DungeonCrawler.MailBoxWidgetBase
// Size: 0x308 (Inherited: 0x300)
struct UMailBoxWidgetBase : UDCWidgetBase {
	struct UListView* ListView; // 0x300(0x08)

	void OnSetPartyPrivacy(bool bOn); // Function DungeonCrawler.MailBoxWidgetBase.OnSetPartyPrivacy // (None) // @ game+0xffffc379df830041
};

// Class DungeonCrawler.MetaClassComponent
// Size: 0x128 (Inherited: 0x100)
struct UMetaClassComponent : UMetaComponentBase {
	struct UAccountLink* AccountLink; // 0x100(0x08)
	struct TArray<struct FPrimaryAssetId> SpellIdArray; // 0x108(0x10)
	struct TArray<struct FAccountDataSpell> AccountDataSpellArray; // 0x118(0x10)
};

// Class DungeonCrawler.MetaFriendComponent
// Size: 0x140 (Inherited: 0x100)
struct UMetaFriendComponent : UMetaComponentBase {
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x30(0x30)
	struct TArray<struct FName> ComponentTags; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	int32_t UCSSerializationIndex; // 0x84(0x04)
	char pad_154_0 : 3; // 0x154(0x01)
	char bNetAddressable : 1; // 0x88(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x88(0x01)
	char bReplicates : 1; // 0x88(0x01)
	char bAutoActivate : 1; // 0x8a(0x01)
	char bIsActive : 1; // 0x8a(0x01)
	char pad_155_0 : 3; // 0x155(0x01)
	char bEditableWhenInherited : 1; // 0x8a(0x01)
	char pad_155_4 : 1; // 0x155(0x01)
	char bCanEverAffectNavigation : 1; // 0x8a(0x01)
	char pad_155_6 : 1; // 0x155(0x01)
	char bIsEditorOnly : 1; // 0x8a(0x01)
	enum class EComponentCreationMethod CreationMethod; // 0x8d(0x01)
	struct FMulticastSparseDelegate OnComponentActivated; // 0x8e(0x01)
	struct FMulticastSparseDelegate OnComponentDeactivated; // 0x8f(0x01)
};

// Class DungeonCrawler.MetaInventoryComponent
// Size: 0x1e0 (Inherited: 0x1e0)
struct UMetaInventoryComponent : UInventoryComponent {
	enum class EInventoryType InventoryType; // 0xf8(0x01)
	int32_t MaxHorizontalSlotCount; // 0xfc(0x04)
	int32_t TotalSlotCount; // 0x100(0x04)
	int32_t RowCount; // 0x104(0x04)
	struct TArray<struct FSlotInfo> SlotInfoArray; // 0x108(0x10)
	struct TMap<int32_t, struct FEmptySlotInfoArray> EmptySlotInfoMap; // 0x118(0x50)
	struct TMap<int32_t, struct UItem*> ItemMap; // 0x168(0x50)
	struct TArray<struct FItemData> ContainingItems; // 0x1b8(0x10)
	int64_t TotalGoldCount; // 0x1c8(0x08)
	struct TArray<struct AActor*> LooterArray; // 0x1d0(0x10)

	void OnLobbyCharacterInfoUupdated(); // Function DungeonCrawler.MetaInventoryComponent.OnLobbyCharacterInfoUupdated // (None) // @ game+0xffffc37adf830041
};

// Class DungeonCrawler.MetaItemComponent
// Size: 0x100 (Inherited: 0x100)
struct UMetaItemComponent : UItemComponentBase {
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x30(0x30)
	struct TArray<struct FName> ComponentTags; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	int32_t UCSSerializationIndex; // 0x84(0x04)
	char pad_154_0 : 3; // 0x154(0x01)
	char bNetAddressable : 1; // 0x88(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x88(0x01)
	char bReplicates : 1; // 0x88(0x01)
	char bAutoActivate : 1; // 0x8a(0x01)
	char bIsActive : 1; // 0x8a(0x01)
	char pad_155_0 : 3; // 0x155(0x01)
	char bEditableWhenInherited : 1; // 0x8a(0x01)
	char pad_155_4 : 1; // 0x155(0x01)
	char bCanEverAffectNavigation : 1; // 0x8a(0x01)
	char pad_155_6 : 1; // 0x155(0x01)
	char bIsEditorOnly : 1; // 0x8a(0x01)
	enum class EComponentCreationMethod CreationMethod; // 0x8d(0x01)
	struct FMulticastSparseDelegate OnComponentActivated; // 0x8e(0x01)
	struct FMulticastSparseDelegate OnComponentDeactivated; // 0x8f(0x01)
};

// Class DungeonCrawler.MetaKarmaComponent
// Size: 0x100 (Inherited: 0x100)
struct UMetaKarmaComponent : UMetaComponentBase {
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x30(0x30)
	struct TArray<struct FName> ComponentTags; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	int32_t UCSSerializationIndex; // 0x84(0x04)
	char pad_154_0 : 3; // 0x154(0x01)
	char bNetAddressable : 1; // 0x88(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x88(0x01)
	char bReplicates : 1; // 0x88(0x01)
	char bAutoActivate : 1; // 0x8a(0x01)
	char bIsActive : 1; // 0x8a(0x01)
	char pad_155_0 : 3; // 0x155(0x01)
	char bEditableWhenInherited : 1; // 0x8a(0x01)
	char pad_155_4 : 1; // 0x155(0x01)
	char bCanEverAffectNavigation : 1; // 0x8a(0x01)
	char pad_155_6 : 1; // 0x155(0x01)
	char bIsEditorOnly : 1; // 0x8a(0x01)
	enum class EComponentCreationMethod CreationMethod; // 0x8d(0x01)
	struct FMulticastSparseDelegate OnComponentActivated; // 0x8e(0x01)
	struct FMulticastSparseDelegate OnComponentDeactivated; // 0x8f(0x01)
};

// Class DungeonCrawler.MetaLeaderBoardComponent
// Size: 0x120 (Inherited: 0x100)
struct UMetaLeaderBoardComponent : UMetaComponentBase {
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x30(0x30)
	struct TArray<struct FName> ComponentTags; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	int32_t UCSSerializationIndex; // 0x84(0x04)
	char pad_154_0 : 3; // 0x154(0x01)
	char bNetAddressable : 1; // 0x88(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x88(0x01)
	char bReplicates : 1; // 0x88(0x01)
	char bAutoActivate : 1; // 0x8a(0x01)
	char bIsActive : 1; // 0x8a(0x01)
	char pad_155_0 : 3; // 0x155(0x01)
	char bEditableWhenInherited : 1; // 0x8a(0x01)
	char pad_155_4 : 1; // 0x155(0x01)
	char bCanEverAffectNavigation : 1; // 0x8a(0x01)
	char pad_155_6 : 1; // 0x155(0x01)
	char bIsEditorOnly : 1; // 0x8a(0x01)
	enum class EComponentCreationMethod CreationMethod; // 0x8d(0x01)
	struct FMulticastSparseDelegate OnComponentActivated; // 0x8e(0x01)
	struct FMulticastSparseDelegate OnComponentDeactivated; // 0x8f(0x01)
};

// Class DungeonCrawler.MetaPartyInterface
// Size: 0x28 (Inherited: 0x28)
struct UMetaPartyInterface : UInterface {
};

// Class DungeonCrawler.MetaPlayComponent
// Size: 0x170 (Inherited: 0x100)
struct UMetaPlayComponent : UMetaComponentBase {
	char pad_100[0x20]; // 0x100(0x20)
	struct TMap<enum class EWidgetPartyUserLocate, struct ADCCharacterLobbyCapture*> CharacterLobbyCaptureMap; // 0x120(0x50)

	void OnRecruitBegin(); // Function DungeonCrawler.MetaPlayComponent.OnRecruitBegin // (None) // @ game+0xffffc37bdf830041
};

// Class DungeonCrawler.MetaStorageComponent
// Size: 0x1e0 (Inherited: 0x1e0)
struct UMetaStorageComponent : UInventoryComponent {
	enum class EInventoryType InventoryType; // 0xf8(0x01)
	int32_t MaxHorizontalSlotCount; // 0xfc(0x04)
	int32_t TotalSlotCount; // 0x100(0x04)
	int32_t RowCount; // 0x104(0x04)
	struct TArray<struct FSlotInfo> SlotInfoArray; // 0x108(0x10)
	struct TMap<int32_t, struct FEmptySlotInfoArray> EmptySlotInfoMap; // 0x118(0x50)
	struct TMap<int32_t, struct UItem*> ItemMap; // 0x168(0x50)
	struct TArray<struct FItemData> ContainingItems; // 0x1b8(0x10)
	int64_t TotalGoldCount; // 0x1c8(0x08)
	struct TArray<struct AActor*> LooterArray; // 0x1d0(0x10)

	void OnLobbyCharacterInfoUupdated(); // Function DungeonCrawler.MetaStorageComponent.OnLobbyCharacterInfoUupdated // (None) // @ game+0xffffc37cdf830041
};

// Class DungeonCrawler.MetaVoipComponent
// Size: 0x268 (Inherited: 0x1f8)
struct UMetaVoipComponent : UDCVoipComponent {
	char pad_1F8[0x20]; // 0x1f8(0x20)
	struct TMap<struct FDCAccountId, struct FMetaBindAccountUserData> MetaBindAccountUserDataMap; // 0x218(0x50)
};

// Class DungeonCrawler.MetaVoipInterface
// Size: 0x28 (Inherited: 0x28)
struct UMetaVoipInterface : UInterface {
};

// Class DungeonCrawler.MiniMapData
// Size: 0x88 (Inherited: 0x38)
struct UMiniMapData : UDCDataAssetBase {
	struct TMap<struct FString, struct FDCMiniMapDataContainer> MiniMapData; // 0x38(0x50)
};

// Class DungeonCrawler.MusicActor
// Size: 0x3d8 (Inherited: 0x2f0)
struct AMusicActor : ADCActorBase {
	char pad_2F0[0xb0]; // 0x2f0(0xb0)
	struct FMusicData MusicData; // 0x3a0(0x1c)
	char pad_3BC[0x4]; // 0x3bc(0x04)
	struct UArtDataMusic* ArtDataMusic; // 0x3c0(0x08)
	struct USoundData* SoundData; // 0x3c8(0x08)
	struct UPlayMusicData* PlayMusicData; // 0x3d0(0x08)

	void SetMusicData(struct FMusicData& NewMusicData); // Function DungeonCrawler.MusicActor.SetMusicData // (None) // @ game+0xffffc383df830041
};

// Class DungeonCrawler.MusicComponent
// Size: 0x128 (Inherited: 0xa0)
struct UMusicComponent : UActorComponent {
	char pad_A0[0x70]; // 0xa0(0x70)
	struct TArray<struct AMusicActor*> MusicActors; // 0x110(0x10)
	char pad_120[0x8]; // 0x120(0x08)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.MusicComponent.UnbindMsgAll // (None) // @ game+0xffffc38ddf830041
};

// Class DungeonCrawler.NickNameWidgetBase
// Size: 0x338 (Inherited: 0x300)
struct UNickNameWidgetBase : UDCWidgetBase {
	struct FNickNameWidgetData WidgetData; // 0x300(0x10)
	char pad_310[0x28]; // 0x310(0x28)

	void SetNickName(struct FNickname& InNickName); // Function DungeonCrawler.NickNameWidgetBase.SetNickName // (None) // @ game+0xffffc38fdf830041
};

// Class DungeonCrawler.OnlineSystemEpic
// Size: 0xa0 (Inherited: 0x30)
struct UOnlineSystemEpic : UGameInstanceSubsystem {
	char pad_30[0x70]; // 0x30(0x70)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.OnlineSystemEpic.UnbindMsgAll // (None) // @ game+0xffffc393df830041
};

// Class DungeonCrawler.OnlineSystemIronmace
// Size: 0x88 (Inherited: 0x30)
struct UOnlineSystemIronmace : UGameInstanceSubsystem {
	char pad_30[0x58]; // 0x30(0x58)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.OnlineSystemIronmace.UnbindMsgAll // (None) // @ game+0xffffc397df830041
};

// Class DungeonCrawler.OnlineSystemSteam
// Size: 0xa0 (Inherited: 0x30)
struct UOnlineSystemSteam : UGameInstanceSubsystem {
	char pad_30[0x70]; // 0x30(0x70)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.OnlineSystemSteam.UnbindMsgAll // (None) // @ game+0xffffc39bdf830041
};

// Class DungeonCrawler.PartyChatWidget
// Size: 0x450 (Inherited: 0x408)
struct UPartyChatWidget : UChatSetWidgetBase {
	struct FPartyChatWidgetData WidgetData; // 0x408(0x48)

	void OnChatAccountData(struct FChatAccountData& NewItemData, struct FChatAccountData& OldItemData); // Function DungeonCrawler.PartyChatWidget.OnChatAccountData // (None) // @ game+0xffffc39cdf830041
};

// Class DungeonCrawler.PartySession
// Size: 0xa8 (Inherited: 0x28)
struct UPartySession : UObject {
	char pad_28[0x58]; // 0x28(0x58)
	struct UBaseObject* BaseObject; // 0x80(0x08)
	char pad_88[0x20]; // 0x88(0x20)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.PartySession.UnbindMsgAll // (None) // @ game+0xffffc3a0df830041
};

// Class DungeonCrawler.PavisePropBase
// Size: 0x3d0 (Inherited: 0x3c0)
struct APavisePropBase : APropsActorBase {
	struct AItemHolderActorBase* ItemHolderClassToSpawn; // 0x3c0(0x08)
	float PushingForce; // 0x3c8(0x04)
	char pad_3CC[0x4]; // 0x3cc(0x04)
};

// Class DungeonCrawler.PerkWidget
// Size: 0x350 (Inherited: 0x300)
struct UPerkWidget : UDCWidgetBase {
	struct UImage* PerkIconImage; // 0x300(0x08)
	struct FPerkWidgetData PerkWidgetData; // 0x308(0x30)
	struct UUserWidget* PerkToolTipWidgetClass; // 0x338(0x08)
	struct FPrimaryAssetId PerkId; // 0x340(0x10)

	void SetPerkData(struct FText& PerkName, struct FText& PerkDesc); // Function DungeonCrawler.PerkWidget.SetPerkData // (None) // @ game+0xffffc3a3df830041
};

// Class DungeonCrawler.PlayerCharacterCaptureActor
// Size: 0x418 (Inherited: 0x2f0)
struct APlayerCharacterCaptureActor : ADCActorBase {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	struct FDCAccountId TargetAccount; // 0x2f8(0x10)
	struct ADCPlayerCharacterBase* TargetPlayerCharacter; // 0x308(0x08)
	struct USceneComponent* RootSceneComponent; // 0x310(0x08)
	struct USkeletalMeshComponent* Mesh; // 0x318(0x08)
	struct USkeletalMeshComponent* PartHead; // 0x320(0x08)
	struct USkeletalMeshComponent* PartHelmet; // 0x328(0x08)
	struct USkeletalMeshComponent* PartGloves; // 0x330(0x08)
	struct USkeletalMeshComponent* PartChest; // 0x338(0x08)
	struct USkeletalMeshComponent* PartPants; // 0x340(0x08)
	struct USkeletalMeshComponent* PartBoots; // 0x348(0x08)
	struct USkeletalMeshComponent* PartBack; // 0x350(0x08)
	struct UAnimationAsset* DefaultIdleAnimation; // 0x358(0x08)
	float StartRotateLocation; // 0x360(0x04)
	char pad_364[0x4]; // 0x364(0x04)
	struct UAbilitySystemComponent* AbilitySystemComponent; // 0x368(0x08)
	struct UAnimationAsset* ItemStandIdleAnimation; // 0x370(0x08)
	struct UAccountLink* AccountLink; // 0x378(0x08)
	struct FString LinkedAccountId; // 0x380(0x10)
	struct FString CheckTargetAccountId; // 0x390(0x10)
	struct TWeakObjectPtr<struct UEquipmentInventoryComponent> CapturedEquipmentComponent; // 0x3a0(0x08)
	struct UDCCharacterDataComponent* DataComponent; // 0x3a8(0x08)
	struct UDCCharacterPartsComponent* PartsComponent; // 0x3b0(0x08)
	struct TMap<int64_t, struct AActor*> ContainingActorMap; // 0x3b8(0x50)
	char pad_408[0x10]; // 0x408(0x10)

	void SetStartRotateLocation(float InStartPosition); // Function DungeonCrawler.PlayerCharacterCaptureActor.SetStartRotateLocation // (None) // @ game+0xffffc3a8df830041
};

// Class DungeonCrawler.PlayMusicData
// Size: 0x68 (Inherited: 0x38)
struct UPlayMusicData : UDCDataAssetBase {
	struct UAkAudioEvent* AkEvent; // 0x38(0x08)
	struct UAkAudioEvent* AkStopEvent; // 0x40(0x08)
	struct TArray<struct FDCPlayMusicDataContainer> PlayMusicDatas; // 0x48(0x10)
	struct TArray<struct FDCPlayMusicDataContainer> ChannelingPlayMusicDatas; // 0x58(0x10)
};

// Class DungeonCrawler.PlayWidget
// Size: 0x508 (Inherited: 0x440)
struct UPlayWidget : UDCCommonActivatableWidgetBase {
	char pad_440[0x10]; // 0x440(0x10)
	struct FLobbyCharacterInfo LobbyCharacterData; // 0x450(0x90)
	struct UAccountLink* AccountLink; // 0x4e0(0x08)
	struct UCommonPopupSWidget* WB_CommonPopup_S; // 0x4e8(0x08)
	char pad_4F0[0x10]; // 0x4f0(0x10)
	struct UDCReportPlayerResultPopup* ReportPlayerResultPopupClass; // 0x500(0x08)

	void OnUpdateLobbyCharacterData(struct FLobbyCharacterInfo& LobbyInfo); // Function DungeonCrawler.PlayWidget.OnUpdateLobbyCharacterData // (None) // @ game+0xffffc3c1df830041
};

// Class DungeonCrawler.ProjectileActor
// Size: 0x690 (Inherited: 0x300)
struct AProjectileActor : ADCAbilityActorBase {
	char pad_300[0x18]; // 0x300(0x18)
	struct USkeletalMeshComponent* Mesh; // 0x318(0x08)
	struct UProjectileMovementComponent* ProjectileMovement; // 0x320(0x08)
	bool bIsHomingProjectile; // 0x328(0x01)
	char pad_329[0x3]; // 0x329(0x03)
	float HomingMagnitude; // 0x32c(0x04)
	float GravityScale; // 0x330(0x04)
	char pad_334[0x4]; // 0x334(0x04)
	struct USceneComponent* HomingTargetComponent; // 0x338(0x08)
	struct USceneComponent* OldHomingTargetComponent; // 0x340(0x08)
	char pad_348[0x8]; // 0x348(0x08)
	struct FVector ProjectileMovementComponentLocalVelocity; // 0x350(0x18)
	struct FVector ProjectileMovementComponentVelocity; // 0x368(0x18)
	struct UDesignDataAssetProjectile* DesignDataAssetProjectile; // 0x380(0x08)
	int32_t PierceCount; // 0x388(0x04)
	bool IsObstaclePierce; // 0x38c(0x01)
	char pad_38D[0x3]; // 0x38d(0x03)
	int32_t ObstaclePierceDecrease; // 0x390(0x04)
	float LifeTime; // 0x394(0x04)
	struct TArray<struct FGameplayTag> AbilityTriggerTagsWhenLifeTimeExpired; // 0x398(0x10)
	char pad_3A8[0x8]; // 0x3a8(0x08)
	struct TArray<struct FPrimaryAssetId> AddEffectToTargetHit; // 0x3b0(0x10)
	struct TArray<struct FPrimaryAssetId> AddEffectToGroundHit; // 0x3c0(0x10)
	struct FTransform SpawnTransform; // 0x3d0(0x60)
	struct FItemData ProjectileItemData; // 0x430(0xa0)
	struct FItemData AmmoItemData; // 0x4d0(0xa0)
	struct UCurveFloat* AccelerationCurve; // 0x570(0x08)
	float StartTime_AccelTimeline; // 0x578(0x04)
	float PlayRate_AccelTimeline; // 0x57c(0x04)
	bool IsLoop_AccelTimeline; // 0x580(0x01)
	char pad_581[0x7]; // 0x581(0x07)
	struct FTimeline AccelrationTimeline; // 0x588(0x98)
	struct USoundData* SoundData; // 0x620(0x08)
	struct TArray<struct FGameplayAbilitySpecHandle> GameplayAbilitySpecHandles; // 0x628(0x10)
	struct TArray<struct FActiveGameplayEffectHandle> GameplayEffectHandles; // 0x638(0x10)
	char pad_648[0x20]; // 0x648(0x20)
	bool bShouldAttachWhenHitCharacter; // 0x668(0x01)
	bool bShouldAttachWhenHitShield; // 0x669(0x01)
	bool bShouldAttachWhenHitStaticObject; // 0x66a(0x01)
	bool bShouldAliveAfterHit; // 0x66b(0x01)
	char pad_66C[0x24]; // 0x66c(0x24)

	void StopPierce(); // Function DungeonCrawler.ProjectileActor.StopPierce // (None) // @ game+0xffffc3dadf830041
};

// Class DungeonCrawler.DCPropDataComponent
// Size: 0xd0 (Inherited: 0xd0)
struct UDCPropDataComponent : UDCDataComponent {
	struct FPrimaryAssetId AssetId; // 0xb8(0x10)
	struct UDCDataAssetBase* DataAsset; // 0xc8(0x08)
};

// Class DungeonCrawler.DCReportSystem
// Size: 0x88 (Inherited: 0x28)
struct UDCReportSystem : UObject {
	char pad_28[0x58]; // 0x28(0x58)
	struct USentrySubsystem* SentrySubsystem; // 0x80(0x08)
};

// Class DungeonCrawler.SampleSubObject
// Size: 0x80 (Inherited: 0x28)
struct USampleSubObject : UObject {
	char pad_28[0x58]; // 0x28(0x58)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.SampleSubObject.UnbindMsgAll // (None) // @ game+0xffffc3e0df830041
};

// Class DungeonCrawler.SampleObject
// Size: 0x98 (Inherited: 0x28)
struct USampleObject : UObject {
	char pad_28[0x58]; // 0x28(0x58)
	struct UBaseObject* BaseObject; // 0x80(0x08)
	struct USampleSubObject* SampleSubObjectClass; // 0x88(0x08)
	struct USampleSubObject* SampleSubObject; // 0x90(0x08)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.SampleObject.UnbindMsgAll // (None) // @ game+0xffffc3e6df830041
};

// Class DungeonCrawler.ServerAccountSubsystem
// Size: 0x170 (Inherited: 0x30)
struct UServerAccountSubsystem : UGameInstanceSubsystem {
	char pad_30[0xc8]; // 0x30(0xc8)
	struct FStartGameSessionState StartGameSessionState; // 0xf8(0x01)
	char pad_F9[0x3]; // 0xf9(0x03)
	struct FProcessTerminateState ProcessTerminateState; // 0xfc(0x08)
	struct FHealthCheckState HealthCheckState; // 0x104(0x01)
	char pad_105[0x6b]; // 0x105(0x6b)

	void UnbindMsgAll(struct UObject* InObject); // Function DungeonCrawler.ServerAccountSubsystem.UnbindMsgAll // (None) // @ game+0xffffc3eadf830041
};

// Class DungeonCrawler.SkeletalMeshItemHolderActor
// Size: 0x3e0 (Inherited: 0x3e0)
struct ASkeletalMeshItemHolderActor : AItemHolderActorBase {
	struct UMeshComponent* ItemMeshComponent; // 0x320(0x08)
	struct FPrimaryAssetId ItemId; // 0x328(0x10)
	struct FItemDataMeta ItemMetaData; // 0x338(0x50)
	struct UItem* ItemObject; // 0x388(0x08)
	struct UArtDataItem* ArtDataItem; // 0x390(0x08)
	struct USoundData* SoundData; // 0x398(0x08)
	struct UDCGlitterComponent* GlitterComponent; // 0x3a0(0x08)
	struct FPrimaryAssetId PropInteractId; // 0x3a8(0x10)
	struct FGameplayTagContainer GameplayTagContainer; // 0x3b8(0x20)
	bool bPreview; // 0x3d8(0x01)
};

// Class DungeonCrawler.SkillActor
// Size: 0x3f8 (Inherited: 0x2f0)
struct ASkillActor : ADCActorBase {
	char pad_2F0[0x8]; // 0x2f0(0x08)
	struct FSkillData SkillData; // 0x2f8(0x30)
	char pad_328[0xc0]; // 0x328(0xc0)
	struct UArtDataSkill* ArtDataSkill; // 0x3e8(0x08)
	struct USoundData* SoundData; // 0x3f0(0x08)

	bool UpdateSkillCount(int32_t DeltaCount); // Function DungeonCrawler.SkillActor.UpdateSkillCount // (None) // @ game+0xffffc3f2df830041
};

// Class DungeonCrawler.SkillComponent
// Size: 0x158 (Inherited: 0xa0)
struct USkillComponent : UActorComponent {
	char pad_A0[0x58]; // 0xa0(0x58)
	struct TArray<struct ASkillActor*> SkillActors; // 0xf8(0x10)
	struct TArray<struct FSkillDataInfo> CurSkillDataList; // 0x108(0x10)
	struct FPrimaryAssetId CharacterStopMovementThresholdConstant; // 0x118(0x10)
	struct FPrimaryAssetId SphereAimRadiusConstant; // 0x128(0x10)
	struct FPrimaryAssetId SkillRequiredRechargeAmountPerTierConstant; // 0x138(0x10)
	char pad_148[0x8]; // 0x148(0x08)
	struct UAsyncTaskEffectStackChanged* EffectStackAsyncTask; // 0x150(0x08)

	bool UpdateSkillCount(struct FGameplayTag SkillTag, int32_t Count); // Function DungeonCrawler.SkillComponent.UpdateSkillCount // (None) // @ game+0xffffc403df830041
};

// Class DungeonCrawler.SkillWidget
// Size: 0x350 (Inherited: 0x300)
struct USkillWidget : UDCWidgetBase {
	struct UImage* SkillIconImage; // 0x300(0x08)
	struct FSkillWidgetData SkillWidgetData; // 0x308(0x30)
	struct UUserWidget* SkillToolTipWidgetClass; // 0x338(0x08)
	struct FPrimaryAssetId SkillId; // 0x340(0x10)

	void SetSkillData(struct FText& SkillName, struct FText& SkillDesc); // Function DungeonCrawler.SkillWidget.SetSkillData // (None) // @ game+0xffffc406df830041
};

// Class DungeonCrawler.SoundBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct USoundBlueprintLibrary : UBlueprintFunctionLibrary {

	bool SetSwitch(struct UObject* InSoundPlayer, struct UAkSwitchValue* AkSwitchValue); // Function DungeonCrawler.SoundBlueprintLibrary.SetSwitch // (None) // @ game+0xffffc40cdf830041
};

// Class DungeonCrawler.SoundData
// Size: 0x128 (Inherited: 0x38)
struct USoundData : UDCDataAssetBase {
	struct TMap<struct FGameplayTag, struct UAkAudioEvent*> AkEventByGameplayTag; // 0x38(0x50)
	struct TMap<struct FGameplayTag, struct FDCSoundDataContainer> AkSwitchesByGameplayTag; // 0x88(0x50)
	struct TMap<struct FGameplayTag, struct FGameplayTagQuery> SoundPlayableTagQuery; // 0xd8(0x50)
};

// Class DungeonCrawler.SoundProvider
// Size: 0x28 (Inherited: 0x28)
struct USoundProvider : UInterface {

	struct FGameplayTagQuery GetTagQuery(struct FGameplayTag& Tag); // Function DungeonCrawler.SoundProvider.GetTagQuery // (None) // @ game+0xffffc413df830041
};

// Class DungeonCrawler.SpellActor
// Size: 0x408 (Inherited: 0x2f0)
struct ASpellActor : ADCActorBase {
	char pad_2F0[0xd8]; // 0x2f0(0xd8)
	struct FSpellData SpellData; // 0x3c8(0x30)
	struct UArtDataSpell* ArtDataSpell; // 0x3f8(0x08)
	struct USoundData* SoundData; // 0x400(0x08)

	bool UpdateSpellCount(int32_t DeltaCount); // Function DungeonCrawler.SpellActor.UpdateSpellCount // (None) // @ game+0xffffc41bdf830041
};

// Class DungeonCrawler.SpellMemorizeComponent
// Size: 0x158 (Inherited: 0xa0)
struct USpellMemorizeComponent : UActorComponent {
	char pad_A0[0x88]; // 0xa0(0x88)
	struct TArray<struct ASpellActor*> SpellActors; // 0x128(0x10)
	struct FGameplayTag CurrentSpellTag; // 0x138(0x08)
	float SpellCurrentCapacity; // 0x140(0x04)
	struct FPrimaryAssetId SpellRequiredRechargeAmountPerTierConstant; // 0x144(0x10)
	char pad_154[0x4]; // 0x154(0x04)

	bool UpdateSpellCount(struct FGameplayTag SpellTag, int32_t Count); // Function DungeonCrawler.SpellMemorizeComponent.UpdateSpellCount // (None) // @ game+0xffffc429df830041
};

// Class DungeonCrawler.StaticMeshItemHolderActor
// Size: 0x3e0 (Inherited: 0x3e0)
struct AStaticMeshItemHolderActor : AItemHolderActorBase {
	struct UMeshComponent* ItemMeshComponent; // 0x320(0x08)
	struct FPrimaryAssetId ItemId; // 0x328(0x10)
	struct FItemDataMeta ItemMetaData; // 0x338(0x50)
	struct UItem* ItemObject; // 0x388(0x08)
	struct UArtDataItem* ArtDataItem; // 0x390(0x08)
	struct USoundData* SoundData; // 0x398(0x08)
	struct UDCGlitterComponent* GlitterComponent; // 0x3a0(0x08)
	struct FPrimaryAssetId PropInteractId; // 0x3a8(0x10)
	struct FGameplayTagContainer GameplayTagContainer; // 0x3b8(0x20)
	bool bPreview; // 0x3d8(0x01)
};

// Class DungeonCrawler.StorageWidget
// Size: 0x300 (Inherited: 0x300)
struct UStorageWidget : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)
};

// Class DungeonCrawler.TagQueryData
// Size: 0xc8 (Inherited: 0x38)
struct UTagQueryData : UDCDataAssetBase {
	struct FGameplayTagQuery SourceTagQuery; // 0x38(0x48)
	struct FGameplayTagQuery TargetTagQuery; // 0x80(0x48)
};

// Class DungeonCrawler.TopTitleWidgetBase
// Size: 0x318 (Inherited: 0x300)
struct UTopTitleWidgetBase : UDCWidgetBase {
	struct UTextBlock* Text_Title; // 0x300(0x08)
	struct UDCCommonButtonBase* Btn_Left; // 0x308(0x08)
	struct UDCCommonButtonBase* Btn_Right; // 0x310(0x08)

	void SetTitleText(struct FText& TitleText); // Function DungeonCrawler.TopTitleWidgetBase.SetTitleText // (None) // @ game+0xffffc42cdf830041
};

// Class DungeonCrawler.TotalGoldCountWidgetBase
// Size: 0x388 (Inherited: 0x300)
struct UTotalGoldCountWidgetBase : UDCWidgetBase {
	struct UTextBlock* GoldCountText; // 0x300(0x08)
	struct UAccountLink* AccountLink; // 0x308(0x08)
	struct TMap<struct TWeakObjectPtr<struct UInventoryComponent>, int32_t> InventoryGoldCountMap; // 0x310(0x50)
	struct TWeakObjectPtr<struct APawn> LinkedPlayerPawn; // 0x360(0x08)
	struct FString LinkedAccountId; // 0x368(0x10)
	struct FString CheckTargetAccountId; // 0x378(0x10)
};

// Class DungeonCrawler.TradeChannelButtonBase
// Size: 0x348 (Inherited: 0x320)
struct UTradeChannelButtonBase : UDCCommonButtonBase {
	struct UCommonButtonBase* Btn_Common; // 0x300(0x08)
	struct FMulticastInlineDelegate OnCommonButtonClick; // 0x308(0x10)
	struct UAkAudioEvent* ClickSound; // 0x318(0x08)
	char pad_340[0x8]; // 0x340(0x08)

	void SetMemberText(int32_t InMemberCount); // Function DungeonCrawler.TradeChannelButtonBase.SetMemberText // (None) // @ game+0xffff8009df830000
};

// Class DungeonCrawler.TradeChannelChatWidget
// Size: 0x5e8 (Inherited: 0x408)
struct UTradeChannelChatWidget : UChatSetWidgetBase {
	struct UDCCommonButtonBase* Btn_ReadRules; // 0x408(0x08)
	struct UChatFilterWidget* TypeChatFilterWidget; // 0x410(0x08)
	struct UChatFilterWidget* IdTagChatFilterWidget; // 0x418(0x08)
	struct UChatFilterWidget* RarityChatFilterWidget; // 0x420(0x08)
	struct UChatFilterWidget* PropertyChatFilterWidget; // 0x428(0x08)
	struct UDCChatRoomDataAsset* ChatRoomData; // 0x430(0x08)
	struct FText ChannelName; // 0x438(0x18)
	struct FTradeChannelChatWidgetData WidgetData; // 0x450(0x50)
	char pad_4A0[0x148]; // 0x4a0(0x148)

	void OnTypeChatFilterReset(); // Function DungeonCrawler.TradeChannelChatWidget.OnTypeChatFilterReset // (None) // @ game+0xffffc43edf830041
};

// Class DungeonCrawler.TradeChannelListWidget
// Size: 0x370 (Inherited: 0x300)
struct UTradeChannelListWidget : UDCWidgetBase {
	struct UTradeChannelButtonBase* ChannelButtonWidgetClass; // 0x300(0x08)
	struct UDCTradeChannelCategoryWidget* ChannelCategoryWidgetClass; // 0x308(0x08)
	struct UScrollBox* ScrollBox_ChannelList; // 0x310(0x08)
	struct UOverlay* Overlay_DisableSelection; // 0x318(0x08)
	char pad_320[0x50]; // 0x320(0x50)
};

// Class DungeonCrawler.TradeChatWidget
// Size: 0x460 (Inherited: 0x408)
struct UTradeChatWidget : UChatSetWidgetBase {
	struct UDCCommonButtonBase* Btn_ReadRules; // 0x408(0x08)
	struct FTradeChatWidgetData WidgetData; // 0x410(0x48)
	char pad_458[0x8]; // 0x458(0x08)

	void OnReadRulesButtonClicked(); // Function DungeonCrawler.TradeChatWidget.OnReadRulesButtonClicked // (None) // @ game+0xffffc440df830041
};

// Class DungeonCrawler.TradeMasterWidget
// Size: 0x310 (Inherited: 0x300)
struct UTradeMasterWidget : UDCWidgetBase {
	struct UCommonButtonLWidget* WB_CommonBtn_BecomeTrader; // 0x300(0x08)
	struct UTextBlock* Text_TradingMasterConversation; // 0x308(0x08)

	void SendTradeSubscriptionWidgetBeginNotify(); // Function DungeonCrawler.TradeMasterWidget.SendTradeSubscriptionWidgetBeginNotify // (None) // @ game+0xffffc441df830041
};

// Class DungeonCrawler.TradeSubscriptionWidget
// Size: 0x398 (Inherited: 0x300)
struct UTradeSubscriptionWidget : UDCWidgetBase {
	struct FText RequirementLevelText; // 0x300(0x18)
	struct FText RequirementFeeText; // 0x318(0x18)
	struct FText RequirementMonthDueText; // 0x330(0x18)
	struct FText RequirementTradeCostText; // 0x348(0x18)
	struct FText TraderName; // 0x360(0x18)
	struct UCommonButtonPopupWidget* CommonBtn_Cancel; // 0x378(0x08)
	struct UCommonButtonPopupWidget* CommonBtn_Confirm; // 0x380(0x08)
	struct UCommonButtonPopupWidget* CommonBtn_Done; // 0x388(0x08)
	struct UWidgetSwitcher* WidgetSwitcher_Subscription; // 0x390(0x08)

	void SendMsgWidgetTradeSubscriptionButtonClicked(); // Function DungeonCrawler.TradeSubscriptionWidget.SendMsgWidgetTradeSubscriptionButtonClicked // (None) // @ game+0xffffc444df830041
};

// Class DungeonCrawler.TradeUserListEntryWidgetData
// Size: 0x90 (Inherited: 0x28)
struct UTradeUserListEntryWidgetData : UObject {
	char pad_28[0x68]; // 0x28(0x68)
};

// Class DungeonCrawler.TradeUserListEntryWidget
// Size: 0x398 (Inherited: 0x388)
struct UTradeUserListEntryWidget : ULobbyUserSlotBase {
	struct FNickname Nickname; // 0x320(0x28)
	struct FText LevelText; // 0x348(0x18)
	struct FText ClassNameText; // 0x360(0x18)
	struct UTexture2D* ClassIconImage; // 0x378(0x08)
	struct UTexture2D* ClassPortraitImage; // 0x380(0x08)

	void OnRightClicked(); // Function DungeonCrawler.TradeUserListEntryWidget.OnRightClicked // (None) // @ game+0xffffc445df830041
};

// Class DungeonCrawler.TradeUserListWidget
// Size: 0x360 (Inherited: 0x300)
struct UTradeUserListWidget : UDCWidgetBase {
	struct FText TraderNumText; // 0x300(0x18)
	struct ULobbyUserSlotBase* TradeUser_Local; // 0x318(0x08)
	struct UTileView* TileView_UserList; // 0x320(0x08)
	struct UEditableTextBox* FindUserEditableTextBox; // 0x328(0x08)
	char pad_330[0x20]; // 0x330(0x20)
	struct TArray<struct UTradeUserListEntryWidgetData*> TradeUserList; // 0x350(0x10)

	void OnTextChanged(struct FText& FindId); // Function DungeonCrawler.TradeUserListWidget.OnTextChanged // (None) // @ game+0xffffc447df830041
};

// Class DungeonCrawler.VoipAkComponent
// Size: 0x540 (Inherited: 0x4a0)
struct UVoipAkComponent : UAkComponent {
	struct UAkAudioEvent* SendPlayEvent; // 0x498(0x08)
	struct UAkAudioEvent* SendStopEvent; // 0x4a0(0x08)
	struct UAkAudioEvent* Receive2dPlayEvent; // 0x4a8(0x08)
	struct UAkAudioEvent* Receive3dPlayEvent; // 0x4b0(0x08)
	struct UAkAudioEvent* ReceiveStopEvent; // 0x4b8(0x08)
	struct UAkRtpc* ReceiveSensitivityRtpc; // 0x4c0(0x08)
	float ReceiveSensitivityMargin; // 0x4c8(0x04)
	struct UAkRtpc* SendSensitivityRtpc; // 0x4d0(0x08)
	float SendSensitivityMargin; // 0x4d8(0x04)
	struct UAkRtpc* GlobalInputVolumeRtpc; // 0x4e0(0x08)
	struct UAkRtpc* GlobalOutputVolumeRtpc; // 0x4e8(0x08)
	struct UAkRtpc* ReceiveVolumeRtpc; // 0x4f0(0x08)
	char pad_4F8[0x48]; // 0x4f8(0x48)
};

// Class DungeonCrawler.VoipPartyMemberSettingWidgetData
// Size: 0x60 (Inherited: 0x28)
struct UVoipPartyMemberSettingWidgetData : UObject {
	struct FVoipPartyMemberData VoipPartyMemberData; // 0x28(0x38)
};

// Class DungeonCrawler.VoipPartyMemberSettingWidget
// Size: 0x308 (Inherited: 0x300)
struct UVoipPartyMemberSettingWidget : UDCWidgetBase {
	struct UBaseObject* BaseObject; // 0x2f8(0x08)
};

// Class DungeonCrawler.VoipPartySettingWidget
// Size: 0x310 (Inherited: 0x300)
struct UVoipPartySettingWidget : UDCWidgetBase {
	struct UListView* PartyMemberSettingListView; // 0x300(0x08)
	char pad_308[0x8]; // 0x308(0x08)

	void OnVoipGlobalSet(bool InbVoipGlobal); // Function DungeonCrawler.VoipPartySettingWidget.OnVoipGlobalSet // (None) // @ game+0xffffc44adf830041
};

// Class DungeonCrawler.VoipUserWidget
// Size: 0x340 (Inherited: 0x300)
struct UVoipUserWidget : UDCWidgetBase {
	struct FVoipUserWidgetData WidgetData; // 0x300(0x38)
	bool bMine; // 0x338(0x01)
	bool bSameParty; // 0x339(0x01)
	char pad_33A[0x6]; // 0x33a(0x06)

	void SetVoipUserData(struct FVoipUserData& InVoipUserData); // Function DungeonCrawler.VoipUserWidget.SetVoipUserData // (None) // @ game+0xffffc452df830041
};

