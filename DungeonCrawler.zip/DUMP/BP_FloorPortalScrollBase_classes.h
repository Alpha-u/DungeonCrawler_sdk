// BlueprintGeneratedClass BP_FloorPortalScrollBase.BP_FloorPortalScrollBase_C
// Size: 0x3f1 (Inherited: 0x3d0)
struct ABP_FloorPortalScrollBase_C : AFloorPortalScrollBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3d0(0x08)
	struct UDCAkComponent* DCAk; // 0x3d8(0x08)
	struct UBoxComponent* Box; // 0x3e0(0x08)
	struct UDCSkeletalMeshComponent* DCSkeletalMesh; // 0x3e8(0x08)
	bool bOpen; // 0x3f0(0x01)

	void OnRep_bOpen(); // Function BP_FloorPortalScrollBase.BP_FloorPortalScrollBase_C.OnRep_bOpen // (None) // @ game+0xddb1dfab0001
};

