// BlueprintGeneratedClass BP_Lantern.BP_Lantern_C
// Size: 0x5e9 (Inherited: 0x578)
struct ABP_Lantern_C : ABP_DCItemActor_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x578(0x08)
	struct UNiagaraComponent* FXS_Fire_OilLantern_Util; // 0x580(0x08)
	struct UPointLightComponent* PointLightFire; // 0x588(0x08)
	struct UDCItemDataComponent* DCItemData; // 0x590(0x08)
	struct UPointLightComponent* PointLight; // 0x598(0x08)
	struct UNiagaraComponent* NS_Util_Torch; // 0x5a0(0x08)
	float Timeline_2______0_BDFC69AA497AA30B34BE3695DB5B5386; // 0x5a8(0x04)
	enum class ETimelineDirection Timeline_2__Direction_BDFC69AA497AA30B34BE3695DB5B5386; // 0x5ac(0x01)
	char pad_5AD[0x3]; // 0x5ad(0x03)
	struct UTimelineComponent* Timeline_3; // 0x5b0(0x08)
	float Timeline_1______0_3B8649B848CA3FD6C368E6925311FEA3; // 0x5b8(0x04)
	enum class ETimelineDirection Timeline_1__Direction_3B8649B848CA3FD6C368E6925311FEA3; // 0x5bc(0x01)
	char pad_5BD[0x3]; // 0x5bd(0x03)
	struct UTimelineComponent* Timeline_2; // 0x5c0(0x08)
	float Timeline_0______0_7A2EB05349A7DFBBEF5C9486C78F703E; // 0x5c8(0x04)
	enum class ETimelineDirection Timeline_0__Direction_7A2EB05349A7DFBBEF5C9486C78F703E; // 0x5cc(0x01)
	char pad_5CD[0x3]; // 0x5cd(0x03)
	struct UTimelineComponent* Timeline_1; // 0x5d0(0x08)
	float Timeline______0_B306F89A42E7828A566D08B5F03B02B4; // 0x5d8(0x04)
	enum class ETimelineDirection Timeline__Direction_B306F89A42E7828A566D08B5F03B02B4; // 0x5dc(0x01)
	char pad_5DD[0x3]; // 0x5dd(0x03)
	struct UTimelineComponent* Timeline; // 0x5e0(0x08)
	bool bAttachedSheathSocket; // 0x5e8(0x01)

	void Timeline__FinishedFunc(); // Function BP_Lantern.BP_Lantern_C.Timeline__FinishedFunc // (None) // @ game+0xffff800adf830001
};

