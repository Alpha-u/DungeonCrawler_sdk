// BlueprintGeneratedClass BP_SoulHeartHolder.BP_SoulHeartHolder_C
// Size: 0x3e0 (Inherited: 0x3e0)
struct ABP_SoulHeartHolder_C : ABP_StaticMeshItemHolder_C {
	struct UMeshComponent* ItemMeshComponent; // 0x320(0x08)
	struct FPrimaryAssetId ItemId; // 0x328(0x10)
	struct FItemDataMeta ItemMetaData; // 0x338(0x50)
	struct UItem* ItemObject; // 0x388(0x08)
	struct UArtDataItem* ArtDataItem; // 0x390(0x08)
	struct USoundData* SoundData; // 0x398(0x08)
	struct UDCGlitterComponent* GlitterComponent; // 0x3a0(0x08)
	struct FPrimaryAssetId PropInteractId; // 0x3a8(0x10)
	struct FGameplayTagContainer GameplayTagContainer; // 0x3b8(0x20)
	bool bPreview; // 0x3d8(0x01)

	void InteractTargetInfoName(struct FText& Name); // Function BP_SoulHeartHolder.BP_SoulHeartHolder_C.InteractTargetInfoName // (NetReliableNetRequest|NetResponse|Static|NetMulticast|UbergraphFunction|MulticastDelegate|Public|NetServer|HasOutParms|HasDefaults|NetClient|BlueprintCallable|BlueprintEvent|BlueprintPure|EditorOnly|NetValidate) // @ game+0x1215edfab0008
};

