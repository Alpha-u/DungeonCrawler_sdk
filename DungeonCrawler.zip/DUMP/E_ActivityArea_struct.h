// UserDefinedEnum E_ActivityArea.E_ActivityArea
enum class E_ActivityArea : uint8 {
	NewEnumerator1 = 0,
	NewEnumerator0 = 1,
	E_MAX = 2
};

