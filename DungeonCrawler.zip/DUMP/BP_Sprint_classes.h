// BlueprintGeneratedClass BP_Sprint.BP_Sprint_C
// Size: 0x400 (Inherited: 0x400)
struct ABP_Sprint_C : ABP_SkillActor_C {
	struct USceneComponent* DefaultSceneRoot; // 0x3f8(0x08)
};

