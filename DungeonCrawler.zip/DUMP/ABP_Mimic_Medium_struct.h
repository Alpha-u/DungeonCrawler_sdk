// ScriptStruct ABP_Mimic_Medium.ABP_Mimic_Medium_C.AnimBlueprintGeneratedMutableData
// Size: 0x08 (Inherited: 0x01)
struct FAnimBlueprintGeneratedMutableData : FAnimBlueprintMutableData {
	char pad_1[0x3]; // 0x01(0x03)
	float __FloatProperty; // 0x04(0x04)
};

// ScriptStruct ABP_Mimic_Medium.ABP_Mimic_Medium_C.AnimBlueprintGeneratedConstantData
// Size: 0x168 (Inherited: 0x01)
struct FAnimBlueprintGeneratedConstantData : FAnimBlueprintConstantData {
	char pad_1[0x3]; // 0x01(0x03)
	struct FName __NameProperty_161; // 0x04(0x08)
	struct FName __NameProperty_162; // 0x0c(0x08)
	struct FName __NameProperty_163; // 0x14(0x08)
	bool __BoolProperty_164; // 0x1c(0x01)
	enum class EAnimSyncMethod __EnumProperty_165; // 0x1d(0x01)
	char pad_1E[0x2]; // 0x1e(0x02)
	struct FName __NameProperty_166; // 0x20(0x08)
	struct FName __NameProperty_167; // 0x28(0x08)
	int32_t __IntProperty_168; // 0x30(0x04)
	struct FName __NameProperty_169; // 0x34(0x08)
	struct FName __NameProperty_170; // 0x3c(0x08)
	int32_t __IntProperty_171; // 0x44(0x04)
	struct FName __NameProperty_172; // 0x48(0x08)
	int32_t __IntProperty_173; // 0x50(0x04)
	float __FloatProperty_174; // 0x54(0x04)
	struct FInputScaleBiasClampConstants __StructProperty_175; // 0x58(0x2c)
	float __FloatProperty_176; // 0x84(0x04)
	float __FloatProperty_177; // 0x88(0x04)
	bool __BoolProperty_178; // 0x8c(0x01)
	enum class EAnimSyncMethod __EnumProperty_179; // 0x8d(0x01)
	enum class EAnimGroupRole __ByteProperty_180; // 0x8e(0x01)
	char pad_8F[0x1]; // 0x8f(0x01)
	struct FName __NameProperty_181; // 0x90(0x08)
	struct FName __NameProperty_182; // 0x98(0x08)
	struct FName __NameProperty_183; // 0xa0(0x08)
	int32_t __IntProperty_184; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
	struct FAnimNodeFunctionRef __StructProperty_185; // 0xb0(0x20)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess; // 0xd0(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base; // 0x150(0x18)
};

