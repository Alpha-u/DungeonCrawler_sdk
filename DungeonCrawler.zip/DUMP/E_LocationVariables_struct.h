// UserDefinedEnum E_LocationVariables.E_LocationVariables
enum class E_LocationVariables : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	E_MAX = 2
};

