// Class ControlRig.RigHierarchy
// Size: 0x320 (Inherited: 0x28)
struct URigHierarchy : UObject {
	char pad_28[0x60]; // 0x28(0x60)
	uint16_t TopologyVersion; // 0x88(0x02)
	uint16_t MetadataVersion; // 0x8a(0x02)
	uint16_t MetadataTagVersion; // 0x8c(0x02)
	bool bEnableDirtyPropagation; // 0x8e(0x01)
	char pad_8F[0x71]; // 0x8f(0x71)
	int32_t TransformStackIndex; // 0x100(0x04)
	char pad_104[0x74]; // 0x104(0x74)
	struct URigHierarchyController* HierarchyController; // 0x178(0x08)
	char pad_180[0x58]; // 0x180(0x58)
	struct TMap<struct FRigElementKey, struct FRigElementKey> PreviousNameMap; // 0x1d8(0x50)
	char pad_228[0x80]; // 0x228(0x80)
	struct URigHierarchy* HierarchyForCacheValidation; // 0x2a8(0x08)
	char pad_2B0[0x70]; // 0x2b0(0x70)

	void UnsetCurveValueByIndex(int32_t InElementIndex, bool bSetupUndo); // Function ControlRig.RigHierarchy.UnsetCurveValueByIndex // (None) // @ game+0xffffb4b2df830041
};

// Class ControlRig.TransformableControlHandle
// Size: 0x90 (Inherited: 0x58)
struct UTransformableControlHandle : UTransformableHandle {
	struct TSoftObjectPtr<UControlRig> ControlRig; // 0x58(0x30)
	struct FName ControlName; // 0x88(0x08)
};

// Class ControlRig.ControlRig
// Size: 0x560 (Inherited: 0x28)
struct UControlRig : UObject {
	char pad_28[0x1e]; // 0x28(0x1e)
	enum class ERigExecutionType ExecutionType; // 0x46(0x01)
	char pad_47[0x1]; // 0x47(0x01)
	struct FRigHierarchySettings HierarchySettings; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct FRigVMRuntimeSettings VMRuntimeSettings; // 0x50(0x18)
	struct TMap<struct FRigElementKey, struct FRigControlElementCustomization> ControlCustomizations; // 0x68(0x50)
	struct URigVM* VM; // 0xb8(0x08)
	struct TMap<uint32_t, struct URigVM*> InitializedVMSnapshots; // 0xc0(0x50)
	char pad_110[0x8]; // 0x110(0x08)
	struct URigHierarchy* DynamicHierarchy; // 0x118(0x08)
	struct TSoftObjectPtr<UControlRigShapeLibrary> GizmoLibrary; // 0x120(0x30)
	struct TArray<struct TSoftObjectPtr<UControlRigShapeLibrary>> ShapeLibraries; // 0x150(0x10)
	char pad_160[0x10]; // 0x160(0x10)
	struct TMap<struct FName, struct FCachedPropertyPath> InputProperties; // 0x170(0x50)
	struct TMap<struct FName, struct FCachedPropertyPath> OutputProperties; // 0x1c0(0x50)
	char pad_210[0xa8]; // 0x210(0xa8)
	struct FControlRigDrawContainer DrawContainer; // 0x2b8(0x18)
	char pad_2D0[0x18]; // 0x2d0(0x18)
	struct UAnimationDataSourceRegistry* DataSourceRegistry; // 0x2e8(0x08)
	struct TArray<struct FName> EventQueue; // 0x2f0(0x10)
	char pad_300[0xd0]; // 0x300(0xd0)
	struct FRigInfluenceMapPerEvent Influences; // 0x3d0(0x60)
	struct UControlRig* InteractionRig; // 0x430(0x08)
	struct UControlRig* InteractionRigClass; // 0x438(0x08)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x440(0x10)
	char pad_450[0xc8]; // 0x450(0xc8)
	struct FMulticastSparseDelegate OnControlSelected_BP; // 0x518(0x01)
	char pad_519[0x47]; // 0x519(0x47)

	bool SupportsEvent(struct FName& InEventName); // Function ControlRig.ControlRig.SupportsEvent // (None) // @ game+0xffff970adf830041
};

// Class ControlRig.ControlRigAnimInstance
// Size: 0x350 (Inherited: 0x350)
struct UControlRigAnimInstance : UAnimInstance {
	struct USkeleton* CurrentSkeleton; // 0x28(0x08)
	enum class ERootMotionMode RootMotionMode; // 0x30(0x01)
	char bUseMultiThreadedAnimationUpdate : 1; // 0x31(0x01)
	char bUsingCopyPoseFromMesh : 1; // 0x31(0x01)
	char pad_359_2 : 2; // 0x359(0x01)
	char bReceiveNotifiesFromLinkedInstances : 1; // 0x31(0x01)
	char bPropagateNotifiesToLinkedInstances : 1; // 0x31(0x01)
	char bUseMainInstanceMontageEvaluationData : 1; // 0x31(0x01)
	char bQueueMontageEvents : 1; // 0x31(0x01)
	struct FMulticastInlineDelegate OnMontageBlendingOut; // 0x38(0x10)
	struct FMulticastInlineDelegate OnMontageStarted; // 0x48(0x10)
	struct FMulticastInlineDelegate OnMontageEnded; // 0x58(0x10)
	struct FMulticastInlineDelegate OnAllMontageInstancesEnded; // 0x68(0x10)
	struct FAnimNotifyQueue NotifyQueue; // 0x150(0x70)
	struct TArray<struct FAnimNotifyEvent> ActiveAnimNotifyState; // 0x1c0(0x10)
	struct TArray<struct FAnimNotifyEventReference> ActiveAnimNotifyEventReference; // 0x1d0(0x10)
};

// Class ControlRig.ControlRigBlueprintGeneratedClass
// Size: 0x380 (Inherited: 0x380)
struct UControlRigBlueprintGeneratedClass : UBlueprintGeneratedClass {
	int32_t NumReplicatedProperties; // 0x238(0x04)
	char bHasNativizedParent : 1; // 0x23c(0x01)
	char bHasCookedComponentInstancingData : 1; // 0x23c(0x01)
	struct TArray<struct UDynamicBlueprintBinding*> DynamicBindingObjects; // 0x240(0x10)
	struct TArray<struct UActorComponent*> ComponentTemplates; // 0x250(0x10)
	struct TArray<struct UTimelineTemplate*> Timelines; // 0x260(0x10)
	struct TArray<struct FBPComponentClassOverride> ComponentClassOverrides; // 0x270(0x10)
	struct USimpleConstructionScript* SimpleConstructionScript; // 0x280(0x08)
	struct UInheritableComponentHandler* InheritableComponentHandler; // 0x288(0x08)
	struct UStructProperty* UberGraphFramePointerProperty; // 0x290(0x08)
	struct UFunction* UberGraphFunction; // 0x2a0(0x08)
	struct TMap<struct FName, struct FGuid> CookedPropertyGuids; // 0x2a8(0x50)
	struct TMap<struct FName, struct FBlueprintCookedComponentInstancingData> CookedComponentInstancingData; // 0x2f8(0x50)
};

// Class ControlRig.ControlRigComponent
// Size: 0x690 (Inherited: 0x540)
struct UControlRigComponent : UPrimitiveComponent {
	struct UControlRig* ControlRigClass; // 0x538(0x08)
	struct FMulticastInlineDelegate OnPreInitializeDelegate; // 0x540(0x10)
	struct FMulticastInlineDelegate OnPostInitializeDelegate; // 0x550(0x10)
	struct FMulticastInlineDelegate OnPreConstructionDelegate; // 0x560(0x10)
	struct FMulticastInlineDelegate OnPostConstructionDelegate; // 0x570(0x10)
	struct FMulticastInlineDelegate OnPreForwardsSolveDelegate; // 0x580(0x10)
	struct FMulticastInlineDelegate OnPostForwardsSolveDelegate; // 0x590(0x10)
	struct TArray<struct FControlRigComponentMappedElement> UserDefinedElements; // 0x5a0(0x10)
	struct TArray<struct FControlRigComponentMappedElement> MappedElements; // 0x5b0(0x10)
	bool bEnableLazyEvaluation; // 0x5c0(0x01)
	float LazyEvaluationPositionThreshold; // 0x5c4(0x04)
	float LazyEvaluationRotationThreshold; // 0x5c8(0x04)
	float LazyEvaluationScaleThreshold; // 0x5cc(0x04)
	bool bResetTransformBeforeTick; // 0x5d0(0x01)
	bool bResetInitialsBeforeConstruction; // 0x5d1(0x01)
	bool bUpdateRigOnTick; // 0x5d2(0x01)
	bool bUpdateInEditor; // 0x5d3(0x01)
	bool bDrawBones; // 0x5d4(0x01)
	bool bShowDebugDrawing; // 0x5d5(0x01)
	struct UControlRig* ControlRig; // 0x5d8(0x08)
	char pad_5E3[0xad]; // 0x5e3(0xad)

	void Update(float DeltaTime); // Function ControlRig.ControlRigComponent.Update // (None) // @ game+0xffffb54adf830041
};

// Class ControlRig.ControlRigControlActor
// Size: 0x348 (Inherited: 0x290)
struct AControlRigControlActor : AActor {
	struct AActor* ActorToTrack; // 0x290(0x08)
	struct UControlRig* ControlRigClass; // 0x298(0x08)
	bool bRefreshOnTick; // 0x2a0(0x01)
	bool bIsSelectable; // 0x2a1(0x01)
	char pad_2A2[0x6]; // 0x2a2(0x06)
	struct UMaterialInterface* MaterialOverride; // 0x2a8(0x08)
	struct FString ColorParameter; // 0x2b0(0x10)
	bool bCastShadows; // 0x2c0(0x01)
	char pad_2C1[0x7]; // 0x2c1(0x07)
	struct USceneComponent* ActorRootComponent; // 0x2c8(0x08)
	struct TSoftObjectPtr<UControlRig> ControlRig; // 0x2d0(0x30)
	struct TArray<struct FName> ControlNames; // 0x300(0x10)
	struct TArray<struct FTransform> ShapeTransforms; // 0x310(0x10)
	struct TArray<struct UStaticMeshComponent*> Components; // 0x320(0x10)
	struct TArray<struct UMaterialInstanceDynamic*> Materials; // 0x330(0x10)
	struct FName ColorParameterName; // 0x340(0x08)

	void ResetControlActor(); // Function ControlRig.ControlRigControlActor.ResetControlActor // (None) // @ game+0xffffb54ddf830041
};

// Class ControlRig.ControlRigShapeActor
// Size: 0x2d8 (Inherited: 0x290)
struct AControlRigShapeActor : AActor {
	struct USceneComponent* ActorRootComponent; // 0x290(0x08)
	struct UStaticMeshComponent* StaticMeshComponent; // 0x298(0x08)
	uint32_t ControlRigIndex; // 0x2a0(0x04)
	struct TWeakObjectPtr<struct UControlRig> ControlRig; // 0x2a4(0x08)
	struct FName ControlName; // 0x2ac(0x08)
	struct FName ShapeName; // 0x2b4(0x08)
	struct FName ColorParameterName; // 0x2bc(0x08)
	char pad_2C4[0x10]; // 0x2c4(0x10)
	char bSelected : 1; // 0x2d4(0x01)
	char bHovered : 1; // 0x2d4(0x01)
	char pad_2D4_2 : 6; // 0x2d4(0x01)
	char pad_2D5[0x3]; // 0x2d5(0x03)

	void SetSelected(bool bInSelected); // Function ControlRig.ControlRigShapeActor.SetSelected // (None) // @ game+0xffff8009df830000
};

// Class ControlRig.ControlRigShapeLibrary
// Size: 0x170 (Inherited: 0x28)
struct UControlRigShapeLibrary : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FControlRigShapeDefinition DefaultShape; // 0x30(0xb0)
	struct TSoftObjectPtr<UMaterial> DefaultMaterial; // 0xe0(0x30)
	struct TSoftObjectPtr<UMaterial> XRayMaterial; // 0x110(0x30)
	struct FName MaterialColorParameter; // 0x140(0x08)
	struct TArray<struct FControlRigShapeDefinition> Shapes; // 0x148(0x10)
	char pad_158[0x18]; // 0x158(0x18)
};

// Class ControlRig.ControlRigValidator
// Size: 0x68 (Inherited: 0x28)
struct UControlRigValidator : UObject {
	struct TArray<struct UControlRigValidationPass*> Passes; // 0x28(0x10)
	char pad_38[0x30]; // 0x38(0x30)
};

// Class ControlRig.ControlRigValidationPass
// Size: 0x28 (Inherited: 0x28)
struct UControlRigValidationPass : UObject {
};

// Class ControlRig.AdditiveControlRig
// Size: 0x570 (Inherited: 0x560)
struct UAdditiveControlRig : UControlRig {
	enum class ERigExecutionType ExecutionType; // 0x46(0x01)
	struct FRigHierarchySettings HierarchySettings; // 0x48(0x04)
	struct FRigVMRuntimeSettings VMRuntimeSettings; // 0x50(0x18)
	struct TMap<struct FRigElementKey, struct FRigControlElementCustomization> ControlCustomizations; // 0x68(0x50)
	struct URigVM* VM; // 0xb8(0x08)
	struct TMap<uint32_t, struct URigVM*> InitializedVMSnapshots; // 0xc0(0x50)
	struct URigHierarchy* DynamicHierarchy; // 0x118(0x08)
	struct TSoftObjectPtr<UControlRigShapeLibrary> GizmoLibrary; // 0x120(0x30)
	struct TArray<struct TSoftObjectPtr<UControlRigShapeLibrary>> ShapeLibraries; // 0x150(0x10)
	struct TMap<struct FName, struct FCachedPropertyPath> InputProperties; // 0x170(0x50)
	struct TMap<struct FName, struct FCachedPropertyPath> OutputProperties; // 0x1c0(0x50)
	struct FControlRigDrawContainer DrawContainer; // 0x2b8(0x18)
	struct UAnimationDataSourceRegistry* DataSourceRegistry; // 0x2e8(0x08)
	struct TArray<struct FName> EventQueue; // 0x2f0(0x10)
	struct FRigInfluenceMapPerEvent Influences; // 0x3d0(0x60)
	struct UControlRig* InteractionRig; // 0x430(0x08)
	struct UControlRig* InteractionRigClass; // 0x438(0x08)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x440(0x10)
	struct FMulticastSparseDelegate OnControlSelected_BP; // 0x518(0x01)
};

// Class ControlRig.FKControlRig
// Size: 0x5a0 (Inherited: 0x560)
struct UFKControlRig : UControlRig {
	struct TArray<bool> IsControlActive; // 0x560(0x10)
	enum class EControlRigFKRigExecuteMode ApplyMode; // 0x570(0x01)
	char pad_571[0x2f]; // 0x571(0x2f)
};

// Class ControlRig.RigHierarchyController
// Size: 0xa0 (Inherited: 0x28)
struct URigHierarchyController : UObject {
	bool bReportWarningsAndErrors; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	struct TWeakObjectPtr<struct URigHierarchy> Hierarchy; // 0x2c(0x08)
	char pad_34[0x6c]; // 0x34(0x6c)

	bool SetSelection(struct TArray<struct FRigElementKey>& InKeys, bool bPrintPythonCommand); // Function ControlRig.RigHierarchyController.SetSelection // (None) // @ game+0xffffb5b9df830041
};

// Class ControlRig.ControlRigLayerInstance
// Size: 0x350 (Inherited: 0x350)
struct UControlRigLayerInstance : UAnimInstance {
	struct USkeleton* CurrentSkeleton; // 0x28(0x08)
	enum class ERootMotionMode RootMotionMode; // 0x30(0x01)
	char bUseMultiThreadedAnimationUpdate : 1; // 0x31(0x01)
	char bUsingCopyPoseFromMesh : 1; // 0x31(0x01)
	char pad_359_2 : 2; // 0x359(0x01)
	char bReceiveNotifiesFromLinkedInstances : 1; // 0x31(0x01)
	char bPropagateNotifiesToLinkedInstances : 1; // 0x31(0x01)
	char bUseMainInstanceMontageEvaluationData : 1; // 0x31(0x01)
	char bQueueMontageEvents : 1; // 0x31(0x01)
	struct FMulticastInlineDelegate OnMontageBlendingOut; // 0x38(0x10)
	struct FMulticastInlineDelegate OnMontageStarted; // 0x48(0x10)
	struct FMulticastInlineDelegate OnMontageEnded; // 0x58(0x10)
	struct FMulticastInlineDelegate OnAllMontageInstancesEnded; // 0x68(0x10)
	struct FAnimNotifyQueue NotifyQueue; // 0x150(0x70)
	struct TArray<struct FAnimNotifyEvent> ActiveAnimNotifyState; // 0x1c0(0x10)
	struct TArray<struct FAnimNotifyEventReference> ActiveAnimNotifyEventReference; // 0x1d0(0x10)
};

// Class ControlRig.ControlRigObjectHolder
// Size: 0x38 (Inherited: 0x28)
struct UControlRigObjectHolder : UObject {
	struct TArray<struct UObject*> Objects; // 0x28(0x10)
};

// Class ControlRig.ControlRigSequence
// Size: 0x288 (Inherited: 0x220)
struct UControlRigSequence : ULevelSequence {
	struct TSoftObjectPtr<UAnimSequence> LastExportedToAnimationSequence; // 0x220(0x30)
	struct TSoftObjectPtr<USkeletalMesh> LastExportedUsingSkeletalMesh; // 0x250(0x30)
	float LastExportedFrameRate; // 0x280(0x04)
	char pad_284[0x4]; // 0x284(0x04)
};

// Class ControlRig.MovieSceneControlRigParameterSection
// Size: 0x3c8 (Inherited: 0x158)
struct UMovieSceneControlRigParameterSection : UMovieSceneParameterSection {
	char pad_158[0x40]; // 0x158(0x40)
	struct UControlRig* ControlRig; // 0x198(0x08)
	struct UControlRig* ControlRigClass; // 0x1a0(0x08)
	struct TArray<bool> ControlsMask; // 0x1a8(0x10)
	struct FMovieSceneTransformMask TransformMask; // 0x1b8(0x04)
	char pad_1BC[0x4]; // 0x1bc(0x04)
	struct FMovieSceneFloatChannel Weight; // 0x1c0(0x110)
	struct TMap<struct FName, struct FChannelMapInfo> ControlChannelMap; // 0x2d0(0x50)
	struct TArray<struct FEnumParameterNameAndCurve> EnumParameterNamesAndCurves; // 0x320(0x10)
	struct TArray<struct FIntegerParameterNameAndCurve> IntegerParameterNamesAndCurves; // 0x330(0x10)
	struct TArray<struct FSpaceControlNameAndChannel> SpaceChannels; // 0x340(0x10)
	struct TArray<struct FConstraintAndActiveChannel> ConstraintsChannels; // 0x350(0x10)
	char pad_360[0x68]; // 0x360(0x68)
};

// Class ControlRig.MovieSceneControlRigParameterTrack
// Size: 0x100 (Inherited: 0x98)
struct UMovieSceneControlRigParameterTrack : UMovieSceneNameableTrack {
	char pad_98[0x40]; // 0x98(0x40)
	struct UControlRig* ControlRig; // 0xd8(0x08)
	struct UMovieSceneSection* SectionToKey; // 0xe0(0x08)
	struct TArray<struct UMovieSceneSection*> Sections; // 0xe8(0x10)
	struct FName TrackName; // 0xf8(0x08)
};

// Class ControlRig.ControlRigSettings
// Size: 0x38 (Inherited: 0x38)
struct UControlRigSettings : UDeveloperSettings {
};

// Class ControlRig.ControlRigEditorSettings
// Size: 0x38 (Inherited: 0x38)
struct UControlRigEditorSettings : UDeveloperSettings {
};

// Class ControlRig.ControlRigPoseAsset
// Size: 0x88 (Inherited: 0x28)
struct UControlRigPoseAsset : UObject {
	struct FControlRigControlPose Pose; // 0x28(0x60)

	void SelectControls(struct UControlRig* InControlRig, bool bDoMirror); // Function ControlRig.ControlRigPoseAsset.SelectControls // (None) // @ game+0xffffb592df830041
};

// Class ControlRig.ControlRigPoseMirrorSettings
// Size: 0x50 (Inherited: 0x28)
struct UControlRigPoseMirrorSettings : UObject {
	struct FString RightSide; // 0x28(0x10)
	struct FString LeftSide; // 0x38(0x10)
	enum class EAxis MirrorAxis; // 0x48(0x01)
	enum class EAxis AxisToFlip; // 0x49(0x01)
	char pad_4A[0x6]; // 0x4a(0x06)
};

// Class ControlRig.ControlRigPoseProjectSettings
// Size: 0x38 (Inherited: 0x28)
struct UControlRigPoseProjectSettings : UObject {
	struct TArray<struct FDirectoryPath> RootSaveDirs; // 0x28(0x10)
};

// Class ControlRig.ControlRigSnapSettings
// Size: 0x30 (Inherited: 0x28)
struct UControlRigSnapSettings : UObject {
	bool bKeepOffset; // 0x28(0x01)
	bool bSnapPosition; // 0x29(0x01)
	bool bSnapRotation; // 0x2a(0x01)
	bool bSnapScale; // 0x2b(0x01)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// Class ControlRig.ControlRigWorkflowOptions
// Size: 0xb0 (Inherited: 0x98)
struct UControlRigWorkflowOptions : URigVMUserWorkflowOptions {
	struct URigHierarchy* Hierarchy; // 0x98(0x08)
	struct TArray<struct FRigElementKey> Selection; // 0xa0(0x10)

	bool EnsureAtLeastOneRigElementSelected(); // Function ControlRig.ControlRigWorkflowOptions.EnsureAtLeastOneRigElementSelected // (None) // @ game+0xffffb5dadf830041
};

// Class ControlRig.ControlRigTransformWorkflowOptions
// Size: 0xb8 (Inherited: 0xb0)
struct UControlRigTransformWorkflowOptions : UControlRigWorkflowOptions {
	enum class ERigTransformType TransformType; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)

	struct TArray<struct FRigVMUserWorkflow> ProvideWorkflows(struct UObject* InSubject); // Function ControlRig.ControlRigTransformWorkflowOptions.ProvideWorkflows // (None) // @ game+0xffffb599df830041
};

// Class ControlRig.ControlRigNumericalValidationPass
// Size: 0xc0 (Inherited: 0x28)
struct UControlRigNumericalValidationPass : UControlRigValidationPass {
	bool bCheckControls; // 0x28(0x01)
	bool bCheckBones; // 0x29(0x01)
	bool bCheckCurves; // 0x2a(0x01)
	char pad_2B[0x1]; // 0x2b(0x01)
	float TranslationPrecision; // 0x2c(0x04)
	float RotationPrecision; // 0x30(0x04)
	float ScalePrecision; // 0x34(0x04)
	float CurvePrecision; // 0x38(0x04)
	struct FName EventNameA; // 0x3c(0x08)
	struct FName EventNameB; // 0x44(0x08)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct FRigPose Pose; // 0x50(0x70)
};

