// BlueprintGeneratedClass BP_GameplayTagColliderActorBase.BP_GameplayTagColliderActorBase_C
// Size: 0x3e0 (Inherited: 0x3e0)
struct ABP_GameplayTagColliderActorBase_C : ADCGameplayTagCollider {
	struct UAccountLink* OwnerAccountLink; // 0x2f0(0x08)
	struct FString OwnerAccountId; // 0x2f8(0x10)
	struct FString TargetAccountId; // 0x308(0x10)
	struct UAccountLink* TargetAccountLink; // 0x318(0x08)
	struct TWeakObjectPtr<struct APawn> TargetPlayerPawn; // 0x320(0x08)
	struct FAccountDataReplication TargetAccountDataReplication; // 0x328(0x78)
	struct FGameplayTagContainer TargetOwnedGameplayeTags; // 0x3a0(0x20)
	float ColliderRadius; // 0x3c0(0x04)
	struct USphereComponent* GameplayTagOverlapSphere; // 0x3c8(0x08)
	struct TArray<struct UDCTagCollisionDetectorComponent*> OverlapDetectorComponentArray; // 0x3d0(0x10)
};

