// BlueprintGeneratedClass Blockout_Box.Blockout_Box_C
// Size: 0x378 (Inherited: 0x328)
struct ABlockout_Box_C : ABlockoutToolsParent {
	struct FVector BoxSize; // 0x328(0x18)
	bool bRoundSize; // 0x340(0x01)
	char pad_341[0x7]; // 0x341(0x07)
	struct UStaticMesh* BlockoutBoxMesh; // 0x348(0x08)
	bool bUseGrid; // 0x350(0x01)
	char pad_351[0x3]; // 0x351(0x03)
	struct FLinearColor Color; // 0x354(0x10)
	bool bUseTopColor; // 0x364(0x01)
	char pad_365[0x3]; // 0x365(0x03)
	struct FLinearColor TopColor; // 0x368(0x10)

	void AddBlockoutBox(); // Function Blockout_Box.Blockout_Box_C.AddBlockoutBox // (NetRequest|Exec|Event|Static|UbergraphFunction|MulticastDelegate|Private|HasDefaults|NetClient|DLLImport|EditorOnly|Const) // @ game+0xffff8009df830000
};

