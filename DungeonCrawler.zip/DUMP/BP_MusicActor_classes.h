// BlueprintGeneratedClass BP_MusicActor.BP_MusicActor_C
// Size: 0x3e0 (Inherited: 0x3d8)
struct ABP_MusicActor_C : AMusicActor {
	struct USceneComponent* DefaultSceneRoot; // 0x3d8(0x08)
};

