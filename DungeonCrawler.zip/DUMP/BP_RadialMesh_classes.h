// BlueprintGeneratedClass BP_RadialMesh.BP_RadialMesh_C
// Size: 0x2c0 (Inherited: 0x290)
struct ABP_RadialMesh_C : AActor {
	struct USceneComponent* DefaultSceneRoot; // 0x290(0x08)
	int32_t Number; // 0x298(0x04)
	char pad_29C[0x4]; // 0x29c(0x04)
	struct UStaticMesh* Mesh; // 0x2a0(0x08)
	double Radius; // 0x2a8(0x08)
	double Offset; // 0x2b0(0x08)
	double Local Scale; // 0x2b8(0x08)

	void UserConstructionScript(); // Function BP_RadialMesh.BP_RadialMesh_C.UserConstructionScript // (NetReliableNetRequest|Exec|Native|NetMulticast|MulticastDelegate|Public|Private|Protected|Delegate|NetServer|HasOutParms|HasDefaults|NetClient|DLLImport|BlueprintEvent|Const|NetValidate) // @ game+0xffff80c1df82ffff
};

