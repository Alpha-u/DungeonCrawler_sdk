// BlueprintGeneratedClass BP_DCMonsterAIController.BP_DCMonsterAIController_C
// Size: 0x458 (Inherited: 0x458)
struct ABP_DCMonsterAIController_C : ADCMonsterAIController {
	struct UBaseObject* BaseObject; // 0x410(0x08)
	struct FGameplayTagContainer TargetInvisibleStateTagContainer; // 0x438(0x20)
};

