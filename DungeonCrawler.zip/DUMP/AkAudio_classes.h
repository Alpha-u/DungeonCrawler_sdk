// Class AkAudio.AkGameObject
// Size: 0x2c0 (Inherited: 0x2a0)
struct UAkGameObject : USceneComponent {
	struct UAkAudioEvent* AkAudioEvent; // 0x2a0(0x08)
	struct FString EventName; // 0x2a8(0x10)
	char pad_2B8[0x8]; // 0x2b8(0x08)

	void Stop(); // Function AkAudio.AkGameObject.Stop // (None) // @ game+0xffffb23cdf830041
};

// Class AkAudio.AkComponent
// Size: 0x4a0 (Inherited: 0x2c0)
struct UAkComponent : UAkGameObject {
	bool bUseSpatialAudio; // 0x2c0(0x01)
	char pad_2C1[0x7]; // 0x2c1(0x07)
	enum class EAkCollisionChannel OcclusionCollisionChannel; // 0x2c8(0x01)
	bool EnableSpotReflectors; // 0x2c9(0x01)
	char pad_2CA[0x2]; // 0x2ca(0x02)
	float OuterRadius; // 0x2cc(0x04)
	float InnerRadius; // 0x2d0(0x04)
	char pad_2D4[0x4]; // 0x2d4(0x04)
	struct UAkAuxBus* EarlyReflectionAuxBus; // 0x2d8(0x08)
	struct FString EarlyReflectionAuxBusName; // 0x2e0(0x10)
	int32_t EarlyReflectionOrder; // 0x2f0(0x04)
	float EarlyReflectionBusSendGain; // 0x2f4(0x04)
	float EarlyReflectionMaxPathLength; // 0x2f8(0x04)
	float roomReverbAuxBusGain; // 0x2fc(0x04)
	int32_t diffractionMaxEdges; // 0x300(0x04)
	int32_t diffractionMaxPaths; // 0x304(0x04)
	float diffractionMaxPathLength; // 0x308(0x04)
	bool DrawFirstOrderReflections; // 0x30c(0x01)
	bool DrawSecondOrderReflections; // 0x30d(0x01)
	bool DrawHigherOrderReflections; // 0x30e(0x01)
	bool DrawDiffraction; // 0x30f(0x01)
	bool StopWhenOwnerDestroyed; // 0x310(0x01)
	char pad_311[0x3]; // 0x311(0x03)
	float AttenuationScalingFactor; // 0x314(0x04)
	float OcclusionRefreshInterval; // 0x318(0x04)
	bool bUseReverbVolumes; // 0x31c(0x01)
	char pad_31D[0x183]; // 0x31d(0x183)

	void UseReverbVolumes(bool inUseReverbVolumes); // Function AkAudio.AkComponent.UseReverbVolumes // (None) // @ game+0xffffb24edf830041
};

// Class AkAudio.AkPortalComponent
// Size: 0x380 (Inherited: 0x2a0)
struct UAkPortalComponent : USceneComponent {
	bool bDynamic; // 0x2a0(0x01)
	enum class AkAcousticPortalState InitialState; // 0x2a1(0x01)
	char pad_2A2[0x2]; // 0x2a2(0x02)
	float ObstructionRefreshInterval; // 0x2a4(0x04)
	enum class ECollisionChannel ObstructionCollisionChannel; // 0x2a8(0x01)
	char pad_2A9[0xd7]; // 0x2a9(0xd7)

	bool PortalPlacementValid(); // Function AkAudio.AkPortalComponent.PortalPlacementValid // (None) // @ game+0xffffb253df830041
};

// Class AkAudio.AkAcousticPortal
// Size: 0x2d8 (Inherited: 0x2c8)
struct AAkAcousticPortal : AVolume {
	struct UAkPortalComponent* Portal; // 0x2c8(0x08)
	enum class AkAcousticPortalState InitialState; // 0x2d0(0x01)
	bool bRequiresStateMigration; // 0x2d1(0x01)
	char pad_2D2[0x6]; // 0x2d2(0x06)

	void OpenPortal(); // Function AkAudio.AkAcousticPortal.OpenPortal // (None) // @ game+0xffffb256df830041
};

// Class AkAudio.AkAudioType
// Size: 0x40 (Inherited: 0x28)
struct UAkAudioType : UObject {
	bool bAutoLoad; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct TArray<struct UObject*> UserData; // 0x30(0x10)

	void UnloadData(); // Function AkAudio.AkAudioType.UnloadData // (None) // @ game+0xffffb259df830041
};

// Class AkAudio.AkAcousticTexture
// Size: 0x50 (Inherited: 0x40)
struct UAkAcousticTexture : UAkAudioType {
	struct FWwiseAcousticTextureCookedData AcousticTextureCookedData; // 0x40(0x0c)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class AkAudio.AkAcousticTextureSetComponent
// Size: 0x2c0 (Inherited: 0x2a0)
struct UAkAcousticTextureSetComponent : USceneComponent {
	struct TWeakObjectPtr<struct APhysicsVolume> PhysicsVolume; // 0xa8(0x08)
	struct USceneComponent* AttachParent; // 0xb0(0x08)
	struct FName AttachSocketName; // 0xb8(0x08)
	struct TArray<struct USceneComponent*> AttachChildren; // 0xc0(0x10)
	struct TArray<struct USceneComponent*> ClientAttachedChildren; // 0xd0(0x10)
	struct FVector RelativeLocation; // 0x128(0x18)
	struct FRotator RelativeRotation; // 0x140(0x18)
	struct FVector RelativeScale3D; // 0x158(0x18)
	struct FVector ComponentVelocity; // 0x170(0x18)
	char bComponentToWorldUpdated : 1; // 0x188(0x01)
	char pad_338_1 : 1; // 0x338(0x01)
	char bAbsoluteLocation : 1; // 0x188(0x01)
	char bAbsoluteRotation : 1; // 0x188(0x01)
	char bAbsoluteScale : 1; // 0x188(0x01)
	char bVisible : 1; // 0x188(0x01)
	char bShouldBeAttached : 1; // 0x188(0x01)
	char bShouldSnapLocationWhenAttached : 1; // 0x188(0x01)
	char bShouldSnapRotationWhenAttached : 1; // 0x189(0x01)
	char bShouldSnapScaleWhenAttached : 1; // 0x189(0x01)
	char bShouldUpdatePhysicsVolume : 1; // 0x189(0x01)
	char bHiddenInGame : 1; // 0x189(0x01)
	char bBoundsChangeTriggersStreamingDataRebuild : 1; // 0x189(0x01)
	char bUseAttachParentBound : 1; // 0x189(0x01)
	char bComputeFastLocalBounds : 1; // 0x189(0x01)
	char bComputeBoundsOnceForGame : 1; // 0x189(0x01)
	char bComputedBoundsOnceForGame : 1; // 0x18a(0x01)
	char bIsNotRenderAttachmentRoot : 1; // 0x18a(0x01)
	enum class EComponentMobility Mobility; // 0x18b(0x01)
	enum class EDetailMode DetailMode; // 0x18c(0x01)
	struct FMulticastSparseDelegate PhysicsVolumeChangedDelegate; // 0x18d(0x01)
};

// Class AkAudio.AkAmbientSound
// Size: 0x2d0 (Inherited: 0x290)
struct AAkAmbientSound : AActor {
	struct UAkAudioEvent* AkAudioEvent; // 0x290(0x08)
	struct UAkComponent* AkComponent; // 0x298(0x08)
	bool StopWhenOwnerIsDestroyed; // 0x2a0(0x01)
	bool AutoPost; // 0x2a1(0x01)
	char pad_2A2[0x2e]; // 0x2a2(0x2e)

	void StopAmbientSound(); // Function AkAudio.AkAmbientSound.StopAmbientSound // (None) // @ game+0xffffb25bdf830041
};

// Class AkAudio.AkAndroidInitializationSettings
// Size: 0x100 (Inherited: 0x28)
struct UAkAndroidInitializationSettings : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // 0x30(0x70)
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // 0xa0(0x20)
	struct FAkAndroidAdvancedInitializationSettings AdvancedSettings; // 0xc0(0x40)

	void MigrateMultiCoreRendering(bool NewValue); // Function AkAudio.AkAndroidInitializationSettings.MigrateMultiCoreRendering // (None) // @ game+0xffffb25cdf830041
};

// Class AkAudio.AkPlatformInfo
// Size: 0x70 (Inherited: 0x28)
struct UAkPlatformInfo : UObject {
	char pad_28[0x48]; // 0x28(0x48)
};

// Class AkAudio.AkAndroidPlatformInfo
// Size: 0x70 (Inherited: 0x70)
struct UAkAndroidPlatformInfo : UAkPlatformInfo {
};

// Class AkAudio.AkAudioBank
// Size: 0x48 (Inherited: 0x40)
struct UAkAudioBank : UAkAudioType {
	bool AutoLoad; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// Class AkAudio.AkAudioEvent
// Size: 0xc0 (Inherited: 0x40)
struct UAkAudioEvent : UAkAudioType {
	float MaxAttenuationRadius; // 0x40(0x04)
	bool IsInfinite; // 0x44(0x01)
	char pad_45[0x3]; // 0x45(0x03)
	float MinimumDuration; // 0x48(0x04)
	float MaximumDuration; // 0x4c(0x04)
	struct FWwiseLocalizedEventCookedData EventCookedData; // 0x50(0x60)
	struct UAkAudioBank* RequiredBank; // 0xb0(0x08)
	char pad_B8[0x8]; // 0xb8(0x08)

	int32_t PostOnGameObjectAndWait(struct UAkGameObject* GameObject, struct FLatentActionInfo LatentActionInfo); // Function AkAudio.AkAudioEvent.PostOnGameObjectAndWait // (None) // @ game+0xffffb264df830041
};

// Class AkAudio.AkAudioInputComponent
// Size: 0x4d0 (Inherited: 0x4a0)
struct UAkAudioInputComponent : UAkComponent {
	bool bUseSpatialAudio; // 0x2c0(0x01)
	enum class EAkCollisionChannel OcclusionCollisionChannel; // 0x2c8(0x01)
	bool EnableSpotReflectors; // 0x2c9(0x01)
	float OuterRadius; // 0x2cc(0x04)
	float InnerRadius; // 0x2d0(0x04)
	struct UAkAuxBus* EarlyReflectionAuxBus; // 0x2d8(0x08)
	struct FString EarlyReflectionAuxBusName; // 0x2e0(0x10)
	int32_t EarlyReflectionOrder; // 0x2f0(0x04)
	float EarlyReflectionBusSendGain; // 0x2f4(0x04)
	float EarlyReflectionMaxPathLength; // 0x2f8(0x04)
	float roomReverbAuxBusGain; // 0x2fc(0x04)
	int32_t diffractionMaxEdges; // 0x300(0x04)
	int32_t diffractionMaxPaths; // 0x304(0x04)
	float diffractionMaxPathLength; // 0x308(0x04)
	bool DrawFirstOrderReflections; // 0x30c(0x01)
	bool DrawSecondOrderReflections; // 0x30d(0x01)
	bool DrawHigherOrderReflections; // 0x30e(0x01)
	bool DrawDiffraction; // 0x30f(0x01)
	bool StopWhenOwnerDestroyed; // 0x310(0x01)
	float AttenuationScalingFactor; // 0x314(0x04)
	float OcclusionRefreshInterval; // 0x318(0x04)
	bool bUseReverbVolumes; // 0x31c(0x01)

	int32_t PostAssociatedAudioInputEvent(); // Function AkAudio.AkAudioInputComponent.PostAssociatedAudioInputEvent // (None) // @ game+0xffffb265df830041
};

// Class AkAudio.AkAuxBus
// Size: 0xb0 (Inherited: 0x40)
struct UAkAuxBus : UAkAudioType {
	struct FWwiseLocalizedAuxBusCookedData AuxBusCookedData; // 0x40(0x60)
	struct UAkAudioBank* RequiredBank; // 0xa0(0x08)
	char pad_A8[0x8]; // 0xa8(0x08)
};

// Class AkAudio.AkCheckBox
// Size: 0xfc0 (Inherited: 0x168)
struct UAkCheckBox : UContentWidget {
	char pad_168[0x290]; // 0x168(0x290)
	enum class ECheckBoxState CheckedState; // 0x3f8(0x01)
	char pad_3F9[0x3]; // 0x3f9(0x03)
	struct FDelegate CheckedStateDelegate; // 0x3fc(0x10)
	char pad_40C[0x4]; // 0x40c(0x04)
	struct FCheckBoxStyle WidgetStyle; // 0x410(0xad0)
	enum class EHorizontalAlignment HorizontalAlignment; // 0xee0(0x01)
	bool IsFocusable; // 0xee1(0x01)
	char pad_EE2[0x6]; // 0xee2(0x06)
	struct FAkBoolPropertyToControl ThePropertyToControl; // 0xee8(0x10)
	struct FAkWwiseItemToControl ItemToControl; // 0xef8(0x40)
	struct FMulticastInlineDelegate AkOnCheckStateChanged; // 0xf38(0x10)
	struct FMulticastInlineDelegate OnItemDropped; // 0xf48(0x10)
	struct FMulticastInlineDelegate OnPropertyDropped; // 0xf58(0x10)
	char pad_F68[0x58]; // 0xf68(0x58)

	void SetIsChecked(bool InIsChecked); // Function AkAudio.AkCheckBox.SetIsChecked // (None) // @ game+0xffffb2b0df830041
};

// Class AkAudio.AkAssetData
// Size: 0x48 (Inherited: 0x28)
struct UAkAssetData : UObject {
	char pad_28[0x20]; // 0x28(0x20)
};

// Class AkAudio.AkAssetPlatformData
// Size: 0x30 (Inherited: 0x28)
struct UAkAssetPlatformData : UObject {
	struct UAkAssetData* CurrentAssetData; // 0x28(0x08)
};

// Class AkAudio.AkMediaAssetData
// Size: 0x38 (Inherited: 0x28)
struct UAkMediaAssetData : UObject {
	char pad_28[0x10]; // 0x28(0x10)
};

// Class AkAudio.AkMediaAsset
// Size: 0x78 (Inherited: 0x28)
struct UAkMediaAsset : UObject {
	struct TMap<struct FString, struct UAkMediaAssetData*> MediaAssetDataPerPlatform; // 0x28(0x50)
};

// Class AkAudio.AkLocalizedMediaAsset
// Size: 0x78 (Inherited: 0x78)
struct UAkLocalizedMediaAsset : UAkMediaAsset {
	struct TMap<struct FString, struct UAkMediaAssetData*> MediaAssetDataPerPlatform; // 0x28(0x50)
};

// Class AkAudio.AkExternalMediaAsset
// Size: 0x78 (Inherited: 0x78)
struct UAkExternalMediaAsset : UAkMediaAsset {
	struct TMap<struct FString, struct UAkMediaAssetData*> MediaAssetDataPerPlatform; // 0x28(0x50)
};

// Class AkAudio.AkFolder
// Size: 0x40 (Inherited: 0x40)
struct UAkFolder : UAkAudioType {
	bool bAutoLoad; // 0x28(0x01)
	struct TArray<struct UObject*> UserData; // 0x30(0x10)
};

// Class AkAudio.DrawPortalComponent
// Size: 0x540 (Inherited: 0x540)
struct UDrawPortalComponent : UPrimitiveComponent {
	float MinDrawDistance; // 0x2b0(0x04)
	float LDMaxDrawDistance; // 0x2b4(0x04)
	float CachedMaxDrawDistance; // 0x2b8(0x04)
	enum class ESceneDepthPriorityGroup DepthPriorityGroup; // 0x2bc(0x01)
	enum class ESceneDepthPriorityGroup ViewOwnerDepthPriorityGroup; // 0x2bd(0x01)
	enum class EIndirectLightingCacheQuality IndirectLightingCacheQuality; // 0x2be(0x01)
	enum class ELightmapType LightmapType; // 0x2bf(0x01)
	char bIsValidTextureStreamingBuiltData : 1; // 0x2c0(0x01)
	char bNeverDistanceCull : 1; // 0x2c0(0x01)
	char pad_550_2 : 5; // 0x550(0x01)
	char bAlwaysCreatePhysicsState : 1; // 0x2c0(0x01)
	char bGenerateOverlapEvents : 1; // 0x2c1(0x01)
	char bMultiBodyOverlap : 1; // 0x2c1(0x01)
	char bTraceComplexOnMove : 1; // 0x2c1(0x01)
	char bReturnMaterialOnMove : 1; // 0x2c1(0x01)
	char bUseViewOwnerDepthPriorityGroup : 1; // 0x2c1(0x01)
	char bAllowCullDistanceVolume : 1; // 0x2c1(0x01)
	char bVisibleInReflectionCaptures : 1; // 0x2c1(0x01)
	char bVisibleInRealTimeSkyCaptures : 1; // 0x2c1(0x01)
	char bVisibleInRayTracing : 1; // 0x2c2(0x01)
	char bRenderInMainPass : 1; // 0x2c2(0x01)
	char bRenderInDepthPass : 1; // 0x2c2(0x01)
	char bReceivesDecals : 1; // 0x2c2(0x01)
	char bOwnerNoSee : 1; // 0x2c2(0x01)
	char bOnlyOwnerSee : 1; // 0x2c2(0x01)
	char bTreatAsBackgroundForOcclusion : 1; // 0x2c2(0x01)
	char bUseAsOccluder : 1; // 0x2c2(0x01)
	char bSelectable : 1; // 0x2c3(0x01)
	char bForceMipStreaming : 1; // 0x2c3(0x01)
	char bHasPerInstanceHitProxies : 1; // 0x2c3(0x01)
	char CastShadow : 1; // 0x2c3(0x01)
	char bEmissiveLightSource : 1; // 0x2c3(0x01)
	char bAffectDynamicIndirectLighting : 1; // 0x2c3(0x01)
	char bAffectIndirectLightingWhileHidden : 1; // 0x2c3(0x01)
	char bAffectDistanceFieldLighting : 1; // 0x2c3(0x01)
	char bCastDynamicShadow : 1; // 0x2c4(0x01)
	char bCastStaticShadow : 1; // 0x2c4(0x01)
	char bCastVolumetricTranslucentShadow : 1; // 0x2c4(0x01)
	char bCastContactShadow : 1; // 0x2c4(0x01)
	char bSelfShadowOnly : 1; // 0x2c4(0x01)
	char bCastFarShadow : 1; // 0x2c4(0x01)
	char bCastInsetShadow : 1; // 0x2c4(0x01)
	char bCastCinematicShadow : 1; // 0x2c4(0x01)
	char bCastHiddenShadow : 1; // 0x2c5(0x01)
	char bCastShadowAsTwoSided : 1; // 0x2c5(0x01)
	char bLightAsIfStatic : 1; // 0x2c5(0x01)
	char bLightAttachmentsAsGroup : 1; // 0x2c5(0x01)
	char bExcludeFromLightAttachmentGroup : 1; // 0x2c5(0x01)
	char bReceiveMobileCSMShadows : 1; // 0x2c5(0x01)
	char bSingleSampleShadowFromStationaryLights : 1; // 0x2c5(0x01)
	char bIgnoreRadialImpulse : 1; // 0x2c5(0x01)
	char bIgnoreRadialForce : 1; // 0x2c6(0x01)
	char bApplyImpulseOnDamage : 1; // 0x2c6(0x01)
	char bReplicatePhysicsToAutonomousProxy : 1; // 0x2c6(0x01)
	char bFillCollisionUnderneathForNavmesh : 1; // 0x2c6(0x01)
	char AlwaysLoadOnClient : 1; // 0x2c6(0x01)
	char AlwaysLoadOnServer : 1; // 0x2c6(0x01)
	char bUseEditorCompositing : 1; // 0x2c6(0x01)
	char bIsBeingMovedByEditor : 1; // 0x2c6(0x01)
	char bRenderCustomDepth : 1; // 0x2c7(0x01)
	char bVisibleInSceneCaptureOnly : 1; // 0x2c7(0x01)
	char bHiddenInSceneCapture : 1; // 0x2c7(0x01)
	char bRayTracingFarField : 1; // 0x2c7(0x01)
	char pad_557_4 : 1; // 0x557(0x01)
	char bHasNoStreamableTextures : 1; // 0x2c7(0x01)
	enum class EHasCustomNavigableGeometry bHasCustomNavigableGeometry; // 0x2c8(0x01)
	enum class ECanBeCharacterBase CanCharacterStepUpOn; // 0x2ca(0x01)
	struct FLightingChannels LightingChannels; // 0x2cb(0x01)
	int32_t RayTracingGroupId; // 0x2cc(0x04)
	int32_t VisibilityId; // 0x2d0(0x04)
	int32_t CustomDepthStencilValue; // 0x2d4(0x04)
	struct FCustomPrimitiveData CustomPrimitiveData; // 0x2d8(0x10)
	struct FCustomPrimitiveData CustomPrimitiveDataInternal; // 0x2e8(0x10)
	int32_t TranslucencySortPriority; // 0x300(0x04)
	float TranslucencySortDistanceOffset; // 0x304(0x04)
	struct TArray<struct URuntimeVirtualTexture*> RuntimeVirtualTextures; // 0x308(0x10)
	int8_t VirtualTextureLodBias; // 0x318(0x01)
	int8_t VirtualTextureCullMips; // 0x319(0x01)
	int8_t VirtualTextureMinCoverage; // 0x31a(0x01)
	enum class ERuntimeVirtualTextureMainPassType VirtualTextureRenderPassType; // 0x31b(0x01)
	float BoundsScale; // 0x32c(0x04)
	struct TArray<struct AActor*> MoveIgnoreActors; // 0x340(0x10)
	struct TArray<struct UPrimitiveComponent*> MoveIgnoreComponents; // 0x350(0x10)
	struct FBodyInstance BodyInstance; // 0x370(0x190)
	struct FMulticastSparseDelegate OnComponentHit; // 0x500(0x01)
	struct FMulticastSparseDelegate OnComponentBeginOverlap; // 0x501(0x01)
	struct FMulticastSparseDelegate OnComponentEndOverlap; // 0x502(0x01)
	struct FMulticastSparseDelegate OnComponentWake; // 0x503(0x01)
	struct FMulticastSparseDelegate OnComponentSleep; // 0x504(0x01)
	struct FMulticastSparseDelegate OnComponentPhysicsStateChanged; // 0x506(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x507(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x508(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x509(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x50a(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x50b(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x50c(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x50d(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x50e(0x01)
	enum class ERayTracingGroupCullingPriority RayTracingGroupCullingPriority; // 0x50f(0x01)
	enum class ERendererStencilMask CustomDepthStencilWriteMask; // 0x510(0x01)
	struct UPrimitiveComponent* LODParentPrimitive; // 0x530(0x08)
};

// Class AkAudio.DrawRoomComponent
// Size: 0x540 (Inherited: 0x540)
struct UDrawRoomComponent : UPrimitiveComponent {
	float MinDrawDistance; // 0x2b0(0x04)
	float LDMaxDrawDistance; // 0x2b4(0x04)
	float CachedMaxDrawDistance; // 0x2b8(0x04)
	enum class ESceneDepthPriorityGroup DepthPriorityGroup; // 0x2bc(0x01)
	enum class ESceneDepthPriorityGroup ViewOwnerDepthPriorityGroup; // 0x2bd(0x01)
	enum class EIndirectLightingCacheQuality IndirectLightingCacheQuality; // 0x2be(0x01)
	enum class ELightmapType LightmapType; // 0x2bf(0x01)
	char bIsValidTextureStreamingBuiltData : 1; // 0x2c0(0x01)
	char bNeverDistanceCull : 1; // 0x2c0(0x01)
	char pad_550_2 : 5; // 0x550(0x01)
	char bAlwaysCreatePhysicsState : 1; // 0x2c0(0x01)
	char bGenerateOverlapEvents : 1; // 0x2c1(0x01)
	char bMultiBodyOverlap : 1; // 0x2c1(0x01)
	char bTraceComplexOnMove : 1; // 0x2c1(0x01)
	char bReturnMaterialOnMove : 1; // 0x2c1(0x01)
	char bUseViewOwnerDepthPriorityGroup : 1; // 0x2c1(0x01)
	char bAllowCullDistanceVolume : 1; // 0x2c1(0x01)
	char bVisibleInReflectionCaptures : 1; // 0x2c1(0x01)
	char bVisibleInRealTimeSkyCaptures : 1; // 0x2c1(0x01)
	char bVisibleInRayTracing : 1; // 0x2c2(0x01)
	char bRenderInMainPass : 1; // 0x2c2(0x01)
	char bRenderInDepthPass : 1; // 0x2c2(0x01)
	char bReceivesDecals : 1; // 0x2c2(0x01)
	char bOwnerNoSee : 1; // 0x2c2(0x01)
	char bOnlyOwnerSee : 1; // 0x2c2(0x01)
	char bTreatAsBackgroundForOcclusion : 1; // 0x2c2(0x01)
	char bUseAsOccluder : 1; // 0x2c2(0x01)
	char bSelectable : 1; // 0x2c3(0x01)
	char bForceMipStreaming : 1; // 0x2c3(0x01)
	char bHasPerInstanceHitProxies : 1; // 0x2c3(0x01)
	char CastShadow : 1; // 0x2c3(0x01)
	char bEmissiveLightSource : 1; // 0x2c3(0x01)
	char bAffectDynamicIndirectLighting : 1; // 0x2c3(0x01)
	char bAffectIndirectLightingWhileHidden : 1; // 0x2c3(0x01)
	char bAffectDistanceFieldLighting : 1; // 0x2c3(0x01)
	char bCastDynamicShadow : 1; // 0x2c4(0x01)
	char bCastStaticShadow : 1; // 0x2c4(0x01)
	char bCastVolumetricTranslucentShadow : 1; // 0x2c4(0x01)
	char bCastContactShadow : 1; // 0x2c4(0x01)
	char bSelfShadowOnly : 1; // 0x2c4(0x01)
	char bCastFarShadow : 1; // 0x2c4(0x01)
	char bCastInsetShadow : 1; // 0x2c4(0x01)
	char bCastCinematicShadow : 1; // 0x2c4(0x01)
	char bCastHiddenShadow : 1; // 0x2c5(0x01)
	char bCastShadowAsTwoSided : 1; // 0x2c5(0x01)
	char bLightAsIfStatic : 1; // 0x2c5(0x01)
	char bLightAttachmentsAsGroup : 1; // 0x2c5(0x01)
	char bExcludeFromLightAttachmentGroup : 1; // 0x2c5(0x01)
	char bReceiveMobileCSMShadows : 1; // 0x2c5(0x01)
	char bSingleSampleShadowFromStationaryLights : 1; // 0x2c5(0x01)
	char bIgnoreRadialImpulse : 1; // 0x2c5(0x01)
	char bIgnoreRadialForce : 1; // 0x2c6(0x01)
	char bApplyImpulseOnDamage : 1; // 0x2c6(0x01)
	char bReplicatePhysicsToAutonomousProxy : 1; // 0x2c6(0x01)
	char bFillCollisionUnderneathForNavmesh : 1; // 0x2c6(0x01)
	char AlwaysLoadOnClient : 1; // 0x2c6(0x01)
	char AlwaysLoadOnServer : 1; // 0x2c6(0x01)
	char bUseEditorCompositing : 1; // 0x2c6(0x01)
	char bIsBeingMovedByEditor : 1; // 0x2c6(0x01)
	char bRenderCustomDepth : 1; // 0x2c7(0x01)
	char bVisibleInSceneCaptureOnly : 1; // 0x2c7(0x01)
	char bHiddenInSceneCapture : 1; // 0x2c7(0x01)
	char bRayTracingFarField : 1; // 0x2c7(0x01)
	char pad_557_4 : 1; // 0x557(0x01)
	char bHasNoStreamableTextures : 1; // 0x2c7(0x01)
	enum class EHasCustomNavigableGeometry bHasCustomNavigableGeometry; // 0x2c8(0x01)
	enum class ECanBeCharacterBase CanCharacterStepUpOn; // 0x2ca(0x01)
	struct FLightingChannels LightingChannels; // 0x2cb(0x01)
	int32_t RayTracingGroupId; // 0x2cc(0x04)
	int32_t VisibilityId; // 0x2d0(0x04)
	int32_t CustomDepthStencilValue; // 0x2d4(0x04)
	struct FCustomPrimitiveData CustomPrimitiveData; // 0x2d8(0x10)
	struct FCustomPrimitiveData CustomPrimitiveDataInternal; // 0x2e8(0x10)
	int32_t TranslucencySortPriority; // 0x300(0x04)
	float TranslucencySortDistanceOffset; // 0x304(0x04)
	struct TArray<struct URuntimeVirtualTexture*> RuntimeVirtualTextures; // 0x308(0x10)
	int8_t VirtualTextureLodBias; // 0x318(0x01)
	int8_t VirtualTextureCullMips; // 0x319(0x01)
	int8_t VirtualTextureMinCoverage; // 0x31a(0x01)
	enum class ERuntimeVirtualTextureMainPassType VirtualTextureRenderPassType; // 0x31b(0x01)
	float BoundsScale; // 0x32c(0x04)
	struct TArray<struct AActor*> MoveIgnoreActors; // 0x340(0x10)
	struct TArray<struct UPrimitiveComponent*> MoveIgnoreComponents; // 0x350(0x10)
	struct FBodyInstance BodyInstance; // 0x370(0x190)
	struct FMulticastSparseDelegate OnComponentHit; // 0x500(0x01)
	struct FMulticastSparseDelegate OnComponentBeginOverlap; // 0x501(0x01)
	struct FMulticastSparseDelegate OnComponentEndOverlap; // 0x502(0x01)
	struct FMulticastSparseDelegate OnComponentWake; // 0x503(0x01)
	struct FMulticastSparseDelegate OnComponentSleep; // 0x504(0x01)
	struct FMulticastSparseDelegate OnComponentPhysicsStateChanged; // 0x506(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x507(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x508(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x509(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x50a(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x50b(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x50c(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x50d(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x50e(0x01)
	enum class ERayTracingGroupCullingPriority RayTracingGroupCullingPriority; // 0x50f(0x01)
	enum class ERendererStencilMask CustomDepthStencilWriteMask; // 0x510(0x01)
	struct UPrimitiveComponent* LODParentPrimitive; // 0x530(0x08)
};

// Class AkAudio.AkEffectShareSet
// Size: 0xa8 (Inherited: 0x40)
struct UAkEffectShareSet : UAkAudioType {
	struct FWwiseLocalizedShareSetCookedData ShareSetCookedData; // 0x40(0x60)
	char pad_A0[0x8]; // 0xa0(0x08)
};

// Class AkAudio.AkGameplayStatics
// Size: 0x28 (Inherited: 0x28)
struct UAkGameplayStatics : UBlueprintFunctionLibrary {

	void UseReverbVolumes(bool inUseReverbVolumes, struct AActor* Actor); // Function AkAudio.AkGameplayStatics.UseReverbVolumes // (None) // @ game+0xffffb2abdf830041
};

// Class AkAudio.AkCallbackInfo
// Size: 0x30 (Inherited: 0x28)
struct UAkCallbackInfo : UObject {
	struct UAkComponent* AkComponent; // 0x28(0x08)
};

// Class AkAudio.AkEventCallbackInfo
// Size: 0x38 (Inherited: 0x30)
struct UAkEventCallbackInfo : UAkCallbackInfo {
	int32_t PlayingID; // 0x30(0x04)
	int32_t EventId; // 0x34(0x04)
};

// Class AkAudio.AkMIDIEventCallbackInfo
// Size: 0x48 (Inherited: 0x38)
struct UAkMIDIEventCallbackInfo : UAkEventCallbackInfo {
	int32_t PlayingID; // 0x30(0x04)
	int32_t EventId; // 0x34(0x04)
	char pad_40[0x8]; // 0x40(0x08)

	enum class EAkMidiEventType GetType(); // Function AkAudio.AkMIDIEventCallbackInfo.GetType // (None) // @ game+0xffffb2b5df830041
};

// Class AkAudio.AkMarkerCallbackInfo
// Size: 0x50 (Inherited: 0x38)
struct UAkMarkerCallbackInfo : UAkEventCallbackInfo {
	int32_t Identifier; // 0x38(0x04)
	int32_t Position; // 0x3c(0x04)
	struct FString Label; // 0x40(0x10)
};

// Class AkAudio.AkDurationCallbackInfo
// Size: 0x50 (Inherited: 0x38)
struct UAkDurationCallbackInfo : UAkEventCallbackInfo {
	float Duration; // 0x38(0x04)
	float EstimatedDuration; // 0x3c(0x04)
	int32_t AudioNodeID; // 0x40(0x04)
	int32_t MediaId; // 0x44(0x04)
	bool bStreaming; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class AkAudio.AkMusicSyncCallbackInfo
// Size: 0x70 (Inherited: 0x30)
struct UAkMusicSyncCallbackInfo : UAkCallbackInfo {
	int32_t PlayingID; // 0x30(0x04)
	struct FAkSegmentInfo SegmentInfo; // 0x34(0x24)
	enum class EAkCallbackType MusicSyncType; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct FString UserCueName; // 0x60(0x10)
};

// Class AkAudio.AkGeometryComponent
// Size: 0x440 (Inherited: 0x2c0)
struct UAkGeometryComponent : UAkAcousticTextureSetComponent {
	enum class AkMeshType MeshType; // 0x2b8(0x01)
	int32_t LOD; // 0x2bc(0x04)
	float WeldingThreshold; // 0x2c0(0x04)
	struct TMap<struct UMaterialInterface*, struct FAkGeometrySurfaceOverride> StaticMeshSurfaceOverride; // 0x2c8(0x50)
	struct FAkGeometrySurfaceOverride CollisionMeshSurfaceOverride; // 0x318(0x18)
	bool bEnableDiffraction; // 0x330(0x01)
	bool bEnableDiffractionOnBoundaryEdges; // 0x331(0x01)
	char pad_333[0x5]; // 0x333(0x05)
	struct AActor* AssociatedRoom; // 0x338(0x08)
	char pad_340[0x10]; // 0x340(0x10)
	struct FAkGeometryData GeometryData; // 0x350(0x50)
	struct TMap<int32_t, double> SurfaceAreas; // 0x3a0(0x50)
	char pad_3F0[0x50]; // 0x3f0(0x50)

	void UpdateGeometry(); // Function AkAudio.AkGeometryComponent.UpdateGeometry // (None) // @ game+0xffffb2b9df830041
};

// Class AkAudio.AkGroupValue
// Size: 0x60 (Inherited: 0x40)
struct UAkGroupValue : UAkAudioType {
	struct FWwiseGroupValueCookedData GroupValueCookedData; // 0x40(0x14)
	uint32_t GroupShortId; // 0x54(0x04)
	char pad_58[0x8]; // 0x58(0x08)
};

// Class AkAudio.AkHololensInitializationSettings
// Size: 0x100 (Inherited: 0x28)
struct UAkHololensInitializationSettings : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // 0x30(0x70)
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // 0xa0(0x20)
	struct FAkHololensAdvancedInitializationSettings AdvancedSettings; // 0xc0(0x3c)
	char pad_FC[0x4]; // 0xfc(0x04)

	void MigrateMultiCoreRendering(bool NewValue); // Function AkAudio.AkHololensInitializationSettings.MigrateMultiCoreRendering // (None) // @ game+0xffffb2badf830041
};

// Class AkAudio.AkHololensPlatformInfo
// Size: 0x70 (Inherited: 0x70)
struct UAkHololensPlatformInfo : UAkPlatformInfo {
};

// Class AkAudio.AkInitBank
// Size: 0x88 (Inherited: 0x40)
struct UAkInitBank : UAkAudioType {
	struct FWwiseInitBankCookedData InitBankCookedData; // 0x40(0x40)
	char pad_80[0x8]; // 0x80(0x08)
};

// Class AkAudio.AkIOSInitializationSettings
// Size: 0x108 (Inherited: 0x28)
struct UAkIOSInitializationSettings : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // 0x30(0x70)
	struct FAkAudioSession AudioSession; // 0xa0(0x0c)
	char pad_AC[0x4]; // 0xac(0x04)
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // 0xb0(0x20)
	struct FAkAdvancedInitializationSettingsWithMultiCoreRendering AdvancedSettings; // 0xd0(0x38)
};

// Class AkAudio.AkIOSPlatformInfo
// Size: 0x70 (Inherited: 0x70)
struct UAkIOSPlatformInfo : UAkPlatformInfo {
};

// Class AkAudio.AkItemBoolPropertiesConv
// Size: 0x28 (Inherited: 0x28)
struct UAkItemBoolPropertiesConv : UBlueprintFunctionLibrary {

	struct FText Conv_FAkBoolPropertyToControlToText(struct FAkBoolPropertyToControl& INAkBoolPropertyToControl); // Function AkAudio.AkItemBoolPropertiesConv.Conv_FAkBoolPropertyToControlToText // (None) // @ game+0xffffb2bcdf830041
};

// Class AkAudio.AkItemBoolProperties
// Size: 0x190 (Inherited: 0x150)
struct UAkItemBoolProperties : UWidget {
	struct FMulticastInlineDelegate OnSelectionChanged; // 0x150(0x10)
	struct FMulticastInlineDelegate OnPropertyDragged; // 0x160(0x10)
	char pad_170[0x20]; // 0x170(0x20)

	void SetSearchText(struct FString newText); // Function AkAudio.AkItemBoolProperties.SetSearchText // (None) // @ game+0xffffb2bfdf830041
};

// Class AkAudio.AkItemPropertiesConv
// Size: 0x28 (Inherited: 0x28)
struct UAkItemPropertiesConv : UBlueprintFunctionLibrary {

	struct FText Conv_FAkPropertyToControlToText(struct FAkPropertyToControl& INAkPropertyToControl); // Function AkAudio.AkItemPropertiesConv.Conv_FAkPropertyToControlToText // (None) // @ game+0xffffb2c1df830041
};

// Class AkAudio.AkItemProperties
// Size: 0x190 (Inherited: 0x150)
struct UAkItemProperties : UWidget {
	struct FMulticastInlineDelegate OnSelectionChanged; // 0x150(0x10)
	struct FMulticastInlineDelegate OnPropertyDragged; // 0x160(0x10)
	char pad_170[0x20]; // 0x170(0x20)

	void SetSearchText(struct FString newText); // Function AkAudio.AkItemProperties.SetSearchText // (None) // @ game+0xffffb2c4df830041
};

// Class AkAudio.AkLateReverbComponent
// Size: 0x330 (Inherited: 0x2a0)
struct UAkLateReverbComponent : USceneComponent {
	bool bEnable; // 0x2a0(0x01)
	char pad_2A1[0x3]; // 0x2a1(0x03)
	float SendLevel; // 0x2a4(0x04)
	float FadeRate; // 0x2a8(0x04)
	float Priority; // 0x2ac(0x04)
	bool AutoAssignAuxBus; // 0x2b0(0x01)
	char pad_2B1[0x7]; // 0x2b1(0x07)
	struct UAkAuxBus* AuxBus; // 0x2b8(0x08)
	struct FString AuxBusName; // 0x2c0(0x10)
	char pad_2D0[0x8]; // 0x2d0(0x08)
	struct UAkAuxBus* AuxBusManual; // 0x2d8(0x08)
	char pad_2E0[0x50]; // 0x2e0(0x50)

	void AssociateAkTextureSetComponent(struct UAkAcousticTextureSetComponent* textureSetComponent); // Function AkAudio.AkLateReverbComponent.AssociateAkTextureSetComponent // (None) // @ game+0xffffb2c5df830041
};

// Class AkAudio.AkLinuxInitializationSettings
// Size: 0xf8 (Inherited: 0x28)
struct UAkLinuxInitializationSettings : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // 0x30(0x70)
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // 0xa0(0x20)
	struct FAkAdvancedInitializationSettingsWithMultiCoreRendering AdvancedSettings; // 0xc0(0x38)

	void MigrateMultiCoreRendering(bool NewValue); // Function AkAudio.AkLinuxInitializationSettings.MigrateMultiCoreRendering // (None) // @ game+0xffffb2c6df830041
};

// Class AkAudio.AkLinuxPlatformInfo
// Size: 0x70 (Inherited: 0x70)
struct UAkLinuxPlatformInfo : UAkPlatformInfo {
};

// Class AkAudio.AkMacInitializationSettings
// Size: 0xf8 (Inherited: 0x28)
struct UAkMacInitializationSettings : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // 0x30(0x70)
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // 0xa0(0x20)
	struct FAkAdvancedInitializationSettingsWithMultiCoreRendering AdvancedSettings; // 0xc0(0x38)

	void MigrateMultiCoreRendering(bool NewValue); // Function AkAudio.AkMacInitializationSettings.MigrateMultiCoreRendering // (None) // @ game+0xffffb2c7df830041
};

// Class AkAudio.AkMacPlatformInfo
// Size: 0x70 (Inherited: 0x70)
struct UAkMacPlatformInfo : UAkPlatformInfo {
};

// Class AkAudio.AkPlatformInitialisationSettingsBase
// Size: 0x28 (Inherited: 0x28)
struct UAkPlatformInitialisationSettingsBase : UInterface {
};

// Class AkAudio.AkReverbVolume
// Size: 0x300 (Inherited: 0x2c8)
struct AAkReverbVolume : AVolume {
	bool bEnabled; // 0x2c8(0x01)
	char pad_2C9[0x7]; // 0x2c9(0x07)
	struct UAkAuxBus* AuxBus; // 0x2d0(0x08)
	struct FString AuxBusName; // 0x2d8(0x10)
	float SendLevel; // 0x2e8(0x04)
	float FadeRate; // 0x2ec(0x04)
	float Priority; // 0x2f0(0x04)
	char pad_2F4[0x4]; // 0x2f4(0x04)
	struct UAkLateReverbComponent* LateReverbComponent; // 0x2f8(0x08)
};

// Class AkAudio.AkRoomComponent
// Size: 0x2f0 (Inherited: 0x2c0)
struct UAkRoomComponent : UAkGameObject {
	bool bEnable; // 0x2c0(0x01)
	bool bDynamic; // 0x2c1(0x01)
	char pad_2C2[0x2]; // 0x2c2(0x02)
	float Priority; // 0x2c4(0x04)
	float WallOcclusion; // 0x2c8(0x04)
	float AuxSendLevel; // 0x2cc(0x04)
	bool AutoPost; // 0x2d0(0x01)
	char pad_2D1[0xf]; // 0x2d1(0x0f)
	struct UAkAcousticTextureSetComponent* GeometryComponent; // 0x2e0(0x08)
	char pad_2E8[0x8]; // 0x2e8(0x08)

	void SetGeometryComponent(struct UAkAcousticTextureSetComponent* textureSetComponent); // Function AkAudio.AkRoomComponent.SetGeometryComponent // (None) // @ game+0xffffb2c9df830041
};

// Class AkAudio.AkRtpc
// Size: 0x50 (Inherited: 0x40)
struct UAkRtpc : UAkAudioType {
	struct FWwiseGameParameterCookedData GameParameterCookedData; // 0x40(0x0c)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class AkAudio.AkSettings
// Size: 0x370 (Inherited: 0x28)
struct UAkSettings : UObject {
	char MaxSimultaneousReverbVolumes; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FFilePath WwiseProjectPath; // 0x30(0x10)
	struct FDirectoryPath WwiseSoundDataFolder; // 0x40(0x10)
	struct FDirectoryPath GeneratedSoundBanksFolder; // 0x50(0x10)
	struct FDirectoryPath WwiseStagingDirectory; // 0x60(0x10)
	bool bSoundBanksTransfered; // 0x70(0x01)
	bool bAssetsMigrated; // 0x71(0x01)
	bool bProjectMigrated; // 0x72(0x01)
	bool bAutoConnectToWAAPI; // 0x73(0x01)
	enum class ECollisionChannel DefaultOcclusionCollisionChannel; // 0x74(0x01)
	enum class ECollisionChannel DefaultFitToGeometryCollisionChannel; // 0x75(0x01)
	char pad_76[0x2]; // 0x76(0x02)
	struct TMap<struct TSoftObjectPtr<UPhysicalMaterial>, struct FAkGeometrySurfacePropertiesToMap> AkGeometryMap; // 0x78(0x50)
	float GlobalDecayAbsorption; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
	struct TSoftObjectPtr<UAkAuxBus> DefaultReverbAuxBus; // 0xd0(0x30)
	struct TMap<float, struct TSoftObjectPtr<UAkAuxBus>> EnvironmentDecayAuxBusMap; // 0x100(0x50)
	struct FString HFDampingName; // 0x150(0x10)
	struct FString DecayEstimateName; // 0x160(0x10)
	struct FString TimeToFirstReflectionName; // 0x170(0x10)
	struct TSoftObjectPtr<UAkRtpc> HFDampingRTPC; // 0x180(0x30)
	struct TSoftObjectPtr<UAkRtpc> DecayEstimateRTPC; // 0x1b0(0x30)
	struct TSoftObjectPtr<UAkRtpc> TimeToFirstReflectionRTPC; // 0x1e0(0x30)
	struct TSoftObjectPtr<UAkAudioEvent> AudioInputEvent; // 0x210(0x30)
	struct TMap<struct FGuid, struct FAkAcousticTextureParams> AcousticTextureParamsMap; // 0x240(0x50)
	bool SplitSwitchContainerMedia; // 0x290(0x01)
	bool SplitMediaPerFolder; // 0x291(0x01)
	bool UseEventBasedPackaging; // 0x292(0x01)
	char pad_293[0x5]; // 0x293(0x05)
	struct FString CommandletCommitMessage; // 0x298(0x10)
	struct TMap<struct FString, struct FString> UnrealCultureToWwiseCulture; // 0x2a8(0x50)
	struct FString DefaultAssetCreationPath; // 0x2f8(0x10)
	struct TSoftObjectPtr<UAkInitBank> InitBank; // 0x308(0x30)
	enum class EAkUnrealAudioRouting AudioRouting; // 0x338(0x04)
	bool bWwiseSoundEngineEnabled; // 0x33c(0x01)
	bool bWwiseAudioLinkEnabled; // 0x33d(0x01)
	bool bAkAudioMixerEnabled; // 0x33e(0x01)
	bool AskedToUseNewAssetManagement; // 0x33f(0x01)
	bool bEnableMultiCoreRendering; // 0x340(0x01)
	bool MigratedEnableMultiCoreRendering; // 0x341(0x01)
	bool FixupRedirectorsDuringMigration; // 0x342(0x01)
	char pad_343[0x5]; // 0x343(0x05)
	struct FDirectoryPath WwiseWindowsInstallationPath; // 0x348(0x10)
	struct FFilePath WwiseMacInstallationPath; // 0x358(0x10)
	char pad_368[0x8]; // 0x368(0x08)
};

// Class AkAudio.AkSettingsPerUser
// Size: 0x78 (Inherited: 0x28)
struct UAkSettingsPerUser : UObject {
	struct FDirectoryPath WwiseWindowsInstallationPath; // 0x28(0x10)
	struct FFilePath WwiseMacInstallationPath; // 0x38(0x10)
	struct FDirectoryPath GeneratedSoundBanksFolderUserOverride; // 0x48(0x10)
	struct FString WaapiIPAddress; // 0x58(0x10)
	uint32_t WaapiPort; // 0x68(0x04)
	bool bAutoConnectToWAAPI; // 0x6c(0x01)
	bool AutoSyncSelection; // 0x6d(0x01)
	char pad_6E[0x2]; // 0x6e(0x02)
	uint32_t WaapiTranslatorTimeout; // 0x70(0x04)
	bool SuppressGeneratedSoundBanksPathWarnings; // 0x74(0x01)
	bool SoundDataGenerationSkipLanguage; // 0x75(0x01)
	bool AskForWwiseAssetReload; // 0x76(0x01)
	char pad_77[0x1]; // 0x77(0x01)
};

// Class AkAudio.AkSlider
// Size: 0x740 (Inherited: 0x150)
struct UAkSlider : UWidget {
	float Value; // 0x150(0x04)
	struct FDelegate ValueDelegate; // 0x154(0x10)
	char pad_164[0xc]; // 0x164(0x0c)
	struct FSliderStyle WidgetStyle; // 0x170(0x500)
	enum class EOrientation Orientation; // 0x670(0x01)
	char pad_671[0x3]; // 0x671(0x03)
	struct FLinearColor SliderBarColor; // 0x674(0x10)
	struct FLinearColor SliderHandleColor; // 0x684(0x10)
	bool IndentHandle; // 0x694(0x01)
	bool Locked; // 0x695(0x01)
	char pad_696[0x2]; // 0x696(0x02)
	float StepSize; // 0x698(0x04)
	bool IsFocusable; // 0x69c(0x01)
	char pad_69D[0x3]; // 0x69d(0x03)
	struct FAkPropertyToControl ThePropertyToControl; // 0x6a0(0x10)
	struct FAkWwiseItemToControl ItemToControl; // 0x6b0(0x40)
	struct FMulticastInlineDelegate OnValueChanged; // 0x6f0(0x10)
	struct FMulticastInlineDelegate OnItemDropped; // 0x700(0x10)
	struct FMulticastInlineDelegate OnPropertyDropped; // 0x710(0x10)
	char pad_720[0x20]; // 0x720(0x20)

	void SetValue(float InValue); // Function AkAudio.AkSlider.SetValue // (None) // @ game+0xffffb2d4df830041
};

// Class AkAudio.AkSpatialAudioVolume
// Size: 0x2e0 (Inherited: 0x2c8)
struct AAkSpatialAudioVolume : AVolume {
	struct UAkSurfaceReflectorSetComponent* SurfaceReflectorSet; // 0x2c8(0x08)
	struct UAkLateReverbComponent* LateReverb; // 0x2d0(0x08)
	struct UAkRoomComponent* Room; // 0x2d8(0x08)
};

// Class AkAudio.AkSpotReflector
// Size: 0x2c8 (Inherited: 0x290)
struct AAkSpotReflector : AActor {
	struct UAkAuxBus* EarlyReflectionAuxBus; // 0x290(0x08)
	struct FString EarlyReflectionAuxBusName; // 0x298(0x10)
	struct UAkAcousticTexture* AcousticTexture; // 0x2a8(0x08)
	float DistanceScalingFactor; // 0x2b0(0x04)
	float Level; // 0x2b4(0x04)
	bool SameRoomOnly; // 0x2b8(0x01)
	bool EnableRoomOverride; // 0x2b9(0x01)
	char pad_2BA[0x6]; // 0x2ba(0x06)
	struct AActor* RoomOverride; // 0x2c0(0x08)
};

// Class AkAudio.AkStateValue
// Size: 0x60 (Inherited: 0x60)
struct UAkStateValue : UAkGroupValue {
	struct FWwiseGroupValueCookedData GroupValueCookedData; // 0x40(0x14)
	uint32_t GroupShortId; // 0x54(0x04)
};

// Class AkAudio.AkSubmixInputComponent
// Size: 0x520 (Inherited: 0x4d0)
struct UAkSubmixInputComponent : UAkAudioInputComponent {
	struct USoundSubmix* SubmixToRecord; // 0x4d0(0x08)
	char pad_4D8[0x48]; // 0x4d8(0x48)
};

// Class AkAudio.AkSurfaceReflectorSetComponent
// Size: 0x2f0 (Inherited: 0x2c0)
struct UAkSurfaceReflectorSetComponent : UAkAcousticTextureSetComponent {
	bool bEnableSurfaceReflectors; // 0x2b8(0x01)
	struct TArray<struct FAkSurfacePoly> AcousticPolys; // 0x2c0(0x10)
	bool bEnableDiffraction; // 0x2d0(0x01)
	bool bEnableDiffractionOnBoundaryEdges; // 0x2d1(0x01)
	char pad_2D3[0x5]; // 0x2d3(0x05)
	struct AActor* AssociatedRoom; // 0x2d8(0x08)
	char pad_2E0[0x10]; // 0x2e0(0x10)

	void UpdateSurfaceReflectorSet(); // Function AkAudio.AkSurfaceReflectorSetComponent.UpdateSurfaceReflectorSet // (None) // @ game+0xffffb2d8df830041
};

// Class AkAudio.AkSwitchValue
// Size: 0x60 (Inherited: 0x60)
struct UAkSwitchValue : UAkGroupValue {
	struct FWwiseGroupValueCookedData GroupValueCookedData; // 0x40(0x14)
	uint32_t GroupShortId; // 0x54(0x04)
};

// Class AkAudio.AkTrigger
// Size: 0x50 (Inherited: 0x40)
struct UAkTrigger : UAkAudioType {
	struct FWwiseTriggerCookedData TriggerCookedData; // 0x40(0x0c)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class AkAudio.AkTVOSInitializationSettings
// Size: 0x108 (Inherited: 0x28)
struct UAkTVOSInitializationSettings : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // 0x30(0x70)
	struct FAkAudioSession AudioSession; // 0xa0(0x0c)
	char pad_AC[0x4]; // 0xac(0x04)
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // 0xb0(0x20)
	struct FAkAdvancedInitializationSettingsWithMultiCoreRendering AdvancedSettings; // 0xd0(0x38)
};

// Class AkAudio.AkTVOSPlatformInfo
// Size: 0x70 (Inherited: 0x70)
struct UAkTVOSPlatformInfo : UAkPlatformInfo {
};

// Class AkAudio.AkWaapiCalls
// Size: 0x28 (Inherited: 0x28)
struct UAkWaapiCalls : UBlueprintFunctionLibrary {

	struct FAKWaapiJsonObject Unsubscribe(struct FAkWaapiSubscriptionId& SubscriptionId, bool& UnsubscriptionDone); // Function AkAudio.AkWaapiCalls.Unsubscribe // (None) // @ game+0xffffb2e1df830041
};

// Class AkAudio.SAkWaapiFieldNamesConv
// Size: 0x28 (Inherited: 0x28)
struct USAkWaapiFieldNamesConv : UBlueprintFunctionLibrary {

	struct FText Conv_FAkWaapiFieldNamesToText(struct FAkWaapiFieldNames& INAkWaapiFieldNames); // Function AkAudio.SAkWaapiFieldNamesConv.Conv_FAkWaapiFieldNamesToText // (None) // @ game+0xffffb2e3df830041
};

// Class AkAudio.AkWaapiJsonManager
// Size: 0x28 (Inherited: 0x28)
struct UAkWaapiJsonManager : UBlueprintFunctionLibrary {

	struct FAKWaapiJsonObject SetStringField(struct FAkWaapiFieldNames& FieldName, struct FString FieldValue, struct FAKWaapiJsonObject Target); // Function AkAudio.AkWaapiJsonManager.SetStringField // (None) // @ game+0xffffb2f1df830041
};

// Class AkAudio.AkWaapiUriConv
// Size: 0x28 (Inherited: 0x28)
struct UAkWaapiUriConv : UBlueprintFunctionLibrary {

	struct FText Conv_FAkWaapiUriToText(struct FAkWaapiUri& INAkWaapiUri); // Function AkAudio.AkWaapiUriConv.Conv_FAkWaapiUriToText // (None) // @ game+0xffffb2f3df830041
};

// Class AkAudio.AkWindowsInitializationSettings
// Size: 0x100 (Inherited: 0x28)
struct UAkWindowsInitializationSettings : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings; // 0x30(0x70)
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings; // 0xa0(0x20)
	struct FAkWindowsAdvancedInitializationSettings AdvancedSettings; // 0xc0(0x40)

	void MigrateMultiCoreRendering(bool NewValue); // Function AkAudio.AkWindowsInitializationSettings.MigrateMultiCoreRendering // (None) // @ game+0xffffb2f4df830041
};

// Class AkAudio.AkWin32PlatformInfo
// Size: 0x70 (Inherited: 0x70)
struct UAkWin32PlatformInfo : UAkPlatformInfo {
};

// Class AkAudio.AkWin64PlatformInfo
// Size: 0x70 (Inherited: 0x70)
struct UAkWin64PlatformInfo : UAkPlatformInfo {
};

// Class AkAudio.AkWindowsPlatformInfo
// Size: 0x70 (Inherited: 0x70)
struct UAkWindowsPlatformInfo : UAkWin64PlatformInfo {
};

// Class AkAudio.AkWwiseTree
// Size: 0x190 (Inherited: 0x150)
struct UAkWwiseTree : UWidget {
	struct FMulticastInlineDelegate OnSelectionChanged; // 0x150(0x10)
	struct FMulticastInlineDelegate OnItemDragged; // 0x160(0x10)
	char pad_170[0x20]; // 0x170(0x20)

	void SetSearchText(struct FString newText); // Function AkAudio.AkWwiseTree.SetSearchText // (None) // @ game+0xffffb2f7df830041
};

// Class AkAudio.AkWwiseTreeSelector
// Size: 0x1b0 (Inherited: 0x150)
struct UAkWwiseTreeSelector : UWidget {
	struct FMulticastInlineDelegate OnSelectionChanged; // 0x150(0x10)
	struct FMulticastInlineDelegate OnItemDragged; // 0x160(0x10)
	char pad_170[0x40]; // 0x170(0x40)
};

// Class AkAudio.MovieSceneAkAudioEventSection
// Size: 0x170 (Inherited: 0xf0)
struct UMovieSceneAkAudioEventSection : UMovieSceneSection {
	char pad_F0[0x28]; // 0xf0(0x28)
	struct UAkAudioEvent* Event; // 0x118(0x08)
	bool RetriggerEvent; // 0x120(0x01)
	char pad_121[0x3]; // 0x121(0x03)
	int32_t ScrubTailLengthMs; // 0x124(0x04)
	bool StopAtSectionEnd; // 0x128(0x01)
	char pad_129[0x7]; // 0x129(0x07)
	struct FString EventName; // 0x130(0x10)
	float MaxSourceDuration; // 0x140(0x04)
	char pad_144[0x4]; // 0x144(0x04)
	struct FString MaxDurationSourceID; // 0x148(0x10)
	char pad_158[0x18]; // 0x158(0x18)
};

// Class AkAudio.MovieSceneAkTrack
// Size: 0xb0 (Inherited: 0x98)
struct UMovieSceneAkTrack : UMovieSceneTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x98(0x10)
	bool bIsAMasterTrack; // 0xa8(0x01)
	char pad_A9[0x7]; // 0xa9(0x07)
};

// Class AkAudio.MovieSceneAkAudioEventTrack
// Size: 0xb8 (Inherited: 0xb0)
struct UMovieSceneAkAudioEventTrack : UMovieSceneAkTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x98(0x10)
	bool bIsAMasterTrack; // 0xa8(0x01)
};

// Class AkAudio.MovieSceneAkAudioRTPCSection
// Size: 0x2c8 (Inherited: 0xf0)
struct UMovieSceneAkAudioRTPCSection : UMovieSceneSection {
	struct UAkRtpc* Rtpc; // 0xf0(0x08)
	struct FString Name; // 0xf8(0x10)
	struct FRichCurve FloatCurve; // 0x108(0x80)
	struct FMovieSceneFloatChannelSerializationHelper FloatChannelSerializationHelper; // 0x188(0x30)
	struct FMovieSceneFloatChannel RTPCChannel; // 0x1b8(0x110)
};

// Class AkAudio.MovieSceneAkAudioRTPCTrack
// Size: 0xb8 (Inherited: 0xb0)
struct UMovieSceneAkAudioRTPCTrack : UMovieSceneAkTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x98(0x10)
	bool bIsAMasterTrack; // 0xa8(0x01)
};

// Class AkAudio.PostEventAsync
// Size: 0x88 (Inherited: 0x30)
struct UPostEventAsync : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)
	char pad_40[0x48]; // 0x40(0x48)

	struct UPostEventAsync* PostEventAsync(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, struct AActor* Actor, int32_t CallbackMask, struct FDelegate& PostEventCallback, bool bStopWhenAttachedToDestroyed); // Function AkAudio.PostEventAsync.PostEventAsync // (None) // @ game+0xffffb2f9df830041
};

// Class AkAudio.PostEventAtLocationAsync
// Size: 0x98 (Inherited: 0x30)
struct UPostEventAtLocationAsync : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)
	char pad_40[0x58]; // 0x40(0x58)

	struct UPostEventAtLocationAsync* PostEventAtLocationAsync(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation); // Function AkAudio.PostEventAtLocationAsync.PostEventAtLocationAsync // (None) // @ game+0xffffb2fbdf830041
};

