// BlueprintGeneratedClass BP_Mimic_Base.BP_Mimic_Base_C
// Size: 0x11d0 (Inherited: 0x1140)
struct ABP_Mimic_Base_C : ABP_DCMonsterBaseWithOptions_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1140(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox_Head; // 0x1148(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox_Slate; // 0x1150(0x08)
	struct UBP_DCHitBox_C* BP_DCHitBox_Body; // 0x1158(0x08)
	struct TMap<struct AActor*, struct FTimerHandle> TimerHandleMap; // 0x1160(0x50)
	struct FPrimaryAssetId MimickingPropsId; // 0x11b0(0x10)
	struct TArray<struct FPrimaryAssetId> Mimic Attribute Effect; // 0x11c0(0x10)

	void Apply Mimic Attribute(); // Function BP_Mimic_Base.BP_Mimic_Base_C.Apply Mimic Attribute // (Net|NetReliableNetRequest|Exec|Event|NetResponse|Static|UbergraphFunction|MulticastDelegate|Private|HasOutParms|HasDefaults|DLLImport|BlueprintEvent|Const|NetValidate) // @ game+0x10875dfab0001
};

