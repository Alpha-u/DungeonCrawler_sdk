// BlueprintGeneratedClass BP_Sky_Sphere.BP_Sky_Sphere_C
// Size: 0x348 (Inherited: 0x290)
struct ABP_Sky_Sphere_C : AActor {
	struct UStaticMeshComponent* SkySphereMesh; // 0x290(0x08)
	struct USceneComponent* Base; // 0x298(0x08)
	struct UMaterialInstanceDynamic* Sky material; // 0x2a0(0x08)
	bool Refresh material; // 0x2a8(0x01)
	char pad_2A9[0x7]; // 0x2a9(0x07)
	struct ADirectionalLight* Directional light actor; // 0x2b0(0x08)
	bool Colors determined by sun position; // 0x2b8(0x01)
	char pad_2B9[0x7]; // 0x2b9(0x07)
	double Sun height; // 0x2c0(0x08)
	double Sun brightness; // 0x2c8(0x08)
	double Horizon falloff; // 0x2d0(0x08)
	struct FLinearColor Zenith color; // 0x2d8(0x10)
	struct FLinearColor Horizon color; // 0x2e8(0x10)
	struct FLinearColor Cloud color; // 0x2f8(0x10)
	struct FLinearColor Overall color; // 0x308(0x10)
	double Cloud speed; // 0x318(0x08)
	double Cloud opacity; // 0x320(0x08)
	double Stars brightness; // 0x328(0x08)
	struct UCurveLinearColor* Horizon color curve; // 0x330(0x08)
	struct UCurveLinearColor* Zenith color curve; // 0x338(0x08)
	struct UCurveLinearColor* Cloud color curve; // 0x340(0x08)

	void RefreshMaterial(); // Function BP_Sky_Sphere.BP_Sky_Sphere_C.RefreshMaterial // (None) // @ game+0xffff8009df830000
};

