// BlueprintGeneratedClass BP_UndeadKnight_AIController.BP_UndeadKnight_AIController_C
// Size: 0x458 (Inherited: 0x458)
struct ABP_UndeadKnight_AIController_C : ABP_DCMonsterAIController_C {
	struct UBaseObject* BaseObject; // 0x410(0x08)
	struct FGameplayTagContainer TargetInvisibleStateTagContainer; // 0x438(0x20)
};

