// BlueprintGeneratedClass BP_Roaster02On.BP_Roaster02On_C
// Size: 0x4c8 (Inherited: 0x488)
struct ABP_Roaster02On_C : ABP_LightSourceBase_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x488(0x08)
	struct UPointLightComponent* PointLight1; // 0x490(0x08)
	struct UStaticMeshComponent* Roaster; // 0x498(0x08)
	struct UParticleSystemComponent* ParticleSystem; // 0x4a0(0x08)
	float Timeline_1______0_E451D19F4BB6167EF9BE3DB485352BB6; // 0x4a8(0x04)
	enum class ETimelineDirection Timeline_1__Direction_E451D19F4BB6167EF9BE3DB485352BB6; // 0x4ac(0x01)
	char pad_4AD[0x3]; // 0x4ad(0x03)
	struct UTimelineComponent* Timeline_2; // 0x4b0(0x08)
	float _____0______0_F917A89142694DFA5AA3FF9337164E38; // 0x4b8(0x04)
	enum class ETimelineDirection _____0__Direction_F917A89142694DFA5AA3FF9337164E38; // 0x4bc(0x01)
	char pad_4BD[0x3]; // 0x4bd(0x03)
	struct UTimelineComponent*  �� _1; // 0x4c0(0x08)

	void  ��임라인_0__Fini(); // Function BP_Roaster02On.BP_Roaster02On_C. ��임라인_0__Fini // (None) // @ game+0x154e8dfab0001
};

