// UserDefinedEnum E_FloatAttributeType.E_FloatAttributeType
enum class E_FloatAttributeType : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator4 = 1,
	NewEnumerator1 = 2,
	NewEnumerator2 = 3,
	NewEnumerator3 = 4,
	E_MAX = 5
};

