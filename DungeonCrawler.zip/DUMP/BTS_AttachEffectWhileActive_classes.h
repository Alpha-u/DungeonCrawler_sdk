// BlueprintGeneratedClass BTS_AttachEffectWhileActive.BTS_AttachEffectWhileActive_C
// Size: 0xd0 (Inherited: 0x98)
struct UBTS_AttachEffectWhileActive_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x98(0x08)
	bool Get Data From Monster BP; // 0xa0(0x01)
	enum class E_BTActionsFromMonsterBP Check BT Action; // 0xa1(0x01)
	enum class E_ActionWhileCombat Combat Action; // 0xa2(0x01)
	char pad_A3[0x5]; // 0xa3(0x05)
	struct TArray<struct FPrimaryAssetId> Attach Effect; // 0xa8(0x10)
	struct ABP_DCMonsterBaseWithOptions_C* As BP DCMonster Base With Options; // 0xb8(0x08)
	struct TArray<struct FActiveGameplayEffectHandle> Effect Handle; // 0xc0(0x10)

	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_AttachEffectWhileActive.BTS_AttachEffectWhileActive_C.ReceiveActivationAI // (None) // @ game+0xffff8009df830000
};

