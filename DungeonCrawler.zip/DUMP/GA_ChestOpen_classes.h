// BlueprintGeneratedClass GA_ChestOpen.GA_ChestOpen_C
// Size: 0x588 (Inherited: 0x588)
struct UGA_ChestOpen_C : UGA_ChangeIdle {
	struct TSoftObjectPtr<UAnimMontage> MontageToPlay; // 0x558(0x30)
};

