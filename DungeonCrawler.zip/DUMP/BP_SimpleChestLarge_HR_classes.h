// BlueprintGeneratedClass BP_SimpleChestLarge_HR.BP_SimpleChestLarge_HR_C
// Size: 0x538 (Inherited: 0x520)
struct ABP_SimpleChestLarge_HR_C : ABP_Chest_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x520(0x08)
	struct UDCGeometryCollectionComponent* GC_WoodChestSmall_Default; // 0x528(0x08)
	struct UDCGeometryCollectionComponent* GC_WoodChestSmall_Open; // 0x530(0x08)

	void ReceiveBeginPlay(); // Function BP_SimpleChestLarge_HR.BP_SimpleChestLarge_HR_C.ReceiveBeginPlay // (None) // @ game+0xffff82071540f580
};

