// UserDefinedEnum E_ActionWhileCombat.E_ActionWhileCombat
enum class E_ActionWhileCombat : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator3 = 3,
	NewEnumerator4 = 4,
	E_MAX = 5
};

