// UserDefinedEnum E_FloatValueCalculate.E_FloatValueCalculate
enum class E_FloatValueCalculate : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	NewEnumerator5 = 3,
	NewEnumerator4 = 4,
	E_MAX = 5
};

