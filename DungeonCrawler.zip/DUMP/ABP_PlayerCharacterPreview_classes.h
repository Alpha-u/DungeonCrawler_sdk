// AnimBlueprintGeneratedClass ABP_PlayerCharacterPreview.ABP_PlayerCharacterPreview_C
// Size: 0x7b8 (Inherited: 0x3a0)
struct UABP_PlayerCharacterPreview_C : UDCAnimInstanceV2 {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3a0(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess; // 0x3a8(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base; // 0x3b0(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x3b8(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x3d8(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0x420(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_2; // 0x440(0xc8)
	struct FAnimNode_RandomPlayer AnimGraphNode_RandomPlayer; // 0x508(0x78)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x580(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x5a0(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x5e8(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x608(0xc8)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend; // 0x6d0(0xe0)
	struct UAnimSequenceBase* IdleAnim; // 0x7b0(0x08)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_PlayerCharacterPreview.ABP_PlayerCharacterPreview_C.AnimGraph // (None) // @ game+0x12347dfab0001
};

