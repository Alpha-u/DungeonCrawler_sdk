// AnimBlueprintGeneratedClass ABP_RecurveBow.ABP_RecurveBow_C
// Size: 0x798 (Inherited: 0x530)
struct UABP_RecurveBow_C : UItemWeaponAnimInstanceBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x530(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess; // 0x538(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base; // 0x540(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x548(0x20)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x568(0x48)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x5b0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x5d8(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x600(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x648(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x668(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x6b0(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x6d0(0xc8)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_RecurveBow.ABP_RecurveBow_C.AnimGraph // (None) // @ game+0xffff800adf82ffff
};

