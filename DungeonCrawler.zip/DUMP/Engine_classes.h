// Class Engine.Actor
// Size: 0x290 (Inherited: 0x28)
struct AActor : UObject {
	struct FActorTickFunction PrimaryActorTick; // 0x28(0x30)
	char bNetTemporary : 1; // 0x58(0x01)
	char pad_58_1 : 1; // 0x58(0x01)
	char bOnlyRelevantToOwner : 1; // 0x58(0x01)
	char bAlwaysRelevant : 1; // 0x58(0x01)
	char bReplicateMovement : 1; // 0x58(0x01)
	char bCallPreReplication : 1; // 0x58(0x01)
	char bCallPreReplicationForReplay : 1; // 0x58(0x01)
	char bHidden : 1; // 0x58(0x01)
	char bTearOff : 1; // 0x59(0x01)
	char bForceNetAddressable : 1; // 0x59(0x01)
	char bExchangedRoles : 1; // 0x59(0x01)
	char bNetLoadOnClient : 1; // 0x59(0x01)
	char bNetUseOwnerRelevancy : 1; // 0x59(0x01)
	char bRelevantForNetworkReplays : 1; // 0x59(0x01)
	char bRelevantForLevelBounds : 1; // 0x59(0x01)
	char bReplayRewindable : 1; // 0x59(0x01)
	char bAllowTickBeforeBeginPlay : 1; // 0x5a(0x01)
	char bAutoDestroyWhenFinished : 1; // 0x5a(0x01)
	char bCanBeDamaged : 1; // 0x5a(0x01)
	char bBlockInput : 1; // 0x5a(0x01)
	char bCollideWhenPlacing : 1; // 0x5a(0x01)
	char bFindCameraComponentWhenViewTarget : 1; // 0x5a(0x01)
	char bGenerateOverlapEventsDuringLevelStreaming : 1; // 0x5a(0x01)
	char bIgnoresOriginShifting : 1; // 0x5a(0x01)
	char bEnableAutoLODGeneration : 1; // 0x5b(0x01)
	char bIsEditorOnlyActor : 1; // 0x5b(0x01)
	char bActorSeamlessTraveled : 1; // 0x5b(0x01)
	char bReplicates : 1; // 0x5b(0x01)
	char bCanBeInCluster : 1; // 0x5b(0x01)
	char bAllowReceiveTickEventOnDedicatedServer : 1; // 0x5b(0x01)
	char pad_5B_6 : 1; // 0x5b(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x5b(0x01)
	char pad_5C_0 : 7; // 0x5c(0x01)
	char bActorEnableCollision : 1; // 0x5c(0x01)
	char bActorIsBeingDestroyed : 1; // 0x5d(0x01)
	char pad_5D_1 : 4; // 0x5d(0x01)
	char bAsyncPhysicsTickEnabled : 1; // 0x5d(0x01)
	char pad_5D_6 : 2; // 0x5d(0x01)
	enum class EActorUpdateOverlapsMethod UpdateOverlapsMethodDuringLevelStreaming; // 0x5e(0x01)
	enum class EActorUpdateOverlapsMethod DefaultUpdateOverlapsMethodDuringLevelStreaming; // 0x5f(0x01)
	float InitialLifeSpan; // 0x60(0x04)
	float CustomTimeDilation; // 0x64(0x04)
	enum class ENetRole RemoteRole; // 0x68(0x01)
	char pad_69[0x3]; // 0x69(0x03)
	int32_t RayTracingGroupId; // 0x6c(0x04)
	struct FRepAttachment AttachmentReplication; // 0x70(0x60)
	struct FRepMovement ReplicatedMovement; // 0xd0(0x70)
	struct AActor* Owner; // 0x140(0x08)
	struct FName NetDriverName; // 0x148(0x08)
	enum class ENetRole Role; // 0x150(0x01)
	enum class ENetDormancy NetDormancy; // 0x151(0x01)
	enum class ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingMethod; // 0x152(0x01)
	enum class EAutoReceiveInput AutoReceiveInput; // 0x153(0x01)
	int32_t InputPriority; // 0x154(0x04)
	char pad_158[0x8]; // 0x158(0x08)
	struct UInputComponent* InputComponent; // 0x160(0x08)
	float NetCullDistanceSquared; // 0x168(0x04)
	int32_t NetTag; // 0x16c(0x04)
	float NetUpdateFrequency; // 0x170(0x04)
	float MinNetUpdateFrequency; // 0x174(0x04)
	float NetPriority; // 0x178(0x04)
	char pad_17C[0x4]; // 0x17c(0x04)
	struct APawn* Instigator; // 0x180(0x08)
	struct TArray<struct AActor*> Children; // 0x188(0x10)
	struct USceneComponent* RootComponent; // 0x198(0x08)
	char pad_1A0[0x8]; // 0x1a0(0x08)
	struct TArray<struct FName> Layers; // 0x1a8(0x10)
	struct TWeakObjectPtr<struct UChildActorComponent> ParentComponent; // 0x1b8(0x08)
	struct TArray<struct FName> Tags; // 0x1c0(0x10)
	struct FMulticastSparseDelegate OnTakeAnyDamage; // 0x1d0(0x01)
	struct FMulticastSparseDelegate OnTakePointDamage; // 0x1d1(0x01)
	struct FMulticastSparseDelegate OnTakeRadialDamage; // 0x1d2(0x01)
	struct FMulticastSparseDelegate OnActorBeginOverlap; // 0x1d3(0x01)
	struct FMulticastSparseDelegate OnActorEndOverlap; // 0x1d4(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x1d5(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x1d6(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x1d7(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x1d8(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x1d9(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x1da(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x1db(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x1dc(0x01)
	struct FMulticastSparseDelegate OnActorHit; // 0x1dd(0x01)
	struct FMulticastSparseDelegate OnDestroyed; // 0x1de(0x01)
	struct FMulticastSparseDelegate OnEndPlay; // 0x1df(0x01)
	char pad_1E0[0x80]; // 0x1e0(0x80)
	struct TArray<struct UActorComponent*> InstanceComponents; // 0x260(0x10)
	struct TArray<struct UActorComponent*> BlueprintCreatedComponents; // 0x270(0x10)
	char pad_280[0x10]; // 0x280(0x10)

	bool WasRecentlyRendered(float Tolerance); // Function Engine.Actor.WasRecentlyRendered // (None) // @ game+0xffffa98edf830041
};

// Class Engine.HUD
// Size: 0x380 (Inherited: 0x290)
struct AHUD : AActor {
	struct APlayerController* PlayerOwner; // 0x290(0x08)
	char bLostFocusPaused : 1; // 0x298(0x01)
	char bShowHUD : 1; // 0x298(0x01)
	char bShowDebugInfo : 1; // 0x298(0x01)
	char pad_298_3 : 5; // 0x298(0x01)
	char pad_299[0x3]; // 0x299(0x03)
	int32_t CurrentTargetIndex; // 0x29c(0x04)
	char bShowHitBoxDebugInfo : 1; // 0x2a0(0x01)
	char bShowOverlays : 1; // 0x2a0(0x01)
	char bEnableDebugTextShadow : 1; // 0x2a0(0x01)
	char pad_2A0_3 : 5; // 0x2a0(0x01)
	char pad_2A1[0x7]; // 0x2a1(0x07)
	struct TArray<struct AActor*> PostRenderedActors; // 0x2a8(0x10)
	char pad_2B8[0x8]; // 0x2b8(0x08)
	struct TArray<struct FName> DebugDisplay; // 0x2c0(0x10)
	struct TArray<struct FName> ToggledDebugCategories; // 0x2d0(0x10)
	struct UCanvas* Canvas; // 0x2e0(0x08)
	struct UCanvas* DebugCanvas; // 0x2e8(0x08)
	struct TArray<struct FDebugTextInfo> DebugTextList; // 0x2f0(0x10)
	struct AActor* ShowDebugTargetDesiredClass; // 0x300(0x08)
	struct AActor* ShowDebugTargetActor; // 0x308(0x08)
	char pad_310[0x70]; // 0x310(0x70)

	void ShowHUD(); // Function Engine.HUD.ShowHUD // (None) // @ game+0xffffae1ddf830041
};

// Class Engine.BlueprintAsyncActionBase
// Size: 0x30 (Inherited: 0x28)
struct UBlueprintAsyncActionBase : UObject {
	char pad_28[0x8]; // 0x28(0x08)

	void Activate(); // Function Engine.BlueprintAsyncActionBase.Activate // (None) // @ game+0xffff92efdf830041
};

// Class Engine.CancellableAsyncAction
// Size: 0x30 (Inherited: 0x30)
struct UCancellableAsyncAction : UBlueprintAsyncActionBase {

	bool IsActive(); // Function Engine.CancellableAsyncAction.IsActive // (None) // @ game+0xffff92f1df830041
};

// Class Engine.DataAsset
// Size: 0x30 (Inherited: 0x28)
struct UDataAsset : UObject {
	struct UDataAsset* NativeClass; // 0x28(0x08)
};

// Class Engine.BlueprintFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UBlueprintFunctionLibrary : UObject {
};

// Class Engine.ActorComponent
// Size: 0xa0 (Inherited: 0x28)
struct UActorComponent : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x30(0x30)
	struct TArray<struct FName> ComponentTags; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	char pad_80[0x4]; // 0x80(0x04)
	int32_t UCSSerializationIndex; // 0x84(0x04)
	char pad_88_0 : 3; // 0x88(0x01)
	char bNetAddressable : 1; // 0x88(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x88(0x01)
	char bReplicates : 1; // 0x88(0x01)
	char pad_88_6 : 2; // 0x88(0x01)
	char pad_89[0x1]; // 0x89(0x01)
	char pad_8A_0 : 1; // 0x8a(0x01)
	char bAutoActivate : 1; // 0x8a(0x01)
	char bIsActive : 1; // 0x8a(0x01)
	char bEditableWhenInherited : 1; // 0x8a(0x01)
	char pad_8A_4 : 1; // 0x8a(0x01)
	char bCanEverAffectNavigation : 1; // 0x8a(0x01)
	char pad_8A_6 : 1; // 0x8a(0x01)
	char bIsEditorOnly : 1; // 0x8a(0x01)
	char pad_8B[0x2]; // 0x8b(0x02)
	enum class EComponentCreationMethod CreationMethod; // 0x8d(0x01)
	struct FMulticastSparseDelegate OnComponentActivated; // 0x8e(0x01)
	struct FMulticastSparseDelegate OnComponentDeactivated; // 0x8f(0x01)
	char pad_90[0x10]; // 0x90(0x10)

	void ToggleActive(); // Function Engine.ActorComponent.ToggleActive // (None) // @ game+0xffff9130df830041
};

// Class Engine.Pawn
// Size: 0x318 (Inherited: 0x290)
struct APawn : AActor {
	char pad_290[0x8]; // 0x290(0x08)
	char bUseControllerRotationPitch : 1; // 0x298(0x01)
	char bUseControllerRotationYaw : 1; // 0x298(0x01)
	char bUseControllerRotationRoll : 1; // 0x298(0x01)
	char bCanAffectNavigationGeneration : 1; // 0x298(0x01)
	char pad_298_4 : 2; // 0x298(0x01)
	char bIsLocalViewTarget : 1; // 0x298(0x01)
	char pad_298_7 : 1; // 0x298(0x01)
	char pad_299[0x3]; // 0x299(0x03)
	float BaseEyeHeight; // 0x29c(0x04)
	enum class EAutoReceiveInput AutoPossessPlayer; // 0x2a0(0x01)
	enum class EAutoPossessAI AutoPossessAI; // 0x2a1(0x01)
	char RemoteViewPitch; // 0x2a2(0x01)
	char pad_2A3[0x5]; // 0x2a3(0x05)
	struct AController* AIControllerClass; // 0x2a8(0x08)
	struct APlayerState* PlayerState; // 0x2b0(0x08)
	char pad_2B8[0x8]; // 0x2b8(0x08)
	struct AController* LastHitBy; // 0x2c0(0x08)
	struct AController* Controller; // 0x2c8(0x08)
	struct AController* PreviousController; // 0x2d0(0x08)
	char pad_2D8[0x4]; // 0x2d8(0x04)
	struct FMulticastSparseDelegate ReceiveControllerChangedDelegate; // 0x2dc(0x01)
	struct FMulticastSparseDelegate ReceiveRestartedDelegate; // 0x2dd(0x01)
	char pad_2DE[0x2]; // 0x2de(0x02)
	struct FVector ControlInputVector; // 0x2e0(0x18)
	struct FVector LastControlInputVector; // 0x2f8(0x18)
	struct UInputComponent* OverrideInputComponentClass; // 0x310(0x08)

	void SpawnDefaultController(); // Function Engine.Pawn.SpawnDefaultController // (None) // @ game+0xffffae43df830041
};

// Class Engine.DefaultPawn
// Size: 0x340 (Inherited: 0x318)
struct ADefaultPawn : APawn {
	float BaseTurnRate; // 0x318(0x04)
	float BaseLookUpRate; // 0x31c(0x04)
	struct UPawnMovementComponent* MovementComponent; // 0x320(0x08)
	struct USphereComponent* CollisionComponent; // 0x328(0x08)
	struct UStaticMeshComponent* MeshComponent; // 0x330(0x08)
	char bAddDefaultMovementBindings : 1; // 0x338(0x01)
	char pad_338_1 : 7; // 0x338(0x01)
	char pad_339[0x7]; // 0x339(0x07)

	void TurnAtRate(float Rate); // Function Engine.DefaultPawn.TurnAtRate // (None) // @ game+0xffffae48df830041
};

// Class Engine.AnimNotify
// Size: 0x38 (Inherited: 0x28)
struct UAnimNotify : UObject {
	char pad_28[0x10]; // 0x28(0x10)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, struct FAnimNotifyEventReference& EventReference); // Function Engine.AnimNotify.Received_Notify // (None) // @ game+0xffffae4bdf830041
};

// Class Engine.AnimNotifyState
// Size: 0x30 (Inherited: 0x28)
struct UAnimNotifyState : UObject {
	char pad_28[0x8]; // 0x28(0x08)

	bool Received_NotifyTick(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float FrameDeltaTime, struct FAnimNotifyEventReference& EventReference); // Function Engine.AnimNotifyState.Received_NotifyTick // (None) // @ game+0xffffae50df830041
};

// Class Engine.BlueprintCore
// Size: 0x50 (Inherited: 0x28)
struct UBlueprintCore : UObject {
	struct UObject* SkeletonGeneratedClass; // 0x28(0x08)
	struct UObject* GeneratedClass; // 0x30(0x08)
	bool bLegacyNeedToPurgeSkelRefs; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	struct FGuid BlueprintGuid; // 0x3c(0x10)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class Engine.Blueprint
// Size: 0xa8 (Inherited: 0x50)
struct UBlueprint : UBlueprintCore {
	char pad_50[0x8]; // 0x50(0x08)
	struct UObject* ParentClass; // 0x58(0x08)
	enum class EBlueprintType BlueprintType; // 0x60(0x01)
	char bRecompileOnLoad : 1; // 0x61(0x01)
	char bHasBeenRegenerated : 1; // 0x61(0x01)
	char bIsRegeneratingOnLoad : 1; // 0x61(0x01)
	char pad_61_3 : 5; // 0x61(0x01)
	char pad_62[0x2]; // 0x62(0x02)
	int32_t BlueprintSystemVersion; // 0x64(0x04)
	struct USimpleConstructionScript* SimpleConstructionScript; // 0x68(0x08)
	struct TArray<struct UActorComponent*> ComponentTemplates; // 0x70(0x10)
	struct TArray<struct UTimelineTemplate*> Timelines; // 0x80(0x10)
	struct TArray<struct FBPComponentClassOverride> ComponentClassOverrides; // 0x90(0x10)
	struct UInheritableComponentHandler* InheritableComponentHandler; // 0xa0(0x08)
};

// Class Engine.SceneComponent
// Size: 0x2a0 (Inherited: 0xa0)
struct USceneComponent : UActorComponent {
	char pad_A0[0x8]; // 0xa0(0x08)
	struct TWeakObjectPtr<struct APhysicsVolume> PhysicsVolume; // 0xa8(0x08)
	struct USceneComponent* AttachParent; // 0xb0(0x08)
	struct FName AttachSocketName; // 0xb8(0x08)
	struct TArray<struct USceneComponent*> AttachChildren; // 0xc0(0x10)
	struct TArray<struct USceneComponent*> ClientAttachedChildren; // 0xd0(0x10)
	char pad_E0[0x48]; // 0xe0(0x48)
	struct FVector RelativeLocation; // 0x128(0x18)
	struct FRotator RelativeRotation; // 0x140(0x18)
	struct FVector RelativeScale3D; // 0x158(0x18)
	struct FVector ComponentVelocity; // 0x170(0x18)
	char bComponentToWorldUpdated : 1; // 0x188(0x01)
	char pad_188_1 : 1; // 0x188(0x01)
	char bAbsoluteLocation : 1; // 0x188(0x01)
	char bAbsoluteRotation : 1; // 0x188(0x01)
	char bAbsoluteScale : 1; // 0x188(0x01)
	char bVisible : 1; // 0x188(0x01)
	char bShouldBeAttached : 1; // 0x188(0x01)
	char bShouldSnapLocationWhenAttached : 1; // 0x188(0x01)
	char bShouldSnapRotationWhenAttached : 1; // 0x189(0x01)
	char bShouldSnapScaleWhenAttached : 1; // 0x189(0x01)
	char bShouldUpdatePhysicsVolume : 1; // 0x189(0x01)
	char bHiddenInGame : 1; // 0x189(0x01)
	char bBoundsChangeTriggersStreamingDataRebuild : 1; // 0x189(0x01)
	char bUseAttachParentBound : 1; // 0x189(0x01)
	char bComputeFastLocalBounds : 1; // 0x189(0x01)
	char bComputeBoundsOnceForGame : 1; // 0x189(0x01)
	char bComputedBoundsOnceForGame : 1; // 0x18a(0x01)
	char bIsNotRenderAttachmentRoot : 1; // 0x18a(0x01)
	char pad_18A_2 : 6; // 0x18a(0x01)
	enum class EComponentMobility Mobility; // 0x18b(0x01)
	enum class EDetailMode DetailMode; // 0x18c(0x01)
	struct FMulticastSparseDelegate PhysicsVolumeChangedDelegate; // 0x18d(0x01)
	char pad_18E[0x112]; // 0x18e(0x112)

	void ToggleVisibility(bool bPropagateToChildren); // Function Engine.SceneComponent.ToggleVisibility // (None) // @ game+0xffff9949df830041
};

// Class Engine.PrimitiveComponent
// Size: 0x540 (Inherited: 0x2a0)
struct UPrimitiveComponent : USceneComponent {
	char pad_2A0[0x10]; // 0x2a0(0x10)
	float MinDrawDistance; // 0x2b0(0x04)
	float LDMaxDrawDistance; // 0x2b4(0x04)
	float CachedMaxDrawDistance; // 0x2b8(0x04)
	enum class ESceneDepthPriorityGroup DepthPriorityGroup; // 0x2bc(0x01)
	enum class ESceneDepthPriorityGroup ViewOwnerDepthPriorityGroup; // 0x2bd(0x01)
	enum class EIndirectLightingCacheQuality IndirectLightingCacheQuality; // 0x2be(0x01)
	enum class ELightmapType LightmapType; // 0x2bf(0x01)
	char bIsValidTextureStreamingBuiltData : 1; // 0x2c0(0x01)
	char bNeverDistanceCull : 1; // 0x2c0(0x01)
	char pad_2C0_2 : 5; // 0x2c0(0x01)
	char bAlwaysCreatePhysicsState : 1; // 0x2c0(0x01)
	char bGenerateOverlapEvents : 1; // 0x2c1(0x01)
	char bMultiBodyOverlap : 1; // 0x2c1(0x01)
	char bTraceComplexOnMove : 1; // 0x2c1(0x01)
	char bReturnMaterialOnMove : 1; // 0x2c1(0x01)
	char bUseViewOwnerDepthPriorityGroup : 1; // 0x2c1(0x01)
	char bAllowCullDistanceVolume : 1; // 0x2c1(0x01)
	char bVisibleInReflectionCaptures : 1; // 0x2c1(0x01)
	char bVisibleInRealTimeSkyCaptures : 1; // 0x2c1(0x01)
	char bVisibleInRayTracing : 1; // 0x2c2(0x01)
	char bRenderInMainPass : 1; // 0x2c2(0x01)
	char bRenderInDepthPass : 1; // 0x2c2(0x01)
	char bReceivesDecals : 1; // 0x2c2(0x01)
	char bOwnerNoSee : 1; // 0x2c2(0x01)
	char bOnlyOwnerSee : 1; // 0x2c2(0x01)
	char bTreatAsBackgroundForOcclusion : 1; // 0x2c2(0x01)
	char bUseAsOccluder : 1; // 0x2c2(0x01)
	char bSelectable : 1; // 0x2c3(0x01)
	char bForceMipStreaming : 1; // 0x2c3(0x01)
	char bHasPerInstanceHitProxies : 1; // 0x2c3(0x01)
	char CastShadow : 1; // 0x2c3(0x01)
	char bEmissiveLightSource : 1; // 0x2c3(0x01)
	char bAffectDynamicIndirectLighting : 1; // 0x2c3(0x01)
	char bAffectIndirectLightingWhileHidden : 1; // 0x2c3(0x01)
	char bAffectDistanceFieldLighting : 1; // 0x2c3(0x01)
	char bCastDynamicShadow : 1; // 0x2c4(0x01)
	char bCastStaticShadow : 1; // 0x2c4(0x01)
	char bCastVolumetricTranslucentShadow : 1; // 0x2c4(0x01)
	char bCastContactShadow : 1; // 0x2c4(0x01)
	char bSelfShadowOnly : 1; // 0x2c4(0x01)
	char bCastFarShadow : 1; // 0x2c4(0x01)
	char bCastInsetShadow : 1; // 0x2c4(0x01)
	char bCastCinematicShadow : 1; // 0x2c4(0x01)
	char bCastHiddenShadow : 1; // 0x2c5(0x01)
	char bCastShadowAsTwoSided : 1; // 0x2c5(0x01)
	char bLightAsIfStatic : 1; // 0x2c5(0x01)
	char bLightAttachmentsAsGroup : 1; // 0x2c5(0x01)
	char bExcludeFromLightAttachmentGroup : 1; // 0x2c5(0x01)
	char bReceiveMobileCSMShadows : 1; // 0x2c5(0x01)
	char bSingleSampleShadowFromStationaryLights : 1; // 0x2c5(0x01)
	char bIgnoreRadialImpulse : 1; // 0x2c5(0x01)
	char bIgnoreRadialForce : 1; // 0x2c6(0x01)
	char bApplyImpulseOnDamage : 1; // 0x2c6(0x01)
	char bReplicatePhysicsToAutonomousProxy : 1; // 0x2c6(0x01)
	char bFillCollisionUnderneathForNavmesh : 1; // 0x2c6(0x01)
	char AlwaysLoadOnClient : 1; // 0x2c6(0x01)
	char AlwaysLoadOnServer : 1; // 0x2c6(0x01)
	char bUseEditorCompositing : 1; // 0x2c6(0x01)
	char bIsBeingMovedByEditor : 1; // 0x2c6(0x01)
	char bRenderCustomDepth : 1; // 0x2c7(0x01)
	char bVisibleInSceneCaptureOnly : 1; // 0x2c7(0x01)
	char bHiddenInSceneCapture : 1; // 0x2c7(0x01)
	char bRayTracingFarField : 1; // 0x2c7(0x01)
	char pad_2C7_4 : 1; // 0x2c7(0x01)
	char bHasNoStreamableTextures : 1; // 0x2c7(0x01)
	char pad_2C7_6 : 2; // 0x2c7(0x01)
	enum class EHasCustomNavigableGeometry bHasCustomNavigableGeometry; // 0x2c8(0x01)
	char pad_2C9[0x1]; // 0x2c9(0x01)
	enum class ECanBeCharacterBase CanCharacterStepUpOn; // 0x2ca(0x01)
	struct FLightingChannels LightingChannels; // 0x2cb(0x01)
	int32_t RayTracingGroupId; // 0x2cc(0x04)
	int32_t VisibilityId; // 0x2d0(0x04)
	int32_t CustomDepthStencilValue; // 0x2d4(0x04)
	struct FCustomPrimitiveData CustomPrimitiveData; // 0x2d8(0x10)
	struct FCustomPrimitiveData CustomPrimitiveDataInternal; // 0x2e8(0x10)
	char pad_2F8[0x8]; // 0x2f8(0x08)
	int32_t TranslucencySortPriority; // 0x300(0x04)
	float TranslucencySortDistanceOffset; // 0x304(0x04)
	struct TArray<struct URuntimeVirtualTexture*> RuntimeVirtualTextures; // 0x308(0x10)
	int8_t VirtualTextureLodBias; // 0x318(0x01)
	int8_t VirtualTextureCullMips; // 0x319(0x01)
	int8_t VirtualTextureMinCoverage; // 0x31a(0x01)
	enum class ERuntimeVirtualTextureMainPassType VirtualTextureRenderPassType; // 0x31b(0x01)
	char pad_31C[0x10]; // 0x31c(0x10)
	float BoundsScale; // 0x32c(0x04)
	char pad_330[0x10]; // 0x330(0x10)
	struct TArray<struct AActor*> MoveIgnoreActors; // 0x340(0x10)
	struct TArray<struct UPrimitiveComponent*> MoveIgnoreComponents; // 0x350(0x10)
	char pad_360[0x10]; // 0x360(0x10)
	struct FBodyInstance BodyInstance; // 0x370(0x190)
	struct FMulticastSparseDelegate OnComponentHit; // 0x500(0x01)
	struct FMulticastSparseDelegate OnComponentBeginOverlap; // 0x501(0x01)
	struct FMulticastSparseDelegate OnComponentEndOverlap; // 0x502(0x01)
	struct FMulticastSparseDelegate OnComponentWake; // 0x503(0x01)
	struct FMulticastSparseDelegate OnComponentSleep; // 0x504(0x01)
	char pad_505[0x1]; // 0x505(0x01)
	struct FMulticastSparseDelegate OnComponentPhysicsStateChanged; // 0x506(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x507(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x508(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x509(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x50a(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x50b(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x50c(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x50d(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x50e(0x01)
	enum class ERayTracingGroupCullingPriority RayTracingGroupCullingPriority; // 0x50f(0x01)
	enum class ERendererStencilMask CustomDepthStencilWriteMask; // 0x510(0x01)
	char pad_511[0x1f]; // 0x511(0x1f)
	struct UPrimitiveComponent* LODParentPrimitive; // 0x530(0x08)
	char pad_538[0x8]; // 0x538(0x08)

	bool WasRecentlyRendered(float Tolerance); // Function Engine.PrimitiveComponent.WasRecentlyRendered // (None) // @ game+0xffff9a64df830041
};

// Class Engine.FXSystemComponent
// Size: 0x540 (Inherited: 0x540)
struct UFXSystemComponent : UPrimitiveComponent {
	float MinDrawDistance; // 0x2b0(0x04)
	float LDMaxDrawDistance; // 0x2b4(0x04)
	float CachedMaxDrawDistance; // 0x2b8(0x04)
	enum class ESceneDepthPriorityGroup DepthPriorityGroup; // 0x2bc(0x01)
	enum class ESceneDepthPriorityGroup ViewOwnerDepthPriorityGroup; // 0x2bd(0x01)
	enum class EIndirectLightingCacheQuality IndirectLightingCacheQuality; // 0x2be(0x01)
	enum class ELightmapType LightmapType; // 0x2bf(0x01)
	char bIsValidTextureStreamingBuiltData : 1; // 0x2c0(0x01)
	char bNeverDistanceCull : 1; // 0x2c0(0x01)
	char pad_550_2 : 5; // 0x550(0x01)
	char bAlwaysCreatePhysicsState : 1; // 0x2c0(0x01)
	char bGenerateOverlapEvents : 1; // 0x2c1(0x01)
	char bMultiBodyOverlap : 1; // 0x2c1(0x01)
	char bTraceComplexOnMove : 1; // 0x2c1(0x01)
	char bReturnMaterialOnMove : 1; // 0x2c1(0x01)
	char bUseViewOwnerDepthPriorityGroup : 1; // 0x2c1(0x01)
	char bAllowCullDistanceVolume : 1; // 0x2c1(0x01)
	char bVisibleInReflectionCaptures : 1; // 0x2c1(0x01)
	char bVisibleInRealTimeSkyCaptures : 1; // 0x2c1(0x01)
	char bVisibleInRayTracing : 1; // 0x2c2(0x01)
	char bRenderInMainPass : 1; // 0x2c2(0x01)
	char bRenderInDepthPass : 1; // 0x2c2(0x01)
	char bReceivesDecals : 1; // 0x2c2(0x01)
	char bOwnerNoSee : 1; // 0x2c2(0x01)
	char bOnlyOwnerSee : 1; // 0x2c2(0x01)
	char bTreatAsBackgroundForOcclusion : 1; // 0x2c2(0x01)
	char bUseAsOccluder : 1; // 0x2c2(0x01)
	char bSelectable : 1; // 0x2c3(0x01)
	char bForceMipStreaming : 1; // 0x2c3(0x01)
	char bHasPerInstanceHitProxies : 1; // 0x2c3(0x01)
	char CastShadow : 1; // 0x2c3(0x01)
	char bEmissiveLightSource : 1; // 0x2c3(0x01)
	char bAffectDynamicIndirectLighting : 1; // 0x2c3(0x01)
	char bAffectIndirectLightingWhileHidden : 1; // 0x2c3(0x01)
	char bAffectDistanceFieldLighting : 1; // 0x2c3(0x01)
	char bCastDynamicShadow : 1; // 0x2c4(0x01)
	char bCastStaticShadow : 1; // 0x2c4(0x01)
	char bCastVolumetricTranslucentShadow : 1; // 0x2c4(0x01)
	char bCastContactShadow : 1; // 0x2c4(0x01)
	char bSelfShadowOnly : 1; // 0x2c4(0x01)
	char bCastFarShadow : 1; // 0x2c4(0x01)
	char bCastInsetShadow : 1; // 0x2c4(0x01)
	char bCastCinematicShadow : 1; // 0x2c4(0x01)
	char bCastHiddenShadow : 1; // 0x2c5(0x01)
	char bCastShadowAsTwoSided : 1; // 0x2c5(0x01)
	char bLightAsIfStatic : 1; // 0x2c5(0x01)
	char bLightAttachmentsAsGroup : 1; // 0x2c5(0x01)
	char bExcludeFromLightAttachmentGroup : 1; // 0x2c5(0x01)
	char bReceiveMobileCSMShadows : 1; // 0x2c5(0x01)
	char bSingleSampleShadowFromStationaryLights : 1; // 0x2c5(0x01)
	char bIgnoreRadialImpulse : 1; // 0x2c5(0x01)
	char bIgnoreRadialForce : 1; // 0x2c6(0x01)
	char bApplyImpulseOnDamage : 1; // 0x2c6(0x01)
	char bReplicatePhysicsToAutonomousProxy : 1; // 0x2c6(0x01)
	char bFillCollisionUnderneathForNavmesh : 1; // 0x2c6(0x01)
	char AlwaysLoadOnClient : 1; // 0x2c6(0x01)
	char AlwaysLoadOnServer : 1; // 0x2c6(0x01)
	char bUseEditorCompositing : 1; // 0x2c6(0x01)
	char bIsBeingMovedByEditor : 1; // 0x2c6(0x01)
	char bRenderCustomDepth : 1; // 0x2c7(0x01)
	char bVisibleInSceneCaptureOnly : 1; // 0x2c7(0x01)
	char bHiddenInSceneCapture : 1; // 0x2c7(0x01)
	char bRayTracingFarField : 1; // 0x2c7(0x01)
	char pad_557_4 : 1; // 0x557(0x01)
	char bHasNoStreamableTextures : 1; // 0x2c7(0x01)
	enum class EHasCustomNavigableGeometry bHasCustomNavigableGeometry; // 0x2c8(0x01)
	enum class ECanBeCharacterBase CanCharacterStepUpOn; // 0x2ca(0x01)
	struct FLightingChannels LightingChannels; // 0x2cb(0x01)
	int32_t RayTracingGroupId; // 0x2cc(0x04)
	int32_t VisibilityId; // 0x2d0(0x04)
	int32_t CustomDepthStencilValue; // 0x2d4(0x04)
	struct FCustomPrimitiveData CustomPrimitiveData; // 0x2d8(0x10)
	struct FCustomPrimitiveData CustomPrimitiveDataInternal; // 0x2e8(0x10)
	int32_t TranslucencySortPriority; // 0x300(0x04)
	float TranslucencySortDistanceOffset; // 0x304(0x04)
	struct TArray<struct URuntimeVirtualTexture*> RuntimeVirtualTextures; // 0x308(0x10)
	int8_t VirtualTextureLodBias; // 0x318(0x01)
	int8_t VirtualTextureCullMips; // 0x319(0x01)
	int8_t VirtualTextureMinCoverage; // 0x31a(0x01)
	enum class ERuntimeVirtualTextureMainPassType VirtualTextureRenderPassType; // 0x31b(0x01)
	float BoundsScale; // 0x32c(0x04)
	struct TArray<struct AActor*> MoveIgnoreActors; // 0x340(0x10)
	struct TArray<struct UPrimitiveComponent*> MoveIgnoreComponents; // 0x350(0x10)
	struct FBodyInstance BodyInstance; // 0x370(0x190)
	struct FMulticastSparseDelegate OnComponentHit; // 0x500(0x01)
	struct FMulticastSparseDelegate OnComponentBeginOverlap; // 0x501(0x01)
	struct FMulticastSparseDelegate OnComponentEndOverlap; // 0x502(0x01)
	struct FMulticastSparseDelegate OnComponentWake; // 0x503(0x01)
	struct FMulticastSparseDelegate OnComponentSleep; // 0x504(0x01)
	struct FMulticastSparseDelegate OnComponentPhysicsStateChanged; // 0x506(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x507(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x508(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x509(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x50a(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x50b(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x50c(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x50d(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x50e(0x01)
	enum class ERayTracingGroupCullingPriority RayTracingGroupCullingPriority; // 0x50f(0x01)
	enum class ERendererStencilMask CustomDepthStencilWriteMask; // 0x510(0x01)
	struct UPrimitiveComponent* LODParentPrimitive; // 0x530(0x08)

	void SetVectorParameter(struct FName ParameterName, struct FVector Param); // Function Engine.FXSystemComponent.SetVectorParameter // (None) // @ game+0xffffae95df830041
};

// Class Engine.FXSystemAsset
// Size: 0x30 (Inherited: 0x28)
struct UFXSystemAsset : UObject {
	uint32_t MaxPoolSize; // 0x28(0x04)
	uint32_t PoolPrimeSize; // 0x2c(0x04)
};

// Class Engine.Subsystem
// Size: 0x30 (Inherited: 0x28)
struct USubsystem : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.DynamicSubsystem
// Size: 0x30 (Inherited: 0x30)
struct UDynamicSubsystem : USubsystem {
};

// Class Engine.EngineSubsystem
// Size: 0x30 (Inherited: 0x30)
struct UEngineSubsystem : UDynamicSubsystem {
};

// Class Engine.ShapeComponent
// Size: 0x560 (Inherited: 0x540)
struct UShapeComponent : UPrimitiveComponent {
	struct UBodySetup* ShapeBodySetup; // 0x538(0x08)
	struct FColor ShapeColor; // 0x540(0x04)
	char bDrawOnlyIfSelected : 1; // 0x544(0x01)
	char bShouldCollideWhenPlacing : 1; // 0x544(0x01)
	char bDynamicObstacle : 1; // 0x544(0x01)
	struct UNavAreaBase* AreaClassOverride; // 0x548(0x08)
	char bUseSystemDefaultObstacleAreaClass : 1; // 0x550(0x01)
	char pad_554_4 : 4; // 0x554(0x01)
	char pad_555[0xb]; // 0x555(0x0b)
};

// Class Engine.BoxComponent
// Size: 0x580 (Inherited: 0x560)
struct UBoxComponent : UShapeComponent {
	struct FVector BoxExtent; // 0x558(0x18)
	float LineThickness; // 0x570(0x04)
	char pad_57C[0x4]; // 0x57c(0x04)

	void SetLineThickness(float Thickness); // Function Engine.BoxComponent.SetLineThickness // (None) // @ game+0xffffaf9cdf830041
};

// Class Engine.Brush
// Size: 0x2c8 (Inherited: 0x290)
struct ABrush : AActor {
	enum class EBrushType BrushType; // 0x290(0x01)
	char pad_291[0x3]; // 0x291(0x03)
	struct FColor BrushColor; // 0x294(0x04)
	int32_t PolyFlags; // 0x298(0x04)
	char bColored : 1; // 0x29c(0x01)
	char bSolidWhenSelected : 1; // 0x29c(0x01)
	char bPlaceableFromClassBrowser : 1; // 0x29c(0x01)
	char bNotForClientOrServer : 1; // 0x29c(0x01)
	char pad_29C_4 : 4; // 0x29c(0x01)
	char pad_29D[0x3]; // 0x29d(0x03)
	struct UModel* Brush; // 0x2a0(0x08)
	struct UBrushComponent* BrushComponent; // 0x2a8(0x08)
	char bInManipulation : 1; // 0x2b0(0x01)
	char pad_2B0_1 : 7; // 0x2b0(0x01)
	char pad_2B1[0x7]; // 0x2b1(0x07)
	struct TArray<struct FGeomSelection> SavedSelections; // 0x2b8(0x10)
};

// Class Engine.Volume
// Size: 0x2c8 (Inherited: 0x2c8)
struct AVolume : ABrush {
	enum class EBrushType BrushType; // 0x290(0x01)
	struct FColor BrushColor; // 0x294(0x04)
	int32_t PolyFlags; // 0x298(0x04)
	char bColored : 1; // 0x29c(0x01)
	char bSolidWhenSelected : 1; // 0x29c(0x01)
	char bPlaceableFromClassBrowser : 1; // 0x29c(0x01)
	char bNotForClientOrServer : 1; // 0x29c(0x01)
	struct UModel* Brush; // 0x2a0(0x08)
	struct UBrushComponent* BrushComponent; // 0x2a8(0x08)
	char bInManipulation : 1; // 0x2b0(0x01)
	struct TArray<struct FGeomSelection> SavedSelections; // 0x2b8(0x10)
};

// Class Engine.PhysicsVolume
// Size: 0x2d8 (Inherited: 0x2c8)
struct APhysicsVolume : AVolume {
	float TerminalVelocity; // 0x2c8(0x04)
	int32_t Priority; // 0x2cc(0x04)
	float FluidFriction; // 0x2d0(0x04)
	char bWaterVolume : 1; // 0x2d4(0x01)
	char bPhysicsOnContact : 1; // 0x2d4(0x01)
	char pad_2D4_2 : 6; // 0x2d4(0x01)
	char pad_2D5[0x3]; // 0x2d5(0x03)
};

// Class Engine.HLODBuilder
// Size: 0x28 (Inherited: 0x28)
struct UHLODBuilder : UObject {
};

// Class Engine.MeshComponent
// Size: 0x570 (Inherited: 0x540)
struct UMeshComponent : UPrimitiveComponent {
	struct TArray<struct UMaterialInterface*> OverrideMaterials; // 0x538(0x10)
	struct UMaterialInterface* OverlayMaterial; // 0x548(0x08)
	float OverlayMaterialMaxDrawDistance; // 0x550(0x04)
	char pad_55C[0xc]; // 0x55c(0x0c)
	char bEnableMaterialParameterCaching : 1; // 0x568(0x01)
	char pad_568_1 : 7; // 0x568(0x01)
	char pad_569[0x7]; // 0x569(0x07)

	void SetVectorParameterValueOnMaterials(struct FName ParameterName, struct FVector ParameterValue); // Function Engine.MeshComponent.SetVectorParameterValueOnMaterials // (None) // @ game+0xffff9a7cdf830041
};

// Class Engine.SplineComponent
// Size: 0x640 (Inherited: 0x540)
struct USplineComponent : UPrimitiveComponent {
	struct FSplineCurves SplineCurves; // 0x538(0x70)
	struct FInterpCurveVector SplineInfo; // 0x5a8(0x18)
	struct FInterpCurveQuat SplineRotInfo; // 0x5c0(0x18)
	struct FInterpCurveVector SplineScaleInfo; // 0x5d8(0x18)
	struct FInterpCurveFloat SplineReparamTable; // 0x5f0(0x18)
	bool bAllowSplineEditingPerInstance; // 0x608(0x01)
	int32_t ReparamStepsPerSegment; // 0x60c(0x04)
	float Duration; // 0x610(0x04)
	bool bStationaryEndpoints; // 0x614(0x01)
	bool bSplineHasBeenEdited; // 0x615(0x01)
	bool bModifiedByConstructionScript; // 0x616(0x01)
	bool bInputSplinePointsToConstructionScript; // 0x617(0x01)
	bool bDrawDebug; // 0x618(0x01)
	bool bClosedLoop; // 0x619(0x01)
	bool bLoopPositionOverride; // 0x61a(0x01)
	float LoopPosition; // 0x61c(0x04)
	struct FVector DefaultUpVector; // 0x620(0x18)
	char pad_63C[0x4]; // 0x63c(0x04)

	void UpdateSpline(); // Function Engine.SplineComponent.UpdateSpline // (None) // @ game+0xffffb027df830041
};

// Class Engine.SplineMetadata
// Size: 0x28 (Inherited: 0x28)
struct USplineMetadata : UObject {
};

// Class Engine.WorldSubsystem
// Size: 0x30 (Inherited: 0x30)
struct UWorldSubsystem : USubsystem {
};

// Class Engine.TickableWorldSubsystem
// Size: 0x40 (Inherited: 0x30)
struct UTickableWorldSubsystem : UWorldSubsystem {
	char pad_30[0x10]; // 0x30(0x10)
};

// Class Engine.ReplicationDriver
// Size: 0x28 (Inherited: 0x28)
struct UReplicationDriver : UObject {
};

// Class Engine.ReplicationConnectionDriver
// Size: 0x28 (Inherited: 0x28)
struct UReplicationConnectionDriver : UObject {
};

// Class Engine.Player
// Size: 0x48 (Inherited: 0x28)
struct UPlayer : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct APlayerController* PlayerController; // 0x30(0x08)
	int32_t CurrentNetSpeed; // 0x38(0x04)
	int32_t ConfiguredInternetSpeed; // 0x3c(0x04)
	int32_t ConfiguredLanSpeed; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class Engine.NetConnection
// Size: 0x3310 (Inherited: 0x48)
struct UNetConnection : UPlayer {
	struct TArray<struct UChildConnection*> Children; // 0x48(0x10)
	struct UNetDriver* Driver; // 0x58(0x08)
	struct UPackageMap* PackageMapClass; // 0x60(0x08)
	struct UPackageMap* PackageMap; // 0x68(0x08)
	struct TArray<struct UChannel*> OpenChannels; // 0x70(0x10)
	struct TArray<struct AActor*> SentTemporaries; // 0x80(0x10)
	struct AActor* ViewTarget; // 0x90(0x08)
	struct AActor* OwningActor; // 0x98(0x08)
	int32_t MaxPacket; // 0xa0(0x04)
	char InternalAck : 1; // 0xa4(0x01)
	char pad_A4_1 : 7; // 0xa4(0x01)
	char pad_A5[0xbb]; // 0xa5(0xbb)
	struct FUniqueNetIdRepl PlayerId; // 0x160(0x30)
	char pad_190[0x48]; // 0x190(0x48)
	double LastReceiveTime; // 0x1d8(0x08)
	char pad_1E0[0x11e0]; // 0x1e0(0x11e0)
	int32_t DefaultMaxChannelSize; // 0x13c0(0x04)
	char pad_13C4[0x284]; // 0x13c4(0x284)
	struct TArray<struct UChannel*> ChannelsToTick; // 0x1648(0x10)
	char pad_1658[0x1cb8]; // 0x1658(0x1cb8)
};

// Class Engine.NetDriver
// Size: 0x790 (Inherited: 0x28)
struct UNetDriver : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FString NetConnectionClassName; // 0x30(0x10)
	struct FString ReplicationDriverClassName; // 0x40(0x10)
	struct FString ReplicationBridgeClassName; // 0x50(0x10)
	int32_t MaxDownloadSize; // 0x60(0x04)
	char bClampListenServerTickRate : 1; // 0x64(0x01)
	char pad_64_1 : 7; // 0x64(0x01)
	char pad_65[0x3]; // 0x65(0x03)
	int32_t NetServerMaxTickRate; // 0x68(0x04)
	int32_t MaxNetTickRate; // 0x6c(0x04)
	int32_t MaxInternetClientRate; // 0x70(0x04)
	int32_t MaxClientRate; // 0x74(0x04)
	float ServerTravelPause; // 0x78(0x04)
	float SpawnPrioritySeconds; // 0x7c(0x04)
	float RelevantTimeout; // 0x80(0x04)
	float KeepAliveTime; // 0x84(0x04)
	float InitialConnectTimeout; // 0x88(0x04)
	float ConnectionTimeout; // 0x8c(0x04)
	float TimeoutMultiplierForUnoptimizedBuilds; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
	struct UNetConnection* ServerConnection; // 0x98(0x08)
	struct TArray<struct UNetConnection*> ClientConnections; // 0xa0(0x10)
	char pad_B0[0x60]; // 0xb0(0x60)
	int32_t RecentlyDisconnectedTrackingTime; // 0x110(0x04)
	char pad_114[0x3c]; // 0x114(0x3c)
	struct UWorld* World; // 0x150(0x08)
	struct UPackage* WorldPackage; // 0x158(0x08)
	char pad_160[0x20]; // 0x160(0x20)
	ClassPtrProperty NetConnectionClass; // 0x180(0x08)
	ClassPtrProperty ReplicationDriverClass; // 0x188(0x08)
	ClassPtrProperty ReplicationBridgeClass; // 0x190(0x08)
	char pad_198[0x10]; // 0x198(0x10)
	struct FName NetDriverName; // 0x1a8(0x08)
	struct TArray<struct FChannelDefinition> ChannelDefinitions; // 0x1b0(0x10)
	struct TMap<struct FName, struct FChannelDefinition> ChannelDefinitionMap; // 0x1c0(0x50)
	struct TArray<struct UChannel*> ActorChannelPool; // 0x210(0x10)
	char pad_220[0x21]; // 0x220(0x21)
	char pad_241_0 : 6; // 0x241(0x01)
	char bNoTimeouts : 1; // 0x241(0x01)
	char bNeverApplyNetworkEmulationSettings : 1; // 0x241(0x01)
	char pad_242[0x4de]; // 0x242(0x4de)
	struct UReplicationDriver* ReplicationDriver; // 0x720(0x08)
	char pad_728[0x68]; // 0x728(0x68)
};

// Class Engine.OnlineBlueprintCallProxyBase
// Size: 0x30 (Inherited: 0x30)
struct UOnlineBlueprintCallProxyBase : UBlueprintAsyncActionBase {
};

// Class Engine.OnlineEngineInterface
// Size: 0x28 (Inherited: 0x28)
struct UOnlineEngineInterface : UObject {
};

// Class Engine.OnlineSession
// Size: 0x28 (Inherited: 0x28)
struct UOnlineSession : UObject {
};

// Class Engine.DynamicBlueprintBinding
// Size: 0x28 (Inherited: 0x28)
struct UDynamicBlueprintBinding : UObject {
};

// Class Engine.InputDelegateBinding
// Size: 0x28 (Inherited: 0x28)
struct UInputDelegateBinding : UDynamicBlueprintBinding {
};

// Class Engine.InputComponent
// Size: 0x128 (Inherited: 0xa0)
struct UInputComponent : UActorComponent {
	char pad_A0[0x70]; // 0xa0(0x70)
	struct TArray<struct FCachedKeyToActionInfo> CachedKeyToActionInfo; // 0x110(0x10)
	char pad_120[0x8]; // 0x120(0x08)

	bool WasControllerKeyJustReleased(struct FKey Key); // Function Engine.InputComponent.WasControllerKeyJustReleased // (None) // @ game+0xffffb088df830041
};

// Class Engine.Engine
// Size: 0x1050 (Inherited: 0x28)
struct UEngine : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct UFont* TinyFont; // 0x30(0x08)
	struct FSoftObjectPath TinyFontName; // 0x38(0x20)
	struct UFont* SmallFont; // 0x58(0x08)
	struct FSoftObjectPath SmallFontName; // 0x60(0x20)
	struct UFont* MediumFont; // 0x80(0x08)
	struct FSoftObjectPath MediumFontName; // 0x88(0x20)
	struct UFont* LargeFont; // 0xa8(0x08)
	struct FSoftObjectPath LargeFontName; // 0xb0(0x20)
	struct UFont* SubtitleFont; // 0xd0(0x08)
	struct FSoftObjectPath SubtitleFontName; // 0xd8(0x20)
	struct TArray<struct UFont*> AdditionalFonts; // 0xf8(0x10)
	struct TArray<struct FString> AdditionalFontNames; // 0x108(0x10)
	struct UConsole* ConsoleClass; // 0x118(0x08)
	struct FSoftClassPath ConsoleClassName; // 0x120(0x20)
	struct UGameViewportClient* GameViewportClientClass; // 0x140(0x08)
	struct FSoftClassPath GameViewportClientClassName; // 0x148(0x20)
	struct ULocalPlayer* LocalPlayerClass; // 0x168(0x08)
	struct FSoftClassPath LocalPlayerClassName; // 0x170(0x20)
	struct AWorldSettings* WorldSettingsClass; // 0x190(0x08)
	struct FSoftClassPath WorldSettingsClassName; // 0x198(0x20)
	struct FSoftClassPath NavigationSystemClassName; // 0x1b8(0x20)
	struct UNavigationSystemBase* NavigationSystemClass; // 0x1d8(0x08)
	struct FSoftClassPath NavigationSystemConfigClassName; // 0x1e0(0x20)
	struct UNavigationSystemConfig* NavigationSystemConfigClass; // 0x200(0x08)
	struct FSoftClassPath AvoidanceManagerClassName; // 0x208(0x20)
	struct UAvoidanceManager* AvoidanceManagerClass; // 0x228(0x08)
	struct FSoftClassPath AIControllerClassName; // 0x230(0x20)
	struct UPhysicsCollisionHandler* PhysicsCollisionHandlerClass; // 0x250(0x08)
	struct FSoftClassPath PhysicsCollisionHandlerClassName; // 0x258(0x20)
	struct FSoftClassPath GameUserSettingsClassName; // 0x278(0x20)
	struct UGameUserSettings* GameUserSettingsClass; // 0x298(0x08)
	struct UGameUserSettings* GameUserSettings; // 0x2a0(0x08)
	struct ALevelScriptActor* LevelScriptActorClass; // 0x2a8(0x08)
	struct FSoftClassPath LevelScriptActorClassName; // 0x2b0(0x20)
	struct FSoftClassPath DefaultBlueprintBaseClassName; // 0x2d0(0x20)
	struct FSoftClassPath GameSingletonClassName; // 0x2f0(0x20)
	struct UObject* GameSingleton; // 0x310(0x08)
	struct FSoftClassPath AssetManagerClassName; // 0x318(0x20)
	struct UAssetManager* AssetManager; // 0x338(0x08)
	struct UTexture2D* DefaultTexture; // 0x340(0x08)
	struct FSoftObjectPath DefaultTextureName; // 0x348(0x20)
	struct UTexture* DefaultDiffuseTexture; // 0x368(0x08)
	struct FSoftObjectPath DefaultDiffuseTextureName; // 0x370(0x20)
	struct UTexture2D* DefaultBSPVertexTexture; // 0x390(0x08)
	struct FSoftObjectPath DefaultBSPVertexTextureName; // 0x398(0x20)
	struct UTexture2D* HighFrequencyNoiseTexture; // 0x3b8(0x08)
	struct FSoftObjectPath HighFrequencyNoiseTextureName; // 0x3c0(0x20)
	struct UTexture2D* DefaultBokehTexture; // 0x3e0(0x08)
	struct FSoftObjectPath DefaultBokehTextureName; // 0x3e8(0x20)
	struct UTexture2D* DefaultBloomKernelTexture; // 0x408(0x08)
	struct FSoftObjectPath DefaultBloomKernelTextureName; // 0x410(0x20)
	struct UTexture2D* DefaultFilmGrainTexture; // 0x430(0x08)
	struct FSoftObjectPath DefaultFilmGrainTextureName; // 0x438(0x20)
	struct UMaterial* WireframeMaterial; // 0x458(0x08)
	struct FString WireframeMaterialName; // 0x460(0x10)
	struct UMaterial* DebugMeshMaterial; // 0x470(0x08)
	struct FSoftObjectPath DebugMeshMaterialName; // 0x478(0x20)
	struct UMaterial* EmissiveMeshMaterial; // 0x498(0x08)
	struct FSoftObjectPath EmissiveMeshMaterialName; // 0x4a0(0x20)
	struct UMaterial* LevelColorationLitMaterial; // 0x4c0(0x08)
	struct FString LevelColorationLitMaterialName; // 0x4c8(0x10)
	struct UMaterial* LevelColorationUnlitMaterial; // 0x4d8(0x08)
	struct FString LevelColorationUnlitMaterialName; // 0x4e0(0x10)
	struct UMaterial* LightingTexelDensityMaterial; // 0x4f0(0x08)
	struct FString LightingTexelDensityName; // 0x4f8(0x10)
	struct UMaterial* ShadedLevelColorationLitMaterial; // 0x508(0x08)
	struct FString ShadedLevelColorationLitMaterialName; // 0x510(0x10)
	struct UMaterial* ShadedLevelColorationUnlitMaterial; // 0x520(0x08)
	struct FString ShadedLevelColorationUnlitMaterialName; // 0x528(0x10)
	struct UMaterial* RemoveSurfaceMaterial; // 0x538(0x08)
	struct FSoftObjectPath RemoveSurfaceMaterialName; // 0x540(0x20)
	struct UMaterial* VertexColorMaterial; // 0x560(0x08)
	struct FString VertexColorMaterialName; // 0x568(0x10)
	struct UMaterial* VertexColorViewModeMaterial_ColorOnly; // 0x578(0x08)
	struct FString VertexColorViewModeMaterialName_ColorOnly; // 0x580(0x10)
	struct UMaterial* VertexColorViewModeMaterial_AlphaAsColor; // 0x590(0x08)
	struct FString VertexColorViewModeMaterialName_AlphaAsColor; // 0x598(0x10)
	struct UMaterial* VertexColorViewModeMaterial_RedOnly; // 0x5a8(0x08)
	struct FString VertexColorViewModeMaterialName_RedOnly; // 0x5b0(0x10)
	struct UMaterial* VertexColorViewModeMaterial_GreenOnly; // 0x5c0(0x08)
	struct FString VertexColorViewModeMaterialName_GreenOnly; // 0x5c8(0x10)
	struct UMaterial* VertexColorViewModeMaterial_BlueOnly; // 0x5d8(0x08)
	struct FString VertexColorViewModeMaterialName_BlueOnly; // 0x5e0(0x10)
	struct FSoftObjectPath DebugEditorMaterialName; // 0x5f0(0x20)
	struct UMaterial* ConstraintLimitMaterial; // 0x610(0x08)
	struct UMaterialInstanceDynamic* ConstraintLimitMaterialX; // 0x618(0x08)
	struct UMaterialInstanceDynamic* ConstraintLimitMaterialXAxis; // 0x620(0x08)
	struct UMaterialInstanceDynamic* ConstraintLimitMaterialY; // 0x628(0x08)
	struct UMaterialInstanceDynamic* ConstraintLimitMaterialYAxis; // 0x630(0x08)
	struct UMaterialInstanceDynamic* ConstraintLimitMaterialZ; // 0x638(0x08)
	struct UMaterialInstanceDynamic* ConstraintLimitMaterialZAxis; // 0x640(0x08)
	struct UMaterialInstanceDynamic* ConstraintLimitMaterialPrismatic; // 0x648(0x08)
	struct UMaterial* InvalidLightmapSettingsMaterial; // 0x650(0x08)
	struct FSoftObjectPath InvalidLightmapSettingsMaterialName; // 0x658(0x20)
	struct UMaterial* PreviewShadowsIndicatorMaterial; // 0x678(0x08)
	struct FSoftObjectPath PreviewShadowsIndicatorMaterialName; // 0x680(0x20)
	struct UMaterial* ArrowMaterial; // 0x6a0(0x08)
	struct UMaterialInstanceDynamic* ArrowMaterialYellow; // 0x6a8(0x08)
	struct FSoftObjectPath ArrowMaterialName; // 0x6b0(0x20)
	struct FLinearColor LightingOnlyBrightness; // 0x6d0(0x10)
	struct TArray<struct FLinearColor> ShaderComplexityColors; // 0x6e0(0x10)
	struct TArray<struct FLinearColor> QuadComplexityColors; // 0x6f0(0x10)
	struct TArray<struct FLinearColor> LightComplexityColors; // 0x700(0x10)
	struct TArray<struct FLinearColor> StationaryLightOverlapColors; // 0x710(0x10)
	struct TArray<struct FLinearColor> LODColorationColors; // 0x720(0x10)
	struct TArray<struct FLinearColor> HLODColorationColors; // 0x730(0x10)
	struct TArray<struct FLinearColor> StreamingAccuracyColors; // 0x740(0x10)
	struct FLinearColor GPUSkinCacheVisualizationExcludedColor; // 0x750(0x10)
	struct FLinearColor GPUSkinCacheVisualizationIncludedColor; // 0x760(0x10)
	struct FLinearColor GPUSkinCacheVisualizationRecomputeTangentsColor; // 0x770(0x10)
	float GPUSkinCacheVisualizationLowMemoryThresholdInMB; // 0x780(0x04)
	float GPUSkinCacheVisualizationHighMemoryThresholdInMB; // 0x784(0x04)
	struct FLinearColor GPUSkinCacheVisualizationLowMemoryColor; // 0x788(0x10)
	struct FLinearColor GPUSkinCacheVisualizationMidMemoryColor; // 0x798(0x10)
	struct FLinearColor GPUSkinCacheVisualizationHighMemoryColor; // 0x7a8(0x10)
	struct TArray<struct FLinearColor> GPUSkinCacheVisualizationRayTracingLODOffsetColors; // 0x7b8(0x10)
	float MaxPixelShaderAdditiveComplexityCount; // 0x7c8(0x04)
	float MaxES3PixelShaderAdditiveComplexityCount; // 0x7cc(0x04)
	float MinLightMapDensity; // 0x7d0(0x04)
	float IdealLightMapDensity; // 0x7d4(0x04)
	float MaxLightMapDensity; // 0x7d8(0x04)
	char bRenderLightMapDensityGrayscale : 1; // 0x7dc(0x01)
	char pad_7DC_1 : 7; // 0x7dc(0x01)
	char pad_7DD[0x3]; // 0x7dd(0x03)
	float RenderLightMapDensityGrayscaleScale; // 0x7e0(0x04)
	float RenderLightMapDensityColorScale; // 0x7e4(0x04)
	struct FLinearColor LightMapDensityVertexMappedColor; // 0x7e8(0x10)
	struct FLinearColor LightMapDensitySelectedColor; // 0x7f8(0x10)
	struct TArray<struct FStatColorMapping> StatColorMappings; // 0x808(0x10)
	struct UPhysicalMaterial* DefaultPhysMaterial; // 0x818(0x08)
	struct FSoftObjectPath DefaultPhysMaterialName; // 0x820(0x20)
	struct UPhysicalMaterial* DefaultDestructiblePhysMaterial; // 0x840(0x08)
	struct FSoftObjectPath DefaultDestructiblePhysMaterialName; // 0x848(0x20)
	struct TArray<struct FGameNameRedirect> ActiveGameNameRedirects; // 0x868(0x10)
	struct TArray<struct FClassRedirect> ActiveClassRedirects; // 0x878(0x10)
	struct TArray<struct FPluginRedirect> ActivePluginRedirects; // 0x888(0x10)
	struct TArray<struct FStructRedirect> ActiveStructRedirects; // 0x898(0x10)
	struct UTexture2D* PreIntegratedSkinBRDFTexture; // 0x8a8(0x08)
	struct FSoftObjectPath PreIntegratedSkinBRDFTextureName; // 0x8b0(0x20)
	struct UTexture2D* BlueNoiseScalarTexture; // 0x8d0(0x08)
	struct UTexture2D* BlueNoiseVec2Texture; // 0x8d8(0x08)
	struct FSoftObjectPath BlueNoiseScalarTextureName; // 0x8e0(0x20)
	struct FSoftObjectPath BlueNoiseVec2TextureName; // 0x900(0x20)
	struct UTexture2D* MiniFontTexture; // 0x920(0x08)
	struct FSoftObjectPath MiniFontTextureName; // 0x928(0x20)
	struct UTexture* WeightMapPlaceholderTexture; // 0x948(0x08)
	struct FSoftObjectPath WeightMapPlaceholderTextureName; // 0x950(0x20)
	struct UTexture2D* LightMapDensityTexture; // 0x970(0x08)
	struct FSoftObjectPath LightMapDensityTextureName; // 0x978(0x20)
	char pad_998[0x8]; // 0x998(0x08)
	struct UGameViewportClient* GameViewport; // 0x9a0(0x08)
	struct TArray<struct FString> DeferredCommands; // 0x9a8(0x10)
	float NearClipPlane; // 0x9b8(0x04)
	char bSubtitlesEnabled : 1; // 0x9bc(0x01)
	char bSubtitlesForcedOff : 1; // 0x9bc(0x01)
	char pad_9BC_2 : 6; // 0x9bc(0x01)
	char pad_9BD[0x3]; // 0x9bd(0x03)
	int32_t MaximumLoopIterationCount; // 0x9c0(0x04)
	char bCanBlueprintsTickByDefault : 1; // 0x9c4(0x01)
	char bOptimizeAnimBlueprintMemberVariableAccess : 1; // 0x9c4(0x01)
	char bAllowMultiThreadedAnimationUpdate : 1; // 0x9c4(0x01)
	char bEnableEditorPSysRealtimeLOD : 1; // 0x9c4(0x01)
	char pad_9C4_4 : 1; // 0x9c4(0x01)
	char bSmoothFrameRate : 1; // 0x9c4(0x01)
	char bUseFixedFrameRate : 1; // 0x9c4(0x01)
	char pad_9C4_7 : 1; // 0x9c4(0x01)
	char pad_9C5[0x3]; // 0x9c5(0x03)
	float FixedFrameRate; // 0x9c8(0x04)
	struct FFloatRange SmoothedFrameRateRange; // 0x9cc(0x10)
	char pad_9DC[0x4]; // 0x9dc(0x04)
	struct UEngineCustomTimeStep* CustomTimeStep; // 0x9e0(0x08)
	char pad_9E8[0x20]; // 0x9e8(0x20)
	struct FSoftClassPath CustomTimeStepClassName; // 0xa08(0x20)
	struct UTimecodeProvider* TimecodeProvider; // 0xa28(0x08)
	char pad_A30[0x20]; // 0xa30(0x20)
	struct FSoftClassPath TimecodeProviderClassName; // 0xa50(0x20)
	bool bGenerateDefaultTimecode; // 0xa70(0x01)
	char pad_A71[0x3]; // 0xa71(0x03)
	struct FFrameRate GenerateDefaultTimecodeFrameRate; // 0xa74(0x08)
	float GenerateDefaultTimecodeFrameDelay; // 0xa7c(0x04)
	char bCheckForMultiplePawnsSpawnedInAFrame : 1; // 0xa80(0x01)
	char pad_A80_1 : 7; // 0xa80(0x01)
	char pad_A81[0x3]; // 0xa81(0x03)
	int32_t NumPawnsAllowedToBeSpawnedInAFrame; // 0xa84(0x04)
	char bShouldGenerateLowQualityLightmaps : 1; // 0xa88(0x01)
	char pad_A88_1 : 7; // 0xa88(0x01)
	char pad_A89[0x3]; // 0xa89(0x03)
	struct FColor C_WorldBox; // 0xa8c(0x04)
	struct FColor C_BrushWire; // 0xa90(0x04)
	struct FColor C_AddWire; // 0xa94(0x04)
	struct FColor C_SubtractWire; // 0xa98(0x04)
	struct FColor C_SemiSolidWire; // 0xa9c(0x04)
	struct FColor C_NonSolidWire; // 0xaa0(0x04)
	struct FColor C_WireBackground; // 0xaa4(0x04)
	struct FColor C_ScaleBoxHi; // 0xaa8(0x04)
	struct FColor C_VolumeCollision; // 0xaac(0x04)
	struct FColor C_BSPCollision; // 0xab0(0x04)
	struct FColor C_OrthoBackground; // 0xab4(0x04)
	struct FColor C_Volume; // 0xab8(0x04)
	struct FColor C_BrushShape; // 0xabc(0x04)
	float StreamingDistanceFactor; // 0xac0(0x04)
	char pad_AC4[0x4]; // 0xac4(0x04)
	struct FDirectoryPath GameScreenshotSaveDirectory; // 0xac8(0x10)
	bool UseStaticMeshMinLODPerQualityLevels; // 0xad8(0x01)
	bool UseSkeletalMeshMinLODPerQualityLevels; // 0xad9(0x01)
	enum class ETransitionType TransitionType; // 0xada(0x01)
	char pad_ADB[0x5]; // 0xadb(0x05)
	struct FString TransitionDescription; // 0xae0(0x10)
	struct FString TransitionGameMode; // 0xaf0(0x10)
	char bAllowMatureLanguage : 1; // 0xb00(0x01)
	char pad_B00_1 : 7; // 0xb00(0x01)
	char pad_B01[0x3]; // 0xb01(0x03)
	float CameraRotationThreshold; // 0xb04(0x04)
	float CameraTranslationThreshold; // 0xb08(0x04)
	float PrimitiveProbablyVisibleTime; // 0xb0c(0x04)
	float MaxOcclusionPixelsFraction; // 0xb10(0x04)
	char bPauseOnLossOfFocus : 1; // 0xb14(0x01)
	char pad_B14_1 : 7; // 0xb14(0x01)
	char pad_B15[0x3]; // 0xb15(0x03)
	int32_t MaxParticleResize; // 0xb18(0x04)
	int32_t MaxParticleResizeWarn; // 0xb1c(0x04)
	struct TArray<struct FDropNoteInfo> PendingDroppedNotes; // 0xb20(0x10)
	float NetClientTicksPerSecond; // 0xb30(0x04)
	float DisplayGamma; // 0xb34(0x04)
	float MinDesiredFrameRate; // 0xb38(0x04)
	struct FLinearColor DefaultSelectedMaterialColor; // 0xb3c(0x10)
	struct FLinearColor SelectedMaterialColor; // 0xb4c(0x10)
	struct FLinearColor SelectionOutlineColor; // 0xb5c(0x10)
	struct FLinearColor SubduedSelectionOutlineColor; // 0xb6c(0x10)
	struct FLinearColor SelectedMaterialColorOverride; // 0xb7c(0x10)
	bool bIsOverridingSelectedColor; // 0xb8c(0x01)
	char pad_B8D[0x3]; // 0xb8d(0x03)
	char bEnableOnScreenDebugMessages : 1; // 0xb90(0x01)
	char bEnableOnScreenDebugMessagesDisplay : 1; // 0xb90(0x01)
	char bSuppressMapWarnings : 1; // 0xb90(0x01)
	char bDisableAILogging : 1; // 0xb90(0x01)
	char pad_B90_4 : 4; // 0xb90(0x01)
	char pad_B91[0x3]; // 0xb91(0x03)
	uint32_t bEnableVisualLogRecordingOnStart; // 0xb94(0x04)
	int32_t ScreenSaverInhibitorSemaphore; // 0xb98(0x04)
	char bLockReadOnlyLevels : 1; // 0xb9c(0x01)
	char pad_B9C_1 : 7; // 0xb9c(0x01)
	char pad_B9D[0x3]; // 0xb9d(0x03)
	struct FString ParticleEventManagerClassPath; // 0xba0(0x10)
	float SelectionHighlightIntensity; // 0xbb0(0x04)
	float BSPSelectionHighlightIntensity; // 0xbb4(0x04)
	float SelectionHighlightIntensityBillboards; // 0xbb8(0x04)
	char pad_BBC[0x294]; // 0xbbc(0x294)
	uint32_t GlobalNetTravelCount; // 0xe50(0x04)
	char pad_E54[0x4]; // 0xe54(0x04)
	struct TArray<struct FNetDriverDefinition> NetDriverDefinitions; // 0xe58(0x10)
	struct TArray<struct FIrisNetDriverConfig> IrisNetDriverConfigs; // 0xe68(0x10)
	struct TArray<struct FString> ServerActors; // 0xe78(0x10)
	struct TArray<struct FString> RuntimeServerActors; // 0xe88(0x10)
	float NetErrorLogInterval; // 0xe98(0x04)
	char bStartedLoadMapMovie : 1; // 0xe9c(0x01)
	char pad_E9C_1 : 7; // 0xe9c(0x01)
	char pad_E9D[0x1b]; // 0xe9d(0x1b)
	int32_t NextWorldContextHandle; // 0xeb8(0x04)
	char pad_EBC[0x194]; // 0xebc(0x194)
};

// Class Engine.LocalPlayer
// Size: 0x298 (Inherited: 0x48)
struct ULocalPlayer : UPlayer {
	char pad_48[0x30]; // 0x48(0x30)
	struct UGameViewportClient* ViewportClient; // 0x78(0x08)
	char pad_80[0x38]; // 0x80(0x38)
	enum class EAspectRatioAxisConstraint AspectRatioAxisConstraint; // 0xb8(0x01)
	char pad_B9[0x7]; // 0xb9(0x07)
	struct APlayerController* PendingLevelPlayerControllerClass; // 0xc0(0x08)
	char bSentSplitJoin : 1; // 0xc8(0x01)
	char pad_C8_1 : 7; // 0xc8(0x01)
	char pad_C9[0x17]; // 0xc9(0x17)
	int32_t ControllerId; // 0xe0(0x04)
	char pad_E4[0x1b4]; // 0xe4(0x1b4)
};

// Class Engine.LocalPlayerSubsystem
// Size: 0x30 (Inherited: 0x30)
struct ULocalPlayerSubsystem : USubsystem {
};

// Class Engine.PlayerInput
// Size: 0x498 (Inherited: 0x28)
struct UPlayerInput : UObject {
	char pad_28[0x178]; // 0x28(0x178)
	struct TArray<struct FKeyBind> DebugExecBindings; // 0x1a0(0x10)
	char pad_1B0[0x30]; // 0x1b0(0x30)
	struct TArray<struct FName> InvertedAxis; // 0x1e0(0x10)
	char pad_1F0[0x2a8]; // 0x1f0(0x2a8)

	void SetMouseSensitivity(float Sensitivity); // Function Engine.PlayerInput.SetMouseSensitivity // (None) // @ game+0xffffb0abdf830041
};

// Class Engine.PrimaryDataAsset
// Size: 0x30 (Inherited: 0x30)
struct UPrimaryDataAsset : UDataAsset {
	struct UDataAsset* NativeClass; // 0x28(0x08)
};

// Class Engine.ScriptViewportClient
// Size: 0x38 (Inherited: 0x28)
struct UScriptViewportClient : UObject {
	char pad_28[0x10]; // 0x28(0x10)
};

// Class Engine.GameViewportClient
// Size: 0x3a0 (Inherited: 0x38)
struct UGameViewportClient : UScriptViewportClient {
	char pad_38[0x8]; // 0x38(0x08)
	struct UConsole* ViewportConsole; // 0x40(0x08)
	struct TArray<struct FDebugDisplayProperty> DebugProperties; // 0x48(0x10)
	char pad_58[0x10]; // 0x58(0x10)
	int32_t MaxSplitscreenPlayers; // 0x68(0x04)
	char pad_6C[0xc]; // 0x6c(0x0c)
	struct UWorld* World; // 0x78(0x08)
	struct UGameInstance* GameInstance; // 0x80(0x08)
	char pad_88[0x318]; // 0x88(0x318)

	void SSSwapControllers(); // Function Engine.GameViewportClient.SSSwapControllers // (None) // @ game+0xffffb144df830041
};

// Class Engine.GameInstance
// Size: 0x1c0 (Inherited: 0x28)
struct UGameInstance : UObject {
	char pad_28[0x10]; // 0x28(0x10)
	struct TArray<struct ULocalPlayer*> LocalPlayers; // 0x38(0x10)
	struct UOnlineSession* OnlineSession; // 0x48(0x08)
	struct TArray<struct UObject*> ReferencedObjects; // 0x50(0x10)
	char pad_60[0x18]; // 0x60(0x18)
	struct FMulticastInlineDelegate OnPawnControllerChangedDelegates; // 0x78(0x10)
	char pad_88[0x18]; // 0x88(0x18)
	struct FMulticastInlineDelegate OnInputDeviceConnectionChange; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnUserInputDevicePairingChange; // 0xb0(0x10)
	char pad_C0[0x100]; // 0xc0(0x100)

	void ReceiveShutdown(); // Function Engine.GameInstance.ReceiveShutdown // (None) // @ game+0xffff9280df830041
};

// Class Engine.GameInstanceSubsystem
// Size: 0x30 (Inherited: 0x30)
struct UGameInstanceSubsystem : USubsystem {
};

// Class Engine.DataTable
// Size: 0xb0 (Inherited: 0x28)
struct UDataTable : UObject {
	struct UScriptStruct* RowStruct; // 0x28(0x08)
	char pad_30[0x50]; // 0x30(0x50)
	char bStripFromClientBuilds : 1; // 0x80(0x01)
	char bIgnoreExtraFields : 1; // 0x80(0x01)
	char bIgnoreMissingFields : 1; // 0x80(0x01)
	char pad_80_3 : 5; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
	struct FString ImportKeyField; // 0x88(0x10)
	char pad_98[0x18]; // 0x98(0x18)
};

// Class Engine.World
// Size: 0x898 (Inherited: 0x28)
struct UWorld : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct ULevel* PersistentLevel; // 0x30(0x08)
	struct UNetDriver* NetDriver; // 0x38(0x08)
	struct ULineBatchComponent* LineBatcher; // 0x40(0x08)
	struct ULineBatchComponent* PersistentLineBatcher; // 0x48(0x08)
	struct ULineBatchComponent* ForegroundLineBatcher; // 0x50(0x08)
	struct AGameNetworkManager* NetworkManager; // 0x58(0x08)
	struct UPhysicsCollisionHandler* PhysicsCollisionHandler; // 0x60(0x08)
	struct TArray<struct UObject*> ExtraReferencedObjects; // 0x68(0x10)
	struct TArray<struct UObject*> PerModuleDataObjects; // 0x78(0x10)
	struct TArray<struct ULevelStreaming*> StreamingLevels; // 0x88(0x10)
	struct FStreamingLevelsToConsider StreamingLevelsToConsider; // 0x98(0x28)
	struct AServerStreamingLevelsVisibility* ServerStreamingLevelsVisibility; // 0xc0(0x08)
	struct FString StreamingLevelsPrefix; // 0xc8(0x10)
	char pad_D8[0x8]; // 0xd8(0x08)
	struct ULevel* CurrentLevelPendingVisibility; // 0xe0(0x08)
	struct ULevel* CurrentLevelPendingInvisibility; // 0xe8(0x08)
	struct UDemoNetDriver* DemoNetDriver; // 0xf0(0x08)
	struct AParticleEventManager* MyParticleEventManager; // 0xf8(0x08)
	struct APhysicsVolume* DefaultPhysicsVolume; // 0x100(0x08)
	char pad_108[0x36]; // 0x108(0x36)
	char pad_13E_0 : 2; // 0x13e(0x01)
	char bAreConstraintsDirty : 1; // 0x13e(0x01)
	char pad_13E_3 : 5; // 0x13e(0x01)
	char pad_13F[0x9]; // 0x13f(0x09)
	struct UNavigationSystemBase* NavigationSystem; // 0x148(0x08)
	struct AGameModeBase* AuthorityGameMode; // 0x150(0x08)
	struct AGameStateBase* GameState; // 0x158(0x08)
	struct UAISystemBase* AISystem; // 0x160(0x08)
	struct UAvoidanceManager* AvoidanceManager; // 0x168(0x08)
	struct TArray<struct ULevel*> Levels; // 0x170(0x10)
	struct TArray<struct FLevelCollection> LevelCollections; // 0x180(0x10)
	char pad_190[0x28]; // 0x190(0x28)
	struct UGameInstance* OwningGameInstance; // 0x1b8(0x08)
	struct TArray<struct UMaterialParameterCollectionInstance*> ParameterCollectionInstances; // 0x1c0(0x10)
	struct UCanvas* CanvasForRenderingToTarget; // 0x1d0(0x08)
	struct UCanvas* CanvasForDrawMaterialToRenderTarget; // 0x1d8(0x08)
	char pad_1E0[0x70]; // 0x1e0(0x70)
	struct UPhysicsFieldComponent* PhysicsField; // 0x250(0x08)
	uint32_t LWILastAssignedUID; // 0x258(0x04)
	char pad_25C[0x4]; // 0x25c(0x04)
	struct TSet<struct UActorComponent*> ComponentsThatNeedPreEndOfFrameSync; // 0x260(0x50)
	struct TArray<struct UActorComponent*> ComponentsThatNeedEndOfFrameUpdate; // 0x2b0(0x10)
	struct TArray<struct UActorComponent*> ComponentsThatNeedEndOfFrameUpdate_OnGameThread; // 0x2c0(0x10)
	char pad_2D0[0x3f8]; // 0x2d0(0x3f8)
	struct UWorldComposition* WorldComposition; // 0x6c8(0x08)
	struct UContentBundleManager* ContentBundleManager; // 0x6d0(0x08)
	char pad_6D8[0xa8]; // 0x6d8(0xa8)
	struct FWorldPSCPool PSCPool; // 0x780(0x58)
	char pad_7D8[0xc0]; // 0x7d8(0xc0)

	struct AWorldSettings* K2_GetWorldSettings(); // Function Engine.World.K2_GetWorldSettings // (None) // @ game+0xffffd2b7df830041
};

// Class Engine.RuntimeOptionsBase
// Size: 0x38 (Inherited: 0x28)
struct URuntimeOptionsBase : UObject {
	char pad_28[0x10]; // 0x28(0x10)
};

// Class Engine.Character
// Size: 0x620 (Inherited: 0x318)
struct ACharacter : APawn {
	struct USkeletalMeshComponent* Mesh; // 0x318(0x08)
	struct UCharacterMovementComponent* CharacterMovement; // 0x320(0x08)
	struct UCapsuleComponent* CapsuleComponent; // 0x328(0x08)
	struct FBasedMovementInfo BasedMovement; // 0x330(0x48)
	struct FBasedMovementInfo ReplicatedBasedMovement; // 0x378(0x48)
	float AnimRootMotionTranslationScale; // 0x3c0(0x04)
	char pad_3C4[0x4]; // 0x3c4(0x04)
	struct FVector BaseTranslationOffset; // 0x3c8(0x18)
	struct FQuat BaseRotationOffset; // 0x3e0(0x20)
	float ReplicatedServerLastTransformUpdateTimeStamp; // 0x400(0x04)
	float ReplayLastTransformUpdateTimeStamp; // 0x404(0x04)
	char ReplicatedMovementMode; // 0x408(0x01)
	bool bInBaseReplication; // 0x409(0x01)
	char pad_40A[0x2]; // 0x40a(0x02)
	float CrouchedEyeHeight; // 0x40c(0x04)
	char bIsCrouched : 1; // 0x410(0x01)
	char bProxyIsJumpForceApplied : 1; // 0x410(0x01)
	char bPressedJump : 1; // 0x410(0x01)
	char bClientUpdating : 1; // 0x410(0x01)
	char bClientWasFalling : 1; // 0x410(0x01)
	char bClientResimulateRootMotion : 1; // 0x410(0x01)
	char bClientResimulateRootMotionSources : 1; // 0x410(0x01)
	char bSimGravityDisabled : 1; // 0x410(0x01)
	char bClientCheckEncroachmentOnNetUpdate : 1; // 0x411(0x01)
	char bServerMoveIgnoreRootMotion : 1; // 0x411(0x01)
	char bWasJumping : 1; // 0x411(0x01)
	char pad_411_3 : 5; // 0x411(0x01)
	char pad_412[0x2]; // 0x412(0x02)
	float JumpKeyHoldTime; // 0x414(0x04)
	float JumpForceTimeRemaining; // 0x418(0x04)
	float ProxyJumpForceStartedTime; // 0x41c(0x04)
	float JumpMaxHoldTime; // 0x420(0x04)
	int32_t JumpMaxCount; // 0x424(0x04)
	int32_t JumpCurrentCount; // 0x428(0x04)
	int32_t JumpCurrentCountPreJump; // 0x42c(0x04)
	char pad_430[0x8]; // 0x430(0x08)
	struct FMulticastInlineDelegate OnReachedJumpApex; // 0x438(0x10)
	struct FMulticastInlineDelegate LandedDelegate; // 0x448(0x10)
	struct FMulticastInlineDelegate MovementModeChangedDelegate; // 0x458(0x10)
	struct FMulticastInlineDelegate OnCharacterMovementUpdated; // 0x468(0x10)
	struct FRootMotionSourceGroup SavedRootMotion; // 0x478(0x48)
	struct FRootMotionMovementParams ClientRootMotionParams; // 0x4c0(0x70)
	struct TArray<struct FSimulatedRootMotionReplicatedMove> RootMotionRepMoves; // 0x530(0x10)
	struct FRepRootMotionMontage RepRootMotion; // 0x540(0xd8)
	char pad_618[0x8]; // 0x618(0x08)

	void UnCrouch(bool bClientSimulation); // Function Engine.Character.UnCrouch // (None) // @ game+0xffffb3d8df830041
};

// Class Engine.MaterialExpression
// Size: 0xb0 (Inherited: 0x28)
struct UMaterialExpression : UObject {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	char pad_40[0x10]; // 0x40(0x10)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char pad_80[0x4]; // 0x80(0x04)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char pad_84_2 : 6; // 0x84(0x01)
	char pad_85[0x3]; // 0x85(0x03)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char pad_88_1 : 7; // 0x88(0x01)
	char pad_89[0x3]; // 0x89(0x03)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	char pad_8D[0x3]; // 0x8d(0x03)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionTextureBase
// Size: 0xc0 (Inherited: 0xb0)
struct UMaterialExpressionTextureBase : UMaterialExpression {
	struct UTexture* Texture; // 0xb0(0x08)
	enum class EMaterialSamplerType SamplerType; // 0xb8(0x01)
	char IsDefaultMeshpaintTexture : 1; // 0xb9(0x01)
	char pad_B9_1 : 7; // 0xb9(0x01)
	char pad_BA[0x6]; // 0xba(0x06)
};

// Class Engine.MaterialExpressionTextureSample
// Size: 0x1b8 (Inherited: 0xc0)
struct UMaterialExpressionTextureSample : UMaterialExpressionTextureBase {
	struct FExpressionInput Coordinates; // 0xc0(0x28)
	struct FExpressionInput TextureObject; // 0xe8(0x28)
	struct FExpressionInput MipValue; // 0x110(0x28)
	struct FExpressionInput CoordinatesDX; // 0x138(0x28)
	struct FExpressionInput CoordinatesDY; // 0x160(0x28)
	struct FExpressionInput AutomaticViewMipBiasValue; // 0x188(0x28)
	enum class ETextureMipValueMode MipValueMode; // 0x1b0(0x01)
	enum class ESamplerSourceMode SamplerSource; // 0x1b1(0x01)
	char AutomaticViewMipBias : 1; // 0x1b2(0x01)
	char pad_1B2_1 : 7; // 0x1b2(0x01)
	char ConstCoordinate; // 0x1b3(0x01)
	int32_t ConstMipValue; // 0x1b4(0x04)
};

// Class Engine.MaterialExpressionTextureSampleParameter
// Size: 0x240 (Inherited: 0x1b8)
struct UMaterialExpressionTextureSampleParameter : UMaterialExpressionTextureSample {
	struct FName ParameterName; // 0x1b8(0x08)
	struct FGuid ExpressionGUID; // 0x1c0(0x10)
	struct FName Group; // 0x1d0(0x08)
	int32_t SortPriority; // 0x1d8(0x04)
	char pad_1DC[0x4]; // 0x1dc(0x04)
	struct FParameterChannelNames ChannelNames; // 0x1e0(0x60)
};

// Class Engine.MaterialExpressionTextureSampleParameter2D
// Size: 0x240 (Inherited: 0x240)
struct UMaterialExpressionTextureSampleParameter2D : UMaterialExpressionTextureSampleParameter {
	struct FName ParameterName; // 0x1b8(0x08)
	struct FGuid ExpressionGUID; // 0x1c0(0x10)
	struct FName Group; // 0x1d0(0x08)
	int32_t SortPriority; // 0x1d8(0x04)
	struct FParameterChannelNames ChannelNames; // 0x1e0(0x60)
};

// Class Engine.SkinnedMeshComponent
// Size: 0x8a0 (Inherited: 0x570)
struct USkinnedMeshComponent : UMeshComponent {
	char pad_570[0x8]; // 0x570(0x08)
	struct USkeletalMesh* SkeletalMesh; // 0x578(0x08)
	struct USkinnedAsset* SkinnedAsset; // 0x580(0x08)
	struct TWeakObjectPtr<struct USkinnedMeshComponent> LeaderPoseComponent; // 0x588(0x08)
	struct TArray<enum class ESkinCacheUsage> SkinCacheUsage; // 0x590(0x10)
	bool bSetMeshDeformer; // 0x5a0(0x01)
	char pad_5A1[0x7]; // 0x5a1(0x07)
	struct UMeshDeformer* MeshDeformer; // 0x5a8(0x08)
	struct UMeshDeformerInstanceSettings* MeshDeformerInstanceSettings; // 0x5b0(0x08)
	struct UMeshDeformerInstance* MeshDeformerInstance; // 0x5b8(0x08)
	char pad_5C0[0x168]; // 0x5c0(0x168)
	struct UPhysicsAsset* PhysicsAssetOverride; // 0x728(0x08)
	int32_t ForcedLodModel; // 0x730(0x04)
	int32_t MinLodModel; // 0x734(0x04)
	char pad_738[0x8]; // 0x738(0x08)
	float StreamingDistanceMultiplier; // 0x740(0x04)
	char pad_744[0xc]; // 0x744(0x0c)
	struct TArray<struct FSkelMeshComponentLODInfo> LODInfo; // 0x750(0x10)
	char pad_760[0x24]; // 0x760(0x24)
	enum class EVisibilityBasedAnimTickOption VisibilityBasedAnimTickOption; // 0x784(0x01)
	char pad_785[0x1]; // 0x785(0x01)
	char pad_786_0 : 3; // 0x786(0x01)
	char bOverrideMinLod : 1; // 0x786(0x01)
	char bUseBoundsFromLeaderPoseComponent : 1; // 0x786(0x01)
	char bForceWireframe : 1; // 0x786(0x01)
	char bDisplayBones : 1; // 0x786(0x01)
	char bDisableMorphTarget : 1; // 0x786(0x01)
	char bHideSkin : 1; // 0x787(0x01)
	char bPerBoneMotionBlur : 1; // 0x787(0x01)
	char bComponentUseFixedSkelBounds : 1; // 0x787(0x01)
	char bConsiderAllBodiesForBounds : 1; // 0x787(0x01)
	char bSyncAttachParentLOD : 1; // 0x787(0x01)
	char bCanHighlightSelectedSections : 1; // 0x787(0x01)
	char bRecentlyRendered : 1; // 0x787(0x01)
	char bCastCapsuleDirectShadow : 1; // 0x787(0x01)
	char bCastCapsuleIndirectShadow : 1; // 0x788(0x01)
	char bCPUSkinning : 1; // 0x788(0x01)
	char bEnableUpdateRateOptimizations : 1; // 0x788(0x01)
	char bDisplayDebugUpdateRateOptimizations : 1; // 0x788(0x01)
	char bRenderStatic : 1; // 0x788(0x01)
	char bIgnoreLeaderPoseComponentLOD : 1; // 0x788(0x01)
	char pad_788_6 : 2; // 0x788(0x01)
	char bCachedLocalBoundsUpToDate : 1; // 0x789(0x01)
	char bCachedWorldSpaceBoundsUpToDate : 1; // 0x789(0x01)
	char pad_789_2 : 2; // 0x789(0x01)
	char bForceMeshObjectUpdate : 1; // 0x789(0x01)
	char pad_789_5 : 3; // 0x789(0x01)
	char pad_78A_0 : 2; // 0x78a(0x01)
	char bFollowerShouldTickPose : 1; // 0x78a(0x01)
	char pad_78A_3 : 5; // 0x78a(0x01)
	char pad_78B[0x1]; // 0x78b(0x01)
	float CapsuleIndirectShadowMinVisibility; // 0x78c(0x04)
	char pad_790[0x38]; // 0x790(0x38)
	struct FBoxSphereBounds CachedWorldOrLocalSpaceBounds; // 0x7c8(0x38)
	struct FMatrix CachedWorldToLocalTransform; // 0x800(0x80)
	char pad_880[0x20]; // 0x880(0x20)

	void UnloadSkinWeightProfile(struct FName InProfileName); // Function Engine.SkinnedMeshComponent.UnloadSkinWeightProfile // (None) // @ game+0xffffc010df830041
};

// Class Engine.SkeletalMeshComponent
// Size: 0xf80 (Inherited: 0x8a0)
struct USkeletalMeshComponent : USkinnedMeshComponent {
	ClassPtrProperty AnimBlueprintGeneratedClass; // 0x8a0(0x08)
	struct UAnimInstance* AnimClass; // 0x8a8(0x08)
	struct UAnimInstance* AnimScriptInstance; // 0x8b0(0x08)
	struct UAnimInstance* PostProcessAnimInstance; // 0x8b8(0x08)
	struct FSingleAnimationPlayData AnimationData; // 0x8c0(0x18)
	char pad_8D8[0x10]; // 0x8d8(0x10)
	struct FVector RootBoneTranslation; // 0x8e8(0x18)
	struct FVector LineCheckBoundsScale; // 0x900(0x18)
	char pad_918[0x30]; // 0x918(0x30)
	struct TArray<struct UAnimInstance*> LinkedInstances; // 0x948(0x10)
	struct TArray<struct FTransform> CachedBoneSpaceTransforms; // 0x958(0x10)
	struct TArray<struct FTransform> CachedComponentSpaceTransforms; // 0x968(0x10)
	char pad_978[0xb0]; // 0x978(0xb0)
	float GlobalAnimRateScale; // 0xa28(0x04)
	enum class EKinematicBonesUpdateToPhysics KinematicBonesUpdateType; // 0xa2c(0x01)
	enum class EPhysicsTransformUpdateMode PhysicsTransformUpdateMode; // 0xa2d(0x01)
	char pad_A2E[0x1]; // 0xa2e(0x01)
	enum class EAnimationMode AnimationMode; // 0xa2f(0x01)
	char pad_A30[0x1]; // 0xa30(0x01)
	char bDisablePostProcessBlueprint : 1; // 0xa31(0x01)
	char pad_A31_1 : 1; // 0xa31(0x01)
	char bUpdateOverlapsOnAnimationFinalize : 1; // 0xa31(0x01)
	char pad_A31_3 : 1; // 0xa31(0x01)
	char bHasValidBodies : 1; // 0xa31(0x01)
	char bBlendPhysics : 1; // 0xa31(0x01)
	char bEnablePhysicsOnDedicatedServer : 1; // 0xa31(0x01)
	char bUpdateMeshWhenKinematic : 1; // 0xa31(0x01)
	char bUpdateJointsFromAnimation : 1; // 0xa32(0x01)
	char bAllowClothActors : 1; // 0xa32(0x01)
	char bDisableClothSimulation : 1; // 0xa32(0x01)
	char pad_A32_3 : 5; // 0xa32(0x01)
	char pad_A33[0x5]; // 0xa33(0x05)
	char bDisableRigidBodyAnimNode : 1; // 0xa38(0x01)
	char bAllowAnimCurveEvaluation : 1; // 0xa38(0x01)
	char bDisableAnimCurves : 1; // 0xa38(0x01)
	char pad_A38_3 : 3; // 0xa38(0x01)
	char bCollideWithEnvironment : 1; // 0xa38(0x01)
	char bCollideWithAttachedChildren : 1; // 0xa38(0x01)
	char bForceCollisionUpdate : 1; // 0xa39(0x01)
	char bLocalSpaceSimulation : 1; // 0xa39(0x01)
	char bResetAfterTeleport : 1; // 0xa39(0x01)
	char pad_A39_3 : 1; // 0xa39(0x01)
	char bDeferKinematicBoneUpdate : 1; // 0xa39(0x01)
	char bNoSkeletonUpdate : 1; // 0xa39(0x01)
	char bPauseAnims : 1; // 0xa39(0x01)
	char bUseRefPoseOnInitAnim : 1; // 0xa39(0x01)
	char bEnablePerPolyCollision : 1; // 0xa3a(0x01)
	char bForceRefpose : 1; // 0xa3a(0x01)
	char bOnlyAllowAutonomousTickPose : 1; // 0xa3a(0x01)
	char bIsAutonomousTickPose : 1; // 0xa3a(0x01)
	char bOldForceRefPose : 1; // 0xa3a(0x01)
	char bShowPrePhysBones : 1; // 0xa3a(0x01)
	char bRequiredBonesUpToDate : 1; // 0xa3a(0x01)
	char bAnimTreeInitialised : 1; // 0xa3a(0x01)
	char bIncludeComponentLocationIntoBounds : 1; // 0xa3b(0x01)
	char bEnableLineCheckWithBounds : 1; // 0xa3b(0x01)
	char bPropagateCurvesToFollowers : 1; // 0xa3b(0x01)
	char bSkipKinematicUpdateWhenInterpolating : 1; // 0xa3b(0x01)
	char bSkipBoundsUpdateWhenInterpolating : 1; // 0xa3b(0x01)
	char pad_A3B_5 : 2; // 0xa3b(0x01)
	char bNeedsQueuedAnimEventsDispatched : 1; // 0xa3b(0x01)
	char pad_A3C[0x2]; // 0xa3c(0x02)
	uint16_t CachedAnimCurveUidVersion; // 0xa3e(0x02)
	float ClothBlendWeight; // 0xa40(0x04)
	bool bWaitForParallelClothTask; // 0xa44(0x01)
	char pad_A45[0x3]; // 0xa45(0x03)
	struct TArray<struct FName> DisallowedAnimCurves; // 0xa48(0x10)
	struct UBodySetup* BodySetup; // 0xa58(0x08)
	char pad_A60[0x4]; // 0xa60(0x04)
	float ClothMaxDistanceScale; // 0xa64(0x04)
	struct FMulticastInlineDelegate OnConstraintBroken; // 0xa68(0x10)
	struct FMulticastInlineDelegate OnPlasticDeformation; // 0xa78(0x10)
	struct UClothingSimulationFactory* ClothingSimulationFactory; // 0xa88(0x08)
	char pad_A90[0xf8]; // 0xa90(0xf8)
	float TeleportDistanceThreshold; // 0xb88(0x04)
	float TeleportRotationThreshold; // 0xb8c(0x04)
	char pad_B90[0x8]; // 0xb90(0x08)
	uint32_t LastPoseTickFrame; // 0xb98(0x04)
	char pad_B9C[0x94]; // 0xb9c(0x94)
	struct UClothingSimulationInteractor* ClothingInteractor; // 0xc30(0x08)
	char pad_C38[0xc8]; // 0xc38(0xc8)
	struct FMulticastInlineDelegate OnAnimInitialized; // 0xd00(0x10)
	char pad_D10[0x270]; // 0xd10(0x270)

	void UnlinkAnimClassLayers(struct UAnimInstance* InClass); // Function Engine.SkeletalMeshComponent.UnlinkAnimClassLayers // (None) // @ game+0xffffc078df830041
};

// Class Engine.AnimInstance
// Size: 0x350 (Inherited: 0x28)
struct UAnimInstance : UObject {
	struct USkeleton* CurrentSkeleton; // 0x28(0x08)
	enum class ERootMotionMode RootMotionMode; // 0x30(0x01)
	char bUseMultiThreadedAnimationUpdate : 1; // 0x31(0x01)
	char bUsingCopyPoseFromMesh : 1; // 0x31(0x01)
	char pad_31_2 : 2; // 0x31(0x01)
	char bReceiveNotifiesFromLinkedInstances : 1; // 0x31(0x01)
	char bPropagateNotifiesToLinkedInstances : 1; // 0x31(0x01)
	char bUseMainInstanceMontageEvaluationData : 1; // 0x31(0x01)
	char bQueueMontageEvents : 1; // 0x31(0x01)
	char pad_32[0x6]; // 0x32(0x06)
	struct FMulticastInlineDelegate OnMontageBlendingOut; // 0x38(0x10)
	struct FMulticastInlineDelegate OnMontageStarted; // 0x48(0x10)
	struct FMulticastInlineDelegate OnMontageEnded; // 0x58(0x10)
	struct FMulticastInlineDelegate OnAllMontageInstancesEnded; // 0x68(0x10)
	char pad_78[0xd8]; // 0x78(0xd8)
	struct FAnimNotifyQueue NotifyQueue; // 0x150(0x70)
	struct TArray<struct FAnimNotifyEvent> ActiveAnimNotifyState; // 0x1c0(0x10)
	struct TArray<struct FAnimNotifyEventReference> ActiveAnimNotifyEventReference; // 0x1d0(0x10)
	char pad_1E0[0x170]; // 0x1e0(0x170)

	bool WasAnimNotifyTriggeredInStateMachine(int32_t MachineIndex, struct UAnimNotify* AnimNotifyType); // Function Engine.AnimInstance.WasAnimNotifyTriggeredInStateMachine // (None) // @ game+0xffffb51bdf830041
};

// Class Engine.BlueprintGeneratedClass
// Size: 0x380 (Inherited: 0x230)
struct UBlueprintGeneratedClass : UClass {
	char pad_230[0x8]; // 0x230(0x08)
	int32_t NumReplicatedProperties; // 0x238(0x04)
	char bHasNativizedParent : 1; // 0x23c(0x01)
	char bHasCookedComponentInstancingData : 1; // 0x23c(0x01)
	char pad_23C_2 : 6; // 0x23c(0x01)
	char pad_23D[0x3]; // 0x23d(0x03)
	struct TArray<struct UDynamicBlueprintBinding*> DynamicBindingObjects; // 0x240(0x10)
	struct TArray<struct UActorComponent*> ComponentTemplates; // 0x250(0x10)
	struct TArray<struct UTimelineTemplate*> Timelines; // 0x260(0x10)
	struct TArray<struct FBPComponentClassOverride> ComponentClassOverrides; // 0x270(0x10)
	struct USimpleConstructionScript* SimpleConstructionScript; // 0x280(0x08)
	struct UInheritableComponentHandler* InheritableComponentHandler; // 0x288(0x08)
	struct UStructProperty* UberGraphFramePointerProperty; // 0x290(0x08)
	char pad_298[0x8]; // 0x298(0x08)
	struct UFunction* UberGraphFunction; // 0x2a0(0x08)
	struct TMap<struct FName, struct FGuid> CookedPropertyGuids; // 0x2a8(0x50)
	struct TMap<struct FName, struct FBlueprintCookedComponentInstancingData> CookedComponentInstancingData; // 0x2f8(0x50)
	char pad_348[0x38]; // 0x348(0x38)
};

// Class Engine.CameraShakeBase
// Size: 0xf0 (Inherited: 0x28)
struct UCameraShakeBase : UObject {
	bool bSingleInstance; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	float ShakeScale; // 0x2c(0x04)
	struct UCameraShakePattern* RootShakePattern; // 0x30(0x08)
	struct APlayerCameraManager* CameraManager; // 0x38(0x08)
	char pad_40[0xb0]; // 0x40(0xb0)

	void SetRootShakePattern(struct UCameraShakePattern* InPattern); // Function Engine.CameraShakeBase.SetRootShakePattern // (None) // @ game+0xffffb6dbdf830041
};

// Class Engine.CameraShakePattern
// Size: 0x28 (Inherited: 0x28)
struct UCameraShakePattern : UObject {
};

// Class Engine.CameraModifier
// Size: 0x48 (Inherited: 0x28)
struct UCameraModifier : UObject {
	char bDebug : 1; // 0x28(0x01)
	char bExclusive : 1; // 0x28(0x01)
	char pad_28_2 : 6; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	char Priority; // 0x2c(0x01)
	char pad_2D[0x3]; // 0x2d(0x03)
	struct APlayerCameraManager* CameraOwner; // 0x30(0x08)
	float AlphaInTime; // 0x38(0x04)
	float AlphaOutTime; // 0x3c(0x04)
	float Alpha; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)

	void OnCameraOwnerDestroyed(struct AActor* InOwner); // Function Engine.CameraModifier.OnCameraOwnerDestroyed // (None) // @ game+0xffffb6e9df830041
};

// Class Engine.Commandlet
// Size: 0x80 (Inherited: 0x28)
struct UCommandlet : UObject {
	struct FString HelpDescription; // 0x28(0x10)
	struct FString HelpUsage; // 0x38(0x10)
	struct FString HelpWebLink; // 0x48(0x10)
	struct TArray<struct FString> HelpParamNames; // 0x58(0x10)
	struct TArray<struct FString> HelpParamDescriptions; // 0x68(0x10)
	char IsServer : 1; // 0x78(0x01)
	char IsClient : 1; // 0x78(0x01)
	char IsEditor : 1; // 0x78(0x01)
	char LogToConsole : 1; // 0x78(0x01)
	char ShowErrorCount : 1; // 0x78(0x01)
	char ShowProgress : 1; // 0x78(0x01)
	char pad_78_6 : 2; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
};

// Class Engine.AudioComponent
// Size: 0xc60 (Inherited: 0x2a0)
struct UAudioComponent : USceneComponent {
	char pad_2A0[0x198]; // 0x2a0(0x198)
	struct USoundBase* Sound; // 0x438(0x08)
	struct TArray<struct FAudioParameter> DefaultParameters; // 0x440(0x10)
	struct TArray<struct FAudioParameter> InstanceParameters; // 0x450(0x10)
	struct USoundClass* SoundClassOverride; // 0x460(0x08)
	char bAutoDestroy : 1; // 0x468(0x01)
	char bStopWhenOwnerDestroyed : 1; // 0x468(0x01)
	char bShouldRemainActiveIfDropped : 1; // 0x468(0x01)
	char bAllowSpatialization : 1; // 0x468(0x01)
	char bOverrideAttenuation : 1; // 0x468(0x01)
	char bOverrideSubtitlePriority : 1; // 0x468(0x01)
	char bIsUISound : 1; // 0x468(0x01)
	char bEnableLowPassFilter : 1; // 0x468(0x01)
	char bOverridePriority : 1; // 0x469(0x01)
	char bSuppressSubtitles : 1; // 0x469(0x01)
	char bCanPlayMultipleInstances : 1; // 0x469(0x01)
	char bDisableParameterUpdatesWhilePlaying : 1; // 0x469(0x01)
	char pad_469_4 : 4; // 0x469(0x01)
	char pad_46A_0 : 6; // 0x46a(0x01)
	char bAutoManageAttachment : 1; // 0x46a(0x01)
	char pad_46A_7 : 1; // 0x46a(0x01)
	char pad_46B[0x5]; // 0x46b(0x05)
	struct FName AudioComponentUserID; // 0x470(0x08)
	float PitchModulationMin; // 0x478(0x04)
	float PitchModulationMax; // 0x47c(0x04)
	float VolumeModulationMin; // 0x480(0x04)
	float VolumeModulationMax; // 0x484(0x04)
	float VolumeMultiplier; // 0x488(0x04)
	int32_t EnvelopeFollowerAttackTime; // 0x48c(0x04)
	int32_t EnvelopeFollowerReleaseTime; // 0x490(0x04)
	float Priority; // 0x494(0x04)
	float SubtitlePriority; // 0x498(0x04)
	char pad_49C[0x4]; // 0x49c(0x04)
	struct USoundEffectSourcePresetChain* SourceEffectChain; // 0x4a0(0x08)
	float PitchMultiplier; // 0x4a8(0x04)
	float LowPassFilterFrequency; // 0x4ac(0x04)
	char pad_4B0[0x8]; // 0x4b0(0x08)
	struct USoundAttenuation* AttenuationSettings; // 0x4b8(0x08)
	struct FSoundAttenuationSettings AttenuationOverrides; // 0x4c0(0x3c8)
	struct USoundConcurrency* ConcurrencySettings; // 0x888(0x08)
	struct TSet<struct USoundConcurrency*> ConcurrencySet; // 0x890(0x50)
	char pad_8E0[0xc]; // 0x8e0(0x0c)
	enum class EAttachmentRule AutoAttachLocationRule; // 0x8ec(0x01)
	enum class EAttachmentRule AutoAttachRotationRule; // 0x8ed(0x01)
	enum class EAttachmentRule AutoAttachScaleRule; // 0x8ee(0x01)
	char pad_8EF[0x1]; // 0x8ef(0x01)
	struct FSoundModulationDefaultRoutingSettings ModulationRouting; // 0x8f0(0x188)
	struct FMulticastInlineDelegate OnAudioPlayStateChanged; // 0xa78(0x10)
	char pad_A88[0x18]; // 0xa88(0x18)
	struct FMulticastInlineDelegate OnAudioVirtualizationChanged; // 0xaa0(0x10)
	char pad_AB0[0x18]; // 0xab0(0x18)
	struct FMulticastInlineDelegate OnAudioFinished; // 0xac8(0x10)
	char pad_AD8[0x18]; // 0xad8(0x18)
	struct FMulticastInlineDelegate OnAudioPlaybackPercent; // 0xaf0(0x10)
	char pad_B00[0x18]; // 0xb00(0x18)
	struct FMulticastInlineDelegate OnAudioSingleEnvelopeValue; // 0xb18(0x10)
	char pad_B28[0x18]; // 0xb28(0x18)
	struct FMulticastInlineDelegate OnAudioMultiEnvelopeValue; // 0xb40(0x10)
	char pad_B50[0x18]; // 0xb50(0x18)
	struct FDelegate OnQueueSubtitles; // 0xb68(0x10)
	char pad_B78[0x10]; // 0xb78(0x10)
	struct TWeakObjectPtr<struct USceneComponent> AutoAttachParent; // 0xb88(0x08)
	struct FName AutoAttachSocketName; // 0xb90(0x08)
	char pad_B98[0xc8]; // 0xb98(0xc8)

	void StopDelayed(float DelayTime); // Function Engine.AudioComponent.StopDelayed // (None) // @ game+0xffffb75adf830041
};

// Class Engine.AssetImportData
// Size: 0x28 (Inherited: 0x28)
struct UAssetImportData : UObject {
};

// Class Engine.AssetUserData
// Size: 0x28 (Inherited: 0x28)
struct UAssetUserData : UObject {
};

// Class Engine.Exporter
// Size: 0x78 (Inherited: 0x28)
struct UExporter : UObject {
	struct UObject* SupportedClass; // 0x28(0x08)
	struct UObject* ExportRootScope; // 0x30(0x08)
	struct TArray<struct FString> FormatExtension; // 0x38(0x10)
	struct TArray<struct FString> FormatDescription; // 0x48(0x10)
	int32_t PreferredFormatIndex; // 0x58(0x04)
	int32_t TextIndent; // 0x5c(0x04)
	char bText : 1; // 0x60(0x01)
	char bSelectedOnly : 1; // 0x60(0x01)
	char bForceFileOperations : 1; // 0x60(0x01)
	char pad_60_3 : 5; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
	struct UAssetExportTask* ExportTask; // 0x68(0x08)
	char pad_70[0x8]; // 0x70(0x08)

	bool ScriptRunAssetExportTask(struct UAssetExportTask* Task); // Function Engine.Exporter.ScriptRunAssetExportTask // (None) // @ game+0xffffb78cdf830041
};

// Class Engine.MovementComponent
// Size: 0x108 (Inherited: 0xa0)
struct UMovementComponent : UActorComponent {
	struct USceneComponent* UpdatedComponent; // 0xa0(0x08)
	struct UPrimitiveComponent* UpdatedPrimitive; // 0xa8(0x08)
	char pad_B0[0x8]; // 0xb0(0x08)
	struct FVector Velocity; // 0xb8(0x18)
	struct FVector PlaneConstraintNormal; // 0xd0(0x18)
	struct FVector PlaneConstraintOrigin; // 0xe8(0x18)
	char bUpdateOnlyIfRendered : 1; // 0x100(0x01)
	char bAutoUpdateTickRegistration : 1; // 0x100(0x01)
	char bTickBeforeOwner : 1; // 0x100(0x01)
	char bAutoRegisterUpdatedComponent : 1; // 0x100(0x01)
	char bConstrainToPlane : 1; // 0x100(0x01)
	char bSnapToPlaneAtStart : 1; // 0x100(0x01)
	char bAutoRegisterPhysicsVolumeUpdates : 1; // 0x100(0x01)
	char bComponentShouldUpdatePhysicsVolume : 1; // 0x100(0x01)
	char pad_101[0x2]; // 0x101(0x02)
	enum class EPlaneConstraintAxisSetting PlaneConstraintAxisSetting; // 0x103(0x01)
	char pad_104[0x4]; // 0x104(0x04)

	void StopMovementImmediately(); // Function Engine.MovementComponent.StopMovementImmediately // (None) // @ game+0xffff9152df830041
};

// Class Engine.NavMovementComponent
// Size: 0x150 (Inherited: 0x108)
struct UNavMovementComponent : UMovementComponent {
	struct FNavAgentProperties NavAgentProps; // 0x108(0x38)
	float FixedPathBrakingDistance; // 0x140(0x04)
	char bUpdateNavAgentWithOwnersCollision : 1; // 0x144(0x01)
	char bUseAccelerationForPaths : 1; // 0x144(0x01)
	char bUseFixedBrakingDistanceForPaths : 1; // 0x144(0x01)
	char pad_144_3 : 5; // 0x144(0x01)
	struct FMovementProperties MovementState; // 0x145(0x01)
	char pad_146[0x2]; // 0x146(0x02)
	struct UObject* PathFollowingComp; // 0x148(0x08)

	void StopMovementKeepPathing(); // Function Engine.NavMovementComponent.StopMovementKeepPathing // (None) // @ game+0xffffb821df830041
};

// Class Engine.PawnMovementComponent
// Size: 0x158 (Inherited: 0x150)
struct UPawnMovementComponent : UNavMovementComponent {
	struct APawn* PawnOwner; // 0x150(0x08)

	bool IsMoveInputIgnored(); // Function Engine.PawnMovementComponent.IsMoveInputIgnored // (None) // @ game+0xffffb827df830041
};

// Class Engine.CharacterMovementComponent
// Size: 0xf00 (Inherited: 0x158)
struct UCharacterMovementComponent : UPawnMovementComponent {
	char pad_158[0x10]; // 0x158(0x10)
	struct ACharacter* CharacterOwner; // 0x168(0x08)
	float GravityScale; // 0x170(0x04)
	float MaxStepHeight; // 0x174(0x04)
	float JumpZVelocity; // 0x178(0x04)
	float JumpOffJumpZFactor; // 0x17c(0x04)
	char pad_180[0x1c]; // 0x180(0x1c)
	float WalkableFloorAngle; // 0x19c(0x04)
	float WalkableFloorZ; // 0x1a0(0x04)
	enum class EMovementMode MovementMode; // 0x1a4(0x01)
	char CustomMovementMode; // 0x1a5(0x01)
	enum class ENetworkSmoothingMode NetworkSmoothingMode; // 0x1a6(0x01)
	char pad_1A7[0x1]; // 0x1a7(0x01)
	float GroundFriction; // 0x1a8(0x04)
	char pad_1AC[0x3c]; // 0x1ac(0x3c)
	float MaxWalkSpeed; // 0x1e8(0x04)
	float MaxWalkSpeedCrouched; // 0x1ec(0x04)
	float MaxSwimSpeed; // 0x1f0(0x04)
	float MaxFlySpeed; // 0x1f4(0x04)
	float MaxCustomMovementSpeed; // 0x1f8(0x04)
	float MaxAcceleration; // 0x1fc(0x04)
	float MinAnalogWalkSpeed; // 0x200(0x04)
	float BrakingFrictionFactor; // 0x204(0x04)
	float BrakingFriction; // 0x208(0x04)
	float BrakingSubStepTime; // 0x20c(0x04)
	float BrakingDecelerationWalking; // 0x210(0x04)
	float BrakingDecelerationFalling; // 0x214(0x04)
	float BrakingDecelerationSwimming; // 0x218(0x04)
	float BrakingDecelerationFlying; // 0x21c(0x04)
	float AirControl; // 0x220(0x04)
	float AirControlBoostMultiplier; // 0x224(0x04)
	float AirControlBoostVelocityThreshold; // 0x228(0x04)
	float FallingLateralFriction; // 0x22c(0x04)
	float CrouchedHalfHeight; // 0x230(0x04)
	float Buoyancy; // 0x234(0x04)
	float PerchRadiusThreshold; // 0x238(0x04)
	float PerchAdditionalHeight; // 0x23c(0x04)
	struct FRotator RotationRate; // 0x240(0x18)
	char bUseSeparateBrakingFriction : 1; // 0x258(0x01)
	char bApplyGravityWhileJumping : 1; // 0x258(0x01)
	char bUseControllerDesiredRotation : 1; // 0x258(0x01)
	char bOrientRotationToMovement : 1; // 0x258(0x01)
	char bSweepWhileNavWalking : 1; // 0x258(0x01)
	char pad_258_5 : 1; // 0x258(0x01)
	char bMovementInProgress : 1; // 0x258(0x01)
	char bEnableScopedMovementUpdates : 1; // 0x258(0x01)
	char bEnableServerDualMoveScopedMovementUpdates : 1; // 0x259(0x01)
	char bForceMaxAccel : 1; // 0x259(0x01)
	char bRunPhysicsWithNoController : 1; // 0x259(0x01)
	char bForceNextFloorCheck : 1; // 0x259(0x01)
	char bShrinkProxyCapsule : 1; // 0x259(0x01)
	char bCanWalkOffLedges : 1; // 0x259(0x01)
	char bCanWalkOffLedgesWhenCrouching : 1; // 0x259(0x01)
	char pad_259_7 : 1; // 0x259(0x01)
	char pad_25A_0 : 1; // 0x25a(0x01)
	char bNetworkSkipProxyPredictionOnNetUpdate : 1; // 0x25a(0x01)
	char bNetworkAlwaysReplicateTransformUpdateTimestamp : 1; // 0x25a(0x01)
	char bDeferUpdateMoveComponent : 1; // 0x25a(0x01)
	char bEnablePhysicsInteraction : 1; // 0x25a(0x01)
	char bTouchForceScaledToMass : 1; // 0x25a(0x01)
	char bPushForceScaledToMass : 1; // 0x25a(0x01)
	char bPushForceUsingZOffset : 1; // 0x25a(0x01)
	char bScalePushForceToVelocity : 1; // 0x25b(0x01)
	char pad_25B_1 : 7; // 0x25b(0x01)
	char pad_25C[0x4]; // 0x25c(0x04)
	struct USceneComponent* DeferredUpdatedMoveComponent; // 0x260(0x08)
	float MaxOutOfWaterStepHeight; // 0x268(0x04)
	float OutofWaterZ; // 0x26c(0x04)
	float Mass; // 0x270(0x04)
	float StandingDownwardForceScale; // 0x274(0x04)
	float InitialPushForceFactor; // 0x278(0x04)
	float PushForceFactor; // 0x27c(0x04)
	float PushForcePointZOffsetFactor; // 0x280(0x04)
	float TouchForceFactor; // 0x284(0x04)
	float MinTouchForce; // 0x288(0x04)
	float MaxTouchForce; // 0x28c(0x04)
	float RepulsionForce; // 0x290(0x04)
	char pad_294[0x4]; // 0x294(0x04)
	struct FVector Acceleration; // 0x298(0x18)
	struct FQuat LastUpdateRotation; // 0x2b0(0x20)
	struct FVector LastUpdateLocation; // 0x2d0(0x18)
	struct FVector LastUpdateVelocity; // 0x2e8(0x18)
	float ServerLastTransformUpdateTimeStamp; // 0x300(0x04)
	float ServerLastClientGoodMoveAckTime; // 0x304(0x04)
	float ServerLastClientAdjustmentTime; // 0x308(0x04)
	char pad_30C[0x4]; // 0x30c(0x04)
	struct FVector PendingImpulseToApply; // 0x310(0x18)
	struct FVector PendingForceToApply; // 0x328(0x18)
	float AnalogInputModifier; // 0x340(0x04)
	char pad_344[0xc]; // 0x344(0x0c)
	float MaxSimulationTimeStep; // 0x350(0x04)
	int32_t MaxSimulationIterations; // 0x354(0x04)
	int32_t MaxJumpApexAttemptsPerSimulation; // 0x358(0x04)
	float MaxDepenetrationWithGeometry; // 0x35c(0x04)
	float MaxDepenetrationWithGeometryAsProxy; // 0x360(0x04)
	float MaxDepenetrationWithPawn; // 0x364(0x04)
	float MaxDepenetrationWithPawnAsProxy; // 0x368(0x04)
	float NetworkSimulatedSmoothLocationTime; // 0x36c(0x04)
	float NetworkSimulatedSmoothRotationTime; // 0x370(0x04)
	float ListenServerNetworkSimulatedSmoothLocationTime; // 0x374(0x04)
	float ListenServerNetworkSimulatedSmoothRotationTime; // 0x378(0x04)
	float NetProxyShrinkRadius; // 0x37c(0x04)
	float NetProxyShrinkHalfHeight; // 0x380(0x04)
	float NetworkMaxSmoothUpdateDistance; // 0x384(0x04)
	float NetworkNoSmoothUpdateDistance; // 0x388(0x04)
	float NetworkMinTimeBetweenClientAckGoodMoves; // 0x38c(0x04)
	float NetworkMinTimeBetweenClientAdjustments; // 0x390(0x04)
	float NetworkMinTimeBetweenClientAdjustmentsLargeCorrection; // 0x394(0x04)
	float NetworkLargeClientCorrectionDistance; // 0x398(0x04)
	float LedgeCheckThreshold; // 0x39c(0x04)
	float JumpOutOfWaterPitch; // 0x3a0(0x04)
	char pad_3A4[0x4]; // 0x3a4(0x04)
	struct FFindFloorResult CurrentFloor; // 0x3a8(0xf8)
	enum class EMovementMode DefaultLandMovementMode; // 0x4a0(0x01)
	enum class EMovementMode DefaultWaterMovementMode; // 0x4a1(0x01)
	enum class EMovementMode GroundMovementMode; // 0x4a2(0x01)
	char pad_4A3[0x9]; // 0x4a3(0x09)
	char bMaintainHorizontalGroundVelocity : 1; // 0x4ac(0x01)
	char bImpartBaseVelocityX : 1; // 0x4ac(0x01)
	char bImpartBaseVelocityY : 1; // 0x4ac(0x01)
	char bImpartBaseVelocityZ : 1; // 0x4ac(0x01)
	char bImpartBaseAngularVelocity : 1; // 0x4ac(0x01)
	char bJustTeleported : 1; // 0x4ac(0x01)
	char bNetworkUpdateReceived : 1; // 0x4ac(0x01)
	char bNetworkMovementModeChanged : 1; // 0x4ac(0x01)
	char bIgnoreClientMovementErrorChecksAndCorrection : 1; // 0x4ad(0x01)
	char bServerAcceptClientAuthoritativePosition : 1; // 0x4ad(0x01)
	char bNotifyApex : 1; // 0x4ad(0x01)
	char bCheatFlying : 1; // 0x4ad(0x01)
	char bWantsToCrouch : 1; // 0x4ad(0x01)
	char bCrouchMaintainsBaseLocation : 1; // 0x4ad(0x01)
	char bIgnoreBaseRotation : 1; // 0x4ad(0x01)
	char bFastAttachedMove : 1; // 0x4ad(0x01)
	char bAlwaysCheckFloor : 1; // 0x4ae(0x01)
	char bUseFlatBaseForFloorChecks : 1; // 0x4ae(0x01)
	char bPerformingJumpOff : 1; // 0x4ae(0x01)
	char bWantsToLeaveNavWalking : 1; // 0x4ae(0x01)
	char bUseRVOAvoidance : 1; // 0x4ae(0x01)
	char bRequestedMoveUseAcceleration : 1; // 0x4ae(0x01)
	char pad_4AE_6 : 1; // 0x4ae(0x01)
	char bWasSimulatingRootMotion : 1; // 0x4ae(0x01)
	char bAllowPhysicsRotationDuringAnimRootMotion : 1; // 0x4af(0x01)
	char pad_4AF_1 : 7; // 0x4af(0x01)
	float FormerBaseVelocityDecayHalfLife; // 0x4b0(0x04)
	char bHasRequestedVelocity : 1; // 0x4b4(0x01)
	char bRequestedMoveWithMaxSpeed : 1; // 0x4b4(0x01)
	char bWasAvoidanceUpdated : 1; // 0x4b4(0x01)
	char pad_4B4_3 : 2; // 0x4b4(0x01)
	char bProjectNavMeshWalking : 1; // 0x4b4(0x01)
	char bProjectNavMeshOnBothWorldChannels : 1; // 0x4b4(0x01)
	char pad_4B4_7 : 1; // 0x4b4(0x01)
	char pad_4B5[0x1f]; // 0x4b5(0x1f)
	float AvoidanceConsiderationRadius; // 0x4d4(0x04)
	struct FVector RequestedVelocity; // 0x4d8(0x18)
	struct FVector LastUpdateRequestedVelocity; // 0x4f0(0x18)
	int32_t AvoidanceUID; // 0x508(0x04)
	struct FNavAvoidanceMask AvoidanceGroup; // 0x50c(0x04)
	struct FNavAvoidanceMask GroupsToAvoid; // 0x510(0x04)
	struct FNavAvoidanceMask GroupsToIgnore; // 0x514(0x04)
	float AvoidanceWeight; // 0x518(0x04)
	char pad_51C[0x4]; // 0x51c(0x04)
	struct FVector PendingLaunchVelocity; // 0x520(0x18)
	char pad_538[0x138]; // 0x538(0x138)
	float NavMeshProjectionInterval; // 0x670(0x04)
	float NavMeshProjectionTimer; // 0x674(0x04)
	float NavMeshProjectionInterpSpeed; // 0x678(0x04)
	float NavMeshProjectionHeightScaleUp; // 0x67c(0x04)
	float NavMeshProjectionHeightScaleDown; // 0x680(0x04)
	float NavWalkingFloorDistTolerance; // 0x684(0x04)
	char pad_688[0x30]; // 0x688(0x30)
	struct FCharacterMovementComponentPostPhysicsTickFunction PostPhysicsTickFunction; // 0x6b8(0x30)
	char pad_6E8[0x18]; // 0x6e8(0x18)
	float MinTimeBetweenTimeStampResets; // 0x700(0x04)
	char pad_704[0x554]; // 0x704(0x554)
	struct FRootMotionSourceGroup CurrentRootMotion; // 0xc58(0x48)
	struct FRootMotionSourceGroup ServerCorrectionRootMotion; // 0xca0(0x48)
	char pad_CE8[0x168]; // 0xce8(0x168)
	struct FRootMotionMovementParams RootMotionParams; // 0xe50(0x70)
	struct FVector AnimRootMotionVelocity; // 0xec0(0x18)
	char pad_ED8[0x28]; // 0xed8(0x28)

	void SetWalkableFloorZ(float InWalkableFloorZ); // Function Engine.CharacterMovementComponent.SetWalkableFloorZ // (None) // @ game+0xffffb84fdf830041
};

// Class Engine.EdGraph
// Size: 0x60 (Inherited: 0x28)
struct UEdGraph : UObject {
	struct UEdGraphSchema* Schema; // 0x28(0x08)
	struct TArray<struct UEdGraphNode*> Nodes; // 0x30(0x10)
	char bEditable : 1; // 0x40(0x01)
	char bAllowDeletion : 1; // 0x40(0x01)
	char bAllowRenaming : 1; // 0x40(0x01)
	char pad_40_3 : 5; // 0x40(0x01)
	char pad_41[0x1f]; // 0x41(0x1f)
};

// Class Engine.SoundBase
// Size: 0x168 (Inherited: 0x28)
struct USoundBase : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct USoundClass* SoundClassObject; // 0x30(0x08)
	char bDebug : 1; // 0x38(0x01)
	char bOverrideConcurrency : 1; // 0x38(0x01)
	char bEnableBusSends : 1; // 0x38(0x01)
	char bEnableBaseSubmix : 1; // 0x38(0x01)
	char bEnableSubmixSends : 1; // 0x38(0x01)
	char bHasDelayNode : 1; // 0x38(0x01)
	char bHasConcatenatorNode : 1; // 0x38(0x01)
	char bBypassVolumeScaleForPriority : 1; // 0x38(0x01)
	enum class EVirtualizationMode VirtualizationMode; // 0x39(0x01)
	char pad_3A[0x56]; // 0x3a(0x56)
	struct TSet<struct USoundConcurrency*> ConcurrencySet; // 0x90(0x50)
	struct FSoundConcurrencySettings ConcurrencyOverrides; // 0xe0(0x20)
	float Duration; // 0x100(0x04)
	float MaxDistance; // 0x104(0x04)
	float TotalSamples; // 0x108(0x04)
	float Priority; // 0x10c(0x04)
	struct USoundAttenuation* AttenuationSettings; // 0x110(0x08)
	struct USoundSubmixBase* SoundSubmixObject; // 0x118(0x08)
	struct TArray<struct FSoundSubmixSendInfo> SoundSubmixSends; // 0x120(0x10)
	struct USoundEffectSourcePresetChain* SourceEffectChain; // 0x130(0x08)
	struct TArray<struct FSoundSourceBusSendInfo> BusSends; // 0x138(0x10)
	struct TArray<struct FSoundSourceBusSendInfo> PreEffectBusSends; // 0x148(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x158(0x10)
};

// Class Engine.SoundWave
// Size: 0x450 (Inherited: 0x168)
struct USoundWave : USoundBase {
	char pad_168[0x10]; // 0x168(0x10)
	int32_t CompressionQuality; // 0x178(0x04)
	int32_t StreamingPriority; // 0x17c(0x04)
	enum class ESoundwaveSampleRateSettings SampleRateQuality; // 0x180(0x01)
	char pad_181[0x1]; // 0x181(0x01)
	enum class ESoundGroup SoundGroup; // 0x182(0x01)
	char bLooping : 1; // 0x183(0x01)
	char bStreaming : 1; // 0x183(0x01)
	char pad_183_2 : 6; // 0x183(0x01)
	enum class ESoundAssetCompressionType SoundAssetCompressionType; // 0x184(0x01)
	char bSeekableStreaming : 1; // 0x185(0x01)
	char bUseBinkAudio : 1; // 0x185(0x01)
	char pad_185_2 : 6; // 0x185(0x01)
	char pad_186[0x1a]; // 0x186(0x1a)
	struct FSoundModulationDefaultRoutingSettings ModulationSettings; // 0x1a0(0x188)
	struct TArray<float> FrequenciesToAnalyze; // 0x328(0x10)
	struct TArray<struct FSoundWaveSpectralTimeData> CookedSpectralTimeData; // 0x338(0x10)
	struct TArray<struct FSoundWaveEnvelopeTimeData> CookedEnvelopeTimeData; // 0x348(0x10)
	int32_t InitialChunkSize; // 0x358(0x04)
	char pad_35C[0x40]; // 0x35c(0x40)
	char pad_39C_0 : 5; // 0x39c(0x01)
	char bMature : 1; // 0x39c(0x01)
	char bManualWordWrap : 1; // 0x39c(0x01)
	char bSingleLine : 1; // 0x39c(0x01)
	char bIsAmbisonics : 1; // 0x39d(0x01)
	char pad_39D_1 : 7; // 0x39d(0x01)
	enum class ESoundWaveLoadingBehavior LoadingBehavior; // 0x39e(0x01)
	char pad_39F[0x1]; // 0x39f(0x01)
	struct FString SpokenText; // 0x3a0(0x10)
	float SubtitlePriority; // 0x3b0(0x04)
	float Volume; // 0x3b4(0x04)
	float Pitch; // 0x3b8(0x04)
	int32_t NumChannels; // 0x3bc(0x04)
	struct TArray<struct FSoundWaveCuePoint> CuePoints; // 0x3c0(0x10)
	int32_t SampleRate; // 0x3d0(0x04)
	char pad_3D4[0xc]; // 0x3d4(0x0c)
	struct TArray<struct FSubtitleCue> Subtitles; // 0x3e0(0x10)
	struct UCurveTable* Curves; // 0x3f0(0x08)
	struct UCurveTable* InternalCurves; // 0x3f8(0x08)
	char pad_400[0x50]; // 0x400(0x50)

	void SetSoundAssetCompressionType(enum class ESoundAssetCompressionType InSoundAssetCompressionType, bool bMarkDirty); // Function Engine.SoundWave.SetSoundAssetCompressionType // (None) // @ game+0xffffb87fdf830041
};

// Class Engine.SoundWaveProcedural
// Size: 0x4a0 (Inherited: 0x450)
struct USoundWaveProcedural : USoundWave {
	int32_t CompressionQuality; // 0x178(0x04)
	int32_t StreamingPriority; // 0x17c(0x04)
	enum class ESoundwaveSampleRateSettings SampleRateQuality; // 0x180(0x01)
	enum class ESoundGroup SoundGroup; // 0x182(0x01)
	char bLooping : 1; // 0x183(0x01)
	char bStreaming : 1; // 0x183(0x01)
	enum class ESoundAssetCompressionType SoundAssetCompressionType; // 0x184(0x01)
	char bSeekableStreaming : 1; // 0x185(0x01)
	char bUseBinkAudio : 1; // 0x185(0x01)
	struct FSoundModulationDefaultRoutingSettings ModulationSettings; // 0x1a0(0x188)
	struct TArray<float> FrequenciesToAnalyze; // 0x328(0x10)
	struct TArray<struct FSoundWaveSpectralTimeData> CookedSpectralTimeData; // 0x338(0x10)
	struct TArray<struct FSoundWaveEnvelopeTimeData> CookedEnvelopeTimeData; // 0x348(0x10)
	int32_t InitialChunkSize; // 0x358(0x04)
	char pad_617_4 : 1; // 0x617(0x01)
	char bMature : 1; // 0x39c(0x01)
	char bManualWordWrap : 1; // 0x39c(0x01)
	char bSingleLine : 1; // 0x39c(0x01)
	char bIsAmbisonics : 1; // 0x39d(0x01)
	enum class ESoundWaveLoadingBehavior LoadingBehavior; // 0x39e(0x01)
	struct FString SpokenText; // 0x3a0(0x10)
	float SubtitlePriority; // 0x3b0(0x04)
	float Volume; // 0x3b4(0x04)
	float Pitch; // 0x3b8(0x04)
	int32_t NumChannels; // 0x3bc(0x04)
	struct TArray<struct FSoundWaveCuePoint> CuePoints; // 0x3c0(0x10)
	int32_t SampleRate; // 0x3d0(0x04)
	struct TArray<struct FSubtitleCue> Subtitles; // 0x3e0(0x10)
	struct UCurveTable* Curves; // 0x3f0(0x08)
	struct UCurveTable* InternalCurves; // 0x3f8(0x08)
};

// Class Engine.SoundEffectPreset
// Size: 0x68 (Inherited: 0x28)
struct USoundEffectPreset : UObject {
	char pad_28[0x40]; // 0x28(0x40)
};

// Class Engine.SoundEffectSubmixPreset
// Size: 0x68 (Inherited: 0x68)
struct USoundEffectSubmixPreset : USoundEffectPreset {
};

// Class Engine.SoundEffectSourcePreset
// Size: 0x68 (Inherited: 0x68)
struct USoundEffectSourcePreset : USoundEffectPreset {
};

// Class Engine.Controller
// Size: 0x328 (Inherited: 0x290)
struct AController : AActor {
	char pad_290[0x8]; // 0x290(0x08)
	struct APlayerState* PlayerState; // 0x298(0x08)
	char pad_2A0[0x8]; // 0x2a0(0x08)
	struct FMulticastInlineDelegate OnInstigatedAnyDamage; // 0x2a8(0x10)
	struct FMulticastInlineDelegate OnPossessedPawnChanged; // 0x2b8(0x10)
	struct FName StateName; // 0x2c8(0x08)
	struct APawn* Pawn; // 0x2d0(0x08)
	char pad_2D8[0x8]; // 0x2d8(0x08)
	struct ACharacter* Character; // 0x2e0(0x08)
	struct USceneComponent* TransformComponent; // 0x2e8(0x08)
	char pad_2F0[0x18]; // 0x2f0(0x18)
	struct FRotator ControlRotation; // 0x308(0x18)
	char bAttachToPawn : 1; // 0x320(0x01)
	char pad_320_1 : 7; // 0x320(0x01)
	char pad_321[0x7]; // 0x321(0x07)

	void UnPossess(); // Function Engine.Controller.UnPossess // (None) // @ game+0xffffbb94df830041
};

// Class Engine.Info
// Size: 0x290 (Inherited: 0x290)
struct AInfo : AActor {
	struct FActorTickFunction PrimaryActorTick; // 0x28(0x30)
	char bNetTemporary : 1; // 0x58(0x01)
	char pad_2C0_1 : 1; // 0x2c0(0x01)
	char bOnlyRelevantToOwner : 1; // 0x58(0x01)
	char bAlwaysRelevant : 1; // 0x58(0x01)
	char bReplicateMovement : 1; // 0x58(0x01)
	char bCallPreReplication : 1; // 0x58(0x01)
	char bCallPreReplicationForReplay : 1; // 0x58(0x01)
	char bHidden : 1; // 0x58(0x01)
	char bTearOff : 1; // 0x59(0x01)
	char bForceNetAddressable : 1; // 0x59(0x01)
	char bExchangedRoles : 1; // 0x59(0x01)
	char bNetLoadOnClient : 1; // 0x59(0x01)
	char bNetUseOwnerRelevancy : 1; // 0x59(0x01)
	char bRelevantForNetworkReplays : 1; // 0x59(0x01)
	char bRelevantForLevelBounds : 1; // 0x59(0x01)
	char bReplayRewindable : 1; // 0x59(0x01)
	char bAllowTickBeforeBeginPlay : 1; // 0x5a(0x01)
	char bAutoDestroyWhenFinished : 1; // 0x5a(0x01)
	char bCanBeDamaged : 1; // 0x5a(0x01)
	char bBlockInput : 1; // 0x5a(0x01)
	char bCollideWhenPlacing : 1; // 0x5a(0x01)
	char bFindCameraComponentWhenViewTarget : 1; // 0x5a(0x01)
	char bGenerateOverlapEventsDuringLevelStreaming : 1; // 0x5a(0x01)
	char bIgnoresOriginShifting : 1; // 0x5a(0x01)
	char bEnableAutoLODGeneration : 1; // 0x5b(0x01)
	char bIsEditorOnlyActor : 1; // 0x5b(0x01)
	char bActorSeamlessTraveled : 1; // 0x5b(0x01)
	char bReplicates : 1; // 0x5b(0x01)
	char bCanBeInCluster : 1; // 0x5b(0x01)
	char bAllowReceiveTickEventOnDedicatedServer : 1; // 0x5b(0x01)
	char pad_2C3_6 : 1; // 0x2c3(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x5b(0x01)
	char pad_2C4_0 : 7; // 0x2c4(0x01)
	char bActorEnableCollision : 1; // 0x5c(0x01)
	char bActorIsBeingDestroyed : 1; // 0x5d(0x01)
	char pad_2C5_1 : 4; // 0x2c5(0x01)
	char bAsyncPhysicsTickEnabled : 1; // 0x5d(0x01)
	enum class EActorUpdateOverlapsMethod UpdateOverlapsMethodDuringLevelStreaming; // 0x5e(0x01)
	enum class EActorUpdateOverlapsMethod DefaultUpdateOverlapsMethodDuringLevelStreaming; // 0x5f(0x01)
	float InitialLifeSpan; // 0x60(0x04)
	float CustomTimeDilation; // 0x64(0x04)
	enum class ENetRole RemoteRole; // 0x68(0x01)
	int32_t RayTracingGroupId; // 0x6c(0x04)
	struct FRepAttachment AttachmentReplication; // 0x70(0x60)
	struct FRepMovement ReplicatedMovement; // 0xd0(0x70)
	struct AActor* Owner; // 0x140(0x08)
	struct FName NetDriverName; // 0x148(0x08)
	enum class ENetRole Role; // 0x150(0x01)
	enum class ENetDormancy NetDormancy; // 0x151(0x01)
	enum class ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingMethod; // 0x152(0x01)
	enum class EAutoReceiveInput AutoReceiveInput; // 0x153(0x01)
	int32_t InputPriority; // 0x154(0x04)
	struct UInputComponent* InputComponent; // 0x160(0x08)
	float NetCullDistanceSquared; // 0x168(0x04)
	int32_t NetTag; // 0x16c(0x04)
	float NetUpdateFrequency; // 0x170(0x04)
	float MinNetUpdateFrequency; // 0x174(0x04)
	float NetPriority; // 0x178(0x04)
	struct APawn* Instigator; // 0x180(0x08)
	struct TArray<struct AActor*> Children; // 0x188(0x10)
	struct USceneComponent* RootComponent; // 0x198(0x08)
	struct TArray<struct FName> Layers; // 0x1a8(0x10)
	struct TWeakObjectPtr<struct UChildActorComponent> ParentComponent; // 0x1b8(0x08)
	struct TArray<struct FName> Tags; // 0x1c0(0x10)
	struct FMulticastSparseDelegate OnTakeAnyDamage; // 0x1d0(0x01)
	struct FMulticastSparseDelegate OnTakePointDamage; // 0x1d1(0x01)
	struct FMulticastSparseDelegate OnTakeRadialDamage; // 0x1d2(0x01)
	struct FMulticastSparseDelegate OnActorBeginOverlap; // 0x1d3(0x01)
	struct FMulticastSparseDelegate OnActorEndOverlap; // 0x1d4(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x1d5(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x1d6(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x1d7(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x1d8(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x1d9(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x1da(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x1db(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x1dc(0x01)
	struct FMulticastSparseDelegate OnActorHit; // 0x1dd(0x01)
	struct FMulticastSparseDelegate OnDestroyed; // 0x1de(0x01)
	struct FMulticastSparseDelegate OnEndPlay; // 0x1df(0x01)
	struct TArray<struct UActorComponent*> InstanceComponents; // 0x260(0x10)
	struct TArray<struct UActorComponent*> BlueprintCreatedComponents; // 0x270(0x10)
};

// Class Engine.GameModeBase
// Size: 0x330 (Inherited: 0x290)
struct AGameModeBase : AInfo {
	struct FString OptionsString; // 0x290(0x10)
	struct AGameSession* GameSessionClass; // 0x2a0(0x08)
	struct AGameStateBase* GameStateClass; // 0x2a8(0x08)
	struct APlayerController* PlayerControllerClass; // 0x2b0(0x08)
	struct APlayerState* PlayerStateClass; // 0x2b8(0x08)
	struct AHUD* HUDClass; // 0x2c0(0x08)
	struct APawn* DefaultPawnClass; // 0x2c8(0x08)
	struct ASpectatorPawn* SpectatorClass; // 0x2d0(0x08)
	struct APlayerController* ReplaySpectatorPlayerControllerClass; // 0x2d8(0x08)
	struct AServerStatReplicator* ServerStatReplicatorClass; // 0x2e0(0x08)
	struct AGameSession* GameSession; // 0x2e8(0x08)
	struct AGameStateBase* GameState; // 0x2f0(0x08)
	struct AServerStatReplicator* ServerStatReplicator; // 0x2f8(0x08)
	struct FText DefaultPlayerName; // 0x300(0x18)
	char bUseSeamlessTravel : 1; // 0x318(0x01)
	char bStartPlayersAsSpectators : 1; // 0x318(0x01)
	char bPauseable : 1; // 0x318(0x01)
	char pad_318_3 : 5; // 0x318(0x01)
	char pad_319[0x17]; // 0x319(0x17)

	void StartPlay(); // Function Engine.GameModeBase.StartPlay // (None) // @ game+0xffffbbe3df830041
};

// Class Engine.AssetManager
// Size: 0x4e8 (Inherited: 0x28)
struct UAssetManager : UObject {
	char pad_28[0x308]; // 0x28(0x308)
	struct TArray<struct UObject*> ObjectReferenceList; // 0x330(0x10)
	bool bIsGlobalAsyncScanEnvironment; // 0x340(0x01)
	bool bShouldGuessTypeAndName; // 0x341(0x01)
	bool bShouldUseSynchronousLoad; // 0x342(0x01)
	bool bIsLoadingFromPakFiles; // 0x343(0x01)
	bool bShouldAcquireMissingChunksOnLoad; // 0x344(0x01)
	bool bOnlyCookProductionAssets; // 0x345(0x01)
	char pad_346[0x2]; // 0x346(0x02)
	int32_t NumBulkScanRequests; // 0x348(0x04)
	bool bIsPrimaryAssetDirectoryCurrent; // 0x34c(0x01)
	bool bIsManagementDatabaseCurrent; // 0x34d(0x01)
	bool bUpdateManagementDatabaseAfterScan; // 0x34e(0x01)
	bool bIncludeOnlyOnDiskAssets; // 0x34f(0x01)
	bool bHasCompletedInitialScan; // 0x350(0x01)
	char pad_351[0x3]; // 0x351(0x03)
	int32_t NumberOfSpawnedNotifications; // 0x354(0x04)
	char pad_358[0x190]; // 0x358(0x190)
};

// Class Engine.GameStateBase
// Size: 0x2e0 (Inherited: 0x290)
struct AGameStateBase : AInfo {
	struct AGameModeBase* GameModeClass; // 0x290(0x08)
	struct AGameModeBase* AuthorityGameMode; // 0x298(0x08)
	struct ASpectatorPawn* SpectatorClass; // 0x2a0(0x08)
	struct TArray<struct APlayerState*> PlayerArray; // 0x2a8(0x10)
	bool bReplicatedHasBegunPlay; // 0x2b8(0x01)
	char pad_2B9[0x3]; // 0x2b9(0x03)
	float ReplicatedWorldTimeSeconds; // 0x2bc(0x04)
	float ServerWorldTimeSecondsDelta; // 0x2c0(0x04)
	float ServerWorldTimeSecondsUpdateFrequency; // 0x2c4(0x04)
	char pad_2C8[0x18]; // 0x2c8(0x18)

	void OnRep_SpectatorClass(); // Function Engine.GameStateBase.OnRep_SpectatorClass // (None) // @ game+0xffffbd52df830041
};

// Class Engine.GameSession
// Size: 0x2a8 (Inherited: 0x290)
struct AGameSession : AInfo {
	int32_t MaxSpectators; // 0x290(0x04)
	int32_t MaxPlayers; // 0x294(0x04)
	int32_t MaxPartySize; // 0x298(0x04)
	char MaxSplitscreensPerConnection; // 0x29c(0x01)
	bool bRequiresPushToTalk; // 0x29d(0x01)
	char pad_29E[0x2]; // 0x29e(0x02)
	struct FName SessionName; // 0x2a0(0x08)
};

// Class Engine.GameUserSettings
// Size: 0x148 (Inherited: 0x28)
struct UGameUserSettings : UObject {
	bool bUseVSync; // 0x28(0x01)
	bool bUseDynamicResolution; // 0x29(0x01)
	char pad_2A[0x5e]; // 0x2a(0x5e)
	uint32_t ResolutionSizeX; // 0x88(0x04)
	uint32_t ResolutionSizeY; // 0x8c(0x04)
	uint32_t LastUserConfirmedResolutionSizeX; // 0x90(0x04)
	uint32_t LastUserConfirmedResolutionSizeY; // 0x94(0x04)
	int32_t WindowPosX; // 0x98(0x04)
	int32_t WindowPosY; // 0x9c(0x04)
	int32_t FullscreenMode; // 0xa0(0x04)
	int32_t LastConfirmedFullscreenMode; // 0xa4(0x04)
	int32_t PreferredFullscreenMode; // 0xa8(0x04)
	uint32_t Version; // 0xac(0x04)
	int32_t AudioQualityLevel; // 0xb0(0x04)
	int32_t LastConfirmedAudioQualityLevel; // 0xb4(0x04)
	float FrameRateLimit; // 0xb8(0x04)
	char pad_BC[0x4]; // 0xbc(0x04)
	int32_t DesiredScreenWidth; // 0xc0(0x04)
	bool bUseDesiredScreenHeight; // 0xc4(0x01)
	char pad_C5[0x3]; // 0xc5(0x03)
	int32_t DesiredScreenHeight; // 0xc8(0x04)
	int32_t LastUserConfirmedDesiredScreenWidth; // 0xcc(0x04)
	int32_t LastUserConfirmedDesiredScreenHeight; // 0xd0(0x04)
	float LastRecommendedScreenWidth; // 0xd4(0x04)
	float LastRecommendedScreenHeight; // 0xd8(0x04)
	float LastCPUBenchmarkResult; // 0xdc(0x04)
	float LastGPUBenchmarkResult; // 0xe0(0x04)
	char pad_E4[0x4]; // 0xe4(0x04)
	struct TArray<float> LastCPUBenchmarkSteps; // 0xe8(0x10)
	struct TArray<float> LastGPUBenchmarkSteps; // 0xf8(0x10)
	float LastGPUBenchmarkMultiplier; // 0x108(0x04)
	bool bUseHDRDisplayOutput; // 0x10c(0x01)
	char pad_10D[0x3]; // 0x10d(0x03)
	int32_t HDRDisplayOutputNits; // 0x110(0x04)
	char pad_114[0x24]; // 0x114(0x24)
	struct FMulticastInlineDelegate OnGameUserSettingsUINeedsUpdate; // 0x138(0x10)

	void ValidateSettings(); // Function Engine.GameUserSettings.ValidateSettings // (None) // @ game+0xffffbe04df830041
};

// Class Engine.PlayerController
// Size: 0x850 (Inherited: 0x328)
struct APlayerController : AController {
	char pad_328[0x8]; // 0x328(0x08)
	struct UPlayer* Player; // 0x330(0x08)
	struct APawn* AcknowledgedPawn; // 0x338(0x08)
	struct AHUD* MyHUD; // 0x340(0x08)
	struct APlayerCameraManager* PlayerCameraManager; // 0x348(0x08)
	struct APlayerCameraManager* PlayerCameraManagerClass; // 0x350(0x08)
	bool bAutoManageActiveCameraTarget; // 0x358(0x01)
	char pad_359[0x7]; // 0x359(0x07)
	struct FRotator TargetViewRotation; // 0x360(0x18)
	char pad_378[0x18]; // 0x378(0x18)
	float SmoothTargetViewRotationSpeed; // 0x390(0x04)
	char pad_394[0x4]; // 0x394(0x04)
	struct TArray<struct AActor*> HiddenActors; // 0x398(0x10)
	struct TArray<struct TWeakObjectPtr<struct UPrimitiveComponent>> HiddenPrimitiveComponents; // 0x3a8(0x10)
	char pad_3B8[0x4]; // 0x3b8(0x04)
	float LastSpectatorStateSynchTime; // 0x3bc(0x04)
	struct FVector LastSpectatorSyncLocation; // 0x3c0(0x18)
	struct FRotator LastSpectatorSyncRotation; // 0x3d8(0x18)
	int32_t ClientCap; // 0x3f0(0x04)
	char pad_3F4[0x4]; // 0x3f4(0x04)
	struct UCheatManager* CheatManager; // 0x3f8(0x08)
	struct UCheatManager* CheatClass; // 0x400(0x08)
	struct UPlayerInput* PlayerInput; // 0x408(0x08)
	struct TArray<struct FActiveForceFeedbackEffect> ActiveForceFeedbackEffects; // 0x410(0x10)
	struct UAsyncPhysicsData* AsyncPhysicsDataClass; // 0x420(0x08)
	struct UAsyncPhysicsInputComponent* AsyncPhysicsDataComponent; // 0x428(0x08)
	char pad_430[0x80]; // 0x430(0x80)
	char pad_4B0_0 : 4; // 0x4b0(0x01)
	char bPlayerIsWaiting : 1; // 0x4b0(0x01)
	char pad_4B0_5 : 3; // 0x4b0(0x01)
	char pad_4B1[0x3]; // 0x4b1(0x03)
	char NetPlayerIndex; // 0x4b4(0x01)
	char pad_4B5[0x5b]; // 0x4b5(0x5b)
	struct UNetConnection* PendingSwapConnection; // 0x510(0x08)
	struct UNetConnection* NetConnection; // 0x518(0x08)
	char pad_520[0x18]; // 0x520(0x18)
	float InputYawScale; // 0x538(0x04)
	float InputPitchScale; // 0x53c(0x04)
	float InputRollScale; // 0x540(0x04)
	char bShowMouseCursor : 1; // 0x544(0x01)
	char bEnableClickEvents : 1; // 0x544(0x01)
	char bEnableTouchEvents : 1; // 0x544(0x01)
	char bEnableMouseOverEvents : 1; // 0x544(0x01)
	char bEnableTouchOverEvents : 1; // 0x544(0x01)
	char bForceFeedbackEnabled : 1; // 0x544(0x01)
	char bEnableMotionControls : 1; // 0x544(0x01)
	char bEnableStreamingSource : 1; // 0x544(0x01)
	char bStreamingSourceShouldActivate : 1; // 0x545(0x01)
	char bStreamingSourceShouldBlockOnSlowStreaming : 1; // 0x545(0x01)
	char pad_545_2 : 6; // 0x545(0x01)
	char pad_546[0x2]; // 0x546(0x02)
	enum class EStreamingSourcePriority StreamingSourcePriority; // 0x548(0x01)
	char pad_549[0x3]; // 0x549(0x03)
	struct FColor StreamingSourceDebugColor; // 0x54c(0x04)
	struct TArray<struct FStreamingSourceShape> StreamingSourceShapes; // 0x550(0x10)
	float ForceFeedbackScale; // 0x560(0x04)
	char pad_564[0x4]; // 0x564(0x04)
	struct TArray<struct FKey> ClickEventKeys; // 0x568(0x10)
	enum class EMouseCursor DefaultMouseCursor; // 0x578(0x01)
	enum class EMouseCursor CurrentMouseCursor; // 0x579(0x01)
	enum class ECollisionChannel DefaultClickTraceChannel; // 0x57a(0x01)
	enum class ECollisionChannel CurrentClickTraceChannel; // 0x57b(0x01)
	float HitResultTraceDistance; // 0x57c(0x04)
	uint16_t SeamlessTravelCount; // 0x580(0x02)
	uint16_t LastCompletedSeamlessTravelCount; // 0x582(0x02)
	char pad_584[0x84]; // 0x584(0x84)
	struct UInputComponent* InactiveStateInputComponent; // 0x608(0x08)
	char pad_610_0 : 2; // 0x610(0x01)
	char bShouldPerformFullTickWhenPaused : 1; // 0x610(0x01)
	char pad_610_3 : 5; // 0x610(0x01)
	char pad_611[0x17]; // 0x611(0x17)
	struct UTouchInterface* CurrentTouchInterface; // 0x628(0x08)
	struct UPlayerInput* OverridePlayerInputClass; // 0x630(0x08)
	char pad_638[0x78]; // 0x638(0x78)
	struct ASpectatorPawn* SpectatorPawn; // 0x6b0(0x08)
	char pad_6B8[0x4]; // 0x6b8(0x04)
	bool bIsLocalPlayerController; // 0x6bc(0x01)
	char pad_6BD[0x3]; // 0x6bd(0x03)
	struct FVector SpawnLocation; // 0x6c0(0x18)
	char pad_6D8[0x178]; // 0x6d8(0x178)

	bool WasInputKeyJustReleased(struct FKey Key); // Function Engine.PlayerController.WasInputKeyJustReleased // (None) // @ game+0xffffbf0bdf830041
};

// Class Engine.NavigationObjectBase
// Size: 0x2b8 (Inherited: 0x290)
struct ANavigationObjectBase : AActor {
	char pad_290[0x8]; // 0x290(0x08)
	struct UCapsuleComponent* CapsuleComponent; // 0x298(0x08)
	struct UBillboardComponent* GoodSprite; // 0x2a0(0x08)
	struct UBillboardComponent* BadSprite; // 0x2a8(0x08)
	char bIsPIEPlayerStart : 1; // 0x2b0(0x01)
	char pad_2B0_1 : 7; // 0x2b0(0x01)
	char pad_2B1[0x7]; // 0x2b1(0x07)
};

// Class Engine.PlayerStart
// Size: 0x2c0 (Inherited: 0x2b8)
struct APlayerStart : ANavigationObjectBase {
	struct FName PlayerStartTag; // 0x2b8(0x08)
};

// Class Engine.SpectatorPawn
// Size: 0x340 (Inherited: 0x340)
struct ASpectatorPawn : ADefaultPawn {
	float BaseTurnRate; // 0x318(0x04)
	float BaseLookUpRate; // 0x31c(0x04)
	struct UPawnMovementComponent* MovementComponent; // 0x320(0x08)
	struct USphereComponent* CollisionComponent; // 0x328(0x08)
	struct UStaticMeshComponent* MeshComponent; // 0x330(0x08)
	char bAddDefaultMovementBindings : 1; // 0x338(0x01)
};

// Class Engine.WorldSettings
// Size: 0x4b8 (Inherited: 0x290)
struct AWorldSettings : AInfo {
	char pad_290[0x8]; // 0x290(0x08)
	int32_t VisibilityCellSize; // 0x298(0x04)
	enum class EVisibilityAggressiveness VisibilityAggressiveness; // 0x29c(0x01)
	char bPrecomputeVisibility : 1; // 0x29d(0x01)
	char bPlaceCellsOnlyAlongCameraTracks : 1; // 0x29d(0x01)
	char bEnableWorldBoundsChecks : 1; // 0x29d(0x01)
	char bEnableNavigationSystem : 1; // 0x29d(0x01)
	char bEnableAISystem : 1; // 0x29d(0x01)
	char bEnableWorldComposition : 1; // 0x29d(0x01)
	char bUseClientSideLevelStreamingVolumes : 1; // 0x29d(0x01)
	char bEnableWorldOriginRebasing : 1; // 0x29d(0x01)
	char bWorldGravitySet : 1; // 0x29e(0x01)
	char bGlobalGravitySet : 1; // 0x29e(0x01)
	char bMinimizeBSPSections : 1; // 0x29e(0x01)
	char bForceNoPrecomputedLighting : 1; // 0x29e(0x01)
	char bHighPriorityLoading : 1; // 0x29e(0x01)
	char bHighPriorityLoadingLocal : 1; // 0x29e(0x01)
	char bOverrideDefaultBroadphaseSettings : 1; // 0x29e(0x01)
	char bGenerateSingleClusterForLevel : 1; // 0x29e(0x01)
	char pad_29F[0x1]; // 0x29f(0x01)
	struct TSoftClassPtr<UObject> AISystemClass; // 0x2a0(0x30)
	struct FVector LevelInstancePivotOffset; // 0x2d0(0x18)
	struct UNavigationSystemConfig* NavigationSystemConfig; // 0x2e8(0x08)
	struct UNavigationSystemConfig* NavigationSystemConfigOverride; // 0x2f0(0x08)
	struct UWorldPartition* WorldPartition; // 0x2f8(0x08)
	struct TArray<struct UDataLayerAsset*> BaseNavmeshDataLayers; // 0x300(0x10)
	float WorldToMeters; // 0x310(0x04)
	float KillZ; // 0x314(0x04)
	struct UDamageType* KillZDamageType; // 0x318(0x08)
	float WorldGravityZ; // 0x320(0x04)
	float GlobalGravityZ; // 0x324(0x04)
	struct ADefaultPhysicsVolume* DefaultPhysicsVolumeClass; // 0x328(0x08)
	struct UPhysicsCollisionHandler* PhysicsCollisionHandlerClass; // 0x330(0x08)
	struct AGameModeBase* DefaultGameMode; // 0x338(0x08)
	struct AGameNetworkManager* GameNetworkManagerClass; // 0x340(0x08)
	int32_t PackedLightAndShadowMapTextureSize; // 0x348(0x04)
	char pad_34C[0x4]; // 0x34c(0x04)
	struct FVector DefaultColorScale; // 0x350(0x18)
	float DefaultMaxDistanceFieldOcclusionDistance; // 0x368(0x04)
	float GlobalDistanceFieldViewDistance; // 0x36c(0x04)
	float DynamicIndirectShadowsSelfShadowingIntensity; // 0x370(0x04)
	char pad_374[0x4]; // 0x374(0x04)
	struct FReverbSettings DefaultReverbSettings; // 0x378(0x20)
	struct FInteriorSettings DefaultAmbientZoneSettings; // 0x398(0x24)
	char pad_3BC[0x4]; // 0x3bc(0x04)
	struct USoundMix* DefaultBaseSoundMix; // 0x3c0(0x08)
	float TimeDilation; // 0x3c8(0x04)
	float CinematicTimeDilation; // 0x3cc(0x04)
	float DemoPlayTimeDilation; // 0x3d0(0x04)
	float MinGlobalTimeDilation; // 0x3d4(0x04)
	float MaxGlobalTimeDilation; // 0x3d8(0x04)
	float MinUndilatedFrameTime; // 0x3dc(0x04)
	float MaxUndilatedFrameTime; // 0x3e0(0x04)
	char pad_3E4[0x4]; // 0x3e4(0x04)
	struct FBroadphaseSettings BroadphaseSettings; // 0x3e8(0x80)
	struct TArray<struct FNetViewer> ReplicationViewers; // 0x468(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x478(0x10)
	struct APlayerState* PauserPlayerState; // 0x488(0x08)
	int32_t MaxNumberOfBookmarks; // 0x490(0x04)
	char pad_494[0x4]; // 0x494(0x04)
	struct UBookmarkBase* DefaultBookmarkClass; // 0x498(0x08)
	struct TArray<struct UBookmarkBase*> BookmarkArray; // 0x4a0(0x10)
	struct UBookmarkBase* LastBookmarkClass; // 0x4b0(0x08)

	void OnRep_WorldGravityZ(); // Function Engine.WorldSettings.OnRep_WorldGravityZ // (None) // @ game+0xffffc097df830041
};

// Class Engine.GameMode
// Size: 0x378 (Inherited: 0x330)
struct AGameMode : AGameModeBase {
	struct FName MatchState; // 0x330(0x08)
	char bDelayedStart : 1; // 0x338(0x01)
	char pad_338_1 : 7; // 0x338(0x01)
	char pad_339[0x3]; // 0x339(0x03)
	int32_t NumSpectators; // 0x33c(0x04)
	int32_t NumPlayers; // 0x340(0x04)
	int32_t NumBots; // 0x344(0x04)
	float MinRespawnDelay; // 0x348(0x04)
	int32_t NumTravellingPlayers; // 0x34c(0x04)
	struct ULocalMessage* EngineMessageClass; // 0x350(0x08)
	struct TArray<struct APlayerState*> InactivePlayerArray; // 0x358(0x10)
	float InactivePlayerStateLifeSpan; // 0x368(0x04)
	int32_t MaxInactivePlayers; // 0x36c(0x04)
	bool bHandleDedicatedServerReplays; // 0x370(0x01)
	char pad_371[0x7]; // 0x371(0x07)

	void StartMatch(); // Function Engine.GameMode.StartMatch // (None) // @ game+0xffffc51ddf830041
};

// Class Engine.GameState
// Size: 0x300 (Inherited: 0x2e0)
struct AGameState : AGameStateBase {
	struct FName MatchState; // 0x2e0(0x08)
	struct FName PreviousMatchState; // 0x2e8(0x08)
	int32_t ElapsedTime; // 0x2f0(0x04)
	char pad_2F4[0xc]; // 0x2f4(0x0c)

	void OnRep_MatchState(); // Function Engine.GameState.OnRep_MatchState // (None) // @ game+0xffffc523df830041
};

// Class Engine.SkyLight
// Size: 0x2a0 (Inherited: 0x290)
struct ASkyLight : AInfo {
	struct USkyLightComponent* LightComponent; // 0x290(0x08)
	char bEnabled : 1; // 0x298(0x01)
	char pad_298_1 : 7; // 0x298(0x01)
	char pad_299[0x7]; // 0x299(0x07)

	void OnRep_bEnabled(); // Function Engine.SkyLight.OnRep_bEnabled // (None) // @ game+0xffffc529df830041
};

// Class Engine.StreamableRenderAsset
// Size: 0xd0 (Inherited: 0x28)
struct UStreamableRenderAsset : UObject {
	char pad_28[0x18]; // 0x28(0x18)
	double ForceMipLevelsToBeResidentTimestamp; // 0x40(0x08)
	int32_t NumCinematicMipLevels; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct FPerQualityLevelInt NoRefStreamingLODBias; // 0x50(0x68)
	int32_t StreamingIndex; // 0xb8(0x04)
	int32_t CachedCombinedLODBias; // 0xbc(0x04)
	char NeverStream : 1; // 0xc0(0x01)
	char bGlobalForceMipLevelsToBeResident : 1; // 0xc0(0x01)
	char bHasStreamingUpdatePending : 1; // 0xc0(0x01)
	char bForceMiplevelsToBeResident : 1; // 0xc0(0x01)
	char bIgnoreStreamingMipBias : 1; // 0xc0(0x01)
	char bUseCinematicMipLevels : 1; // 0xc0(0x01)
	char pad_C0_6 : 2; // 0xc0(0x01)
	char pad_C1[0xf]; // 0xc1(0x0f)

	void SetForceMipLevelsToBeResident(float Seconds, int32_t CinematicLODGroupMask); // Function Engine.StreamableRenderAsset.SetForceMipLevelsToBeResident // (None) // @ game+0xffffc52bdf830041
};

// Class Engine.Texture
// Size: 0x1f0 (Inherited: 0xd0)
struct UTexture : UStreamableRenderAsset {
	char pad_D0[0x10]; // 0xd0(0x10)
	struct FGuid LightingGuid; // 0xe0(0x10)
	int32_t LevelIndex; // 0xf0(0x04)
	int32_t LODBias; // 0xf4(0x04)
	enum class TextureCompressionSettings CompressionSettings; // 0xf8(0x01)
	enum class TextureFilter Filter; // 0xf9(0x01)
	enum class ETextureMipLoadOptions MipLoadOptions; // 0xfa(0x01)
	enum class TextureGroup LODGroup; // 0xfb(0x01)
	struct FPerPlatformFloat Downscale; // 0xfc(0x04)
	enum class ETextureDownscaleOptions DownscaleOptions; // 0x100(0x01)
	char SRGB : 1; // 0x101(0x01)
	char bNoTiling : 1; // 0x101(0x01)
	char VirtualTextureStreaming : 1; // 0x101(0x01)
	char CompressionYCoCg : 1; // 0x101(0x01)
	char bNotOfflineProcessed : 1; // 0x101(0x01)
	char bAsyncResourceReleaseHasBeenStarted : 1; // 0x101(0x01)
	char pad_101_6 : 2; // 0x101(0x01)
	char pad_102[0x6]; // 0x102(0x06)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x108(0x10)
	char pad_118[0xd8]; // 0x118(0xd8)

	int64_t Blueprint_GetMemorySize(); // Function Engine.Texture.Blueprint_GetMemorySize // (None) // @ game+0xffffc52cdf830041
};

// Class Engine.TextureCube
// Size: 0x290 (Inherited: 0x1f0)
struct UTextureCube : UTexture {
	struct FGuid LightingGuid; // 0xe0(0x10)
	int32_t LevelIndex; // 0xf0(0x04)
	int32_t LODBias; // 0xf4(0x04)
	enum class TextureCompressionSettings CompressionSettings; // 0xf8(0x01)
	enum class TextureFilter Filter; // 0xf9(0x01)
	enum class ETextureMipLoadOptions MipLoadOptions; // 0xfa(0x01)
	enum class TextureGroup LODGroup; // 0xfb(0x01)
	struct FPerPlatformFloat Downscale; // 0xfc(0x04)
	enum class ETextureDownscaleOptions DownscaleOptions; // 0x100(0x01)
	char SRGB : 1; // 0x101(0x01)
	char bNoTiling : 1; // 0x101(0x01)
	char VirtualTextureStreaming : 1; // 0x101(0x01)
	char CompressionYCoCg : 1; // 0x101(0x01)
	char bNotOfflineProcessed : 1; // 0x101(0x01)
	char bAsyncResourceReleaseHasBeenStarted : 1; // 0x101(0x01)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x108(0x10)
	char pad_221_6 : 2; // 0x221(0x01)
	char pad_222[0x6e]; // 0x222(0x6e)
};

// Class Engine.StaticMeshComponent
// Size: 0x5f0 (Inherited: 0x570)
struct UStaticMeshComponent : UMeshComponent {
	int32_t ForcedLodModel; // 0x570(0x04)
	int32_t PreviousLODLevel; // 0x574(0x04)
	int32_t MinLOD; // 0x578(0x04)
	int32_t SubDivisionStepSize; // 0x57c(0x04)
	struct UStaticMesh* StaticMesh; // 0x580(0x08)
	struct FColor WireframeColorOverride; // 0x588(0x04)
	char bDisallowNanite : 1; // 0x58c(0x01)
	char bEvaluateWorldPositionOffset : 1; // 0x58c(0x01)
	char bEvaluateWorldPositionOffsetInRayTracing : 1; // 0x58c(0x01)
	char pad_58C_3 : 5; // 0x58c(0x01)
	char pad_58D[0x3]; // 0x58d(0x03)
	int32_t WorldPositionOffsetDisableDistance; // 0x590(0x04)
	char pad_594_0 : 1; // 0x594(0x01)
	char bOverrideWireframeColor : 1; // 0x594(0x01)
	char bOverrideMinLod : 1; // 0x594(0x01)
	char bOverrideNavigationExport : 1; // 0x594(0x01)
	char bForceNavigationObstacle : 1; // 0x594(0x01)
	char bDisallowMeshPaintPerInstance : 1; // 0x594(0x01)
	char bIgnoreInstanceForTextureStreaming : 1; // 0x594(0x01)
	char bOverrideLightMapRes : 1; // 0x594(0x01)
	char bCastDistanceFieldIndirectShadow : 1; // 0x595(0x01)
	char bOverrideDistanceFieldSelfShadowBias : 1; // 0x595(0x01)
	char bUseSubDivisions : 1; // 0x595(0x01)
	char bUseDefaultCollision : 1; // 0x595(0x01)
	char bSortTriangles : 1; // 0x595(0x01)
	char bReverseCulling : 1; // 0x595(0x01)
	char pad_595_6 : 2; // 0x595(0x01)
	char pad_596[0x2]; // 0x596(0x02)
	int32_t OverriddenLightMapRes; // 0x598(0x04)
	float DistanceFieldIndirectShadowMinVisibility; // 0x59c(0x04)
	float DistanceFieldSelfShadowBias; // 0x5a0(0x04)
	float StreamingDistanceMultiplier; // 0x5a4(0x04)
	struct TArray<struct FStaticMeshComponentLODInfo> LODData; // 0x5a8(0x10)
	struct TArray<struct FStreamingTextureBuildInfo> StreamingTextureData; // 0x5b8(0x10)
	struct FLightmassPrimitiveSettings LightmassSettings; // 0x5c8(0x18)
	char pad_5E0[0x10]; // 0x5e0(0x10)

	bool SetStaticMesh(struct UStaticMesh* NewMesh); // Function Engine.StaticMeshComponent.SetStaticMesh // (None) // @ game+0xffffc5d3df830041
};

// Class Engine.InstancedStaticMeshComponent
// Size: 0x740 (Inherited: 0x5f0)
struct UInstancedStaticMeshComponent : UStaticMeshComponent {
	char pad_5F0[0x8]; // 0x5f0(0x08)
	struct TArray<struct FInstancedStaticMeshInstanceData> PerInstanceSMData; // 0x5f8(0x10)
	struct TArray<struct FMatrix> PerInstancePrevTransform; // 0x608(0x10)
	int32_t NumCustomDataFloats; // 0x618(0x04)
	char pad_61C[0x4]; // 0x61c(0x04)
	struct TArray<float> PerInstanceSMCustomData; // 0x620(0x10)
	int32_t InstancingRandomSeed; // 0x630(0x04)
	char pad_634[0x4]; // 0x634(0x04)
	struct TArray<struct FInstancedStaticMeshRandomSeed> AdditionalRandomSeeds; // 0x638(0x10)
	int32_t InstanceStartCullDistance; // 0x648(0x04)
	int32_t InstanceEndCullDistance; // 0x64c(0x04)
	struct TArray<int32_t> InstanceReorderTable; // 0x650(0x10)
	char pad_660[0xc0]; // 0x660(0xc0)
	int32_t NumPendingLightmaps; // 0x720(0x04)
	char pad_724[0x4]; // 0x724(0x04)
	struct TArray<struct FInstancedStaticMeshMappingInfo> CachedMappings; // 0x728(0x10)
	char pad_738[0x8]; // 0x738(0x08)

	bool UpdateInstanceTransform(int32_t InstanceIndex, struct FTransform& NewInstanceTransform, bool bWorldSpace, bool bMarkRenderStateDirty, bool bTeleport); // Function Engine.InstancedStaticMeshComponent.UpdateInstanceTransform // (None) // @ game+0xffffc5e3df830041
};

// Class Engine.HierarchicalInstancedStaticMeshComponent
// Size: 0x8d0 (Inherited: 0x740)
struct UHierarchicalInstancedStaticMeshComponent : UInstancedStaticMeshComponent {
	char pad_740[0x8]; // 0x740(0x08)
	char bUseTranslatedInstanceSpace : 1; // 0x748(0x01)
	char pad_748_1 : 7; // 0x748(0x01)
	char pad_749[0x7]; // 0x749(0x07)
	struct FVector TranslatedInstanceSpaceOrigin; // 0x750(0x18)
	struct TArray<int32_t> SortedInstances; // 0x768(0x10)
	int32_t NumBuiltInstances; // 0x778(0x04)
	char pad_77C[0x4]; // 0x77c(0x04)
	struct FBox BuiltInstanceBounds; // 0x780(0x38)
	struct FBox UnbuiltInstanceBounds; // 0x7b8(0x38)
	struct TArray<struct FBox> UnbuiltInstanceBoundsList; // 0x7f0(0x10)
	char bEnableDensityScaling : 1; // 0x800(0x01)
	char pad_800_1 : 7; // 0x800(0x01)
	char pad_801[0x7]; // 0x801(0x07)
	int32_t OcclusionLayerNumNodes; // 0x808(0x04)
	char pad_80C[0x4]; // 0x80c(0x04)
	struct FBoxSphereBounds CacheMeshExtendedBounds; // 0x810(0x38)
	bool bDisableCollision; // 0x848(0x01)
	char pad_849[0x3]; // 0x849(0x03)
	int32_t InstanceCountToRender; // 0x84c(0x04)
	char pad_850[0x80]; // 0x850(0x80)
};

// Class Engine.PartitionActor
// Size: 0x290 (Inherited: 0x290)
struct APartitionActor : AActor {
	struct FActorTickFunction PrimaryActorTick; // 0x28(0x30)
	char bNetTemporary : 1; // 0x58(0x01)
	char pad_2C0_1 : 1; // 0x2c0(0x01)
	char bOnlyRelevantToOwner : 1; // 0x58(0x01)
	char bAlwaysRelevant : 1; // 0x58(0x01)
	char bReplicateMovement : 1; // 0x58(0x01)
	char bCallPreReplication : 1; // 0x58(0x01)
	char bCallPreReplicationForReplay : 1; // 0x58(0x01)
	char bHidden : 1; // 0x58(0x01)
	char bTearOff : 1; // 0x59(0x01)
	char bForceNetAddressable : 1; // 0x59(0x01)
	char bExchangedRoles : 1; // 0x59(0x01)
	char bNetLoadOnClient : 1; // 0x59(0x01)
	char bNetUseOwnerRelevancy : 1; // 0x59(0x01)
	char bRelevantForNetworkReplays : 1; // 0x59(0x01)
	char bRelevantForLevelBounds : 1; // 0x59(0x01)
	char bReplayRewindable : 1; // 0x59(0x01)
	char bAllowTickBeforeBeginPlay : 1; // 0x5a(0x01)
	char bAutoDestroyWhenFinished : 1; // 0x5a(0x01)
	char bCanBeDamaged : 1; // 0x5a(0x01)
	char bBlockInput : 1; // 0x5a(0x01)
	char bCollideWhenPlacing : 1; // 0x5a(0x01)
	char bFindCameraComponentWhenViewTarget : 1; // 0x5a(0x01)
	char bGenerateOverlapEventsDuringLevelStreaming : 1; // 0x5a(0x01)
	char bIgnoresOriginShifting : 1; // 0x5a(0x01)
	char bEnableAutoLODGeneration : 1; // 0x5b(0x01)
	char bIsEditorOnlyActor : 1; // 0x5b(0x01)
	char bActorSeamlessTraveled : 1; // 0x5b(0x01)
	char bReplicates : 1; // 0x5b(0x01)
	char bCanBeInCluster : 1; // 0x5b(0x01)
	char bAllowReceiveTickEventOnDedicatedServer : 1; // 0x5b(0x01)
	char pad_2C3_6 : 1; // 0x2c3(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x5b(0x01)
	char pad_2C4_0 : 7; // 0x2c4(0x01)
	char bActorEnableCollision : 1; // 0x5c(0x01)
	char bActorIsBeingDestroyed : 1; // 0x5d(0x01)
	char pad_2C5_1 : 4; // 0x2c5(0x01)
	char bAsyncPhysicsTickEnabled : 1; // 0x5d(0x01)
	enum class EActorUpdateOverlapsMethod UpdateOverlapsMethodDuringLevelStreaming; // 0x5e(0x01)
	enum class EActorUpdateOverlapsMethod DefaultUpdateOverlapsMethodDuringLevelStreaming; // 0x5f(0x01)
	float InitialLifeSpan; // 0x60(0x04)
	float CustomTimeDilation; // 0x64(0x04)
	enum class ENetRole RemoteRole; // 0x68(0x01)
	int32_t RayTracingGroupId; // 0x6c(0x04)
	struct FRepAttachment AttachmentReplication; // 0x70(0x60)
	struct FRepMovement ReplicatedMovement; // 0xd0(0x70)
	struct AActor* Owner; // 0x140(0x08)
	struct FName NetDriverName; // 0x148(0x08)
	enum class ENetRole Role; // 0x150(0x01)
	enum class ENetDormancy NetDormancy; // 0x151(0x01)
	enum class ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingMethod; // 0x152(0x01)
	enum class EAutoReceiveInput AutoReceiveInput; // 0x153(0x01)
	int32_t InputPriority; // 0x154(0x04)
	struct UInputComponent* InputComponent; // 0x160(0x08)
	float NetCullDistanceSquared; // 0x168(0x04)
	int32_t NetTag; // 0x16c(0x04)
	float NetUpdateFrequency; // 0x170(0x04)
	float MinNetUpdateFrequency; // 0x174(0x04)
	float NetPriority; // 0x178(0x04)
	struct APawn* Instigator; // 0x180(0x08)
	struct TArray<struct AActor*> Children; // 0x188(0x10)
	struct USceneComponent* RootComponent; // 0x198(0x08)
	struct TArray<struct FName> Layers; // 0x1a8(0x10)
	struct TWeakObjectPtr<struct UChildActorComponent> ParentComponent; // 0x1b8(0x08)
	struct TArray<struct FName> Tags; // 0x1c0(0x10)
	struct FMulticastSparseDelegate OnTakeAnyDamage; // 0x1d0(0x01)
	struct FMulticastSparseDelegate OnTakePointDamage; // 0x1d1(0x01)
	struct FMulticastSparseDelegate OnTakeRadialDamage; // 0x1d2(0x01)
	struct FMulticastSparseDelegate OnActorBeginOverlap; // 0x1d3(0x01)
	struct FMulticastSparseDelegate OnActorEndOverlap; // 0x1d4(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x1d5(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x1d6(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x1d7(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x1d8(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x1d9(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x1da(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x1db(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x1dc(0x01)
	struct FMulticastSparseDelegate OnActorHit; // 0x1dd(0x01)
	struct FMulticastSparseDelegate OnDestroyed; // 0x1de(0x01)
	struct FMulticastSparseDelegate OnEndPlay; // 0x1df(0x01)
	struct TArray<struct UActorComponent*> InstanceComponents; // 0x260(0x10)
	struct TArray<struct UActorComponent*> BlueprintCreatedComponents; // 0x270(0x10)
};

// Class Engine.ISMPartitionActor
// Size: 0x2a0 (Inherited: 0x290)
struct AISMPartitionActor : APartitionActor {
	struct FActorTickFunction PrimaryActorTick; // 0x28(0x30)
	char bNetTemporary : 1; // 0x58(0x01)
	char pad_2C0_1 : 1; // 0x2c0(0x01)
	char bOnlyRelevantToOwner : 1; // 0x58(0x01)
	char bAlwaysRelevant : 1; // 0x58(0x01)
	char bReplicateMovement : 1; // 0x58(0x01)
	char bCallPreReplication : 1; // 0x58(0x01)
	char bCallPreReplicationForReplay : 1; // 0x58(0x01)
	char bHidden : 1; // 0x58(0x01)
	char bTearOff : 1; // 0x59(0x01)
	char bForceNetAddressable : 1; // 0x59(0x01)
	char bExchangedRoles : 1; // 0x59(0x01)
	char bNetLoadOnClient : 1; // 0x59(0x01)
	char bNetUseOwnerRelevancy : 1; // 0x59(0x01)
	char bRelevantForNetworkReplays : 1; // 0x59(0x01)
	char bRelevantForLevelBounds : 1; // 0x59(0x01)
	char bReplayRewindable : 1; // 0x59(0x01)
	char bAllowTickBeforeBeginPlay : 1; // 0x5a(0x01)
	char bAutoDestroyWhenFinished : 1; // 0x5a(0x01)
	char bCanBeDamaged : 1; // 0x5a(0x01)
	char bBlockInput : 1; // 0x5a(0x01)
	char bCollideWhenPlacing : 1; // 0x5a(0x01)
	char bFindCameraComponentWhenViewTarget : 1; // 0x5a(0x01)
	char bGenerateOverlapEventsDuringLevelStreaming : 1; // 0x5a(0x01)
	char bIgnoresOriginShifting : 1; // 0x5a(0x01)
	char bEnableAutoLODGeneration : 1; // 0x5b(0x01)
	char bIsEditorOnlyActor : 1; // 0x5b(0x01)
	char bActorSeamlessTraveled : 1; // 0x5b(0x01)
	char bReplicates : 1; // 0x5b(0x01)
	char bCanBeInCluster : 1; // 0x5b(0x01)
	char bAllowReceiveTickEventOnDedicatedServer : 1; // 0x5b(0x01)
	char pad_2C3_6 : 1; // 0x2c3(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x5b(0x01)
	char pad_2C4_0 : 7; // 0x2c4(0x01)
	char bActorEnableCollision : 1; // 0x5c(0x01)
	char bActorIsBeingDestroyed : 1; // 0x5d(0x01)
	char pad_2C5_1 : 4; // 0x2c5(0x01)
	char bAsyncPhysicsTickEnabled : 1; // 0x5d(0x01)
	enum class EActorUpdateOverlapsMethod UpdateOverlapsMethodDuringLevelStreaming; // 0x5e(0x01)
	enum class EActorUpdateOverlapsMethod DefaultUpdateOverlapsMethodDuringLevelStreaming; // 0x5f(0x01)
	float InitialLifeSpan; // 0x60(0x04)
	float CustomTimeDilation; // 0x64(0x04)
	enum class ENetRole RemoteRole; // 0x68(0x01)
	int32_t RayTracingGroupId; // 0x6c(0x04)
	struct FRepAttachment AttachmentReplication; // 0x70(0x60)
	struct FRepMovement ReplicatedMovement; // 0xd0(0x70)
	struct AActor* Owner; // 0x140(0x08)
	struct FName NetDriverName; // 0x148(0x08)
	enum class ENetRole Role; // 0x150(0x01)
	enum class ENetDormancy NetDormancy; // 0x151(0x01)
	enum class ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingMethod; // 0x152(0x01)
	enum class EAutoReceiveInput AutoReceiveInput; // 0x153(0x01)
	int32_t InputPriority; // 0x154(0x04)
	struct UInputComponent* InputComponent; // 0x160(0x08)
	float NetCullDistanceSquared; // 0x168(0x04)
	int32_t NetTag; // 0x16c(0x04)
	float NetUpdateFrequency; // 0x170(0x04)
	float MinNetUpdateFrequency; // 0x174(0x04)
	float NetPriority; // 0x178(0x04)
	struct APawn* Instigator; // 0x180(0x08)
	struct TArray<struct AActor*> Children; // 0x188(0x10)
	struct USceneComponent* RootComponent; // 0x198(0x08)
	struct TArray<struct FName> Layers; // 0x1a8(0x10)
	struct TWeakObjectPtr<struct UChildActorComponent> ParentComponent; // 0x1b8(0x08)
	struct TArray<struct FName> Tags; // 0x1c0(0x10)
	struct FMulticastSparseDelegate OnTakeAnyDamage; // 0x1d0(0x01)
	struct FMulticastSparseDelegate OnTakePointDamage; // 0x1d1(0x01)
	struct FMulticastSparseDelegate OnTakeRadialDamage; // 0x1d2(0x01)
	struct FMulticastSparseDelegate OnActorBeginOverlap; // 0x1d3(0x01)
	struct FMulticastSparseDelegate OnActorEndOverlap; // 0x1d4(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x1d5(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x1d6(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x1d7(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x1d8(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x1d9(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x1da(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x1db(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x1dc(0x01)
	struct FMulticastSparseDelegate OnActorHit; // 0x1dd(0x01)
	struct FMulticastSparseDelegate OnDestroyed; // 0x1de(0x01)
	struct FMulticastSparseDelegate OnEndPlay; // 0x1df(0x01)
	struct TArray<struct UActorComponent*> InstanceComponents; // 0x260(0x10)
	struct TArray<struct UActorComponent*> BlueprintCreatedComponents; // 0x270(0x10)
};

// Class Engine.StaticMeshActor
// Size: 0x2a0 (Inherited: 0x290)
struct AStaticMeshActor : AActor {
	struct UStaticMeshComponent* StaticMeshComponent; // 0x290(0x08)
	bool bStaticMeshReplicateMovement; // 0x298(0x01)
	enum class ENavDataGatheringMode NavigationGeometryGatheringMode; // 0x299(0x01)
	char pad_29A[0x6]; // 0x29a(0x06)

	void SetMobility(enum class EComponentMobility InMobility); // Function Engine.StaticMeshActor.SetMobility // (None) // @ game+0xffffc5e7df830041
};

// Class Engine.MaterialInterface
// Size: 0x98 (Inherited: 0x28)
struct UMaterialInterface : UObject {
	char pad_28[0x10]; // 0x28(0x10)
	struct USubsurfaceProfile* SubsurfaceProfile; // 0x38(0x08)
	char pad_40[0x10]; // 0x40(0x10)
	struct FLightmassMaterialInterfaceSettings LightmassSettings; // 0x50(0x10)
	struct TArray<struct FMaterialTextureInfo> TextureStreamingData; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	char pad_80[0x18]; // 0x80(0x18)

	void SetForceMipLevelsToBeResident(bool OverrideForceMiplevelsToBeResident, bool bForceMiplevelsToBeResidentValue, float ForceDuration, int32_t CinematicTextureGroups, bool bFastResponse); // Function Engine.MaterialInterface.SetForceMipLevelsToBeResident // (None) // @ game+0xffffc601df830041
};

// Class Engine.MaterialInstance
// Size: 0x1f8 (Inherited: 0x98)
struct UMaterialInstance : UMaterialInterface {
	struct UPhysicalMaterial* PhysMaterial; // 0x98(0x08)
	struct UPhysicalMaterial* PhysicalMaterialMap[0x8]; // 0xa0(0x40)
	struct UMaterialInterface* Parent; // 0xe0(0x08)
	struct FMaterialOverrideNanite NaniteOverrideMaterial; // 0xe8(0x40)
	char bHasStaticPermutationResource : 1; // 0x128(0x01)
	char bOverrideSubsurfaceProfile : 1; // 0x128(0x01)
	char pad_128_2 : 6; // 0x128(0x01)
	char pad_129[0x7]; // 0x129(0x07)
	struct TArray<struct FScalarParameterValue> ScalarParameterValues; // 0x130(0x10)
	struct TArray<struct FVectorParameterValue> VectorParameterValues; // 0x140(0x10)
	struct TArray<struct FDoubleVectorParameterValue> DoubleVectorParameterValues; // 0x150(0x10)
	struct TArray<struct FTextureParameterValue> TextureParameterValues; // 0x160(0x10)
	struct TArray<struct FRuntimeVirtualTextureParameterValue> RuntimeVirtualTextureParameterValues; // 0x170(0x10)
	struct TArray<struct FFontParameterValue> FontParameterValues; // 0x180(0x10)
	struct FMaterialInstanceBasePropertyOverrides BasePropertyOverrides; // 0x190(0x08)
	char pad_198[0x8]; // 0x198(0x08)
	struct FStaticParameterSetRuntimeData StaticParametersRuntime; // 0x1a0(0x28)
	char pad_1C8[0x30]; // 0x1c8(0x30)
};

// Class Engine.MaterialInstanceConstant
// Size: 0x200 (Inherited: 0x1f8)
struct UMaterialInstanceConstant : UMaterialInstance {
	struct UPhysicalMaterialMask* PhysMaterialMask; // 0x1f8(0x08)

	struct FLinearColor K2_GetVectorParameterValue(struct FName ParameterName); // Function Engine.MaterialInstanceConstant.K2_GetVectorParameterValue // (None) // @ game+0xffffc604df830041
};

// Class Engine.MaterialExpressionCustomOutput
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionCustomOutput : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.EngineCustomTimeStep
// Size: 0x28 (Inherited: 0x28)
struct UEngineCustomTimeStep : UObject {
};

// Class Engine.TimecodeProvider
// Size: 0x30 (Inherited: 0x28)
struct UTimecodeProvider : UObject {
	float FrameDelay; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)

	struct FTimecode GetTimecode(); // Function Engine.TimecodeProvider.GetTimecode // (None) // @ game+0xffffc611df830041
};

// Class Engine.EdGraphNode
// Size: 0x98 (Inherited: 0x28)
struct UEdGraphNode : UObject {
	char pad_28[0x10]; // 0x28(0x10)
	struct TArray<struct UEdGraphPin_Deprecated*> DeprecatedPins; // 0x38(0x10)
	int32_t NodePosX; // 0x48(0x04)
	int32_t NodePosY; // 0x4c(0x04)
	int32_t NodeWidth; // 0x50(0x04)
	int32_t NodeHeight; // 0x54(0x04)
	enum class ENodeAdvancedPins AdvancedPinDisplay; // 0x58(0x01)
	enum class ENodeEnabledState EnabledState; // 0x59(0x01)
	char pad_5A[0x1]; // 0x5a(0x01)
	char pad_5B_0 : 1; // 0x5b(0x01)
	char bDisplayAsDisabled : 1; // 0x5b(0x01)
	char bUserSetEnabledState : 1; // 0x5b(0x01)
	char bIsIntermediateNode : 1; // 0x5b(0x01)
	char bHasCompilerMessage : 1; // 0x5b(0x01)
	char pad_5B_5 : 3; // 0x5b(0x01)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct FString NodeComment; // 0x60(0x10)
	int32_t ErrorType; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct FString ErrorMsg; // 0x78(0x10)
	struct FGuid NodeGuid; // 0x88(0x10)
};

// Class Engine.CameraActor
// Size: 0x9a0 (Inherited: 0x290)
struct ACameraActor : AActor {
	enum class EAutoReceiveInput AutoActivateForPlayer; // 0x290(0x01)
	char pad_291[0x7]; // 0x291(0x07)
	struct UCameraComponent* CameraComponent; // 0x298(0x08)
	struct USceneComponent* SceneComponent; // 0x2a0(0x08)
	char bConstrainAspectRatio : 1; // 0x2a8(0x01)
	char pad_2A8_1 : 7; // 0x2a8(0x01)
	char pad_2A9[0x3]; // 0x2a9(0x03)
	float AspectRatio; // 0x2ac(0x04)
	float FOVAngle; // 0x2b0(0x04)
	float PostProcessBlendWeight; // 0x2b4(0x04)
	char pad_2B8[0x8]; // 0x2b8(0x08)
	struct FPostProcessSettings PostProcessSettings; // 0x2c0(0x6e0)

	int32_t GetAutoActivatePlayerIndex(); // Function Engine.CameraActor.GetAutoActivatePlayerIndex // (None) // @ game+0xffffc849df830041
};

// Class Engine.CameraComponent
// Size: 0xa30 (Inherited: 0x2a0)
struct UCameraComponent : USceneComponent {
	float FieldOfView; // 0x2a0(0x04)
	float OrthoWidth; // 0x2a4(0x04)
	float OrthoNearClipPlane; // 0x2a8(0x04)
	float OrthoFarClipPlane; // 0x2ac(0x04)
	float AspectRatio; // 0x2b0(0x04)
	char bConstrainAspectRatio : 1; // 0x2b4(0x01)
	char bUseFieldOfViewForLOD : 1; // 0x2b4(0x01)
	char bLockToHmd : 1; // 0x2b4(0x01)
	char bUsePawnControlRotation : 1; // 0x2b4(0x01)
	char pad_2B4_4 : 4; // 0x2b4(0x01)
	enum class ECameraProjectionMode ProjectionMode; // 0x2b5(0x01)
	char pad_2B6[0x6a]; // 0x2b6(0x6a)
	float PostProcessBlendWeight; // 0x320(0x04)
	char pad_324[0x2c]; // 0x324(0x2c)
	struct FPostProcessSettings PostProcessSettings; // 0x350(0x6e0)

	void SetUseFieldOfViewForLOD(bool bInUseFieldOfViewForLOD); // Function Engine.CameraComponent.SetUseFieldOfViewForLOD // (None) // @ game+0xffffc857df830041
};

// Class Engine.ActiveSoundUpdateInterface
// Size: 0x28 (Inherited: 0x28)
struct UActiveSoundUpdateInterface : UInterface {
};

// Class Engine.Channel
// Size: 0x68 (Inherited: 0x28)
struct UChannel : UObject {
	struct UNetConnection* Connection; // 0x28(0x08)
	char pad_30[0x38]; // 0x30(0x38)
};

// Class Engine.ActorChannel
// Size: 0x290 (Inherited: 0x68)
struct UActorChannel : UChannel {
	struct AActor* Actor; // 0x68(0x08)
	char pad_70[0xe8]; // 0x70(0xe8)
	struct TArray<struct UObject*> CreateSubObjects; // 0x158(0x10)
	char pad_168[0x128]; // 0x168(0x128)
};

// Class Engine.ActorReplicationBridge
// Size: 0x28 (Inherited: 0x28)
struct UActorReplicationBridge : UObjectReplicationBridge {
};

// Class Engine.AnimationAssetExtensions
// Size: 0x28 (Inherited: 0x28)
struct UAnimationAssetExtensions : UBlueprintFunctionLibrary {
};

// Class Engine.AnimBlueprintClassSubsystem_PropertyAccess
// Size: 0x28 (Inherited: 0x28)
struct UAnimBlueprintClassSubsystem_PropertyAccess : UObject {
};

// Class Engine.AnimationDataModelNotifiesExtensions
// Size: 0x28 (Inherited: 0x28)
struct UAnimationDataModelNotifiesExtensions : UBlueprintFunctionLibrary {
};

// Class Engine.AnimLayerInterface
// Size: 0x28 (Inherited: 0x28)
struct UAnimLayerInterface : UInterface {
};

// Class Engine.AnimationAsset
// Size: 0x80 (Inherited: 0x28)
struct UAnimationAsset : UObject {
	char pad_28[0x10]; // 0x28(0x10)
	struct USkeleton* Skeleton; // 0x38(0x08)
	char pad_40[0x20]; // 0x40(0x20)
	struct TArray<struct UAnimMetaData*> MetaData; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)

	float GetPlayLength(); // Function Engine.AnimationAsset.GetPlayLength // (None) // @ game+0xffffc9acdf830041
};

// Class Engine.AnimSequenceBase
// Size: 0xb0 (Inherited: 0x80)
struct UAnimSequenceBase : UAnimationAsset {
	struct TArray<struct FAnimNotifyEvent> Notifies; // 0x80(0x10)
	float SequenceLength; // 0x90(0x04)
	float RateScale; // 0x94(0x04)
	bool bLoop; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
	struct FRawCurveTracks RawCurveData; // 0xa0(0x10)
};

// Class Engine.RawAnimSequenceTrackExtensions
// Size: 0x28 (Inherited: 0x28)
struct URawAnimSequenceTrackExtensions : UBlueprintFunctionLibrary {

	struct TArray<struct FVector> GetScaleKeys(struct FRawAnimSequenceTrack& Track); // Function Engine.RawAnimSequenceTrackExtensions.GetScaleKeys // (None) // @ game+0xffffc9afdf830041
};

// Class Engine.AssetExportTask
// Size: 0x78 (Inherited: 0x28)
struct UAssetExportTask : UObject {
	struct UObject* Object; // 0x28(0x08)
	struct UExporter* Exporter; // 0x30(0x08)
	struct FString Filename; // 0x38(0x10)
	bool bSelected; // 0x48(0x01)
	bool bReplaceIdentical; // 0x49(0x01)
	bool bPrompt; // 0x4a(0x01)
	bool bAutomated; // 0x4b(0x01)
	bool bUseFileArchive; // 0x4c(0x01)
	bool bWriteEmptyFiles; // 0x4d(0x01)
	char pad_4E[0x2]; // 0x4e(0x02)
	struct TArray<struct UObject*> IgnoreObjectList; // 0x50(0x10)
	struct UObject* Options; // 0x60(0x08)
	struct TArray<struct FString> Errors; // 0x68(0x10)
};

// Class Engine.AssetManagerSettings
// Size: 0x100 (Inherited: 0x38)
struct UAssetManagerSettings : UDeveloperSettings {
	struct TArray<struct FPrimaryAssetTypeInfo> PrimaryAssetTypesToScan; // 0x38(0x10)
	struct TArray<struct FDirectoryPath> DirectoriesToExclude; // 0x48(0x10)
	struct TArray<struct FPrimaryAssetRulesOverride> PrimaryAssetRules; // 0x58(0x10)
	struct TArray<struct FPrimaryAssetRulesCustomOverride> CustomPrimaryAssetRules; // 0x68(0x10)
	bool bOnlyCookProductionAssets; // 0x78(0x01)
	bool bShouldManagerDetermineTypeAndName; // 0x79(0x01)
	bool bShouldGuessTypeAndNameInEditor; // 0x7a(0x01)
	bool bShouldAcquireMissingChunksOnLoad; // 0x7b(0x01)
	bool bShouldWarnAboutInvalidAssets; // 0x7c(0x01)
	char pad_7D[0x3]; // 0x7d(0x03)
	struct TArray<struct FAssetManagerRedirect> PrimaryAssetIdRedirects; // 0x80(0x10)
	struct TArray<struct FAssetManagerRedirect> PrimaryAssetTypeRedirects; // 0x90(0x10)
	struct TArray<struct FAssetManagerRedirect> AssetPathRedirects; // 0xa0(0x10)
	struct TSet<struct FName> MetaDataTagsForAssetRegistry; // 0xb0(0x50)
};

// Class Engine.AsyncPhysicsData
// Size: 0x30 (Inherited: 0x28)
struct UAsyncPhysicsData : UObject {
	int32_t ServerFrame; // 0x28(0x04)
	int32_t ReplicationRedundancy; // 0x2c(0x04)
};

// Class Engine.AudioPanelWidgetInterface
// Size: 0x28 (Inherited: 0x28)
struct UAudioPanelWidgetInterface : UInterface {

	struct FName GetIconBrushName(); // Function Engine.AudioPanelWidgetInterface.GetIconBrushName // (None) // @ game+0xffffc9b1df830041
};

// Class Engine.BlendableInterface
// Size: 0x28 (Inherited: 0x28)
struct UBlendableInterface : UInterface {
};

// Class Engine.AnalysisProperties
// Size: 0x38 (Inherited: 0x28)
struct UAnalysisProperties : UObject {
	struct FString Function; // 0x28(0x10)
};

// Class Engine.BlendSpace
// Size: 0x1a0 (Inherited: 0x80)
struct UBlendSpace : UAnimationAsset {
	char pad_80[0x8]; // 0x80(0x08)
	bool bContainsRotationOffsetMeshSpaceSamples; // 0x88(0x01)
	char pad_89[0x3]; // 0x89(0x03)
	struct FInterpolationParameter InterpolationParam[0x3]; // 0x8c(0x30)
	float TargetWeightInterpolationSpeedPerSec; // 0xbc(0x04)
	bool bTargetWeightInterpolationEaseInOut; // 0xc0(0x01)
	bool bAllowMeshSpaceBlending; // 0xc1(0x01)
	bool bLoop; // 0xc2(0x01)
	char pad_C3[0x1]; // 0xc3(0x01)
	float AnimLength; // 0xc4(0x04)
	enum class ENotifyTriggerMode NotifyTriggerMode; // 0xc8(0x01)
	bool bInterpolateUsingGrid; // 0xc9(0x01)
	enum class EPreferredTriangulationDirection PreferredTriangulationDirection; // 0xca(0x01)
	char pad_CB[0x5]; // 0xcb(0x05)
	struct TArray<struct FPerBoneInterpolation> PerBoneBlend; // 0xd0(0x10)
	int32_t SampleIndexWithMarkers; // 0xe0(0x04)
	char pad_E4[0x4]; // 0xe4(0x04)
	struct TArray<struct FBlendSample> SampleData; // 0xe8(0x10)
	struct TArray<struct FEditorElement> GridSamples; // 0xf8(0x10)
	struct FBlendSpaceData BlendSpaceData; // 0x108(0x20)
	struct FBlendParameter BlendParameters[0x3]; // 0x128(0x60)
	enum class EBlendSpaceAxis AxisToScaleAnimation; // 0x188(0x01)
	char pad_189[0x7]; // 0x189(0x07)
	struct TArray<int32_t> DimensionIndices; // 0x190(0x10)
};

// Class Engine.Breakpoint
// Size: 0x28 (Inherited: 0x28)
struct UBreakpoint : UObject {
};

// Class Engine.BlueprintExtension
// Size: 0x28 (Inherited: 0x28)
struct UBlueprintExtension : UObject {
};

// Class Engine.BookmarkBase
// Size: 0x28 (Inherited: 0x28)
struct UBookmarkBase : UObject {
};

// Class Engine.BookMark2D
// Size: 0x38 (Inherited: 0x28)
struct UBookMark2D : UBookmarkBase {
	float Zoom2D; // 0x28(0x04)
	struct FIntPoint Location; // 0x2c(0x08)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class Engine.ReflectionCapture
// Size: 0x298 (Inherited: 0x290)
struct AReflectionCapture : AActor {
	struct UReflectionCaptureComponent* CaptureComponent; // 0x290(0x08)
};

// Class Engine.BoxReflectionCapture
// Size: 0x298 (Inherited: 0x298)
struct ABoxReflectionCapture : AReflectionCapture {
	struct UReflectionCaptureComponent* CaptureComponent; // 0x290(0x08)
};

// Class Engine.ReflectionCaptureComponent
// Size: 0x310 (Inherited: 0x2a0)
struct UReflectionCaptureComponent : USceneComponent {
	struct UBillboardComponent* CaptureOffsetComponent; // 0x2a0(0x08)
	enum class EReflectionSourceType ReflectionSourceType; // 0x2a8(0x01)
	char pad_2A9[0x7]; // 0x2a9(0x07)
	struct UTextureCube* Cubemap; // 0x2b0(0x08)
	float SourceCubemapAngle; // 0x2b8(0x04)
	float Brightness; // 0x2bc(0x04)
	struct FVector CaptureOffset; // 0x2c0(0x18)
	struct FGuid MapBuildDataId; // 0x2d8(0x10)
	char pad_2E8[0x28]; // 0x2e8(0x28)
};

// Class Engine.BoxReflectionCaptureComponent
// Size: 0x330 (Inherited: 0x310)
struct UBoxReflectionCaptureComponent : UReflectionCaptureComponent {
	float BoxTransitionDistance; // 0x310(0x04)
	char pad_314[0x4]; // 0x314(0x04)
	struct UBoxComponent* PreviewInfluenceBox; // 0x318(0x08)
	struct UBoxComponent* PreviewCaptureBox; // 0x320(0x08)
	char pad_328[0x8]; // 0x328(0x08)
};

// Class Engine.BuiltInAttributesExtensions
// Size: 0x28 (Inherited: 0x28)
struct UBuiltInAttributesExtensions : UBlueprintFunctionLibrary {
};

// Class Engine.ChildConnection
// Size: 0x3310 (Inherited: 0x3310)
struct UChildConnection : UNetConnection {
	struct UNetConnection* Parent; // 0x3308(0x08)
};

// Class Engine.PlatformInterfaceBase
// Size: 0x38 (Inherited: 0x28)
struct UPlatformInterfaceBase : UObject {
	struct TArray<struct FDelegateArray> AllDelegates; // 0x28(0x10)
};

// Class Engine.CloudStorageBase
// Size: 0x50 (Inherited: 0x38)
struct UCloudStorageBase : UPlatformInterfaceBase {
	struct TArray<struct FString> LocalCloudFiles; // 0x38(0x10)
	char bSuppressDelegateCalls : 1; // 0x48(0x01)
	char pad_48_1 : 7; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class Engine.ControlChannel
// Size: 0x80 (Inherited: 0x68)
struct UControlChannel : UChannel {
	struct UNetConnection* Connection; // 0x28(0x08)
	char pad_70[0x10]; // 0x70(0x10)
};

// Class Engine.DataStreamChannel
// Size: 0x2098 (Inherited: 0x68)
struct UDataStreamChannel : UChannel {
	struct UNetConnection* Connection; // 0x28(0x08)
	char pad_70[0x2028]; // 0x70(0x2028)
};

// Class Engine.DemoNetConnection
// Size: 0x3360 (Inherited: 0x3310)
struct UDemoNetConnection : UNetConnection {
	struct TArray<struct UChildConnection*> Children; // 0x48(0x10)
	struct UNetDriver* Driver; // 0x58(0x08)
	struct UPackageMap* PackageMapClass; // 0x60(0x08)
	struct UPackageMap* PackageMap; // 0x68(0x08)
	struct TArray<struct UChannel*> OpenChannels; // 0x70(0x10)
	struct TArray<struct AActor*> SentTemporaries; // 0x80(0x10)
	struct AActor* ViewTarget; // 0x90(0x08)
	struct AActor* OwningActor; // 0x98(0x08)
	int32_t MaxPacket; // 0xa0(0x04)
	char InternalAck : 1; // 0xa4(0x01)
	struct FUniqueNetIdRepl PlayerId; // 0x160(0x30)
	double LastReceiveTime; // 0x1d8(0x08)
	int32_t DefaultMaxChannelSize; // 0x13c0(0x04)
	struct TArray<struct UChannel*> ChannelsToTick; // 0x1648(0x10)
};

// Class Engine.PendingNetGame
// Size: 0xc0 (Inherited: 0x28)
struct UPendingNetGame : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct UNetDriver* NetDriver; // 0x30(0x08)
	struct UDemoNetDriver* DemoNetDriver; // 0x38(0x08)
	char pad_40[0x80]; // 0x40(0x80)
};

// Class Engine.DemoPendingNetGame
// Size: 0xc0 (Inherited: 0xc0)
struct UDemoPendingNetGame : UPendingNetGame {
	struct UNetDriver* NetDriver; // 0x30(0x08)
	struct UDemoNetDriver* DemoNetDriver; // 0x38(0x08)
};

// Class Engine.DeviceProfileFragment
// Size: 0x38 (Inherited: 0x28)
struct UDeviceProfileFragment : UObject {
	struct TArray<struct FString> CVars; // 0x28(0x10)
};

// Class Engine.DialogueSoundWaveProxy
// Size: 0x180 (Inherited: 0x168)
struct UDialogueSoundWaveProxy : USoundBase {
	struct USoundClass* SoundClassObject; // 0x30(0x08)
	char bDebug : 1; // 0x38(0x01)
	char bOverrideConcurrency : 1; // 0x38(0x01)
	char bEnableBusSends : 1; // 0x38(0x01)
	char bEnableBaseSubmix : 1; // 0x38(0x01)
	char bEnableSubmixSends : 1; // 0x38(0x01)
	char bHasDelayNode : 1; // 0x38(0x01)
	char bHasConcatenatorNode : 1; // 0x38(0x01)
	char bBypassVolumeScaleForPriority : 1; // 0x38(0x01)
	enum class EVirtualizationMode VirtualizationMode; // 0x39(0x01)
	struct TSet<struct USoundConcurrency*> ConcurrencySet; // 0x90(0x50)
	struct FSoundConcurrencySettings ConcurrencyOverrides; // 0xe0(0x20)
	float Duration; // 0x100(0x04)
	float MaxDistance; // 0x104(0x04)
	float TotalSamples; // 0x108(0x04)
	float Priority; // 0x10c(0x04)
	struct USoundAttenuation* AttenuationSettings; // 0x110(0x08)
	struct USoundSubmixBase* SoundSubmixObject; // 0x118(0x08)
	struct TArray<struct FSoundSubmixSendInfo> SoundSubmixSends; // 0x120(0x10)
	struct USoundEffectSourcePresetChain* SourceEffectChain; // 0x130(0x08)
	struct TArray<struct FSoundSourceBusSendInfo> BusSends; // 0x138(0x10)
	struct TArray<struct FSoundSourceBusSendInfo> PreEffectBusSends; // 0x148(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x158(0x10)
};

// Class Engine.Light
// Size: 0x2a0 (Inherited: 0x290)
struct ALight : AActor {
	struct ULightComponent* LightComponent; // 0x290(0x08)
	char bEnabled : 1; // 0x298(0x01)
	char pad_298_1 : 7; // 0x298(0x01)
	char pad_299[0x7]; // 0x299(0x07)

	void ToggleEnabled(); // Function Engine.Light.ToggleEnabled // (None) // @ game+0xffffc9bedf830041
};

// Class Engine.DirectionalLight
// Size: 0x2a0 (Inherited: 0x2a0)
struct ADirectionalLight : ALight {
	struct ULightComponent* LightComponent; // 0x290(0x08)
	char bEnabled : 1; // 0x298(0x01)
};

// Class Engine.Distribution
// Size: 0x30 (Inherited: 0x28)
struct UDistribution : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.DistributionFloat
// Size: 0x38 (Inherited: 0x30)
struct UDistributionFloat : UDistribution {
	char bCanBeBaked : 1; // 0x30(0x01)
	char pad_30_1 : 1; // 0x30(0x01)
	char bBakedDataSuccesfully : 1; // 0x30(0x01)
	char pad_30_3 : 5; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// Class Engine.DistributionFloatConstant
// Size: 0x40 (Inherited: 0x38)
struct UDistributionFloatConstant : UDistributionFloat {
	float Constant; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class Engine.DistributionFloatConstantCurve
// Size: 0x50 (Inherited: 0x38)
struct UDistributionFloatConstantCurve : UDistributionFloat {
	struct FInterpCurveFloat ConstantCurve; // 0x38(0x18)
};

// Class Engine.DistributionFloatParameterBase
// Size: 0x60 (Inherited: 0x40)
struct UDistributionFloatParameterBase : UDistributionFloatConstant {
	struct FName ParameterName; // 0x40(0x08)
	float MinInput; // 0x48(0x04)
	float MaxInput; // 0x4c(0x04)
	float MinOutput; // 0x50(0x04)
	float MaxOutput; // 0x54(0x04)
	enum class DistributionParamMode ParamMode; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
};

// Class Engine.DistributionFloatParticleParameter
// Size: 0x60 (Inherited: 0x60)
struct UDistributionFloatParticleParameter : UDistributionFloatParameterBase {
	struct FName ParameterName; // 0x40(0x08)
	float MinInput; // 0x48(0x04)
	float MaxInput; // 0x4c(0x04)
	float MinOutput; // 0x50(0x04)
	float MaxOutput; // 0x54(0x04)
	enum class DistributionParamMode ParamMode; // 0x58(0x01)
};

// Class Engine.DistributionFloatUniform
// Size: 0x40 (Inherited: 0x38)
struct UDistributionFloatUniform : UDistributionFloat {
	float Min; // 0x38(0x04)
	float Max; // 0x3c(0x04)
};

// Class Engine.DistributionFloatUniformCurve
// Size: 0x50 (Inherited: 0x38)
struct UDistributionFloatUniformCurve : UDistributionFloat {
	struct FInterpCurveVector2D ConstantCurve; // 0x38(0x18)
};

// Class Engine.DistributionVector
// Size: 0x38 (Inherited: 0x30)
struct UDistributionVector : UDistribution {
	char bCanBeBaked : 1; // 0x30(0x01)
	char bIsDirty : 1; // 0x30(0x01)
	char bBakedDataSuccesfully : 1; // 0x30(0x01)
	char pad_30_3 : 5; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// Class Engine.DistributionVectorConstant
// Size: 0x58 (Inherited: 0x38)
struct UDistributionVectorConstant : UDistributionVector {
	struct FVector Constant; // 0x38(0x18)
	char bLockAxes : 1; // 0x50(0x01)
	char pad_50_1 : 7; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	enum class EDistributionVectorLockFlags LockedAxes; // 0x54(0x01)
	char pad_55[0x3]; // 0x55(0x03)
};

// Class Engine.DistributionVectorConstantCurve
// Size: 0x58 (Inherited: 0x38)
struct UDistributionVectorConstantCurve : UDistributionVector {
	struct FInterpCurveVector ConstantCurve; // 0x38(0x18)
	char bLockAxes : 1; // 0x50(0x01)
	char pad_50_1 : 7; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	enum class EDistributionVectorLockFlags LockedAxes; // 0x54(0x01)
	char pad_55[0x3]; // 0x55(0x03)
};

// Class Engine.DistributionVectorParameterBase
// Size: 0xc8 (Inherited: 0x58)
struct UDistributionVectorParameterBase : UDistributionVectorConstant {
	struct FName ParameterName; // 0x58(0x08)
	struct FVector MinInput; // 0x60(0x18)
	struct FVector MaxInput; // 0x78(0x18)
	struct FVector MinOutput; // 0x90(0x18)
	struct FVector MaxOutput; // 0xa8(0x18)
	enum class DistributionParamMode ParamModes[0x3]; // 0xc0(0x03)
	char pad_C3[0x5]; // 0xc3(0x05)
};

// Class Engine.DistributionVectorParticleParameter
// Size: 0xc8 (Inherited: 0xc8)
struct UDistributionVectorParticleParameter : UDistributionVectorParameterBase {
	struct FName ParameterName; // 0x58(0x08)
	struct FVector MinInput; // 0x60(0x18)
	struct FVector MaxInput; // 0x78(0x18)
	struct FVector MinOutput; // 0x90(0x18)
	struct FVector MaxOutput; // 0xa8(0x18)
	enum class DistributionParamMode ParamModes[0x3]; // 0xc0(0x03)
};

// Class Engine.DistributionVectorUniform
// Size: 0x78 (Inherited: 0x38)
struct UDistributionVectorUniform : UDistributionVector {
	struct FVector Max; // 0x38(0x18)
	struct FVector Min; // 0x50(0x18)
	char bLockAxes : 1; // 0x68(0x01)
	char pad_68_1 : 7; // 0x68(0x01)
	char pad_69[0x3]; // 0x69(0x03)
	enum class EDistributionVectorLockFlags LockedAxes; // 0x6c(0x01)
	enum class EDistributionVectorMirrorFlags MirrorFlags[0x3]; // 0x6d(0x03)
	char bUseExtremes : 1; // 0x70(0x01)
	char pad_70_1 : 7; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class Engine.DistributionVectorUniformCurve
// Size: 0x60 (Inherited: 0x38)
struct UDistributionVectorUniformCurve : UDistributionVector {
	struct FInterpCurveTwoVectors ConstantCurve; // 0x38(0x18)
	char bLockAxes1 : 1; // 0x50(0x01)
	char bLockAxes2 : 1; // 0x50(0x01)
	char pad_50_2 : 6; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	enum class EDistributionVectorLockFlags LockedAxes[0x2]; // 0x54(0x02)
	enum class EDistributionVectorMirrorFlags MirrorFlags[0x3]; // 0x56(0x03)
	char pad_59[0x3]; // 0x59(0x03)
	char bUseExtremes : 1; // 0x5c(0x01)
	char pad_5C_1 : 7; // 0x5c(0x01)
	char pad_5D[0x3]; // 0x5d(0x03)
};

// Class Engine.GraphNodeContextMenuContext
// Size: 0x50 (Inherited: 0x28)
struct UGraphNodeContextMenuContext : UObject {
	struct UBlueprint* Blueprint; // 0x28(0x08)
	struct UEdGraph* Graph; // 0x30(0x08)
	struct UEdGraphNode* Node; // 0x38(0x08)
	char pad_40[0x8]; // 0x40(0x08)
	bool bIsDebugging; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class Engine.EdGraphPin_Deprecated
// Size: 0x118 (Inherited: 0x28)
struct UEdGraphPin_Deprecated : UObject {
	struct FString PinName; // 0x28(0x10)
	struct FString PinToolTip; // 0x38(0x10)
	enum class EEdGraphPinDirection Direction; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct FEdGraphPinType PinType; // 0x50(0x58)
	struct FString DefaultValue; // 0xa8(0x10)
	struct FString AutogeneratedDefaultValue; // 0xb8(0x10)
	struct UObject* DefaultObject; // 0xc8(0x08)
	struct FText DefaultTextValue; // 0xd0(0x18)
	struct TArray<struct UEdGraphPin_Deprecated*> LinkedTo; // 0xe8(0x10)
	struct TArray<struct UEdGraphPin_Deprecated*> SubPins; // 0xf8(0x10)
	struct UEdGraphPin_Deprecated* ParentPin; // 0x108(0x08)
	struct UEdGraphPin_Deprecated* ReferencePassThroughConnection; // 0x110(0x08)
};

// Class Engine.EdGraphSchema
// Size: 0x28 (Inherited: 0x28)
struct UEdGraphSchema : UObject {
};

// Class Engine.Emitter
// Size: 0x2e0 (Inherited: 0x290)
struct AEmitter : AActor {
	struct UParticleSystemComponent* ParticleSystemComponent; // 0x290(0x08)
	char bDestroyOnSystemFinish : 1; // 0x298(0x01)
	char bPostUpdateTickGroup : 1; // 0x298(0x01)
	char bCurrentlyActive : 1; // 0x298(0x01)
	char pad_298_3 : 5; // 0x298(0x01)
	char pad_299[0x7]; // 0x299(0x07)
	struct FMulticastInlineDelegate OnParticleSpawn; // 0x2a0(0x10)
	struct FMulticastInlineDelegate OnParticleBurst; // 0x2b0(0x10)
	struct FMulticastInlineDelegate OnParticleDeath; // 0x2c0(0x10)
	struct FMulticastInlineDelegate OnParticleCollide; // 0x2d0(0x10)

	void ToggleActive(); // Function Engine.Emitter.ToggleActive // (None) // @ game+0xffffc9cadf830041
};

// Class Engine.EmitterCameraLensEffectBase
// Size: 0x380 (Inherited: 0x2e0)
struct AEmitterCameraLensEffectBase : AEmitter {
	char pad_2E0[0x8]; // 0x2e0(0x08)
	struct UParticleSystem* PS_CameraEffect; // 0x2e8(0x08)
	struct APlayerCameraManager* BaseCamera; // 0x2f0(0x08)
	char pad_2F8[0x8]; // 0x2f8(0x08)
	struct FTransform RelativeTransform; // 0x300(0x60)
	float BaseFOV; // 0x360(0x04)
	char bAllowMultipleInstances : 1; // 0x364(0x01)
	char bResetWhenRetriggered : 1; // 0x364(0x01)
	char pad_364_2 : 6; // 0x364(0x01)
	char pad_365[0x3]; // 0x365(0x03)
	struct TArray<struct AActor*> EmittersToTreatAsSame; // 0x368(0x10)
	float DistFromCamera; // 0x378(0x04)
	char pad_37C[0x4]; // 0x37c(0x04)
};

// Class Engine.ViewModeUtils
// Size: 0x28 (Inherited: 0x28)
struct UViewModeUtils : UObject {
};

// Class Engine.EngineBaseTypes
// Size: 0x28 (Inherited: 0x28)
struct UEngineBaseTypes : UObject {
};

// Class Engine.EngineTypes
// Size: 0x28 (Inherited: 0x28)
struct UEngineTypes : UObject {
};

// Class Engine.ExponentialHeightFog
// Size: 0x2a0 (Inherited: 0x290)
struct AExponentialHeightFog : AInfo {
	struct UExponentialHeightFogComponent* Component; // 0x290(0x08)
	char bEnabled : 1; // 0x298(0x01)
	char pad_298_1 : 7; // 0x298(0x01)
	char pad_299[0x7]; // 0x299(0x07)

	void OnRep_bEnabled(); // Function Engine.ExponentialHeightFog.OnRep_bEnabled // (None) // @ game+0xffffc9cbdf830041
};

// Class Engine.ExponentialHeightFogComponent
// Size: 0x380 (Inherited: 0x2a0)
struct UExponentialHeightFogComponent : USceneComponent {
	float FogDensity; // 0x2a0(0x04)
	float FogHeightFalloff; // 0x2a4(0x04)
	struct FExponentialHeightFogData SecondFogData; // 0x2a8(0x0c)
	struct FLinearColor FogInscatteringColor; // 0x2b4(0x10)
	struct FLinearColor FogInscatteringLuminance; // 0x2c4(0x10)
	struct FLinearColor SkyAtmosphereAmbientContributionColorScale; // 0x2d4(0x10)
	char pad_2E4[0x4]; // 0x2e4(0x04)
	struct UTextureCube* InscatteringColorCubemap; // 0x2e8(0x08)
	float InscatteringColorCubemapAngle; // 0x2f0(0x04)
	struct FLinearColor InscatteringTextureTint; // 0x2f4(0x10)
	float FullyDirectionalInscatteringColorDistance; // 0x304(0x04)
	float NonDirectionalInscatteringColorDistance; // 0x308(0x04)
	float DirectionalInscatteringExponent; // 0x30c(0x04)
	float DirectionalInscatteringStartDistance; // 0x310(0x04)
	struct FLinearColor DirectionalInscatteringColor; // 0x314(0x10)
	struct FLinearColor DirectionalInscatteringLuminance; // 0x324(0x10)
	float FogMaxOpacity; // 0x334(0x04)
	float StartDistance; // 0x338(0x04)
	float FogCutoffDistance; // 0x33c(0x04)
	bool bEnableVolumetricFog; // 0x340(0x01)
	char pad_341[0x3]; // 0x341(0x03)
	float VolumetricFogScatteringDistribution; // 0x344(0x04)
	struct FColor VolumetricFogAlbedo; // 0x348(0x04)
	struct FLinearColor VolumetricFogEmissive; // 0x34c(0x10)
	float VolumetricFogExtinctionScale; // 0x35c(0x04)
	float VolumetricFogDistance; // 0x360(0x04)
	float VolumetricFogStartDistance; // 0x364(0x04)
	float VolumetricFogNearFadeInDistance; // 0x368(0x04)
	float VolumetricFogStaticLightingScatteringIntensity; // 0x36c(0x04)
	bool bOverrideLightColorsWithFogInscatteringColors; // 0x370(0x01)
	char pad_371[0xf]; // 0x371(0x0f)

	void SetVolumetricFogScatteringDistribution(float NewValue); // Function Engine.ExponentialHeightFogComponent.SetVolumetricFogScatteringDistribution // (None) // @ game+0xffff8009df830000
};

// Class Engine.FontImportOptions
// Size: 0xd8 (Inherited: 0x28)
struct UFontImportOptions : UObject {
	struct FFontImportOptionsData Data; // 0x28(0xb0)
};

// Class Engine.ForceFeedbackAttenuation
// Size: 0xe8 (Inherited: 0x28)
struct UForceFeedbackAttenuation : UObject {
	struct FForceFeedbackAttenuationSettings Attenuation; // 0x28(0xc0)
};

// Class Engine.GameNetworkManager
// Size: 0x338 (Inherited: 0x290)
struct AGameNetworkManager : AInfo {
	float BadPacketLossThreshold; // 0x290(0x04)
	float SeverePacketLossThreshold; // 0x294(0x04)
	int32_t BadPingThreshold; // 0x298(0x04)
	int32_t SeverePingThreshold; // 0x29c(0x04)
	int32_t AdjustedNetSpeed; // 0x2a0(0x04)
	float LastNetSpeedUpdateTime; // 0x2a4(0x04)
	int32_t TotalNetBandwidth; // 0x2a8(0x04)
	int32_t MinDynamicBandwidth; // 0x2ac(0x04)
	int32_t MaxDynamicBandwidth; // 0x2b0(0x04)
	char bIsStandbyCheckingEnabled : 1; // 0x2b4(0x01)
	char bHasStandbyCheatTriggered : 1; // 0x2b4(0x01)
	char pad_2B4_2 : 6; // 0x2b4(0x01)
	char pad_2B5[0x3]; // 0x2b5(0x03)
	float StandbyRxCheatTime; // 0x2b8(0x04)
	float StandbyTxCheatTime; // 0x2bc(0x04)
	float PercentMissingForRxStandby; // 0x2c0(0x04)
	float PercentMissingForTxStandby; // 0x2c4(0x04)
	float PercentForBadPing; // 0x2c8(0x04)
	float JoinInProgressStandbyWaitTime; // 0x2cc(0x04)
	float MoveRepSize; // 0x2d0(0x04)
	float MAXPOSITIONERRORSQUARED; // 0x2d4(0x04)
	float MAXNEARZEROVELOCITYSQUARED; // 0x2d8(0x04)
	float CLIENTADJUSTUPDATECOST; // 0x2dc(0x04)
	float MAXCLIENTUPDATEINTERVAL; // 0x2e0(0x04)
	float MaxClientForcedUpdateDuration; // 0x2e4(0x04)
	float ServerForcedUpdateHitchThreshold; // 0x2e8(0x04)
	float ServerForcedUpdateHitchCooldown; // 0x2ec(0x04)
	float MaxMoveDeltaTime; // 0x2f0(0x04)
	float MaxClientSmoothingDeltaTime; // 0x2f4(0x04)
	float ClientNetSendMoveDeltaTime; // 0x2f8(0x04)
	float ClientNetSendMoveDeltaTimeThrottled; // 0x2fc(0x04)
	float ClientNetSendMoveDeltaTimeStationary; // 0x300(0x04)
	int32_t ClientNetSendMoveThrottleAtNetSpeed; // 0x304(0x04)
	int32_t ClientNetSendMoveThrottleOverPlayerCount; // 0x308(0x04)
	float ClientErrorUpdateRateLimit; // 0x30c(0x04)
	float ClientNetCamUpdateDeltaTime; // 0x310(0x04)
	float ClientNetCamUpdatePositionLimit; // 0x314(0x04)
	bool ClientAuthorativePosition; // 0x318(0x01)
	bool bMovementTimeDiscrepancyDetection; // 0x319(0x01)
	bool bMovementTimeDiscrepancyResolution; // 0x31a(0x01)
	char pad_31B[0x1]; // 0x31b(0x01)
	float MovementTimeDiscrepancyMaxTimeMargin; // 0x31c(0x04)
	float MovementTimeDiscrepancyMinTimeMargin; // 0x320(0x04)
	float MovementTimeDiscrepancyResolutionRate; // 0x324(0x04)
	float MovementTimeDiscrepancyDriftAllowance; // 0x328(0x04)
	bool bMovementTimeDiscrepancyForceCorrectionsDuringResolution; // 0x32c(0x01)
	bool bUseDistanceBasedRelevancy; // 0x32d(0x01)
	char pad_32E[0xa]; // 0x32e(0x0a)
};

// Class Engine.SpotLight
// Size: 0x2a8 (Inherited: 0x2a0)
struct ASpotLight : ALight {
	struct USpotLightComponent* SpotLightComponent; // 0x2a0(0x08)

	void SetOuterConeAngle(float NewOuterConeAngle); // Function Engine.SpotLight.SetOuterConeAngle // (None) // @ game+0xffffc9e5df830041
};

// Class Engine.GeneratedMeshAreaLight
// Size: 0x2a8 (Inherited: 0x2a8)
struct AGeneratedMeshAreaLight : ASpotLight {
	struct USpotLightComponent* SpotLightComponent; // 0x2a0(0x08)
};

// Class Engine.HapticFeedbackEffect_Base
// Size: 0x28 (Inherited: 0x28)
struct UHapticFeedbackEffect_Base : UObject {
};

// Class Engine.HapticFeedbackEffect_Buffer
// Size: 0x40 (Inherited: 0x28)
struct UHapticFeedbackEffect_Buffer : UHapticFeedbackEffect_Base {
	struct TArray<char> Amplitudes; // 0x28(0x10)
	int32_t SampleRate; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class Engine.HapticFeedbackEffect_Curve
// Size: 0x138 (Inherited: 0x28)
struct UHapticFeedbackEffect_Curve : UHapticFeedbackEffect_Base {
	struct FHapticFeedbackDetails_Curve HapticDetails; // 0x28(0x110)
};

// Class Engine.HapticFeedbackEffect_SoundWave
// Size: 0x48 (Inherited: 0x28)
struct UHapticFeedbackEffect_SoundWave : UHapticFeedbackEffect_Base {
	struct USoundWave* SoundWave; // 0x28(0x08)
	bool bUseStereo; // 0x30(0x01)
	char pad_31[0x17]; // 0x31(0x17)
};

// Class Engine.AnimationDataController
// Size: 0x28 (Inherited: 0x28)
struct UAnimationDataController : UInterface {

	void UpdateCurveNamesFromSkeleton(struct USkeleton* Skeleton, enum class ERawCurveTrackTypes SupportedCurveType, bool bShouldTransact); // Function Engine.AnimationDataController.UpdateCurveNamesFromSkeleton // (None) // @ game+0xffffca09df830041
};

// Class Engine.InGameAdManager
// Size: 0x60 (Inherited: 0x38)
struct UInGameAdManager : UPlatformInterfaceBase {
	char bShouldPauseWhileAdOpen : 1; // 0x38(0x01)
	char pad_38_1 : 7; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct TArray<struct FDelegate> ClickedBannerDelegates; // 0x40(0x10)
	struct TArray<struct FDelegate> ClosedAdDelegates; // 0x50(0x10)
};

// Class Engine.Interface_ActorSubobject
// Size: 0x28 (Inherited: 0x28)
struct UInterface_ActorSubobject : UInterface {
};

// Class Engine.Interface_AssetUserData
// Size: 0x28 (Inherited: 0x28)
struct UInterface_AssetUserData : UInterface {
};

// Class Engine.Interface_AsyncCompilation
// Size: 0x28 (Inherited: 0x28)
struct UInterface_AsyncCompilation : UInterface {
};

// Class Engine.BoneReferenceSkeletonProvider
// Size: 0x28 (Inherited: 0x28)
struct UBoneReferenceSkeletonProvider : UInterface {
};

// Class Engine.Interface_CollisionDataProvider
// Size: 0x28 (Inherited: 0x28)
struct UInterface_CollisionDataProvider : UInterface {
};

// Class Engine.Interface_PostProcessVolume
// Size: 0x28 (Inherited: 0x28)
struct UInterface_PostProcessVolume : UInterface {
};

// Class Engine.Interface_PreviewMeshProvider
// Size: 0x28 (Inherited: 0x28)
struct UInterface_PreviewMeshProvider : UInterface {
};

// Class Engine.ISMPartitionInstanceManager
// Size: 0x28 (Inherited: 0x28)
struct UISMPartitionInstanceManager : UInterface {
};

// Class Engine.ISMPartitionInstanceManagerProvider
// Size: 0x28 (Inherited: 0x28)
struct UISMPartitionInstanceManagerProvider : UInterface {
};

// Class Engine.KismetTextLibrary
// Size: 0x28 (Inherited: 0x28)
struct UKismetTextLibrary : UBlueprintFunctionLibrary {

	struct FText TextTrimTrailing(struct FText& InText); // Function Engine.KismetTextLibrary.TextTrimTrailing // (None) // @ game+0xffffca36df830041
};

// Class Engine.LevelInstanceEditorPivotInterface
// Size: 0x28 (Inherited: 0x28)
struct ULevelInstanceEditorPivotInterface : UInterface {
};

// Class Engine.LevelStreaming
// Size: 0x1b0 (Inherited: 0x28)
struct ULevelStreaming : UObject {
	struct TSoftObjectPtr<UWorld> WorldAsset; // 0x28(0x30)
	int32_t StreamingPriority; // 0x58(0x04)
	struct FName PackageNameToLoad; // 0x5c(0x08)
	char pad_64[0x4]; // 0x64(0x04)
	struct TArray<struct FName> LODPackageNames; // 0x68(0x10)
	char pad_78[0x18]; // 0x78(0x18)
	struct FTransform LevelTransform; // 0x90(0x60)
	bool bClientOnlyVisible; // 0xf0(0x01)
	char pad_F1[0x3]; // 0xf1(0x03)
	int32_t LevelLODIndex; // 0xf4(0x04)
	char pad_F8_0 : 3; // 0xf8(0x01)
	char bShouldBeVisible : 1; // 0xf8(0x01)
	char bShouldBeLoaded : 1; // 0xf8(0x01)
	char pad_F8_5 : 3; // 0xf8(0x01)
	char pad_F9[0x2]; // 0xf9(0x02)
	char bLocked : 1; // 0xfb(0x01)
	char bIsStatic : 1; // 0xfb(0x01)
	char bShouldBlockOnLoad : 1; // 0xfb(0x01)
	char bShouldBlockOnUnload : 1; // 0xfb(0x01)
	char bDisableDistanceStreaming : 1; // 0xfb(0x01)
	char bDrawOnLevelStatusMap : 1; // 0xfb(0x01)
	char pad_FB_6 : 2; // 0xfb(0x01)
	struct FLinearColor LevelColor; // 0xfc(0x10)
	char pad_10C[0x4]; // 0x10c(0x04)
	struct TArray<struct ALevelStreamingVolume*> EditorStreamingVolumes; // 0x110(0x10)
	float MinTimeBetweenVolumeUnloadRequests; // 0x120(0x04)
	char pad_124[0x4]; // 0x124(0x04)
	struct FMulticastInlineDelegate OnLevelLoaded; // 0x128(0x10)
	struct FMulticastInlineDelegate OnLevelUnloaded; // 0x138(0x10)
	struct FMulticastInlineDelegate OnLevelShown; // 0x148(0x10)
	struct FMulticastInlineDelegate OnLevelHidden; // 0x158(0x10)
	struct ULevel* LoadedLevel; // 0x168(0x08)
	struct ULevel* PendingUnloadLevel; // 0x170(0x08)
	char pad_178[0x38]; // 0x178(0x38)

	bool ShouldBeLoaded(); // Function Engine.LevelStreaming.ShouldBeLoaded // (None) // @ game+0xffffca44df830041
};

// Class Engine.LevelStreamingAlwaysLoaded
// Size: 0x1b0 (Inherited: 0x1b0)
struct ULevelStreamingAlwaysLoaded : ULevelStreaming {
	struct TSoftObjectPtr<UWorld> WorldAsset; // 0x28(0x30)
	int32_t StreamingPriority; // 0x58(0x04)
	struct FName PackageNameToLoad; // 0x5c(0x08)
	struct TArray<struct FName> LODPackageNames; // 0x68(0x10)
	struct FTransform LevelTransform; // 0x90(0x60)
	bool bClientOnlyVisible; // 0xf0(0x01)
	int32_t LevelLODIndex; // 0xf4(0x04)
	char pad_261_0 : 3; // 0x261(0x01)
	char bShouldBeVisible : 1; // 0xf8(0x01)
	char bShouldBeLoaded : 1; // 0xf8(0x01)
	char bLocked : 1; // 0xfb(0x01)
	char bIsStatic : 1; // 0xfb(0x01)
	char bShouldBlockOnLoad : 1; // 0xfb(0x01)
	char pad_262_0 : 3; // 0x262(0x01)
	char bShouldBlockOnUnload : 1; // 0xfb(0x01)
	char bDisableDistanceStreaming : 1; // 0xfb(0x01)
	char bDrawOnLevelStatusMap : 1; // 0xfb(0x01)
	struct FLinearColor LevelColor; // 0xfc(0x10)
	struct TArray<struct ALevelStreamingVolume*> EditorStreamingVolumes; // 0x110(0x10)
	float MinTimeBetweenVolumeUnloadRequests; // 0x120(0x04)
	struct FMulticastInlineDelegate OnLevelLoaded; // 0x128(0x10)
	struct FMulticastInlineDelegate OnLevelUnloaded; // 0x138(0x10)
	struct FMulticastInlineDelegate OnLevelShown; // 0x148(0x10)
	struct FMulticastInlineDelegate OnLevelHidden; // 0x158(0x10)
	struct ULevel* LoadedLevel; // 0x168(0x08)
	struct ULevel* PendingUnloadLevel; // 0x170(0x08)
};

// Class Engine.LevelStreamingDynamic
// Size: 0x1b0 (Inherited: 0x1b0)
struct ULevelStreamingDynamic : ULevelStreaming {
	char bInitiallyLoaded : 1; // 0x1a8(0x01)
	char bInitiallyVisible : 1; // 0x1a8(0x01)

	struct ULevelStreamingDynamic* LoadLevelInstanceBySoftObjectPtr(struct UObject* WorldContextObject, struct TSoftObjectPtr<UWorld> Level, struct FVector Location, struct FRotator Rotation, bool& bOutSuccess, struct FString OptionalLevelNameOverride, struct ULevelStreamingDynamic* OptionalLevelStreamingClass, bool bLoadAsTempPackage); // Function Engine.LevelStreamingDynamic.LoadLevelInstanceBySoftObjectPtr // (None) // @ game+0xffffca46df830041
};

// Class Engine.LevelStreamingPersistent
// Size: 0x1b0 (Inherited: 0x1b0)
struct ULevelStreamingPersistent : ULevelStreaming {
	struct TSoftObjectPtr<UWorld> WorldAsset; // 0x28(0x30)
	int32_t StreamingPriority; // 0x58(0x04)
	struct FName PackageNameToLoad; // 0x5c(0x08)
	struct TArray<struct FName> LODPackageNames; // 0x68(0x10)
	struct FTransform LevelTransform; // 0x90(0x60)
	bool bClientOnlyVisible; // 0xf0(0x01)
	int32_t LevelLODIndex; // 0xf4(0x04)
	char pad_261_0 : 3; // 0x261(0x01)
	char bShouldBeVisible : 1; // 0xf8(0x01)
	char bShouldBeLoaded : 1; // 0xf8(0x01)
	char bLocked : 1; // 0xfb(0x01)
	char bIsStatic : 1; // 0xfb(0x01)
	char bShouldBlockOnLoad : 1; // 0xfb(0x01)
	char pad_262_0 : 3; // 0x262(0x01)
	char bShouldBlockOnUnload : 1; // 0xfb(0x01)
	char bDisableDistanceStreaming : 1; // 0xfb(0x01)
	char bDrawOnLevelStatusMap : 1; // 0xfb(0x01)
	struct FLinearColor LevelColor; // 0xfc(0x10)
	struct TArray<struct ALevelStreamingVolume*> EditorStreamingVolumes; // 0x110(0x10)
	float MinTimeBetweenVolumeUnloadRequests; // 0x120(0x04)
	struct FMulticastInlineDelegate OnLevelLoaded; // 0x128(0x10)
	struct FMulticastInlineDelegate OnLevelUnloaded; // 0x138(0x10)
	struct FMulticastInlineDelegate OnLevelShown; // 0x148(0x10)
	struct FMulticastInlineDelegate OnLevelHidden; // 0x158(0x10)
	struct ULevel* LoadedLevel; // 0x168(0x08)
	struct ULevel* PendingUnloadLevel; // 0x170(0x08)
};

// Class Engine.LevelStreamingVolume
// Size: 0x2e0 (Inherited: 0x2c8)
struct ALevelStreamingVolume : AVolume {
	struct TArray<struct FName> StreamingLevelNames; // 0x2c8(0x10)
	char bEditorPreVisOnly : 1; // 0x2d8(0x01)
	char bDisabled : 1; // 0x2d8(0x01)
	char pad_2D8_2 : 6; // 0x2d8(0x01)
	char pad_2D9[0x3]; // 0x2d9(0x03)
	enum class EStreamingVolumeUsage StreamingUsage; // 0x2dc(0x01)
	char pad_2DD[0x3]; // 0x2dd(0x03)
};

// Class Engine.LightComponentBase
// Size: 0x2e0 (Inherited: 0x2a0)
struct ULightComponentBase : USceneComponent {
	struct FGuid LightGuid; // 0x2a0(0x10)
	float Brightness; // 0x2b0(0x04)
	float Intensity; // 0x2b4(0x04)
	struct FColor LightColor; // 0x2b8(0x04)
	char bAffectsWorld : 1; // 0x2bc(0x01)
	char CastShadows : 1; // 0x2bc(0x01)
	char CastStaticShadows : 1; // 0x2bc(0x01)
	char CastDynamicShadows : 1; // 0x2bc(0x01)
	char bAffectTranslucentLighting : 1; // 0x2bc(0x01)
	char bTransmission : 1; // 0x2bc(0x01)
	char bCastVolumetricShadow : 1; // 0x2bc(0x01)
	char bCastDeepShadow : 1; // 0x2bc(0x01)
	char bCastRaytracedShadow : 1; // 0x2bd(0x01)
	char pad_2BD_1 : 7; // 0x2bd(0x01)
	char pad_2BE[0x2]; // 0x2be(0x02)
	enum class ECastRayTracedShadow CastRaytracedShadow; // 0x2c0(0x01)
	char pad_2C1[0x3]; // 0x2c1(0x03)
	char bAffectReflection : 1; // 0x2c4(0x01)
	char bAffectGlobalIllumination : 1; // 0x2c4(0x01)
	char pad_2C4_2 : 6; // 0x2c4(0x01)
	char pad_2C5[0x3]; // 0x2c5(0x03)
	float DeepShadowLayerDistribution; // 0x2c8(0x04)
	float IndirectLightingIntensity; // 0x2cc(0x04)
	float VolumetricScatteringIntensity; // 0x2d0(0x04)
	int32_t SamplesPerPixel; // 0x2d4(0x04)
	char pad_2D8[0x8]; // 0x2d8(0x08)

	void SetSamplesPerPixel(int32_t NewValue); // Function Engine.LightComponentBase.SetSamplesPerPixel // (None) // @ game+0xffffca4fdf830041
};

// Class Engine.Texture2D
// Size: 0x2b0 (Inherited: 0x1f0)
struct UTexture2D : UTexture {
	int32_t FirstResourceMemMip; // 0x1f0(0x04)
	char bTemporarilyDisableStreaming : 1; // 0x1f4(0x01)
	char pad_1F4_1 : 7; // 0x1f4(0x01)
	enum class TextureAddress AddressX; // 0x1f5(0x01)
	enum class TextureAddress AddressY; // 0x1f6(0x01)
	char pad_1F7[0x1]; // 0x1f7(0x01)
	struct FIntPoint ImportedSize; // 0x1f8(0x08)
	char pad_200[0xb0]; // 0x200(0xb0)

	int32_t Blueprint_GetSizeY(); // Function Engine.Texture2D.Blueprint_GetSizeY // (None) // @ game+0xffffca51df830041
};

// Class Engine.LightMapTexture2D
// Size: 0x2b0 (Inherited: 0x2b0)
struct ULightMapTexture2D : UTexture2D {
	int32_t FirstResourceMemMip; // 0x1f0(0x04)
	char bTemporarilyDisableStreaming : 1; // 0x1f4(0x01)
	enum class TextureAddress AddressX; // 0x1f5(0x01)
	enum class TextureAddress AddressY; // 0x1f6(0x01)
	struct FIntPoint ImportedSize; // 0x1f8(0x08)
};

// Class Engine.LightmassPortal
// Size: 0x298 (Inherited: 0x290)
struct ALightmassPortal : AActor {
	struct ULightmassPortalComponent* PortalComponent; // 0x290(0x08)
};

// Class Engine.LightmassPortalComponent
// Size: 0x2b0 (Inherited: 0x2a0)
struct ULightmassPortalComponent : USceneComponent {
	struct UBoxComponent* PreviewBox; // 0x2a0(0x08)
	char pad_2A8[0x8]; // 0x2a8(0x08)
};

// Class Engine.MapBuildDataRegistry
// Size: 0x238 (Inherited: 0x28)
struct UMapBuildDataRegistry : UObject {
	enum class ELightingBuildQuality LevelLightingQuality; // 0x28(0x01)
	char pad_29[0x20f]; // 0x29(0x20f)
};

// Class Engine.MaterialInterfaceEditorOnlyData
// Size: 0x40 (Inherited: 0x28)
struct UMaterialInterfaceEditorOnlyData : UObject {
	char pad_28[0x18]; // 0x28(0x18)
};

// Class Engine.MaterialEditorOnlyData
// Size: 0x618 (Inherited: 0x40)
struct UMaterialEditorOnlyData : UMaterialInterfaceEditorOnlyData {
	struct FColorMaterialInput BaseColor; // 0x40(0x30)
	struct FScalarMaterialInput Metallic; // 0x70(0x30)
	struct FScalarMaterialInput Specular; // 0xa0(0x30)
	struct FScalarMaterialInput Roughness; // 0xd0(0x30)
	struct FScalarMaterialInput Anisotropy; // 0x100(0x30)
	struct FVectorMaterialInput Normal; // 0x130(0x38)
	struct FVectorMaterialInput Tangent; // 0x168(0x38)
	struct FColorMaterialInput EmissiveColor; // 0x1a0(0x30)
	struct FScalarMaterialInput Opacity; // 0x1d0(0x30)
	struct FScalarMaterialInput OpacityMask; // 0x200(0x30)
	struct FVectorMaterialInput WorldPositionOffset; // 0x230(0x38)
	struct FColorMaterialInput SubsurfaceColor; // 0x268(0x30)
	struct FScalarMaterialInput ClearCoat; // 0x298(0x30)
	struct FScalarMaterialInput ClearCoatRoughness; // 0x2c8(0x30)
	struct FScalarMaterialInput AmbientOcclusion; // 0x2f8(0x30)
	struct FScalarMaterialInput Refraction; // 0x328(0x30)
	struct FVector2MaterialInput CustomizedUVs[0x8]; // 0x358(0x1c0)
	struct FMaterialAttributesInput MaterialAttributes; // 0x518(0x30)
	struct FScalarMaterialInput PixelDepthOffset; // 0x548(0x30)
	struct FShadingModelMaterialInput ShadingModelFromMaterialExpression; // 0x578(0x28)
	char pad_5A0[0x8]; // 0x5a0(0x08)
	struct FStrataMaterialInput FrontMaterial; // 0x5a8(0x28)
	char pad_5D0[0x8]; // 0x5d0(0x08)
	struct FMaterialExpressionCollection ExpressionCollection; // 0x5d8(0x30)
	struct TArray<struct FParameterGroupData> ParameterGroupData; // 0x608(0x10)
};

// Class Engine.Material
// Size: 0x1f0 (Inherited: 0x98)
struct UMaterial : UMaterialInterface {
	struct UPhysicalMaterial* PhysMaterial; // 0x98(0x08)
	struct UPhysicalMaterialMask* PhysMaterialMask; // 0xa0(0x08)
	struct UPhysicalMaterial* PhysicalMaterialMap[0x8]; // 0xa8(0x40)
	struct TArray<struct UPhysicalMaterial*> RenderTracePhysicalMaterialOutputs; // 0xe8(0x10)
	enum class EMaterialDomain MaterialDomain; // 0xf8(0x01)
	enum class EBlendMode BlendMode; // 0xf9(0x01)
	enum class EStrataBlendMode StrataBlendMode; // 0xfa(0x01)
	enum class EDecalBlendMode DecalBlendMode; // 0xfb(0x01)
	enum class EMaterialDecalResponse MaterialDecalResponse; // 0xfc(0x01)
	char pad_FD[0x3]; // 0xfd(0x03)
	struct FMaterialOverrideNanite NaniteOverrideMaterial; // 0x100(0x40)
	uint32_t CachedConnectedInputs; // 0x140(0x04)
	enum class EMaterialShadingModel ShadingModel; // 0x144(0x01)
	char bCastDynamicShadowAsMasked : 1; // 0x145(0x01)
	char pad_145_1 : 7; // 0x145(0x01)
	struct FMaterialShadingModelField ShadingModels; // 0x146(0x02)
	float OpacityMaskClipValue; // 0x148(0x04)
	char bEnableSeparateTranslucency : 1; // 0x14c(0x01)
	char bEnableResponsiveAA : 1; // 0x14c(0x01)
	char bScreenSpaceReflections : 1; // 0x14c(0x01)
	char bContactShadows : 1; // 0x14c(0x01)
	char TwoSided : 1; // 0x14c(0x01)
	char DitheredLODTransition : 1; // 0x14c(0x01)
	char DitherOpacityMask : 1; // 0x14c(0x01)
	char bAllowNegativeEmissiveColor : 1; // 0x14c(0x01)
	enum class EMaterialTranslucencyPass TranslucencyPass; // 0x14d(0x01)
	enum class ETranslucencyLightingMode TranslucencyLightingMode; // 0x14e(0x01)
	char bEnableMobileSeparateTranslucency : 1; // 0x14f(0x01)
	char pad_14F_1 : 7; // 0x14f(0x01)
	int32_t NumCustomizedUVs; // 0x150(0x04)
	float TranslucencyDirectionalLightingIntensity; // 0x154(0x04)
	float TranslucentShadowDensityScale; // 0x158(0x04)
	float TranslucentSelfShadowDensityScale; // 0x15c(0x04)
	float TranslucentSelfShadowSecondDensityScale; // 0x160(0x04)
	float TranslucentSelfShadowSecondOpacity; // 0x164(0x04)
	float TranslucentBackscatteringExponent; // 0x168(0x04)
	struct FLinearColor TranslucentMultipleScatteringExtinction; // 0x16c(0x10)
	float TranslucentShadowStartOffset; // 0x17c(0x04)
	char bDisableDepthTest : 1; // 0x180(0x01)
	char bWriteOnlyAlpha : 1; // 0x180(0x01)
	char bGenerateSphericalParticleNormals : 1; // 0x180(0x01)
	char bTangentSpaceNormal : 1; // 0x180(0x01)
	char bUseEmissiveForDynamicAreaLighting : 1; // 0x180(0x01)
	char bUsedAsSpecialEngineMaterial : 1; // 0x180(0x01)
	char bUsedWithSkeletalMesh : 1; // 0x180(0x01)
	char bUsedWithEditorCompositing : 1; // 0x180(0x01)
	char bUsedWithParticleSprites : 1; // 0x181(0x01)
	char bUsedWithBeamTrails : 1; // 0x181(0x01)
	char bUsedWithMeshParticles : 1; // 0x181(0x01)
	char bUsedWithNiagaraSprites : 1; // 0x181(0x01)
	char bUsedWithNiagaraRibbons : 1; // 0x181(0x01)
	char bUsedWithNiagaraMeshParticles : 1; // 0x181(0x01)
	char bUsedWithGeometryCache : 1; // 0x181(0x01)
	char bUsedWithStaticLighting : 1; // 0x181(0x01)
	char bUsedWithMorphTargets : 1; // 0x182(0x01)
	char bUsedWithSplineMeshes : 1; // 0x182(0x01)
	char bUsedWithInstancedStaticMeshes : 1; // 0x182(0x01)
	char bUsedWithGeometryCollections : 1; // 0x182(0x01)
	char bUsesDistortion : 1; // 0x182(0x01)
	char bUsedWithClothing : 1; // 0x182(0x01)
	char pad_182_6 : 2; // 0x182(0x01)
	char pad_183[0x1]; // 0x183(0x01)
	char bUsedWithWater : 1; // 0x184(0x01)
	char bUsedWithHairStrands : 1; // 0x184(0x01)
	char bUsedWithLidarPointCloud : 1; // 0x184(0x01)
	char bUsedWithVirtualHeightfieldMesh : 1; // 0x184(0x01)
	char bUsedWithNanite : 1; // 0x184(0x01)
	char pad_184_5 : 3; // 0x184(0x01)
	char pad_185[0x3]; // 0x185(0x03)
	char bUsedWithUI : 1; // 0x188(0x01)
	char bAutomaticallySetUsageInEditor : 1; // 0x188(0x01)
	char bFullyRough : 1; // 0x188(0x01)
	char bUseFullPrecision : 1; // 0x188(0x01)
	char pad_188_4 : 4; // 0x188(0x01)
	enum class EMaterialFloatPrecisionMode FloatPrecisionMode; // 0x189(0x01)
	char bUseLightmapDirectionality : 1; // 0x18a(0x01)
	char bMobileEnableHighQualityBRDF : 1; // 0x18a(0x01)
	char bUseAlphaToCoverage : 1; // 0x18a(0x01)
	char pad_18A_3 : 5; // 0x18a(0x01)
	char pad_18B[0x1]; // 0x18b(0x01)
	char bForwardRenderUsePreintegratedGFForSimpleIBL : 1; // 0x18c(0x01)
	char pad_18C_1 : 7; // 0x18c(0x01)
	char pad_18D[0x3]; // 0x18d(0x03)
	char bUseHQForwardReflections : 1; // 0x190(0x01)
	char bForwardBlendsSkyLightCubemaps : 1; // 0x190(0x01)
	char bUsePlanarForwardReflections : 1; // 0x190(0x01)
	char bNormalCurvatureToRoughness : 1; // 0x190(0x01)
	char AllowTranslucentCustomDepthWrites : 1; // 0x190(0x01)
	char Wireframe : 1; // 0x190(0x01)
	char pad_190_6 : 2; // 0x190(0x01)
	enum class EMaterialShadingRate ShadingRate; // 0x191(0x01)
	char bCanMaskedBeAssumedOpaque : 1; // 0x192(0x01)
	char bIsMasked : 1; // 0x192(0x01)
	char bIsPreviewMaterial : 1; // 0x192(0x01)
	char bIsFunctionPreviewMaterial : 1; // 0x192(0x01)
	char bUseMaterialAttributes : 1; // 0x192(0x01)
	char bEnableExecWire : 1; // 0x192(0x01)
	char bEnableNewHLSLGenerator : 1; // 0x192(0x01)
	char bCastRayTracedShadows : 1; // 0x192(0x01)
	char bUseTranslucencyVertexFog : 1; // 0x193(0x01)
	char bApplyCloudFogging : 1; // 0x193(0x01)
	char bIsSky : 1; // 0x193(0x01)
	char bComputeFogPerPixel : 1; // 0x193(0x01)
	char bOutputTranslucentVelocity : 1; // 0x193(0x01)
	char bAllowDevelopmentShaderCompile : 1; // 0x193(0x01)
	char bIsMaterialEditorStatsMaterial : 1; // 0x193(0x01)
	char pad_193_7 : 1; // 0x193(0x01)
	enum class EBlendableLocation BlendableLocation; // 0x194(0x01)
	char BlendableOutputAlpha : 1; // 0x195(0x01)
	char bEnableStencilTest : 1; // 0x195(0x01)
	char pad_195_2 : 6; // 0x195(0x01)
	enum class EMaterialStencilCompare StencilCompare; // 0x196(0x01)
	char StencilRefValue; // 0x197(0x01)
	enum class ERefractionMode RefractionMode; // 0x198(0x01)
	char pad_199[0x3]; // 0x199(0x03)
	int32_t BlendablePriority; // 0x19c(0x04)
	char bIsBlendable : 1; // 0x1a0(0x01)
	char pad_1A0_1 : 7; // 0x1a0(0x01)
	char pad_1A1[0x3]; // 0x1a1(0x03)
	uint32_t UsageFlagWarnings; // 0x1a4(0x04)
	float RefractionDepthBias; // 0x1a8(0x04)
	struct FGuid StateId; // 0x1ac(0x10)
	char pad_1BC[0x34]; // 0x1bc(0x34)
};

// Class Engine.MaterialExpressionAbs
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionAbs : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionAbsorptionMediumMaterialOutput
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionAbsorptionMediumMaterialOutput : UMaterialExpressionCustomOutput {
	struct FExpressionInput TransmittanceColor; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionActorPositionWS
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionActorPositionWS : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionAdd
// Size: 0x108 (Inherited: 0xb0)
struct UMaterialExpressionAdd : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	float ConstA; // 0x100(0x04)
	float ConstB; // 0x104(0x04)
};

// Class Engine.MaterialExpressionAntialiasedTextureMask
// Size: 0x248 (Inherited: 0x240)
struct UMaterialExpressionAntialiasedTextureMask : UMaterialExpressionTextureSampleParameter2D {
	float Threshold; // 0x240(0x04)
	enum class ETextureColorChannel Channel; // 0x244(0x01)
	char pad_245[0x3]; // 0x245(0x03)
};

// Class Engine.MaterialExpressionAppendVector
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionAppendVector : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionArccosine
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionArccosine : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionArccosineFast
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionArccosineFast : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionArcsine
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionArcsine : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionArcsineFast
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionArcsineFast : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionArctangent
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionArctangent : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionArctangent2
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionArctangent2 : UMaterialExpression {
	struct FExpressionInput Y; // 0xb0(0x28)
	struct FExpressionInput X; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionArctangent2Fast
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionArctangent2Fast : UMaterialExpression {
	struct FExpressionInput Y; // 0xb0(0x28)
	struct FExpressionInput X; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionArctangentFast
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionArctangentFast : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionAtmosphericFogColor
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionAtmosphericFogColor : UMaterialExpression {
	struct FExpressionInput WorldPosition; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionAtmosphericLightColor
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionAtmosphericLightColor : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionAtmosphericLightVector
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionAtmosphericLightVector : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionBentNormalCustomOutput
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionBentNormalCustomOutput : UMaterialExpressionCustomOutput {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionBinaryOp
// Size: 0x108 (Inherited: 0xb0)
struct UMaterialExpressionBinaryOp : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	float ConstA; // 0x100(0x04)
	float ConstB; // 0x104(0x04)
};

// Class Engine.MaterialExpressionLess
// Size: 0x108 (Inherited: 0x108)
struct UMaterialExpressionLess : UMaterialExpressionBinaryOp {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	float ConstA; // 0x100(0x04)
	float ConstB; // 0x104(0x04)
};

// Class Engine.MaterialExpressionBlackBody
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionBlackBody : UMaterialExpression {
	struct FExpressionInput Temp; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionBlendMaterialAttributes
// Size: 0x140 (Inherited: 0xb0)
struct UMaterialExpressionBlendMaterialAttributes : UMaterialExpression {
	struct FMaterialAttributesInput A; // 0xb0(0x30)
	struct FMaterialAttributesInput B; // 0xe0(0x30)
	struct FExpressionInput Alpha; // 0x110(0x28)
	enum class EMaterialAttributeBlend PixelAttributeBlendType; // 0x138(0x01)
	enum class EMaterialAttributeBlend VertexAttributeBlendType; // 0x139(0x01)
	char pad_13A[0x6]; // 0x13a(0x06)
};

// Class Engine.MaterialExpressionBreakMaterialAttributes
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionBreakMaterialAttributes : UMaterialExpression {
	struct FMaterialAttributesInput MaterialAttributes; // 0xb0(0x30)
};

// Class Engine.MaterialExpressionBumpOffset
// Size: 0x138 (Inherited: 0xb0)
struct UMaterialExpressionBumpOffset : UMaterialExpression {
	struct FExpressionInput Coordinate; // 0xb0(0x28)
	struct FExpressionInput Height; // 0xd8(0x28)
	struct FExpressionInput HeightRatioInput; // 0x100(0x28)
	float HeightRatio; // 0x128(0x04)
	float ReferencePlane; // 0x12c(0x04)
	uint32_t ConstCoordinate; // 0x130(0x04)
	char pad_134[0x4]; // 0x134(0x04)
};

// Class Engine.MaterialExpressionCameraPositionWS
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionCameraPositionWS : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionCameraVectorWS
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionCameraVectorWS : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionCeil
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionCeil : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionParameter
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionParameter : UMaterialExpression {
	struct FName ParameterName; // 0xb0(0x08)
	struct FGuid ExpressionGUID; // 0xb8(0x10)
	struct FName Group; // 0xc8(0x08)
	int32_t SortPriority; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)
};

// Class Engine.MaterialExpressionVectorParameter
// Size: 0x150 (Inherited: 0xd8)
struct UMaterialExpressionVectorParameter : UMaterialExpressionParameter {
	struct FLinearColor DefaultValue; // 0xd8(0x10)
	bool bUseCustomPrimitiveData; // 0xe8(0x01)
	char PrimitiveDataIndex; // 0xe9(0x01)
	char pad_EA[0x6]; // 0xea(0x06)
	struct FParameterChannelNames ChannelNames; // 0xf0(0x60)
};

// Class Engine.MaterialExpressionChannelMaskParameter
// Size: 0x180 (Inherited: 0x150)
struct UMaterialExpressionChannelMaskParameter : UMaterialExpressionVectorParameter {
	enum class EChannelMaskParameterColor MaskChannel; // 0x150(0x01)
	char pad_151[0x7]; // 0x151(0x07)
	struct FExpressionInput Input; // 0x158(0x28)
};

// Class Engine.MaterialExpressionClamp
// Size: 0x138 (Inherited: 0xb0)
struct UMaterialExpressionClamp : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
	struct FExpressionInput Min; // 0xd8(0x28)
	struct FExpressionInput Max; // 0x100(0x28)
	enum class EClampMode ClampMode; // 0x128(0x01)
	char pad_129[0x3]; // 0x129(0x03)
	float MinDefault; // 0x12c(0x04)
	float MaxDefault; // 0x130(0x04)
	char pad_134[0x4]; // 0x134(0x04)
};

// Class Engine.MaterialExpressionClearCoatNormalCustomOutput
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionClearCoatNormalCustomOutput : UMaterialExpressionCustomOutput {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionCloudSampleAttribute
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionCloudSampleAttribute : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionCollectionParameter
// Size: 0xd0 (Inherited: 0xb0)
struct UMaterialExpressionCollectionParameter : UMaterialExpression {
	struct UMaterialParameterCollection* Collection; // 0xb0(0x08)
	struct FName ParameterName; // 0xb8(0x08)
	struct FGuid ParameterId; // 0xc0(0x10)
};

// Class Engine.MaterialExpressionComment
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionComment : UMaterialExpression {
	int32_t SizeX; // 0xb0(0x04)
	int32_t SizeY; // 0xb4(0x04)
	struct FString Text; // 0xb8(0x10)
	struct FLinearColor CommentColor; // 0xc8(0x10)
	int32_t FontSize; // 0xd8(0x04)
	char pad_DC[0x4]; // 0xdc(0x04)
};

// Class Engine.MaterialExpressionComponentMask
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionComponentMask : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
	char R : 1; // 0xd8(0x01)
	char G : 1; // 0xd8(0x01)
	char B : 1; // 0xd8(0x01)
	char A : 1; // 0xd8(0x01)
	char pad_D8_4 : 4; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
};

// Class Engine.MaterialExpressionComposite
// Size: 0xd0 (Inherited: 0xb0)
struct UMaterialExpressionComposite : UMaterialExpression {
	struct FString SubgraphName; // 0xb0(0x10)
	struct UMaterialExpressionPinBase* InputExpressions; // 0xc0(0x08)
	struct UMaterialExpressionPinBase* OutputExpressions; // 0xc8(0x08)
};

// Class Engine.MaterialExpressionConstant
// Size: 0xb8 (Inherited: 0xb0)
struct UMaterialExpressionConstant : UMaterialExpression {
	float R; // 0xb0(0x04)
	char pad_B4[0x4]; // 0xb4(0x04)
};

// Class Engine.MaterialExpressionConstant2Vector
// Size: 0xb8 (Inherited: 0xb0)
struct UMaterialExpressionConstant2Vector : UMaterialExpression {
	float R; // 0xb0(0x04)
	float G; // 0xb4(0x04)
};

// Class Engine.MaterialExpressionConstant3Vector
// Size: 0xc0 (Inherited: 0xb0)
struct UMaterialExpressionConstant3Vector : UMaterialExpression {
	struct FLinearColor Constant; // 0xb0(0x10)
};

// Class Engine.MaterialExpressionConstant4Vector
// Size: 0xc0 (Inherited: 0xb0)
struct UMaterialExpressionConstant4Vector : UMaterialExpression {
	struct FLinearColor Constant; // 0xb0(0x10)
};

// Class Engine.MaterialExpressionConstantBiasScale
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionConstantBiasScale : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
	float Bias; // 0xd8(0x04)
	float Scale; // 0xdc(0x04)
};

// Class Engine.MaterialExpressionCosine
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionCosine : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
	float Period; // 0xd8(0x04)
	char pad_DC[0x4]; // 0xdc(0x04)
};

// Class Engine.MaterialExpressionCrossProduct
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionCrossProduct : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionScalarParameter
// Size: 0xe8 (Inherited: 0xd8)
struct UMaterialExpressionScalarParameter : UMaterialExpressionParameter {
	float DefaultValue; // 0xd8(0x04)
	bool bUseCustomPrimitiveData; // 0xdc(0x01)
	char PrimitiveDataIndex; // 0xdd(0x01)
	char pad_DE[0x2]; // 0xde(0x02)
	float SliderMin; // 0xe0(0x04)
	float SliderMax; // 0xe4(0x04)
};

// Class Engine.MaterialExpressionCurveAtlasRowParameter
// Size: 0x120 (Inherited: 0xe8)
struct UMaterialExpressionCurveAtlasRowParameter : UMaterialExpressionScalarParameter {
	struct UCurveLinearColor* Curve; // 0xe8(0x08)
	struct UCurveLinearColorAtlas* Atlas; // 0xf0(0x08)
	struct FExpressionInput InputTime; // 0xf8(0x28)
};

// Class Engine.MaterialExpressionCustom
// Size: 0x118 (Inherited: 0xb0)
struct UMaterialExpressionCustom : UMaterialExpression {
	struct FString code; // 0xb0(0x10)
	enum class ECustomMaterialOutputType OutputType; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
	struct FString Description; // 0xc8(0x10)
	struct TArray<struct FCustomInput> Inputs; // 0xd8(0x10)
	struct TArray<struct FCustomOutput> AdditionalOutputs; // 0xe8(0x10)
	struct TArray<struct FCustomDefine> AdditionalDefines; // 0xf8(0x10)
	struct TArray<struct FString> IncludeFilePaths; // 0x108(0x10)
};

// Class Engine.MaterialExpressionDBufferTexture
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionDBufferTexture : UMaterialExpression {
	struct FExpressionInput Coordinates; // 0xb0(0x28)
	enum class EDBufferTextureId DBufferTextureId; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
};

// Class Engine.MaterialExpressionDDX
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionDDX : UMaterialExpression {
	struct FExpressionInput Value; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionDDY
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionDDY : UMaterialExpression {
	struct FExpressionInput Value; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionDecalDerivative
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionDecalDerivative : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionDecalLifetimeOpacity
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionDecalLifetimeOpacity : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionDecalMipmapLevel
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionDecalMipmapLevel : UMaterialExpression {
	struct FExpressionInput TextureSize; // 0xb0(0x28)
	float ConstWidth; // 0xd8(0x04)
	float ConstHeight; // 0xdc(0x04)
};

// Class Engine.MaterialExpressionDeltaTime
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionDeltaTime : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionDepthFade
// Size: 0x108 (Inherited: 0xb0)
struct UMaterialExpressionDepthFade : UMaterialExpression {
	struct FExpressionInput InOpacity; // 0xb0(0x28)
	struct FExpressionInput FadeDistance; // 0xd8(0x28)
	float OpacityDefault; // 0x100(0x04)
	float FadeDistanceDefault; // 0x104(0x04)
};

// Class Engine.MaterialExpressionDepthOfFieldFunction
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionDepthOfFieldFunction : UMaterialExpression {
	enum class EDepthOfFieldFunctionValue FunctionValue; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
	struct FExpressionInput Depth; // 0xb8(0x28)
};

// Class Engine.MaterialExpressionDeriveNormalZ
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionDeriveNormalZ : UMaterialExpression {
	struct FExpressionInput InXY; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionDesaturation
// Size: 0x110 (Inherited: 0xb0)
struct UMaterialExpressionDesaturation : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
	struct FExpressionInput Fraction; // 0xd8(0x28)
	struct FLinearColor LuminanceFactors; // 0x100(0x10)
};

// Class Engine.MaterialExpressionDistance
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionDistance : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionDistanceCullFade
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionDistanceCullFade : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionDistanceFieldApproxAO
// Size: 0x168 (Inherited: 0xb0)
struct UMaterialExpressionDistanceFieldApproxAO : UMaterialExpression {
	struct FExpressionInput Position; // 0xb0(0x28)
	struct FExpressionInput Normal; // 0xd8(0x28)
	struct FExpressionInput BaseDistance; // 0x100(0x28)
	float BaseDistanceDefault; // 0x128(0x04)
	char pad_12C[0x4]; // 0x12c(0x04)
	struct FExpressionInput Radius; // 0x130(0x28)
	float RadiusDefault; // 0x158(0x04)
	uint32_t NumSteps; // 0x15c(0x04)
	float StepScaleDefault; // 0x160(0x04)
	char pad_164[0x4]; // 0x164(0x04)
};

// Class Engine.MaterialExpressionDistanceFieldGradient
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionDistanceFieldGradient : UMaterialExpression {
	struct FExpressionInput Position; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionDistanceFieldsRenderingSwitch
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionDistanceFieldsRenderingSwitch : UMaterialExpression {
	struct FExpressionInput No; // 0xb0(0x28)
	struct FExpressionInput Yes; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionDistanceToNearestSurface
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionDistanceToNearestSurface : UMaterialExpression {
	struct FExpressionInput Position; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionDivide
// Size: 0x108 (Inherited: 0xb0)
struct UMaterialExpressionDivide : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	float ConstA; // 0x100(0x04)
	float ConstB; // 0x104(0x04)
};

// Class Engine.MaterialExpressionDotProduct
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionDotProduct : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionDoubleVectorParameter
// Size: 0x100 (Inherited: 0xd8)
struct UMaterialExpressionDoubleVectorParameter : UMaterialExpressionParameter {
	char pad_D8[0x8]; // 0xd8(0x08)
	struct FVector4d DefaultValue; // 0xe0(0x20)
};

// Class Engine.MaterialExpressionDynamicParameter
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionDynamicParameter : UMaterialExpression {
	struct TArray<struct FString> ParamNames; // 0xb0(0x10)
	struct FLinearColor DefaultValue; // 0xc0(0x10)
	uint32_t ParameterIndex; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)
};

// Class Engine.MaterialExpressionExecBegin
// Size: 0xb8 (Inherited: 0xb0)
struct UMaterialExpressionExecBegin : UMaterialExpression {
	struct FExpressionExecOutput Exec; // 0xb0(0x08)
};

// Class Engine.MaterialExpressionExecEnd
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionExecEnd : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionEyeAdaptation
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionEyeAdaptation : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionEyeAdaptationInverse
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionEyeAdaptationInverse : UMaterialExpression {
	struct FExpressionInput LightValueInput; // 0xb0(0x28)
	struct FExpressionInput AlphaInput; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionFeatureLevelSwitch
// Size: 0x1a0 (Inherited: 0xb0)
struct UMaterialExpressionFeatureLevelSwitch : UMaterialExpression {
	struct FExpressionInput Default; // 0xb0(0x28)
	struct FExpressionInput Inputs[0x5]; // 0xd8(0xc8)
};

// Class Engine.MaterialExpressionFloor
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionFloor : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionFmod
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionFmod : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionFontSample
// Size: 0xc0 (Inherited: 0xb0)
struct UMaterialExpressionFontSample : UMaterialExpression {
	struct UFont* Font; // 0xb0(0x08)
	int32_t FontTexturePage; // 0xb8(0x04)
	char pad_BC[0x4]; // 0xbc(0x04)
};

// Class Engine.MaterialExpressionFontSampleParameter
// Size: 0xe8 (Inherited: 0xc0)
struct UMaterialExpressionFontSampleParameter : UMaterialExpressionFontSample {
	struct FName ParameterName; // 0xc0(0x08)
	struct FGuid ExpressionGUID; // 0xc8(0x10)
	struct FName Group; // 0xd8(0x08)
	int32_t SortPriority; // 0xe0(0x04)
	char pad_E4[0x4]; // 0xe4(0x04)
};

// Class Engine.MaterialExpressionForLoop
// Size: 0x138 (Inherited: 0xb0)
struct UMaterialExpressionForLoop : UMaterialExpression {
	struct FExpressionExecOutput LoopBody; // 0xb0(0x08)
	struct FExpressionExecOutput Completed; // 0xb8(0x08)
	struct FExpressionInput StartIndex; // 0xc0(0x28)
	struct FExpressionInput EndIndex; // 0xe8(0x28)
	struct FExpressionInput IndexStep; // 0x110(0x28)
};

// Class Engine.MaterialExpressionFrac
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionFrac : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionFresnel
// Size: 0x138 (Inherited: 0xb0)
struct UMaterialExpressionFresnel : UMaterialExpression {
	struct FExpressionInput ExponentIn; // 0xb0(0x28)
	float Exponent; // 0xd8(0x04)
	char pad_DC[0x4]; // 0xdc(0x04)
	struct FExpressionInput BaseReflectFractionIn; // 0xe0(0x28)
	float BaseReflectFraction; // 0x108(0x04)
	char pad_10C[0x4]; // 0x10c(0x04)
	struct FExpressionInput Normal; // 0x110(0x28)
};

// Class Engine.MaterialExpressionFunctionInput
// Size: 0x160 (Inherited: 0xb0)
struct UMaterialExpressionFunctionInput : UMaterialExpression {
	struct FExpressionInput Preview; // 0xb0(0x28)
	struct FName InputName; // 0xd8(0x08)
	struct FString Description; // 0xe0(0x10)
	struct FGuid ID; // 0xf0(0x10)
	enum class EFunctionInputType InputType; // 0x100(0x01)
	char pad_101[0xf]; // 0x101(0x0f)
	struct FVector4f PreviewValue; // 0x110(0x10)
	char bUsePreviewValueAsDefault : 1; // 0x120(0x01)
	char pad_120_1 : 7; // 0x120(0x01)
	char pad_121[0x3]; // 0x121(0x03)
	int32_t SortPriority; // 0x124(0x04)
	char bCompilingFunctionPreview : 1; // 0x128(0x01)
	char pad_128_1 : 7; // 0x128(0x01)
	char pad_129[0x37]; // 0x129(0x37)
};

// Class Engine.MaterialExpressionFunctionOutput
// Size: 0x110 (Inherited: 0xb0)
struct UMaterialExpressionFunctionOutput : UMaterialExpression {
	struct FName OutputName; // 0xb0(0x08)
	struct FString Description; // 0xb8(0x10)
	int32_t SortPriority; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
	struct FExpressionInput A; // 0xd0(0x28)
	char bLastPreviewed : 1; // 0xf8(0x01)
	char pad_F8_1 : 7; // 0xf8(0x01)
	char pad_F9[0x3]; // 0xf9(0x03)
	struct FGuid ID; // 0xfc(0x10)
	char pad_10C[0x4]; // 0x10c(0x04)
};

// Class Engine.MaterialExpressionGenericConstant
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionGenericConstant : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionConstantDouble
// Size: 0xb8 (Inherited: 0xb0)
struct UMaterialExpressionConstantDouble : UMaterialExpressionGenericConstant {
	double Value; // 0xb0(0x08)
};

// Class Engine.MaterialExpressionGetLocal
// Size: 0xb8 (Inherited: 0xb0)
struct UMaterialExpressionGetLocal : UMaterialExpression {
	struct FName LocalName; // 0xb0(0x08)
};

// Class Engine.MaterialExpressionGetMaterialAttributes
// Size: 0xf0 (Inherited: 0xb0)
struct UMaterialExpressionGetMaterialAttributes : UMaterialExpression {
	struct FMaterialAttributesInput MaterialAttributes; // 0xb0(0x30)
	struct TArray<struct FGuid> AttributeGetTypes; // 0xe0(0x10)
};

// Class Engine.MaterialExpressionGIReplace
// Size: 0x128 (Inherited: 0xb0)
struct UMaterialExpressionGIReplace : UMaterialExpression {
	struct FExpressionInput Default; // 0xb0(0x28)
	struct FExpressionInput StaticIndirect; // 0xd8(0x28)
	struct FExpressionInput DynamicIndirect; // 0x100(0x28)
};

// Class Engine.MaterialExpressionHairAttributes
// Size: 0xb8 (Inherited: 0xb0)
struct UMaterialExpressionHairAttributes : UMaterialExpression {
	char bUseTangentSpace : 1; // 0xb0(0x01)
	char pad_B0_1 : 7; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
};

// Class Engine.MaterialExpressionHairColor
// Size: 0x128 (Inherited: 0xb0)
struct UMaterialExpressionHairColor : UMaterialExpression {
	struct FExpressionInput Melanin; // 0xb0(0x28)
	struct FExpressionInput Redness; // 0xd8(0x28)
	struct FExpressionInput DyeColor; // 0x100(0x28)
};

// Class Engine.MaterialExpressionIf
// Size: 0x188 (Inherited: 0xb0)
struct UMaterialExpressionIf : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	struct FExpressionInput AGreaterThanB; // 0x100(0x28)
	struct FExpressionInput AEqualsB; // 0x128(0x28)
	struct FExpressionInput ALessThanB; // 0x150(0x28)
	float EqualsThreshold; // 0x178(0x04)
	float ConstB; // 0x17c(0x04)
	float ConstAEqualsB; // 0x180(0x04)
	char pad_184[0x4]; // 0x184(0x04)
};

// Class Engine.MaterialExpressionIfThenElse
// Size: 0xe8 (Inherited: 0xb0)
struct UMaterialExpressionIfThenElse : UMaterialExpression {
	struct FExpressionExecOutput Then; // 0xb0(0x08)
	struct FExpressionExecOutput Else; // 0xb8(0x08)
	struct FExpressionInput Condition; // 0xc0(0x28)
};

// Class Engine.MaterialExpressionInverseLinearInterpolate
// Size: 0x138 (Inherited: 0xb0)
struct UMaterialExpressionInverseLinearInterpolate : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	struct FExpressionInput Value; // 0x100(0x28)
	float ConstA; // 0x128(0x04)
	float ConstB; // 0x12c(0x04)
	float ConstValue; // 0x130(0x04)
	bool bClampResult; // 0x134(0x01)
	char pad_135[0x3]; // 0x135(0x03)
};

// Class Engine.MaterialExpressionIsOrthographic
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionIsOrthographic : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionLightmapUVs
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionLightmapUVs : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionLightmassReplace
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionLightmassReplace : UMaterialExpression {
	struct FExpressionInput Realtime; // 0xb0(0x28)
	struct FExpressionInput Lightmass; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionLightVector
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionLightVector : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionLinearInterpolate
// Size: 0x138 (Inherited: 0xb0)
struct UMaterialExpressionLinearInterpolate : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	struct FExpressionInput Alpha; // 0x100(0x28)
	float ConstA; // 0x128(0x04)
	float ConstB; // 0x12c(0x04)
	float ConstAlpha; // 0x130(0x04)
	char pad_134[0x4]; // 0x134(0x04)
};

// Class Engine.MaterialExpressionLogarithm10
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionLogarithm10 : UMaterialExpression {
	struct FExpressionInput X; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionLogarithm2
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionLogarithm2 : UMaterialExpression {
	struct FExpressionInput X; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionMakeMaterialAttributes
// Size: 0x4c0 (Inherited: 0xb0)
struct UMaterialExpressionMakeMaterialAttributes : UMaterialExpression {
	struct FExpressionInput BaseColor; // 0xb0(0x28)
	struct FExpressionInput Metallic; // 0xd8(0x28)
	struct FExpressionInput Specular; // 0x100(0x28)
	struct FExpressionInput Roughness; // 0x128(0x28)
	struct FExpressionInput Anisotropy; // 0x150(0x28)
	struct FExpressionInput EmissiveColor; // 0x178(0x28)
	struct FExpressionInput Opacity; // 0x1a0(0x28)
	struct FExpressionInput OpacityMask; // 0x1c8(0x28)
	struct FExpressionInput Normal; // 0x1f0(0x28)
	struct FExpressionInput Tangent; // 0x218(0x28)
	struct FExpressionInput WorldPositionOffset; // 0x240(0x28)
	struct FExpressionInput SubsurfaceColor; // 0x268(0x28)
	struct FExpressionInput ClearCoat; // 0x290(0x28)
	struct FExpressionInput ClearCoatRoughness; // 0x2b8(0x28)
	struct FExpressionInput AmbientOcclusion; // 0x2e0(0x28)
	struct FExpressionInput Refraction; // 0x308(0x28)
	struct FExpressionInput CustomizedUVs[0x8]; // 0x330(0x140)
	struct FExpressionInput PixelDepthOffset; // 0x470(0x28)
	struct FExpressionInput ShadingModel; // 0x498(0x28)
};

// Class Engine.MaterialExpressionMapARPassthroughCameraUV
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionMapARPassthroughCameraUV : UMaterialExpression {
	struct FExpressionInput Coordinates; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionMaterialAttributeLayers
// Size: 0x218 (Inherited: 0xb0)
struct UMaterialExpressionMaterialAttributeLayers : UMaterialExpression {
	struct FMaterialAttributesInput Input; // 0xb0(0x30)
	struct FMaterialLayersFunctions DefaultLayers; // 0xe0(0x100)
	struct TArray<struct UMaterialExpressionMaterialFunctionCall*> LayerCallers; // 0x1e0(0x10)
	int32_t NumActiveLayerCallers; // 0x1f0(0x04)
	char pad_1F4[0x4]; // 0x1f4(0x04)
	struct TArray<struct UMaterialExpressionMaterialFunctionCall*> BlendCallers; // 0x1f8(0x10)
	int32_t NumActiveBlendCallers; // 0x208(0x04)
	bool bIsLayerGraphBuilt; // 0x20c(0x01)
	char pad_20D[0xb]; // 0x20d(0x0b)
};

// Class Engine.MaterialExpressionMaterialFunctionCall
// Size: 0xe8 (Inherited: 0xb0)
struct UMaterialExpressionMaterialFunctionCall : UMaterialExpression {
	struct UMaterialFunctionInterface* MaterialFunction; // 0xb0(0x08)
	struct TArray<struct FFunctionExpressionInput> FunctionInputs; // 0xb8(0x10)
	struct TArray<struct FFunctionExpressionOutput> FunctionOutputs; // 0xc8(0x10)
	struct FMaterialParameterInfo FunctionParameterInfo; // 0xd8(0x10)
};

// Class Engine.MaterialExpressionMaterialLayerOutput
// Size: 0x110 (Inherited: 0x110)
struct UMaterialExpressionMaterialLayerOutput : UMaterialExpressionFunctionOutput {
	struct FName OutputName; // 0xb0(0x08)
	struct FString Description; // 0xb8(0x10)
	int32_t SortPriority; // 0xc8(0x04)
	struct FExpressionInput A; // 0xd0(0x28)
	char bLastPreviewed : 1; // 0xf8(0x01)
	struct FGuid ID; // 0xfc(0x10)
};

// Class Engine.MaterialExpressionMaterialProxyReplace
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionMaterialProxyReplace : UMaterialExpression {
	struct FExpressionInput Realtime; // 0xb0(0x28)
	struct FExpressionInput MaterialProxy; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionMax
// Size: 0x108 (Inherited: 0xb0)
struct UMaterialExpressionMax : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	float ConstA; // 0x100(0x04)
	float ConstB; // 0x104(0x04)
};

// Class Engine.MaterialExpressionMin
// Size: 0x108 (Inherited: 0xb0)
struct UMaterialExpressionMin : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	float ConstA; // 0x100(0x04)
	float ConstB; // 0x104(0x04)
};

// Class Engine.MaterialExpressionMultiply
// Size: 0x108 (Inherited: 0xb0)
struct UMaterialExpressionMultiply : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	float ConstA; // 0x100(0x04)
	float ConstB; // 0x104(0x04)
};

// Class Engine.MaterialExpressionRerouteBase
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionRerouteBase : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionNamedRerouteBase
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionNamedRerouteBase : UMaterialExpressionRerouteBase {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionNamedRerouteDeclaration
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionNamedRerouteDeclaration : UMaterialExpressionNamedRerouteBase {
	struct FExpressionInput Input; // 0xb0(0x28)
	struct FName Name; // 0xd8(0x08)
	struct FLinearColor NodeColor; // 0xe0(0x10)
	struct FGuid VariableGuid; // 0xf0(0x10)
};

// Class Engine.MaterialExpressionNamedRerouteUsage
// Size: 0xc8 (Inherited: 0xb0)
struct UMaterialExpressionNamedRerouteUsage : UMaterialExpressionNamedRerouteBase {
	struct UMaterialExpressionNamedRerouteDeclaration* Declaration; // 0xb0(0x08)
	struct FGuid DeclarationGuid; // 0xb8(0x10)
};

// Class Engine.MaterialExpressionNaniteReplace
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionNaniteReplace : UMaterialExpression {
	struct FExpressionInput Default; // 0xb0(0x28)
	struct FExpressionInput Nanite; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionNoise
// Size: 0x128 (Inherited: 0xb0)
struct UMaterialExpressionNoise : UMaterialExpression {
	struct FExpressionInput Position; // 0xb0(0x28)
	struct FExpressionInput FilterWidth; // 0xd8(0x28)
	float Scale; // 0x100(0x04)
	int32_t Quality; // 0x104(0x04)
	enum class ENoiseFunction NoiseFunction; // 0x108(0x01)
	char pad_109[0x3]; // 0x109(0x03)
	char bTurbulence : 1; // 0x10c(0x01)
	char pad_10C_1 : 7; // 0x10c(0x01)
	char pad_10D[0x3]; // 0x10d(0x03)
	int32_t Levels; // 0x110(0x04)
	float OutputMin; // 0x114(0x04)
	float OutputMax; // 0x118(0x04)
	float LevelScale; // 0x11c(0x04)
	char bTiling : 1; // 0x120(0x01)
	char pad_120_1 : 7; // 0x120(0x01)
	char pad_121[0x3]; // 0x121(0x03)
	uint32_t RepeatSize; // 0x124(0x04)
};

// Class Engine.MaterialExpressionNormalize
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionNormalize : UMaterialExpression {
	struct FExpressionInput VectorInput; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionObjectBounds
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionObjectBounds : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionObjectOrientation
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionObjectOrientation : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionObjectPositionWS
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionObjectPositionWS : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionObjectRadius
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionObjectRadius : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionOneMinus
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionOneMinus : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionPanner
// Size: 0x138 (Inherited: 0xb0)
struct UMaterialExpressionPanner : UMaterialExpression {
	struct FExpressionInput Coordinate; // 0xb0(0x28)
	struct FExpressionInput Time; // 0xd8(0x28)
	struct FExpressionInput Speed; // 0x100(0x28)
	float SpeedX; // 0x128(0x04)
	float SpeedY; // 0x12c(0x04)
	uint32_t ConstCoordinate; // 0x130(0x04)
	bool bFractionalPart; // 0x134(0x01)
	char pad_135[0x3]; // 0x135(0x03)
};

// Class Engine.MaterialExpressionParticleColor
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionParticleColor : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionParticleDirection
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionParticleDirection : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionParticleMacroUV
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionParticleMacroUV : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionParticleMotionBlurFade
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionParticleMotionBlurFade : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionParticlePositionWS
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionParticlePositionWS : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionParticleRadius
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionParticleRadius : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionParticleRandom
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionParticleRandom : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionParticleRelativeTime
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionParticleRelativeTime : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionParticleSize
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionParticleSize : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionParticleSpeed
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionParticleSpeed : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionParticleSubUV
// Size: 0x1c0 (Inherited: 0x1b8)
struct UMaterialExpressionParticleSubUV : UMaterialExpressionTextureSample {
	char bBlend : 1; // 0x1b8(0x01)
	char pad_1B8_1 : 7; // 0x1b8(0x01)
	char pad_1B9[0x7]; // 0x1b9(0x07)
};

// Class Engine.MaterialExpressionParticleSubUVProperties
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionParticleSubUVProperties : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionPathTracingQualitySwitch
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionPathTracingQualitySwitch : UMaterialExpression {
	struct FExpressionInput Normal; // 0xb0(0x28)
	struct FExpressionInput PathTraced; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionPerInstanceCustomData
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionPerInstanceCustomData : UMaterialExpression {
	struct FExpressionInput DefaultValue; // 0xb0(0x28)
	float ConstDefaultValue; // 0xd8(0x04)
	uint32_t DataIndex; // 0xdc(0x04)
};

// Class Engine.MaterialExpressionPerInstanceCustomData3Vector
// Size: 0xf0 (Inherited: 0xb0)
struct UMaterialExpressionPerInstanceCustomData3Vector : UMaterialExpression {
	struct FExpressionInput DefaultValue; // 0xb0(0x28)
	struct FLinearColor ConstDefaultValue; // 0xd8(0x10)
	uint32_t DataIndex; // 0xe8(0x04)
	char pad_EC[0x4]; // 0xec(0x04)
};

// Class Engine.MaterialExpressionPerInstanceFadeAmount
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionPerInstanceFadeAmount : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionPerInstanceRandom
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionPerInstanceRandom : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionPinBase
// Size: 0xc8 (Inherited: 0xb0)
struct UMaterialExpressionPinBase : UMaterialExpression {
	struct TArray<struct FCompositeReroute> ReroutePins; // 0xb0(0x10)
	enum class EEdGraphPinDirection PinDirection; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
};

// Class Engine.MaterialExpressionPixelDepth
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionPixelDepth : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionPixelNormalWS
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionPixelNormalWS : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionPower
// Size: 0x108 (Inherited: 0xb0)
struct UMaterialExpressionPower : UMaterialExpression {
	struct FExpressionInput Base; // 0xb0(0x28)
	struct FExpressionInput Exponent; // 0xd8(0x28)
	float ConstExponent; // 0x100(0x04)
	char pad_104[0x4]; // 0x104(0x04)
};

// Class Engine.MaterialExpressionPrecomputedAOMask
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionPrecomputedAOMask : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionPreSkinnedLocalBounds
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionPreSkinnedLocalBounds : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionPreSkinnedNormal
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionPreSkinnedNormal : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionPreSkinnedPosition
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionPreSkinnedPosition : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionPreviousFrameSwitch
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionPreviousFrameSwitch : UMaterialExpression {
	struct FExpressionInput CurrentFrame; // 0xb0(0x28)
	struct FExpressionInput PreviousFrame; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionQualitySwitch
// Size: 0x178 (Inherited: 0xb0)
struct UMaterialExpressionQualitySwitch : UMaterialExpression {
	struct FExpressionInput Default; // 0xb0(0x28)
	struct FExpressionInput Inputs[0x4]; // 0xd8(0xa0)
};

// Class Engine.MaterialExpressionRayTracingQualitySwitch
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionRayTracingQualitySwitch : UMaterialExpression {
	struct FExpressionInput Normal; // 0xb0(0x28)
	struct FExpressionInput RayTraced; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionReflectionCapturePassSwitch
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionReflectionCapturePassSwitch : UMaterialExpression {
	struct FExpressionInput Default; // 0xb0(0x28)
	struct FExpressionInput Reflection; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionReflectionVectorWS
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionReflectionVectorWS : UMaterialExpression {
	struct FExpressionInput CustomWorldNormal; // 0xb0(0x28)
	char bNormalizeCustomWorldNormal : 1; // 0xd8(0x01)
	char pad_D8_1 : 7; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
};

// Class Engine.MaterialExpressionReroute
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionReroute : UMaterialExpressionRerouteBase {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionRotateAboutAxis
// Size: 0x158 (Inherited: 0xb0)
struct UMaterialExpressionRotateAboutAxis : UMaterialExpression {
	struct FExpressionInput NormalizedRotationAxis; // 0xb0(0x28)
	struct FExpressionInput RotationAngle; // 0xd8(0x28)
	struct FExpressionInput PivotPoint; // 0x100(0x28)
	struct FExpressionInput Position; // 0x128(0x28)
	float Period; // 0x150(0x04)
	char pad_154[0x4]; // 0x154(0x04)
};

// Class Engine.MaterialExpressionRotator
// Size: 0x110 (Inherited: 0xb0)
struct UMaterialExpressionRotator : UMaterialExpression {
	struct FExpressionInput Coordinate; // 0xb0(0x28)
	struct FExpressionInput Time; // 0xd8(0x28)
	float CenterX; // 0x100(0x04)
	float CenterY; // 0x104(0x04)
	float Speed; // 0x108(0x04)
	uint32_t ConstCoordinate; // 0x10c(0x04)
};

// Class Engine.MaterialExpressionRound
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionRound : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionRuntimeVirtualTextureOutput
// Size: 0x1c8 (Inherited: 0xb0)
struct UMaterialExpressionRuntimeVirtualTextureOutput : UMaterialExpressionCustomOutput {
	struct FExpressionInput BaseColor; // 0xb0(0x28)
	struct FExpressionInput Specular; // 0xd8(0x28)
	struct FExpressionInput Roughness; // 0x100(0x28)
	struct FExpressionInput Normal; // 0x128(0x28)
	struct FExpressionInput WorldHeight; // 0x150(0x28)
	struct FExpressionInput Opacity; // 0x178(0x28)
	struct FExpressionInput Mask; // 0x1a0(0x28)
};

// Class Engine.MaterialExpressionRuntimeVirtualTextureReplace
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionRuntimeVirtualTextureReplace : UMaterialExpression {
	struct FExpressionInput Default; // 0xb0(0x28)
	struct FExpressionInput VirtualTextureOutput; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionRuntimeVirtualTextureSample
// Size: 0x138 (Inherited: 0xb0)
struct UMaterialExpressionRuntimeVirtualTextureSample : UMaterialExpression {
	struct FExpressionInput Coordinates; // 0xb0(0x28)
	struct FExpressionInput WorldPosition; // 0xd8(0x28)
	struct FExpressionInput MipValue; // 0x100(0x28)
	struct URuntimeVirtualTexture* VirtualTexture; // 0x128(0x08)
	enum class ERuntimeVirtualTextureMaterialType MaterialType; // 0x130(0x01)
	bool bSinglePhysicalSpace; // 0x131(0x01)
	bool bAdaptive; // 0x132(0x01)
	enum class ERuntimeVirtualTextureMipValueMode MipValueMode; // 0x133(0x01)
	enum class ERuntimeVirtualTextureTextureAddressMode TextureAddressMode; // 0x134(0x01)
	char pad_135[0x3]; // 0x135(0x03)
};

// Class Engine.MaterialExpressionRuntimeVirtualTextureSampleParameter
// Size: 0x160 (Inherited: 0x138)
struct UMaterialExpressionRuntimeVirtualTextureSampleParameter : UMaterialExpressionRuntimeVirtualTextureSample {
	struct FName ParameterName; // 0x138(0x08)
	struct FGuid ExpressionGUID; // 0x140(0x10)
	struct FName Group; // 0x150(0x08)
	int32_t SortPriority; // 0x158(0x04)
	char pad_15C[0x4]; // 0x15c(0x04)
};

// Class Engine.MaterialExpressionSamplePhysicsVectorField
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionSamplePhysicsVectorField : UMaterialExpression {
	struct FExpressionInput WorldPosition; // 0xb0(0x28)
	enum class EFieldVectorType FieldTarget; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
};

// Class Engine.MaterialExpressionSamplePhysicsScalarField
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionSamplePhysicsScalarField : UMaterialExpression {
	struct FExpressionInput WorldPosition; // 0xb0(0x28)
	enum class EFieldScalarType FieldTarget; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
};

// Class Engine.MaterialExpressionSamplePhysicsIntegerField
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionSamplePhysicsIntegerField : UMaterialExpression {
	struct FExpressionInput WorldPosition; // 0xb0(0x28)
	enum class EFieldIntegerType FieldTarget; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
};

// Class Engine.MaterialExpressionSaturate
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionSaturate : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionSceneColor
// Size: 0x118 (Inherited: 0xb0)
struct UMaterialExpressionSceneColor : UMaterialExpression {
	enum class EMaterialSceneAttributeInputMode InputMode; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
	struct FExpressionInput Input; // 0xb8(0x28)
	struct FExpressionInput OffsetFraction; // 0xe0(0x28)
	struct FVector2D ConstInput; // 0x108(0x10)
};

// Class Engine.MaterialExpressionSceneDepth
// Size: 0x118 (Inherited: 0xb0)
struct UMaterialExpressionSceneDepth : UMaterialExpression {
	enum class EMaterialSceneAttributeInputMode InputMode; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
	struct FExpressionInput Input; // 0xb8(0x28)
	struct FExpressionInput Coordinates; // 0xe0(0x28)
	struct FVector2D ConstInput; // 0x108(0x10)
};

// Class Engine.MaterialExpressionSceneDepthWithoutWater
// Size: 0xf8 (Inherited: 0xb0)
struct UMaterialExpressionSceneDepthWithoutWater : UMaterialExpression {
	enum class EMaterialSceneAttributeInputMode InputMode; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
	struct FExpressionInput Input; // 0xb8(0x28)
	struct FVector2D ConstInput; // 0xe0(0x10)
	float FallbackDepth; // 0xf0(0x04)
	char pad_F4[0x4]; // 0xf4(0x04)
};

// Class Engine.MaterialExpressionSceneTexelSize
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionSceneTexelSize : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionSceneTexture
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionSceneTexture : UMaterialExpression {
	struct FExpressionInput Coordinates; // 0xb0(0x28)
	enum class ESceneTextureId SceneTextureId; // 0xd8(0x01)
	bool bFiltered; // 0xd9(0x01)
	char pad_DA[0x6]; // 0xda(0x06)
};

// Class Engine.MaterialExpressionScreenPosition
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionScreenPosition : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionSetLocal
// Size: 0xe8 (Inherited: 0xb0)
struct UMaterialExpressionSetLocal : UMaterialExpression {
	struct FExpressionExecOutput Exec; // 0xb0(0x08)
	struct FExpressionInput Value; // 0xb8(0x28)
	struct FName LocalName; // 0xe0(0x08)
};

// Class Engine.MaterialExpressionSetMaterialAttributes
// Size: 0xd0 (Inherited: 0xb0)
struct UMaterialExpressionSetMaterialAttributes : UMaterialExpression {
	struct TArray<struct FExpressionInput> Inputs; // 0xb0(0x10)
	struct TArray<struct FGuid> AttributeSetTypes; // 0xc0(0x10)
};

// Class Engine.MaterialExpressionShaderStageSwitch
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionShaderStageSwitch : UMaterialExpression {
	struct FExpressionInput PixelShader; // 0xb0(0x28)
	struct FExpressionInput VertexShader; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionShadingModel
// Size: 0xb8 (Inherited: 0xb0)
struct UMaterialExpressionShadingModel : UMaterialExpression {
	enum class EMaterialShadingModel ShadingModel; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
};

// Class Engine.MaterialExpressionShadingPathSwitch
// Size: 0x150 (Inherited: 0xb0)
struct UMaterialExpressionShadingPathSwitch : UMaterialExpression {
	struct FExpressionInput Default; // 0xb0(0x28)
	struct FExpressionInput Inputs[0x3]; // 0xd8(0x78)
};

// Class Engine.MaterialExpressionShadowReplace
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionShadowReplace : UMaterialExpression {
	struct FExpressionInput Default; // 0xb0(0x28)
	struct FExpressionInput Shadow; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionSign
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionSign : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionSine
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionSine : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
	float Period; // 0xd8(0x04)
	char pad_DC[0x4]; // 0xdc(0x04)
};

// Class Engine.MaterialExpressionSingleLayerWaterMaterialOutput
// Size: 0x150 (Inherited: 0xb0)
struct UMaterialExpressionSingleLayerWaterMaterialOutput : UMaterialExpressionCustomOutput {
	struct FExpressionInput ScatteringCoefficients; // 0xb0(0x28)
	struct FExpressionInput AbsorptionCoefficients; // 0xd8(0x28)
	struct FExpressionInput PhaseG; // 0x100(0x28)
	struct FExpressionInput ColorScaleBehindWater; // 0x128(0x28)
};

// Class Engine.MaterialExpressionSkyAtmosphereLightDirection
// Size: 0xb8 (Inherited: 0xb0)
struct UMaterialExpressionSkyAtmosphereLightDirection : UMaterialExpression {
	int32_t LightIndex; // 0xb0(0x04)
	char pad_B4[0x4]; // 0xb4(0x04)
};

// Class Engine.MaterialExpressionSkyAtmosphereLightIlluminance
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionSkyAtmosphereLightIlluminance : UMaterialExpression {
	int32_t LightIndex; // 0xb0(0x04)
	char pad_B4[0x4]; // 0xb4(0x04)
	struct FExpressionInput WorldPosition; // 0xb8(0x28)
};

// Class Engine.MaterialExpressionSkyAtmosphereLightDiskLuminance
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionSkyAtmosphereLightDiskLuminance : UMaterialExpression {
	int32_t LightIndex; // 0xb0(0x04)
	char pad_B4[0x4]; // 0xb4(0x04)
	struct FExpressionInput DiskAngularDiameterOverride; // 0xb8(0x28)
};

// Class Engine.MaterialExpressionSkyAtmosphereAerialPerspective
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionSkyAtmosphereAerialPerspective : UMaterialExpression {
	struct FExpressionInput WorldPosition; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionSkyAtmosphereDistantLightScatteredLuminance
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionSkyAtmosphereDistantLightScatteredLuminance : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionSkyAtmosphereViewLuminance
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionSkyAtmosphereViewLuminance : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionSkyLightEnvMapSample
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionSkyLightEnvMapSample : UMaterialExpression {
	struct FExpressionInput Direction; // 0xb0(0x28)
	struct FExpressionInput Roughness; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionSmoothStep
// Size: 0x138 (Inherited: 0xb0)
struct UMaterialExpressionSmoothStep : UMaterialExpression {
	struct FExpressionInput Min; // 0xb0(0x28)
	struct FExpressionInput Max; // 0xd8(0x28)
	struct FExpressionInput Value; // 0x100(0x28)
	float ConstMin; // 0x128(0x04)
	float ConstMax; // 0x12c(0x04)
	float ConstValue; // 0x130(0x04)
	char pad_134[0x4]; // 0x134(0x04)
};

// Class Engine.MaterialExpressionSobol
// Size: 0x140 (Inherited: 0xb0)
struct UMaterialExpressionSobol : UMaterialExpression {
	struct FExpressionInput Cell; // 0xb0(0x28)
	struct FExpressionInput Index; // 0xd8(0x28)
	struct FExpressionInput Seed; // 0x100(0x28)
	uint32_t ConstIndex; // 0x128(0x04)
	char pad_12C[0x4]; // 0x12c(0x04)
	struct FVector2D ConstSeed; // 0x130(0x10)
};

// Class Engine.MaterialExpressionSpeedTree
// Size: 0x160 (Inherited: 0xb0)
struct UMaterialExpressionSpeedTree : UMaterialExpression {
	struct FExpressionInput GeometryInput; // 0xb0(0x28)
	struct FExpressionInput WindInput; // 0xd8(0x28)
	struct FExpressionInput LODInput; // 0x100(0x28)
	struct FExpressionInput ExtraBendWS; // 0x128(0x28)
	enum class ESpeedTreeGeometryType GeometryType; // 0x150(0x01)
	enum class ESpeedTreeWindType WindType; // 0x151(0x01)
	enum class ESpeedTreeLODType LODType; // 0x152(0x01)
	char pad_153[0x1]; // 0x153(0x01)
	float BillboardThreshold; // 0x154(0x04)
	bool bAccurateWindVelocities; // 0x158(0x01)
	char pad_159[0x7]; // 0x159(0x07)
};

// Class Engine.MaterialExpressionSphereMask
// Size: 0x158 (Inherited: 0xb0)
struct UMaterialExpressionSphereMask : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	struct FExpressionInput Radius; // 0x100(0x28)
	struct FExpressionInput Hardness; // 0x128(0x28)
	float AttenuationRadius; // 0x150(0x04)
	float HardnessPercent; // 0x154(0x04)
};

// Class Engine.MaterialExpressionSphericalParticleOpacity
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionSphericalParticleOpacity : UMaterialExpression {
	struct FExpressionInput Density; // 0xb0(0x28)
	float ConstantDensity; // 0xd8(0x04)
	char pad_DC[0x4]; // 0xdc(0x04)
};

// Class Engine.MaterialExpressionSquareRoot
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionSquareRoot : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionStaticBool
// Size: 0xb8 (Inherited: 0xb0)
struct UMaterialExpressionStaticBool : UMaterialExpression {
	char Value : 1; // 0xb0(0x01)
	char pad_B0_1 : 7; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
};

// Class Engine.MaterialExpressionStaticBoolParameter
// Size: 0xe0 (Inherited: 0xd8)
struct UMaterialExpressionStaticBoolParameter : UMaterialExpressionParameter {
	char DefaultValue : 1; // 0xd8(0x01)
	char pad_D8_1 : 7; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
};

// Class Engine.MaterialExpressionStaticComponentMaskParameter
// Size: 0x108 (Inherited: 0xd8)
struct UMaterialExpressionStaticComponentMaskParameter : UMaterialExpressionParameter {
	struct FExpressionInput Input; // 0xd8(0x28)
	char DefaultR : 1; // 0x100(0x01)
	char DefaultG : 1; // 0x100(0x01)
	char DefaultB : 1; // 0x100(0x01)
	char DefaultA : 1; // 0x100(0x01)
	char pad_100_4 : 4; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
};

// Class Engine.MaterialExpressionStaticSwitch
// Size: 0x130 (Inherited: 0xb0)
struct UMaterialExpressionStaticSwitch : UMaterialExpression {
	char DefaultValue : 1; // 0xb0(0x01)
	char pad_B0_1 : 7; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
	struct FExpressionInput A; // 0xb8(0x28)
	struct FExpressionInput B; // 0xe0(0x28)
	struct FExpressionInput Value; // 0x108(0x28)
};

// Class Engine.MaterialExpressionStaticSwitchParameter
// Size: 0x130 (Inherited: 0xe0)
struct UMaterialExpressionStaticSwitchParameter : UMaterialExpressionStaticBoolParameter {
	struct FExpressionInput A; // 0xe0(0x28)
	struct FExpressionInput B; // 0x108(0x28)
};

// Class Engine.MaterialExpressionStep
// Size: 0x108 (Inherited: 0xb0)
struct UMaterialExpressionStep : UMaterialExpression {
	struct FExpressionInput Y; // 0xb0(0x28)
	struct FExpressionInput X; // 0xd8(0x28)
	float ConstY; // 0x100(0x04)
	float ConstX; // 0x104(0x04)
};

// Class Engine.MaterialExpressionStrataBSDF
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionStrataBSDF : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionStrataLegacyConversion
// Size: 0x3f8 (Inherited: 0xb0)
struct UMaterialExpressionStrataLegacyConversion : UMaterialExpressionStrataBSDF {
	struct FExpressionInput BaseColor; // 0xb0(0x28)
	struct FExpressionInput Metallic; // 0xd8(0x28)
	struct FExpressionInput Specular; // 0x100(0x28)
	struct FExpressionInput Roughness; // 0x128(0x28)
	struct FExpressionInput Anisotropy; // 0x150(0x28)
	struct FExpressionInput EmissiveColor; // 0x178(0x28)
	struct FExpressionInput Normal; // 0x1a0(0x28)
	struct FExpressionInput Tangent; // 0x1c8(0x28)
	struct FExpressionInput SubsurfaceColor; // 0x1f0(0x28)
	struct FExpressionInput ClearCoat; // 0x218(0x28)
	struct FExpressionInput ClearCoatRoughness; // 0x240(0x28)
	struct FExpressionInput Opacity; // 0x268(0x28)
	struct FExpressionInput TransmittanceColor; // 0x290(0x28)
	struct FExpressionInput WaterScatteringCoefficients; // 0x2b8(0x28)
	struct FExpressionInput WaterAbsorptionCoefficients; // 0x2e0(0x28)
	struct FExpressionInput WaterPhaseG; // 0x308(0x28)
	struct FExpressionInput ColorScaleBehindWater; // 0x330(0x28)
	struct FExpressionInput ClearCoatNormal; // 0x358(0x28)
	struct FExpressionInput CustomTangent; // 0x380(0x28)
	struct FShadingModelMaterialInput ShadingModel; // 0x3a8(0x28)
	char pad_3D0[0x8]; // 0x3d0(0x08)
	struct USubsurfaceProfile* SubsurfaceProfile; // 0x3d8(0x08)
	struct FStrataMaterialInfo ConvertedStrataMaterialInfo; // 0x3e0(0x18)
};

// Class Engine.MaterialExpressionStrataSlabBSDF
// Size: 0x3e0 (Inherited: 0xb0)
struct UMaterialExpressionStrataSlabBSDF : UMaterialExpressionStrataBSDF {
	struct FExpressionInput BaseColor; // 0xb0(0x28)
	struct FExpressionInput EdgeColor; // 0xd8(0x28)
	struct FExpressionInput Metallic; // 0x100(0x28)
	struct FExpressionInput Specular; // 0x128(0x28)
	struct FExpressionInput DiffuseAlbedo; // 0x150(0x28)
	struct FExpressionInput F0; // 0x178(0x28)
	struct FExpressionInput F90; // 0x1a0(0x28)
	struct FExpressionInput Roughness; // 0x1c8(0x28)
	struct FExpressionInput Anisotropy; // 0x1f0(0x28)
	struct FExpressionInput Normal; // 0x218(0x28)
	struct FExpressionInput Tangent; // 0x240(0x28)
	struct FExpressionInput SSSMFP; // 0x268(0x28)
	struct FExpressionInput SSSMFPScale; // 0x290(0x28)
	struct FExpressionInput SSSPhaseAnisotropy; // 0x2b8(0x28)
	struct FExpressionInput EmissiveColor; // 0x2e0(0x28)
	struct FExpressionInput SecondRoughness; // 0x308(0x28)
	struct FExpressionInput SecondRoughnessWeight; // 0x330(0x28)
	struct FExpressionInput Thickness; // 0x358(0x28)
	struct FExpressionInput FuzzAmount; // 0x380(0x28)
	struct FExpressionInput FuzzColor; // 0x3a8(0x28)
	struct USubsurfaceProfile* SubsurfaceProfile; // 0x3d0(0x08)
	char bUseMetalness : 1; // 0x3d8(0x01)
	char bUseSSSDiffusion : 1; // 0x3d8(0x01)
	char pad_3D8_2 : 6; // 0x3d8(0x01)
	char pad_3D9[0x7]; // 0x3d9(0x07)
};

// Class Engine.MaterialExpressionStrataSimpleClearCoatBSDF
// Size: 0x1f0 (Inherited: 0xb0)
struct UMaterialExpressionStrataSimpleClearCoatBSDF : UMaterialExpressionStrataBSDF {
	struct FExpressionInput BaseColor; // 0xb0(0x28)
	struct FExpressionInput Metallic; // 0xd8(0x28)
	struct FExpressionInput Specular; // 0x100(0x28)
	struct FExpressionInput Roughness; // 0x128(0x28)
	struct FExpressionInput ClearCoatCoverage; // 0x150(0x28)
	struct FExpressionInput ClearCoatRoughness; // 0x178(0x28)
	struct FExpressionInput Normal; // 0x1a0(0x28)
	struct FExpressionInput EmissiveColor; // 0x1c8(0x28)
};

// Class Engine.MaterialExpressionStrataVolumetricFogCloudBSDF
// Size: 0x150 (Inherited: 0xb0)
struct UMaterialExpressionStrataVolumetricFogCloudBSDF : UMaterialExpressionStrataBSDF {
	struct FExpressionInput Albedo; // 0xb0(0x28)
	struct FExpressionInput Extinction; // 0xd8(0x28)
	struct FExpressionInput EmissiveColor; // 0x100(0x28)
	struct FExpressionInput AmbientOcclusion; // 0x128(0x28)
};

// Class Engine.MaterialExpressionStrataUnlitBSDF
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionStrataUnlitBSDF : UMaterialExpressionStrataBSDF {
	struct FExpressionInput EmissiveColor; // 0xb0(0x28)
	struct FExpressionInput TransmittanceColor; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionStrataHairBSDF
// Size: 0x1c8 (Inherited: 0xb0)
struct UMaterialExpressionStrataHairBSDF : UMaterialExpressionStrataBSDF {
	struct FExpressionInput BaseColor; // 0xb0(0x28)
	struct FExpressionInput Scatter; // 0xd8(0x28)
	struct FExpressionInput Specular; // 0x100(0x28)
	struct FExpressionInput Roughness; // 0x128(0x28)
	struct FExpressionInput Backlit; // 0x150(0x28)
	struct FExpressionInput Tangent; // 0x178(0x28)
	struct FExpressionInput EmissiveColor; // 0x1a0(0x28)
};

// Class Engine.MaterialExpressionStrataEyeBSDF
// Size: 0x1f8 (Inherited: 0xb0)
struct UMaterialExpressionStrataEyeBSDF : UMaterialExpressionStrataBSDF {
	struct FExpressionInput DiffuseColor; // 0xb0(0x28)
	struct FExpressionInput Roughness; // 0xd8(0x28)
	struct FExpressionInput CorneaNormal; // 0x100(0x28)
	struct FExpressionInput IrisNormal; // 0x128(0x28)
	struct FExpressionInput IrisPlaneNormal; // 0x150(0x28)
	struct FExpressionInput IrisMask; // 0x178(0x28)
	struct FExpressionInput IrisDistance; // 0x1a0(0x28)
	struct FExpressionInput EmissiveColor; // 0x1c8(0x28)
	struct USubsurfaceProfile* SubsurfaceProfile; // 0x1f0(0x08)
};

// Class Engine.MaterialExpressionStrataSingleLayerWaterBSDF
// Size: 0x268 (Inherited: 0xb0)
struct UMaterialExpressionStrataSingleLayerWaterBSDF : UMaterialExpressionStrataBSDF {
	struct FExpressionInput BaseColor; // 0xb0(0x28)
	struct FExpressionInput Metallic; // 0xd8(0x28)
	struct FExpressionInput Specular; // 0x100(0x28)
	struct FExpressionInput Roughness; // 0x128(0x28)
	struct FExpressionInput Normal; // 0x150(0x28)
	struct FExpressionInput EmissiveColor; // 0x178(0x28)
	struct FExpressionInput TopMaterialOpacity; // 0x1a0(0x28)
	struct FExpressionInput WaterAlbedo; // 0x1c8(0x28)
	struct FExpressionInput WaterExtinction; // 0x1f0(0x28)
	struct FExpressionInput WaterPhaseG; // 0x218(0x28)
	struct FExpressionInput ColorScaleBehindWater; // 0x240(0x28)
};

// Class Engine.MaterialExpressionStrataLightFunction
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionStrataLightFunction : UMaterialExpressionStrataBSDF {
	struct FExpressionInput Color; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionStrataPostProcess
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionStrataPostProcess : UMaterialExpressionStrataBSDF {
	struct FExpressionInput Color; // 0xb0(0x28)
	struct FExpressionInput Opacity; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionStrataConvertToDecal
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionStrataConvertToDecal : UMaterialExpressionStrataBSDF {
	struct FExpressionInput DecalMaterial; // 0xb0(0x28)
	struct FExpressionInput Coverage; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionStrataHorizontalMixing
// Size: 0x130 (Inherited: 0xb0)
struct UMaterialExpressionStrataHorizontalMixing : UMaterialExpressionStrataBSDF {
	struct FExpressionInput Background; // 0xb0(0x28)
	struct FExpressionInput Foreground; // 0xd8(0x28)
	struct FExpressionInput Mix; // 0x100(0x28)
	char bUseParameterBlending : 1; // 0x128(0x01)
	char pad_128_1 : 7; // 0x128(0x01)
	char pad_129[0x7]; // 0x129(0x07)
};

// Class Engine.MaterialExpressionStrataVerticalLayering
// Size: 0x108 (Inherited: 0xb0)
struct UMaterialExpressionStrataVerticalLayering : UMaterialExpressionStrataBSDF {
	struct FExpressionInput Top; // 0xb0(0x28)
	struct FExpressionInput Base; // 0xd8(0x28)
	char bUseParameterBlending : 1; // 0x100(0x01)
	char pad_100_1 : 7; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
};

// Class Engine.MaterialExpressionStrataAdd
// Size: 0x108 (Inherited: 0xb0)
struct UMaterialExpressionStrataAdd : UMaterialExpressionStrataBSDF {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	char bUseParameterBlending : 1; // 0x100(0x01)
	char pad_100_1 : 7; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
};

// Class Engine.MaterialExpressionStrataWeight
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionStrataWeight : UMaterialExpressionStrataBSDF {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput Weight; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionStrataThinFilm
// Size: 0x128 (Inherited: 0xb0)
struct UMaterialExpressionStrataThinFilm : UMaterialExpressionStrataBSDF {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput Thickness; // 0xd8(0x28)
	struct FExpressionInput IOR; // 0x100(0x28)
};

// Class Engine.MaterialExpressionStrataUtilityBase
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionStrataUtilityBase : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionStrataTransmittanceToMFP
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionStrataTransmittanceToMFP : UMaterialExpressionStrataUtilityBase {
	struct FExpressionInput TransmittanceColor; // 0xb0(0x28)
	struct FExpressionInput Thickness; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionStrataMetalnessToDiffuseAlbedoF0
// Size: 0x128 (Inherited: 0xb0)
struct UMaterialExpressionStrataMetalnessToDiffuseAlbedoF0 : UMaterialExpressionStrataUtilityBase {
	struct FExpressionInput BaseColor; // 0xb0(0x28)
	struct FExpressionInput Metallic; // 0xd8(0x28)
	struct FExpressionInput Specular; // 0x100(0x28)
};

// Class Engine.MaterialExpressionStrataHazinessToSecondaryRoughness
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionStrataHazinessToSecondaryRoughness : UMaterialExpressionStrataUtilityBase {
	struct FExpressionInput BaseRoughness; // 0xb0(0x28)
	struct FExpressionInput Haziness; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionSubtract
// Size: 0x108 (Inherited: 0xb0)
struct UMaterialExpressionSubtract : UMaterialExpression {
	struct FExpressionInput A; // 0xb0(0x28)
	struct FExpressionInput B; // 0xd8(0x28)
	float ConstA; // 0x100(0x04)
	float ConstB; // 0x104(0x04)
};

// Class Engine.MaterialExpressionTangent
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionTangent : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
	float Period; // 0xd8(0x04)
	char pad_DC[0x4]; // 0xdc(0x04)
};

// Class Engine.MaterialExpressionTangentOutput
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionTangentOutput : UMaterialExpressionCustomOutput {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionTemporalSobol
// Size: 0x118 (Inherited: 0xb0)
struct UMaterialExpressionTemporalSobol : UMaterialExpression {
	struct FExpressionInput Index; // 0xb0(0x28)
	struct FExpressionInput Seed; // 0xd8(0x28)
	uint32_t ConstIndex; // 0x100(0x04)
	char pad_104[0x4]; // 0x104(0x04)
	struct FVector2D ConstSeed; // 0x108(0x10)
};

// Class Engine.MaterialExpressionTextureCoordinate
// Size: 0xc0 (Inherited: 0xb0)
struct UMaterialExpressionTextureCoordinate : UMaterialExpression {
	int32_t CoordinateIndex; // 0xb0(0x04)
	float UTiling; // 0xb4(0x04)
	float VTiling; // 0xb8(0x04)
	char UnMirrorU : 1; // 0xbc(0x01)
	char UnMirrorV : 1; // 0xbc(0x01)
	char pad_BC_2 : 6; // 0xbc(0x01)
	char pad_BD[0x3]; // 0xbd(0x03)
};

// Class Engine.MaterialExpressionTextureObject
// Size: 0xc0 (Inherited: 0xc0)
struct UMaterialExpressionTextureObject : UMaterialExpressionTextureBase {
	struct UTexture* Texture; // 0xb0(0x08)
	enum class EMaterialSamplerType SamplerType; // 0xb8(0x01)
	char IsDefaultMeshpaintTexture : 1; // 0xb9(0x01)
};

// Class Engine.MaterialExpressionTextureObjectParameter
// Size: 0x240 (Inherited: 0x240)
struct UMaterialExpressionTextureObjectParameter : UMaterialExpressionTextureSampleParameter {
	struct FName ParameterName; // 0x1b8(0x08)
	struct FGuid ExpressionGUID; // 0x1c0(0x10)
	struct FName Group; // 0x1d0(0x08)
	int32_t SortPriority; // 0x1d8(0x04)
	struct FParameterChannelNames ChannelNames; // 0x1e0(0x60)
};

// Class Engine.MaterialExpressionTextureProperty
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionTextureProperty : UMaterialExpression {
	struct FExpressionInput TextureObject; // 0xb0(0x28)
	enum class EMaterialExposedTextureProperty Property; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
};

// Class Engine.MaterialExpressionTextureSampleParameter2DArray
// Size: 0x240 (Inherited: 0x240)
struct UMaterialExpressionTextureSampleParameter2DArray : UMaterialExpressionTextureSampleParameter {
	struct FName ParameterName; // 0x1b8(0x08)
	struct FGuid ExpressionGUID; // 0x1c0(0x10)
	struct FName Group; // 0x1d0(0x08)
	int32_t SortPriority; // 0x1d8(0x04)
	struct FParameterChannelNames ChannelNames; // 0x1e0(0x60)
};

// Class Engine.MaterialExpressionTextureSampleParameterCube
// Size: 0x240 (Inherited: 0x240)
struct UMaterialExpressionTextureSampleParameterCube : UMaterialExpressionTextureSampleParameter {
	struct FName ParameterName; // 0x1b8(0x08)
	struct FGuid ExpressionGUID; // 0x1c0(0x10)
	struct FName Group; // 0x1d0(0x08)
	int32_t SortPriority; // 0x1d8(0x04)
	struct FParameterChannelNames ChannelNames; // 0x1e0(0x60)
};

// Class Engine.MaterialExpressionTextureSampleParameterCubeArray
// Size: 0x240 (Inherited: 0x240)
struct UMaterialExpressionTextureSampleParameterCubeArray : UMaterialExpressionTextureSampleParameter {
	struct FName ParameterName; // 0x1b8(0x08)
	struct FGuid ExpressionGUID; // 0x1c0(0x10)
	struct FName Group; // 0x1d0(0x08)
	int32_t SortPriority; // 0x1d8(0x04)
	struct FParameterChannelNames ChannelNames; // 0x1e0(0x60)
};

// Class Engine.MaterialExpressionTextureSampleParameterSubUV
// Size: 0x248 (Inherited: 0x240)
struct UMaterialExpressionTextureSampleParameterSubUV : UMaterialExpressionTextureSampleParameter2D {
	char bBlend : 1; // 0x240(0x01)
	char pad_240_1 : 7; // 0x240(0x01)
	char pad_241[0x7]; // 0x241(0x07)
};

// Class Engine.MaterialExpressionTextureSampleParameterVolume
// Size: 0x240 (Inherited: 0x240)
struct UMaterialExpressionTextureSampleParameterVolume : UMaterialExpressionTextureSampleParameter {
	struct FName ParameterName; // 0x1b8(0x08)
	struct FGuid ExpressionGUID; // 0x1c0(0x10)
	struct FName Group; // 0x1d0(0x08)
	int32_t SortPriority; // 0x1d8(0x04)
	struct FParameterChannelNames ChannelNames; // 0x1e0(0x60)
};

// Class Engine.MaterialExpressionThinTranslucentMaterialOutput
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionThinTranslucentMaterialOutput : UMaterialExpressionCustomOutput {
	struct FExpressionInput TransmittanceColor; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionTime
// Size: 0xb8 (Inherited: 0xb0)
struct UMaterialExpressionTime : UMaterialExpression {
	char bIgnorePause : 1; // 0xb0(0x01)
	char bOverride_Period : 1; // 0xb0(0x01)
	char pad_B0_2 : 6; // 0xb0(0x01)
	char pad_B1[0x3]; // 0xb1(0x03)
	float Period; // 0xb4(0x04)
};

// Class Engine.MaterialExpressionTransform
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionTransform : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
	enum class EMaterialVectorCoordTransformSource TransformSourceType; // 0xd8(0x01)
	enum class EMaterialVectorCoordTransform TransformType; // 0xd9(0x01)
	char pad_DA[0x6]; // 0xda(0x06)
};

// Class Engine.MaterialExpressionTransformPosition
// Size: 0xe0 (Inherited: 0xb0)
struct UMaterialExpressionTransformPosition : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
	enum class EMaterialPositionTransformSource TransformSourceType; // 0xd8(0x01)
	enum class EMaterialPositionTransformSource TransformType; // 0xd9(0x01)
	char pad_DA[0x6]; // 0xda(0x06)
};

// Class Engine.MaterialExpressionTruncate
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionTruncate : UMaterialExpression {
	struct FExpressionInput Input; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionTwoSidedSign
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionTwoSidedSign : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionVectorNoise
// Size: 0xe8 (Inherited: 0xb0)
struct UMaterialExpressionVectorNoise : UMaterialExpression {
	struct FExpressionInput Position; // 0xb0(0x28)
	enum class EVectorNoiseFunction NoiseFunction; // 0xd8(0x01)
	char pad_D9[0x3]; // 0xd9(0x03)
	int32_t Quality; // 0xdc(0x04)
	char bTiling : 1; // 0xe0(0x01)
	char pad_E0_1 : 7; // 0xe0(0x01)
	char pad_E1[0x3]; // 0xe1(0x03)
	uint32_t TileSize; // 0xe4(0x04)
};

// Class Engine.MaterialExpressionVertexColor
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionVertexColor : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionVertexInterpolator
// Size: 0xe8 (Inherited: 0xb0)
struct UMaterialExpressionVertexInterpolator : UMaterialExpressionCustomOutput {
	struct FExpressionInput Input; // 0xb0(0x28)
	char pad_D8[0x10]; // 0xd8(0x10)
};

// Class Engine.MaterialExpressionVertexNormalWS
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionVertexNormalWS : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionVertexTangentWS
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionVertexTangentWS : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionViewProperty
// Size: 0xb8 (Inherited: 0xb0)
struct UMaterialExpressionViewProperty : UMaterialExpression {
	enum class EMaterialExposedViewProperty Property; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
};

// Class Engine.MaterialExpressionViewSize
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionViewSize : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionVirtualTextureFeatureSwitch
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialExpressionVirtualTextureFeatureSwitch : UMaterialExpression {
	struct FExpressionInput No; // 0xb0(0x28)
	struct FExpressionInput Yes; // 0xd8(0x28)
};

// Class Engine.MaterialExpressionVolumetricAdvancedMaterialInput
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionVolumetricAdvancedMaterialInput : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionVolumetricCloudEmptySpaceSkippingInput
// Size: 0xb0 (Inherited: 0xb0)
struct UMaterialExpressionVolumetricCloudEmptySpaceSkippingInput : UMaterialExpression {
	int32_t MaterialExpressionEditorX; // 0x28(0x04)
	int32_t MaterialExpressionEditorY; // 0x2c(0x04)
	struct UEdGraphNode* GraphNode; // 0x30(0x08)
	struct UMaterialExpression* SubgraphExpression; // 0x38(0x08)
	struct FGuid MaterialExpressionGuid; // 0x50(0x10)
	struct UMaterial* Material; // 0x60(0x08)
	struct UMaterialFunction* Function; // 0x68(0x08)
	struct FString Desc; // 0x70(0x10)
	char bRealtimePreview : 1; // 0x84(0x01)
	char bNeedToUpdatePreview : 1; // 0x84(0x01)
	char bIsParameterExpression : 1; // 0x88(0x01)
	char bCommentBubbleVisible : 1; // 0x8c(0x01)
	char bShowOutputNameOnPin : 1; // 0x8c(0x01)
	char bShowMaskColorsOnPin : 1; // 0x8c(0x01)
	char bHidePreviewWindow : 1; // 0x8c(0x01)
	char bCollapsed : 1; // 0x8c(0x01)
	char pad_F9_0 : 5; // 0xf9(0x01)
	char bShaderInputData : 1; // 0x8c(0x01)
	char bShowInputs : 1; // 0x8c(0x01)
	char bShowOutputs : 1; // 0x8c(0x01)
	struct TArray<struct FText> MenuCategories; // 0x90(0x10)
	struct TArray<struct FExpressionOutput> Outputs; // 0xa0(0x10)
};

// Class Engine.MaterialExpressionVolumetricAdvancedMaterialOutput
// Size: 0x1f0 (Inherited: 0xb0)
struct UMaterialExpressionVolumetricAdvancedMaterialOutput : UMaterialExpressionCustomOutput {
	struct FExpressionInput PhaseG; // 0xb0(0x28)
	struct FExpressionInput PhaseG2; // 0xd8(0x28)
	struct FExpressionInput PhaseBlend; // 0x100(0x28)
	struct FExpressionInput MultiScatteringContribution; // 0x128(0x28)
	struct FExpressionInput MultiScatteringOcclusion; // 0x150(0x28)
	struct FExpressionInput MultiScatteringEccentricity; // 0x178(0x28)
	struct FExpressionInput ConservativeDensity; // 0x1a0(0x28)
	float ConstPhaseG; // 0x1c8(0x04)
	float ConstPhaseG2; // 0x1cc(0x04)
	float ConstPhaseBlend; // 0x1d0(0x04)
	bool PerSamplePhaseEvaluation; // 0x1d4(0x01)
	char pad_1D5[0x3]; // 0x1d5(0x03)
	uint32_t MultiScatteringApproximationOctaveCount; // 0x1d8(0x04)
	float ConstMultiScatteringContribution; // 0x1dc(0x04)
	float ConstMultiScatteringOcclusion; // 0x1e0(0x04)
	float ConstMultiScatteringEccentricity; // 0x1e4(0x04)
	bool bGroundContribution; // 0x1e8(0x01)
	bool bGrayScaleMaterial; // 0x1e9(0x01)
	bool bRayMarchVolumeShadow; // 0x1ea(0x01)
	bool bClampMultiScatteringContribution; // 0x1eb(0x01)
	char pad_1EC[0x4]; // 0x1ec(0x04)
};

// Class Engine.MaterialExpressionVolumetricCloudEmptySpaceSkippingOutput
// Size: 0xd8 (Inherited: 0xb0)
struct UMaterialExpressionVolumetricCloudEmptySpaceSkippingOutput : UMaterialExpressionCustomOutput {
	struct FExpressionInput ContainsMatter; // 0xb0(0x28)
};

// Class Engine.MaterialExpressionWhileLoop
// Size: 0xe8 (Inherited: 0xb0)
struct UMaterialExpressionWhileLoop : UMaterialExpression {
	struct FExpressionExecOutput LoopBody; // 0xb0(0x08)
	struct FExpressionExecOutput Completed; // 0xb8(0x08)
	struct FExpressionInput Condition; // 0xc0(0x28)
};

// Class Engine.MaterialExpressionWorldPosition
// Size: 0xb8 (Inherited: 0xb0)
struct UMaterialExpressionWorldPosition : UMaterialExpression {
	enum class EWorldPositionIncludedOffsets WorldPositionShaderOffset; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
};

// Class Engine.MaterialFunctionInterfaceEditorOnlyData
// Size: 0x28 (Inherited: 0x28)
struct UMaterialFunctionInterfaceEditorOnlyData : UObject {
};

// Class Engine.MaterialFunctionEditorOnlyData
// Size: 0x58 (Inherited: 0x28)
struct UMaterialFunctionEditorOnlyData : UMaterialFunctionInterfaceEditorOnlyData {
	struct FMaterialExpressionCollection ExpressionCollection; // 0x28(0x30)
};

// Class Engine.MaterialFunctionInterface
// Size: 0x40 (Inherited: 0x28)
struct UMaterialFunctionInterface : UObject {
	struct FGuid StateId; // 0x28(0x10)
	enum class EMaterialFunctionUsage MaterialFunctionUsage; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// Class Engine.MaterialFunction
// Size: 0x58 (Inherited: 0x40)
struct UMaterialFunction : UMaterialFunctionInterface {
	struct FString Description; // 0x40(0x10)
	char bExposeToLibrary : 1; // 0x50(0x01)
	char bPrefixParameterNames : 1; // 0x50(0x01)
	char bEnableExecWire : 1; // 0x50(0x01)
	char bEnableNewHLSLGenerator : 1; // 0x50(0x01)
	char pad_50_4 : 4; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
};

// Class Engine.MaterialFunctionInstance
// Size: 0xd0 (Inherited: 0x40)
struct UMaterialFunctionInstance : UMaterialFunctionInterface {
	struct UMaterialFunctionInterface* Parent; // 0x40(0x08)
	struct UMaterialFunctionInterface* Base; // 0x48(0x08)
	struct TArray<struct FScalarParameterValue> ScalarParameterValues; // 0x50(0x10)
	struct TArray<struct FVectorParameterValue> VectorParameterValues; // 0x60(0x10)
	struct TArray<struct FDoubleVectorParameterValue> DoubleVectorParameterValues; // 0x70(0x10)
	struct TArray<struct FTextureParameterValue> TextureParameterValues; // 0x80(0x10)
	struct TArray<struct FFontParameterValue> FontParameterValues; // 0x90(0x10)
	struct TArray<struct FStaticSwitchParameter> StaticSwitchParameterValues; // 0xa0(0x10)
	struct TArray<struct FStaticComponentMaskParameter> StaticComponentMaskParameterValues; // 0xb0(0x10)
	struct TArray<struct FRuntimeVirtualTextureParameterValue> RuntimeVirtualTextureParameterValues; // 0xc0(0x10)
};

// Class Engine.MaterialFunctionMaterialLayer
// Size: 0x58 (Inherited: 0x58)
struct UMaterialFunctionMaterialLayer : UMaterialFunction {
	struct FString Description; // 0x40(0x10)
	char bExposeToLibrary : 1; // 0x50(0x01)
	char bPrefixParameterNames : 1; // 0x50(0x01)
	char bEnableExecWire : 1; // 0x50(0x01)
	char bEnableNewHLSLGenerator : 1; // 0x50(0x01)
};

// Class Engine.MaterialFunctionMaterialLayerInstance
// Size: 0xd0 (Inherited: 0xd0)
struct UMaterialFunctionMaterialLayerInstance : UMaterialFunctionInstance {
	struct UMaterialFunctionInterface* Parent; // 0x40(0x08)
	struct UMaterialFunctionInterface* Base; // 0x48(0x08)
	struct TArray<struct FScalarParameterValue> ScalarParameterValues; // 0x50(0x10)
	struct TArray<struct FVectorParameterValue> VectorParameterValues; // 0x60(0x10)
	struct TArray<struct FDoubleVectorParameterValue> DoubleVectorParameterValues; // 0x70(0x10)
	struct TArray<struct FTextureParameterValue> TextureParameterValues; // 0x80(0x10)
	struct TArray<struct FFontParameterValue> FontParameterValues; // 0x90(0x10)
	struct TArray<struct FStaticSwitchParameter> StaticSwitchParameterValues; // 0xa0(0x10)
	struct TArray<struct FStaticComponentMaskParameter> StaticComponentMaskParameterValues; // 0xb0(0x10)
	struct TArray<struct FRuntimeVirtualTextureParameterValue> RuntimeVirtualTextureParameterValues; // 0xc0(0x10)
};

// Class Engine.MaterialFunctionMaterialLayerBlend
// Size: 0x58 (Inherited: 0x58)
struct UMaterialFunctionMaterialLayerBlend : UMaterialFunction {
	struct FString Description; // 0x40(0x10)
	char bExposeToLibrary : 1; // 0x50(0x01)
	char bPrefixParameterNames : 1; // 0x50(0x01)
	char bEnableExecWire : 1; // 0x50(0x01)
	char bEnableNewHLSLGenerator : 1; // 0x50(0x01)
};

// Class Engine.MaterialFunctionMaterialLayerBlendInstance
// Size: 0xd0 (Inherited: 0xd0)
struct UMaterialFunctionMaterialLayerBlendInstance : UMaterialFunctionInstance {
	struct UMaterialFunctionInterface* Parent; // 0x40(0x08)
	struct UMaterialFunctionInterface* Base; // 0x48(0x08)
	struct TArray<struct FScalarParameterValue> ScalarParameterValues; // 0x50(0x10)
	struct TArray<struct FVectorParameterValue> VectorParameterValues; // 0x60(0x10)
	struct TArray<struct FDoubleVectorParameterValue> DoubleVectorParameterValues; // 0x70(0x10)
	struct TArray<struct FTextureParameterValue> TextureParameterValues; // 0x80(0x10)
	struct TArray<struct FFontParameterValue> FontParameterValues; // 0x90(0x10)
	struct TArray<struct FStaticSwitchParameter> StaticSwitchParameterValues; // 0xa0(0x10)
	struct TArray<struct FStaticComponentMaskParameter> StaticComponentMaskParameterValues; // 0xb0(0x10)
	struct TArray<struct FRuntimeVirtualTextureParameterValue> RuntimeVirtualTextureParameterValues; // 0xc0(0x10)
};

// Class Engine.MaterialParameterCollection
// Size: 0x70 (Inherited: 0x28)
struct UMaterialParameterCollection : UObject {
	struct FGuid StateId; // 0x28(0x10)
	struct TArray<struct FCollectionScalarParameter> ScalarParameters; // 0x38(0x10)
	struct TArray<struct FCollectionVectorParameter> VectorParameters; // 0x48(0x10)
	char pad_58[0x18]; // 0x58(0x18)

	struct TArray<struct FName> GetVectorParameterNames(); // Function Engine.MaterialParameterCollection.GetVectorParameterNames // (None) // @ game+0xffffca55df830041
};

// Class Engine.MaterialParameterCollectionInstance
// Size: 0x120 (Inherited: 0x28)
struct UMaterialParameterCollectionInstance : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct UMaterialParameterCollection* Collection; // 0x30(0x08)
	char pad_38[0xe8]; // 0x38(0xe8)
};

// Class Engine.MeshDeformer
// Size: 0x28 (Inherited: 0x28)
struct UMeshDeformer : UObject {
};

// Class Engine.MeshDeformerInstanceSettings
// Size: 0x28 (Inherited: 0x28)
struct UMeshDeformerInstanceSettings : UObject {
};

// Class Engine.MeshDeformerInstance
// Size: 0x28 (Inherited: 0x28)
struct UMeshDeformerInstance : UObject {
};

// Class Engine.MicroTransactionBase
// Size: 0x68 (Inherited: 0x38)
struct UMicroTransactionBase : UPlatformInterfaceBase {
	struct TArray<struct FPurchaseInfo> AvailableProducts; // 0x38(0x10)
	struct FString LastError; // 0x48(0x10)
	struct FString LastErrorSolution; // 0x58(0x10)
};

// Class Engine.MorphTarget
// Size: 0x40 (Inherited: 0x28)
struct UMorphTarget : UObject {
	struct USkeletalMesh* BaseSkelMesh; // 0x28(0x08)
	char pad_30[0x10]; // 0x30(0x10)
};

// Class Engine.NavAgentInterface
// Size: 0x28 (Inherited: 0x28)
struct UNavAgentInterface : UInterface {
};

// Class Engine.NavAreaBase
// Size: 0x30 (Inherited: 0x28)
struct UNavAreaBase : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.NavEdgeProviderInterface
// Size: 0x28 (Inherited: 0x28)
struct UNavEdgeProviderInterface : UInterface {
};

// Class Engine.NavigationDataInterface
// Size: 0x28 (Inherited: 0x28)
struct UNavigationDataInterface : UInterface {
};

// Class Engine.NavLinkDefinition
// Size: 0x50 (Inherited: 0x28)
struct UNavLinkDefinition : UObject {
	struct TArray<struct FNavigationLink> Links; // 0x28(0x10)
	struct TArray<struct FNavigationSegmentLink> SegmentLinks; // 0x38(0x10)
	char pad_48[0x8]; // 0x48(0x08)
};

// Class Engine.NavPathObserverInterface
// Size: 0x28 (Inherited: 0x28)
struct UNavPathObserverInterface : UInterface {
};

// Class Engine.NavRelevantInterface
// Size: 0x28 (Inherited: 0x28)
struct UNavRelevantInterface : UInterface {
};

// Class Engine.NetworkPredictionInterface
// Size: 0x28 (Inherited: 0x28)
struct UNetworkPredictionInterface : UInterface {
};

// Class Engine.ParticleEmitter
// Size: 0x1c0 (Inherited: 0x28)
struct UParticleEmitter : UObject {
	struct FName EmitterName; // 0x28(0x08)
	int32_t SubUVDataOffset; // 0x30(0x04)
	enum class EEmitterRenderMode EmitterRenderMode; // 0x34(0x01)
	enum class EParticleSignificanceLevel SignificanceLevel; // 0x35(0x01)
	char pad_36[0x1]; // 0x36(0x01)
	char bUseLegacySpawningBehavior : 1; // 0x37(0x01)
	char pad_37_1 : 3; // 0x37(0x01)
	char ConvertedModules : 1; // 0x37(0x01)
	char bIsSoloing : 1; // 0x37(0x01)
	char bCookedOut : 1; // 0x37(0x01)
	char bDisabledLODsKeepEmitterAlive : 1; // 0x37(0x01)
	char bDisableWhenInsignficant : 1; // 0x38(0x01)
	char pad_38_1 : 7; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct TArray<struct UParticleLODLevel*> LODLevels; // 0x40(0x10)
	int32_t PeakActiveParticles; // 0x50(0x04)
	int32_t InitialAllocationCount; // 0x54(0x04)
	float QualityLevelSpawnRateScale; // 0x58(0x04)
	uint32_t DetailModeBitmask; // 0x5c(0x04)
	char pad_60[0x160]; // 0x60(0x160)
};

// Class Engine.ParticleLODLevel
// Size: 0xb8 (Inherited: 0x28)
struct UParticleLODLevel : UObject {
	int32_t Level; // 0x28(0x04)
	char bEnabled : 1; // 0x2c(0x01)
	char pad_2C_1 : 7; // 0x2c(0x01)
	char pad_2D[0x3]; // 0x2d(0x03)
	struct UParticleModuleRequired* RequiredModule; // 0x30(0x08)
	struct TArray<struct UParticleModule*> Modules; // 0x38(0x10)
	struct UParticleModuleTypeDataBase* TypeDataModule; // 0x48(0x08)
	struct UParticleModuleSpawn* SpawnModule; // 0x50(0x08)
	struct UParticleModuleEventGenerator* EventGenerator; // 0x58(0x08)
	struct TArray<struct UParticleModuleSpawnBase*> SpawningModules; // 0x60(0x10)
	struct TArray<struct UParticleModule*> SpawnModules; // 0x70(0x10)
	struct TArray<struct UParticleModule*> UpdateModules; // 0x80(0x10)
	struct TArray<struct UParticleModuleOrbit*> OrbitModules; // 0x90(0x10)
	struct TArray<struct UParticleModuleEventReceiverBase*> EventReceiverModules; // 0xa0(0x10)
	char ConvertedModules : 1; // 0xb0(0x01)
	char pad_B0_1 : 7; // 0xb0(0x01)
	char pad_B1[0x3]; // 0xb1(0x03)
	int32_t PeakActiveParticles; // 0xb4(0x04)
};

// Class Engine.ParticleSystem
// Size: 0x158 (Inherited: 0x30)
struct UParticleSystem : UFXSystemAsset {
	float UpdateTime_FPS; // 0x30(0x04)
	float UpdateTime_Delta; // 0x34(0x04)
	float WarmupTime; // 0x38(0x04)
	float WarmupTickRate; // 0x3c(0x04)
	struct TArray<struct UParticleEmitter*> Emitters; // 0x40(0x10)
	struct UParticleSystemComponent* PreviewComponent; // 0x50(0x08)
	struct UInterpCurveEdSetup* CurveEdSetup; // 0x58(0x08)
	float LODDistanceCheckTime; // 0x60(0x04)
	float MacroUVRadius; // 0x64(0x04)
	struct TArray<float> LODDistances; // 0x68(0x10)
	struct TArray<struct FParticleSystemLOD> LODSettings; // 0x78(0x10)
	struct FBox FixedRelativeBoundingBox; // 0x88(0x38)
	float SecondsBeforeInactive; // 0xc0(0x04)
	float Delay; // 0xc4(0x04)
	float DelayLow; // 0xc8(0x04)
	char bOrientZAxisTowardCamera : 1; // 0xcc(0x01)
	char bUseFixedRelativeBoundingBox : 1; // 0xcc(0x01)
	char bShouldResetPeakCounts : 1; // 0xcc(0x01)
	char bHasPhysics : 1; // 0xcc(0x01)
	char bUseRealtimeThumbnail : 1; // 0xcc(0x01)
	char ThumbnailImageOutOfDate : 1; // 0xcc(0x01)
	char pad_CC_6 : 2; // 0xcc(0x01)
	char bUseDelayRange : 1; // 0xcd(0x01)
	char bAllowManagedTicking : 1; // 0xcd(0x01)
	char bAutoDeactivate : 1; // 0xcd(0x01)
	char bRegenerateLODDuplicate : 1; // 0xcd(0x01)
	char pad_CD_4 : 4; // 0xcd(0x01)
	enum class EParticleSystemUpdateMode SystemUpdateMode; // 0xce(0x01)
	enum class ParticleSystemLODMethod LODMethod; // 0xcf(0x01)
	enum class EParticleSystemInsignificanceReaction InsignificantReaction; // 0xd0(0x01)
	enum class EParticleSystemOcclusionBoundsMethod OcclusionBoundsMethod; // 0xd1(0x01)
	char pad_D2[0x1]; // 0xd2(0x01)
	enum class EParticleSignificanceLevel MaxSignificanceLevel; // 0xd3(0x01)
	uint32_t MinTimeBetweenTicks; // 0xd4(0x04)
	float InsignificanceDelay; // 0xd8(0x04)
	char pad_DC[0x4]; // 0xdc(0x04)
	struct FVector MacroUVPosition; // 0xe0(0x18)
	struct FBox CustomOcclusionBounds; // 0xf8(0x38)
	struct TArray<struct FLODSoloTrack> SoloTracking; // 0x130(0x10)
	struct TArray<struct FNamedEmitterMaterial> NamedMaterialSlots; // 0x140(0x10)
	char pad_150[0x8]; // 0x150(0x08)

	bool ContainsEmitterType(struct UObject* TypeData); // Function Engine.ParticleSystem.ContainsEmitterType // (None) // @ game+0xffffca56df830041
};

// Class Engine.ParticleModule
// Size: 0x30 (Inherited: 0x28)
struct UParticleModule : UObject {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char pad_29_4 : 4; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
	char pad_2B[0x5]; // 0x2b(0x05)
};

// Class Engine.ParticleModuleAccelerationBase
// Size: 0x38 (Inherited: 0x30)
struct UParticleModuleAccelerationBase : UParticleModule {
	char bAlwaysInWorldSpace : 1; // 0x30(0x01)
	char pad_30_1 : 7; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// Class Engine.ParticleModuleAcceleration
// Size: 0xa0 (Inherited: 0x38)
struct UParticleModuleAcceleration : UParticleModuleAccelerationBase {
	struct FRawDistributionVector Acceleration; // 0x38(0x60)
	char bApplyOwnerScale : 1; // 0x98(0x01)
	char pad_98_1 : 7; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
};

// Class Engine.ParticleModuleAccelerationConstant
// Size: 0x50 (Inherited: 0x38)
struct UParticleModuleAccelerationConstant : UParticleModuleAccelerationBase {
	struct FVector Acceleration; // 0x38(0x18)
};

// Class Engine.ParticleModuleAccelerationDrag
// Size: 0x70 (Inherited: 0x38)
struct UParticleModuleAccelerationDrag : UParticleModuleAccelerationBase {
	struct UDistributionFloat* DragCoefficient; // 0x38(0x08)
	struct FRawDistributionFloat DragCoefficientRaw; // 0x40(0x30)
};

// Class Engine.ParticleModuleAccelerationDragScaleOverLife
// Size: 0x70 (Inherited: 0x38)
struct UParticleModuleAccelerationDragScaleOverLife : UParticleModuleAccelerationBase {
	struct UDistributionFloat* DragScale; // 0x38(0x08)
	struct FRawDistributionFloat DragScaleRaw; // 0x40(0x30)
};

// Class Engine.ParticleModuleAccelerationOverLifetime
// Size: 0x98 (Inherited: 0x38)
struct UParticleModuleAccelerationOverLifetime : UParticleModuleAccelerationBase {
	struct FRawDistributionVector AccelOverLife; // 0x38(0x60)
};

// Class Engine.ParticleModuleAttractorBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleAttractorBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleAttractorLine
// Size: 0xc0 (Inherited: 0x30)
struct UParticleModuleAttractorLine : UParticleModuleAttractorBase {
	struct FVector EndPoint0; // 0x30(0x18)
	struct FVector EndPoint1; // 0x48(0x18)
	struct FRawDistributionFloat Range; // 0x60(0x30)
	struct FRawDistributionFloat Strength; // 0x90(0x30)
};

// Class Engine.ParticleModuleAttractorParticle
// Size: 0xb0 (Inherited: 0x30)
struct UParticleModuleAttractorParticle : UParticleModuleAttractorBase {
	struct FName EmitterName; // 0x30(0x08)
	struct FRawDistributionFloat Range; // 0x38(0x30)
	char bStrengthByDistance : 1; // 0x68(0x01)
	char pad_68_1 : 7; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
	struct FRawDistributionFloat Strength; // 0x70(0x30)
	char bAffectBaseVelocity : 1; // 0xa0(0x01)
	char pad_A0_1 : 7; // 0xa0(0x01)
	char pad_A1[0x3]; // 0xa1(0x03)
	enum class EAttractorParticleSelectionMethod SelectionMethod; // 0xa4(0x01)
	char pad_A5[0x3]; // 0xa5(0x03)
	char bRenewSource : 1; // 0xa8(0x01)
	char bInheritSourceVel : 1; // 0xa8(0x01)
	char pad_A8_2 : 6; // 0xa8(0x01)
	char pad_A9[0x3]; // 0xa9(0x03)
	int32_t LastSelIndex; // 0xac(0x04)
};

// Class Engine.ParticleModuleAttractorPoint
// Size: 0xf8 (Inherited: 0x30)
struct UParticleModuleAttractorPoint : UParticleModuleAttractorBase {
	struct FRawDistributionVector Position; // 0x30(0x60)
	struct FRawDistributionFloat Range; // 0x90(0x30)
	struct FRawDistributionFloat Strength; // 0xc0(0x30)
	char StrengthByDistance : 1; // 0xf0(0x01)
	char bAffectBaseVelocity : 1; // 0xf0(0x01)
	char bOverrideVelocity : 1; // 0xf0(0x01)
	char bUseWorldSpacePosition : 1; // 0xf0(0x01)
	char Positive_X : 1; // 0xf0(0x01)
	char Positive_Y : 1; // 0xf0(0x01)
	char Positive_Z : 1; // 0xf0(0x01)
	char Negative_X : 1; // 0xf0(0x01)
	char Negative_Y : 1; // 0xf1(0x01)
	char Negative_Z : 1; // 0xf1(0x01)
	char pad_F1_2 : 6; // 0xf1(0x01)
	char pad_F2[0x6]; // 0xf2(0x06)
};

// Class Engine.ParticleModuleAttractorPointGravity
// Size: 0x88 (Inherited: 0x30)
struct UParticleModuleAttractorPointGravity : UParticleModuleAttractorBase {
	struct FVector Position; // 0x30(0x18)
	float Radius; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct UDistributionFloat* Strength; // 0x50(0x08)
	struct FRawDistributionFloat StrengthRaw; // 0x58(0x30)
};

// Class Engine.ParticleModuleBeamBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleBeamBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleBeamModifier
// Size: 0x138 (Inherited: 0x30)
struct UParticleModuleBeamModifier : UParticleModuleBeamBase {
	enum class BeamModifierType ModifierType; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	struct FBeamModifierOptions PositionOptions; // 0x34(0x04)
	struct FRawDistributionVector Position; // 0x38(0x60)
	struct FBeamModifierOptions TangentOptions; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
	struct FRawDistributionVector Tangent; // 0xa0(0x60)
	char bAbsoluteTangent : 1; // 0x100(0x01)
	char pad_100_1 : 7; // 0x100(0x01)
	char pad_101[0x3]; // 0x101(0x03)
	struct FBeamModifierOptions StrengthOptions; // 0x104(0x04)
	struct FRawDistributionFloat Strength; // 0x108(0x30)
};

// Class Engine.ParticleModuleBeamNoise
// Size: 0x1c0 (Inherited: 0x30)
struct UParticleModuleBeamNoise : UParticleModuleBeamBase {
	char bLowFreq_Enabled : 1; // 0x30(0x01)
	char pad_30_1 : 7; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	int32_t Frequency; // 0x34(0x04)
	int32_t Frequency_LowRange; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FRawDistributionVector NoiseRange; // 0x40(0x60)
	struct FRawDistributionFloat NoiseRangeScale; // 0xa0(0x30)
	char bNRScaleEmitterTime : 1; // 0xd0(0x01)
	char pad_D0_1 : 7; // 0xd0(0x01)
	char pad_D1[0x7]; // 0xd1(0x07)
	struct FRawDistributionVector NoiseSpeed; // 0xd8(0x60)
	char bSmooth : 1; // 0x138(0x01)
	char pad_138_1 : 7; // 0x138(0x01)
	char pad_139[0x3]; // 0x139(0x03)
	float NoiseLockRadius; // 0x13c(0x04)
	char bNoiseLock : 1; // 0x140(0x01)
	char bOscillate : 1; // 0x140(0x01)
	char pad_140_2 : 6; // 0x140(0x01)
	char pad_141[0x3]; // 0x141(0x03)
	float NoiseLockTime; // 0x144(0x04)
	float NoiseTension; // 0x148(0x04)
	char bUseNoiseTangents : 1; // 0x14c(0x01)
	char pad_14C_1 : 7; // 0x14c(0x01)
	char pad_14D[0x3]; // 0x14d(0x03)
	struct FRawDistributionFloat NoiseTangentStrength; // 0x150(0x30)
	int32_t NoiseTessellation; // 0x180(0x04)
	char bTargetNoise : 1; // 0x184(0x01)
	char pad_184_1 : 7; // 0x184(0x01)
	char pad_185[0x3]; // 0x185(0x03)
	float FrequencyDistance; // 0x188(0x04)
	char bApplyNoiseScale : 1; // 0x18c(0x01)
	char pad_18C_1 : 7; // 0x18c(0x01)
	char pad_18D[0x3]; // 0x18d(0x03)
	struct FRawDistributionFloat NoiseScale; // 0x190(0x30)
};

// Class Engine.ParticleModuleBeamSource
// Size: 0x148 (Inherited: 0x30)
struct UParticleModuleBeamSource : UParticleModuleBeamBase {
	enum class Beam2SourceTargetMethod SourceMethod; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	struct FName SourceName; // 0x34(0x08)
	char bSourceAbsolute : 1; // 0x3c(0x01)
	char pad_3C_1 : 7; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
	struct FRawDistributionVector Source; // 0x40(0x60)
	char bLockSource : 1; // 0xa0(0x01)
	char pad_A0_1 : 7; // 0xa0(0x01)
	char pad_A1[0x3]; // 0xa1(0x03)
	enum class Beam2SourceTargetTangentMethod SourceTangentMethod; // 0xa4(0x01)
	char pad_A5[0x3]; // 0xa5(0x03)
	struct FRawDistributionVector SourceTangent; // 0xa8(0x60)
	char bLockSourceTangent : 1; // 0x108(0x01)
	char pad_108_1 : 7; // 0x108(0x01)
	char pad_109[0x7]; // 0x109(0x07)
	struct FRawDistributionFloat SourceStrength; // 0x110(0x30)
	char bLockSourceStength : 1; // 0x140(0x01)
	char pad_140_1 : 7; // 0x140(0x01)
	char pad_141[0x7]; // 0x141(0x07)
};

// Class Engine.ParticleModuleBeamTarget
// Size: 0x150 (Inherited: 0x30)
struct UParticleModuleBeamTarget : UParticleModuleBeamBase {
	enum class Beam2SourceTargetMethod TargetMethod; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	struct FName TargetName; // 0x34(0x08)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FRawDistributionVector Target; // 0x40(0x60)
	char bTargetAbsolute : 1; // 0xa0(0x01)
	char bLockTarget : 1; // 0xa0(0x01)
	char pad_A0_2 : 6; // 0xa0(0x01)
	char pad_A1[0x3]; // 0xa1(0x03)
	enum class Beam2SourceTargetTangentMethod TargetTangentMethod; // 0xa4(0x01)
	char pad_A5[0x3]; // 0xa5(0x03)
	struct FRawDistributionVector TargetTangent; // 0xa8(0x60)
	char bLockTargetTangent : 1; // 0x108(0x01)
	char pad_108_1 : 7; // 0x108(0x01)
	char pad_109[0x7]; // 0x109(0x07)
	struct FRawDistributionFloat TargetStrength; // 0x110(0x30)
	char bLockTargetStength : 1; // 0x140(0x01)
	char pad_140_1 : 7; // 0x140(0x01)
	char pad_141[0x3]; // 0x141(0x03)
	float LockRadius; // 0x144(0x04)
	char pad_148[0x8]; // 0x148(0x08)
};

// Class Engine.ParticleModuleCameraBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleCameraBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleCameraOffset
// Size: 0x68 (Inherited: 0x30)
struct UParticleModuleCameraOffset : UParticleModuleCameraBase {
	struct FRawDistributionFloat CameraOffset; // 0x30(0x30)
	char bSpawnTimeOnly : 1; // 0x60(0x01)
	char pad_60_1 : 7; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	enum class EParticleCameraOffsetUpdateMethod UpdateMethod; // 0x64(0x01)
	char pad_65[0x3]; // 0x65(0x03)
};

// Class Engine.ParticleModuleCollisionBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleCollisionBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleCollision
// Size: 0x1c0 (Inherited: 0x30)
struct UParticleModuleCollision : UParticleModuleCollisionBase {
	struct FRawDistributionVector DampingFactor; // 0x30(0x60)
	struct FRawDistributionVector DampingFactorRotation; // 0x90(0x60)
	struct FRawDistributionFloat MaxCollisions; // 0xf0(0x30)
	enum class EParticleCollisionComplete CollisionCompletionOption; // 0x120(0x01)
	char pad_121[0x7]; // 0x121(0x07)
	struct TArray<enum class EObjectTypeQuery> CollisionTypes; // 0x128(0x10)
	char pad_138[0x8]; // 0x138(0x08)
	char bApplyPhysics : 1; // 0x140(0x01)
	char bIgnoreTriggerVolumes : 1; // 0x140(0x01)
	char pad_140_2 : 6; // 0x140(0x01)
	char pad_141[0x7]; // 0x141(0x07)
	struct FRawDistributionFloat ParticleMass; // 0x148(0x30)
	float DirScalar; // 0x178(0x04)
	char bPawnsDoNotDecrementCount : 1; // 0x17c(0x01)
	char bOnlyVerticalNormalsDecrementCount : 1; // 0x17c(0x01)
	char pad_17C_2 : 6; // 0x17c(0x01)
	char pad_17D[0x3]; // 0x17d(0x03)
	float VerticalFudgeFactor; // 0x180(0x04)
	char pad_184[0x4]; // 0x184(0x04)
	struct FRawDistributionFloat DelayAmount; // 0x188(0x30)
	char bDropDetail : 1; // 0x1b8(0x01)
	char bCollideOnlyIfVisible : 1; // 0x1b8(0x01)
	char bIgnoreSourceActor : 1; // 0x1b8(0x01)
	char pad_1B8_3 : 5; // 0x1b8(0x01)
	char pad_1B9[0x3]; // 0x1b9(0x03)
	float MaxCollisionDistance; // 0x1bc(0x04)
};

// Class Engine.ParticleModuleCollisionGPU
// Size: 0xa8 (Inherited: 0x30)
struct UParticleModuleCollisionGPU : UParticleModuleCollisionBase {
	struct FRawDistributionFloat Resilience; // 0x30(0x30)
	struct FRawDistributionFloat ResilienceScaleOverLife; // 0x60(0x30)
	float Friction; // 0x90(0x04)
	float RandomSpread; // 0x94(0x04)
	float RandomDistribution; // 0x98(0x04)
	float RadiusScale; // 0x9c(0x04)
	float RadiusBias; // 0xa0(0x04)
	enum class EParticleCollisionResponse Response; // 0xa4(0x01)
	enum class EParticleCollisionMode CollisionMode; // 0xa5(0x01)
	char pad_A6[0x2]; // 0xa6(0x02)
};

// Class Engine.ParticleModuleColorBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleColorBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleColor
// Size: 0xc8 (Inherited: 0x30)
struct UParticleModuleColor : UParticleModuleColorBase {
	struct FRawDistributionVector StartColor; // 0x30(0x60)
	struct FRawDistributionFloat StartAlpha; // 0x90(0x30)
	char bClampAlpha : 1; // 0xc0(0x01)
	char pad_C0_1 : 7; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
};

// Class Engine.ParticleModuleColorOverLife
// Size: 0xc8 (Inherited: 0x30)
struct UParticleModuleColorOverLife : UParticleModuleColorBase {
	struct FRawDistributionVector ColorOverLife; // 0x30(0x60)
	struct FRawDistributionFloat AlphaOverLife; // 0x90(0x30)
	char bClampAlpha : 1; // 0xc0(0x01)
	char pad_C0_1 : 7; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
};

// Class Engine.ParticleModuleColorScaleOverLife
// Size: 0xc8 (Inherited: 0x30)
struct UParticleModuleColorScaleOverLife : UParticleModuleColorBase {
	struct FRawDistributionVector ColorScaleOverLife; // 0x30(0x60)
	struct FRawDistributionFloat AlphaScaleOverLife; // 0x90(0x30)
	char bEmitterTime : 1; // 0xc0(0x01)
	char pad_C0_1 : 7; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
};

// Class Engine.ParticleModuleColor_Seeded
// Size: 0xe8 (Inherited: 0xc8)
struct UParticleModuleColor_Seeded : UParticleModuleColor {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0xc8(0x20)
};

// Class Engine.ParticleModuleEventBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleEventBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleEventGenerator
// Size: 0x40 (Inherited: 0x30)
struct UParticleModuleEventGenerator : UParticleModuleEventBase {
	struct TArray<struct FParticleEvent_GenerateInfo> Events; // 0x30(0x10)
};

// Class Engine.ParticleModuleEventReceiverBase
// Size: 0x40 (Inherited: 0x30)
struct UParticleModuleEventReceiverBase : UParticleModuleEventBase {
	enum class EParticleEventType EventGeneratorType; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	struct FName EventName; // 0x34(0x08)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class Engine.ParticleModuleEventReceiverKillParticles
// Size: 0x48 (Inherited: 0x40)
struct UParticleModuleEventReceiverKillParticles : UParticleModuleEventReceiverBase {
	char bStopSpawning : 1; // 0x40(0x01)
	char pad_40_1 : 7; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// Class Engine.ParticleModuleEventReceiverSpawn
// Size: 0xf0 (Inherited: 0x40)
struct UParticleModuleEventReceiverSpawn : UParticleModuleEventReceiverBase {
	struct FRawDistributionFloat SpawnCount; // 0x40(0x30)
	char bUseParticleTime : 1; // 0x70(0x01)
	char bUsePSysLocation : 1; // 0x70(0x01)
	char bInheritVelocity : 1; // 0x70(0x01)
	char pad_70_3 : 5; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
	struct FRawDistributionVector InheritVelocityScale; // 0x78(0x60)
	struct TArray<struct UPhysicalMaterial*> PhysicalMaterials; // 0xd8(0x10)
	char bBanPhysicalMaterials : 1; // 0xe8(0x01)
	char pad_E8_1 : 7; // 0xe8(0x01)
	char pad_E9[0x7]; // 0xe9(0x07)
};

// Class Engine.ParticleModuleEventSendToGame
// Size: 0x28 (Inherited: 0x28)
struct UParticleModuleEventSendToGame : UObject {
};

// Class Engine.ParticleModuleKillBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleKillBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleKillBox
// Size: 0xf8 (Inherited: 0x30)
struct UParticleModuleKillBox : UParticleModuleKillBase {
	struct FRawDistributionVector LowerLeftCorner; // 0x30(0x60)
	struct FRawDistributionVector UpperRightCorner; // 0x90(0x60)
	char bAbsolute : 1; // 0xf0(0x01)
	char bKillInside : 1; // 0xf0(0x01)
	char bAxisAlignedAndFixedSize : 1; // 0xf0(0x01)
	char pad_F0_3 : 5; // 0xf0(0x01)
	char pad_F1[0x7]; // 0xf1(0x07)
};

// Class Engine.ParticleModuleKillHeight
// Size: 0x68 (Inherited: 0x30)
struct UParticleModuleKillHeight : UParticleModuleKillBase {
	struct FRawDistributionFloat Height; // 0x30(0x30)
	char bAbsolute : 1; // 0x60(0x01)
	char bFloor : 1; // 0x60(0x01)
	char bApplyPSysScale : 1; // 0x60(0x01)
	char pad_60_3 : 5; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
};

// Class Engine.ParticleModuleLifetimeBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleLifetimeBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleLifetime
// Size: 0x60 (Inherited: 0x30)
struct UParticleModuleLifetime : UParticleModuleLifetimeBase {
	struct FRawDistributionFloat LifeTime; // 0x30(0x30)
};

// Class Engine.ParticleModuleLifetime_Seeded
// Size: 0x80 (Inherited: 0x60)
struct UParticleModuleLifetime_Seeded : UParticleModuleLifetime {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x60(0x20)
};

// Class Engine.ParticleModuleLightBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleLightBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleLight
// Size: 0x140 (Inherited: 0x30)
struct UParticleModuleLight : UParticleModuleLightBase {
	bool bUseInverseSquaredFalloff; // 0x30(0x01)
	bool bAffectsTranslucency; // 0x31(0x01)
	char pad_32[0x2]; // 0x32(0x02)
	char bOverrideInverseExposureBlend : 1; // 0x34(0x01)
	char pad_34_1 : 7; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
	bool bPreviewLightRadius; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	float SpawnFraction; // 0x3c(0x04)
	struct FRawDistributionVector ColorScaleOverLife; // 0x40(0x60)
	struct FRawDistributionFloat BrightnessOverLife; // 0xa0(0x30)
	struct FRawDistributionFloat RadiusScale; // 0xd0(0x30)
	struct FRawDistributionFloat LightExponent; // 0x100(0x30)
	float InverseExposureBlend; // 0x130(0x04)
	struct FLightingChannels LightingChannels; // 0x134(0x01)
	char pad_135[0x3]; // 0x135(0x03)
	float VolumetricScatteringIntensity; // 0x138(0x04)
	bool bHighQualityLights; // 0x13c(0x01)
	bool bShadowCastingLights; // 0x13d(0x01)
	char pad_13E[0x2]; // 0x13e(0x02)
};

// Class Engine.ParticleModuleLight_Seeded
// Size: 0x160 (Inherited: 0x140)
struct UParticleModuleLight_Seeded : UParticleModuleLight {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x140(0x20)
};

// Class Engine.ParticleModuleLocationBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleLocationBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleLocation
// Size: 0x98 (Inherited: 0x30)
struct UParticleModuleLocation : UParticleModuleLocationBase {
	struct FRawDistributionVector StartLocation; // 0x30(0x60)
	float DistributeOverNPoints; // 0x90(0x04)
	float DistributeThreshold; // 0x94(0x04)
};

// Class Engine.ParticleModuleLocationBoneSocket
// Size: 0x80 (Inherited: 0x30)
struct UParticleModuleLocationBoneSocket : UParticleModuleLocationBase {
	enum class ELocationBoneSocketSource SourceType; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FVector UniversalOffset; // 0x38(0x18)
	struct TArray<struct FLocationBoneSocketInfo> SourceLocations; // 0x50(0x10)
	enum class ELocationBoneSocketSelectionMethod SelectionMethod; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	char bUpdatePositionEachFrame : 1; // 0x64(0x01)
	char bOrientMeshEmitters : 1; // 0x64(0x01)
	char bInheritBoneVelocity : 1; // 0x64(0x01)
	char pad_64_3 : 5; // 0x64(0x01)
	char pad_65[0x3]; // 0x65(0x03)
	float InheritVelocityScale; // 0x68(0x04)
	struct FName SkelMeshActorParamName; // 0x6c(0x08)
	int32_t NumPreSelectedIndices; // 0x74(0x04)
	char pad_78[0x8]; // 0x78(0x08)
};

// Class Engine.ParticleModuleLocationDirect
// Size: 0x1b0 (Inherited: 0x30)
struct UParticleModuleLocationDirect : UParticleModuleLocationBase {
	struct FRawDistributionVector Location; // 0x30(0x60)
	struct FRawDistributionVector LocationOffset; // 0x90(0x60)
	struct FRawDistributionVector ScaleFactor; // 0xf0(0x60)
	struct FRawDistributionVector Direction; // 0x150(0x60)
};

// Class Engine.ParticleModuleLocationEmitter
// Size: 0x50 (Inherited: 0x30)
struct UParticleModuleLocationEmitter : UParticleModuleLocationBase {
	struct FName EmitterName; // 0x30(0x08)
	enum class ELocationEmitterSelectionMethod SelectionMethod; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	char InheritSourceVelocity : 1; // 0x3c(0x01)
	char pad_3C_1 : 7; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
	float InheritSourceVelocityScale; // 0x40(0x04)
	char bInheritSourceRotation : 1; // 0x44(0x01)
	char pad_44_1 : 7; // 0x44(0x01)
	char pad_45[0x3]; // 0x45(0x03)
	float InheritSourceRotationScale; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class Engine.ParticleModuleLocationEmitterDirect
// Size: 0x38 (Inherited: 0x30)
struct UParticleModuleLocationEmitterDirect : UParticleModuleLocationBase {
	struct FName EmitterName; // 0x30(0x08)
};

// Class Engine.ParticleModuleLocationPrimitiveBase
// Size: 0xc8 (Inherited: 0x30)
struct UParticleModuleLocationPrimitiveBase : UParticleModuleLocationBase {
	char Positive_X : 1; // 0x30(0x01)
	char Positive_Y : 1; // 0x30(0x01)
	char Positive_Z : 1; // 0x30(0x01)
	char Negative_X : 1; // 0x30(0x01)
	char Negative_Y : 1; // 0x30(0x01)
	char Negative_Z : 1; // 0x30(0x01)
	char SurfaceOnly : 1; // 0x30(0x01)
	char Velocity : 1; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FRawDistributionFloat VelocityScale; // 0x38(0x30)
	struct FRawDistributionVector StartLocation; // 0x68(0x60)
};

// Class Engine.ParticleModuleLocationPrimitiveCylinder
// Size: 0x138 (Inherited: 0xc8)
struct UParticleModuleLocationPrimitiveCylinder : UParticleModuleLocationPrimitiveBase {
	char RadialVelocity : 1; // 0xc8(0x01)
	char pad_C8_1 : 7; // 0xc8(0x01)
	char pad_C9[0x7]; // 0xc9(0x07)
	struct FRawDistributionFloat StartRadius; // 0xd0(0x30)
	struct FRawDistributionFloat StartHeight; // 0x100(0x30)
	enum class CylinderHeightAxis HeightAxis; // 0x130(0x01)
	char pad_131[0x7]; // 0x131(0x07)
};

// Class Engine.ParticleModuleLocationPrimitiveCylinder_Seeded
// Size: 0x158 (Inherited: 0x138)
struct UParticleModuleLocationPrimitiveCylinder_Seeded : UParticleModuleLocationPrimitiveCylinder {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x138(0x20)
};

// Class Engine.ParticleModuleLocationPrimitiveSphere
// Size: 0xf8 (Inherited: 0xc8)
struct UParticleModuleLocationPrimitiveSphere : UParticleModuleLocationPrimitiveBase {
	struct FRawDistributionFloat StartRadius; // 0xc8(0x30)
};

// Class Engine.ParticleModuleLocationPrimitiveSphere_Seeded
// Size: 0x118 (Inherited: 0xf8)
struct UParticleModuleLocationPrimitiveSphere_Seeded : UParticleModuleLocationPrimitiveSphere {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0xf8(0x20)
};

// Class Engine.ParticleModuleLocationPrimitiveTriangle
// Size: 0x120 (Inherited: 0x30)
struct UParticleModuleLocationPrimitiveTriangle : UParticleModuleLocationBase {
	struct FRawDistributionVector StartOffset; // 0x30(0x60)
	struct FRawDistributionFloat Height; // 0x90(0x30)
	struct FRawDistributionFloat Angle; // 0xc0(0x30)
	struct FRawDistributionFloat Thickness; // 0xf0(0x30)
};

// Class Engine.ParticleModuleLocationSkelVertSurface
// Size: 0xb0 (Inherited: 0x30)
struct UParticleModuleLocationSkelVertSurface : UParticleModuleLocationBase {
	enum class ELocationSkelVertSurfaceSource SourceType; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FVector UniversalOffset; // 0x38(0x18)
	char bUpdatePositionEachFrame : 1; // 0x50(0x01)
	char bOrientMeshEmitters : 1; // 0x50(0x01)
	char bInheritBoneVelocity : 1; // 0x50(0x01)
	char pad_50_3 : 5; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	float InheritVelocityScale; // 0x54(0x04)
	struct FName SkelMeshActorParamName; // 0x58(0x08)
	struct TArray<struct FName> ValidAssociatedBones; // 0x60(0x10)
	char bEnforceNormalCheck : 1; // 0x70(0x01)
	char pad_70_1 : 7; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
	struct FVector NormalToCompare; // 0x78(0x18)
	float NormalCheckToleranceDegrees; // 0x90(0x04)
	float NormalCheckTolerance; // 0x94(0x04)
	struct TArray<int32_t> ValidMaterialIndices; // 0x98(0x10)
	char bInheritVertexColor : 1; // 0xa8(0x01)
	char bInheritUV : 1; // 0xa8(0x01)
	char pad_A8_2 : 6; // 0xa8(0x01)
	char pad_A9[0x3]; // 0xa9(0x03)
	uint32_t InheritUVChannel; // 0xac(0x04)
};

// Class Engine.ParticleModuleLocationWorldOffset
// Size: 0x98 (Inherited: 0x98)
struct UParticleModuleLocationWorldOffset : UParticleModuleLocation {
	struct FRawDistributionVector StartLocation; // 0x30(0x60)
	float DistributeOverNPoints; // 0x90(0x04)
	float DistributeThreshold; // 0x94(0x04)
};

// Class Engine.ParticleModuleLocationWorldOffset_Seeded
// Size: 0xb8 (Inherited: 0x98)
struct UParticleModuleLocationWorldOffset_Seeded : UParticleModuleLocationWorldOffset {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x98(0x20)
};

// Class Engine.ParticleModuleLocation_Seeded
// Size: 0xb8 (Inherited: 0x98)
struct UParticleModuleLocation_Seeded : UParticleModuleLocation {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x98(0x20)
};

// Class Engine.ParticleModuleMaterialBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleMaterialBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleMeshMaterial
// Size: 0x40 (Inherited: 0x30)
struct UParticleModuleMeshMaterial : UParticleModuleMaterialBase {
	struct TArray<struct UMaterialInterface*> MeshMaterials; // 0x30(0x10)
};

// Class Engine.ParticleModuleRotationBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleRotationBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleMeshRotation
// Size: 0x98 (Inherited: 0x30)
struct UParticleModuleMeshRotation : UParticleModuleRotationBase {
	struct FRawDistributionVector StartRotation; // 0x30(0x60)
	char bInheritParent : 1; // 0x90(0x01)
	char pad_90_1 : 7; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// Class Engine.ParticleModuleRotationRateBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleRotationRateBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleMeshRotationRate
// Size: 0x90 (Inherited: 0x30)
struct UParticleModuleMeshRotationRate : UParticleModuleRotationRateBase {
	struct FRawDistributionVector StartRotationRate; // 0x30(0x60)
};

// Class Engine.ParticleModuleMeshRotationRateMultiplyLife
// Size: 0x90 (Inherited: 0x30)
struct UParticleModuleMeshRotationRateMultiplyLife : UParticleModuleRotationRateBase {
	struct FRawDistributionVector LifeMultiplier; // 0x30(0x60)
};

// Class Engine.ParticleModuleMeshRotationRateOverLife
// Size: 0x98 (Inherited: 0x30)
struct UParticleModuleMeshRotationRateOverLife : UParticleModuleRotationRateBase {
	struct FRawDistributionVector RotRate; // 0x30(0x60)
	char bScaleRotRate : 1; // 0x90(0x01)
	char pad_90_1 : 7; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// Class Engine.ParticleModuleMeshRotationRate_Seeded
// Size: 0xb0 (Inherited: 0x90)
struct UParticleModuleMeshRotationRate_Seeded : UParticleModuleMeshRotationRate {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x90(0x20)
};

// Class Engine.ParticleModuleMeshRotation_Seeded
// Size: 0xb8 (Inherited: 0x98)
struct UParticleModuleMeshRotation_Seeded : UParticleModuleMeshRotation {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x98(0x20)
};

// Class Engine.ParticleModuleOrbitBase
// Size: 0x38 (Inherited: 0x30)
struct UParticleModuleOrbitBase : UParticleModule {
	char bUseEmitterTime : 1; // 0x30(0x01)
	char pad_30_1 : 7; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// Class Engine.ParticleModuleOrbit
// Size: 0x178 (Inherited: 0x38)
struct UParticleModuleOrbit : UParticleModuleOrbitBase {
	enum class EOrbitChainMode ChainMode; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct FRawDistributionVector OffsetAmount; // 0x40(0x60)
	struct FOrbitOptions OffsetOptions; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)
	struct FRawDistributionVector RotationAmount; // 0xa8(0x60)
	struct FOrbitOptions RotationOptions; // 0x108(0x04)
	char pad_10C[0x4]; // 0x10c(0x04)
	struct FRawDistributionVector RotationRateAmount; // 0x110(0x60)
	struct FOrbitOptions RotationRateOptions; // 0x170(0x04)
	char pad_174[0x4]; // 0x174(0x04)
};

// Class Engine.ParticleModuleOrientationBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleOrientationBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleOrientationAxisLock
// Size: 0x38 (Inherited: 0x30)
struct UParticleModuleOrientationAxisLock : UParticleModuleOrientationBase {
	enum class EParticleAxisLock LockAxisFlags; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// Class Engine.ParticleModuleParameterBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleParameterBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleParameterDynamic
// Size: 0x48 (Inherited: 0x30)
struct UParticleModuleParameterDynamic : UParticleModuleParameterBase {
	struct TArray<struct FEmitterDynamicParameter> DynamicParams; // 0x30(0x10)
	int32_t UpdateFlags; // 0x40(0x04)
	char bUsesVelocity : 1; // 0x44(0x01)
	char pad_44_1 : 7; // 0x44(0x01)
	char pad_45[0x3]; // 0x45(0x03)
};

// Class Engine.ParticleModuleParameterDynamic_Seeded
// Size: 0x68 (Inherited: 0x48)
struct UParticleModuleParameterDynamic_Seeded : UParticleModuleParameterDynamic {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x48(0x20)
};

// Class Engine.ParticleModulePivotOffset
// Size: 0x40 (Inherited: 0x30)
struct UParticleModulePivotOffset : UParticleModuleLocationBase {
	struct FVector2D PivotOffset; // 0x30(0x10)
};

// Class Engine.ParticleModuleRequired
// Size: 0x178 (Inherited: 0x30)
struct UParticleModuleRequired : UParticleModule {
	struct UMaterialInterface* Material; // 0x30(0x08)
	float MinFacingCameraBlendDistance; // 0x38(0x04)
	float MaxFacingCameraBlendDistance; // 0x3c(0x04)
	struct FVector EmitterOrigin; // 0x40(0x18)
	struct FRotator EmitterRotation; // 0x58(0x18)
	enum class EParticleScreenAlignment ScreenAlignment; // 0x70(0x01)
	char bUseLocalSpace : 1; // 0x71(0x01)
	char bKillOnDeactivate : 1; // 0x71(0x01)
	char bKillOnCompleted : 1; // 0x71(0x01)
	char pad_71_3 : 5; // 0x71(0x01)
	enum class EParticleSortMode SortMode; // 0x72(0x01)
	char bUseLegacyEmitterTime : 1; // 0x73(0x01)
	char bRemoveHMDRoll : 1; // 0x73(0x01)
	char bSupportLargeWorldCoordinates : 1; // 0x73(0x01)
	char bEmitterDurationUseRange : 1; // 0x73(0x01)
	char pad_73_4 : 4; // 0x73(0x01)
	float EmitterDuration; // 0x74(0x04)
	struct FRawDistributionFloat SpawnRate; // 0x78(0x30)
	struct TArray<struct FParticleBurst> BurstList; // 0xa8(0x10)
	float EmitterDelay; // 0xb8(0x04)
	float EmitterDelayLow; // 0xbc(0x04)
	char bDelayFirstLoopOnly : 1; // 0xc0(0x01)
	char pad_C0_1 : 7; // 0xc0(0x01)
	enum class EParticleSubUVInterpMethod InterpolationMethod; // 0xc1(0x01)
	char bScaleUV : 1; // 0xc2(0x01)
	char bEmitterDelayUseRange : 1; // 0xc2(0x01)
	char pad_C2_2 : 6; // 0xc2(0x01)
	enum class EParticleBurstMethod ParticleBurstMethod; // 0xc3(0x01)
	char bOverrideSystemMacroUV : 1; // 0xc4(0x01)
	char bUseMaxDrawCount : 1; // 0xc4(0x01)
	char pad_C4_2 : 6; // 0xc4(0x01)
	enum class EOpacitySourceMode OpacitySourceMode; // 0xc5(0x01)
	enum class EEmitterNormalsMode EmitterNormalsMode; // 0xc6(0x01)
	char bOrbitModuleAffectsVelocityAlignment : 1; // 0xc7(0x01)
	char pad_C7_1 : 7; // 0xc7(0x01)
	int32_t SubImages_Horizontal; // 0xc8(0x04)
	int32_t SubImages_Vertical; // 0xcc(0x04)
	float RandomImageTime; // 0xd0(0x04)
	int32_t RandomImageChanges; // 0xd4(0x04)
	struct FVector MacroUVPosition; // 0xd8(0x18)
	float MacroUVRadius; // 0xf0(0x04)
	enum class EParticleUVFlipMode UVFlippingMode; // 0xf4(0x01)
	enum class ESubUVBoundingVertexCount BoundingMode; // 0xf5(0x01)
	char bDurationRecalcEachLoop : 1; // 0xf6(0x01)
	char pad_F6_1 : 7; // 0xf6(0x01)
	char pad_F7[0x1]; // 0xf7(0x01)
	struct FVector NormalsSphereCenter; // 0xf8(0x18)
	float AlphaThreshold; // 0x110(0x04)
	int32_t EmitterLoops; // 0x114(0x04)
	struct UTexture2D* CutoutTexture; // 0x118(0x08)
	int32_t MaxDrawCount; // 0x120(0x04)
	float EmitterDurationLow; // 0x124(0x04)
	struct FVector NormalsCylinderDirection; // 0x128(0x18)
	struct TArray<struct FName> NamedMaterialOverrides; // 0x140(0x10)
	char pad_150[0x28]; // 0x150(0x28)
};

// Class Engine.ParticleModuleRotation
// Size: 0x60 (Inherited: 0x30)
struct UParticleModuleRotation : UParticleModuleRotationBase {
	struct FRawDistributionFloat StartRotation; // 0x30(0x30)
};

// Class Engine.ParticleModuleRotationOverLifetime
// Size: 0x68 (Inherited: 0x30)
struct UParticleModuleRotationOverLifetime : UParticleModuleRotationBase {
	struct FRawDistributionFloat RotationOverLife; // 0x30(0x30)
	char Scale : 1; // 0x60(0x01)
	char pad_60_1 : 7; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
};

// Class Engine.ParticleModuleRotationRate
// Size: 0x60 (Inherited: 0x30)
struct UParticleModuleRotationRate : UParticleModuleRotationRateBase {
	struct FRawDistributionFloat StartRotationRate; // 0x30(0x30)
};

// Class Engine.ParticleModuleRotationRateMultiplyLife
// Size: 0x60 (Inherited: 0x30)
struct UParticleModuleRotationRateMultiplyLife : UParticleModuleRotationRateBase {
	struct FRawDistributionFloat LifeMultiplier; // 0x30(0x30)
};

// Class Engine.ParticleModuleRotationRate_Seeded
// Size: 0x80 (Inherited: 0x60)
struct UParticleModuleRotationRate_Seeded : UParticleModuleRotationRate {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x60(0x20)
};

// Class Engine.ParticleModuleRotation_Seeded
// Size: 0x80 (Inherited: 0x60)
struct UParticleModuleRotation_Seeded : UParticleModuleRotation {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x60(0x20)
};

// Class Engine.ParticleModuleSizeBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleSizeBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleSize
// Size: 0x90 (Inherited: 0x30)
struct UParticleModuleSize : UParticleModuleSizeBase {
	struct FRawDistributionVector StartSize; // 0x30(0x60)
};

// Class Engine.ParticleModuleSizeMultiplyLife
// Size: 0x98 (Inherited: 0x30)
struct UParticleModuleSizeMultiplyLife : UParticleModuleSizeBase {
	struct FRawDistributionVector LifeMultiplier; // 0x30(0x60)
	char MultiplyX : 1; // 0x90(0x01)
	char MultiplyY : 1; // 0x90(0x01)
	char MultiplyZ : 1; // 0x90(0x01)
	char pad_90_3 : 5; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// Class Engine.ParticleModuleSizeScale
// Size: 0x98 (Inherited: 0x30)
struct UParticleModuleSizeScale : UParticleModuleSizeBase {
	struct FRawDistributionVector SizeScale; // 0x30(0x60)
	char EnableX : 1; // 0x90(0x01)
	char EnableY : 1; // 0x90(0x01)
	char EnableZ : 1; // 0x90(0x01)
	char pad_90_3 : 5; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// Class Engine.ParticleModuleSizeScaleBySpeed
// Size: 0x50 (Inherited: 0x30)
struct UParticleModuleSizeScaleBySpeed : UParticleModuleSizeBase {
	struct FVector2D SpeedScale; // 0x30(0x10)
	struct FVector2D MaxScale; // 0x40(0x10)
};

// Class Engine.ParticleModuleSize_Seeded
// Size: 0xb0 (Inherited: 0x90)
struct UParticleModuleSize_Seeded : UParticleModuleSize {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0x90(0x20)
};

// Class Engine.ParticleModuleSourceMovement
// Size: 0x90 (Inherited: 0x30)
struct UParticleModuleSourceMovement : UParticleModuleLocationBase {
	struct FRawDistributionVector SourceMovementScale; // 0x30(0x60)
};

// Class Engine.ParticleModuleSpawnBase
// Size: 0x38 (Inherited: 0x30)
struct UParticleModuleSpawnBase : UParticleModule {
	char bProcessSpawnRate : 1; // 0x30(0x01)
	char bProcessBurstList : 1; // 0x30(0x01)
	char pad_30_2 : 6; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// Class Engine.ParticleModuleSpawn
// Size: 0xe0 (Inherited: 0x38)
struct UParticleModuleSpawn : UParticleModuleSpawnBase {
	struct FRawDistributionFloat Rate; // 0x38(0x30)
	struct FRawDistributionFloat RateScale; // 0x68(0x30)
	struct TArray<struct FParticleBurst> BurstList; // 0x98(0x10)
	struct FRawDistributionFloat BurstScale; // 0xa8(0x30)
	enum class EParticleBurstMethod ParticleBurstMethod; // 0xd8(0x01)
	char pad_D9[0x3]; // 0xd9(0x03)
	char bApplyGlobalSpawnRateScale : 1; // 0xdc(0x01)
	char pad_DC_1 : 7; // 0xdc(0x01)
	char pad_DD[0x3]; // 0xdd(0x03)
};

// Class Engine.ParticleModuleSpawnPerUnit
// Size: 0x78 (Inherited: 0x38)
struct UParticleModuleSpawnPerUnit : UParticleModuleSpawnBase {
	float UnitScalar; // 0x38(0x04)
	float MovementTolerance; // 0x3c(0x04)
	struct FRawDistributionFloat SpawnPerUnit; // 0x40(0x30)
	float MaxFrameDistance; // 0x70(0x04)
	char bIgnoreSpawnRateWhenMoving : 1; // 0x74(0x01)
	char bIgnoreMovementAlongX : 1; // 0x74(0x01)
	char bIgnoreMovementAlongY : 1; // 0x74(0x01)
	char bIgnoreMovementAlongZ : 1; // 0x74(0x01)
	char pad_74_4 : 4; // 0x74(0x01)
	char pad_75[0x3]; // 0x75(0x03)
};

// Class Engine.ParticleModuleSubUVBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleSubUVBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleSubUV
// Size: 0x70 (Inherited: 0x30)
struct UParticleModuleSubUV : UParticleModuleSubUVBase {
	struct USubUVAnimation* Animation; // 0x30(0x08)
	struct FRawDistributionFloat SubImageIndex; // 0x38(0x30)
	char bUseRealTime : 1; // 0x68(0x01)
	char pad_68_1 : 7; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
};

// Class Engine.ParticleModuleSubUVMovie
// Size: 0xb0 (Inherited: 0x70)
struct UParticleModuleSubUVMovie : UParticleModuleSubUV {
	char bUseEmitterTime : 1; // 0x70(0x01)
	char pad_70_1 : 7; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
	struct FRawDistributionFloat FrameRate; // 0x78(0x30)
	int32_t StartingFrame; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
};

// Class Engine.ParticleModuleTrailBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleTrailBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleTrailSource
// Size: 0x90 (Inherited: 0x30)
struct UParticleModuleTrailSource : UParticleModuleTrailBase {
	enum class ETrail2SourceMethod SourceMethod; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	struct FName SourceName; // 0x34(0x08)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FRawDistributionFloat SourceStrength; // 0x40(0x30)
	char bLockSourceStength : 1; // 0x70(0x01)
	char pad_70_1 : 7; // 0x70(0x01)
	char pad_71[0x3]; // 0x71(0x03)
	int32_t SourceOffsetCount; // 0x74(0x04)
	struct TArray<struct FVector> SourceOffsetDefaults; // 0x78(0x10)
	enum class EParticleSourceSelectionMethod SelectionMethod; // 0x88(0x01)
	char pad_89[0x3]; // 0x89(0x03)
	char bInheritRotation : 1; // 0x8c(0x01)
	char pad_8C_1 : 7; // 0x8c(0x01)
	char pad_8D[0x3]; // 0x8d(0x03)
};

// Class Engine.ParticleModuleTypeDataBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleTypeDataBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleTypeDataAnimTrail
// Size: 0x48 (Inherited: 0x30)
struct UParticleModuleTypeDataAnimTrail : UParticleModuleTypeDataBase {
	char bDeadTrailsOnDeactivate : 1; // 0x30(0x01)
	char bEnablePreviousTangentRecalculation : 1; // 0x30(0x01)
	char bTangentRecalculationEveryFrame : 1; // 0x30(0x01)
	char pad_30_3 : 5; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	float TilingDistance; // 0x34(0x04)
	float DistanceTessellationStepSize; // 0x38(0x04)
	float TangentTessellationStepSize; // 0x3c(0x04)
	float WidthTessellationStepSize; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class Engine.ParticleModuleTypeDataBeam2
// Size: 0x150 (Inherited: 0x30)
struct UParticleModuleTypeDataBeam2 : UParticleModuleTypeDataBase {
	enum class EBeam2Method BeamMethod; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	int32_t TextureTile; // 0x34(0x04)
	float TextureTileDistance; // 0x38(0x04)
	int32_t Sheets; // 0x3c(0x04)
	int32_t MaxBeamCount; // 0x40(0x04)
	float Speed; // 0x44(0x04)
	int32_t InterpolationPoints; // 0x48(0x04)
	char bAlwaysOn : 1; // 0x4c(0x01)
	char pad_4C_1 : 7; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	int32_t UpVectorStepSize; // 0x50(0x04)
	struct FName BranchParentName; // 0x54(0x08)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct FRawDistributionFloat Distance; // 0x60(0x30)
	enum class EBeamTaperMethod TaperMethod; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
	struct FRawDistributionFloat TaperFactor; // 0x98(0x30)
	struct FRawDistributionFloat TaperScale; // 0xc8(0x30)
	char RenderGeometry : 1; // 0xf8(0x01)
	char RenderDirectLine : 1; // 0xf8(0x01)
	char RenderLines : 1; // 0xf8(0x01)
	char RenderTessellation : 1; // 0xf8(0x01)
	char pad_F8_4 : 4; // 0xf8(0x01)
	char pad_F9[0x57]; // 0xf9(0x57)
};

// Class Engine.ParticleModuleTypeDataGpu
// Size: 0x5d0 (Inherited: 0x30)
struct UParticleModuleTypeDataGpu : UParticleModuleTypeDataBase {
	struct FGPUSpriteEmitterInfo EmitterInfo; // 0x30(0x350)
	struct FGPUSpriteResourceData ResourceData; // 0x380(0x240)
	float CameraMotionBlurAmount; // 0x5c0(0x04)
	char bClearExistingParticlesOnInit : 1; // 0x5c4(0x01)
	char pad_5C4_1 : 7; // 0x5c4(0x01)
	char pad_5C5[0xb]; // 0x5c5(0x0b)
};

// Class Engine.ParticleModuleTypeDataMesh
// Size: 0xb0 (Inherited: 0x30)
struct UParticleModuleTypeDataMesh : UParticleModuleTypeDataBase {
	struct UStaticMesh* Mesh; // 0x30(0x08)
	char pad_38[0x8]; // 0x38(0x08)
	float LODSizeScale; // 0x40(0x04)
	char bUseStaticMeshLODs : 1; // 0x44(0x01)
	char CastShadows : 1; // 0x44(0x01)
	char DoCollisions : 1; // 0x44(0x01)
	char pad_44_3 : 5; // 0x44(0x01)
	enum class EMeshScreenAlignment MeshAlignment; // 0x45(0x01)
	char bOverrideMaterial : 1; // 0x46(0x01)
	char bOverrideDefaultMotionBlurSettings : 1; // 0x46(0x01)
	char bEnableMotionBlur : 1; // 0x46(0x01)
	char pad_46_3 : 5; // 0x46(0x01)
	char pad_47[0x1]; // 0x47(0x01)
	struct FRawDistributionVector RollPitchYawRange; // 0x48(0x60)
	enum class EParticleAxisLock AxisLockOption; // 0xa8(0x01)
	char bCameraFacing : 1; // 0xa9(0x01)
	char pad_A9_1 : 7; // 0xa9(0x01)
	enum class EMeshCameraFacingUpAxis CameraFacingUpAxisOption; // 0xaa(0x01)
	enum class EMeshCameraFacingOptions CameraFacingOption; // 0xab(0x01)
	char bApplyParticleRotationAsSpin : 1; // 0xac(0x01)
	char bFaceCameraDirectionRatherThanPosition : 1; // 0xac(0x01)
	char bCollisionsConsiderPartilceSize : 1; // 0xac(0x01)
	char pad_AC_3 : 5; // 0xac(0x01)
	char pad_AD[0x3]; // 0xad(0x03)
};

// Class Engine.ParticleModuleTypeDataRibbon
// Size: 0x60 (Inherited: 0x30)
struct UParticleModuleTypeDataRibbon : UParticleModuleTypeDataBase {
	int32_t MaxTessellationBetweenParticles; // 0x30(0x04)
	int32_t SheetsPerTrail; // 0x34(0x04)
	int32_t MaxTrailCount; // 0x38(0x04)
	int32_t MaxParticleInTrailCount; // 0x3c(0x04)
	char bDeadTrailsOnDeactivate : 1; // 0x40(0x01)
	char bDeadTrailsOnSourceLoss : 1; // 0x40(0x01)
	char bClipSourceSegement : 1; // 0x40(0x01)
	char bEnablePreviousTangentRecalculation : 1; // 0x40(0x01)
	char bTangentRecalculationEveryFrame : 1; // 0x40(0x01)
	char bSpawnInitialParticle : 1; // 0x40(0x01)
	char pad_40_6 : 2; // 0x40(0x01)
	char pad_41[0x3]; // 0x41(0x03)
	enum class ETrailsRenderAxisOption RenderAxis; // 0x44(0x01)
	char pad_45[0x3]; // 0x45(0x03)
	float TangentSpawningScalar; // 0x48(0x04)
	char bRenderGeometry : 1; // 0x4c(0x01)
	char bRenderSpawnPoints : 1; // 0x4c(0x01)
	char bRenderTangents : 1; // 0x4c(0x01)
	char bRenderTessellation : 1; // 0x4c(0x01)
	char pad_4C_4 : 4; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	float TilingDistance; // 0x50(0x04)
	float DistanceTessellationStepSize; // 0x54(0x04)
	char bEnableTangentDiffInterpScale : 1; // 0x58(0x01)
	char pad_58_1 : 7; // 0x58(0x01)
	char pad_59[0x3]; // 0x59(0x03)
	float TangentTessellationScalar; // 0x5c(0x04)
};

// Class Engine.ParticleModuleVectorFieldBase
// Size: 0x30 (Inherited: 0x30)
struct UParticleModuleVectorFieldBase : UParticleModule {
	char bSpawnModule : 1; // 0x28(0x01)
	char bUpdateModule : 1; // 0x28(0x01)
	char bFinalUpdateModule : 1; // 0x28(0x01)
	char bUpdateForGPUEmitter : 1; // 0x28(0x01)
	char bCurvesAsColor : 1; // 0x28(0x01)
	char b3DDrawMode : 1; // 0x28(0x01)
	char bSupported3DDrawMode : 1; // 0x28(0x01)
	char bEnabled : 1; // 0x28(0x01)
	char bEditable : 1; // 0x29(0x01)
	char LODDuplicate : 1; // 0x29(0x01)
	char bSupportsRandomSeed : 1; // 0x29(0x01)
	char bRequiresLoopingNotification : 1; // 0x29(0x01)
	char LODValidity; // 0x2a(0x01)
};

// Class Engine.ParticleModuleVectorFieldGlobal
// Size: 0x40 (Inherited: 0x30)
struct UParticleModuleVectorFieldGlobal : UParticleModuleVectorFieldBase {
	char bOverrideGlobalVectorFieldTightness : 1; // 0x30(0x01)
	char pad_30_1 : 7; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	float GlobalVectorFieldScale; // 0x34(0x04)
	float GlobalVectorFieldTightness; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class Engine.ParticleModuleVectorFieldLocal
// Size: 0x90 (Inherited: 0x30)
struct UParticleModuleVectorFieldLocal : UParticleModuleVectorFieldBase {
	struct UVectorField* VectorField; // 0x30(0x08)
	struct FVector RelativeTranslation; // 0x38(0x18)
	struct FRotator RelativeRotation; // 0x50(0x18)
	struct FVector RelativeScale3D; // 0x68(0x18)
	float Intensity; // 0x80(0x04)
	float Tightness; // 0x84(0x04)
	char bIgnoreComponentTransform : 1; // 0x88(0x01)
	char bTileX : 1; // 0x88(0x01)
	char bTileY : 1; // 0x88(0x01)
	char bTileZ : 1; // 0x88(0x01)
	char bUseFixDT : 1; // 0x88(0x01)
	char pad_88_5 : 3; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
};

// Class Engine.ParticleModuleVectorFieldRotation
// Size: 0x60 (Inherited: 0x30)
struct UParticleModuleVectorFieldRotation : UParticleModuleVectorFieldBase {
	struct FVector MinInitialRotation; // 0x30(0x18)
	struct FVector MaxInitialRotation; // 0x48(0x18)
};

// Class Engine.ParticleModuleVectorFieldRotationRate
// Size: 0x48 (Inherited: 0x30)
struct UParticleModuleVectorFieldRotationRate : UParticleModuleVectorFieldBase {
	struct FVector RotationRate; // 0x30(0x18)
};

// Class Engine.ParticleModuleVectorFieldScale
// Size: 0x68 (Inherited: 0x30)
struct UParticleModuleVectorFieldScale : UParticleModuleVectorFieldBase {
	struct UDistributionFloat* VectorFieldScale; // 0x30(0x08)
	struct FRawDistributionFloat VectorFieldScaleRaw; // 0x38(0x30)
};

// Class Engine.ParticleModuleVectorFieldScaleOverLife
// Size: 0x68 (Inherited: 0x30)
struct UParticleModuleVectorFieldScaleOverLife : UParticleModuleVectorFieldBase {
	struct UDistributionFloat* VectorFieldScaleOverLife; // 0x30(0x08)
	struct FRawDistributionFloat VectorFieldScaleOverLifeRaw; // 0x38(0x30)
};

// Class Engine.ParticleModuleVelocityBase
// Size: 0x38 (Inherited: 0x30)
struct UParticleModuleVelocityBase : UParticleModule {
	char bInWorldSpace : 1; // 0x30(0x01)
	char bApplyOwnerScale : 1; // 0x30(0x01)
	char pad_30_2 : 6; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// Class Engine.ParticleModuleVelocity
// Size: 0xc8 (Inherited: 0x38)
struct UParticleModuleVelocity : UParticleModuleVelocityBase {
	struct FRawDistributionVector StartVelocity; // 0x38(0x60)
	struct FRawDistributionFloat StartVelocityRadial; // 0x98(0x30)
};

// Class Engine.ParticleModuleVelocityCone
// Size: 0xb0 (Inherited: 0x38)
struct UParticleModuleVelocityCone : UParticleModuleVelocityBase {
	struct FRawDistributionFloat Angle; // 0x38(0x30)
	struct FRawDistributionFloat Velocity; // 0x68(0x30)
	struct FVector Direction; // 0x98(0x18)
};

// Class Engine.ParticleModuleVelocityInheritParent
// Size: 0x98 (Inherited: 0x38)
struct UParticleModuleVelocityInheritParent : UParticleModuleVelocityBase {
	struct FRawDistributionVector Scale; // 0x38(0x60)
};

// Class Engine.ParticleModuleVelocityOverLifetime
// Size: 0xa0 (Inherited: 0x38)
struct UParticleModuleVelocityOverLifetime : UParticleModuleVelocityBase {
	struct FRawDistributionVector VelOverLife; // 0x38(0x60)
	char Absolute : 1; // 0x98(0x01)
	char pad_98_1 : 7; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
};

// Class Engine.ParticleModuleVelocity_Seeded
// Size: 0xe8 (Inherited: 0xc8)
struct UParticleModuleVelocity_Seeded : UParticleModuleVelocity {
	struct FParticleRandomSeedInfo RandomSeedInfo; // 0xc8(0x20)
};

// Class Engine.ParticleSpriteEmitter
// Size: 0x1c0 (Inherited: 0x1c0)
struct UParticleSpriteEmitter : UParticleEmitter {
	struct FName EmitterName; // 0x28(0x08)
	int32_t SubUVDataOffset; // 0x30(0x04)
	enum class EEmitterRenderMode EmitterRenderMode; // 0x34(0x01)
	enum class EParticleSignificanceLevel SignificanceLevel; // 0x35(0x01)
	char bUseLegacySpawningBehavior : 1; // 0x37(0x01)
	char pad_1CE_1 : 3; // 0x1ce(0x01)
	char ConvertedModules : 1; // 0x37(0x01)
	char bIsSoloing : 1; // 0x37(0x01)
	char bCookedOut : 1; // 0x37(0x01)
	char bDisabledLODsKeepEmitterAlive : 1; // 0x37(0x01)
	char bDisableWhenInsignficant : 1; // 0x38(0x01)
	struct TArray<struct UParticleLODLevel*> LODLevels; // 0x40(0x10)
	int32_t PeakActiveParticles; // 0x50(0x04)
	int32_t InitialAllocationCount; // 0x54(0x04)
	float QualityLevelSpawnRateScale; // 0x58(0x04)
	uint32_t DetailModeBitmask; // 0x5c(0x04)
};

// Class Engine.ParticleSystemComponent
// Size: 0x850 (Inherited: 0x540)
struct UParticleSystemComponent : UFXSystemComponent {
	struct UParticleSystem* Template; // 0x538(0x08)
	struct TArray<struct UMaterialInterface*> EmitterMaterials; // 0x540(0x10)
	struct TArray<struct USkeletalMeshComponent*> SkelMeshComponents; // 0x550(0x10)
	char bResetOnDetach : 1; // 0x561(0x01)
	char bUpdateOnDedicatedServer : 1; // 0x561(0x01)
	char pad_568_2 : 2; // 0x568(0x01)
	char bAllowRecycling : 1; // 0x561(0x01)
	char bAutoManageAttachment : 1; // 0x561(0x01)
	char bAutoAttachWeldSimulatedBodies : 1; // 0x561(0x01)
	char bWarmingUp : 1; // 0x562(0x01)
	char pad_569_0 : 3; // 0x569(0x01)
	char bOverrideLODMethod : 1; // 0x562(0x01)
	char bSkipUpdateDynamicDataDuringTick : 1; // 0x562(0x01)
	char pad_569_5 : 3; // 0x569(0x01)
	char pad_56A[0x3]; // 0x56a(0x03)
	enum class ParticleSystemLODMethod LODMethod; // 0x56d(0x01)
	enum class EParticleSignificanceLevel RequiredSignificance; // 0x56e(0x01)
	char pad_56F[0x1]; // 0x56f(0x01)
	struct TArray<struct FParticleSysParam> InstanceParameters; // 0x570(0x10)
	struct FMulticastInlineDelegate OnParticleSpawn; // 0x580(0x10)
	struct FMulticastInlineDelegate OnParticleBurst; // 0x590(0x10)
	struct FMulticastInlineDelegate OnParticleDeath; // 0x5a0(0x10)
	struct FMulticastInlineDelegate OnParticleCollide; // 0x5b0(0x10)
	bool bOldPositionValid; // 0x5c0(0x01)
	char pad_5C1[0x7]; // 0x5c1(0x07)
	struct FVector OldPosition; // 0x5c8(0x18)
	struct FVector PartSysVelocity; // 0x5e0(0x18)
	float WarmupTime; // 0x5f8(0x04)
	float WarmupTickRate; // 0x5fc(0x04)
	char pad_600[0x4]; // 0x600(0x04)
	float SecondsBeforeInactive; // 0x604(0x04)
	char pad_608[0x4]; // 0x608(0x04)
	float MaxTimeBeforeForceUpdateTransform; // 0x60c(0x04)
	char pad_610[0x20]; // 0x610(0x20)
	struct TArray<struct UParticleSystemReplay*> ReplayClips; // 0x630(0x10)
	char pad_640[0x8]; // 0x640(0x08)
	float CustomTimeDilation; // 0x648(0x04)
	char pad_64C[0x54]; // 0x64c(0x54)
	struct TWeakObjectPtr<struct USceneComponent> AutoAttachParent; // 0x6a0(0x08)
	struct FName AutoAttachSocketName; // 0x6a8(0x08)
	enum class EAttachmentRule AutoAttachLocationRule; // 0x6b0(0x01)
	enum class EAttachmentRule AutoAttachRotationRule; // 0x6b1(0x01)
	enum class EAttachmentRule AutoAttachScaleRule; // 0x6b2(0x01)
	char pad_6B3[0x55]; // 0x6b3(0x55)
	struct FMulticastInlineDelegate OnSystemFinished; // 0x708(0x10)
	char pad_718[0x138]; // 0x718(0x138)

	void SetTrailSourceData(struct FName InFirstSocketName, struct FName InSecondSocketName, enum class ETrailWidthMode InWidthMode, float InWidth); // Function Engine.ParticleSystemComponent.SetTrailSourceData // (None) // @ game+0xffffca6edf830041
};

// Class Engine.ParticleSystemReplay
// Size: 0x40 (Inherited: 0x28)
struct UParticleSystemReplay : UObject {
	int32_t ClipIDNumber; // 0x28(0x04)
	char pad_2C[0x14]; // 0x2c(0x14)
};

// Class Engine.PathFollowingAgentInterface
// Size: 0x28 (Inherited: 0x28)
struct UPathFollowingAgentInterface : UInterface {
};

// Class Engine.PhysicsSpringComponent
// Size: 0x2d0 (Inherited: 0x2a0)
struct UPhysicsSpringComponent : USceneComponent {
	float SpringStiffness; // 0x2a0(0x04)
	float SpringDamping; // 0x2a4(0x04)
	float SpringLengthAtRest; // 0x2a8(0x04)
	float SpringRadius; // 0x2ac(0x04)
	enum class ECollisionChannel SpringChannel; // 0x2b0(0x01)
	bool bIgnoreSelf; // 0x2b1(0x01)
	char pad_2B2[0x2]; // 0x2b2(0x02)
	float SpringCompression; // 0x2b4(0x04)
	char pad_2B8[0x18]; // 0x2b8(0x18)

	struct FVector GetSpringRestingPoint(); // Function Engine.PhysicsSpringComponent.GetSpringRestingPoint // (None) // @ game+0xffffca72df830041
};

// Class Engine.PhysicsThreadLibrary
// Size: 0x28 (Inherited: 0x28)
struct UPhysicsThreadLibrary : UBlueprintFunctionLibrary {

	void AddForce(struct FBodyInstanceAsyncPhysicsTickHandle Handle, struct FVector Force, bool bAccelChange); // Function Engine.PhysicsThreadLibrary.AddForce // (None) // @ game+0xffffca73df830041
};

// Class Engine.PhysicsThrusterComponent
// Size: 0x2b0 (Inherited: 0x2a0)
struct UPhysicsThrusterComponent : USceneComponent {
	float ThrustStrength; // 0x2a0(0x04)
	char pad_2A4[0xc]; // 0x2a4(0x0c)
};

// Class Engine.SceneCapture
// Size: 0x2a0 (Inherited: 0x290)
struct ASceneCapture : AActor {
	struct UStaticMeshComponent* MeshComp; // 0x290(0x08)
	struct USceneComponent* SceneComponent; // 0x298(0x08)
};

// Class Engine.PlanarReflection
// Size: 0x2b0 (Inherited: 0x2a0)
struct APlanarReflection : ASceneCapture {
	struct UPlanarReflectionComponent* PlanarReflectionComponent; // 0x2a0(0x08)
	bool bShowPreviewPlane; // 0x2a8(0x01)
	char pad_2A9[0x7]; // 0x2a9(0x07)

	void OnInterpToggle(bool bEnable); // Function Engine.PlanarReflection.OnInterpToggle // (None) // @ game+0xffffca74df830041
};

// Class Engine.SceneCaptureComponent
// Size: 0x360 (Inherited: 0x2a0)
struct USceneCaptureComponent : USceneComponent {
	enum class ESceneCapturePrimitiveRenderMode PrimitiveRenderMode; // 0x2a0(0x01)
	enum class ESceneCaptureSource CaptureSource; // 0x2a1(0x01)
	char bCaptureEveryFrame : 1; // 0x2a2(0x01)
	char bCaptureOnMovement : 1; // 0x2a2(0x01)
	char pad_2A2_2 : 6; // 0x2a2(0x01)
	bool bAlwaysPersistRenderingState; // 0x2a3(0x01)
	char pad_2A4[0x4]; // 0x2a4(0x04)
	struct TArray<struct TWeakObjectPtr<struct UPrimitiveComponent>> HiddenComponents; // 0x2a8(0x10)
	struct TArray<struct AActor*> HiddenActors; // 0x2b8(0x10)
	struct TArray<struct TWeakObjectPtr<struct UPrimitiveComponent>> ShowOnlyComponents; // 0x2c8(0x10)
	struct TArray<struct AActor*> ShowOnlyActors; // 0x2d8(0x10)
	float LODDistanceFactor; // 0x2e8(0x04)
	float MaxViewDistanceOverride; // 0x2ec(0x04)
	int32_t CaptureSortPriority; // 0x2f0(0x04)
	bool bUseRayTracingIfEnabled; // 0x2f4(0x01)
	char pad_2F5[0x3]; // 0x2f5(0x03)
	struct TArray<struct FEngineShowFlagsSetting> ShowFlagSettings; // 0x2f8(0x10)
	char pad_308[0x30]; // 0x308(0x30)
	struct FString ProfilingEventName; // 0x338(0x10)
	char pad_348[0x18]; // 0x348(0x18)

	void ShowOnlyComponent(struct UPrimitiveComponent* InComponent); // Function Engine.SceneCaptureComponent.ShowOnlyComponent // (None) // @ game+0xffffca7ddf830041
};

// Class Engine.PlanarReflectionComponent
// Size: 0x4c0 (Inherited: 0x360)
struct UPlanarReflectionComponent : USceneCaptureComponent {
	struct UBoxComponent* PreviewBox; // 0x358(0x08)
	float NormalDistortionStrength; // 0x360(0x04)
	float PrefilterRoughness; // 0x364(0x04)
	float PrefilterRoughnessDistance; // 0x368(0x04)
	int32_t ScreenPercentage; // 0x36c(0x04)
	float ExtraFOV; // 0x370(0x04)
	float DistanceFromPlaneFadeStart; // 0x374(0x04)
	float DistanceFromPlaneFadeEnd; // 0x378(0x04)
	float DistanceFromPlaneFadeoutStart; // 0x37c(0x04)
	float DistanceFromPlaneFadeoutEnd; // 0x380(0x04)
	float AngleFromPlaneFadeStart; // 0x384(0x04)
	float AngleFromPlaneFadeEnd; // 0x388(0x04)
	bool bShowPreviewPlane; // 0x38c(0x01)
	bool bRenderSceneTwoSided; // 0x38d(0x01)
	char pad_396[0x12a]; // 0x396(0x12a)
};

// Class Engine.PlaneReflectionCapture
// Size: 0x298 (Inherited: 0x298)
struct APlaneReflectionCapture : AReflectionCapture {
	struct UReflectionCaptureComponent* CaptureComponent; // 0x290(0x08)
};

// Class Engine.PlaneReflectionCaptureComponent
// Size: 0x330 (Inherited: 0x310)
struct UPlaneReflectionCaptureComponent : UReflectionCaptureComponent {
	float InfluenceRadiusScale; // 0x310(0x04)
	char pad_314[0x4]; // 0x314(0x04)
	struct UDrawSphereComponent* PreviewInfluenceRadius; // 0x318(0x08)
	struct UBoxComponent* PreviewCaptureBox; // 0x320(0x08)
	char pad_328[0x8]; // 0x328(0x08)
};

// Class Engine.PlatformInterfaceWebResponse
// Size: 0xb0 (Inherited: 0x28)
struct UPlatformInterfaceWebResponse : UObject {
	struct FString OriginalURL; // 0x28(0x10)
	int32_t ResponseCode; // 0x38(0x04)
	int32_t Tag; // 0x3c(0x04)
	struct FString StringResponse; // 0x40(0x10)
	struct TArray<char> BinaryResponse; // 0x50(0x10)
	char pad_60[0x50]; // 0x60(0x50)

	int32_t GetNumHeaders(); // Function Engine.PlatformInterfaceWebResponse.GetNumHeaders // (None) // @ game+0xffffca80df830041
};

// Class Engine.PlayerCameraManager
// Size: 0x3340 (Inherited: 0x290)
struct APlayerCameraManager : AActor {
	struct APlayerController* PCOwner; // 0x290(0x08)
	struct USceneComponent* TransformComponent; // 0x298(0x08)
	char pad_2A0[0x8]; // 0x2a0(0x08)
	float DefaultFOV; // 0x2a8(0x04)
	char pad_2AC[0x4]; // 0x2ac(0x04)
	float DefaultOrthoWidth; // 0x2b0(0x04)
	char pad_2B4[0x4]; // 0x2b4(0x04)
	float DefaultAspectRatio; // 0x2b8(0x04)
	char pad_2BC[0x64]; // 0x2bc(0x64)
	struct FCameraCacheEntry CameraCache; // 0x320(0x7d0)
	struct FCameraCacheEntry LastFrameCameraCache; // 0xaf0(0x7d0)
	struct FTViewTarget ViewTarget; // 0x12c0(0x7e0)
	struct FTViewTarget PendingViewTarget; // 0x1aa0(0x7e0)
	char pad_2280[0x30]; // 0x2280(0x30)
	struct FCameraCacheEntry CameraCachePrivate; // 0x22b0(0x7d0)
	struct FCameraCacheEntry LastFrameCameraCachePrivate; // 0x2a80(0x7d0)
	struct TArray<struct UCameraModifier*> ModifierList; // 0x3250(0x10)
	struct TArray<struct UCameraModifier*> DefaultModifiers; // 0x3260(0x10)
	float FreeCamDistance; // 0x3270(0x04)
	char pad_3274[0x4]; // 0x3274(0x04)
	struct FVector FreeCamOffset; // 0x3278(0x18)
	struct FVector ViewTargetOffset; // 0x3290(0x18)
	struct FMulticastInlineDelegate OnAudioFadeChangeEvent; // 0x32a8(0x10)
	char pad_32B8[0x18]; // 0x32b8(0x18)
	struct TArray<struct TScriptInterface<ICameraLensEffectInterface>> CameraLensEffects; // 0x32d0(0x10)
	struct UCameraModifier_CameraShake* CachedCameraShakeMod; // 0x32e0(0x08)
	struct TArray<struct FPostProcessSettings> PostProcessBlendCache; // 0x32e8(0x10)
	char pad_32F8[0x10]; // 0x32f8(0x10)
	struct ACameraActor* AnimCameraActor; // 0x3308(0x08)
	char bIsOrthographic : 1; // 0x3310(0x01)
	char bDefaultConstrainAspectRatio : 1; // 0x3310(0x01)
	char pad_3310_2 : 4; // 0x3310(0x01)
	char bClientSimulatingViewTarget : 1; // 0x3310(0x01)
	char bUseClientSideCameraUpdates : 1; // 0x3310(0x01)
	char pad_3311_0 : 2; // 0x3311(0x01)
	char bGameCameraCutThisFrame : 1; // 0x3311(0x01)
	char pad_3311_3 : 5; // 0x3311(0x01)
	char pad_3312[0x2]; // 0x3312(0x02)
	float ViewPitchMin; // 0x3314(0x04)
	float ViewPitchMax; // 0x3318(0x04)
	float ViewYawMin; // 0x331c(0x04)
	float ViewYawMax; // 0x3320(0x04)
	float ViewRollMin; // 0x3324(0x04)
	float ViewRollMax; // 0x3328(0x04)
	char pad_332C[0x4]; // 0x332c(0x04)
	float ServerUpdateCameraTimeout; // 0x3330(0x04)
	char pad_3334[0xc]; // 0x3334(0x0c)

	void SwapPendingViewTargetWhenUsingClientSideCameraUpdates(); // Function Engine.PlayerCameraManager.SwapPendingViewTargetWhenUsingClientSideCameraUpdates // (None) // @ game+0xffffca9edf830041
};

// Class Engine.PlayerStateCountLimiterConfig
// Size: 0x28 (Inherited: 0x28)
struct UPlayerStateCountLimiterConfig : UNetObjectCountLimiterConfig {
};

// Class Engine.PointLight
// Size: 0x2a8 (Inherited: 0x2a0)
struct APointLight : ALight {
	struct UPointLightComponent* PointLightComponent; // 0x2a0(0x08)

	void SetRadius(float NewRadius); // Function Engine.PointLight.SetRadius // (None) // @ game+0xffffcaa0df830041
};

// Class Engine.Polys
// Size: 0x38 (Inherited: 0x28)
struct UPolys : UObject {
	char pad_28[0x10]; // 0x28(0x10)
};

// Class Engine.PrecomputedVisibilityOverrideVolume
// Size: 0x2f8 (Inherited: 0x2c8)
struct APrecomputedVisibilityOverrideVolume : AVolume {
	struct TArray<struct AActor*> OverrideVisibleActors; // 0x2c8(0x10)
	struct TArray<struct AActor*> OverrideInvisibleActors; // 0x2d8(0x10)
	struct TArray<struct FName> OverrideInvisibleLevels; // 0x2e8(0x10)
};

// Class Engine.RigidBodyBase
// Size: 0x290 (Inherited: 0x290)
struct ARigidBodyBase : AActor {
	struct FActorTickFunction PrimaryActorTick; // 0x28(0x30)
	char bNetTemporary : 1; // 0x58(0x01)
	char pad_2C0_1 : 1; // 0x2c0(0x01)
	char bOnlyRelevantToOwner : 1; // 0x58(0x01)
	char bAlwaysRelevant : 1; // 0x58(0x01)
	char bReplicateMovement : 1; // 0x58(0x01)
	char bCallPreReplication : 1; // 0x58(0x01)
	char bCallPreReplicationForReplay : 1; // 0x58(0x01)
	char bHidden : 1; // 0x58(0x01)
	char bTearOff : 1; // 0x59(0x01)
	char bForceNetAddressable : 1; // 0x59(0x01)
	char bExchangedRoles : 1; // 0x59(0x01)
	char bNetLoadOnClient : 1; // 0x59(0x01)
	char bNetUseOwnerRelevancy : 1; // 0x59(0x01)
	char bRelevantForNetworkReplays : 1; // 0x59(0x01)
	char bRelevantForLevelBounds : 1; // 0x59(0x01)
	char bReplayRewindable : 1; // 0x59(0x01)
	char bAllowTickBeforeBeginPlay : 1; // 0x5a(0x01)
	char bAutoDestroyWhenFinished : 1; // 0x5a(0x01)
	char bCanBeDamaged : 1; // 0x5a(0x01)
	char bBlockInput : 1; // 0x5a(0x01)
	char bCollideWhenPlacing : 1; // 0x5a(0x01)
	char bFindCameraComponentWhenViewTarget : 1; // 0x5a(0x01)
	char bGenerateOverlapEventsDuringLevelStreaming : 1; // 0x5a(0x01)
	char bIgnoresOriginShifting : 1; // 0x5a(0x01)
	char bEnableAutoLODGeneration : 1; // 0x5b(0x01)
	char bIsEditorOnlyActor : 1; // 0x5b(0x01)
	char bActorSeamlessTraveled : 1; // 0x5b(0x01)
	char bReplicates : 1; // 0x5b(0x01)
	char bCanBeInCluster : 1; // 0x5b(0x01)
	char bAllowReceiveTickEventOnDedicatedServer : 1; // 0x5b(0x01)
	char pad_2C3_6 : 1; // 0x2c3(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x5b(0x01)
	char pad_2C4_0 : 7; // 0x2c4(0x01)
	char bActorEnableCollision : 1; // 0x5c(0x01)
	char bActorIsBeingDestroyed : 1; // 0x5d(0x01)
	char pad_2C5_1 : 4; // 0x2c5(0x01)
	char bAsyncPhysicsTickEnabled : 1; // 0x5d(0x01)
	enum class EActorUpdateOverlapsMethod UpdateOverlapsMethodDuringLevelStreaming; // 0x5e(0x01)
	enum class EActorUpdateOverlapsMethod DefaultUpdateOverlapsMethodDuringLevelStreaming; // 0x5f(0x01)
	float InitialLifeSpan; // 0x60(0x04)
	float CustomTimeDilation; // 0x64(0x04)
	enum class ENetRole RemoteRole; // 0x68(0x01)
	int32_t RayTracingGroupId; // 0x6c(0x04)
	struct FRepAttachment AttachmentReplication; // 0x70(0x60)
	struct FRepMovement ReplicatedMovement; // 0xd0(0x70)
	struct AActor* Owner; // 0x140(0x08)
	struct FName NetDriverName; // 0x148(0x08)
	enum class ENetRole Role; // 0x150(0x01)
	enum class ENetDormancy NetDormancy; // 0x151(0x01)
	enum class ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingMethod; // 0x152(0x01)
	enum class EAutoReceiveInput AutoReceiveInput; // 0x153(0x01)
	int32_t InputPriority; // 0x154(0x04)
	struct UInputComponent* InputComponent; // 0x160(0x08)
	float NetCullDistanceSquared; // 0x168(0x04)
	int32_t NetTag; // 0x16c(0x04)
	float NetUpdateFrequency; // 0x170(0x04)
	float MinNetUpdateFrequency; // 0x174(0x04)
	float NetPriority; // 0x178(0x04)
	struct APawn* Instigator; // 0x180(0x08)
	struct TArray<struct AActor*> Children; // 0x188(0x10)
	struct USceneComponent* RootComponent; // 0x198(0x08)
	struct TArray<struct FName> Layers; // 0x1a8(0x10)
	struct TWeakObjectPtr<struct UChildActorComponent> ParentComponent; // 0x1b8(0x08)
	struct TArray<struct FName> Tags; // 0x1c0(0x10)
	struct FMulticastSparseDelegate OnTakeAnyDamage; // 0x1d0(0x01)
	struct FMulticastSparseDelegate OnTakePointDamage; // 0x1d1(0x01)
	struct FMulticastSparseDelegate OnTakeRadialDamage; // 0x1d2(0x01)
	struct FMulticastSparseDelegate OnActorBeginOverlap; // 0x1d3(0x01)
	struct FMulticastSparseDelegate OnActorEndOverlap; // 0x1d4(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x1d5(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x1d6(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x1d7(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x1d8(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x1d9(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x1da(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x1db(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x1dc(0x01)
	struct FMulticastSparseDelegate OnActorHit; // 0x1dd(0x01)
	struct FMulticastSparseDelegate OnDestroyed; // 0x1de(0x01)
	struct FMulticastSparseDelegate OnEndPlay; // 0x1df(0x01)
	struct TArray<struct UActorComponent*> InstanceComponents; // 0x260(0x10)
	struct TArray<struct UActorComponent*> BlueprintCreatedComponents; // 0x270(0x10)
};

// Class Engine.RadialForceActor
// Size: 0x298 (Inherited: 0x290)
struct ARadialForceActor : ARigidBodyBase {
	struct URadialForceComponent* ForceComponent; // 0x290(0x08)

	void ToggleForce(); // Function Engine.RadialForceActor.ToggleForce // (None) // @ game+0xffffcae6df830041
};

// Class Engine.RVOAvoidanceInterface
// Size: 0x28 (Inherited: 0x28)
struct URVOAvoidanceInterface : UInterface {
};

// Class Engine.Scene
// Size: 0x28 (Inherited: 0x28)
struct UScene : UObject {
};

// Class Engine.SceneCapture2D
// Size: 0x2a8 (Inherited: 0x2a0)
struct ASceneCapture2D : ASceneCapture {
	struct USceneCaptureComponent2D* CaptureComponent2D; // 0x2a0(0x08)

	void OnInterpToggle(bool bEnable); // Function Engine.SceneCapture2D.OnInterpToggle // (None) // @ game+0xffffcaa5df830041
};

// Class Engine.SceneCaptureComponent2D
// Size: 0xb50 (Inherited: 0x360)
struct USceneCaptureComponent2D : USceneCaptureComponent {
	enum class ECameraProjectionMode ProjectionType; // 0x358(0x01)
	float FOVAngle; // 0x35c(0x04)
	float OrthoWidth; // 0x360(0x04)
	struct UTextureRenderTarget2D* TextureTarget; // 0x368(0x08)
	enum class ESceneCaptureCompositeMode CompositeMode; // 0x370(0x01)
	char pad_372[0xe]; // 0x372(0x0e)
	struct FPostProcessSettings PostProcessSettings; // 0x380(0x6e0)
	float PostProcessBlendWeight; // 0xa60(0x04)
	char bOverride_CustomNearClippingPlane : 1; // 0xa64(0x01)
	char pad_A64_1 : 7; // 0xa64(0x01)
	char pad_A65[0x3]; // 0xa65(0x03)
	float CustomNearClippingPlane; // 0xa68(0x04)
	bool bUseCustomProjectionMatrix; // 0xa6c(0x01)
	char pad_A6D[0x3]; // 0xa6d(0x03)
	struct FMatrix CustomProjectionMatrix; // 0xa70(0x80)
	bool bUseFauxOrthoViewPos; // 0xaf0(0x01)
	bool bEnableOrthographicTiling; // 0xaf1(0x01)
	char pad_AF2[0x2]; // 0xaf2(0x02)
	int32_t NumXTiles; // 0xaf4(0x04)
	int32_t NumYTiles; // 0xaf8(0x04)
	bool bEnableClipPlane; // 0xafc(0x01)
	char pad_AFD[0x3]; // 0xafd(0x03)
	struct FVector ClipPlaneBase; // 0xb00(0x18)
	struct FVector ClipPlaneNormal; // 0xb18(0x18)
	char bCameraCutThisFrame : 1; // 0xb30(0x01)
	char bConsiderUnrenderedOpaquePixelAsFullyTranslucent : 1; // 0xb30(0x01)
	char pad_B30_2 : 6; // 0xb30(0x01)
	char pad_B31[0x1f]; // 0xb31(0x1f)

	void RemoveBlendable(struct TScriptInterface<IBlendableInterface> InBlendableObject); // Function Engine.SceneCaptureComponent2D.RemoveBlendable // (None) // @ game+0xffffcaa8df830041
};

// Class Engine.SceneCaptureComponentCube
// Size: 0x370 (Inherited: 0x360)
struct USceneCaptureComponentCube : USceneCaptureComponent {
	struct UTextureRenderTargetCube* TextureTarget; // 0x358(0x08)
	bool bCaptureRotation; // 0x360(0x01)
	char pad_369[0x7]; // 0x369(0x07)

	void CaptureScene(); // Function Engine.SceneCaptureComponentCube.CaptureScene // (None) // @ game+0xffffcaa9df830041
};

// Class Engine.SceneCaptureCube
// Size: 0x2a8 (Inherited: 0x2a0)
struct ASceneCaptureCube : ASceneCapture {
	struct USceneCaptureComponentCube* CaptureComponentCube; // 0x2a0(0x08)

	void OnInterpToggle(bool bEnable); // Function Engine.SceneCaptureCube.OnInterpToggle // (None) // @ game+0xffffcaaadf830041
};

// Class Engine.ServerStreamingLevelsVisibility
// Size: 0x2e0 (Inherited: 0x290)
struct AServerStreamingLevelsVisibility : AActor {
	struct FActorTickFunction PrimaryActorTick; // 0x28(0x30)
	char bNetTemporary : 1; // 0x58(0x01)
	char pad_2C0_1 : 1; // 0x2c0(0x01)
	char bOnlyRelevantToOwner : 1; // 0x58(0x01)
	char bAlwaysRelevant : 1; // 0x58(0x01)
	char bReplicateMovement : 1; // 0x58(0x01)
	char bCallPreReplication : 1; // 0x58(0x01)
	char bCallPreReplicationForReplay : 1; // 0x58(0x01)
	char bHidden : 1; // 0x58(0x01)
	char bTearOff : 1; // 0x59(0x01)
	char bForceNetAddressable : 1; // 0x59(0x01)
	char bExchangedRoles : 1; // 0x59(0x01)
	char bNetLoadOnClient : 1; // 0x59(0x01)
	char bNetUseOwnerRelevancy : 1; // 0x59(0x01)
	char bRelevantForNetworkReplays : 1; // 0x59(0x01)
	char bRelevantForLevelBounds : 1; // 0x59(0x01)
	char bReplayRewindable : 1; // 0x59(0x01)
	char bAllowTickBeforeBeginPlay : 1; // 0x5a(0x01)
	char bAutoDestroyWhenFinished : 1; // 0x5a(0x01)
	char bCanBeDamaged : 1; // 0x5a(0x01)
	char bBlockInput : 1; // 0x5a(0x01)
	char bCollideWhenPlacing : 1; // 0x5a(0x01)
	char bFindCameraComponentWhenViewTarget : 1; // 0x5a(0x01)
	char bGenerateOverlapEventsDuringLevelStreaming : 1; // 0x5a(0x01)
	char bIgnoresOriginShifting : 1; // 0x5a(0x01)
	char bEnableAutoLODGeneration : 1; // 0x5b(0x01)
	char bIsEditorOnlyActor : 1; // 0x5b(0x01)
	char bActorSeamlessTraveled : 1; // 0x5b(0x01)
	char bReplicates : 1; // 0x5b(0x01)
	char bCanBeInCluster : 1; // 0x5b(0x01)
	char bAllowReceiveTickEventOnDedicatedServer : 1; // 0x5b(0x01)
	char pad_2C3_6 : 1; // 0x2c3(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x5b(0x01)
	char pad_2C4_0 : 7; // 0x2c4(0x01)
	char bActorEnableCollision : 1; // 0x5c(0x01)
	char bActorIsBeingDestroyed : 1; // 0x5d(0x01)
	char pad_2C5_1 : 4; // 0x2c5(0x01)
	char bAsyncPhysicsTickEnabled : 1; // 0x5d(0x01)
	enum class EActorUpdateOverlapsMethod UpdateOverlapsMethodDuringLevelStreaming; // 0x5e(0x01)
	enum class EActorUpdateOverlapsMethod DefaultUpdateOverlapsMethodDuringLevelStreaming; // 0x5f(0x01)
	float InitialLifeSpan; // 0x60(0x04)
	float CustomTimeDilation; // 0x64(0x04)
	enum class ENetRole RemoteRole; // 0x68(0x01)
	int32_t RayTracingGroupId; // 0x6c(0x04)
	struct FRepAttachment AttachmentReplication; // 0x70(0x60)
	struct FRepMovement ReplicatedMovement; // 0xd0(0x70)
	struct AActor* Owner; // 0x140(0x08)
	struct FName NetDriverName; // 0x148(0x08)
	enum class ENetRole Role; // 0x150(0x01)
	enum class ENetDormancy NetDormancy; // 0x151(0x01)
	enum class ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingMethod; // 0x152(0x01)
	enum class EAutoReceiveInput AutoReceiveInput; // 0x153(0x01)
	int32_t InputPriority; // 0x154(0x04)
	struct UInputComponent* InputComponent; // 0x160(0x08)
	float NetCullDistanceSquared; // 0x168(0x04)
	int32_t NetTag; // 0x16c(0x04)
	float NetUpdateFrequency; // 0x170(0x04)
	float MinNetUpdateFrequency; // 0x174(0x04)
	float NetPriority; // 0x178(0x04)
	struct APawn* Instigator; // 0x180(0x08)
	struct TArray<struct AActor*> Children; // 0x188(0x10)
	struct USceneComponent* RootComponent; // 0x198(0x08)
	struct TArray<struct FName> Layers; // 0x1a8(0x10)
	struct TWeakObjectPtr<struct UChildActorComponent> ParentComponent; // 0x1b8(0x08)
	struct TArray<struct FName> Tags; // 0x1c0(0x10)
	struct FMulticastSparseDelegate OnTakeAnyDamage; // 0x1d0(0x01)
	struct FMulticastSparseDelegate OnTakePointDamage; // 0x1d1(0x01)
	struct FMulticastSparseDelegate OnTakeRadialDamage; // 0x1d2(0x01)
	struct FMulticastSparseDelegate OnActorBeginOverlap; // 0x1d3(0x01)
	struct FMulticastSparseDelegate OnActorEndOverlap; // 0x1d4(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x1d5(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x1d6(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x1d7(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x1d8(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x1d9(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x1da(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x1db(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x1dc(0x01)
	struct FMulticastSparseDelegate OnActorHit; // 0x1dd(0x01)
	struct FMulticastSparseDelegate OnDestroyed; // 0x1de(0x01)
	struct FMulticastSparseDelegate OnEndPlay; // 0x1df(0x01)
	struct TArray<struct UActorComponent*> InstanceComponents; // 0x260(0x10)
	struct TArray<struct UActorComponent*> BlueprintCreatedComponents; // 0x270(0x10)
};

// Class Engine.ShadowMapTexture2D
// Size: 0x2b0 (Inherited: 0x2b0)
struct UShadowMapTexture2D : UTexture2D {
	enum class EShadowMapFlags ShadowmapFlags; // 0x2a8(0x01)
};

// Class Engine.SkeletalMeshSocket
// Size: 0x88 (Inherited: 0x28)
struct USkeletalMeshSocket : UObject {
	struct FName SocketName; // 0x28(0x08)
	struct FName BoneName; // 0x30(0x08)
	struct FVector RelativeLocation; // 0x38(0x18)
	struct FRotator RelativeRotation; // 0x50(0x18)
	struct FVector RelativeScale; // 0x68(0x18)
	bool bForceAlwaysAnimated; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)

	void InitializeSocketFromLocation(struct USkeletalMeshComponent* SkelComp, struct FVector WorldLocation, struct FVector WorldNormal); // Function Engine.SkeletalMeshSocket.InitializeSocketFromLocation // (None) // @ game+0xffffcaacdf830041
};

// Class Engine.SkinnedAsset
// Size: 0xd8 (Inherited: 0xd0)
struct USkinnedAsset : UStreamableRenderAsset {
	double ForceMipLevelsToBeResidentTimestamp; // 0x40(0x08)
	int32_t NumCinematicMipLevels; // 0x48(0x04)
	struct FPerQualityLevelInt NoRefStreamingLODBias; // 0x50(0x68)
	int32_t StreamingIndex; // 0xb8(0x04)
	int32_t CachedCombinedLODBias; // 0xbc(0x04)
	char NeverStream : 1; // 0xc0(0x01)
	char bGlobalForceMipLevelsToBeResident : 1; // 0xc0(0x01)
	char bHasStreamingUpdatePending : 1; // 0xc0(0x01)
	char bForceMiplevelsToBeResident : 1; // 0xc0(0x01)
	char bIgnoreStreamingMipBias : 1; // 0xc0(0x01)
	char bUseCinematicMipLevels : 1; // 0xc0(0x01)

	struct USkeletalMeshSocket* FindSocketInfo(struct FName InSocketName, struct FTransform& OutTransform, int32_t& OutBoneIndex, int32_t& OutIndex); // Function Engine.SkinnedAsset.FindSocketInfo // (None) // @ game+0xffffcaaedf830041
};

// Class Engine.SkyLightComponent
// Size: 0x4b0 (Inherited: 0x2e0)
struct USkyLightComponent : ULightComponentBase {
	bool bRealTimeCapture; // 0x2d8(0x01)
	enum class ESkyLightSourceType SourceType; // 0x2d9(0x01)
	struct UTextureCube* Cubemap; // 0x2e0(0x08)
	float SourceCubemapAngle; // 0x2e8(0x04)
	int32_t CubemapResolution; // 0x2ec(0x04)
	float SkyDistanceThreshold; // 0x2f0(0x04)
	bool bCaptureEmissiveOnly; // 0x2f4(0x01)
	bool bLowerHemisphereIsBlack; // 0x2f5(0x01)
	struct FLinearColor LowerHemisphereColor; // 0x2f8(0x10)
	float OcclusionMaxDistance; // 0x308(0x04)
	float Contrast; // 0x30c(0x04)
	float OcclusionExponent; // 0x310(0x04)
	float MinOcclusion; // 0x314(0x04)
	struct FColor OcclusionTint; // 0x318(0x04)
	char bCloudAmbientOcclusion : 1; // 0x31c(0x01)
	char pad_31C_1 : 7; // 0x31c(0x01)
	char pad_31D[0x3]; // 0x31d(0x03)
	float CloudAmbientOcclusionStrength; // 0x320(0x04)
	float CloudAmbientOcclusionExtent; // 0x324(0x04)
	float CloudAmbientOcclusionMapResolutionScale; // 0x328(0x04)
	float CloudAmbientOcclusionApertureScale; // 0x32c(0x04)
	enum class EOcclusionCombineMode OcclusionCombineMode; // 0x330(0x01)
	char pad_331[0xa7]; // 0x331(0xa7)
	struct UTextureCube* BlendDestinationCubemap; // 0x3d8(0x08)
	char pad_3E0[0xd0]; // 0x3e0(0xd0)

	void SetVolumetricScatteringIntensity(float NewIntensity); // Function Engine.SkyLightComponent.SetVolumetricScatteringIntensity // (None) // @ game+0xffffcabbdf830041
};

// Class Engine.SMInstanceManager
// Size: 0x28 (Inherited: 0x28)
struct USMInstanceManager : UInterface {
};

// Class Engine.SMInstanceManagerProvider
// Size: 0x28 (Inherited: 0x28)
struct USMInstanceManagerProvider : UInterface {
};

// Class Engine.SoundAttenuation
// Size: 0x3f0 (Inherited: 0x28)
struct USoundAttenuation : UObject {
	struct FSoundAttenuationSettings Attenuation; // 0x28(0x3c8)
};

// Class Engine.SoundEffectPresetWidgetInterface
// Size: 0x28 (Inherited: 0x28)
struct USoundEffectPresetWidgetInterface : UAudioPanelWidgetInterface {

	void OnPropertyChanged(struct USoundEffectPreset* Preset, struct FName PropertyName); // Function Engine.SoundEffectPresetWidgetInterface.OnPropertyChanged // (None) // @ game+0xffffcabedf830041
};

// Class Engine.SoundEffectSourcePresetChain
// Size: 0x40 (Inherited: 0x28)
struct USoundEffectSourcePresetChain : UObject {
	struct TArray<struct FSourceEffectChainEntry> chain; // 0x28(0x10)
	char bPlayEffectChainTails : 1; // 0x38(0x01)
	char pad_38_1 : 7; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// Class Engine.SoundGroups
// Size: 0x88 (Inherited: 0x28)
struct USoundGroups : UObject {
	struct TArray<struct FSoundGroup> SoundGroupProfiles; // 0x28(0x10)
	char pad_38[0x50]; // 0x38(0x50)
};

// Class Engine.SoundNode
// Size: 0x48 (Inherited: 0x28)
struct USoundNode : UObject {
	struct TArray<struct USoundNode*> ChildNodes; // 0x28(0x10)
	char pad_38[0x10]; // 0x38(0x10)
};

// Class Engine.SoundNodeModulatorContinuous
// Size: 0x88 (Inherited: 0x48)
struct USoundNodeModulatorContinuous : USoundNode {
	struct FModulatorContinuousParams PitchModulationParams; // 0x48(0x20)
	struct FModulatorContinuousParams VolumeModulationParams; // 0x68(0x20)
};

// Class Engine.SoundSubmixWidgetInterface
// Size: 0x28 (Inherited: 0x28)
struct USoundSubmixWidgetInterface : UInterface {

	void OnConstructed(struct USoundSubmixBase* SoundSubmix); // Function Engine.SoundSubmixWidgetInterface.OnConstructed // (None) // @ game+0xffffcabfdf830041
};

// Class Engine.SphereReflectionCapture
// Size: 0x2a0 (Inherited: 0x298)
struct ASphereReflectionCapture : AReflectionCapture {
	struct UDrawSphereComponent* DrawCaptureRadius; // 0x298(0x08)
};

// Class Engine.SphereReflectionCaptureComponent
// Size: 0x320 (Inherited: 0x310)
struct USphereReflectionCaptureComponent : UReflectionCaptureComponent {
	float InfluenceRadius; // 0x310(0x04)
	float CaptureDistanceScale; // 0x314(0x04)
	struct UDrawSphereComponent* PreviewInfluenceRadius; // 0x318(0x08)
};

// Class Engine.StaticMesh
// Size: 0x258 (Inherited: 0xd0)
struct UStaticMesh : UStreamableRenderAsset {
	char pad_D0[0x20]; // 0xd0(0x20)
	struct FPerQualityLevelInt MinQualityLevelLOD; // 0xf0(0x68)
	struct FPerPlatformInt MinLOD; // 0x158(0x04)
	char pad_15C[0x4]; // 0x15c(0x04)
	struct TArray<struct FStaticMaterial> StaticMaterials; // 0x160(0x10)
	float LightmapUVDensity; // 0x170(0x04)
	int32_t LightMapResolution; // 0x174(0x04)
	int32_t LightMapCoordinateIndex; // 0x178(0x04)
	float DistanceFieldSelfShadowBias; // 0x17c(0x04)
	struct UBodySetup* BodySetup; // 0x180(0x08)
	int32_t LODForCollision; // 0x188(0x04)
	char bGenerateMeshDistanceField : 1; // 0x18c(0x01)
	char bStripComplexCollisionForConsole : 1; // 0x18c(0x01)
	char bHasNavigationData : 1; // 0x18c(0x01)
	char bSupportUniformlyDistributedSampling : 1; // 0x18c(0x01)
	char bSupportPhysicalMaterialMasks : 1; // 0x18c(0x01)
	char bSupportRayTracing : 1; // 0x18c(0x01)
	char bDoFastBuild : 1; // 0x18c(0x01)
	char bIsBuiltAtRuntime : 1; // 0x18c(0x01)
	char pad_18D_0 : 1; // 0x18d(0x01)
	char bAllowCPUAccess : 1; // 0x18d(0x01)
	char bSupportGpuUniformlyDistributedSampling : 1; // 0x18d(0x01)
	char pad_18D_3 : 5; // 0x18d(0x01)
	char pad_18E[0x22]; // 0x18e(0x22)
	struct TArray<struct UStaticMeshSocket*> Sockets; // 0x1b0(0x10)
	char pad_1C0[0x10]; // 0x1c0(0x10)
	struct FVector PositiveBoundsExtension; // 0x1d0(0x18)
	struct FVector NegativeBoundsExtension; // 0x1e8(0x18)
	struct FBoxSphereBounds ExtendedBounds; // 0x200(0x38)
	int32_t ElementToIgnoreForTexFactor; // 0x238(0x04)
	char pad_23C[0x4]; // 0x23c(0x04)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x240(0x10)
	struct UNavCollisionBase* NavCollision; // 0x250(0x08)

	void SetStaticMaterials(struct TArray<struct FStaticMaterial>& InStaticMaterials); // Function Engine.StaticMesh.SetStaticMaterials // (None) // @ game+0xffffcad8df830041
};

// Class Engine.StaticMeshSocket
// Size: 0x88 (Inherited: 0x28)
struct UStaticMeshSocket : UObject {
	struct FName SocketName; // 0x28(0x08)
	struct FVector RelativeLocation; // 0x30(0x18)
	struct FRotator RelativeRotation; // 0x48(0x18)
	struct FVector RelativeScale; // 0x60(0x18)
	struct FString Tag; // 0x78(0x10)
};

// Class Engine.StereoLayerShape
// Size: 0x28 (Inherited: 0x28)
struct UStereoLayerShape : UObject {
};

// Class Engine.StereoLayerShapeQuad
// Size: 0x28 (Inherited: 0x28)
struct UStereoLayerShapeQuad : UStereoLayerShape {
};

// Class Engine.StereoLayerShapeCylinder
// Size: 0x38 (Inherited: 0x28)
struct UStereoLayerShapeCylinder : UStereoLayerShape {
	float Radius; // 0x28(0x04)
	float OverlayArc; // 0x2c(0x04)
	int32_t Height; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)

	void SetRadius(float InRadius); // Function Engine.StereoLayerShapeCylinder.SetRadius // (None) // @ game+0xffffcadbdf830041
};

// Class Engine.StereoLayerShapeCubemap
// Size: 0x28 (Inherited: 0x28)
struct UStereoLayerShapeCubemap : UStereoLayerShape {
};

// Class Engine.StereoLayerShapeEquirect
// Size: 0xb8 (Inherited: 0x28)
struct UStereoLayerShapeEquirect : UStereoLayerShape {
	struct FBox2D LeftUVRect; // 0x28(0x28)
	struct FBox2D RightUVRect; // 0x50(0x28)
	struct FVector2D LeftScale; // 0x78(0x10)
	struct FVector2D RightScale; // 0x88(0x10)
	struct FVector2D LeftBias; // 0x98(0x10)
	struct FVector2D RightBias; // 0xa8(0x10)

	void SetEquirectProps(struct FEquirectProps InScaleBiases); // Function Engine.StereoLayerShapeEquirect.SetEquirectProps // (None) // @ game+0xffffcadcdf830041
};

// Class Engine.StereoLayerComponent
// Size: 0x430 (Inherited: 0x2a0)
struct UStereoLayerComponent : USceneComponent {
	char bLiveTexture : 1; // 0x2a0(0x01)
	char bSupportsDepth : 1; // 0x2a0(0x01)
	char bNoAlphaChannel : 1; // 0x2a0(0x01)
	char pad_2A0_3 : 5; // 0x2a0(0x01)
	char pad_2A1[0x7]; // 0x2a1(0x07)
	struct UTexture* Texture; // 0x2a8(0x08)
	struct UTexture* LeftTexture; // 0x2b0(0x08)
	char bQuadPreserveTextureRatio : 1; // 0x2b8(0x01)
	char pad_2B8_1 : 7; // 0x2b8(0x01)
	char pad_2B9[0x7]; // 0x2b9(0x07)
	struct FVector2D QuadSize; // 0x2c0(0x10)
	struct FBox2D UVRect; // 0x2d0(0x28)
	float CylinderRadius; // 0x2f8(0x04)
	float CylinderOverlayArc; // 0x2fc(0x04)
	int32_t CylinderHeight; // 0x300(0x04)
	char pad_304[0x4]; // 0x304(0x04)
	struct FEquirectProps EquirectProps; // 0x308(0x90)
	enum class EStereoLayerType StereoLayerType; // 0x398(0x01)
	enum class EStereoLayerShape StereoLayerShape; // 0x399(0x01)
	char pad_39A[0x6]; // 0x39a(0x06)
	struct UStereoLayerShape* Shape; // 0x3a0(0x08)
	int32_t Priority; // 0x3a8(0x04)
	char pad_3AC[0x84]; // 0x3ac(0x84)

	void SetUVRect(struct FBox2D InUVRect); // Function Engine.StereoLayerComponent.SetUVRect // (None) // @ game+0xffffcae8df830041
};

// Class Engine.SubUVAnimation
// Size: 0x68 (Inherited: 0x28)
struct USubUVAnimation : UObject {
	struct UTexture2D* SubUVTexture; // 0x28(0x08)
	int32_t SubImages_Horizontal; // 0x30(0x04)
	int32_t SubImages_Vertical; // 0x34(0x04)
	enum class ESubUVBoundingVertexCount BoundingMode; // 0x38(0x01)
	enum class EOpacitySourceMode OpacitySourceMode; // 0x39(0x01)
	char pad_3A[0x2]; // 0x3a(0x02)
	float AlphaThreshold; // 0x3c(0x04)
	char pad_40[0x28]; // 0x40(0x28)
};

// Class Engine.TextPropertyTestObject
// Size: 0x70 (Inherited: 0x28)
struct UTextPropertyTestObject : UObject {
	struct FText DefaultedText; // 0x28(0x18)
	struct FText UndefaultedText; // 0x40(0x18)
	struct FText TransientText; // 0x58(0x18)
};

// Class Engine.TextRenderActor
// Size: 0x298 (Inherited: 0x290)
struct ATextRenderActor : AActor {
	struct UTextRenderComponent* TextRender; // 0x290(0x08)
};

// Class Engine.TextRenderComponent
// Size: 0x590 (Inherited: 0x540)
struct UTextRenderComponent : UPrimitiveComponent {
	struct FText Text; // 0x538(0x18)
	struct UMaterialInterface* TextMaterial; // 0x550(0x08)
	struct UFont* Font; // 0x558(0x08)
	enum class EHorizTextAligment HorizontalAlignment; // 0x560(0x01)
	enum class EVerticalTextAligment VerticalAlignment; // 0x561(0x01)
	struct FColor TextRenderColor; // 0x564(0x04)
	float XScale; // 0x568(0x04)
	float YScale; // 0x56c(0x04)
	float WorldSize; // 0x570(0x04)
	float InvDefaultSize; // 0x574(0x04)
	float HorizSpacingAdjust; // 0x578(0x04)
	float VertSpacingAdjust; // 0x57c(0x04)
	char bAlwaysRenderAsText : 1; // 0x580(0x01)
	char pad_586_1 : 7; // 0x586(0x01)
	char pad_587[0x9]; // 0x587(0x09)

	void SetYScale(float Value); // Function Engine.TextRenderComponent.SetYScale // (None) // @ game+0xffffcaf5df830041
};

// Class Engine.TextureRenderTarget
// Size: 0x200 (Inherited: 0x1f0)
struct UTextureRenderTarget : UTexture {
	float TargetGamma; // 0x1f0(0x04)
	char pad_1F4[0xc]; // 0x1f4(0x0c)
};

// Class Engine.TextureRenderTarget2D
// Size: 0x220 (Inherited: 0x200)
struct UTextureRenderTarget2D : UTextureRenderTarget {
	int32_t SizeX; // 0x1f8(0x04)
	int32_t SizeY; // 0x1fc(0x04)
	struct FLinearColor ClearColor; // 0x200(0x10)
	enum class TextureAddress AddressX; // 0x210(0x01)
	enum class TextureAddress AddressY; // 0x211(0x01)
	char bForceLinearGamma : 1; // 0x212(0x01)
	char bHDR : 1; // 0x212(0x01)
	char bGPUSharedFlag : 1; // 0x212(0x01)
	enum class ETextureRenderTargetFormat RenderTargetFormat; // 0x213(0x01)
	char bAutoGenerateMips : 1; // 0x214(0x01)
	enum class TextureFilter MipsSamplerFilter; // 0x215(0x01)
	enum class TextureAddress MipsAddressU; // 0x216(0x01)
	enum class TextureAddress MipsAddressV; // 0x217(0x01)
	enum class EPixelFormat OverrideFormat; // 0x218(0x01)
	char pad_21F_4 : 4; // 0x21f(0x01)
};

// Class Engine.TimelineComponent
// Size: 0x140 (Inherited: 0xa0)
struct UTimelineComponent : UActorComponent {
	struct FTimeline TheTimeline; // 0xa0(0x98)
	char bIgnoreTimeDilation : 1; // 0x138(0x01)
	char pad_138_1 : 7; // 0x138(0x01)
	char pad_139[0x7]; // 0x139(0x07)

	void Stop(); // Function Engine.TimelineComponent.Stop // (None) // @ game+0xffffcb0ddf830041
};

// Class Engine.TriggerBase
// Size: 0x298 (Inherited: 0x290)
struct ATriggerBase : AActor {
	struct UShapeComponent* CollisionComponent; // 0x290(0x08)
};

// Class Engine.TriggerBox
// Size: 0x298 (Inherited: 0x298)
struct ATriggerBox : ATriggerBase {
	struct UShapeComponent* CollisionComponent; // 0x290(0x08)
};

// Class Engine.TriggerCapsule
// Size: 0x298 (Inherited: 0x298)
struct ATriggerCapsule : ATriggerBase {
	struct UShapeComponent* CollisionComponent; // 0x290(0x08)
};

// Class Engine.TriggerSphere
// Size: 0x298 (Inherited: 0x298)
struct ATriggerSphere : ATriggerBase {
	struct UShapeComponent* CollisionComponent; // 0x290(0x08)
};

// Class Engine.TwitterIntegrationBase
// Size: 0x38 (Inherited: 0x38)
struct UTwitterIntegrationBase : UPlatformInterfaceBase {
	struct TArray<struct FDelegateArray> AllDelegates; // 0x28(0x10)

	bool TwitterRequest(struct FString URL, struct TArray<struct FString>& ParamKeysAndValues, enum class ETwitterRequestMethod RequestMethod, int32_t AccountIndex); // Function Engine.TwitterIntegrationBase.TwitterRequest // (None) // @ game+0xffffcb14df830041
};

// Class Engine.UserDefinedStruct
// Size: 0x108 (Inherited: 0xc0)
struct UUserDefinedStruct : UScriptStruct {
	enum class EUserDefinedStructureStatus Status; // 0xc0(0x01)
	char pad_C1[0x3]; // 0xc1(0x03)
	struct FGuid Guid; // 0xc4(0x10)
	char pad_D4[0x34]; // 0xd4(0x34)
};

// Class Engine.VectorField
// Size: 0x68 (Inherited: 0x28)
struct UVectorField : UObject {
	struct FBox Bounds; // 0x28(0x38)
	float Intensity; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
};

// Class Engine.VectorFieldAnimated
// Size: 0xa8 (Inherited: 0x68)
struct UVectorFieldAnimated : UVectorField {
	struct UTexture2D* Texture; // 0x68(0x08)
	enum class EVectorFieldConstructionOp ConstructionOp; // 0x70(0x01)
	char pad_71[0x3]; // 0x71(0x03)
	int32_t VolumeSizeX; // 0x74(0x04)
	int32_t VolumeSizeY; // 0x78(0x04)
	int32_t VolumeSizeZ; // 0x7c(0x04)
	int32_t SubImagesX; // 0x80(0x04)
	int32_t SubImagesY; // 0x84(0x04)
	int32_t FrameCount; // 0x88(0x04)
	float FramesPerSecond; // 0x8c(0x04)
	char bLoop : 1; // 0x90(0x01)
	char pad_90_1 : 7; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
	struct UVectorFieldStatic* NoiseField; // 0x98(0x08)
	float NoiseScale; // 0xa0(0x04)
	float NoiseMax; // 0xa4(0x04)
};

// Class Engine.VectorFieldComponent
// Size: 0x560 (Inherited: 0x540)
struct UVectorFieldComponent : UPrimitiveComponent {
	struct UVectorField* VectorField; // 0x538(0x08)
	float Intensity; // 0x540(0x04)
	float Tightness; // 0x544(0x04)
	char bPreviewVectorField : 1; // 0x548(0x01)
	char pad_550_1 : 7; // 0x550(0x01)
	char pad_551[0xf]; // 0x551(0x0f)

	void SetIntensity(float NewIntensity); // Function Engine.VectorFieldComponent.SetIntensity // (None) // @ game+0xffffcb15df830041
};

// Class Engine.VectorFieldStatic
// Size: 0xb0 (Inherited: 0x68)
struct UVectorFieldStatic : UVectorField {
	int32_t SizeX; // 0x68(0x04)
	int32_t SizeY; // 0x6c(0x04)
	int32_t SizeZ; // 0x70(0x04)
	bool bAllowCPUAccess; // 0x74(0x01)
	char pad_75[0x3b]; // 0x75(0x3b)
};

// Class Engine.VisualLoggerDebugSnapshotInterface
// Size: 0x28 (Inherited: 0x28)
struct UVisualLoggerDebugSnapshotInterface : UInterface {
};

// Class Engine.WindDirectionalSourceComponent
// Size: 0x2c0 (Inherited: 0x2a0)
struct UWindDirectionalSourceComponent : USceneComponent {
	float Strength; // 0x2a0(0x04)
	float Speed; // 0x2a4(0x04)
	float MinGustAmount; // 0x2a8(0x04)
	float MaxGustAmount; // 0x2ac(0x04)
	float Radius; // 0x2b0(0x04)
	char bPointWind : 1; // 0x2b4(0x01)
	char pad_2B4_1 : 7; // 0x2b4(0x01)
	char pad_2B5[0xb]; // 0x2b5(0x0b)

	void SetWindType(enum class EWindSourceType InNewType); // Function Engine.WindDirectionalSourceComponent.SetWindType // (None) // @ game+0xffffcb1bdf830041
};

// Class Engine.WorldPartitionEditorLoaderAdapter
// Size: 0x30 (Inherited: 0x28)
struct UWorldPartitionEditorLoaderAdapter : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.WorldPartitionRuntimeCellOwner
// Size: 0x28 (Inherited: 0x28)
struct UWorldPartitionRuntimeCellOwner : UInterface {
};

// Class Engine.HierarchicalLODSetup
// Size: 0x68 (Inherited: 0x28)
struct UHierarchicalLODSetup : UObject {
	struct TArray<struct FHierarchicalSimplification> HierarchicalLODSetup; // 0x28(0x10)
	struct TSoftObjectPtr<UMaterialInterface> OverrideBaseMaterial; // 0x38(0x30)
};

// Class Engine.Texture2DArray
// Size: 0x2a0 (Inherited: 0x1f0)
struct UTexture2DArray : UTexture {
	char pad_1F0[0xa0]; // 0x1f0(0xa0)
	enum class TextureAddress AddressX; // 0x290(0x01)
	enum class TextureAddress AddressY; // 0x291(0x01)
	enum class TextureAddress AddressZ; // 0x292(0x01)
	char pad_293[0xd]; // 0x293(0x0d)
};

// Class Engine.Level
// Size: 0x318 (Inherited: 0x28)
struct ULevel : UObject {
	char pad_28[0x90]; // 0x28(0x90)
	struct UWorld* OwningWorld; // 0xb8(0x08)
	struct UModel* Model; // 0xc0(0x08)
	struct TArray<struct UModelComponent*> ModelComponents; // 0xc8(0x10)
	struct ULevelActorContainer* ActorCluster; // 0xd8(0x08)
	int32_t NumTextureStreamingUnbuiltComponents; // 0xe0(0x04)
	int32_t NumTextureStreamingDirtyResources; // 0xe4(0x04)
	struct ALevelScriptActor* LevelScriptActor; // 0xe8(0x08)
	struct ANavigationObjectBase* NavListStart; // 0xf0(0x08)
	struct ANavigationObjectBase* NavListEnd; // 0xf8(0x08)
	struct TArray<struct UNavigationDataChunk*> NavDataChunks; // 0x100(0x10)
	float LightmapTotalSize; // 0x110(0x04)
	float ShadowmapTotalSize; // 0x114(0x04)
	struct TArray<struct FVector> StaticNavigableGeometry; // 0x118(0x10)
	struct TArray<struct FGuid> StreamingTextureGuids; // 0x128(0x10)
	struct TArray<struct FName> StreamingTextures; // 0x138(0x10)
	uint32_t PackedTextureStreamingQualityLevelFeatureLevel; // 0x148(0x04)
	char pad_14C[0xc4]; // 0x14c(0xc4)
	struct FGuid LevelBuildDataId; // 0x210(0x10)
	struct UMapBuildDataRegistry* MapBuildData; // 0x220(0x08)
	struct FIntVector LightBuildLevelOffset; // 0x228(0x0c)
	char bIsLightingScenario : 1; // 0x234(0x01)
	char pad_234_1 : 2; // 0x234(0x01)
	char bTextureStreamingRotationChanged : 1; // 0x234(0x01)
	char bStaticComponentsRegisteredInStreamingManager : 1; // 0x234(0x01)
	char bIsVisible : 1; // 0x234(0x01)
	char pad_234_6 : 2; // 0x234(0x01)
	char pad_235[0x1]; // 0x235(0x01)
	char pad_236_0 : 6; // 0x236(0x01)
	char bIsPartitioned : 1; // 0x236(0x01)
	char pad_236_7 : 1; // 0x236(0x01)
	char pad_237[0x61]; // 0x237(0x61)
	struct AWorldSettings* WorldSettings; // 0x298(0x08)
	struct AWorldDataLayers* WorldDataLayers; // 0x2a0(0x08)
	struct TSoftObjectPtr<UWorldPartitionRuntimeCell> WorldPartitionRuntimeCell; // 0x2a8(0x30)
	char pad_2D8[0x8]; // 0x2d8(0x08)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x2e0(0x10)
	char pad_2F0[0x10]; // 0x2f0(0x10)
	struct TArray<struct FReplicatedStaticActorDestructionInfo> DestroyedReplicatedStaticActors; // 0x300(0x10)
	char pad_310[0x8]; // 0x310(0x08)
};

// Class Engine.ActorFolder
// Size: 0x28 (Inherited: 0x28)
struct UActorFolder : UObject {
};

// Class Engine.ActorPartitionSubsystem
// Size: 0x30 (Inherited: 0x30)
struct UActorPartitionSubsystem : UWorldSubsystem {
};

// Class Engine.AISystemBase
// Size: 0x60 (Inherited: 0x28)
struct UAISystemBase : UObject {
	struct FSoftClassPath AISystemClassName; // 0x28(0x20)
	struct FName AISystemModuleName; // 0x48(0x08)
	char pad_50[0x8]; // 0x50(0x08)
	bool bInstantiateAISystemOnClient; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
};

// Class Engine.NavigationSystemBase
// Size: 0x28 (Inherited: 0x28)
struct UNavigationSystemBase : UObject {
};

// Class Engine.NavigationSystemConfig
// Size: 0x58 (Inherited: 0x28)
struct UNavigationSystemConfig : UObject {
	struct FSoftClassPath NavigationSystemClass; // 0x28(0x20)
	struct FNavAgentSelector SupportedAgentsMask; // 0x48(0x04)
	struct FName DefaultAgentName; // 0x4c(0x08)
	char bIsOverriden : 1; // 0x54(0x01)
	char pad_54_1 : 7; // 0x54(0x01)
	char pad_55[0x3]; // 0x55(0x03)
};

// Class Engine.NullNavSysConfig
// Size: 0x58 (Inherited: 0x58)
struct UNullNavSysConfig : UNavigationSystemConfig {
	struct FSoftClassPath NavigationSystemClass; // 0x28(0x20)
	struct FNavAgentSelector SupportedAgentsMask; // 0x48(0x04)
	struct FName DefaultAgentName; // 0x4c(0x08)
	char bIsOverriden : 1; // 0x54(0x01)
};

// Class Engine.AvoidanceManager
// Size: 0xe0 (Inherited: 0x28)
struct UAvoidanceManager : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	float DefaultTimeToLive; // 0x30(0x04)
	float LockTimeAfterAvoid; // 0x34(0x04)
	float LockTimeAfterClean; // 0x38(0x04)
	float DeltaTimeToPredict; // 0x3c(0x04)
	float ArtificialRadiusExpansion; // 0x40(0x04)
	float TestHeightDifference; // 0x44(0x04)
	float HeightCheckMargin; // 0x48(0x04)
	char pad_4C[0x94]; // 0x4c(0x94)

	bool RegisterMovementComponent(struct UMovementComponent* MovementComp, float AvoidanceWeight); // Function Engine.AvoidanceManager.RegisterMovementComponent // (None) // @ game+0xffffcb1fdf830041
};

// Class Engine.NavCollisionBase
// Size: 0x70 (Inherited: 0x28)
struct UNavCollisionBase : UObject {
	char bIsDynamicObstacle : 1; // 0x28(0x01)
	char pad_28_1 : 7; // 0x28(0x01)
	char pad_29[0x47]; // 0x29(0x47)
};

// Class Engine.NavigationDataChunk
// Size: 0x30 (Inherited: 0x28)
struct UNavigationDataChunk : UObject {
	struct FName NavigationDataName; // 0x28(0x08)
};

// Class Engine.AmbientSound
// Size: 0x298 (Inherited: 0x290)
struct AAmbientSound : AActor {
	struct UAudioComponent* AudioComponent; // 0x290(0x08)

	void Stop(); // Function Engine.AmbientSound.Stop // (None) // @ game+0xffffcb24df830041
};

// Class Engine.AimOffsetBlendSpace
// Size: 0x1a0 (Inherited: 0x1a0)
struct UAimOffsetBlendSpace : UBlendSpace {
	bool bContainsRotationOffsetMeshSpaceSamples; // 0x88(0x01)
	struct FInterpolationParameter InterpolationParam[0x3]; // 0x8c(0x30)
	float TargetWeightInterpolationSpeedPerSec; // 0xbc(0x04)
	bool bTargetWeightInterpolationEaseInOut; // 0xc0(0x01)
	bool bAllowMeshSpaceBlending; // 0xc1(0x01)
	bool bLoop; // 0xc2(0x01)
	float AnimLength; // 0xc4(0x04)
	enum class ENotifyTriggerMode NotifyTriggerMode; // 0xc8(0x01)
	bool bInterpolateUsingGrid; // 0xc9(0x01)
	enum class EPreferredTriangulationDirection PreferredTriangulationDirection; // 0xca(0x01)
	struct TArray<struct FPerBoneInterpolation> PerBoneBlend; // 0xd0(0x10)
	int32_t SampleIndexWithMarkers; // 0xe0(0x04)
	struct TArray<struct FBlendSample> SampleData; // 0xe8(0x10)
	struct TArray<struct FEditorElement> GridSamples; // 0xf8(0x10)
	struct FBlendSpaceData BlendSpaceData; // 0x108(0x20)
	struct FBlendParameter BlendParameters[0x3]; // 0x128(0x60)
	enum class EBlendSpaceAxis AxisToScaleAnimation; // 0x188(0x01)
	struct TArray<int32_t> DimensionIndices; // 0x190(0x10)
};

// Class Engine.BlendSpace1D
// Size: 0x1a8 (Inherited: 0x1a0)
struct UBlendSpace1D : UBlendSpace {
	bool bScaleAnimation; // 0x1a0(0x01)
	char pad_1A1[0x7]; // 0x1a1(0x07)
};

// Class Engine.AimOffsetBlendSpace1D
// Size: 0x1a8 (Inherited: 0x1a8)
struct UAimOffsetBlendSpace1D : UBlendSpace1D {
	bool bScaleAnimation; // 0x1a0(0x01)
};

// Class Engine.AnimationSettings
// Size: 0x138 (Inherited: 0x38)
struct UAnimationSettings : UDeveloperSettings {
	int32_t CompressCommandletVersion; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct TArray<struct FString> KeyEndEffectorsMatchNameArray; // 0x40(0x10)
	bool ForceRecompression; // 0x50(0x01)
	bool bForceBelowThreshold; // 0x51(0x01)
	bool bFirstRecompressUsingCurrentOrDefault; // 0x52(0x01)
	bool bRaiseMaxErrorToExisting; // 0x53(0x01)
	bool bEnablePerformanceLog; // 0x54(0x01)
	bool bStripAnimationDataOnDedicatedServer; // 0x55(0x01)
	bool bTickAnimationOnSkeletalMeshInit; // 0x56(0x01)
	char pad_57[0x1]; // 0x57(0x01)
	struct FTimecodeCustomAttributeNameSettings BoneTimecodeCustomAttributeNameSettings; // 0x58(0x38)
	struct TArray<struct FCustomAttributeSetting> BoneCustomAttributesNames; // 0x90(0x10)
	struct TArray<struct FString> BoneNamesWithCustomAttributes; // 0xa0(0x10)
	struct TMap<struct FName, enum class ECustomAttributeBlendType> AttributeBlendModes; // 0xb0(0x50)
	enum class ECustomAttributeBlendType DefaultAttributeBlendMode; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct TArray<struct FString> TransformAttributeNames; // 0x108(0x10)
	struct TArray<struct TSoftObjectPtr<UUserDefinedStruct>> UserDefinedStructAttributes; // 0x118(0x10)
	struct TArray<struct FMirrorFindReplaceExpression> MirrorFindReplaceExpressions; // 0x128(0x10)

	struct TArray<struct FString> GetBoneCustomAttributeNamesToImport(); // Function Engine.AnimationSettings.GetBoneCustomAttributeNamesToImport // (None) // @ game+0xffffcb25df830041
};

// Class Engine.AnimBlueprintGeneratedStruct
// Size: 0xc0 (Inherited: 0xc0)
struct UAnimBlueprintGeneratedStruct : UScriptStruct {
};

// Class Engine.AnimBlueprintGeneratedClass
// Size: 0x5e8 (Inherited: 0x380)
struct UAnimBlueprintGeneratedClass : UBlueprintGeneratedClass {
	char pad_380[0x8]; // 0x380(0x08)
	struct TArray<struct FBakedAnimationStateMachine> BakedStateMachines; // 0x388(0x10)
	struct USkeleton* TargetSkeleton; // 0x398(0x08)
	struct TArray<struct FAnimNotifyEvent> AnimNotifies; // 0x3a0(0x10)
	struct TMap<struct FName, struct FCachedPoseIndices> OrderedSavedPoseIndicesMap; // 0x3b0(0x50)
	char pad_400[0x80]; // 0x400(0x80)
	struct TArray<struct FName> SyncGroupNames; // 0x480(0x10)
	struct TMap<struct FName, struct FGraphAssetPlayerInformation> GraphAssetPlayerInformation; // 0x490(0x50)
	struct TMap<struct FName, struct FAnimGraphBlendOptions> GraphBlendOptions; // 0x4e0(0x50)
	struct TArray<struct FAnimNodeData> AnimNodeData; // 0x530(0x10)
	struct TMap<struct UScriptStruct*, struct FAnimNodeStructData> NodeTypeMap; // 0x540(0x50)
	char pad_590[0x58]; // 0x590(0x58)
};

// Class Engine.AnimBoneCompressionCodec
// Size: 0x38 (Inherited: 0x28)
struct UAnimBoneCompressionCodec : UObject {
	struct FString Description; // 0x28(0x10)
};

// Class Engine.AnimBoneCompressionSettings
// Size: 0x38 (Inherited: 0x28)
struct UAnimBoneCompressionSettings : UObject {
	struct TArray<struct UAnimBoneCompressionCodec*> Codecs; // 0x28(0x10)
};

// Class Engine.AnimClassData
// Size: 0x258 (Inherited: 0x28)
struct UAnimClassData : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TArray<struct FBakedAnimationStateMachine> BakedStateMachines; // 0x30(0x10)
	struct USkeleton* TargetSkeleton; // 0x40(0x08)
	struct TArray<struct FAnimNotifyEvent> AnimNotifies; // 0x48(0x10)
	struct TMap<struct FName, struct FCachedPoseIndices> OrderedSavedPoseIndicesMap; // 0x58(0x50)
	struct TArray<struct FAnimBlueprintFunction> AnimBlueprintFunctions; // 0xa8(0x10)
	struct TArray<struct FAnimBlueprintFunctionData> AnimBlueprintFunctionData; // 0xb8(0x10)
	struct TArray<struct TFieldPath<FStructProperty>> AnimNodeProperties; // 0xc8(0x10)
	char pad_D8[0x10]; // 0xd8(0x10)
	struct TArray<struct TFieldPath<FStructProperty>> LinkedAnimGraphNodeProperties; // 0xe8(0x10)
	char pad_F8[0x10]; // 0xf8(0x10)
	struct TArray<struct TFieldPath<FStructProperty>> LinkedAnimLayerNodeProperties; // 0x108(0x10)
	char pad_118[0x10]; // 0x118(0x10)
	struct TArray<struct TFieldPath<FStructProperty>> PreUpdateNodeProperties; // 0x128(0x10)
	char pad_138[0x10]; // 0x138(0x10)
	struct TArray<struct TFieldPath<FStructProperty>> DynamicResetNodeProperties; // 0x148(0x10)
	char pad_158[0x10]; // 0x158(0x10)
	struct TArray<struct TFieldPath<FStructProperty>> StateMachineNodeProperties; // 0x168(0x10)
	char pad_178[0x10]; // 0x178(0x10)
	struct TArray<struct TFieldPath<FStructProperty>> InitializationNodeProperties; // 0x188(0x10)
	char pad_198[0x10]; // 0x198(0x10)
	struct TMap<struct FName, struct FGraphAssetPlayerInformation> GraphNameAssetPlayers; // 0x1a8(0x50)
	struct TArray<struct FName> SyncGroupNames; // 0x1f8(0x10)
	struct TMap<struct FName, struct FAnimGraphBlendOptions> GraphBlendOptions; // 0x208(0x50)
};

// Class Engine.AnimClassInterface
// Size: 0x28 (Inherited: 0x28)
struct UAnimClassInterface : UInterface {
};

// Class Engine.AnimCompositeBase
// Size: 0xb0 (Inherited: 0xb0)
struct UAnimCompositeBase : UAnimSequenceBase {
	struct TArray<struct FAnimNotifyEvent> Notifies; // 0x80(0x10)
	float SequenceLength; // 0x90(0x04)
	float RateScale; // 0x94(0x04)
	bool bLoop; // 0x98(0x01)
	struct FRawCurveTracks RawCurveData; // 0xa0(0x10)
};

// Class Engine.AnimComposite
// Size: 0xc0 (Inherited: 0xb0)
struct UAnimComposite : UAnimCompositeBase {
	struct FAnimTrack AnimationTrack; // 0xb0(0x10)
};

// Class Engine.AnimCompress
// Size: 0x40 (Inherited: 0x38)
struct UAnimCompress : UAnimBoneCompressionCodec {
	char bNeedsSkeleton : 1; // 0x38(0x01)
	char pad_38_1 : 7; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	enum class AnimationCompressionFormat TranslationCompressionFormat; // 0x3c(0x01)
	enum class AnimationCompressionFormat RotationCompressionFormat; // 0x3d(0x01)
	enum class AnimationCompressionFormat ScaleCompressionFormat; // 0x3e(0x01)
	char pad_3F[0x1]; // 0x3f(0x01)
};

// Class Engine.AnimCompress_BitwiseCompressOnly
// Size: 0x40 (Inherited: 0x40)
struct UAnimCompress_BitwiseCompressOnly : UAnimCompress {
	char bNeedsSkeleton : 1; // 0x38(0x01)
	enum class AnimationCompressionFormat TranslationCompressionFormat; // 0x3c(0x01)
	enum class AnimationCompressionFormat RotationCompressionFormat; // 0x3d(0x01)
	enum class AnimationCompressionFormat ScaleCompressionFormat; // 0x3e(0x01)
};

// Class Engine.AnimCompress_LeastDestructive
// Size: 0x40 (Inherited: 0x40)
struct UAnimCompress_LeastDestructive : UAnimCompress_BitwiseCompressOnly {
	char bNeedsSkeleton : 1; // 0x38(0x01)
	enum class AnimationCompressionFormat TranslationCompressionFormat; // 0x3c(0x01)
	enum class AnimationCompressionFormat RotationCompressionFormat; // 0x3d(0x01)
	enum class AnimationCompressionFormat ScaleCompressionFormat; // 0x3e(0x01)
};

// Class Engine.AnimCompress_RemoveLinearKeys
// Size: 0x60 (Inherited: 0x40)
struct UAnimCompress_RemoveLinearKeys : UAnimCompress {
	float MaxPosDiff; // 0x40(0x04)
	float MaxAngleDiff; // 0x44(0x04)
	float MaxScaleDiff; // 0x48(0x04)
	float MaxEffectorDiff; // 0x4c(0x04)
	float MinEffectorDiff; // 0x50(0x04)
	float EffectorDiffSocket; // 0x54(0x04)
	float ParentKeyScale; // 0x58(0x04)
	char bRetarget : 1; // 0x5c(0x01)
	char bActuallyFilterLinearKeys : 1; // 0x5c(0x01)
	char pad_5C_2 : 6; // 0x5c(0x01)
	char pad_5D[0x3]; // 0x5d(0x03)
};

// Class Engine.AnimCompress_PerTrackCompression
// Size: 0xd8 (Inherited: 0x60)
struct UAnimCompress_PerTrackCompression : UAnimCompress_RemoveLinearKeys {
	float MaxZeroingThreshold; // 0x60(0x04)
	float MaxPosDiffBitwise; // 0x64(0x04)
	float MaxAngleDiffBitwise; // 0x68(0x04)
	float MaxScaleDiffBitwise; // 0x6c(0x04)
	struct TArray<enum class AnimationCompressionFormat> AllowedRotationFormats; // 0x70(0x10)
	struct TArray<enum class AnimationCompressionFormat> AllowedTranslationFormats; // 0x80(0x10)
	struct TArray<enum class AnimationCompressionFormat> AllowedScaleFormats; // 0x90(0x10)
	char bResampleAnimation : 1; // 0xa0(0x01)
	char pad_A0_1 : 7; // 0xa0(0x01)
	char pad_A1[0x3]; // 0xa1(0x03)
	float ResampledFramerate; // 0xa4(0x04)
	int32_t MinKeysForResampling; // 0xa8(0x04)
	char bUseAdaptiveError : 1; // 0xac(0x01)
	char bUseOverrideForEndEffectors : 1; // 0xac(0x01)
	char pad_AC_2 : 6; // 0xac(0x01)
	char pad_AD[0x3]; // 0xad(0x03)
	int32_t TrackHeightBias; // 0xb0(0x04)
	float ParentingDivisor; // 0xb4(0x04)
	float ParentingDivisorExponent; // 0xb8(0x04)
	char bUseAdaptiveError2 : 1; // 0xbc(0x01)
	char pad_BC_1 : 7; // 0xbc(0x01)
	char pad_BD[0x3]; // 0xbd(0x03)
	float RotationErrorSourceRatio; // 0xc0(0x04)
	float TranslationErrorSourceRatio; // 0xc4(0x04)
	float ScaleErrorSourceRatio; // 0xc8(0x04)
	float MaxErrorPerTrackRatio; // 0xcc(0x04)
	float PerturbationProbeSize; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)
};

// Class Engine.AnimCompress_RemoveEverySecondKey
// Size: 0x48 (Inherited: 0x40)
struct UAnimCompress_RemoveEverySecondKey : UAnimCompress {
	int32_t MinKeys; // 0x40(0x04)
	char bStartAtSecondKey : 1; // 0x44(0x01)
	char pad_44_1 : 7; // 0x44(0x01)
	char pad_45[0x3]; // 0x45(0x03)
};

// Class Engine.AnimCompress_RemoveTrivialKeys
// Size: 0x50 (Inherited: 0x40)
struct UAnimCompress_RemoveTrivialKeys : UAnimCompress {
	float MaxPosDiff; // 0x40(0x04)
	float MaxAngleDiff; // 0x44(0x04)
	float MaxScaleDiff; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class Engine.AnimCurveCompressionCodec
// Size: 0x28 (Inherited: 0x28)
struct UAnimCurveCompressionCodec : UObject {
};

// Class Engine.AnimCurveCompressionCodec_CompressedRichCurve
// Size: 0x28 (Inherited: 0x28)
struct UAnimCurveCompressionCodec_CompressedRichCurve : UAnimCurveCompressionCodec {
};

// Class Engine.AnimCurveCompressionCodec_UniformIndexable
// Size: 0x28 (Inherited: 0x28)
struct UAnimCurveCompressionCodec_UniformIndexable : UAnimCurveCompressionCodec {
};

// Class Engine.AnimCurveCompressionCodec_UniformlySampled
// Size: 0x28 (Inherited: 0x28)
struct UAnimCurveCompressionCodec_UniformlySampled : UAnimCurveCompressionCodec {
};

// Class Engine.AnimCurveCompressionSettings
// Size: 0x30 (Inherited: 0x28)
struct UAnimCurveCompressionSettings : UObject {
	struct UAnimCurveCompressionCodec* Codec; // 0x28(0x08)
};

// Class Engine.AnimDataModel
// Size: 0xb0 (Inherited: 0x28)
struct UAnimDataModel : UObject {
	int32_t BracketCounter; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct FMulticastInlineDelegate ModifiedEventDynamic; // 0x30(0x10)
	char pad_40[0x18]; // 0x40(0x18)
	struct TArray<struct FBoneAnimationTrack> BoneAnimationTracks; // 0x58(0x10)
	float PlayLength; // 0x68(0x04)
	struct FFrameRate FrameRate; // 0x6c(0x08)
	int32_t NumberOfFrames; // 0x74(0x04)
	int32_t NumberOfKeys; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct FAnimationCurveData CurveData; // 0x80(0x20)
	struct TArray<struct FAnimatedBoneAttribute> AnimatedBoneAttributes; // 0xa0(0x10)

	bool IsValidBoneTrackIndex(int32_t TrackIndex); // Function Engine.AnimDataModel.IsValidBoneTrackIndex // (None) // @ game+0xffffcb34df830041
};

// Class Engine.AnimMetaData
// Size: 0x28 (Inherited: 0x28)
struct UAnimMetaData : UObject {
};

// Class Engine.AnimMontage
// Size: 0x1f8 (Inherited: 0xb0)
struct UAnimMontage : UAnimCompositeBase {
	enum class EMontageBlendMode BlendModeIn; // 0xb0(0x01)
	enum class EMontageBlendMode BlendModeOut; // 0xb1(0x01)
	char pad_B2[0x6]; // 0xb2(0x06)
	struct FAlphaBlend BlendIn; // 0xb8(0x30)
	float BlendInTime; // 0xe8(0x04)
	char pad_EC[0x4]; // 0xec(0x04)
	struct FAlphaBlend BlendOut; // 0xf0(0x30)
	float BlendOutTime; // 0x120(0x04)
	float BlendOutTriggerTime; // 0x124(0x04)
	struct FName SyncGroup; // 0x128(0x08)
	int32_t SyncSlotIndex; // 0x130(0x04)
	char pad_134[0x4]; // 0x134(0x04)
	struct FMarkerSyncData MarkerData; // 0x138(0x20)
	struct TArray<struct FCompositeSection> CompositeSections; // 0x158(0x10)
	struct TArray<struct FSlotAnimationTrack> SlotAnimTracks; // 0x168(0x10)
	struct TArray<struct FBranchingPoint> BranchingPoints; // 0x178(0x10)
	bool bEnableRootMotionTranslation; // 0x188(0x01)
	bool bEnableRootMotionRotation; // 0x189(0x01)
	bool bEnableAutoBlendOut; // 0x18a(0x01)
	char pad_18B[0x5]; // 0x18b(0x05)
	struct UBlendProfile* BlendProfileIn; // 0x190(0x08)
	struct UBlendProfile* BlendProfileOut; // 0x198(0x08)
	enum class ERootMotionRootLock RootMotionRootLock; // 0x1a0(0x01)
	char pad_1A1[0x7]; // 0x1a1(0x07)
	struct TArray<struct FBranchingPointMarker> BranchingPointMarkers; // 0x1a8(0x10)
	struct TArray<int32_t> BranchingPointStateNotifyIndices; // 0x1b8(0x10)
	struct FTimeStretchCurve TimeStretchCurve; // 0x1c8(0x28)
	struct FName TimeStretchCurveName; // 0x1f0(0x08)

	bool IsValidSectionName(struct FName InSectionName); // Function Engine.AnimMontage.IsValidSectionName // (None) // @ game+0xffffcb3ddf830041
};

// Class Engine.AnimNotifyLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAnimNotifyLibrary : UBlueprintFunctionLibrary {

	bool NotifyStateReachedEnd(struct FAnimNotifyEventReference& EventReference); // Function Engine.AnimNotifyLibrary.NotifyStateReachedEnd // (None) // @ game+0xffffcb3edf830041
};

// Class Engine.AnimNotifyMirrorInspectionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAnimNotifyMirrorInspectionLibrary : UBlueprintFunctionLibrary {

	bool IsTriggeredByMirroredAnimation(struct FAnimNotifyEventReference& EventReference); // Function Engine.AnimNotifyMirrorInspectionLibrary.IsTriggeredByMirroredAnimation // (None) // @ game+0xffffcb40df830041
};

// Class Engine.AnimNotifyStateMachineInspectionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAnimNotifyStateMachineInspectionLibrary : UBlueprintFunctionLibrary {

	bool IsTriggeredByStateMachine(struct FAnimNotifyEventReference& EventReference, struct UAnimInstance* AnimInstance, struct FName StateMachineName); // Function Engine.AnimNotifyStateMachineInspectionLibrary.IsTriggeredByStateMachine // (None) // @ game+0xffffcb43df830041
};

// Class Engine.AnimNotifyState_DisableRootMotion
// Size: 0x30 (Inherited: 0x30)
struct UAnimNotifyState_DisableRootMotion : UAnimNotifyState {
};

// Class Engine.AnimNotifyState_TimedParticleEffect
// Size: 0x78 (Inherited: 0x30)
struct UAnimNotifyState_TimedParticleEffect : UAnimNotifyState {
	struct UParticleSystem* PSTemplate; // 0x30(0x08)
	struct FName SocketName; // 0x38(0x08)
	struct FVector LocationOffset; // 0x40(0x18)
	struct FRotator RotationOffset; // 0x58(0x18)
	bool bDestroyAtEnd; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class Engine.AnimNotifyState_Trail
// Size: 0x58 (Inherited: 0x30)
struct UAnimNotifyState_Trail : UAnimNotifyState {
	struct UParticleSystem* PSTemplate; // 0x30(0x08)
	struct FName FirstSocketName; // 0x38(0x08)
	struct FName SecondSocketName; // 0x40(0x08)
	enum class ETrailWidthMode WidthScaleMode; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	struct FName WidthScaleCurve; // 0x4c(0x08)
	char bRecycleSpawnedSystems : 1; // 0x54(0x01)
	char pad_54_1 : 7; // 0x54(0x01)
	char pad_55[0x3]; // 0x55(0x03)

	struct UParticleSystem* OverridePSTemplate(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function Engine.AnimNotifyState_Trail.OverridePSTemplate // (None) // @ game+0xffffcb86df830041
};

// Class Engine.AnimNotify_PauseClothingSimulation
// Size: 0x38 (Inherited: 0x38)
struct UAnimNotify_PauseClothingSimulation : UAnimNotify {
};

// Class Engine.AnimNotify_PlayParticleEffect
// Size: 0xc0 (Inherited: 0x38)
struct UAnimNotify_PlayParticleEffect : UAnimNotify {
	struct UParticleSystem* PSTemplate; // 0x38(0x08)
	struct FVector LocationOffset; // 0x40(0x18)
	struct FRotator RotationOffset; // 0x58(0x18)
	struct FVector Scale; // 0x70(0x18)
	char pad_88[0x28]; // 0x88(0x28)
	char Attached : 1; // 0xb0(0x01)
	char pad_B0_1 : 7; // 0xb0(0x01)
	char pad_B1[0x3]; // 0xb1(0x03)
	struct FName SocketName; // 0xb4(0x08)
	char pad_BC[0x4]; // 0xbc(0x04)
};

// Class Engine.AnimNotify_PlaySound
// Size: 0x58 (Inherited: 0x38)
struct UAnimNotify_PlaySound : UAnimNotify {
	struct USoundBase* Sound; // 0x38(0x08)
	float VolumeMultiplier; // 0x40(0x04)
	float PitchMultiplier; // 0x44(0x04)
	char bFollow : 1; // 0x48(0x01)
	char pad_48_1 : 7; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	struct FName AttachName; // 0x4c(0x08)
	char pad_54[0x4]; // 0x54(0x04)
};

// Class Engine.AnimNotify_ResetClothingSimulation
// Size: 0x38 (Inherited: 0x38)
struct UAnimNotify_ResetClothingSimulation : UAnimNotify {
};

// Class Engine.AnimNotify_ResetDynamics
// Size: 0x38 (Inherited: 0x38)
struct UAnimNotify_ResetDynamics : UAnimNotify {
};

// Class Engine.AnimNotify_ResumeClothingSimulation
// Size: 0x38 (Inherited: 0x38)
struct UAnimNotify_ResumeClothingSimulation : UAnimNotify {
};

// Class Engine.AnimSequence
// Size: 0x1d8 (Inherited: 0xb0)
struct UAnimSequence : UAnimSequenceBase {
	struct UAnimBoneCompressionSettings* BoneCompressionSettings; // 0xb0(0x08)
	struct UAnimCurveCompressionSettings* CurveCompressionSettings; // 0xb8(0x08)
	char pad_C0[0x70]; // 0xc0(0x70)
	enum class EAdditiveAnimationType AdditiveAnimType; // 0x130(0x01)
	enum class EAdditiveBasePoseType RefPoseType; // 0x131(0x01)
	char pad_132[0x2]; // 0x132(0x02)
	int32_t RefFrameIndex; // 0x134(0x04)
	struct UAnimSequence* RefPoseSeq; // 0x138(0x08)
	struct FName RetargetSource; // 0x140(0x08)
	struct TArray<struct FTransform> RetargetSourceAssetReferencePose; // 0x148(0x10)
	enum class EAnimInterpolationType Interpolation; // 0x158(0x01)
	bool bEnableRootMotion; // 0x159(0x01)
	enum class ERootMotionRootLock RootMotionRootLock; // 0x15a(0x01)
	bool bForceRootLock; // 0x15b(0x01)
	bool bUseNormalizedRootMotionScale; // 0x15c(0x01)
	bool bRootMotionSettingsCopiedFromMontage; // 0x15d(0x01)
	char pad_15E[0x2]; // 0x15e(0x02)
	struct TArray<struct FAnimSyncMarker> AuthoredSyncMarkers; // 0x160(0x10)
	char pad_170[0x10]; // 0x170(0x10)
	struct FFrameRate TargetFrameRate; // 0x180(0x08)
	struct TMap<struct FAnimationAttributeIdentifier, struct FAttributeCurve> AttributeCurves; // 0x188(0x50)
};

// Class Engine.AnimSet
// Size: 0xf0 (Inherited: 0x28)
struct UAnimSet : UObject {
	char bAnimRotationOnly : 1; // 0x28(0x01)
	char pad_28_1 : 7; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct TArray<struct FName> TrackBoneNames; // 0x30(0x10)
	struct TArray<struct FAnimSetMeshLinkup> LinkupCache; // 0x40(0x10)
	struct TArray<char> BoneUseAnimTranslation; // 0x50(0x10)
	struct TArray<char> ForceUseMeshTranslation; // 0x60(0x10)
	struct TArray<struct FName> UseTranslationBoneNames; // 0x70(0x10)
	struct TArray<struct FName> ForceMeshTranslationBoneNames; // 0x80(0x10)
	struct FName PreviewSkelMeshName; // 0x90(0x08)
	struct FName BestRatioSkelMeshName; // 0x98(0x08)
	char pad_A0[0x50]; // 0xa0(0x50)
};

// Class Engine.AnimSingleNodeInstance
// Size: 0x360 (Inherited: 0x350)
struct UAnimSingleNodeInstance : UAnimInstance {
	struct UAnimationAsset* CurrentAsset; // 0x348(0x08)
	struct FDelegate PostEvaluateAnimEvent; // 0x350(0x10)

	void StopAnim(); // Function Engine.AnimSingleNodeInstance.StopAnim // (None) // @ game+0xffffcb53df830041
};

// Class Engine.AnimStateMachineTypes
// Size: 0x28 (Inherited: 0x28)
struct UAnimStateMachineTypes : UObject {
};

// Class Engine.AnimStreamable
// Size: 0xe8 (Inherited: 0xb0)
struct UAnimStreamable : UAnimSequenceBase {
	int32_t NumberOfKeys; // 0xb0(0x04)
	enum class EAnimInterpolationType Interpolation; // 0xb4(0x01)
	char pad_B5[0x3]; // 0xb5(0x03)
	struct FName RetargetSource; // 0xb8(0x08)
	char pad_C0[0x10]; // 0xc0(0x10)
	struct UAnimBoneCompressionSettings* BoneCompressionSettings; // 0xd0(0x08)
	struct UAnimCurveCompressionSettings* CurveCompressionSettings; // 0xd8(0x08)
	bool bEnableRootMotion; // 0xe0(0x01)
	enum class ERootMotionRootLock RootMotionRootLock; // 0xe1(0x01)
	bool bForceRootLock; // 0xe2(0x01)
	bool bUseNormalizedRootMotionScale; // 0xe3(0x01)
	char pad_E4[0x4]; // 0xe4(0x04)
};

// Class Engine.AssetMappingTable
// Size: 0x38 (Inherited: 0x28)
struct UAssetMappingTable : UObject {
	struct TArray<struct FAssetMapping> MappedAssets; // 0x28(0x10)
};

// Class Engine.AnimationAttributeIdentifierExtensions
// Size: 0x28 (Inherited: 0x28)
struct UAnimationAttributeIdentifierExtensions : UBlueprintFunctionLibrary {

	bool IsValid(struct FAnimationAttributeIdentifier& Identifier); // Function Engine.AnimationAttributeIdentifierExtensions.IsValid // (None) // @ game+0xffffcb54df830041
};

// Class Engine.Skeleton
// Size: 0x4c8 (Inherited: 0x28)
struct USkeleton : UObject {
	char pad_28[0x10]; // 0x28(0x10)
	struct TArray<struct FBoneNode> BoneTree; // 0x38(0x10)
	struct TArray<struct FTransform> RefLocalPoses; // 0x48(0x10)
	char pad_58[0x118]; // 0x58(0x118)
	struct FGuid VirtualBoneGuid; // 0x170(0x10)
	struct TArray<struct FVirtualBone> VirtualBones; // 0x180(0x10)
	struct TArray<struct TSoftObjectPtr<USkeleton>> CompatibleSkeletons; // 0x190(0x10)
	struct TArray<struct USkeletalMeshSocket*> Sockets; // 0x1a0(0x10)
	char pad_1B0[0x50]; // 0x1b0(0x50)
	struct FSmartNameContainer SmartNames; // 0x200(0x50)
	char pad_250[0x30]; // 0x250(0x30)
	struct TArray<struct UBlendProfile*> BlendProfiles; // 0x280(0x10)
	struct TArray<struct FAnimSlotGroup> SlotGroups; // 0x290(0x10)
	char pad_2A0[0x218]; // 0x2a0(0x218)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x4b8(0x10)

	struct UBlendProfile* GetBlendProfile(struct FName& InProfileName); // Function Engine.Skeleton.GetBlendProfile // (None) // @ game+0xffffcb63df830041
};

// Class Engine.BlendProfile
// Size: 0x50 (Inherited: 0x28)
struct UBlendProfile : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct USkeleton* OwningSkeleton; // 0x30(0x08)
	struct TArray<struct FBlendProfileBoneEntry> ProfileEntries; // 0x38(0x10)
	enum class EBlendProfileMode Mode; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class Engine.BoneMaskFilter
// Size: 0x38 (Inherited: 0x28)
struct UBoneMaskFilter : UObject {
	struct TArray<struct FInputBlendPose> BlendPoses; // 0x28(0x10)
};

// Class Engine.CachedAnimDataLibrary
// Size: 0x28 (Inherited: 0x28)
struct UCachedAnimDataLibrary : UBlueprintFunctionLibrary {

	bool StateMachine_IsStateRelevant(struct UAnimInstance* InAnimInstance, struct FCachedAnimStateData& CachedAnimStateData); // Function Engine.CachedAnimDataLibrary.StateMachine_IsStateRelevant // (None) // @ game+0xffffcb57df830041
};

// Class Engine.AnimationCurveIdentifierExtensions
// Size: 0x28 (Inherited: 0x28)
struct UAnimationCurveIdentifierExtensions : UBlueprintFunctionLibrary {

	bool IsValid(struct FAnimationCurveIdentifier& Identifier); // Function Engine.AnimationCurveIdentifierExtensions.IsValid // (None) // @ game+0xffffcb5adf830041
};

// Class Engine.CurveSourceInterface
// Size: 0x28 (Inherited: 0x28)
struct UCurveSourceInterface : UInterface {

	float GetCurveValue(struct FName CurveName); // Function Engine.CurveSourceInterface.GetCurveValue // (None) // @ game+0xffffcb5ddf830041
};

// Class Engine.MirrorDataTable
// Size: 0x1a0 (Inherited: 0xb0)
struct UMirrorDataTable : UDataTable {
	struct TArray<struct FMirrorFindReplaceExpression> MirrorFindReplaceExpressions; // 0xb0(0x10)
	enum class EAxis MirrorAxis; // 0xc0(0x01)
	char pad_C1[0x7]; // 0xc1(0x07)
	struct USkeleton* Skeleton; // 0xc8(0x08)
	char pad_D0[0xd0]; // 0xd0(0xd0)
};

// Class Engine.NodeMappingContainer
// Size: 0x178 (Inherited: 0x28)
struct UNodeMappingContainer : UObject {
	struct TMap<struct FName, struct FNodeItem> SourceItems; // 0x28(0x50)
	struct TMap<struct FName, struct FNodeItem> TargetItems; // 0x78(0x50)
	struct TMap<struct FName, struct FName> SourceToTarget; // 0xc8(0x50)
	struct TSoftObjectPtr<UObject> SourceAsset; // 0x118(0x30)
	struct TSoftObjectPtr<UObject> TargetAsset; // 0x148(0x30)
};

// Class Engine.NodeMappingProviderInterface
// Size: 0x28 (Inherited: 0x28)
struct UNodeMappingProviderInterface : UInterface {
};

// Class Engine.PoseAsset
// Size: 0x100 (Inherited: 0x80)
struct UPoseAsset : UAnimationAsset {
	struct FPoseDataContainer PoseContainer; // 0x80(0x60)
	bool bAdditivePose; // 0xe0(0x01)
	char pad_E1[0x3]; // 0xe1(0x03)
	int32_t BasePoseIndex; // 0xe4(0x04)
	struct FName RetargetSource; // 0xe8(0x08)
	struct TArray<struct FTransform> RetargetSourceAssetReferencePose; // 0xf0(0x10)
};

// Class Engine.PreviewCollectionInterface
// Size: 0x28 (Inherited: 0x28)
struct UPreviewCollectionInterface : UInterface {
};

// Class Engine.PreviewMeshCollection
// Size: 0x50 (Inherited: 0x30)
struct UPreviewMeshCollection : UDataAsset {
	char pad_30[0x8]; // 0x30(0x08)
	struct USkeleton* Skeleton; // 0x38(0x08)
	struct TArray<struct FPreviewMeshCollectionEntry> SkeletalMeshes; // 0x40(0x10)
};

// Class Engine.Rig
// Size: 0x50 (Inherited: 0x28)
struct URig : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TArray<struct FTransformBase> TransformBases; // 0x30(0x10)
	struct TArray<struct FNode> Nodes; // 0x40(0x10)
};

// Class Engine.SkeletalMeshActor
// Size: 0x310 (Inherited: 0x290)
struct ASkeletalMeshActor : AActor {
	char bShouldDoAnimNotifies : 1; // 0x290(0x01)
	char bWakeOnLevelStart : 1; // 0x290(0x01)
	char pad_290_2 : 6; // 0x290(0x01)
	char pad_291[0x7]; // 0x291(0x07)
	struct USkeletalMeshComponent* SkeletalMeshComponent; // 0x298(0x08)
	struct USkeletalMesh* ReplicatedMesh; // 0x2a0(0x08)
	struct UPhysicsAsset* ReplicatedPhysAsset; // 0x2a8(0x08)
	struct UMaterialInterface* ReplicatedMaterial0; // 0x2b0(0x08)
	struct UMaterialInterface* ReplicatedMaterial1; // 0x2b8(0x08)
	char pad_2C0[0x50]; // 0x2c0(0x50)

	void OnRep_ReplicatedPhysAsset(); // Function Engine.SkeletalMeshActor.OnRep_ReplicatedPhysAsset // (None) // @ game+0xffffcb61df830041
};

// Class Engine.AnimBlueprint
// Size: 0xd0 (Inherited: 0xa8)
struct UAnimBlueprint : UBlueprint {
	char pad_A8[0x8]; // 0xa8(0x08)
	struct USkeleton* TargetSkeleton; // 0xb0(0x08)
	struct TArray<struct FAnimGroupInfo> Groups; // 0xb8(0x10)
	bool bIsTemplate; // 0xc8(0x01)
	bool bUseMultiThreadedAnimationUpdate; // 0xc9(0x01)
	bool bWarnAboutBlueprintUsage; // 0xca(0x01)
	char pad_CB[0x5]; // 0xcb(0x05)
};

// Class Engine.AsyncActionLoadPrimaryAssetBase
// Size: 0x78 (Inherited: 0x30)
struct UAsyncActionLoadPrimaryAssetBase : UBlueprintAsyncActionBase {
	char pad_30[0x48]; // 0x30(0x48)
};

// Class Engine.AsyncActionLoadPrimaryAsset
// Size: 0x88 (Inherited: 0x78)
struct UAsyncActionLoadPrimaryAsset : UAsyncActionLoadPrimaryAssetBase {
	struct FMulticastInlineDelegate Completed; // 0x78(0x10)

	struct UAsyncActionLoadPrimaryAsset* AsyncLoadPrimaryAsset(struct UObject* WorldContextObject, struct FPrimaryAssetId PrimaryAsset, struct TArray<struct FName>& LoadBundles); // Function Engine.AsyncActionLoadPrimaryAsset.AsyncLoadPrimaryAsset // (None) // @ game+0xffffcb64df830041
};

// Class Engine.AsyncActionLoadPrimaryAssetClass
// Size: 0x88 (Inherited: 0x78)
struct UAsyncActionLoadPrimaryAssetClass : UAsyncActionLoadPrimaryAssetBase {
	struct FMulticastInlineDelegate Completed; // 0x78(0x10)

	struct UAsyncActionLoadPrimaryAssetClass* AsyncLoadPrimaryAssetClass(struct UObject* WorldContextObject, struct FPrimaryAssetId PrimaryAsset, struct TArray<struct FName>& LoadBundles); // Function Engine.AsyncActionLoadPrimaryAssetClass.AsyncLoadPrimaryAssetClass // (None) // @ game+0xffffcba7df830041
};

// Class Engine.AsyncActionLoadPrimaryAssetList
// Size: 0x88 (Inherited: 0x78)
struct UAsyncActionLoadPrimaryAssetList : UAsyncActionLoadPrimaryAssetBase {
	struct FMulticastInlineDelegate Completed; // 0x78(0x10)

	struct UAsyncActionLoadPrimaryAssetList* AsyncLoadPrimaryAssetList(struct UObject* WorldContextObject, struct TArray<struct FPrimaryAssetId>& PrimaryAssetList, struct TArray<struct FName>& LoadBundles); // Function Engine.AsyncActionLoadPrimaryAssetList.AsyncLoadPrimaryAssetList // (None) // @ game+0xffffcb66df830041
};

// Class Engine.AsyncActionLoadPrimaryAssetClassList
// Size: 0x88 (Inherited: 0x78)
struct UAsyncActionLoadPrimaryAssetClassList : UAsyncActionLoadPrimaryAssetBase {
	struct FMulticastInlineDelegate Completed; // 0x78(0x10)

	struct UAsyncActionLoadPrimaryAssetClassList* AsyncLoadPrimaryAssetClassList(struct UObject* WorldContextObject, struct TArray<struct FPrimaryAssetId>& PrimaryAssetList, struct TArray<struct FName>& LoadBundles); // Function Engine.AsyncActionLoadPrimaryAssetClassList.AsyncLoadPrimaryAssetClassList // (None) // @ game+0xffffcb67df830041
};

// Class Engine.AsyncActionChangePrimaryAssetBundles
// Size: 0x88 (Inherited: 0x78)
struct UAsyncActionChangePrimaryAssetBundles : UAsyncActionLoadPrimaryAssetBase {
	struct FMulticastInlineDelegate Completed; // 0x78(0x10)

	struct UAsyncActionChangePrimaryAssetBundles* AsyncChangeBundleStateForPrimaryAssetList(struct UObject* WorldContextObject, struct TArray<struct FPrimaryAssetId>& PrimaryAssetList, struct TArray<struct FName>& AddBundles, struct TArray<struct FName>& RemoveBundles); // Function Engine.AsyncActionChangePrimaryAssetBundles.AsyncChangeBundleStateForPrimaryAssetList // (None) // @ game+0xffffcb69df830041
};

// Class Engine.AtmosphericFog
// Size: 0x298 (Inherited: 0x290)
struct AAtmosphericFog : AInfo {
	struct UAtmosphericFogComponent* AtmosphericFogComponent; // 0x290(0x08)
};

// Class Engine.SkyAtmosphereComponent
// Size: 0x3a0 (Inherited: 0x2a0)
struct USkyAtmosphereComponent : USceneComponent {
	enum class ESkyAtmosphereTransformMode TransformMode; // 0x2a0(0x01)
	char pad_2A1[0x3]; // 0x2a1(0x03)
	float BottomRadius; // 0x2a4(0x04)
	struct FColor GroundAlbedo; // 0x2a8(0x04)
	float AtmosphereHeight; // 0x2ac(0x04)
	float MultiScatteringFactor; // 0x2b0(0x04)
	float TraceSampleCountScale; // 0x2b4(0x04)
	float RayleighScatteringScale; // 0x2b8(0x04)
	struct FLinearColor RayleighScattering; // 0x2bc(0x10)
	float RayleighExponentialDistribution; // 0x2cc(0x04)
	float MieScatteringScale; // 0x2d0(0x04)
	struct FLinearColor MieScattering; // 0x2d4(0x10)
	float MieAbsorptionScale; // 0x2e4(0x04)
	struct FLinearColor MieAbsorption; // 0x2e8(0x10)
	float MieAnisotropy; // 0x2f8(0x04)
	float MieExponentialDistribution; // 0x2fc(0x04)
	float OtherAbsorptionScale; // 0x300(0x04)
	struct FLinearColor OtherAbsorption; // 0x304(0x10)
	struct FTentDistribution OtherTentDistribution; // 0x314(0x0c)
	struct FLinearColor SkyLuminanceFactor; // 0x320(0x10)
	float AerialPespectiveViewDistanceScale; // 0x330(0x04)
	float HeightFogContribution; // 0x334(0x04)
	float TransmittanceMinLightElevationAngle; // 0x338(0x04)
	float AerialPerspectiveStartDepth; // 0x33c(0x04)
	char pad_340[0x40]; // 0x340(0x40)
	struct FGuid bStaticLightingBuiltGUID; // 0x380(0x10)
	char pad_390[0x10]; // 0x390(0x10)

	void SetSkyLuminanceFactor(struct FLinearColor NewValue); // Function Engine.SkyAtmosphereComponent.SetSkyLuminanceFactor // (None) // @ game+0xffffcb7bdf830041
};

// Class Engine.AtmosphericFogComponent
// Size: 0x3a0 (Inherited: 0x3a0)
struct UAtmosphericFogComponent : USkyAtmosphereComponent {
	enum class ESkyAtmosphereTransformMode TransformMode; // 0x2a0(0x01)
	float BottomRadius; // 0x2a4(0x04)
	struct FColor GroundAlbedo; // 0x2a8(0x04)
	float AtmosphereHeight; // 0x2ac(0x04)
	float MultiScatteringFactor; // 0x2b0(0x04)
	float TraceSampleCountScale; // 0x2b4(0x04)
	float RayleighScatteringScale; // 0x2b8(0x04)
	struct FLinearColor RayleighScattering; // 0x2bc(0x10)
	float RayleighExponentialDistribution; // 0x2cc(0x04)
	float MieScatteringScale; // 0x2d0(0x04)
	struct FLinearColor MieScattering; // 0x2d4(0x10)
	float MieAbsorptionScale; // 0x2e4(0x04)
	struct FLinearColor MieAbsorption; // 0x2e8(0x10)
	float MieAnisotropy; // 0x2f8(0x04)
	float MieExponentialDistribution; // 0x2fc(0x04)
	float OtherAbsorptionScale; // 0x300(0x04)
	struct FLinearColor OtherAbsorption; // 0x304(0x10)
	struct FTentDistribution OtherTentDistribution; // 0x314(0x0c)
	struct FLinearColor SkyLuminanceFactor; // 0x320(0x10)
	float AerialPespectiveViewDistanceScale; // 0x330(0x04)
	float HeightFogContribution; // 0x334(0x04)
	float TransmittanceMinLightElevationAngle; // 0x338(0x04)
	float AerialPerspectiveStartDepth; // 0x33c(0x04)
	struct FGuid bStaticLightingBuiltGUID; // 0x380(0x10)

	void SetSunMultiplier(float NewSunMultiplier); // Function Engine.AtmosphericFogComponent.SetSunMultiplier // (None) // @ game+0xffffcb88df830041
};

// Class Engine.AudioBus
// Size: 0x38 (Inherited: 0x28)
struct UAudioBus : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	enum class EAudioBusChannels AudioBusChannels; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// Class Engine.AudioSettings
// Size: 0x1e0 (Inherited: 0x38)
struct UAudioSettings : UDeveloperSettings {
	struct FSoftObjectPath DefaultSoundClassName; // 0x38(0x20)
	struct FSoftObjectPath DefaultMediaSoundClassName; // 0x58(0x20)
	struct FSoftObjectPath DefaultSoundConcurrencyName; // 0x78(0x20)
	struct FSoftObjectPath DefaultBaseSoundMix; // 0x98(0x20)
	struct FSoftObjectPath VoiPSoundClass; // 0xb8(0x20)
	struct FSoftObjectPath MasterSubmix; // 0xd8(0x20)
	struct FSoftObjectPath BaseDefaultSubmix; // 0xf8(0x20)
	struct FSoftObjectPath ReverbSubmix; // 0x118(0x20)
	struct FSoftObjectPath EQSubmix; // 0x138(0x20)
	enum class EVoiceSampleRate VoiPSampleRate; // 0x158(0x04)
	enum class EDefaultAudioCompressionType DefaultAudioCompressionType; // 0x15c(0x01)
	char pad_15D[0x3]; // 0x15d(0x03)
	float DefaultReverbSendLevel; // 0x160(0x04)
	int32_t MaximumConcurrentStreams; // 0x164(0x04)
	float GlobalMinPitchScale; // 0x168(0x04)
	float GlobalMaxPitchScale; // 0x16c(0x04)
	struct TArray<struct FAudioQualitySettings> QualityLevels; // 0x170(0x10)
	char bAllowPlayWhenSilent : 1; // 0x180(0x01)
	char bDisableMasterEQ : 1; // 0x180(0x01)
	char bAllowCenterChannel3DPanning : 1; // 0x180(0x01)
	char pad_180_3 : 5; // 0x180(0x01)
	char pad_181[0x3]; // 0x181(0x03)
	uint32_t NumStoppingSources; // 0x184(0x04)
	enum class EPanningMethod PanningMethod; // 0x188(0x01)
	enum class EMonoChannelUpmixMethod MonoChannelUpmixMethod; // 0x189(0x01)
	char pad_18A[0x6]; // 0x18a(0x06)
	struct FString DialogueFilenameFormat; // 0x190(0x10)
	struct TArray<struct FSoundDebugEntry> DebugSounds; // 0x1a0(0x10)
	struct TArray<struct FDefaultAudioBusSettings> DefaultAudioBuses; // 0x1b0(0x10)
	struct USoundClass* DefaultSoundClass; // 0x1c0(0x08)
	struct USoundClass* DefaultMediaSoundClass; // 0x1c8(0x08)
	struct USoundConcurrency* DefaultSoundConcurrency; // 0x1d0(0x08)
	char pad_1D8[0x8]; // 0x1d8(0x08)
};

// Class Engine.AudioVolume
// Size: 0x338 (Inherited: 0x2c8)
struct AAudioVolume : AVolume {
	float Priority; // 0x2c8(0x04)
	char bEnabled : 1; // 0x2cc(0x01)
	char pad_2CC_1 : 7; // 0x2cc(0x01)
	char pad_2CD[0x3]; // 0x2cd(0x03)
	struct FReverbSettings Settings; // 0x2d0(0x20)
	struct FInteriorSettings AmbientZoneSettings; // 0x2f0(0x24)
	char pad_314[0x4]; // 0x314(0x04)
	struct TArray<struct FAudioVolumeSubmixSendSettings> SubmixSendSettings; // 0x318(0x10)
	struct TArray<struct FAudioVolumeSubmixOverrideSettings> SubmixOverrideSettings; // 0x328(0x10)

	void SetSubmixSendSettings(struct TArray<struct FAudioVolumeSubmixSendSettings>& NewSubmixSendSettings); // Function Engine.AudioVolume.SetSubmixSendSettings // (None) // @ game+0xffffcb8fdf830041
};

// Class Engine.ActorSoundParameterInterface
// Size: 0x28 (Inherited: 0x28)
struct UActorSoundParameterInterface : UInterface {

	void GetActorSoundParams(struct TArray<struct FAudioParameter>& Params); // Function Engine.ActorSoundParameterInterface.GetActorSoundParams // (None) // @ game+0xffffcb90df830041
};

// Class Engine.AudioWidgetSubsystem
// Size: 0x30 (Inherited: 0x30)
struct UAudioWidgetSubsystem : UEngineSubsystem {
};

// Class Engine.SoundParameterControllerInterface
// Size: 0x28 (Inherited: 0x28)
struct USoundParameterControllerInterface : UAudioParameterControllerInterface {
};

// Class Engine.AudioParameterConversionStatics
// Size: 0x28 (Inherited: 0x28)
struct UAudioParameterConversionStatics : UBlueprintFunctionLibrary {

	struct FAudioParameter StringToAudioParameter(struct FName Name, struct FString String); // Function Engine.AudioParameterConversionStatics.StringToAudioParameter // (None) // @ game+0xffffcb9adf830041
};

// Class Engine.BlockingVolume
// Size: 0x2c8 (Inherited: 0x2c8)
struct ABlockingVolume : AVolume {
	enum class EBrushType BrushType; // 0x290(0x01)
	struct FColor BrushColor; // 0x294(0x04)
	int32_t PolyFlags; // 0x298(0x04)
	char bColored : 1; // 0x29c(0x01)
	char bSolidWhenSelected : 1; // 0x29c(0x01)
	char bPlaceableFromClassBrowser : 1; // 0x29c(0x01)
	char bNotForClientOrServer : 1; // 0x29c(0x01)
	struct UModel* Brush; // 0x2a0(0x08)
	struct UBrushComponent* BrushComponent; // 0x2a8(0x08)
	char bInManipulation : 1; // 0x2b0(0x01)
	struct TArray<struct FGeomSelection> SavedSelections; // 0x2b8(0x10)
};

// Class Engine.BlueprintMapLibrary
// Size: 0x28 (Inherited: 0x28)
struct UBlueprintMapLibrary : UBlueprintFunctionLibrary {

	void SetMapPropertyByName(struct UObject* Object, struct FName PropertyName, struct TMap<int32_t, int32_t>& Value); // Function Engine.BlueprintMapLibrary.SetMapPropertyByName // (None) // @ game+0xffffcba5df830041
};

// Class Engine.BlueprintSetLibrary
// Size: 0x28 (Inherited: 0x28)
struct UBlueprintSetLibrary : UBlueprintFunctionLibrary {

	void SetSetPropertyByName(struct UObject* Object, struct FName PropertyName, struct TSet<int32_t>& Value); // Function Engine.BlueprintSetLibrary.SetSetPropertyByName // (None) // @ game+0xffffcbb3df830041
};

// Class Engine.BookMark
// Size: 0x68 (Inherited: 0x28)
struct UBookMark : UBookmarkBase {
	struct FVector Location; // 0x28(0x18)
	struct FRotator Rotation; // 0x40(0x18)
	struct TArray<struct FString> HiddenLevels; // 0x58(0x10)
};

// Class Engine.BrushBuilder
// Size: 0x80 (Inherited: 0x28)
struct UBrushBuilder : UObject {
	struct FString BitmapFilename; // 0x28(0x10)
	struct FString ToolTip; // 0x38(0x10)
	char NotifyBadParams : 1; // 0x48(0x01)
	char pad_48_1 : 7; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct TArray<struct FVector> Vertices; // 0x50(0x10)
	struct TArray<struct FBuilderPoly> Polys; // 0x60(0x10)
	struct FName Layer; // 0x70(0x08)
	char MergeCoplanars : 1; // 0x78(0x01)
	char pad_78_1 : 7; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
};

// Class Engine.BrushShape
// Size: 0x2c8 (Inherited: 0x2c8)
struct ABrushShape : ABrush {
	enum class EBrushType BrushType; // 0x290(0x01)
	struct FColor BrushColor; // 0x294(0x04)
	int32_t PolyFlags; // 0x298(0x04)
	char bColored : 1; // 0x29c(0x01)
	char bSolidWhenSelected : 1; // 0x29c(0x01)
	char bPlaceableFromClassBrowser : 1; // 0x29c(0x01)
	char bNotForClientOrServer : 1; // 0x29c(0x01)
	struct UModel* Brush; // 0x2a0(0x08)
	struct UBrushComponent* BrushComponent; // 0x2a8(0x08)
	char bInManipulation : 1; // 0x2b0(0x01)
	struct TArray<struct FGeomSelection> SavedSelections; // 0x2b8(0x10)
};

// Class Engine.CameraBlockingVolume
// Size: 0x2c8 (Inherited: 0x2c8)
struct ACameraBlockingVolume : AVolume {
	enum class EBrushType BrushType; // 0x290(0x01)
	struct FColor BrushColor; // 0x294(0x04)
	int32_t PolyFlags; // 0x298(0x04)
	char bColored : 1; // 0x29c(0x01)
	char bSolidWhenSelected : 1; // 0x29c(0x01)
	char bPlaceableFromClassBrowser : 1; // 0x29c(0x01)
	char bNotForClientOrServer : 1; // 0x29c(0x01)
	struct UModel* Brush; // 0x2a0(0x08)
	struct UBrushComponent* BrushComponent; // 0x2a8(0x08)
	char bInManipulation : 1; // 0x2b0(0x01)
	struct TArray<struct FGeomSelection> SavedSelections; // 0x2b8(0x10)
};

// Class Engine.CameraLensEffectInterface
// Size: 0x28 (Inherited: 0x28)
struct UCameraLensEffectInterface : UInterface {

	struct UFXSystemComponent* GetPrimaryParticleComponent(); // Function Engine.CameraLensEffectInterface.GetPrimaryParticleComponent // (None) // @ game+0xffffcbb5df830041
};

// Class Engine.CameraLensEffectInterfaceClassSupportLibrary
// Size: 0x28 (Inherited: 0x28)
struct UCameraLensEffectInterfaceClassSupportLibrary : UBlueprintFunctionLibrary {

	void SetInterfaceClass(struct AActor* Class, struct FCameraLensInterfaceClassSupport& Var, enum class EInterfaceValidResult& Result); // Function Engine.CameraLensEffectInterfaceClassSupportLibrary.SetInterfaceClass // (None) // @ game+0xffffcbb9df830041
};

// Class Engine.CameraModifier_CameraShake
// Size: 0xb0 (Inherited: 0x48)
struct UCameraModifier_CameraShake : UCameraModifier {
	struct TArray<struct FActiveCameraShakeInfo> ActiveShakes; // 0x48(0x10)
	struct TMap<struct UCameraShakeBase*, struct FPooledCameraShakes> ExpiredPooledShakesMap; // 0x58(0x50)
	float SplitScreenShakeScale; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
};

// Class Engine.CameraShakeSourceActor
// Size: 0x298 (Inherited: 0x290)
struct ACameraShakeSourceActor : AActor {
	struct UCameraShakeSourceComponent* CameraShakeSourceComponent; // 0x290(0x08)
};

// Class Engine.CameraShakeSourceComponent
// Size: 0x2c0 (Inherited: 0x2a0)
struct UCameraShakeSourceComponent : USceneComponent {
	enum class ECameraShakeAttenuation Attenuation; // 0x2a0(0x01)
	char pad_2A1[0x3]; // 0x2a1(0x03)
	float InnerAttenuationRadius; // 0x2a4(0x04)
	float OuterAttenuationRadius; // 0x2a8(0x04)
	char pad_2AC[0x4]; // 0x2ac(0x04)
	struct UCameraShakeBase* CameraShake; // 0x2b0(0x08)
	bool bAutoStart; // 0x2b8(0x01)
	char pad_2B9[0x7]; // 0x2b9(0x07)

	void StopAllCameraShakesOfType(struct UCameraShakeBase* InCameraShake, bool bImmediately); // Function Engine.CameraShakeSourceComponent.StopAllCameraShakesOfType // (None) // @ game+0xffffcbbedf830041
};

// Class Engine.CanvasRenderTarget2D
// Size: 0x240 (Inherited: 0x220)
struct UCanvasRenderTarget2D : UTextureRenderTarget2D {
	struct FMulticastInlineDelegate OnCanvasRenderTargetUpdate; // 0x220(0x10)
	struct TWeakObjectPtr<struct UWorld> World; // 0x230(0x08)
	bool bShouldClearRenderTargetOnReceiveUpdate; // 0x238(0x01)
	char pad_239[0x7]; // 0x239(0x07)

	void UpdateResource(); // Function Engine.CanvasRenderTarget2D.UpdateResource // (None) // @ game+0xffffcbc2df830041
};

// Class Engine.CheatManager
// Size: 0x88 (Inherited: 0x28)
struct UCheatManager : UObject {
	struct ADebugCameraController* DebugCameraControllerRef; // 0x28(0x08)
	struct ADebugCameraController* DebugCameraControllerClass; // 0x30(0x08)
	char pad_38[0x40]; // 0x38(0x40)
	struct TArray<struct UCheatManagerExtension*> CheatManagerExtensions; // 0x78(0x10)

	void Walk(); // Function Engine.CheatManager.Walk // (None) // @ game+0xffffcbfedf830041
};

// Class Engine.CheatManagerExtension
// Size: 0x28 (Inherited: 0x28)
struct UCheatManagerExtension : UObject {

	void RemovedFromCheatManager(); // Function Engine.CheatManagerExtension.RemovedFromCheatManager // (None) // @ game+0xffffcbc5df830041
};

// Class Engine.CollisionProfile
// Size: 0x170 (Inherited: 0x38)
struct UCollisionProfile : UDeveloperSettings {
	struct TArray<struct FCollisionResponseTemplate> Profiles; // 0x38(0x10)
	struct TArray<struct FCustomChannelSetup> DefaultChannelResponses; // 0x48(0x10)
	struct TArray<struct FCustomProfile> EditProfiles; // 0x58(0x10)
	struct TArray<struct FRedirector> ProfileRedirects; // 0x68(0x10)
	struct TArray<struct FRedirector> CollisionChannelRedirects; // 0x78(0x10)
	char pad_88[0xe8]; // 0x88(0xe8)
};

// Class Engine.PluginCommandlet
// Size: 0xa0 (Inherited: 0x80)
struct UPluginCommandlet : UCommandlet {
	struct FString HelpDescription; // 0x28(0x10)
	struct FString HelpUsage; // 0x38(0x10)
	struct FString HelpWebLink; // 0x48(0x10)
	struct TArray<struct FString> HelpParamNames; // 0x58(0x10)
	struct TArray<struct FString> HelpParamDescriptions; // 0x68(0x10)
	char IsServer : 1; // 0x78(0x01)
	char IsClient : 1; // 0x78(0x01)
	char IsEditor : 1; // 0x78(0x01)
	char LogToConsole : 1; // 0x78(0x01)
	char ShowErrorCount : 1; // 0x78(0x01)
	char ShowProgress : 1; // 0x78(0x01)
};

// Class Engine.SmokeTestCommandlet
// Size: 0x80 (Inherited: 0x80)
struct USmokeTestCommandlet : UCommandlet {
	struct FString HelpDescription; // 0x28(0x10)
	struct FString HelpUsage; // 0x38(0x10)
	struct FString HelpWebLink; // 0x48(0x10)
	struct TArray<struct FString> HelpParamNames; // 0x58(0x10)
	struct TArray<struct FString> HelpParamDescriptions; // 0x68(0x10)
	char IsServer : 1; // 0x78(0x01)
	char IsClient : 1; // 0x78(0x01)
	char IsEditor : 1; // 0x78(0x01)
	char LogToConsole : 1; // 0x78(0x01)
	char ShowErrorCount : 1; // 0x78(0x01)
	char ShowProgress : 1; // 0x78(0x01)
};

// Class Engine.ComponentDelegateBinding
// Size: 0x38 (Inherited: 0x28)
struct UComponentDelegateBinding : UDynamicBlueprintBinding {
	struct TArray<struct FBlueprintComponentDelegateBinding> ComponentDelegateBindings; // 0x28(0x10)
};

// Class Engine.ActorComponentInstanceDataTransientOuter
// Size: 0x28 (Inherited: 0x28)
struct UActorComponentInstanceDataTransientOuter : UObject {
};

// Class Engine.ApplicationLifecycleComponent
// Size: 0x130 (Inherited: 0xa0)
struct UApplicationLifecycleComponent : UActorComponent {
	struct FMulticastInlineDelegate ApplicationWillDeactivateDelegate; // 0xa0(0x10)
	struct FMulticastInlineDelegate ApplicationHasReactivatedDelegate; // 0xb0(0x10)
	struct FMulticastInlineDelegate ApplicationWillEnterBackgroundDelegate; // 0xc0(0x10)
	struct FMulticastInlineDelegate ApplicationHasEnteredForegroundDelegate; // 0xd0(0x10)
	struct FMulticastInlineDelegate ApplicationWillTerminateDelegate; // 0xe0(0x10)
	struct FMulticastInlineDelegate ApplicationShouldUnloadResourcesDelegate; // 0xf0(0x10)
	struct FMulticastInlineDelegate ApplicationReceivedStartupArgumentsDelegate; // 0x100(0x10)
	struct FMulticastInlineDelegate OnTemperatureChangeDelegate; // 0x110(0x10)
	struct FMulticastInlineDelegate OnLowPowerModeDelegate; // 0x120(0x10)
};

// Class Engine.ArrowComponent
// Size: 0x550 (Inherited: 0x540)
struct UArrowComponent : UPrimitiveComponent {
	struct FColor ArrowColor; // 0x538(0x04)
	float ArrowSize; // 0x53c(0x04)
	float ArrowLength; // 0x540(0x04)
	float ScreenSize; // 0x544(0x04)
	char bIsScreenSizeScaled : 1; // 0x548(0x01)
	char bTreatAsASprite : 1; // 0x548(0x01)

	void SetArrowColor(struct FLinearColor NewColor); // Function Engine.ArrowComponent.SetArrowColor // (None) // @ game+0xffffcbffdf830041
};

// Class Engine.InitialActiveSoundParams
// Size: 0x38 (Inherited: 0x28)
struct UInitialActiveSoundParams : UObject {
	struct TArray<struct FAudioParameter> AudioParams; // 0x28(0x10)
};

// Class Engine.BillboardComponent
// Size: 0x560 (Inherited: 0x540)
struct UBillboardComponent : UPrimitiveComponent {
	struct UTexture2D* Sprite; // 0x538(0x08)
	char bIsScreenSizeScaled : 1; // 0x540(0x01)
	float ScreenSize; // 0x544(0x04)
	float U; // 0x548(0x04)
	float UL; // 0x54c(0x04)
	float V; // 0x550(0x04)
	float VL; // 0x554(0x04)
	float OpacityMaskRefVal; // 0x558(0x04)

	void SetUV(int32_t NewU, int32_t NewUL, int32_t NewV, int32_t NewVL); // Function Engine.BillboardComponent.SetUV // (None) // @ game+0xffffcc03df830041
};

// Class Engine.BoundsCopyComponent
// Size: 0x150 (Inherited: 0xa0)
struct UBoundsCopyComponent : UActorComponent {
	struct TSoftObjectPtr<AActor> BoundsSourceActor; // 0xa0(0x30)
	bool bUseCollidingComponentsForSourceBounds; // 0xd0(0x01)
	bool bKeepOwnBoundsScale; // 0xd1(0x01)
	bool bUseCollidingComponentsForOwnBounds; // 0xd2(0x01)
	char pad_D3[0xd]; // 0xd3(0x0d)
	struct FTransform PostTransform; // 0xe0(0x60)
	bool bCopyXBounds; // 0x140(0x01)
	bool bCopyYBounds; // 0x141(0x01)
	bool bCopyZBounds; // 0x142(0x01)
	char pad_143[0xd]; // 0x143(0x0d)
};

// Class Engine.BrushComponent
// Size: 0x550 (Inherited: 0x540)
struct UBrushComponent : UPrimitiveComponent {
	struct UModel* Brush; // 0x538(0x08)
	struct UBodySetup* BrushBodySetup; // 0x540(0x08)
};

// Class Engine.CapsuleComponent
// Size: 0x560 (Inherited: 0x560)
struct UCapsuleComponent : UShapeComponent {
	float CapsuleHalfHeight; // 0x558(0x04)
	float CapsuleRadius; // 0x55c(0x04)

	void SetCapsuleSize(float InRadius, float InHalfHeight, bool bUpdateOverlaps); // Function Engine.CapsuleComponent.SetCapsuleSize // (None) // @ game+0xffffcc11df830041
};

// Class Engine.ChildActorComponent
// Size: 0x2e0 (Inherited: 0x2a0)
struct UChildActorComponent : USceneComponent {
	struct AActor* ChildActorClass; // 0x2a0(0x08)
	struct AActor* ChildActor; // 0x2a8(0x08)
	struct AActor* ChildActorTemplate; // 0x2b0(0x08)
	char pad_2B8[0x28]; // 0x2b8(0x28)

	void SetChildActorClass(struct AActor* InClass); // Function Engine.ChildActorComponent.SetChildActorClass // (None) // @ game+0xffffcc13df830041
};

// Class Engine.DecalComponent
// Size: 0x2f0 (Inherited: 0x2a0)
struct UDecalComponent : USceneComponent {
	struct UMaterialInterface* DecalMaterial; // 0x2a0(0x08)
	int32_t SortOrder; // 0x2a8(0x04)
	float FadeScreenSize; // 0x2ac(0x04)
	float FadeStartDelay; // 0x2b0(0x04)
	float FadeDuration; // 0x2b4(0x04)
	float FadeInDuration; // 0x2b8(0x04)
	float FadeInStartDelay; // 0x2bc(0x04)
	char bDestroyOwnerAfterFade : 1; // 0x2c0(0x01)
	char pad_2C0_1 : 7; // 0x2c0(0x01)
	char pad_2C1[0x7]; // 0x2c1(0x07)
	struct FVector DecalSize; // 0x2c8(0x18)
	char pad_2E0[0x10]; // 0x2e0(0x10)

	void SetSortOrder(int32_t Value); // Function Engine.DecalComponent.SetSortOrder // (None) // @ game+0xffffcc1edf830041
};

// Class Engine.LightComponent
// Size: 0x3e0 (Inherited: 0x2e0)
struct ULightComponent : ULightComponentBase {
	float Temperature; // 0x2d8(0x04)
	float MaxDrawDistance; // 0x2dc(0x04)
	float MaxDistanceFadeRange; // 0x2e0(0x04)
	char bUseTemperature : 1; // 0x2e4(0x01)
	int32_t ShadowMapChannel; // 0x2e8(0x04)
	float MinRoughness; // 0x2f0(0x04)
	float SpecularScale; // 0x2f4(0x04)
	float ShadowResolutionScale; // 0x2f8(0x04)
	float ShadowBias; // 0x2fc(0x04)
	float ShadowSlopeBias; // 0x300(0x04)
	float ShadowSharpen; // 0x304(0x04)
	float ContactShadowLength; // 0x308(0x04)
	char ContactShadowLengthInWS : 1; // 0x30c(0x01)
	char InverseSquaredFalloff : 1; // 0x30c(0x01)
	char CastTranslucentShadows : 1; // 0x30c(0x01)
	char bCastShadowsFromCinematicObjectsOnly : 1; // 0x30c(0x01)
	char bAffectDynamicIndirectLighting : 1; // 0x30c(0x01)
	char bForceCachedShadowsForMovablePrimitives : 1; // 0x30c(0x01)
	char pad_30C_7 : 1; // 0x30c(0x01)
	char pad_30D[0x3]; // 0x30d(0x03)
	struct FLightingChannels LightingChannels; // 0x310(0x01)
	char pad_311[0x7]; // 0x311(0x07)
	struct UMaterialInterface* LightFunctionMaterial; // 0x318(0x08)
	struct FVector LightFunctionScale; // 0x320(0x18)
	struct UTextureLightProfile* IESTexture; // 0x338(0x08)
	char bUseIESBrightness : 1; // 0x340(0x01)
	char pad_340_1 : 7; // 0x340(0x01)
	char pad_341[0x3]; // 0x341(0x03)
	float IESBrightnessScale; // 0x344(0x04)
	float LightFunctionFadeDistance; // 0x348(0x04)
	float DisabledBrightness; // 0x34c(0x04)
	char bEnableLightShaftBloom : 1; // 0x350(0x01)
	char pad_350_1 : 7; // 0x350(0x01)
	char pad_351[0x3]; // 0x351(0x03)
	float BloomScale; // 0x354(0x04)
	float BloomThreshold; // 0x358(0x04)
	float BloomMaxBrightness; // 0x35c(0x04)
	struct FColor BloomTint; // 0x360(0x04)
	bool bUseRayTracedDistanceFieldShadows; // 0x364(0x01)
	char pad_365[0x3]; // 0x365(0x03)
	float RayStartOffsetDepthScale; // 0x368(0x04)
	char pad_36C[0x74]; // 0x36c(0x74)

	void SetVolumetricScatteringIntensity(float NewIntensity); // Function Engine.LightComponent.SetVolumetricScatteringIntensity // (None) // @ game+0xffffcc39df830041
};

// Class Engine.DirectionalLightComponent
// Size: 0x4b0 (Inherited: 0x3e0)
struct UDirectionalLightComponent : ULightComponent {
	float ShadowCascadeBiasDistribution; // 0x3e0(0x04)
	char bEnableLightShaftOcclusion : 1; // 0x3e4(0x01)
	char pad_3E4_1 : 7; // 0x3e4(0x01)
	char pad_3E5[0x3]; // 0x3e5(0x03)
	float OcclusionMaskDarkness; // 0x3e8(0x04)
	float OcclusionDepthRange; // 0x3ec(0x04)
	struct FVector LightShaftOverrideDirection; // 0x3f0(0x18)
	float WholeSceneDynamicShadowRadius; // 0x408(0x04)
	float DynamicShadowDistanceMovableLight; // 0x40c(0x04)
	float DynamicShadowDistanceStationaryLight; // 0x410(0x04)
	int32_t DynamicShadowCascades; // 0x414(0x04)
	float CascadeDistributionExponent; // 0x418(0x04)
	float CascadeTransitionFraction; // 0x41c(0x04)
	float ShadowDistanceFadeoutFraction; // 0x420(0x04)
	char bUseInsetShadowsForMovableObjects : 1; // 0x424(0x01)
	char pad_424_1 : 7; // 0x424(0x01)
	char pad_425[0x3]; // 0x425(0x03)
	int32_t FarShadowCascadeCount; // 0x428(0x04)
	float FarShadowDistance; // 0x42c(0x04)
	float DistanceFieldShadowDistance; // 0x430(0x04)
	int32_t ForwardShadingPriority; // 0x434(0x04)
	float LightSourceAngle; // 0x438(0x04)
	float LightSourceSoftAngle; // 0x43c(0x04)
	float ShadowSourceAngleFactor; // 0x440(0x04)
	float TraceDistance; // 0x444(0x04)
	char bUsedAsAtmosphereSunLight : 1; // 0x448(0x01)
	char bAtmosphereSunLight : 1; // 0x448(0x01)
	char pad_448_2 : 6; // 0x448(0x01)
	char pad_449[0x3]; // 0x449(0x03)
	int32_t AtmosphereSunLightIndex; // 0x44c(0x04)
	struct FLinearColor AtmosphereSunDiskColorScale; // 0x450(0x10)
	char bPerPixelAtmosphereTransmittance : 1; // 0x460(0x01)
	char bCastShadowsOnClouds : 1; // 0x460(0x01)
	char bCastShadowsOnAtmosphere : 1; // 0x460(0x01)
	char bCastCloudShadows : 1; // 0x460(0x01)
	char pad_460_4 : 4; // 0x460(0x01)
	char pad_461[0x3]; // 0x461(0x03)
	float CloudShadowStrength; // 0x464(0x04)
	float CloudShadowOnAtmosphereStrength; // 0x468(0x04)
	float CloudShadowOnSurfaceStrength; // 0x46c(0x04)
	float CloudShadowDepthBias; // 0x470(0x04)
	float CloudShadowExtent; // 0x474(0x04)
	float CloudShadowMapResolutionScale; // 0x478(0x04)
	float CloudShadowRaySampleCountScale; // 0x47c(0x04)
	struct FLinearColor CloudScatteredLuminanceScale; // 0x480(0x10)
	struct FLightmassDirectionalLightSettings LightmassSettings; // 0x490(0x10)
	char bCastModulatedShadows : 1; // 0x4a0(0x01)
	char pad_4A0_1 : 7; // 0x4a0(0x01)
	char pad_4A1[0x3]; // 0x4a1(0x03)
	struct FColor ModulatedShadowColor; // 0x4a4(0x04)
	float ShadowAmount; // 0x4a8(0x04)
	char pad_4AC[0x4]; // 0x4ac(0x04)

	void SetShadowSourceAngleFactor(float NewValue); // Function Engine.DirectionalLightComponent.SetShadowSourceAngleFactor // (None) // @ game+0xffffcc4adf830041
};

// Class Engine.DrawFrustumComponent
// Size: 0x560 (Inherited: 0x540)
struct UDrawFrustumComponent : UPrimitiveComponent {
	bool bFrustumEnabled; // 0x538(0x01)
	struct FColor FrustumColor; // 0x53c(0x04)
	float FrustumAngle; // 0x540(0x04)
	float FrustumAspectRatio; // 0x544(0x04)
	float FrustumStartDist; // 0x548(0x04)
	float FrustumEndDist; // 0x54c(0x04)
	struct UTexture* Texture; // 0x550(0x08)
	char pad_55D[0x3]; // 0x55d(0x03)
};

// Class Engine.SphereComponent
// Size: 0x560 (Inherited: 0x560)
struct USphereComponent : UShapeComponent {
	float SphereRadius; // 0x558(0x04)

	void SetSphereRadius(float InSphereRadius, bool bUpdateOverlaps); // Function Engine.SphereComponent.SetSphereRadius // (None) // @ game+0xffffcc4edf830041
};

// Class Engine.DrawSphereComponent
// Size: 0x560 (Inherited: 0x560)
struct UDrawSphereComponent : USphereComponent {
	float SphereRadius; // 0x558(0x04)
};

// Class Engine.ForceFeedbackComponent
// Size: 0x390 (Inherited: 0x2a0)
struct UForceFeedbackComponent : USceneComponent {
	struct UForceFeedbackEffect* ForceFeedbackEffect; // 0x2a0(0x08)
	char bAutoDestroy : 1; // 0x2a8(0x01)
	char bStopWhenOwnerDestroyed : 1; // 0x2a8(0x01)
	char bLooping : 1; // 0x2a8(0x01)
	char bIgnoreTimeDilation : 1; // 0x2a8(0x01)
	char bOverrideAttenuation : 1; // 0x2a8(0x01)
	char pad_2A8_5 : 3; // 0x2a8(0x01)
	char pad_2A9[0x3]; // 0x2a9(0x03)
	float IntensityMultiplier; // 0x2ac(0x04)
	struct UForceFeedbackAttenuation* AttenuationSettings; // 0x2b0(0x08)
	struct FForceFeedbackAttenuationSettings AttenuationOverrides; // 0x2b8(0xc0)
	struct FMulticastInlineDelegate OnForceFeedbackFinished; // 0x378(0x10)
	char pad_388[0x8]; // 0x388(0x08)

	void Stop(); // Function Engine.ForceFeedbackComponent.Stop // (None) // @ game+0xffffcc54df830041
};

// Class Engine.InterpToMovementComponent
// Size: 0x1b8 (Inherited: 0x108)
struct UInterpToMovementComponent : UMovementComponent {
	float Duration; // 0x108(0x04)
	char bPauseOnImpact : 1; // 0x10c(0x01)
	char pad_10C_1 : 7; // 0x10c(0x01)
	char pad_10D[0x3]; // 0x10d(0x03)
	bool bSweep; // 0x110(0x01)
	enum class ETeleportType TeleportType; // 0x111(0x01)
	enum class EInterpToBehaviourType BehaviourType; // 0x112(0x01)
	bool bCheckIfStillInWorld; // 0x113(0x01)
	char bForceSubStepping : 1; // 0x114(0x01)
	char pad_114_1 : 7; // 0x114(0x01)
	char pad_115[0x3]; // 0x115(0x03)
	struct FMulticastInlineDelegate OnInterpToReverse; // 0x118(0x10)
	struct FMulticastInlineDelegate OnInterpToStop; // 0x128(0x10)
	struct FMulticastInlineDelegate OnWaitBeginDelegate; // 0x138(0x10)
	struct FMulticastInlineDelegate OnWaitEndDelegate; // 0x148(0x10)
	struct FMulticastInlineDelegate OnResetDelegate; // 0x158(0x10)
	float MaxSimulationTimeStep; // 0x168(0x04)
	int32_t MaxSimulationIterations; // 0x16c(0x04)
	struct TArray<struct FInterpControlPoint> ControlPoints; // 0x170(0x10)
	char pad_180[0x38]; // 0x180(0x38)

	void StopSimulating(struct FHitResult& HitResult); // Function Engine.InterpToMovementComponent.StopSimulating // (None) // @ game+0xffff915cdf830041
};

// Class Engine.LineBatchComponent
// Size: 0x580 (Inherited: 0x540)
struct ULineBatchComponent : UPrimitiveComponent {
	float MinDrawDistance; // 0x2b0(0x04)
	float LDMaxDrawDistance; // 0x2b4(0x04)
	float CachedMaxDrawDistance; // 0x2b8(0x04)
	enum class ESceneDepthPriorityGroup DepthPriorityGroup; // 0x2bc(0x01)
	enum class ESceneDepthPriorityGroup ViewOwnerDepthPriorityGroup; // 0x2bd(0x01)
	enum class EIndirectLightingCacheQuality IndirectLightingCacheQuality; // 0x2be(0x01)
	enum class ELightmapType LightmapType; // 0x2bf(0x01)
	char bIsValidTextureStreamingBuiltData : 1; // 0x2c0(0x01)
	char bNeverDistanceCull : 1; // 0x2c0(0x01)
	char pad_550_2 : 5; // 0x550(0x01)
	char bAlwaysCreatePhysicsState : 1; // 0x2c0(0x01)
	char bGenerateOverlapEvents : 1; // 0x2c1(0x01)
	char bMultiBodyOverlap : 1; // 0x2c1(0x01)
	char bTraceComplexOnMove : 1; // 0x2c1(0x01)
	char bReturnMaterialOnMove : 1; // 0x2c1(0x01)
	char bUseViewOwnerDepthPriorityGroup : 1; // 0x2c1(0x01)
	char bAllowCullDistanceVolume : 1; // 0x2c1(0x01)
	char bVisibleInReflectionCaptures : 1; // 0x2c1(0x01)
	char bVisibleInRealTimeSkyCaptures : 1; // 0x2c1(0x01)
	char bVisibleInRayTracing : 1; // 0x2c2(0x01)
	char bRenderInMainPass : 1; // 0x2c2(0x01)
	char bRenderInDepthPass : 1; // 0x2c2(0x01)
	char bReceivesDecals : 1; // 0x2c2(0x01)
	char bOwnerNoSee : 1; // 0x2c2(0x01)
	char bOnlyOwnerSee : 1; // 0x2c2(0x01)
	char bTreatAsBackgroundForOcclusion : 1; // 0x2c2(0x01)
	char bUseAsOccluder : 1; // 0x2c2(0x01)
	char bSelectable : 1; // 0x2c3(0x01)
	char bForceMipStreaming : 1; // 0x2c3(0x01)
	char bHasPerInstanceHitProxies : 1; // 0x2c3(0x01)
	char CastShadow : 1; // 0x2c3(0x01)
	char bEmissiveLightSource : 1; // 0x2c3(0x01)
	char bAffectDynamicIndirectLighting : 1; // 0x2c3(0x01)
	char bAffectIndirectLightingWhileHidden : 1; // 0x2c3(0x01)
	char bAffectDistanceFieldLighting : 1; // 0x2c3(0x01)
	char bCastDynamicShadow : 1; // 0x2c4(0x01)
	char bCastStaticShadow : 1; // 0x2c4(0x01)
	char bCastVolumetricTranslucentShadow : 1; // 0x2c4(0x01)
	char bCastContactShadow : 1; // 0x2c4(0x01)
	char bSelfShadowOnly : 1; // 0x2c4(0x01)
	char bCastFarShadow : 1; // 0x2c4(0x01)
	char bCastInsetShadow : 1; // 0x2c4(0x01)
	char bCastCinematicShadow : 1; // 0x2c4(0x01)
	char bCastHiddenShadow : 1; // 0x2c5(0x01)
	char bCastShadowAsTwoSided : 1; // 0x2c5(0x01)
	char bLightAsIfStatic : 1; // 0x2c5(0x01)
	char bLightAttachmentsAsGroup : 1; // 0x2c5(0x01)
	char bExcludeFromLightAttachmentGroup : 1; // 0x2c5(0x01)
	char bReceiveMobileCSMShadows : 1; // 0x2c5(0x01)
	char bSingleSampleShadowFromStationaryLights : 1; // 0x2c5(0x01)
	char bIgnoreRadialImpulse : 1; // 0x2c5(0x01)
	char bIgnoreRadialForce : 1; // 0x2c6(0x01)
	char bApplyImpulseOnDamage : 1; // 0x2c6(0x01)
	char bReplicatePhysicsToAutonomousProxy : 1; // 0x2c6(0x01)
	char bFillCollisionUnderneathForNavmesh : 1; // 0x2c6(0x01)
	char AlwaysLoadOnClient : 1; // 0x2c6(0x01)
	char AlwaysLoadOnServer : 1; // 0x2c6(0x01)
	char bUseEditorCompositing : 1; // 0x2c6(0x01)
	char bIsBeingMovedByEditor : 1; // 0x2c6(0x01)
	char bRenderCustomDepth : 1; // 0x2c7(0x01)
	char bVisibleInSceneCaptureOnly : 1; // 0x2c7(0x01)
	char bHiddenInSceneCapture : 1; // 0x2c7(0x01)
	char bRayTracingFarField : 1; // 0x2c7(0x01)
	char pad_557_4 : 1; // 0x557(0x01)
	char bHasNoStreamableTextures : 1; // 0x2c7(0x01)
	enum class EHasCustomNavigableGeometry bHasCustomNavigableGeometry; // 0x2c8(0x01)
	enum class ECanBeCharacterBase CanCharacterStepUpOn; // 0x2ca(0x01)
	struct FLightingChannels LightingChannels; // 0x2cb(0x01)
	int32_t RayTracingGroupId; // 0x2cc(0x04)
	int32_t VisibilityId; // 0x2d0(0x04)
	int32_t CustomDepthStencilValue; // 0x2d4(0x04)
	struct FCustomPrimitiveData CustomPrimitiveData; // 0x2d8(0x10)
	struct FCustomPrimitiveData CustomPrimitiveDataInternal; // 0x2e8(0x10)
	int32_t TranslucencySortPriority; // 0x300(0x04)
	float TranslucencySortDistanceOffset; // 0x304(0x04)
	struct TArray<struct URuntimeVirtualTexture*> RuntimeVirtualTextures; // 0x308(0x10)
	int8_t VirtualTextureLodBias; // 0x318(0x01)
	int8_t VirtualTextureCullMips; // 0x319(0x01)
	int8_t VirtualTextureMinCoverage; // 0x31a(0x01)
	enum class ERuntimeVirtualTextureMainPassType VirtualTextureRenderPassType; // 0x31b(0x01)
	float BoundsScale; // 0x32c(0x04)
	struct TArray<struct AActor*> MoveIgnoreActors; // 0x340(0x10)
	struct TArray<struct UPrimitiveComponent*> MoveIgnoreComponents; // 0x350(0x10)
	struct FBodyInstance BodyInstance; // 0x370(0x190)
	struct FMulticastSparseDelegate OnComponentHit; // 0x500(0x01)
	struct FMulticastSparseDelegate OnComponentBeginOverlap; // 0x501(0x01)
	struct FMulticastSparseDelegate OnComponentEndOverlap; // 0x502(0x01)
	struct FMulticastSparseDelegate OnComponentWake; // 0x503(0x01)
	struct FMulticastSparseDelegate OnComponentSleep; // 0x504(0x01)
	struct FMulticastSparseDelegate OnComponentPhysicsStateChanged; // 0x506(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x507(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x508(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x509(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x50a(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x50b(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x50c(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x50d(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x50e(0x01)
	enum class ERayTracingGroupCullingPriority RayTracingGroupCullingPriority; // 0x50f(0x01)
	enum class ERendererStencilMask CustomDepthStencilWriteMask; // 0x510(0x01)
	struct UPrimitiveComponent* LODParentPrimitive; // 0x530(0x08)
};

// Class Engine.LocalLightComponent
// Size: 0x400 (Inherited: 0x3e0)
struct ULocalLightComponent : ULightComponent {
	enum class ELightUnits IntensityUnits; // 0x3e0(0x01)
	char pad_3E1[0x3]; // 0x3e1(0x03)
	float InverseExposureBlend; // 0x3e4(0x04)
	float Radius; // 0x3e8(0x04)
	float AttenuationRadius; // 0x3ec(0x04)
	struct FLightmassPointLightSettings LightmassSettings; // 0x3f0(0x0c)
	char pad_3FC[0x4]; // 0x3fc(0x04)

	void SetIntensityUnits(enum class ELightUnits NewIntensityUnits); // Function Engine.LocalLightComponent.SetIntensityUnits // (None) // @ game+0xffffcc57df830041
};

// Class Engine.LODSyncComponent
// Size: 0x138 (Inherited: 0xa0)
struct ULODSyncComponent : UActorComponent {
	int32_t NumLODs; // 0xa0(0x04)
	int32_t ForcedLOD; // 0xa4(0x04)
	int32_t MinLOD; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
	struct TArray<struct FComponentSync> ComponentsToSync; // 0xb0(0x10)
	struct TMap<struct FName, struct FLODMappingData> CustomLODMapping; // 0xc0(0x50)
	int32_t CurrentLOD; // 0x110(0x04)
	int32_t CurrentNumLODs; // 0x114(0x04)
	struct TArray<struct UPrimitiveComponent*> DriveComponents; // 0x118(0x10)
	struct TArray<struct UPrimitiveComponent*> SubComponents; // 0x128(0x10)

	struct FString GetLODSyncDebugText(); // Function Engine.LODSyncComponent.GetLODSyncDebugText // (None) // @ game+0xffffcc58df830041
};

// Class Engine.MaterialBillboardComponent
// Size: 0x550 (Inherited: 0x540)
struct UMaterialBillboardComponent : UPrimitiveComponent {
	struct TArray<struct FMaterialSpriteElement> Elements; // 0x538(0x10)

	void SetElements(struct TArray<struct FMaterialSpriteElement>& NewElements); // Function Engine.MaterialBillboardComponent.SetElements // (None) // @ game+0xffffcc5adf830041
};

// Class Engine.ModelComponent
// Size: 0x580 (Inherited: 0x540)
struct UModelComponent : UPrimitiveComponent {
	char pad_540[0x10]; // 0x540(0x10)
	struct UBodySetup* ModelBodySetup; // 0x550(0x08)
	char pad_558[0x28]; // 0x558(0x28)
};

// Class Engine.PawnNoiseEmitterComponent
// Size: 0xd8 (Inherited: 0xa0)
struct UPawnNoiseEmitterComponent : UActorComponent {
	char bAIPerceptionSystemCompatibilityMode : 1; // 0xa0(0x01)
	char pad_A0_1 : 7; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)
	struct FVector LastRemoteNoisePosition; // 0xa8(0x18)
	float NoiseLifetime; // 0xc0(0x04)
	float LastRemoteNoiseVolume; // 0xc4(0x04)
	float LastRemoteNoiseTime; // 0xc8(0x04)
	float LastLocalNoiseVolume; // 0xcc(0x04)
	float LastLocalNoiseTime; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)

	void MakeNoise(struct AActor* NoiseMaker, float Loudness, struct FVector& NoiseLocation); // Function Engine.PawnNoiseEmitterComponent.MakeNoise // (None) // @ game+0xffffcc5bdf830041
};

// Class Engine.PlatformEventsComponent
// Size: 0xc0 (Inherited: 0xa0)
struct UPlatformEventsComponent : UActorComponent {
	struct FMulticastInlineDelegate PlatformChangedToLaptopModeDelegate; // 0xa0(0x10)
	struct FMulticastInlineDelegate PlatformChangedToTabletModeDelegate; // 0xb0(0x10)

	bool SupportsConvertibleLaptops(); // Function Engine.PlatformEventsComponent.SupportsConvertibleLaptops // (None) // @ game+0xffff9278df830041
};

// Class Engine.PointLightComponent
// Size: 0x420 (Inherited: 0x400)
struct UPointLightComponent : ULocalLightComponent {
	char bUseInverseSquaredFalloff : 1; // 0x400(0x01)
	char pad_400_1 : 7; // 0x400(0x01)
	char pad_401[0x3]; // 0x401(0x03)
	float LightFalloffExponent; // 0x404(0x04)
	float SourceRadius; // 0x408(0x04)
	float SoftSourceRadius; // 0x40c(0x04)
	float SourceLength; // 0x410(0x04)
	char pad_414[0xc]; // 0x414(0x0c)

	void SetUseInverseSquaredFalloff(bool bNewValue); // Function Engine.PointLightComponent.SetUseInverseSquaredFalloff // (None) // @ game+0xffffcc61df830041
};

// Class Engine.PoseableMeshComponent
// Size: 0xa40 (Inherited: 0x8a0)
struct UPoseableMeshComponent : USkinnedMeshComponent {
	struct USkeletalMesh* SkeletalMesh; // 0x578(0x08)
	struct USkinnedAsset* SkinnedAsset; // 0x580(0x08)
	struct TWeakObjectPtr<struct USkinnedMeshComponent> LeaderPoseComponent; // 0x588(0x08)
	struct TArray<enum class ESkinCacheUsage> SkinCacheUsage; // 0x590(0x10)
	bool bSetMeshDeformer; // 0x5a0(0x01)
	struct UMeshDeformer* MeshDeformer; // 0x5a8(0x08)
	struct UMeshDeformerInstanceSettings* MeshDeformerInstanceSettings; // 0x5b0(0x08)
	struct UMeshDeformerInstance* MeshDeformerInstance; // 0x5b8(0x08)
	struct UPhysicsAsset* PhysicsAssetOverride; // 0x728(0x08)
	int32_t ForcedLodModel; // 0x730(0x04)
	int32_t MinLodModel; // 0x734(0x04)
	float StreamingDistanceMultiplier; // 0x740(0x04)
	struct TArray<struct FSkelMeshComponentLODInfo> LODInfo; // 0x750(0x10)
	enum class EVisibilityBasedAnimTickOption VisibilityBasedAnimTickOption; // 0x784(0x01)
	char pad_906_0 : 3; // 0x906(0x01)
	char bOverrideMinLod : 1; // 0x786(0x01)
	char bUseBoundsFromLeaderPoseComponent : 1; // 0x786(0x01)
	char bForceWireframe : 1; // 0x786(0x01)
	char bDisplayBones : 1; // 0x786(0x01)
	char bDisableMorphTarget : 1; // 0x786(0x01)
	char bHideSkin : 1; // 0x787(0x01)
	char bPerBoneMotionBlur : 1; // 0x787(0x01)
	char bComponentUseFixedSkelBounds : 1; // 0x787(0x01)
	char bConsiderAllBodiesForBounds : 1; // 0x787(0x01)
	char bSyncAttachParentLOD : 1; // 0x787(0x01)
	char bCanHighlightSelectedSections : 1; // 0x787(0x01)
	char bRecentlyRendered : 1; // 0x787(0x01)
	char bCastCapsuleDirectShadow : 1; // 0x787(0x01)
	char bCastCapsuleIndirectShadow : 1; // 0x788(0x01)
	char bCPUSkinning : 1; // 0x788(0x01)
	char bEnableUpdateRateOptimizations : 1; // 0x788(0x01)
	char bDisplayDebugUpdateRateOptimizations : 1; // 0x788(0x01)
	char bRenderStatic : 1; // 0x788(0x01)
	char bIgnoreLeaderPoseComponentLOD : 1; // 0x788(0x01)
	char bCachedLocalBoundsUpToDate : 1; // 0x789(0x01)
	char bCachedWorldSpaceBoundsUpToDate : 1; // 0x789(0x01)
	char pad_909_0 : 4; // 0x909(0x01)
	char bForceMeshObjectUpdate : 1; // 0x789(0x01)
	char bFollowerShouldTickPose : 1; // 0x78a(0x01)
	float CapsuleIndirectShadowMinVisibility; // 0x78c(0x04)
	struct FBoxSphereBounds CachedWorldOrLocalSpaceBounds; // 0x7c8(0x38)
	struct FMatrix CachedWorldToLocalTransform; // 0x800(0x80)
	char pad_9C5_6 : 2; // 0x9c5(0x01)
	char pad_9C6[0x7a]; // 0x9c6(0x7a)

	void SetBoneTransformByName(struct FName BoneName, struct FTransform& InTransform, enum class EBoneSpaces BoneSpace); // Function Engine.PoseableMeshComponent.SetBoneTransformByName // (None) // @ game+0xffffcc6bdf830041
};

// Class Engine.PostProcessComponent
// Size: 0x9a0 (Inherited: 0x2a0)
struct UPostProcessComponent : USceneComponent {
	char pad_2A0[0x10]; // 0x2a0(0x10)
	struct FPostProcessSettings Settings; // 0x2b0(0x6e0)
	float Priority; // 0x990(0x04)
	float BlendRadius; // 0x994(0x04)
	float BlendWeight; // 0x998(0x04)
	char bEnabled : 1; // 0x99c(0x01)
	char bUnbound : 1; // 0x99c(0x01)
	char pad_99C_2 : 6; // 0x99c(0x01)
	char pad_99D[0x3]; // 0x99d(0x03)

	void AddOrUpdateBlendable(struct TScriptInterface<IBlendableInterface> InBlendableObject, float InWeight); // Function Engine.PostProcessComponent.AddOrUpdateBlendable // (None) // @ game+0xffffcc6cdf830041
};

// Class Engine.ProjectileMovementComponent
// Size: 0x240 (Inherited: 0x108)
struct UProjectileMovementComponent : UMovementComponent {
	float InitialSpeed; // 0x108(0x04)
	float MaxSpeed; // 0x10c(0x04)
	char bRotationFollowsVelocity : 1; // 0x110(0x01)
	char bRotationRemainsVertical : 1; // 0x110(0x01)
	char bShouldBounce : 1; // 0x110(0x01)
	char bInitialVelocityInLocalSpace : 1; // 0x110(0x01)
	char bForceSubStepping : 1; // 0x110(0x01)
	char bSimulationEnabled : 1; // 0x110(0x01)
	char bSweepCollision : 1; // 0x110(0x01)
	char bIsHomingProjectile : 1; // 0x110(0x01)
	char bBounceAngleAffectsFriction : 1; // 0x111(0x01)
	char bIsSliding : 1; // 0x111(0x01)
	char bInterpMovement : 1; // 0x111(0x01)
	char bInterpRotation : 1; // 0x111(0x01)
	char pad_111_4 : 4; // 0x111(0x01)
	char pad_112[0x2]; // 0x112(0x02)
	float PreviousHitTime; // 0x114(0x04)
	struct FVector PreviousHitNormal; // 0x118(0x18)
	float ProjectileGravityScale; // 0x130(0x04)
	float Buoyancy; // 0x134(0x04)
	float Bounciness; // 0x138(0x04)
	float Friction; // 0x13c(0x04)
	float BounceVelocityStopSimulatingThreshold; // 0x140(0x04)
	float MinFrictionFraction; // 0x144(0x04)
	struct FMulticastInlineDelegate OnProjectileBounce; // 0x148(0x10)
	struct FMulticastInlineDelegate OnProjectileStop; // 0x158(0x10)
	float HomingAccelerationMagnitude; // 0x168(0x04)
	struct TWeakObjectPtr<struct USceneComponent> HomingTargetComponent; // 0x16c(0x08)
	float MaxSimulationTimeStep; // 0x174(0x04)
	int32_t MaxSimulationIterations; // 0x178(0x04)
	int32_t BounceAdditionalIterations; // 0x17c(0x04)
	float InterpLocationTime; // 0x180(0x04)
	float InterpRotationTime; // 0x184(0x04)
	float InterpLocationMaxLagDistance; // 0x188(0x04)
	float InterpLocationSnapToTargetDistance; // 0x18c(0x04)
	char pad_190[0xb0]; // 0x190(0xb0)

	void StopSimulating(struct FHitResult& HitResult); // Function Engine.ProjectileMovementComponent.StopSimulating // (None) // @ game+0xffff9294df830041
};

// Class Engine.RectLightComponent
// Size: 0x420 (Inherited: 0x400)
struct URectLightComponent : ULocalLightComponent {
	float SourceWidth; // 0x400(0x04)
	float SourceHeight; // 0x404(0x04)
	float BarnDoorAngle; // 0x408(0x04)
	float BarnDoorLength; // 0x40c(0x04)
	struct UTexture* SourceTexture; // 0x410(0x08)
	char pad_418[0x8]; // 0x418(0x08)

	void SetSourceWidth(float NewValue); // Function Engine.RectLightComponent.SetSourceWidth // (None) // @ game+0xffffcc71df830041
};

// Class Engine.RotatingMovementComponent
// Size: 0x140 (Inherited: 0x108)
struct URotatingMovementComponent : UMovementComponent {
	struct FRotator RotationRate; // 0x108(0x18)
	struct FVector PivotTranslation; // 0x120(0x18)
	char bRotationInLocalSpace : 1; // 0x138(0x01)
	char pad_138_1 : 7; // 0x138(0x01)
	char pad_139[0x7]; // 0x139(0x07)
};

// Class Engine.RuntimeVirtualTextureComponent
// Size: 0x330 (Inherited: 0x2a0)
struct URuntimeVirtualTextureComponent : USceneComponent {
	struct TSoftObjectPtr<AActor> BoundsAlignActor; // 0x2a0(0x30)
	bool bSetBoundsButton; // 0x2d0(0x01)
	bool bSnapBoundsToLandscape; // 0x2d1(0x01)
	char pad_2D2[0x6]; // 0x2d2(0x06)
	struct URuntimeVirtualTexture* VirtualTexture; // 0x2d8(0x08)
	bool bEnableScalability; // 0x2e0(0x01)
	char pad_2E1[0x3]; // 0x2e1(0x03)
	uint32_t ScalabilityGroup; // 0x2e4(0x04)
	bool bHidePrimitives; // 0x2e8(0x01)
	char pad_2E9[0x7]; // 0x2e9(0x07)
	struct UVirtualTextureBuilder* StreamingTexture; // 0x2f0(0x08)
	int32_t StreamLowMips; // 0x2f8(0x04)
	bool bBuildStreamingMipsButton; // 0x2fc(0x01)
	enum class ETextureLossyCompressionAmount LossyCompressionAmount; // 0x2fd(0x01)
	bool bUseStreamingLowMipsInEditor; // 0x2fe(0x01)
	bool bBuildDebugStreamingMips; // 0x2ff(0x01)
	char pad_300[0x30]; // 0x300(0x30)

	void Invalidate(struct FBoxSphereBounds& WorldBounds); // Function Engine.RuntimeVirtualTextureComponent.Invalidate // (None) // @ game+0xffffcc72df830041
};

// Class Engine.SkyAtmosphere
// Size: 0x298 (Inherited: 0x290)
struct ASkyAtmosphere : AInfo {
	struct USkyAtmosphereComponent* SkyAtmosphereComponent; // 0x290(0x08)
};

// Class Engine.SplineMeshComponent
// Size: 0x6f0 (Inherited: 0x5f0)
struct USplineMeshComponent : UStaticMeshComponent {
	char pad_5F0[0x8]; // 0x5f0(0x08)
	struct FSplineMeshParams SplineParams; // 0x5f8(0xb0)
	struct FVector SplineUpDir; // 0x6a8(0x18)
	float SplineBoundaryMin; // 0x6c0(0x04)
	struct FGuid CachedMeshBodySetupGuid; // 0x6c4(0x10)
	char pad_6D4[0x4]; // 0x6d4(0x04)
	struct UBodySetup* BodySetup; // 0x6d8(0x08)
	float SplineBoundaryMax; // 0x6e0(0x04)
	char bAllowSplineEditingPerInstance : 1; // 0x6e4(0x01)
	char bSmoothInterpRollScale : 1; // 0x6e4(0x01)
	char bMeshDirty : 1; // 0x6e4(0x01)
	char pad_6E4_3 : 5; // 0x6e4(0x01)
	enum class ESplineMeshAxis ForwardAxis; // 0x6e5(0x01)
	char pad_6E6[0x2]; // 0x6e6(0x02)
	float VirtualTextureMainPassMaxDrawDistance; // 0x6e8(0x04)
	char pad_6EC[0x4]; // 0x6ec(0x04)

	void UpdateMesh(); // Function Engine.SplineMeshComponent.UpdateMesh // (None) // @ game+0xffffcc90df830041
};

// Class Engine.SpotLightComponent
// Size: 0x420 (Inherited: 0x420)
struct USpotLightComponent : UPointLightComponent {
	float InnerConeAngle; // 0x418(0x04)
	float OuterConeAngle; // 0x41c(0x04)

	void SetOuterConeAngle(float NewOuterConeAngle); // Function Engine.SpotLightComponent.SetOuterConeAngle // (None) // @ game+0xffffcc92df830041
};

// Class Engine.VolumetricCloudComponent
// Size: 0x300 (Inherited: 0x2a0)
struct UVolumetricCloudComponent : USceneComponent {
	float LayerBottomAltitude; // 0x2a0(0x04)
	float LayerHeight; // 0x2a4(0x04)
	float TracingStartMaxDistance; // 0x2a8(0x04)
	enum class EVolumetricCloudTracingMaxDistanceMode TracingMaxDistanceMode; // 0x2ac(0x01)
	char pad_2AD[0x3]; // 0x2ad(0x03)
	float TracingMaxDistance; // 0x2b0(0x04)
	float PlanetRadius; // 0x2b4(0x04)
	struct FColor GroundAlbedo; // 0x2b8(0x04)
	char pad_2BC[0x4]; // 0x2bc(0x04)
	struct UMaterialInterface* Material; // 0x2c0(0x08)
	char bUsePerSampleAtmosphericLightTransmittance : 1; // 0x2c8(0x01)
	char pad_2C8_1 : 7; // 0x2c8(0x01)
	char pad_2C9[0x3]; // 0x2c9(0x03)
	float SkyLightCloudBottomOcclusion; // 0x2cc(0x04)
	float ViewSampleCountScale; // 0x2d0(0x04)
	float ReflectionViewSampleCountScaleValue; // 0x2d4(0x04)
	float ReflectionViewSampleCountScale; // 0x2d8(0x04)
	float ReflectionSampleCountScale; // 0x2dc(0x04)
	float ShadowViewSampleCountScale; // 0x2e0(0x04)
	float ShadowReflectionViewSampleCountScaleValue; // 0x2e4(0x04)
	float ShadowReflectionViewSampleCountScale; // 0x2e8(0x04)
	float ShadowReflectionSampleCountScale; // 0x2ec(0x04)
	float ShadowTracingDistance; // 0x2f0(0x04)
	float StopTracingTransmittanceThreshold; // 0x2f4(0x04)
	char pad_2F8[0x8]; // 0x2f8(0x08)

	void SetViewSampleCountScale(float NewValue); // Function Engine.VolumetricCloudComponent.SetViewSampleCountScale // (None) // @ game+0xffffcca3df830041
};

// Class Engine.VolumetricCloud
// Size: 0x298 (Inherited: 0x290)
struct AVolumetricCloud : AInfo {
	struct UVolumetricCloudComponent* VolumetricCloudComponent; // 0x290(0x08)
};

// Class Engine.WorldPartitionStreamingSourceComponent
// Size: 0xd8 (Inherited: 0xa0)
struct UWorldPartitionStreamingSourceComponent : UActorComponent {
	char pad_A0[0x8]; // 0xa0(0x08)
	struct FName TargetGrid; // 0xa8(0x08)
	struct FColor DebugColor; // 0xb0(0x04)
	char pad_B4[0x4]; // 0xb4(0x04)
	struct UHLODLayer* TargetHLODLayer; // 0xb8(0x08)
	struct TArray<struct FStreamingSourceShape> Shapes; // 0xc0(0x10)
	enum class EStreamingSourcePriority Priority; // 0xd0(0x01)
	bool bStreamingSourceEnabled; // 0xd1(0x01)
	enum class EStreamingSourceTargetState TargetState; // 0xd2(0x01)
	char pad_D3[0x5]; // 0xd3(0x05)

	bool IsStreamingSourceEnabled(); // Function Engine.WorldPartitionStreamingSourceComponent.IsStreamingSourceEnabled // (None) // @ game+0xffffcca7df830041
};

// Class Engine.CurveTable
// Size: 0xa0 (Inherited: 0x28)
struct UCurveTable : UObject {
	char pad_28[0x78]; // 0x28(0x78)
};

// Class Engine.CompositeCurveTable
// Size: 0xc8 (Inherited: 0xa0)
struct UCompositeCurveTable : UCurveTable {
	struct TArray<struct UCurveTable*> ParentTables; // 0xa0(0x10)
	struct TArray<struct UCurveTable*> OldParentTables; // 0xb0(0x10)
	char pad_C0[0x8]; // 0xc0(0x08)
};

// Class Engine.CompositeDataTable
// Size: 0xd8 (Inherited: 0xb0)
struct UCompositeDataTable : UDataTable {
	struct TArray<struct UDataTable*> ParentTables; // 0xb0(0x10)
	struct TArray<struct UDataTable*> OldParentTables; // 0xc0(0x10)
	char pad_D0[0x8]; // 0xd0(0x08)
};

// Class Engine.EnumCookedMetaData
// Size: 0x78 (Inherited: 0x28)
struct UEnumCookedMetaData : UObject {
	struct FObjectCookedMetaDataStore EnumMetaData; // 0x28(0x50)
};

// Class Engine.StructCookedMetaData
// Size: 0xc8 (Inherited: 0x28)
struct UStructCookedMetaData : UObject {
	struct FStructCookedMetaDataStore StructMetaData; // 0x28(0xa0)
};

// Class Engine.ClassCookedMetaData
// Size: 0x118 (Inherited: 0x28)
struct UClassCookedMetaData : UObject {
	struct FStructCookedMetaDataStore ClassMetaData; // 0x28(0xa0)
	struct TMap<struct FName, struct FStructCookedMetaDataStore> FunctionsMetaData; // 0xc8(0x50)
};

// Class Engine.StreamingSettings
// Size: 0x70 (Inherited: 0x38)
struct UStreamingSettings : UDeveloperSettings {
	char AsyncLoadingThreadEnabled : 1; // 0x38(0x01)
	char WarnIfTimeLimitExceeded : 1; // 0x38(0x01)
	char pad_38_2 : 6; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	float TimeLimitExceededMultiplier; // 0x3c(0x04)
	float TimeLimitExceededMinTime; // 0x40(0x04)
	int32_t MinBulkDataSizeForAsyncLoading; // 0x44(0x04)
	char UseBackgroundLevelStreaming : 1; // 0x48(0x01)
	char AsyncLoadingUseFullTimeLimit : 1; // 0x48(0x01)
	char pad_48_2 : 6; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	float AsyncLoadingTimeLimit; // 0x4c(0x04)
	float PriorityAsyncLoadingExtraTime; // 0x50(0x04)
	float LevelStreamingActorsUpdateTimeLimit; // 0x54(0x04)
	float PriorityLevelStreamingActorsUpdateExtraTime; // 0x58(0x04)
	int32_t LevelStreamingComponentsRegistrationGranularity; // 0x5c(0x04)
	int32_t LevelStreamingAddPrimitiveGranularity; // 0x60(0x04)
	float LevelStreamingUnregisterComponentsTimeLimit; // 0x64(0x04)
	int32_t LevelStreamingComponentsUnregistrationGranularity; // 0x68(0x04)
	char FlushStreamingOnExit : 1; // 0x6c(0x01)
	char EventDrivenLoaderEnabled : 1; // 0x6c(0x01)
	char pad_6C_2 : 6; // 0x6c(0x01)
	char pad_6D[0x3]; // 0x6d(0x03)
};

// Class Engine.GarbageCollectionSettings
// Size: 0x58 (Inherited: 0x38)
struct UGarbageCollectionSettings : UDeveloperSettings {
	float TimeBetweenPurgingPendingKillObjects; // 0x38(0x04)
	char FlushStreamingOnGC : 1; // 0x3c(0x01)
	char AllowParallelGC : 1; // 0x3c(0x01)
	char IncrementalBeginDestroyEnabled : 1; // 0x3c(0x01)
	char MultithreadedDestructionEnabled : 1; // 0x3c(0x01)
	char CreateGCClusters : 1; // 0x3c(0x01)
	char AssetClusteringEnabled : 1; // 0x3c(0x01)
	char ActorClusteringEnabled : 1; // 0x3c(0x01)
	char BlueprintClusteringEnabled : 1; // 0x3c(0x01)
	char UseDisregardForGCOnDedicatedServers : 1; // 0x3d(0x01)
	char VerifyGCObjectNames : 1; // 0x3d(0x01)
	char VerifyUObjectsAreNotFGCObjects : 1; // 0x3d(0x01)
	char PendingKillEnabled : 1; // 0x3d(0x01)
	char pad_3D_4 : 4; // 0x3d(0x01)
	char pad_3E[0x2]; // 0x3e(0x02)
	int32_t MinGCClusterSize; // 0x40(0x04)
	int32_t NumRetriesBeforeForcingGC; // 0x44(0x04)
	int32_t MaxObjectsNotConsideredByGC; // 0x48(0x04)
	int32_t SizeOfPermanentObjectPool; // 0x4c(0x04)
	int32_t MaxObjectsInGame; // 0x50(0x04)
	int32_t MaxObjectsInEditor; // 0x54(0x04)
};

// Class Engine.CullDistanceVolume
// Size: 0x2e0 (Inherited: 0x2c8)
struct ACullDistanceVolume : AVolume {
	struct TArray<struct FCullDistanceSizePair> CullDistances; // 0x2c8(0x10)
	char bEnabled : 1; // 0x2d8(0x01)
	char pad_2D8_1 : 7; // 0x2d8(0x01)
	char pad_2D9[0x7]; // 0x2d9(0x07)
};

// Class Engine.CurveBase
// Size: 0x30 (Inherited: 0x28)
struct UCurveBase : UObject {
	char pad_28[0x8]; // 0x28(0x08)

	void GetValueRange(float& MinValue, float& MaxValue); // Function Engine.CurveBase.GetValueRange // (None) // @ game+0xffffcca9df830041
};

// Class Engine.CurveEdPresetCurve
// Size: 0x28 (Inherited: 0x28)
struct UCurveEdPresetCurve : UObject {
};

// Class Engine.CurveFloat
// Size: 0xb8 (Inherited: 0x30)
struct UCurveFloat : UCurveBase {
	struct FRichCurve FloatCurve; // 0x30(0x80)
	bool bIsEventCurve; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)

	float GetFloatValue(float InTime); // Function Engine.CurveFloat.GetFloatValue // (None) // @ game+0xffffccecdf830041
};

// Class Engine.CurveLinearColor
// Size: 0x250 (Inherited: 0x30)
struct UCurveLinearColor : UCurveBase {
	struct FRichCurve FloatCurves[0x4]; // 0x30(0x200)
	float AdjustHue; // 0x230(0x04)
	float AdjustSaturation; // 0x234(0x04)
	float AdjustBrightness; // 0x238(0x04)
	float AdjustBrightnessCurve; // 0x23c(0x04)
	float AdjustVibrance; // 0x240(0x04)
	float AdjustMinAlpha; // 0x244(0x04)
	float AdjustMaxAlpha; // 0x248(0x04)
	char pad_24C[0x4]; // 0x24c(0x04)

	struct FLinearColor GetUnadjustedLinearColorValue(float InTime); // Function Engine.CurveLinearColor.GetUnadjustedLinearColorValue // (None) // @ game+0xffffccaddf830041
};

// Class Engine.CurveLinearColorAtlas
// Size: 0x2d0 (Inherited: 0x2b0)
struct UCurveLinearColorAtlas : UTexture2D {
	uint32_t TextureSize; // 0x2a8(0x04)
	char bSquareResolution : 1; // 0x2ac(0x01)
	uint32_t TextureHeight; // 0x2b0(0x04)
	struct TArray<struct UCurveLinearColor*> GradientCurves; // 0x2b8(0x10)
	char pad_2C8_1 : 7; // 0x2c8(0x01)
	char pad_2C9[0x7]; // 0x2c9(0x07)

	bool GetCurvePosition(struct UCurveLinearColor* InCurve, float& Position); // Function Engine.CurveLinearColorAtlas.GetCurvePosition // (None) // @ game+0xffffccaedf830041
};

// Class Engine.CurveVector
// Size: 0x1b0 (Inherited: 0x30)
struct UCurveVector : UCurveBase {
	struct FRichCurve FloatCurves[0x3]; // 0x30(0x180)

	struct FVector GetVectorValue(float InTime); // Function Engine.CurveVector.GetVectorValue // (None) // @ game+0xffffccafdf830041
};

// Class Engine.DamageType
// Size: 0x40 (Inherited: 0x28)
struct UDamageType : UObject {
	char bCausedByWorld : 1; // 0x28(0x01)
	char bScaleMomentumByMass : 1; // 0x28(0x01)
	char bRadialDamageVelChange : 1; // 0x28(0x01)
	char pad_28_3 : 5; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	float DamageImpulse; // 0x2c(0x04)
	float DestructibleImpulse; // 0x30(0x04)
	float DestructibleDamageSpreadScale; // 0x34(0x04)
	float DamageFalloff; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class Engine.DataDrivenCVarEngineSubsystem
// Size: 0x40 (Inherited: 0x30)
struct UDataDrivenCVarEngineSubsystem : UEngineSubsystem {
	struct FMulticastInlineDelegate OnDataDrivenCVarDelegate; // 0x30(0x10)
};

// Class Engine.DataDrivenConsoleVariableSettings
// Size: 0x70 (Inherited: 0x38)
struct UDataDrivenConsoleVariableSettings : UDeveloperSettings {
	char pad_38[0x18]; // 0x38(0x18)
	struct TArray<struct FDataDrivenConsoleVariable> CVarsArray; // 0x50(0x10)
	char pad_60[0x10]; // 0x60(0x10)
};

// Class Engine.DataTableFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UDataTableFunctionLibrary : UBlueprintFunctionLibrary {

	void GetDataTableRowNames(struct UDataTable* Table, struct TArray<struct FName>& OutRowNames); // Function Engine.DataTableFunctionLibrary.GetDataTableRowNames // (None) // @ game+0xffffccb4df830041
};

// Class Engine.DebugCameraController
// Size: 0x9d0 (Inherited: 0x850)
struct ADebugCameraController : APlayerController {
	char bShowSelectedInfo : 1; // 0x850(0x01)
	char bIsFrozenRendering : 1; // 0x850(0x01)
	char bIsOrbitingSelectedActor : 1; // 0x850(0x01)
	char bOrbitPivotUseCenter : 1; // 0x850(0x01)
	char bEnableBufferVisualization : 1; // 0x850(0x01)
	char bEnableBufferVisualizationFullMode : 1; // 0x850(0x01)
	char bIsBufferVisualizationInputSetup : 1; // 0x850(0x01)
	char bLastDisplayEnabled : 1; // 0x850(0x01)
	char pad_851[0x7]; // 0x851(0x07)
	struct UDrawFrustumComponent* DrawFrustum; // 0x858(0x08)
	struct TWeakObjectPtr<struct AActor> SelectedActor; // 0x860(0x08)
	struct TWeakObjectPtr<struct UPrimitiveComponent> SelectedComponent; // 0x868(0x08)
	struct FHitResult SelectedHitPoint; // 0x870(0xe8)
	struct APlayerController* OriginalControllerRef; // 0x958(0x08)
	struct UPlayer* OriginalPlayer; // 0x960(0x08)
	float SpeedScale; // 0x968(0x04)
	float InitialMaxSpeed; // 0x96c(0x04)
	float InitialAccel; // 0x970(0x04)
	float InitialDecel; // 0x974(0x04)
	char pad_978[0x58]; // 0x978(0x58)

	void ToggleDisplay(); // Function Engine.DebugCameraController.ToggleDisplay // (None) // @ game+0xffffccbbdf830041
};

// Class Engine.DebugCameraControllerSettings
// Size: 0x48 (Inherited: 0x38)
struct UDebugCameraControllerSettings : UDeveloperSettings {
	struct TArray<struct FDebugCameraControllerSettingsViewModeIndex> CycleViewModes; // 0x38(0x10)
};

// Class Engine.DebugCameraHUD
// Size: 0x380 (Inherited: 0x380)
struct ADebugCameraHUD : AHUD {
	struct APlayerController* PlayerOwner; // 0x290(0x08)
	char bLostFocusPaused : 1; // 0x298(0x01)
	char bShowHUD : 1; // 0x298(0x01)
	char bShowDebugInfo : 1; // 0x298(0x01)
	int32_t CurrentTargetIndex; // 0x29c(0x04)
	char bShowHitBoxDebugInfo : 1; // 0x2a0(0x01)
	char bShowOverlays : 1; // 0x2a0(0x01)
	char bEnableDebugTextShadow : 1; // 0x2a0(0x01)
	struct TArray<struct AActor*> PostRenderedActors; // 0x2a8(0x10)
	struct TArray<struct FName> DebugDisplay; // 0x2c0(0x10)
	struct TArray<struct FName> ToggledDebugCategories; // 0x2d0(0x10)
	struct UCanvas* Canvas; // 0x2e0(0x08)
	struct UCanvas* DebugCanvas; // 0x2e8(0x08)
	struct TArray<struct FDebugTextInfo> DebugTextList; // 0x2f0(0x10)
	struct AActor* ShowDebugTargetDesiredClass; // 0x300(0x08)
	struct AActor* ShowDebugTargetActor; // 0x308(0x08)
};

// Class Engine.DebugDrawComponent
// Size: 0x590 (Inherited: 0x540)
struct UDebugDrawComponent : UPrimitiveComponent {
	float MinDrawDistance; // 0x2b0(0x04)
	float LDMaxDrawDistance; // 0x2b4(0x04)
	float CachedMaxDrawDistance; // 0x2b8(0x04)
	enum class ESceneDepthPriorityGroup DepthPriorityGroup; // 0x2bc(0x01)
	enum class ESceneDepthPriorityGroup ViewOwnerDepthPriorityGroup; // 0x2bd(0x01)
	enum class EIndirectLightingCacheQuality IndirectLightingCacheQuality; // 0x2be(0x01)
	enum class ELightmapType LightmapType; // 0x2bf(0x01)
	char bIsValidTextureStreamingBuiltData : 1; // 0x2c0(0x01)
	char bNeverDistanceCull : 1; // 0x2c0(0x01)
	char pad_550_2 : 5; // 0x550(0x01)
	char bAlwaysCreatePhysicsState : 1; // 0x2c0(0x01)
	char bGenerateOverlapEvents : 1; // 0x2c1(0x01)
	char bMultiBodyOverlap : 1; // 0x2c1(0x01)
	char bTraceComplexOnMove : 1; // 0x2c1(0x01)
	char bReturnMaterialOnMove : 1; // 0x2c1(0x01)
	char bUseViewOwnerDepthPriorityGroup : 1; // 0x2c1(0x01)
	char bAllowCullDistanceVolume : 1; // 0x2c1(0x01)
	char bVisibleInReflectionCaptures : 1; // 0x2c1(0x01)
	char bVisibleInRealTimeSkyCaptures : 1; // 0x2c1(0x01)
	char bVisibleInRayTracing : 1; // 0x2c2(0x01)
	char bRenderInMainPass : 1; // 0x2c2(0x01)
	char bRenderInDepthPass : 1; // 0x2c2(0x01)
	char bReceivesDecals : 1; // 0x2c2(0x01)
	char bOwnerNoSee : 1; // 0x2c2(0x01)
	char bOnlyOwnerSee : 1; // 0x2c2(0x01)
	char bTreatAsBackgroundForOcclusion : 1; // 0x2c2(0x01)
	char bUseAsOccluder : 1; // 0x2c2(0x01)
	char bSelectable : 1; // 0x2c3(0x01)
	char bForceMipStreaming : 1; // 0x2c3(0x01)
	char bHasPerInstanceHitProxies : 1; // 0x2c3(0x01)
	char CastShadow : 1; // 0x2c3(0x01)
	char bEmissiveLightSource : 1; // 0x2c3(0x01)
	char bAffectDynamicIndirectLighting : 1; // 0x2c3(0x01)
	char bAffectIndirectLightingWhileHidden : 1; // 0x2c3(0x01)
	char bAffectDistanceFieldLighting : 1; // 0x2c3(0x01)
	char bCastDynamicShadow : 1; // 0x2c4(0x01)
	char bCastStaticShadow : 1; // 0x2c4(0x01)
	char bCastVolumetricTranslucentShadow : 1; // 0x2c4(0x01)
	char bCastContactShadow : 1; // 0x2c4(0x01)
	char bSelfShadowOnly : 1; // 0x2c4(0x01)
	char bCastFarShadow : 1; // 0x2c4(0x01)
	char bCastInsetShadow : 1; // 0x2c4(0x01)
	char bCastCinematicShadow : 1; // 0x2c4(0x01)
	char bCastHiddenShadow : 1; // 0x2c5(0x01)
	char bCastShadowAsTwoSided : 1; // 0x2c5(0x01)
	char bLightAsIfStatic : 1; // 0x2c5(0x01)
	char bLightAttachmentsAsGroup : 1; // 0x2c5(0x01)
	char bExcludeFromLightAttachmentGroup : 1; // 0x2c5(0x01)
	char bReceiveMobileCSMShadows : 1; // 0x2c5(0x01)
	char bSingleSampleShadowFromStationaryLights : 1; // 0x2c5(0x01)
	char bIgnoreRadialImpulse : 1; // 0x2c5(0x01)
	char bIgnoreRadialForce : 1; // 0x2c6(0x01)
	char bApplyImpulseOnDamage : 1; // 0x2c6(0x01)
	char bReplicatePhysicsToAutonomousProxy : 1; // 0x2c6(0x01)
	char bFillCollisionUnderneathForNavmesh : 1; // 0x2c6(0x01)
	char AlwaysLoadOnClient : 1; // 0x2c6(0x01)
	char AlwaysLoadOnServer : 1; // 0x2c6(0x01)
	char bUseEditorCompositing : 1; // 0x2c6(0x01)
	char bIsBeingMovedByEditor : 1; // 0x2c6(0x01)
	char bRenderCustomDepth : 1; // 0x2c7(0x01)
	char bVisibleInSceneCaptureOnly : 1; // 0x2c7(0x01)
	char bHiddenInSceneCapture : 1; // 0x2c7(0x01)
	char bRayTracingFarField : 1; // 0x2c7(0x01)
	char pad_557_4 : 1; // 0x557(0x01)
	char bHasNoStreamableTextures : 1; // 0x2c7(0x01)
	enum class EHasCustomNavigableGeometry bHasCustomNavigableGeometry; // 0x2c8(0x01)
	enum class ECanBeCharacterBase CanCharacterStepUpOn; // 0x2ca(0x01)
	struct FLightingChannels LightingChannels; // 0x2cb(0x01)
	int32_t RayTracingGroupId; // 0x2cc(0x04)
	int32_t VisibilityId; // 0x2d0(0x04)
	int32_t CustomDepthStencilValue; // 0x2d4(0x04)
	struct FCustomPrimitiveData CustomPrimitiveData; // 0x2d8(0x10)
	struct FCustomPrimitiveData CustomPrimitiveDataInternal; // 0x2e8(0x10)
	int32_t TranslucencySortPriority; // 0x300(0x04)
	float TranslucencySortDistanceOffset; // 0x304(0x04)
	struct TArray<struct URuntimeVirtualTexture*> RuntimeVirtualTextures; // 0x308(0x10)
	int8_t VirtualTextureLodBias; // 0x318(0x01)
	int8_t VirtualTextureCullMips; // 0x319(0x01)
	int8_t VirtualTextureMinCoverage; // 0x31a(0x01)
	enum class ERuntimeVirtualTextureMainPassType VirtualTextureRenderPassType; // 0x31b(0x01)
	float BoundsScale; // 0x32c(0x04)
	struct TArray<struct AActor*> MoveIgnoreActors; // 0x340(0x10)
	struct TArray<struct UPrimitiveComponent*> MoveIgnoreComponents; // 0x350(0x10)
	struct FBodyInstance BodyInstance; // 0x370(0x190)
	struct FMulticastSparseDelegate OnComponentHit; // 0x500(0x01)
	struct FMulticastSparseDelegate OnComponentBeginOverlap; // 0x501(0x01)
	struct FMulticastSparseDelegate OnComponentEndOverlap; // 0x502(0x01)
	struct FMulticastSparseDelegate OnComponentWake; // 0x503(0x01)
	struct FMulticastSparseDelegate OnComponentSleep; // 0x504(0x01)
	struct FMulticastSparseDelegate OnComponentPhysicsStateChanged; // 0x506(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x507(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x508(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x509(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x50a(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x50b(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x50c(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x50d(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x50e(0x01)
	enum class ERayTracingGroupCullingPriority RayTracingGroupCullingPriority; // 0x50f(0x01)
	enum class ERendererStencilMask CustomDepthStencilWriteMask; // 0x510(0x01)
	struct UPrimitiveComponent* LODParentPrimitive; // 0x530(0x08)
};

// Class Engine.DebugDrawService
// Size: 0x28 (Inherited: 0x28)
struct UDebugDrawService : UBlueprintFunctionLibrary {
};

// Class Engine.ReporterBase
// Size: 0x30 (Inherited: 0x28)
struct UReporterBase : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.ReporterGraph
// Size: 0xc8 (Inherited: 0x30)
struct UReporterGraph : UReporterBase {
	char pad_30[0x98]; // 0x30(0x98)
};

// Class Engine.DecalActor
// Size: 0x298 (Inherited: 0x290)
struct ADecalActor : AActor {
	struct UDecalComponent* Decal; // 0x290(0x08)

	void SetDecalMaterial(struct UMaterialInterface* NewDecalMaterial); // Function Engine.DecalActor.SetDecalMaterial // (None) // @ game+0xffffccbedf830041
};

// Class Engine.DefaultPhysicsVolume
// Size: 0x2d8 (Inherited: 0x2d8)
struct ADefaultPhysicsVolume : APhysicsVolume {
	float TerminalVelocity; // 0x2c8(0x04)
	int32_t Priority; // 0x2cc(0x04)
	float FluidFriction; // 0x2d0(0x04)
	char bWaterVolume : 1; // 0x2d4(0x01)
	char bPhysicsOnContact : 1; // 0x2d4(0x01)
};

// Class Engine.DemoNetDriver
// Size: 0x1430 (Inherited: 0x790)
struct UDemoNetDriver : UNetDriver {
	char pad_790[0x38]; // 0x790(0x38)
	struct TMap<struct FString, struct FRollbackNetStartupActorInfo> RollbackNetStartupActors; // 0x7c8(0x50)
	char pad_818[0xdc]; // 0x818(0xdc)
	float CheckpointSaveMaxMSPerFrame; // 0x8f4(0x04)
	char pad_8F8[0x18]; // 0x8f8(0x18)
	struct TArray<struct FMulticastRecordOptions> MulticastRecordOptions; // 0x910(0x10)
	struct TArray<struct APlayerController*> SpectatorControllers; // 0x920(0x10)
	char pad_930[0xb00]; // 0x930(0xb00)
};

// Class Engine.DestructibleInterface
// Size: 0x28 (Inherited: 0x28)
struct UDestructibleInterface : UInterface {
};

// Class Engine.TextureLODSettings
// Size: 0x38 (Inherited: 0x28)
struct UTextureLODSettings : UObject {
	struct TArray<struct FTextureLODGroup> TextureLODGroups; // 0x28(0x10)
};

// Class Engine.DeviceProfile
// Size: 0xd0 (Inherited: 0x38)
struct UDeviceProfile : UTextureLODSettings {
	struct FString DeviceType; // 0x38(0x10)
	struct FString BaseProfileName; // 0x48(0x10)
	char bIsVisibleForAssets : 1; // 0x58(0x01)
	char pad_58_1 : 7; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct UDeviceProfile* Parent; // 0x60(0x08)
	char pad_68[0x28]; // 0x68(0x28)
	struct TArray<struct FString> CVars; // 0x90(0x10)
	struct TArray<struct FDPMatchingRulestruct> MatchingRules; // 0xa0(0x10)
	char pad_B0[0x20]; // 0xb0(0x20)
};

// Class Engine.DeviceProfileManager
// Size: 0x90 (Inherited: 0x28)
struct UDeviceProfileManager : UObject {
	struct TArray<struct UDeviceProfile*> Profiles; // 0x28(0x10)
	struct TArray<struct UDeviceProfile*> BackupProfiles; // 0x38(0x10)
	char pad_48[0x48]; // 0x48(0x48)
};

// Class Engine.DialogueVoice
// Size: 0x40 (Inherited: 0x28)
struct UDialogueVoice : UObject {
	enum class EGrammaticalGender Gender; // 0x28(0x01)
	enum class EGrammaticalNumber Plurality; // 0x29(0x01)
	char pad_2A[0x2]; // 0x2a(0x02)
	struct FGuid LocalizationGUID; // 0x2c(0x10)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class Engine.DialogueWave
// Size: 0x70 (Inherited: 0x28)
struct UDialogueWave : UObject {
	char bMature : 1; // 0x28(0x01)
	char bOverride_SubtitleOverride : 1; // 0x28(0x01)
	char pad_28_2 : 6; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FString SpokenText; // 0x30(0x10)
	struct FString SubtitleOverride; // 0x40(0x10)
	struct TArray<struct FDialogueContextMapping> ContextMappings; // 0x50(0x10)
	struct FGuid LocalizationGUID; // 0x60(0x10)
};

// Class Engine.DocumentationActor
// Size: 0x298 (Inherited: 0x290)
struct ADocumentationActor : AActor {
	struct FActorTickFunction PrimaryActorTick; // 0x28(0x30)
	char bNetTemporary : 1; // 0x58(0x01)
	char pad_2C0_1 : 1; // 0x2c0(0x01)
	char bOnlyRelevantToOwner : 1; // 0x58(0x01)
	char bAlwaysRelevant : 1; // 0x58(0x01)
	char bReplicateMovement : 1; // 0x58(0x01)
	char bCallPreReplication : 1; // 0x58(0x01)
	char bCallPreReplicationForReplay : 1; // 0x58(0x01)
	char bHidden : 1; // 0x58(0x01)
	char bTearOff : 1; // 0x59(0x01)
	char bForceNetAddressable : 1; // 0x59(0x01)
	char bExchangedRoles : 1; // 0x59(0x01)
	char bNetLoadOnClient : 1; // 0x59(0x01)
	char bNetUseOwnerRelevancy : 1; // 0x59(0x01)
	char bRelevantForNetworkReplays : 1; // 0x59(0x01)
	char bRelevantForLevelBounds : 1; // 0x59(0x01)
	char bReplayRewindable : 1; // 0x59(0x01)
	char bAllowTickBeforeBeginPlay : 1; // 0x5a(0x01)
	char bAutoDestroyWhenFinished : 1; // 0x5a(0x01)
	char bCanBeDamaged : 1; // 0x5a(0x01)
	char bBlockInput : 1; // 0x5a(0x01)
	char bCollideWhenPlacing : 1; // 0x5a(0x01)
	char bFindCameraComponentWhenViewTarget : 1; // 0x5a(0x01)
	char bGenerateOverlapEventsDuringLevelStreaming : 1; // 0x5a(0x01)
	char bIgnoresOriginShifting : 1; // 0x5a(0x01)
	char bEnableAutoLODGeneration : 1; // 0x5b(0x01)
	char bIsEditorOnlyActor : 1; // 0x5b(0x01)
	char bActorSeamlessTraveled : 1; // 0x5b(0x01)
	char bReplicates : 1; // 0x5b(0x01)
	char bCanBeInCluster : 1; // 0x5b(0x01)
	char bAllowReceiveTickEventOnDedicatedServer : 1; // 0x5b(0x01)
	char pad_2C3_6 : 1; // 0x2c3(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x5b(0x01)
	char pad_2C4_0 : 7; // 0x2c4(0x01)
	char bActorEnableCollision : 1; // 0x5c(0x01)
	char bActorIsBeingDestroyed : 1; // 0x5d(0x01)
	char pad_2C5_1 : 4; // 0x2c5(0x01)
	char bAsyncPhysicsTickEnabled : 1; // 0x5d(0x01)
	enum class EActorUpdateOverlapsMethod UpdateOverlapsMethodDuringLevelStreaming; // 0x5e(0x01)
	enum class EActorUpdateOverlapsMethod DefaultUpdateOverlapsMethodDuringLevelStreaming; // 0x5f(0x01)
	float InitialLifeSpan; // 0x60(0x04)
	float CustomTimeDilation; // 0x64(0x04)
	enum class ENetRole RemoteRole; // 0x68(0x01)
	int32_t RayTracingGroupId; // 0x6c(0x04)
	struct FRepAttachment AttachmentReplication; // 0x70(0x60)
	struct FRepMovement ReplicatedMovement; // 0xd0(0x70)
	struct AActor* Owner; // 0x140(0x08)
	struct FName NetDriverName; // 0x148(0x08)
	enum class ENetRole Role; // 0x150(0x01)
	enum class ENetDormancy NetDormancy; // 0x151(0x01)
	enum class ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingMethod; // 0x152(0x01)
	enum class EAutoReceiveInput AutoReceiveInput; // 0x153(0x01)
	int32_t InputPriority; // 0x154(0x04)
	struct UInputComponent* InputComponent; // 0x160(0x08)
	float NetCullDistanceSquared; // 0x168(0x04)
	int32_t NetTag; // 0x16c(0x04)
	float NetUpdateFrequency; // 0x170(0x04)
	float MinNetUpdateFrequency; // 0x174(0x04)
	float NetPriority; // 0x178(0x04)
	struct APawn* Instigator; // 0x180(0x08)
	struct TArray<struct AActor*> Children; // 0x188(0x10)
	struct USceneComponent* RootComponent; // 0x198(0x08)
	struct TArray<struct FName> Layers; // 0x1a8(0x10)
	struct TWeakObjectPtr<struct UChildActorComponent> ParentComponent; // 0x1b8(0x08)
	struct TArray<struct FName> Tags; // 0x1c0(0x10)
	struct FMulticastSparseDelegate OnTakeAnyDamage; // 0x1d0(0x01)
	struct FMulticastSparseDelegate OnTakePointDamage; // 0x1d1(0x01)
	struct FMulticastSparseDelegate OnTakeRadialDamage; // 0x1d2(0x01)
	struct FMulticastSparseDelegate OnActorBeginOverlap; // 0x1d3(0x01)
	struct FMulticastSparseDelegate OnActorEndOverlap; // 0x1d4(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x1d5(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x1d6(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x1d7(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x1d8(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x1d9(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x1da(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x1db(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x1dc(0x01)
	struct FMulticastSparseDelegate OnActorHit; // 0x1dd(0x01)
	struct FMulticastSparseDelegate OnDestroyed; // 0x1de(0x01)
	struct FMulticastSparseDelegate OnEndPlay; // 0x1df(0x01)
	struct TArray<struct UActorComponent*> InstanceComponents; // 0x260(0x10)
	struct TArray<struct UActorComponent*> BlueprintCreatedComponents; // 0x270(0x10)
};

// Class Engine.DPICustomScalingRule
// Size: 0x28 (Inherited: 0x28)
struct UDPICustomScalingRule : UObject {
};

// Class Engine.EdGraphNode_Documentation
// Size: 0xb8 (Inherited: 0x98)
struct UEdGraphNode_Documentation : UEdGraphNode {
	struct FString Link; // 0x98(0x10)
	struct FString Excerpt; // 0xa8(0x10)
};

// Class Engine.ThumbnailInfo
// Size: 0x28 (Inherited: 0x28)
struct UThumbnailInfo : UObject {
};

// Class Engine.ActorElementAssetDataInterface
// Size: 0x30 (Inherited: 0x28)
struct UActorElementAssetDataInterface : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.ActorElementCounterInterface
// Size: 0x30 (Inherited: 0x28)
struct UActorElementCounterInterface : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.ActorElementHierarchyInterface
// Size: 0x30 (Inherited: 0x28)
struct UActorElementHierarchyInterface : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.ActorElementObjectInterface
// Size: 0x30 (Inherited: 0x28)
struct UActorElementObjectInterface : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.ActorElementSelectionInterface
// Size: 0x30 (Inherited: 0x28)
struct UActorElementSelectionInterface : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.ActorElementWorldInterface
// Size: 0x30 (Inherited: 0x28)
struct UActorElementWorldInterface : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.ComponentElementCounterInterface
// Size: 0x30 (Inherited: 0x28)
struct UComponentElementCounterInterface : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.ComponentElementHierarchyInterface
// Size: 0x30 (Inherited: 0x28)
struct UComponentElementHierarchyInterface : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.ComponentElementObjectInterface
// Size: 0x30 (Inherited: 0x28)
struct UComponentElementObjectInterface : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.ComponentElementSelectionInterface
// Size: 0x30 (Inherited: 0x28)
struct UComponentElementSelectionInterface : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.ComponentElementWorldInterface
// Size: 0x30 (Inherited: 0x28)
struct UComponentElementWorldInterface : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.EngineElementsLibrary
// Size: 0x28 (Inherited: 0x28)
struct UEngineElementsLibrary : UBlueprintFunctionLibrary {
};

// Class Engine.TypedElementCommonActions
// Size: 0x828 (Inherited: 0x28)
struct UTypedElementCommonActions : UObject {
	char pad_28[0x800]; // 0x28(0x800)

	struct TArray<struct FScriptTypedElementHandle> K2_DuplicateSelectedElements(struct UTypedElementSelectionSet* SelectionSet, struct UWorld* World, struct FVector& LocationOffset); // Function Engine.TypedElementCommonActions.K2_DuplicateSelectedElements // (None) // @ game+0xffffccc2df830041
};

// Class Engine.TypedElementWorldInterface
// Size: 0x28 (Inherited: 0x28)
struct UTypedElementWorldInterface : UInterface {

	bool SetWorldTransform(struct FScriptTypedElementHandle& InElementHandle, struct FTransform& InTransform); // Function Engine.TypedElementWorldInterface.SetWorldTransform // (None) // @ game+0xffffccd7df830041
};

// Class Engine.ObjectElementAssetDataInterface
// Size: 0x30 (Inherited: 0x28)
struct UObjectElementAssetDataInterface : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.ObjectElementCounterInterface
// Size: 0x30 (Inherited: 0x28)
struct UObjectElementCounterInterface : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.ObjectElementObjectInterface
// Size: 0x30 (Inherited: 0x28)
struct UObjectElementObjectInterface : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.ObjectElementSelectionInterface
// Size: 0x30 (Inherited: 0x28)
struct UObjectElementSelectionInterface : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.SMInstanceElementAssetDataInterface
// Size: 0x30 (Inherited: 0x28)
struct USMInstanceElementAssetDataInterface : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.SMInstanceElementHierarchyInterface
// Size: 0x30 (Inherited: 0x28)
struct USMInstanceElementHierarchyInterface : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.SMInstanceElementIdMapTransactor
// Size: 0x28 (Inherited: 0x28)
struct USMInstanceElementIdMapTransactor : UObject {
};

// Class Engine.SMInstanceElementSelectionInterface
// Size: 0x30 (Inherited: 0x28)
struct USMInstanceElementSelectionInterface : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.SMInstanceElementWorldInterface
// Size: 0x30 (Inherited: 0x28)
struct USMInstanceElementWorldInterface : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.LocalMessage
// Size: 0x28 (Inherited: 0x28)
struct ULocalMessage : UObject {
};

// Class Engine.EngineMessage
// Size: 0xa8 (Inherited: 0x28)
struct UEngineMessage : ULocalMessage {
	struct FString FailedPlaceMessage; // 0x28(0x10)
	struct FString MaxedOutMessage; // 0x38(0x10)
	struct FString EnteredMessage; // 0x48(0x10)
	struct FString LeftMessage; // 0x58(0x10)
	struct FString GlobalNameChange; // 0x68(0x10)
	struct FString SpecEnteredMessage; // 0x78(0x10)
	struct FString NewPlayerMessage; // 0x88(0x10)
	struct FString NewSpecMessage; // 0x98(0x10)
};

// Class Engine.AutoDestroySubsystem
// Size: 0x50 (Inherited: 0x40)
struct UAutoDestroySubsystem : UTickableWorldSubsystem {
	struct TArray<struct AActor*> ActorsToPoll; // 0x40(0x10)

	void OnActorEndPlay(struct AActor* Actor, enum class EEndPlayReason EndPlayReason); // Function Engine.AutoDestroySubsystem.OnActorEndPlay // (None) // @ game+0xffffccd8df830041
};

// Class Engine.LODSyncInterface
// Size: 0x28 (Inherited: 0x28)
struct ULODSyncInterface : UInterface {
};

// Class Engine.PoseWatchFolder
// Size: 0x28 (Inherited: 0x28)
struct UPoseWatchFolder : UObject {
};

// Class Engine.PoseWatchElement
// Size: 0x28 (Inherited: 0x28)
struct UPoseWatchElement : UObject {
};

// Class Engine.PoseWatchPoseElement
// Size: 0x28 (Inherited: 0x28)
struct UPoseWatchPoseElement : UPoseWatchElement {
};

// Class Engine.PoseWatch
// Size: 0x28 (Inherited: 0x28)
struct UPoseWatch : UObject {
};

// Class Engine.ServerStatReplicator
// Size: 0x358 (Inherited: 0x290)
struct AServerStatReplicator : AInfo {
	bool bUpdateStatNet; // 0x290(0x01)
	bool bOverwriteClientStats; // 0x291(0x01)
	char pad_292[0x2]; // 0x292(0x02)
	uint32_t Channels; // 0x294(0x04)
	uint32_t InRate; // 0x298(0x04)
	uint32_t OutRate; // 0x29c(0x04)
	char pad_2A0[0x4]; // 0x2a0(0x04)
	uint32_t MaxPacketOverhead; // 0x2a4(0x04)
	uint32_t InRateClientMax; // 0x2a8(0x04)
	uint32_t InRateClientMin; // 0x2ac(0x04)
	uint32_t InRateClientAvg; // 0x2b0(0x04)
	uint32_t InPacketsClientMax; // 0x2b4(0x04)
	uint32_t InPacketsClientMin; // 0x2b8(0x04)
	uint32_t InPacketsClientAvg; // 0x2bc(0x04)
	uint32_t OutRateClientMax; // 0x2c0(0x04)
	uint32_t OutRateClientMin; // 0x2c4(0x04)
	uint32_t OutRateClientAvg; // 0x2c8(0x04)
	uint32_t OutPacketsClientMax; // 0x2cc(0x04)
	uint32_t OutPacketsClientMin; // 0x2d0(0x04)
	uint32_t OutPacketsClientAvg; // 0x2d4(0x04)
	uint32_t NetNumClients; // 0x2d8(0x04)
	uint32_t InPackets; // 0x2dc(0x04)
	uint32_t OutPackets; // 0x2e0(0x04)
	uint32_t InBunches; // 0x2e4(0x04)
	uint32_t OutBunches; // 0x2e8(0x04)
	uint32_t OutLoss; // 0x2ec(0x04)
	uint32_t InLoss; // 0x2f0(0x04)
	uint32_t VoiceBytesSent; // 0x2f4(0x04)
	uint32_t VoiceBytesRecv; // 0x2f8(0x04)
	uint32_t VoicePacketsSent; // 0x2fc(0x04)
	uint32_t VoicePacketsRecv; // 0x300(0x04)
	uint32_t PercentInVoice; // 0x304(0x04)
	uint32_t PercentOutVoice; // 0x308(0x04)
	uint32_t NumActorChannels; // 0x30c(0x04)
	uint32_t NumConsideredActors; // 0x310(0x04)
	uint32_t PrioritizedActors; // 0x314(0x04)
	uint32_t NumRelevantActors; // 0x318(0x04)
	uint32_t NumRelevantDeletedActors; // 0x31c(0x04)
	uint32_t NumReplicatedActorAttempts; // 0x320(0x04)
	uint32_t NumReplicatedActors; // 0x324(0x04)
	uint32_t NumActors; // 0x328(0x04)
	uint32_t NumNetActors; // 0x32c(0x04)
	uint32_t NumDormantActors; // 0x330(0x04)
	uint32_t NumInitiallyDormantActors; // 0x334(0x04)
	uint32_t NumNetGUIDsAckd; // 0x338(0x04)
	uint32_t NumNetGUIDsPending; // 0x33c(0x04)
	uint32_t NumNetGUIDsUnAckd; // 0x340(0x04)
	uint32_t ObjPathBytes; // 0x344(0x04)
	uint32_t NetGUIDOutRate; // 0x348(0x04)
	uint32_t NetGUIDInRate; // 0x34c(0x04)
	uint32_t NetSaturated; // 0x350(0x04)
	char pad_354[0x4]; // 0x354(0x04)
};

// Class Engine.SystemTimeTimecodeProvider
// Size: 0x40 (Inherited: 0x30)
struct USystemTimeTimecodeProvider : UTimecodeProvider {
	struct FFrameRate FrameRate; // 0x30(0x08)
	bool bGenerateFullFrame; // 0x38(0x01)
	bool bUseHighPerformanceClock; // 0x39(0x01)
	char pad_3A[0x6]; // 0x3a(0x06)
};

// Class Engine.ViewportStatsSubsystem
// Size: 0x50 (Inherited: 0x30)
struct UViewportStatsSubsystem : UWorldSubsystem {
	char pad_30[0x20]; // 0x30(0x20)

	void RemoveDisplayDelegate(int32_t IndexToRemove); // Function Engine.ViewportStatsSubsystem.RemoveDisplayDelegate // (None) // @ game+0xffffccdbdf830041
};

// Class Engine.FloatingPawnMovement
// Size: 0x170 (Inherited: 0x158)
struct UFloatingPawnMovement : UPawnMovementComponent {
	float MaxSpeed; // 0x158(0x04)
	float Acceleration; // 0x15c(0x04)
	float Deceleration; // 0x160(0x04)
	float TurningBoost; // 0x164(0x04)
	char bPositionCorrected : 1; // 0x168(0x01)
	char pad_168_1 : 7; // 0x168(0x01)
	char pad_169[0x7]; // 0x169(0x07)
};

// Class Engine.Font
// Size: 0x1d0 (Inherited: 0x28)
struct UFont : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	enum class EFontCacheType FontCacheType; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct TArray<struct FFontCharacter> Characters; // 0x38(0x10)
	struct TArray<struct UTexture2D*> Textures; // 0x48(0x10)
	int32_t IsRemapped; // 0x58(0x04)
	float EmScale; // 0x5c(0x04)
	float Ascent; // 0x60(0x04)
	float Descent; // 0x64(0x04)
	float Leading; // 0x68(0x04)
	int32_t Kerning; // 0x6c(0x04)
	struct FFontImportOptionsData ImportOptions; // 0x70(0xb0)
	int32_t NumCharacters; // 0x120(0x04)
	char pad_124[0x4]; // 0x124(0x04)
	struct TArray<int32_t> MaxCharHeight; // 0x128(0x10)
	float ScalingFactor; // 0x138(0x04)
	int32_t LegacyFontSize; // 0x13c(0x04)
	struct FName LegacyFontName; // 0x140(0x08)
	struct FCompositeFont CompositeFont; // 0x148(0x38)
	char pad_180[0x50]; // 0x180(0x50)
};

// Class Engine.FontFace
// Size: 0x58 (Inherited: 0x28)
struct UFontFace : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FString SourceFilename; // 0x30(0x10)
	enum class EFontHinting Hinting; // 0x40(0x01)
	enum class EFontLoadingPolicy LoadingPolicy; // 0x41(0x01)
	enum class EFontLayoutMethod LayoutMethod; // 0x42(0x01)
	char pad_43[0x15]; // 0x43(0x15)
};

// Class Engine.GameEngine
// Size: 0x10a8 (Inherited: 0x1050)
struct UGameEngine : UEngine {
	float MaxDeltaTime; // 0x1050(0x04)
	float ServerFlushLogInterval; // 0x1054(0x04)
	struct UGameInstance* GameInstance; // 0x1058(0x08)
	char pad_1060[0x48]; // 0x1060(0x48)
};

// Class Engine.AsyncActionHandleSaveGame
// Size: 0x68 (Inherited: 0x30)
struct UAsyncActionHandleSaveGame : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Completed; // 0x30(0x10)
	char pad_40[0x20]; // 0x40(0x20)
	struct USaveGame* SaveGameObject; // 0x60(0x08)

	struct UAsyncActionHandleSaveGame* AsyncSaveGameToSlot(struct UObject* WorldContextObject, struct USaveGame* SaveGameObject, struct FString SlotName, int32_t UserIndex); // Function Engine.AsyncActionHandleSaveGame.AsyncSaveGameToSlot // (None) // @ game+0xffffccdddf830041
};

// Class Engine.ForceFeedbackEffect
// Size: 0x40 (Inherited: 0x28)
struct UForceFeedbackEffect : UObject {
	struct TArray<struct FForceFeedbackChannelDetails> ChannelDetails; // 0x28(0x10)
	float Duration; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class Engine.SaveGame
// Size: 0x28 (Inherited: 0x28)
struct USaveGame : UObject {
};

// Class Engine.SpringArmComponent
// Size: 0x3a0 (Inherited: 0x2a0)
struct USpringArmComponent : USceneComponent {
	float TargetArmLength; // 0x2a0(0x04)
	char pad_2A4[0x4]; // 0x2a4(0x04)
	struct FVector SocketOffset; // 0x2a8(0x18)
	struct FVector TargetOffset; // 0x2c0(0x18)
	float ProbeSize; // 0x2d8(0x04)
	enum class ECollisionChannel ProbeChannel; // 0x2dc(0x01)
	char pad_2DD[0x3]; // 0x2dd(0x03)
	char bDoCollisionTest : 1; // 0x2e0(0x01)
	char bUsePawnControlRotation : 1; // 0x2e0(0x01)
	char bInheritPitch : 1; // 0x2e0(0x01)
	char bInheritYaw : 1; // 0x2e0(0x01)
	char bInheritRoll : 1; // 0x2e0(0x01)
	char bEnableCameraLag : 1; // 0x2e0(0x01)
	char bEnableCameraRotationLag : 1; // 0x2e0(0x01)
	char bUseCameraLagSubstepping : 1; // 0x2e0(0x01)
	char bDrawDebugLagMarkers : 1; // 0x2e1(0x01)
	char pad_2E1_1 : 7; // 0x2e1(0x01)
	char pad_2E2[0x2]; // 0x2e2(0x02)
	float CameraLagSpeed; // 0x2e4(0x04)
	float CameraRotationLagSpeed; // 0x2e8(0x04)
	float CameraLagMaxTimeStep; // 0x2ec(0x04)
	float CameraLagMaxDistance; // 0x2f0(0x04)
	char bClampToMaxPhysicsDeltaTime : 1; // 0x2f4(0x01)
	char pad_2F4_1 : 7; // 0x2f4(0x01)
	char pad_2F5[0xab]; // 0x2f5(0xab)

	bool IsCollisionFixApplied(); // Function Engine.SpringArmComponent.IsCollisionFixApplied // (None) // @ game+0xffffcce0df830041
};

// Class Engine.TouchInterface
// Size: 0x58 (Inherited: 0x28)
struct UTouchInterface : UObject {
	struct TArray<struct FTouchInputControl> Controls; // 0x28(0x10)
	float ActiveOpacity; // 0x38(0x04)
	float InactiveOpacity; // 0x3c(0x04)
	float TimeUntilDeactive; // 0x40(0x04)
	float TimeUntilReset; // 0x44(0x04)
	float ActivationDelay; // 0x48(0x04)
	bool bPreventRecenter; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	float StartupDelay; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// Class Engine.GameplayStatics
// Size: 0x28 (Inherited: 0x28)
struct UGameplayStatics : UBlueprintFunctionLibrary {

	void UnRetainAllSoundsInSoundClass(struct USoundClass* InSoundClass); // Function Engine.GameplayStatics.UnRetainAllSoundsInSoundClass // (None) // @ game+0xffffcd69df830041
};

// Class Engine.HLODProxy
// Size: 0x88 (Inherited: 0x28)
struct UHLODProxy : UObject {
	struct TArray<struct FHLODProxyMesh> ProxyMeshes; // 0x28(0x10)
	struct TMap<struct UHLODProxyDesc*, struct FHLODProxyMesh> HLODActors; // 0x38(0x50)
};

// Class Engine.HLODEngineSubsystem
// Size: 0x30 (Inherited: 0x30)
struct UHLODEngineSubsystem : UEngineSubsystem {
};

// Class Engine.HLODProxyDesc
// Size: 0x28 (Inherited: 0x28)
struct UHLODProxyDesc : UObject {
};

// Class Engine.ImportantToggleSettingInterface
// Size: 0x28 (Inherited: 0x28)
struct UImportantToggleSettingInterface : UInterface {
};

// Class Engine.InheritableComponentHandler
// Size: 0x48 (Inherited: 0x28)
struct UInheritableComponentHandler : UObject {
	struct TArray<struct FComponentOverrideRecord> Records; // 0x28(0x10)
	struct TArray<struct UActorComponent*> UnnecessaryComponents; // 0x38(0x10)
};

// Class Engine.InputActionDelegateBinding
// Size: 0x38 (Inherited: 0x28)
struct UInputActionDelegateBinding : UInputDelegateBinding {
	struct TArray<struct FBlueprintInputActionDelegateBinding> InputActionDelegateBindings; // 0x28(0x10)
};

// Class Engine.InputAxisDelegateBinding
// Size: 0x38 (Inherited: 0x28)
struct UInputAxisDelegateBinding : UInputDelegateBinding {
	struct TArray<struct FBlueprintInputAxisDelegateBinding> InputAxisDelegateBindings; // 0x28(0x10)
};

// Class Engine.InputAxisKeyDelegateBinding
// Size: 0x38 (Inherited: 0x28)
struct UInputAxisKeyDelegateBinding : UInputDelegateBinding {
	struct TArray<struct FBlueprintInputAxisKeyDelegateBinding> InputAxisKeyDelegateBindings; // 0x28(0x10)
};

// Class Engine.InputKeyDelegateBinding
// Size: 0x38 (Inherited: 0x28)
struct UInputKeyDelegateBinding : UInputDelegateBinding {
	struct TArray<struct FBlueprintInputKeyDelegateBinding> InputKeyDelegateBindings; // 0x28(0x10)
};

// Class Engine.InputTouchDelegateBinding
// Size: 0x38 (Inherited: 0x28)
struct UInputTouchDelegateBinding : UInputDelegateBinding {
	struct TArray<struct FBlueprintInputTouchDelegateBinding> InputTouchDelegateBindings; // 0x28(0x10)
};

// Class Engine.InputVectorAxisDelegateBinding
// Size: 0x38 (Inherited: 0x38)
struct UInputVectorAxisDelegateBinding : UInputAxisKeyDelegateBinding {
	struct TArray<struct FBlueprintInputAxisKeyDelegateBinding> InputAxisKeyDelegateBindings; // 0x28(0x10)
};

// Class Engine.InstancedPlacemenClientSettings
// Size: 0x28 (Inherited: 0x28)
struct UInstancedPlacemenClientSettings : UObject {
};

// Class Engine.InstancedPlacementPartitionActor
// Size: 0x2a0 (Inherited: 0x2a0)
struct AInstancedPlacementPartitionActor : AISMPartitionActor {
	struct FActorTickFunction PrimaryActorTick; // 0x28(0x30)
	char bNetTemporary : 1; // 0x58(0x01)
	char pad_2D0_1 : 1; // 0x2d0(0x01)
	char bOnlyRelevantToOwner : 1; // 0x58(0x01)
	char bAlwaysRelevant : 1; // 0x58(0x01)
	char bReplicateMovement : 1; // 0x58(0x01)
	char bCallPreReplication : 1; // 0x58(0x01)
	char bCallPreReplicationForReplay : 1; // 0x58(0x01)
	char bHidden : 1; // 0x58(0x01)
	char bTearOff : 1; // 0x59(0x01)
	char bForceNetAddressable : 1; // 0x59(0x01)
	char bExchangedRoles : 1; // 0x59(0x01)
	char bNetLoadOnClient : 1; // 0x59(0x01)
	char bNetUseOwnerRelevancy : 1; // 0x59(0x01)
	char bRelevantForNetworkReplays : 1; // 0x59(0x01)
	char bRelevantForLevelBounds : 1; // 0x59(0x01)
	char bReplayRewindable : 1; // 0x59(0x01)
	char bAllowTickBeforeBeginPlay : 1; // 0x5a(0x01)
	char bAutoDestroyWhenFinished : 1; // 0x5a(0x01)
	char bCanBeDamaged : 1; // 0x5a(0x01)
	char bBlockInput : 1; // 0x5a(0x01)
	char bCollideWhenPlacing : 1; // 0x5a(0x01)
	char bFindCameraComponentWhenViewTarget : 1; // 0x5a(0x01)
	char bGenerateOverlapEventsDuringLevelStreaming : 1; // 0x5a(0x01)
	char bIgnoresOriginShifting : 1; // 0x5a(0x01)
	char bEnableAutoLODGeneration : 1; // 0x5b(0x01)
	char bIsEditorOnlyActor : 1; // 0x5b(0x01)
	char bActorSeamlessTraveled : 1; // 0x5b(0x01)
	char bReplicates : 1; // 0x5b(0x01)
	char bCanBeInCluster : 1; // 0x5b(0x01)
	char bAllowReceiveTickEventOnDedicatedServer : 1; // 0x5b(0x01)
	char pad_2D3_6 : 1; // 0x2d3(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x5b(0x01)
	char pad_2D4_0 : 7; // 0x2d4(0x01)
	char bActorEnableCollision : 1; // 0x5c(0x01)
	char bActorIsBeingDestroyed : 1; // 0x5d(0x01)
	char pad_2D5_1 : 4; // 0x2d5(0x01)
	char bAsyncPhysicsTickEnabled : 1; // 0x5d(0x01)
	enum class EActorUpdateOverlapsMethod UpdateOverlapsMethodDuringLevelStreaming; // 0x5e(0x01)
	enum class EActorUpdateOverlapsMethod DefaultUpdateOverlapsMethodDuringLevelStreaming; // 0x5f(0x01)
	float InitialLifeSpan; // 0x60(0x04)
	float CustomTimeDilation; // 0x64(0x04)
	enum class ENetRole RemoteRole; // 0x68(0x01)
	int32_t RayTracingGroupId; // 0x6c(0x04)
	struct FRepAttachment AttachmentReplication; // 0x70(0x60)
	struct FRepMovement ReplicatedMovement; // 0xd0(0x70)
	struct AActor* Owner; // 0x140(0x08)
	struct FName NetDriverName; // 0x148(0x08)
	enum class ENetRole Role; // 0x150(0x01)
	enum class ENetDormancy NetDormancy; // 0x151(0x01)
	enum class ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingMethod; // 0x152(0x01)
	enum class EAutoReceiveInput AutoReceiveInput; // 0x153(0x01)
	int32_t InputPriority; // 0x154(0x04)
	struct UInputComponent* InputComponent; // 0x160(0x08)
	float NetCullDistanceSquared; // 0x168(0x04)
	int32_t NetTag; // 0x16c(0x04)
	float NetUpdateFrequency; // 0x170(0x04)
	float MinNetUpdateFrequency; // 0x174(0x04)
	float NetPriority; // 0x178(0x04)
	struct APawn* Instigator; // 0x180(0x08)
	struct TArray<struct AActor*> Children; // 0x188(0x10)
	struct USceneComponent* RootComponent; // 0x198(0x08)
	struct TArray<struct FName> Layers; // 0x1a8(0x10)
	struct TWeakObjectPtr<struct UChildActorComponent> ParentComponent; // 0x1b8(0x08)
	struct TArray<struct FName> Tags; // 0x1c0(0x10)
	struct FMulticastSparseDelegate OnTakeAnyDamage; // 0x1d0(0x01)
	struct FMulticastSparseDelegate OnTakePointDamage; // 0x1d1(0x01)
	struct FMulticastSparseDelegate OnTakeRadialDamage; // 0x1d2(0x01)
	struct FMulticastSparseDelegate OnActorBeginOverlap; // 0x1d3(0x01)
	struct FMulticastSparseDelegate OnActorEndOverlap; // 0x1d4(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x1d5(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x1d6(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x1d7(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x1d8(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x1d9(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x1da(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x1db(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x1dc(0x01)
	struct FMulticastSparseDelegate OnActorHit; // 0x1dd(0x01)
	struct FMulticastSparseDelegate OnDestroyed; // 0x1de(0x01)
	struct FMulticastSparseDelegate OnEndPlay; // 0x1df(0x01)
	struct TArray<struct UActorComponent*> InstanceComponents; // 0x260(0x10)
	struct TArray<struct UActorComponent*> BlueprintCreatedComponents; // 0x270(0x10)
};

// Class Engine.StringTable
// Size: 0x40 (Inherited: 0x28)
struct UStringTable : UObject {
	char pad_28[0x18]; // 0x28(0x18)
};

// Class Engine.InterpCurveEdSetup
// Size: 0x40 (Inherited: 0x28)
struct UInterpCurveEdSetup : UObject {
	struct TArray<struct FCurveEdTab> Tabs; // 0x28(0x10)
	int32_t ActiveTab; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class Engine.IntSerialization
// Size: 0x50 (Inherited: 0x28)
struct UIntSerialization : UObject {
	uint16_t UnsignedInt16Variable; // 0x28(0x02)
	char pad_2A[0x2]; // 0x2a(0x02)
	uint32_t UnsignedInt32Variable; // 0x2c(0x04)
	uint64_t UnsignedInt64Variable; // 0x30(0x08)
	int8_t SignedInt8Variable; // 0x38(0x01)
	char pad_39[0x1]; // 0x39(0x01)
	int16_t SignedInt16Variable; // 0x3a(0x02)
	char pad_3C[0x4]; // 0x3c(0x04)
	int64_t SignedInt64Variable; // 0x40(0x08)
	char UnsignedInt8Variable; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	int32_t SignedInt32Variable; // 0x4c(0x04)
};

// Class Engine.KillZVolume
// Size: 0x2d8 (Inherited: 0x2d8)
struct AKillZVolume : APhysicsVolume {
	float TerminalVelocity; // 0x2c8(0x04)
	int32_t Priority; // 0x2cc(0x04)
	float FluidFriction; // 0x2d0(0x04)
	char bWaterVolume : 1; // 0x2d4(0x01)
	char bPhysicsOnContact : 1; // 0x2d4(0x01)
};

// Class Engine.KismetArrayLibrary
// Size: 0x28 (Inherited: 0x28)
struct UKismetArrayLibrary : UBlueprintFunctionLibrary {

	void SetArrayPropertyByName(struct UObject* Object, struct FName PropertyName, struct TArray<int32_t>& Value); // Function Engine.KismetArrayLibrary.SetArrayPropertyByName // (None) // @ game+0xffffcd82df830041
};

// Class Engine.KismetGuidLibrary
// Size: 0x28 (Inherited: 0x28)
struct UKismetGuidLibrary : UBlueprintFunctionLibrary {

	void Parse_StringToGuid(struct FString GuidString, struct FGuid& OutGuid, bool& Success); // Function Engine.KismetGuidLibrary.Parse_StringToGuid // (None) // @ game+0xffffcd89df830041
};

// Class Engine.KismetInputLibrary
// Size: 0x28 (Inherited: 0x28)
struct UKismetInputLibrary : UBlueprintFunctionLibrary {

	bool PointerEvent_IsTouchEvent(struct FPointerEvent& Input); // Function Engine.KismetInputLibrary.PointerEvent_IsTouchEvent // (None) // @ game+0xffffcdbfdf830041
};

// Class Engine.KismetInternationalizationLibrary
// Size: 0x28 (Inherited: 0x28)
struct UKismetInternationalizationLibrary : UBlueprintFunctionLibrary {

	bool SetCurrentLocale(struct FString culture, bool SaveToConfig); // Function Engine.KismetInternationalizationLibrary.SetCurrentLocale // (None) // @ game+0xffffcdcddf830041
};

// Class Engine.KismetMaterialLibrary
// Size: 0x28 (Inherited: 0x28)
struct UKismetMaterialLibrary : UBlueprintFunctionLibrary {

	void SetVectorParameterValue(struct UObject* WorldContextObject, struct UMaterialParameterCollection* Collection, struct FName ParameterName, struct FLinearColor& ParameterValue); // Function Engine.KismetMaterialLibrary.SetVectorParameterValue // (None) // @ game+0xffffcdd2df830041
};

// Class Engine.KismetMathLibrary
// Size: 0x28 (Inherited: 0x28)
struct UKismetMathLibrary : UBlueprintFunctionLibrary {

	int32_t Xor_IntInt(int32_t A, int32_t B); // Function Engine.KismetMathLibrary.Xor_IntInt // (None) // @ game+0xffffd0d7df830041
};

// Class Engine.KismetNodeHelperLibrary
// Size: 0x28 (Inherited: 0x28)
struct UKismetNodeHelperLibrary : UBlueprintFunctionLibrary {

	void MarkBit(int32_t& Data, int32_t Index); // Function Engine.KismetNodeHelperLibrary.MarkBit // (None) // @ game+0xffffd0a7df830041
};

// Class Engine.KismetRenderingLibrary
// Size: 0x28 (Inherited: 0x28)
struct UKismetRenderingLibrary : UBlueprintFunctionLibrary {

	void SetCastInsetShadowForAllAttachments(struct UPrimitiveComponent* PrimitiveComponent, bool bCastInsetShadow, bool bLightAttachmentsAsGroup); // Function Engine.KismetRenderingLibrary.SetCastInsetShadowForAllAttachments // (None) // @ game+0xffffd0c2df830041
};

// Class Engine.KismetStringLibrary
// Size: 0x28 (Inherited: 0x28)
struct UKismetStringLibrary : UBlueprintFunctionLibrary {

	struct FString TrimTrailing(struct FString SourceString); // Function Engine.KismetStringLibrary.TrimTrailing // (None) // @ game+0xffffd10adf830041
};

// Class Engine.KismetStringTableLibrary
// Size: 0x28 (Inherited: 0x28)
struct UKismetStringTableLibrary : UBlueprintFunctionLibrary {

	bool IsRegisteredTableId(struct FName TableId); // Function Engine.KismetStringTableLibrary.IsRegisteredTableId // (None) // @ game+0xffffd112df830041
};

// Class Engine.KismetSystemLibrary
// Size: 0x28 (Inherited: 0x28)
struct UKismetSystemLibrary : UBlueprintFunctionLibrary {

	void UnregisterForRemoteNotifications(); // Function Engine.KismetSystemLibrary.UnregisterForRemoteNotifications // (None) // @ game+0xffff9274df830041
};

// Class Engine.BlueprintPathsLibrary
// Size: 0x28 (Inherited: 0x28)
struct UBlueprintPathsLibrary : UBlueprintFunctionLibrary {

	struct FString VideoCaptureDir(); // Function Engine.BlueprintPathsLibrary.VideoCaptureDir // (None) // @ game+0xffffd164df830041
};

// Class Engine.PlatformGameInstance
// Size: 0x290 (Inherited: 0x1c0)
struct UPlatformGameInstance : UGameInstance {
	struct FMulticastInlineDelegate ApplicationWillDeactivateDelegate; // 0x1c0(0x10)
	struct FMulticastInlineDelegate ApplicationHasReactivatedDelegate; // 0x1d0(0x10)
	struct FMulticastInlineDelegate ApplicationWillEnterBackgroundDelegate; // 0x1e0(0x10)
	struct FMulticastInlineDelegate ApplicationHasEnteredForegroundDelegate; // 0x1f0(0x10)
	struct FMulticastInlineDelegate ApplicationWillTerminateDelegate; // 0x200(0x10)
	struct FMulticastInlineDelegate ApplicationShouldUnloadResourcesDelegate; // 0x210(0x10)
	struct FMulticastInlineDelegate ApplicationReceivedStartupArgumentsDelegate; // 0x220(0x10)
	struct FMulticastInlineDelegate ApplicationRegisteredForRemoteNotificationsDelegate; // 0x230(0x10)
	struct FMulticastInlineDelegate ApplicationRegisteredForUserNotificationsDelegate; // 0x240(0x10)
	struct FMulticastInlineDelegate ApplicationFailedToRegisterForRemoteNotificationsDelegate; // 0x250(0x10)
	struct FMulticastInlineDelegate ApplicationReceivedRemoteNotificationDelegate; // 0x260(0x10)
	struct FMulticastInlineDelegate ApplicationReceivedLocalNotificationDelegate; // 0x270(0x10)
	struct FMulticastInlineDelegate ApplicationReceivedScreenOrientationChangedNotificationDelegate; // 0x280(0x10)
};

// Class Engine.BlueprintPlatformLibrary
// Size: 0x28 (Inherited: 0x28)
struct UBlueprintPlatformLibrary : UBlueprintFunctionLibrary {

	void SetAllowedDeviceOrientation(enum class EScreenOrientation NewAllowedDeviceOrientation); // Function Engine.BlueprintPlatformLibrary.SetAllowedDeviceOrientation // (None) // @ game+0xffffd16fdf830041
};

// Class Engine.BlueprintTypeConversions
// Size: 0x28 (Inherited: 0x28)
struct UBlueprintTypeConversions : UObject {

	struct TSet<int32_t> ConvertSetType(struct TSet<int32_t>& InSet); // Function Engine.BlueprintTypeConversions.ConvertSetType // (None) // @ game+0xffffd184df830041
};

// Class Engine.ImportanceSamplingLibrary
// Size: 0x28 (Inherited: 0x28)
struct UImportanceSamplingLibrary : UBlueprintFunctionLibrary {

	float RandomSobolFloat(int32_t Index, int32_t Dimension, float Seed); // Function Engine.ImportanceSamplingLibrary.RandomSobolFloat // (None) // @ game+0xffffd18ddf830041
};

// Class Engine.Layer
// Size: 0x48 (Inherited: 0x28)
struct ULayer : UObject {
	struct FName LayerName; // 0x28(0x08)
	char bIsVisible : 1; // 0x30(0x01)
	char pad_30_1 : 7; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct TArray<struct FLayerActorStats> ActorStats; // 0x38(0x10)
};

// Class Engine.LevelPartitionInterface
// Size: 0x28 (Inherited: 0x28)
struct ULevelPartitionInterface : UInterface {
};

// Class Engine.ActorContainer
// Size: 0x78 (Inherited: 0x28)
struct UActorContainer : UObject {
	struct TMap<struct FName, struct AActor*> Actors; // 0x28(0x50)
};

// Class Engine.LevelActorContainer
// Size: 0x38 (Inherited: 0x28)
struct ULevelActorContainer : UObject {
	struct TArray<struct AActor*> Actors; // 0x28(0x10)
};

// Class Engine.LevelBounds
// Size: 0x2a0 (Inherited: 0x290)
struct ALevelBounds : AActor {
	struct UBoxComponent* BoxComponent; // 0x290(0x08)
	bool bAutoUpdateBounds; // 0x298(0x01)
	char pad_299[0x7]; // 0x299(0x07)
};

// Class Engine.LevelInstance
// Size: 0x320 (Inherited: 0x290)
struct ALevelInstance : AActor {
	char pad_290[0x8]; // 0x290(0x08)
	struct TSoftObjectPtr<UWorld> CookedWorldAsset; // 0x298(0x30)
	struct FGuid LevelInstanceSpawnGuid; // 0x2c8(0x10)
	char pad_2D8[0x48]; // 0x2d8(0x48)

	void OnRep_LevelInstanceSpawnGuid(); // Function Engine.LevelInstance.OnRep_LevelInstanceSpawnGuid // (None) // @ game+0xffffd18edf830041
};

// Class Engine.LevelInstanceComponent
// Size: 0x2a0 (Inherited: 0x2a0)
struct ULevelInstanceComponent : USceneComponent {
	struct TWeakObjectPtr<struct APhysicsVolume> PhysicsVolume; // 0xa8(0x08)
	struct USceneComponent* AttachParent; // 0xb0(0x08)
	struct FName AttachSocketName; // 0xb8(0x08)
	struct TArray<struct USceneComponent*> AttachChildren; // 0xc0(0x10)
	struct TArray<struct USceneComponent*> ClientAttachedChildren; // 0xd0(0x10)
	struct FVector RelativeLocation; // 0x128(0x18)
	struct FRotator RelativeRotation; // 0x140(0x18)
	struct FVector RelativeScale3D; // 0x158(0x18)
	struct FVector ComponentVelocity; // 0x170(0x18)
	char bComponentToWorldUpdated : 1; // 0x188(0x01)
	char pad_338_1 : 1; // 0x338(0x01)
	char bAbsoluteLocation : 1; // 0x188(0x01)
	char bAbsoluteRotation : 1; // 0x188(0x01)
	char bAbsoluteScale : 1; // 0x188(0x01)
	char bVisible : 1; // 0x188(0x01)
	char bShouldBeAttached : 1; // 0x188(0x01)
	char bShouldSnapLocationWhenAttached : 1; // 0x188(0x01)
	char bShouldSnapRotationWhenAttached : 1; // 0x189(0x01)
	char bShouldSnapScaleWhenAttached : 1; // 0x189(0x01)
	char bShouldUpdatePhysicsVolume : 1; // 0x189(0x01)
	char bHiddenInGame : 1; // 0x189(0x01)
	char bBoundsChangeTriggersStreamingDataRebuild : 1; // 0x189(0x01)
	char bUseAttachParentBound : 1; // 0x189(0x01)
	char bComputeFastLocalBounds : 1; // 0x189(0x01)
	char bComputeBoundsOnceForGame : 1; // 0x189(0x01)
	char bComputedBoundsOnceForGame : 1; // 0x18a(0x01)
	char bIsNotRenderAttachmentRoot : 1; // 0x18a(0x01)
	enum class EComponentMobility Mobility; // 0x18b(0x01)
	enum class EDetailMode DetailMode; // 0x18c(0x01)
	struct FMulticastSparseDelegate PhysicsVolumeChangedDelegate; // 0x18d(0x01)
};

// Class Engine.LevelInstanceEditorInstanceActor
// Size: 0x290 (Inherited: 0x290)
struct ALevelInstanceEditorInstanceActor : AActor {
	struct FActorTickFunction PrimaryActorTick; // 0x28(0x30)
	char bNetTemporary : 1; // 0x58(0x01)
	char pad_2C0_1 : 1; // 0x2c0(0x01)
	char bOnlyRelevantToOwner : 1; // 0x58(0x01)
	char bAlwaysRelevant : 1; // 0x58(0x01)
	char bReplicateMovement : 1; // 0x58(0x01)
	char bCallPreReplication : 1; // 0x58(0x01)
	char bCallPreReplicationForReplay : 1; // 0x58(0x01)
	char bHidden : 1; // 0x58(0x01)
	char bTearOff : 1; // 0x59(0x01)
	char bForceNetAddressable : 1; // 0x59(0x01)
	char bExchangedRoles : 1; // 0x59(0x01)
	char bNetLoadOnClient : 1; // 0x59(0x01)
	char bNetUseOwnerRelevancy : 1; // 0x59(0x01)
	char bRelevantForNetworkReplays : 1; // 0x59(0x01)
	char bRelevantForLevelBounds : 1; // 0x59(0x01)
	char bReplayRewindable : 1; // 0x59(0x01)
	char bAllowTickBeforeBeginPlay : 1; // 0x5a(0x01)
	char bAutoDestroyWhenFinished : 1; // 0x5a(0x01)
	char bCanBeDamaged : 1; // 0x5a(0x01)
	char bBlockInput : 1; // 0x5a(0x01)
	char bCollideWhenPlacing : 1; // 0x5a(0x01)
	char bFindCameraComponentWhenViewTarget : 1; // 0x5a(0x01)
	char bGenerateOverlapEventsDuringLevelStreaming : 1; // 0x5a(0x01)
	char bIgnoresOriginShifting : 1; // 0x5a(0x01)
	char bEnableAutoLODGeneration : 1; // 0x5b(0x01)
	char bIsEditorOnlyActor : 1; // 0x5b(0x01)
	char bActorSeamlessTraveled : 1; // 0x5b(0x01)
	char bReplicates : 1; // 0x5b(0x01)
	char bCanBeInCluster : 1; // 0x5b(0x01)
	char bAllowReceiveTickEventOnDedicatedServer : 1; // 0x5b(0x01)
	char pad_2C3_6 : 1; // 0x2c3(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x5b(0x01)
	char pad_2C4_0 : 7; // 0x2c4(0x01)
	char bActorEnableCollision : 1; // 0x5c(0x01)
	char bActorIsBeingDestroyed : 1; // 0x5d(0x01)
	char pad_2C5_1 : 4; // 0x2c5(0x01)
	char bAsyncPhysicsTickEnabled : 1; // 0x5d(0x01)
	enum class EActorUpdateOverlapsMethod UpdateOverlapsMethodDuringLevelStreaming; // 0x5e(0x01)
	enum class EActorUpdateOverlapsMethod DefaultUpdateOverlapsMethodDuringLevelStreaming; // 0x5f(0x01)
	float InitialLifeSpan; // 0x60(0x04)
	float CustomTimeDilation; // 0x64(0x04)
	enum class ENetRole RemoteRole; // 0x68(0x01)
	int32_t RayTracingGroupId; // 0x6c(0x04)
	struct FRepAttachment AttachmentReplication; // 0x70(0x60)
	struct FRepMovement ReplicatedMovement; // 0xd0(0x70)
	struct AActor* Owner; // 0x140(0x08)
	struct FName NetDriverName; // 0x148(0x08)
	enum class ENetRole Role; // 0x150(0x01)
	enum class ENetDormancy NetDormancy; // 0x151(0x01)
	enum class ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingMethod; // 0x152(0x01)
	enum class EAutoReceiveInput AutoReceiveInput; // 0x153(0x01)
	int32_t InputPriority; // 0x154(0x04)
	struct UInputComponent* InputComponent; // 0x160(0x08)
	float NetCullDistanceSquared; // 0x168(0x04)
	int32_t NetTag; // 0x16c(0x04)
	float NetUpdateFrequency; // 0x170(0x04)
	float MinNetUpdateFrequency; // 0x174(0x04)
	float NetPriority; // 0x178(0x04)
	struct APawn* Instigator; // 0x180(0x08)
	struct TArray<struct AActor*> Children; // 0x188(0x10)
	struct USceneComponent* RootComponent; // 0x198(0x08)
	struct TArray<struct FName> Layers; // 0x1a8(0x10)
	struct TWeakObjectPtr<struct UChildActorComponent> ParentComponent; // 0x1b8(0x08)
	struct TArray<struct FName> Tags; // 0x1c0(0x10)
	struct FMulticastSparseDelegate OnTakeAnyDamage; // 0x1d0(0x01)
	struct FMulticastSparseDelegate OnTakePointDamage; // 0x1d1(0x01)
	struct FMulticastSparseDelegate OnTakeRadialDamage; // 0x1d2(0x01)
	struct FMulticastSparseDelegate OnActorBeginOverlap; // 0x1d3(0x01)
	struct FMulticastSparseDelegate OnActorEndOverlap; // 0x1d4(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x1d5(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x1d6(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x1d7(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x1d8(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x1d9(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x1da(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x1db(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x1dc(0x01)
	struct FMulticastSparseDelegate OnActorHit; // 0x1dd(0x01)
	struct FMulticastSparseDelegate OnDestroyed; // 0x1de(0x01)
	struct FMulticastSparseDelegate OnEndPlay; // 0x1df(0x01)
	struct TArray<struct UActorComponent*> InstanceComponents; // 0x260(0x10)
	struct TArray<struct UActorComponent*> BlueprintCreatedComponents; // 0x270(0x10)
};

// Class Engine.LevelStreamingLevelInstanceEditor
// Size: 0x1b0 (Inherited: 0x1b0)
struct ULevelStreamingLevelInstanceEditor : ULevelStreamingAlwaysLoaded {
	struct TSoftObjectPtr<UWorld> WorldAsset; // 0x28(0x30)
	int32_t StreamingPriority; // 0x58(0x04)
	struct FName PackageNameToLoad; // 0x5c(0x08)
	struct TArray<struct FName> LODPackageNames; // 0x68(0x10)
	struct FTransform LevelTransform; // 0x90(0x60)
	bool bClientOnlyVisible; // 0xf0(0x01)
	int32_t LevelLODIndex; // 0xf4(0x04)
	char pad_261_0 : 3; // 0x261(0x01)
	char bShouldBeVisible : 1; // 0xf8(0x01)
	char bShouldBeLoaded : 1; // 0xf8(0x01)
	char bLocked : 1; // 0xfb(0x01)
	char bIsStatic : 1; // 0xfb(0x01)
	char bShouldBlockOnLoad : 1; // 0xfb(0x01)
	char pad_262_0 : 3; // 0x262(0x01)
	char bShouldBlockOnUnload : 1; // 0xfb(0x01)
	char bDisableDistanceStreaming : 1; // 0xfb(0x01)
	char bDrawOnLevelStatusMap : 1; // 0xfb(0x01)
	struct FLinearColor LevelColor; // 0xfc(0x10)
	struct TArray<struct ALevelStreamingVolume*> EditorStreamingVolumes; // 0x110(0x10)
	float MinTimeBetweenVolumeUnloadRequests; // 0x120(0x04)
	struct FMulticastInlineDelegate OnLevelLoaded; // 0x128(0x10)
	struct FMulticastInlineDelegate OnLevelUnloaded; // 0x138(0x10)
	struct FMulticastInlineDelegate OnLevelShown; // 0x148(0x10)
	struct FMulticastInlineDelegate OnLevelHidden; // 0x158(0x10)
	struct ULevel* LoadedLevel; // 0x168(0x08)
	struct ULevel* PendingUnloadLevel; // 0x170(0x08)
};

// Class Engine.LevelInstanceEditorObject
// Size: 0x28 (Inherited: 0x28)
struct ULevelInstanceEditorObject : UObject {
};

// Class Engine.LevelInstancePivot
// Size: 0x298 (Inherited: 0x290)
struct ALevelInstancePivot : AActor {
	struct FActorTickFunction PrimaryActorTick; // 0x28(0x30)
	char bNetTemporary : 1; // 0x58(0x01)
	char pad_2C0_1 : 1; // 0x2c0(0x01)
	char bOnlyRelevantToOwner : 1; // 0x58(0x01)
	char bAlwaysRelevant : 1; // 0x58(0x01)
	char bReplicateMovement : 1; // 0x58(0x01)
	char bCallPreReplication : 1; // 0x58(0x01)
	char bCallPreReplicationForReplay : 1; // 0x58(0x01)
	char bHidden : 1; // 0x58(0x01)
	char bTearOff : 1; // 0x59(0x01)
	char bForceNetAddressable : 1; // 0x59(0x01)
	char bExchangedRoles : 1; // 0x59(0x01)
	char bNetLoadOnClient : 1; // 0x59(0x01)
	char bNetUseOwnerRelevancy : 1; // 0x59(0x01)
	char bRelevantForNetworkReplays : 1; // 0x59(0x01)
	char bRelevantForLevelBounds : 1; // 0x59(0x01)
	char bReplayRewindable : 1; // 0x59(0x01)
	char bAllowTickBeforeBeginPlay : 1; // 0x5a(0x01)
	char bAutoDestroyWhenFinished : 1; // 0x5a(0x01)
	char bCanBeDamaged : 1; // 0x5a(0x01)
	char bBlockInput : 1; // 0x5a(0x01)
	char bCollideWhenPlacing : 1; // 0x5a(0x01)
	char bFindCameraComponentWhenViewTarget : 1; // 0x5a(0x01)
	char bGenerateOverlapEventsDuringLevelStreaming : 1; // 0x5a(0x01)
	char bIgnoresOriginShifting : 1; // 0x5a(0x01)
	char bEnableAutoLODGeneration : 1; // 0x5b(0x01)
	char bIsEditorOnlyActor : 1; // 0x5b(0x01)
	char bActorSeamlessTraveled : 1; // 0x5b(0x01)
	char bReplicates : 1; // 0x5b(0x01)
	char bCanBeInCluster : 1; // 0x5b(0x01)
	char bAllowReceiveTickEventOnDedicatedServer : 1; // 0x5b(0x01)
	char pad_2C3_6 : 1; // 0x2c3(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x5b(0x01)
	char pad_2C4_0 : 7; // 0x2c4(0x01)
	char bActorEnableCollision : 1; // 0x5c(0x01)
	char bActorIsBeingDestroyed : 1; // 0x5d(0x01)
	char pad_2C5_1 : 4; // 0x2c5(0x01)
	char bAsyncPhysicsTickEnabled : 1; // 0x5d(0x01)
	enum class EActorUpdateOverlapsMethod UpdateOverlapsMethodDuringLevelStreaming; // 0x5e(0x01)
	enum class EActorUpdateOverlapsMethod DefaultUpdateOverlapsMethodDuringLevelStreaming; // 0x5f(0x01)
	float InitialLifeSpan; // 0x60(0x04)
	float CustomTimeDilation; // 0x64(0x04)
	enum class ENetRole RemoteRole; // 0x68(0x01)
	int32_t RayTracingGroupId; // 0x6c(0x04)
	struct FRepAttachment AttachmentReplication; // 0x70(0x60)
	struct FRepMovement ReplicatedMovement; // 0xd0(0x70)
	struct AActor* Owner; // 0x140(0x08)
	struct FName NetDriverName; // 0x148(0x08)
	enum class ENetRole Role; // 0x150(0x01)
	enum class ENetDormancy NetDormancy; // 0x151(0x01)
	enum class ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingMethod; // 0x152(0x01)
	enum class EAutoReceiveInput AutoReceiveInput; // 0x153(0x01)
	int32_t InputPriority; // 0x154(0x04)
	struct UInputComponent* InputComponent; // 0x160(0x08)
	float NetCullDistanceSquared; // 0x168(0x04)
	int32_t NetTag; // 0x16c(0x04)
	float NetUpdateFrequency; // 0x170(0x04)
	float MinNetUpdateFrequency; // 0x174(0x04)
	float NetPriority; // 0x178(0x04)
	struct APawn* Instigator; // 0x180(0x08)
	struct TArray<struct AActor*> Children; // 0x188(0x10)
	struct USceneComponent* RootComponent; // 0x198(0x08)
	struct TArray<struct FName> Layers; // 0x1a8(0x10)
	struct TWeakObjectPtr<struct UChildActorComponent> ParentComponent; // 0x1b8(0x08)
	struct TArray<struct FName> Tags; // 0x1c0(0x10)
	struct FMulticastSparseDelegate OnTakeAnyDamage; // 0x1d0(0x01)
	struct FMulticastSparseDelegate OnTakePointDamage; // 0x1d1(0x01)
	struct FMulticastSparseDelegate OnTakeRadialDamage; // 0x1d2(0x01)
	struct FMulticastSparseDelegate OnActorBeginOverlap; // 0x1d3(0x01)
	struct FMulticastSparseDelegate OnActorEndOverlap; // 0x1d4(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x1d5(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x1d6(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x1d7(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x1d8(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x1d9(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x1da(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x1db(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x1dc(0x01)
	struct FMulticastSparseDelegate OnActorHit; // 0x1dd(0x01)
	struct FMulticastSparseDelegate OnDestroyed; // 0x1de(0x01)
	struct FMulticastSparseDelegate OnEndPlay; // 0x1df(0x01)
	struct TArray<struct UActorComponent*> InstanceComponents; // 0x260(0x10)
	struct TArray<struct UActorComponent*> BlueprintCreatedComponents; // 0x270(0x10)
};

// Class Engine.LevelInstanceInterface
// Size: 0x28 (Inherited: 0x28)
struct ULevelInstanceInterface : UInterface {
};

// Class Engine.LevelStreamingLevelInstance
// Size: 0x1d0 (Inherited: 0x1b0)
struct ULevelStreamingLevelInstance : ULevelStreamingDynamic {
	char bInitiallyLoaded : 1; // 0x1a8(0x01)
	char bInitiallyVisible : 1; // 0x1a8(0x01)
	char pad_1B0_2 : 6; // 0x1b0(0x01)
	char pad_1B1[0x1f]; // 0x1b1(0x1f)
};

// Class Engine.LevelInstanceSubsystem
// Size: 0x1c0 (Inherited: 0x30)
struct ULevelInstanceSubsystem : UWorldSubsystem {
	char pad_30[0x190]; // 0x30(0x190)
};

// Class Engine.LevelScriptActor
// Size: 0x298 (Inherited: 0x290)
struct ALevelScriptActor : AActor {
	char bInputEnabled : 1; // 0x290(0x01)
	char pad_290_1 : 7; // 0x290(0x01)
	char pad_291[0x7]; // 0x291(0x07)

	void WorldOriginLocationChanged(struct FIntVector OldOriginLocation, struct FIntVector NewOriginLocation); // Function Engine.LevelScriptActor.WorldOriginLocationChanged // (None) // @ game+0xffffd192df830041
};

// Class Engine.LevelScriptBlueprint
// Size: 0xa8 (Inherited: 0xa8)
struct ULevelScriptBlueprint : UBlueprint {
	struct UObject* ParentClass; // 0x58(0x08)
	enum class EBlueprintType BlueprintType; // 0x60(0x01)
	char bRecompileOnLoad : 1; // 0x61(0x01)
	char bHasBeenRegenerated : 1; // 0x61(0x01)
	char bIsRegeneratingOnLoad : 1; // 0x61(0x01)
	int32_t BlueprintSystemVersion; // 0x64(0x04)
	struct USimpleConstructionScript* SimpleConstructionScript; // 0x68(0x08)
	struct TArray<struct UActorComponent*> ComponentTemplates; // 0x70(0x10)
	struct TArray<struct UTimelineTemplate*> Timelines; // 0x80(0x10)
	struct TArray<struct FBPComponentClassOverride> ComponentClassOverrides; // 0x90(0x10)
	struct UInheritableComponentHandler* InheritableComponentHandler; // 0xa0(0x08)
};

// Class Engine.LightmappedSurfaceCollection
// Size: 0x40 (Inherited: 0x28)
struct ULightmappedSurfaceCollection : UObject {
	struct UModel* SourceModel; // 0x28(0x08)
	struct TArray<int32_t> Surfaces; // 0x30(0x10)
};

// Class Engine.LightmassCharacterIndirectDetailVolume
// Size: 0x2c8 (Inherited: 0x2c8)
struct ALightmassCharacterIndirectDetailVolume : AVolume {
	enum class EBrushType BrushType; // 0x290(0x01)
	struct FColor BrushColor; // 0x294(0x04)
	int32_t PolyFlags; // 0x298(0x04)
	char bColored : 1; // 0x29c(0x01)
	char bSolidWhenSelected : 1; // 0x29c(0x01)
	char bPlaceableFromClassBrowser : 1; // 0x29c(0x01)
	char bNotForClientOrServer : 1; // 0x29c(0x01)
	struct UModel* Brush; // 0x2a0(0x08)
	struct UBrushComponent* BrushComponent; // 0x2a8(0x08)
	char bInManipulation : 1; // 0x2b0(0x01)
	struct TArray<struct FGeomSelection> SavedSelections; // 0x2b8(0x10)
};

// Class Engine.LightmassImportanceVolume
// Size: 0x2c8 (Inherited: 0x2c8)
struct ALightmassImportanceVolume : AVolume {
	enum class EBrushType BrushType; // 0x290(0x01)
	struct FColor BrushColor; // 0x294(0x04)
	int32_t PolyFlags; // 0x298(0x04)
	char bColored : 1; // 0x29c(0x01)
	char bSolidWhenSelected : 1; // 0x29c(0x01)
	char bPlaceableFromClassBrowser : 1; // 0x29c(0x01)
	char bNotForClientOrServer : 1; // 0x29c(0x01)
	struct UModel* Brush; // 0x2a0(0x08)
	struct UBrushComponent* BrushComponent; // 0x2a8(0x08)
	char bInManipulation : 1; // 0x2b0(0x01)
	struct TArray<struct FGeomSelection> SavedSelections; // 0x2b8(0x10)
};

// Class Engine.LightmassPrimitiveSettingsObject
// Size: 0x40 (Inherited: 0x28)
struct ULightmassPrimitiveSettingsObject : UObject {
	struct FLightmassPrimitiveSettings LightmassSettings; // 0x28(0x18)
};

// Class Engine.LightWeightInstanceBlueprintFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct ULightWeightInstanceBlueprintFunctionLibrary : UBlueprintFunctionLibrary {

	struct FActorInstanceHandle CreateNewLightWeightInstance(struct UObject* ActorClass, struct FTransform Transform, struct UDataLayerInstance* Layer, struct UWorld* World); // Function Engine.LightWeightInstanceBlueprintFunctionLibrary.CreateNewLightWeightInstance // (None) // @ game+0xffffd194df830041
};

// Class Engine.ActorInstanceHandleInterface
// Size: 0x48 (Inherited: 0x28)
struct UActorInstanceHandleInterface : UObject {
	char pad_28[0x20]; // 0x28(0x20)
};

// Class Engine.LightWeightInstanceManager
// Size: 0x330 (Inherited: 0x290)
struct ALightWeightInstanceManager : AActor {
	char pad_290[0x10]; // 0x290(0x10)
	struct AActor* RepresentedClass; // 0x2a0(0x08)
	struct AActor* AcceptedClass; // 0x2a8(0x08)
	struct TArray<struct FTransform> InstanceTransforms; // 0x2b0(0x10)
	char pad_2C0[0x50]; // 0x2c0(0x50)
	struct TArray<int32_t> FreeIndices; // 0x310(0x10)
	struct TArray<bool> ValidIndices; // 0x320(0x10)

	void OnRep_Transforms(); // Function Engine.LightWeightInstanceManager.OnRep_Transforms // (None) // @ game+0xffffd195df830041
};

// Class Engine.LightWeightInstanceStaticMeshManager
// Size: 0x3a0 (Inherited: 0x330)
struct ALightWeightInstanceStaticMeshManager : ALightWeightInstanceManager {
	char pad_330[0x8]; // 0x330(0x08)
	struct TSoftObjectPtr<UStaticMesh> StaticMesh; // 0x338(0x30)
	struct UHierarchicalInstancedStaticMeshComponent* InstancedStaticMeshComponent; // 0x368(0x08)
	struct TArray<int32_t> RenderingIndicesToDataIndices; // 0x370(0x10)
	struct TArray<int32_t> DataIndicesToRenderingIndices; // 0x380(0x10)
	char pad_390[0x10]; // 0x390(0x10)

	void OnRep_StaticMesh(); // Function Engine.LightWeightInstanceStaticMeshManager.OnRep_StaticMesh // (None) // @ game+0xffffd196df830041
};

// Class Engine.LocationVolume
// Size: 0x2d8 (Inherited: 0x2c8)
struct ALocationVolume : AVolume {
	char pad_2C8[0x8]; // 0x2c8(0x08)
	struct FColor DebugColor; // 0x2d0(0x04)
	char bIsRuntime : 1; // 0x2d4(0x01)
	char pad_2D4_1 : 7; // 0x2d4(0x01)
	char pad_2D5[0x3]; // 0x2d5(0x03)

	void Unload(); // Function Engine.LocationVolume.Unload // (None) // @ game+0xffffd199df830041
};

// Class Engine.LODActor
// Size: 0x318 (Inherited: 0x290)
struct ALODActor : AActor {
	struct UStaticMeshComponent* StaticMeshComponent; // 0x290(0x08)
	struct TMap<struct FHLODInstancingKey, struct UInstancedStaticMeshComponent*> InstancedStaticMeshComponents; // 0x298(0x50)
	struct UHLODProxy* Proxy; // 0x2e8(0x08)
	struct FName Key; // 0x2f0(0x08)
	float LODDrawDistance; // 0x2f8(0x04)
	int32_t LODLevel; // 0x2fc(0x04)
	struct TArray<struct AActor*> SubActors; // 0x300(0x10)
	char CachedNumHLODLevels; // 0x310(0x01)
	char pad_311[0x7]; // 0x311(0x07)

	void OnSubActorEndPlay(struct AActor* Actor, enum class EEndPlayReason Reason); // Function Engine.LODActor.OnSubActorEndPlay // (None) // @ game+0xffffd19adf830041
};

// Class Engine.MaterialInstanceActor
// Size: 0x2a0 (Inherited: 0x290)
struct AMaterialInstanceActor : AActor {
	struct TArray<struct AActor*> TargetActors; // 0x290(0x10)
};

// Class Engine.MaterialInstanceEditorOnlyData
// Size: 0xe0 (Inherited: 0x40)
struct UMaterialInstanceEditorOnlyData : UMaterialInterfaceEditorOnlyData {
	struct FStaticParameterSetEditorOnlyData StaticParameters; // 0x40(0xa0)
};

// Class Engine.MaterialInstanceDynamic
// Size: 0x248 (Inherited: 0x1f8)
struct UMaterialInstanceDynamic : UMaterialInstance {
	struct UPhysicalMaterial* PhysMaterial; // 0x98(0x08)
	struct UPhysicalMaterial* PhysicalMaterialMap[0x8]; // 0xa0(0x40)
	struct UMaterialInterface* Parent; // 0xe0(0x08)
	struct FMaterialOverrideNanite NaniteOverrideMaterial; // 0xe8(0x40)
	char bHasStaticPermutationResource : 1; // 0x128(0x01)
	char bOverrideSubsurfaceProfile : 1; // 0x128(0x01)
	struct TArray<struct FScalarParameterValue> ScalarParameterValues; // 0x130(0x10)
	struct TArray<struct FVectorParameterValue> VectorParameterValues; // 0x140(0x10)
	struct TArray<struct FDoubleVectorParameterValue> DoubleVectorParameterValues; // 0x150(0x10)
	struct TArray<struct FTextureParameterValue> TextureParameterValues; // 0x160(0x10)
	struct TArray<struct FRuntimeVirtualTextureParameterValue> RuntimeVirtualTextureParameterValues; // 0x170(0x10)
	struct TArray<struct FFontParameterValue> FontParameterValues; // 0x180(0x10)
	struct FMaterialInstanceBasePropertyOverrides BasePropertyOverrides; // 0x190(0x08)
	struct FStaticParameterSetRuntimeData StaticParametersRuntime; // 0x1a0(0x28)

	void SetVectorParameterValueByInfo(struct FMaterialParameterInfo& ParameterInfo, struct FLinearColor Value); // Function Engine.MaterialInstanceDynamic.SetVectorParameterValueByInfo // (None) // @ game+0xffffd1afdf830041
};

// Class Engine.MeshMergeCullingVolume
// Size: 0x2c8 (Inherited: 0x2c8)
struct AMeshMergeCullingVolume : AVolume {
	enum class EBrushType BrushType; // 0x290(0x01)
	struct FColor BrushColor; // 0x294(0x04)
	int32_t PolyFlags; // 0x298(0x04)
	char bColored : 1; // 0x29c(0x01)
	char bSolidWhenSelected : 1; // 0x29c(0x01)
	char bPlaceableFromClassBrowser : 1; // 0x29c(0x01)
	char bNotForClientOrServer : 1; // 0x29c(0x01)
	struct UModel* Brush; // 0x2a0(0x08)
	struct UBrushComponent* BrushComponent; // 0x2a8(0x08)
	char bInManipulation : 1; // 0x2b0(0x01)
	struct TArray<struct FGeomSelection> SavedSelections; // 0x2b8(0x10)
};

// Class Engine.MeshSimplificationSettings
// Size: 0x48 (Inherited: 0x38)
struct UMeshSimplificationSettings : UDeveloperSettings {
	struct FName MeshReductionModuleName; // 0x38(0x08)
	bool bMeshReductionBackwardCompatible; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// Class Engine.MeshVertexPainterKismetLibrary
// Size: 0x28 (Inherited: 0x28)
struct UMeshVertexPainterKismetLibrary : UBlueprintFunctionLibrary {

	void RemovePaintedVertices(struct UStaticMeshComponent* StaticMeshComponent); // Function Engine.MeshVertexPainterKismetLibrary.RemovePaintedVertices // (None) // @ game+0xffffd1b2df830041
};

// Class Engine.Model
// Size: 0x270 (Inherited: 0x28)
struct UModel : UObject {
	char pad_28[0x248]; // 0x28(0x248)
};

// Class Engine.SimulatedClientNetConnection
// Size: 0x3310 (Inherited: 0x3310)
struct USimulatedClientNetConnection : UNetConnection {
	struct TArray<struct UChildConnection*> Children; // 0x48(0x10)
	struct UNetDriver* Driver; // 0x58(0x08)
	struct UPackageMap* PackageMapClass; // 0x60(0x08)
	struct UPackageMap* PackageMap; // 0x68(0x08)
	struct TArray<struct UChannel*> OpenChannels; // 0x70(0x10)
	struct TArray<struct AActor*> SentTemporaries; // 0x80(0x10)
	struct AActor* ViewTarget; // 0x90(0x08)
	struct AActor* OwningActor; // 0x98(0x08)
	int32_t MaxPacket; // 0xa0(0x04)
	char InternalAck : 1; // 0xa4(0x01)
	struct FUniqueNetIdRepl PlayerId; // 0x160(0x30)
	double LastReceiveTime; // 0x1d8(0x08)
	int32_t DefaultMaxChannelSize; // 0x13c0(0x04)
	struct TArray<struct UChannel*> ChannelsToTick; // 0x1648(0x10)
};

// Class Engine.NetworkSettings
// Size: 0x50 (Inherited: 0x38)
struct UNetworkSettings : UDeveloperSettings {
	char bVerifyPeer : 1; // 0x38(0x01)
	char bEnableMultiplayerWorldOriginRebasing : 1; // 0x38(0x01)
	char pad_38_2 : 6; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct TArray<struct FNetworkEmulationProfileDescription> NetworkEmulationProfiles; // 0x40(0x10)
};

// Class Engine.BandwidthTestActor
// Size: 0x2b0 (Inherited: 0x290)
struct ABandwidthTestActor : AActor {
	struct FBandwidthTestGenerator BandwidthGenerator; // 0x290(0x20)
};

// Class Engine.NetFaultConfig
// Size: 0x88 (Inherited: 0x88)
struct UNetFaultConfig : UEscalationManagerConfig {
	struct TArray<struct FString> EscalationSeverity; // 0x68(0x10)
};

// Class Engine.NetPushModelHelpers
// Size: 0x28 (Inherited: 0x28)
struct UNetPushModelHelpers : UBlueprintFunctionLibrary {

	void MarkPropertyDirtyFromRepIndex(struct UObject* Object, int32_t RepIndex, struct FName PropertyName); // Function Engine.NetPushModelHelpers.MarkPropertyDirtyFromRepIndex // (None) // @ game+0xffffd1b4df830041
};

// Class Engine.RPCDoSDetectionConfig
// Size: 0x88 (Inherited: 0x28)
struct URPCDoSDetectionConfig : UObject {
	bool bRPCDoSDetection; // 0x28(0x01)
	bool bRPCDoSAnalytics; // 0x29(0x01)
	char pad_2A[0x2]; // 0x2a(0x02)
	int32_t HitchTimeQuotaMS; // 0x2c(0x04)
	int32_t HitchSuspendDetectionTimeMS; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct TArray<struct FString> DetectionSeverity; // 0x38(0x10)
	int32_t InitialConnectToleranceMS; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct TArray<struct FName> RPCBlockWhitelist; // 0x50(0x10)
	struct TArray<struct FName> RPCBlockAllowlist; // 0x60(0x10)
	struct TArray<struct FRPCAnalyticsThreshold> RPCAnalyticsThresholds; // 0x70(0x10)
	double RPCAnalyticsOverrideChance; // 0x80(0x08)
};

// Class Engine.NetworkSubsystem
// Size: 0x80 (Inherited: 0x30)
struct UNetworkSubsystem : UWorldSubsystem {
	char pad_30[0x50]; // 0x30(0x50)
};

// Class Engine.Note
// Size: 0x290 (Inherited: 0x290)
struct ANote : AActor {
	struct FActorTickFunction PrimaryActorTick; // 0x28(0x30)
	char bNetTemporary : 1; // 0x58(0x01)
	char pad_2C0_1 : 1; // 0x2c0(0x01)
	char bOnlyRelevantToOwner : 1; // 0x58(0x01)
	char bAlwaysRelevant : 1; // 0x58(0x01)
	char bReplicateMovement : 1; // 0x58(0x01)
	char bCallPreReplication : 1; // 0x58(0x01)
	char bCallPreReplicationForReplay : 1; // 0x58(0x01)
	char bHidden : 1; // 0x58(0x01)
	char bTearOff : 1; // 0x59(0x01)
	char bForceNetAddressable : 1; // 0x59(0x01)
	char bExchangedRoles : 1; // 0x59(0x01)
	char bNetLoadOnClient : 1; // 0x59(0x01)
	char bNetUseOwnerRelevancy : 1; // 0x59(0x01)
	char bRelevantForNetworkReplays : 1; // 0x59(0x01)
	char bRelevantForLevelBounds : 1; // 0x59(0x01)
	char bReplayRewindable : 1; // 0x59(0x01)
	char bAllowTickBeforeBeginPlay : 1; // 0x5a(0x01)
	char bAutoDestroyWhenFinished : 1; // 0x5a(0x01)
	char bCanBeDamaged : 1; // 0x5a(0x01)
	char bBlockInput : 1; // 0x5a(0x01)
	char bCollideWhenPlacing : 1; // 0x5a(0x01)
	char bFindCameraComponentWhenViewTarget : 1; // 0x5a(0x01)
	char bGenerateOverlapEventsDuringLevelStreaming : 1; // 0x5a(0x01)
	char bIgnoresOriginShifting : 1; // 0x5a(0x01)
	char bEnableAutoLODGeneration : 1; // 0x5b(0x01)
	char bIsEditorOnlyActor : 1; // 0x5b(0x01)
	char bActorSeamlessTraveled : 1; // 0x5b(0x01)
	char bReplicates : 1; // 0x5b(0x01)
	char bCanBeInCluster : 1; // 0x5b(0x01)
	char bAllowReceiveTickEventOnDedicatedServer : 1; // 0x5b(0x01)
	char pad_2C3_6 : 1; // 0x2c3(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x5b(0x01)
	char pad_2C4_0 : 7; // 0x2c4(0x01)
	char bActorEnableCollision : 1; // 0x5c(0x01)
	char bActorIsBeingDestroyed : 1; // 0x5d(0x01)
	char pad_2C5_1 : 4; // 0x2c5(0x01)
	char bAsyncPhysicsTickEnabled : 1; // 0x5d(0x01)
	enum class EActorUpdateOverlapsMethod UpdateOverlapsMethodDuringLevelStreaming; // 0x5e(0x01)
	enum class EActorUpdateOverlapsMethod DefaultUpdateOverlapsMethodDuringLevelStreaming; // 0x5f(0x01)
	float InitialLifeSpan; // 0x60(0x04)
	float CustomTimeDilation; // 0x64(0x04)
	enum class ENetRole RemoteRole; // 0x68(0x01)
	int32_t RayTracingGroupId; // 0x6c(0x04)
	struct FRepAttachment AttachmentReplication; // 0x70(0x60)
	struct FRepMovement ReplicatedMovement; // 0xd0(0x70)
	struct AActor* Owner; // 0x140(0x08)
	struct FName NetDriverName; // 0x148(0x08)
	enum class ENetRole Role; // 0x150(0x01)
	enum class ENetDormancy NetDormancy; // 0x151(0x01)
	enum class ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingMethod; // 0x152(0x01)
	enum class EAutoReceiveInput AutoReceiveInput; // 0x153(0x01)
	int32_t InputPriority; // 0x154(0x04)
	struct UInputComponent* InputComponent; // 0x160(0x08)
	float NetCullDistanceSquared; // 0x168(0x04)
	int32_t NetTag; // 0x16c(0x04)
	float NetUpdateFrequency; // 0x170(0x04)
	float MinNetUpdateFrequency; // 0x174(0x04)
	float NetPriority; // 0x178(0x04)
	struct APawn* Instigator; // 0x180(0x08)
	struct TArray<struct AActor*> Children; // 0x188(0x10)
	struct USceneComponent* RootComponent; // 0x198(0x08)
	struct TArray<struct FName> Layers; // 0x1a8(0x10)
	struct TWeakObjectPtr<struct UChildActorComponent> ParentComponent; // 0x1b8(0x08)
	struct TArray<struct FName> Tags; // 0x1c0(0x10)
	struct FMulticastSparseDelegate OnTakeAnyDamage; // 0x1d0(0x01)
	struct FMulticastSparseDelegate OnTakePointDamage; // 0x1d1(0x01)
	struct FMulticastSparseDelegate OnTakeRadialDamage; // 0x1d2(0x01)
	struct FMulticastSparseDelegate OnActorBeginOverlap; // 0x1d3(0x01)
	struct FMulticastSparseDelegate OnActorEndOverlap; // 0x1d4(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x1d5(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x1d6(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x1d7(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x1d8(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x1d9(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x1da(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x1db(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x1dc(0x01)
	struct FMulticastSparseDelegate OnActorHit; // 0x1dd(0x01)
	struct FMulticastSparseDelegate OnDestroyed; // 0x1de(0x01)
	struct FMulticastSparseDelegate OnEndPlay; // 0x1df(0x01)
	struct TArray<struct UActorComponent*> InstanceComponents; // 0x260(0x10)
	struct TArray<struct UActorComponent*> BlueprintCreatedComponents; // 0x270(0x10)
};

// Class Engine.ObjectLibrary
// Size: 0xa8 (Inherited: 0x28)
struct UObjectLibrary : UObject {
	ClassPtrProperty ObjectBaseClass; // 0x28(0x08)
	bool bHasBlueprintClasses; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct TArray<struct UObject*> Objects; // 0x38(0x10)
	struct TArray<struct TWeakObjectPtr<struct UObject>> WeakObjects; // 0x48(0x10)
	bool bUseWeakReferences; // 0x58(0x01)
	bool bIsFullyLoaded; // 0x59(0x01)
	char pad_5A[0x4e]; // 0x5a(0x4e)
};

// Class Engine.ObjectReferencer
// Size: 0x38 (Inherited: 0x28)
struct UObjectReferencer : UObject {
	struct TArray<struct UObject*> ReferencedObjects; // 0x28(0x10)
};

// Class Engine.ObjectTraceWorldSubsystem
// Size: 0x40 (Inherited: 0x30)
struct UObjectTraceWorldSubsystem : UWorldSubsystem {
	char pad_30[0x10]; // 0x30(0x10)
};

// Class Engine.PackageMapClient
// Size: 0x408 (Inherited: 0xe0)
struct UPackageMapClient : UPackageMap {
	char pad_E0[0x328]; // 0xe0(0x328)
};

// Class Engine.PackedLevelActor
// Size: 0x320 (Inherited: 0x320)
struct APackedLevelActor : ALevelInstance {
	struct TSoftObjectPtr<UWorld> CookedWorldAsset; // 0x298(0x30)
	struct FGuid LevelInstanceSpawnGuid; // 0x2c8(0x10)
};

// Class Engine.EngineHandlerComponentFactory
// Size: 0x28 (Inherited: 0x28)
struct UEngineHandlerComponentFactory : UHandlerComponentFactory {
};

// Class Engine.PainCausingVolume
// Size: 0x300 (Inherited: 0x2d8)
struct APainCausingVolume : APhysicsVolume {
	char bPainCausing : 1; // 0x2d8(0x01)
	char pad_2D8_1 : 7; // 0x2d8(0x01)
	char pad_2D9[0x3]; // 0x2d9(0x03)
	float DamagePerSec; // 0x2dc(0x04)
	struct UDamageType* DamageType; // 0x2e0(0x08)
	float PainInterval; // 0x2e8(0x04)
	char bEntryPain : 1; // 0x2ec(0x01)
	char BACKUP_bPainCausing : 1; // 0x2ec(0x01)
	char pad_2EC_2 : 6; // 0x2ec(0x01)
	char pad_2ED[0x3]; // 0x2ed(0x03)
	struct AController* DamageInstigator; // 0x2f0(0x08)
	char pad_2F8[0x8]; // 0x2f8(0x08)
};

// Class Engine.ParticleEventManager
// Size: 0x290 (Inherited: 0x290)
struct AParticleEventManager : AActor {
	struct FActorTickFunction PrimaryActorTick; // 0x28(0x30)
	char bNetTemporary : 1; // 0x58(0x01)
	char pad_2C0_1 : 1; // 0x2c0(0x01)
	char bOnlyRelevantToOwner : 1; // 0x58(0x01)
	char bAlwaysRelevant : 1; // 0x58(0x01)
	char bReplicateMovement : 1; // 0x58(0x01)
	char bCallPreReplication : 1; // 0x58(0x01)
	char bCallPreReplicationForReplay : 1; // 0x58(0x01)
	char bHidden : 1; // 0x58(0x01)
	char bTearOff : 1; // 0x59(0x01)
	char bForceNetAddressable : 1; // 0x59(0x01)
	char bExchangedRoles : 1; // 0x59(0x01)
	char bNetLoadOnClient : 1; // 0x59(0x01)
	char bNetUseOwnerRelevancy : 1; // 0x59(0x01)
	char bRelevantForNetworkReplays : 1; // 0x59(0x01)
	char bRelevantForLevelBounds : 1; // 0x59(0x01)
	char bReplayRewindable : 1; // 0x59(0x01)
	char bAllowTickBeforeBeginPlay : 1; // 0x5a(0x01)
	char bAutoDestroyWhenFinished : 1; // 0x5a(0x01)
	char bCanBeDamaged : 1; // 0x5a(0x01)
	char bBlockInput : 1; // 0x5a(0x01)
	char bCollideWhenPlacing : 1; // 0x5a(0x01)
	char bFindCameraComponentWhenViewTarget : 1; // 0x5a(0x01)
	char bGenerateOverlapEventsDuringLevelStreaming : 1; // 0x5a(0x01)
	char bIgnoresOriginShifting : 1; // 0x5a(0x01)
	char bEnableAutoLODGeneration : 1; // 0x5b(0x01)
	char bIsEditorOnlyActor : 1; // 0x5b(0x01)
	char bActorSeamlessTraveled : 1; // 0x5b(0x01)
	char bReplicates : 1; // 0x5b(0x01)
	char bCanBeInCluster : 1; // 0x5b(0x01)
	char bAllowReceiveTickEventOnDedicatedServer : 1; // 0x5b(0x01)
	char pad_2C3_6 : 1; // 0x2c3(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x5b(0x01)
	char pad_2C4_0 : 7; // 0x2c4(0x01)
	char bActorEnableCollision : 1; // 0x5c(0x01)
	char bActorIsBeingDestroyed : 1; // 0x5d(0x01)
	char pad_2C5_1 : 4; // 0x2c5(0x01)
	char bAsyncPhysicsTickEnabled : 1; // 0x5d(0x01)
	enum class EActorUpdateOverlapsMethod UpdateOverlapsMethodDuringLevelStreaming; // 0x5e(0x01)
	enum class EActorUpdateOverlapsMethod DefaultUpdateOverlapsMethodDuringLevelStreaming; // 0x5f(0x01)
	float InitialLifeSpan; // 0x60(0x04)
	float CustomTimeDilation; // 0x64(0x04)
	enum class ENetRole RemoteRole; // 0x68(0x01)
	int32_t RayTracingGroupId; // 0x6c(0x04)
	struct FRepAttachment AttachmentReplication; // 0x70(0x60)
	struct FRepMovement ReplicatedMovement; // 0xd0(0x70)
	struct AActor* Owner; // 0x140(0x08)
	struct FName NetDriverName; // 0x148(0x08)
	enum class ENetRole Role; // 0x150(0x01)
	enum class ENetDormancy NetDormancy; // 0x151(0x01)
	enum class ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingMethod; // 0x152(0x01)
	enum class EAutoReceiveInput AutoReceiveInput; // 0x153(0x01)
	int32_t InputPriority; // 0x154(0x04)
	struct UInputComponent* InputComponent; // 0x160(0x08)
	float NetCullDistanceSquared; // 0x168(0x04)
	int32_t NetTag; // 0x16c(0x04)
	float NetUpdateFrequency; // 0x170(0x04)
	float MinNetUpdateFrequency; // 0x174(0x04)
	float NetPriority; // 0x178(0x04)
	struct APawn* Instigator; // 0x180(0x08)
	struct TArray<struct AActor*> Children; // 0x188(0x10)
	struct USceneComponent* RootComponent; // 0x198(0x08)
	struct TArray<struct FName> Layers; // 0x1a8(0x10)
	struct TWeakObjectPtr<struct UChildActorComponent> ParentComponent; // 0x1b8(0x08)
	struct TArray<struct FName> Tags; // 0x1c0(0x10)
	struct FMulticastSparseDelegate OnTakeAnyDamage; // 0x1d0(0x01)
	struct FMulticastSparseDelegate OnTakePointDamage; // 0x1d1(0x01)
	struct FMulticastSparseDelegate OnTakeRadialDamage; // 0x1d2(0x01)
	struct FMulticastSparseDelegate OnActorBeginOverlap; // 0x1d3(0x01)
	struct FMulticastSparseDelegate OnActorEndOverlap; // 0x1d4(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x1d5(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x1d6(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x1d7(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x1d8(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x1d9(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x1da(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x1db(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x1dc(0x01)
	struct FMulticastSparseDelegate OnActorHit; // 0x1dd(0x01)
	struct FMulticastSparseDelegate OnDestroyed; // 0x1de(0x01)
	struct FMulticastSparseDelegate OnEndPlay; // 0x1df(0x01)
	struct TArray<struct UActorComponent*> InstanceComponents; // 0x260(0x10)
	struct TArray<struct UActorComponent*> BlueprintCreatedComponents; // 0x270(0x10)
};

// Class Engine.AsyncPhysicsInputComponent
// Size: 0xc8 (Inherited: 0xa0)
struct UAsyncPhysicsInputComponent : UActorComponent {
	struct UAsyncPhysicsData* DataClass; // 0xa0(0x08)
	struct TArray<struct UAsyncPhysicsData*> BufferedData; // 0xa8(0x10)
	struct UAsyncPhysicsData* DataToConsume; // 0xb8(0x08)
	struct UAsyncPhysicsData* DataToWrite; // 0xc0(0x08)

	void ServerRPCBufferInput(struct UAsyncPhysicsData* AsyncPhysicsData); // Function Engine.AsyncPhysicsInputComponent.ServerRPCBufferInput // (None) // @ game+0xffffd1b7df830041
};

// Class Engine.BodySetup
// Size: 0x2f0 (Inherited: 0x38)
struct UBodySetup : UBodySetupCore {
	struct FKAggregateGeom AggGeom; // 0x38(0x68)
	char bAlwaysFullAnimWeight : 1; // 0xa0(0x01)
	char bConsiderForBounds : 1; // 0xa0(0x01)
	char bMeshCollideAll : 1; // 0xa0(0x01)
	char bDoubleSidedGeometry : 1; // 0xa0(0x01)
	char bGenerateNonMirroredCollision : 1; // 0xa0(0x01)
	char bSharedCookedData : 1; // 0xa0(0x01)
	char bGenerateMirroredCollision : 1; // 0xa0(0x01)
	char bSupportUVsAndFaceRemap : 1; // 0xa0(0x01)
	char pad_A1_0 : 3; // 0xa1(0x01)
	char bNeverNeedsCookedCollisionData : 1; // 0xa1(0x01)
	char pad_A1_4 : 4; // 0xa1(0x01)
	char pad_A2[0x6]; // 0xa2(0x06)
	struct UPhysicalMaterial* PhysMaterial; // 0xa8(0x08)
	struct FWalkableSlopeOverride WalkableSlopeOverride; // 0xb0(0x10)
	char pad_C0[0x70]; // 0xc0(0x70)
	struct FBodyInstance DefaultInstance; // 0x130(0x190)
	char pad_2C0[0x8]; // 0x2c0(0x08)
	struct FVector BuildScale3D; // 0x2c8(0x18)
	char pad_2E0[0x10]; // 0x2e0(0x10)
};

// Class Engine.ConstraintInstanceBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UConstraintInstanceBlueprintLibrary : UBlueprintFunctionLibrary {

	void SetProjectionParams(struct FConstraintInstanceAccessor& Accessor, bool bEnableProjection, float ProjectionLinearAlpha, float ProjectionAngularAlpha); // Function Engine.ConstraintInstanceBlueprintLibrary.SetProjectionParams // (None) // @ game+0xffffd1eddf830041
};

// Class Engine.PhysicalAnimationComponent
// Size: 0xe0 (Inherited: 0xa0)
struct UPhysicalAnimationComponent : UActorComponent {
	float StrengthMultiplyer; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)
	struct USkeletalMeshComponent* SkeletalMeshComponent; // 0xa8(0x08)
	char pad_B0[0x30]; // 0xb0(0x30)

	void SetStrengthMultiplyer(float InStrengthMultiplyer); // Function Engine.PhysicalAnimationComponent.SetStrengthMultiplyer // (None) // @ game+0xffffd1f3df830041
};

// Class Engine.PhysicalMaterialMask
// Size: 0x38 (Inherited: 0x28)
struct UPhysicalMaterialMask : UObject {
	int32_t UVChannelIndex; // 0x28(0x04)
	enum class TextureAddress AddressX; // 0x2c(0x01)
	enum class TextureAddress AddressY; // 0x2d(0x01)
	char pad_2E[0xa]; // 0x2e(0x0a)
};

// Class Engine.PhysicsAsset
// Size: 0x150 (Inherited: 0x28)
struct UPhysicsAsset : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TArray<int32_t> BoundsBodies; // 0x30(0x10)
	struct TArray<struct USkeletalBodySetup*> SkeletalBodySetups; // 0x40(0x10)
	struct TArray<struct UPhysicsConstraintTemplate*> ConstraintSetup; // 0x50(0x10)
	struct FPhysicsAssetSolverSettings SolverSettings; // 0x60(0x1c)
	struct FSolverIterations SolverIterations; // 0x7c(0x18)
	enum class EPhysicsAssetSolverType SolverType; // 0x94(0x01)
	char bNotForDedicatedServer : 1; // 0x95(0x01)
	char pad_95_1 : 7; // 0x95(0x01)
	char pad_96[0xa2]; // 0x96(0xa2)
	struct UThumbnailInfo* ThumbnailInfo; // 0x138(0x08)
	struct TArray<struct UBodySetup*> BodySetup; // 0x140(0x10)
};

// Class Engine.SkeletalBodySetup
// Size: 0x308 (Inherited: 0x2f0)
struct USkeletalBodySetup : UBodySetup {
	bool bSkipScaleFromAnimation; // 0x2f0(0x01)
	char pad_2F1[0x7]; // 0x2f1(0x07)
	struct TArray<struct FPhysicalAnimationProfile> PhysicalAnimationData; // 0x2f8(0x10)
};

// Class Engine.PhysicsCollisionHandler
// Size: 0x40 (Inherited: 0x28)
struct UPhysicsCollisionHandler : UObject {
	float ImpactThreshold; // 0x28(0x04)
	float ImpactReFireDelay; // 0x2c(0x04)
	struct USoundBase* DefaultImpactSound; // 0x30(0x08)
	float LastImpactSoundTime; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class Engine.PhysicsConstraintActor
// Size: 0x2b0 (Inherited: 0x290)
struct APhysicsConstraintActor : ARigidBodyBase {
	struct UPhysicsConstraintComponent* ConstraintComp; // 0x290(0x08)
	struct AActor* ConstraintActor1; // 0x298(0x08)
	struct AActor* ConstraintActor2; // 0x2a0(0x08)
	char bDisableCollision : 1; // 0x2a8(0x01)
	char pad_2A8_1 : 7; // 0x2a8(0x01)
	char pad_2A9[0x7]; // 0x2a9(0x07)
};

// Class Engine.PhysicsConstraintComponent
// Size: 0x570 (Inherited: 0x2a0)
struct UPhysicsConstraintComponent : USceneComponent {
	struct AActor* ConstraintActor1; // 0x2a0(0x08)
	struct FConstrainComponentPropName ComponentName1; // 0x2a8(0x08)
	struct AActor* ConstraintActor2; // 0x2b0(0x08)
	struct FConstrainComponentPropName ComponentName2; // 0x2b8(0x08)
	char pad_2C0[0x10]; // 0x2c0(0x10)
	struct UPhysicsConstraintTemplate* ConstraintSetup; // 0x2d0(0x08)
	struct FMulticastInlineDelegate OnConstraintBroken; // 0x2d8(0x10)
	struct FMulticastInlineDelegate OnPlasticDeformation; // 0x2e8(0x10)
	struct FConstraintInstance ConstraintInstance; // 0x2f8(0x278)

	void SetOrientationDriveTwistAndSwing(bool bEnableTwistDrive, bool bEnableSwingDrive); // Function Engine.PhysicsConstraintComponent.SetOrientationDriveTwistAndSwing // (None) // @ game+0xffffd21adf830041
};

// Class Engine.PhysicsConstraintTemplate
// Size: 0x410 (Inherited: 0x28)
struct UPhysicsConstraintTemplate : UObject {
	struct FConstraintInstance DefaultInstance; // 0x28(0x278)
	struct TArray<struct FPhysicsConstraintProfileHandle> ProfileHandles; // 0x2a0(0x10)
	struct FConstraintProfileProperties DefaultProfile; // 0x2b0(0x160)
};

// Class Engine.PhysicsHandleComponent
// Size: 0x4e0 (Inherited: 0xa0)
struct UPhysicsHandleComponent : UActorComponent {
	struct UPrimitiveComponent* GrabbedComponent; // 0xa0(0x08)
	char pad_A8[0x8]; // 0xa8(0x08)
	char pad_B0_0 : 1; // 0xb0(0x01)
	char bSoftAngularConstraint : 1; // 0xb0(0x01)
	char bSoftLinearConstraint : 1; // 0xb0(0x01)
	char bInterpolateTarget : 1; // 0xb0(0x01)
	char pad_B0_4 : 4; // 0xb0(0x01)
	char pad_B1[0x3]; // 0xb1(0x03)
	float LinearDamping; // 0xb4(0x04)
	float LinearStiffness; // 0xb8(0x04)
	float AngularDamping; // 0xbc(0x04)
	float AngularStiffness; // 0xc0(0x04)
	char pad_C4[0xcc]; // 0xc4(0xcc)
	float InterpolationSpeed; // 0x190(0x04)
	char pad_194[0x34c]; // 0x194(0x34c)

	void SetTargetRotation(struct FRotator NewRotation); // Function Engine.PhysicsHandleComponent.SetTargetRotation // (None) // @ game+0xffffd228df830041
};

// Class Engine.PhysicsSettings
// Size: 0x1e8 (Inherited: 0xe0)
struct UPhysicsSettings : UPhysicsSettingsCore {
	struct FRigidBodyErrorCorrection PhysicErrorCorrection; // 0xe0(0x34)
	enum class ESettingsLockedAxis LockedAxis; // 0x114(0x01)
	enum class ESettingsDOF DefaultDegreesOfFreedom; // 0x115(0x01)
	bool bSuppressFaceRemapTable; // 0x116(0x01)
	bool bSupportUVFromHitResults; // 0x117(0x01)
	bool bDisableActiveActors; // 0x118(0x01)
	bool bDisableKinematicStaticPairs; // 0x119(0x01)
	bool bDisableKinematicKinematicPairs; // 0x11a(0x01)
	bool bDisableCCD; // 0x11b(0x01)
	bool bEnableEnhancedDeterminism; // 0x11c(0x01)
	char pad_11D[0x3]; // 0x11d(0x03)
	float AnimPhysicsMinDeltaTime; // 0x120(0x04)
	bool bSimulateAnimPhysicsAfterReset; // 0x124(0x01)
	char pad_125[0x3]; // 0x125(0x03)
	float MinPhysicsDeltaTime; // 0x128(0x04)
	float MaxPhysicsDeltaTime; // 0x12c(0x04)
	bool bSubstepping; // 0x130(0x01)
	bool bSubsteppingAsync; // 0x131(0x01)
	bool bTickPhysicsAsync; // 0x132(0x01)
	char pad_133[0x1]; // 0x133(0x01)
	float AsyncFixedTimeStepSize; // 0x134(0x04)
	float MaxSubstepDeltaTime; // 0x138(0x04)
	int32_t MaxSubsteps; // 0x13c(0x04)
	float SyncSceneSmoothingFactor; // 0x140(0x04)
	float InitialAverageFrameRate; // 0x144(0x04)
	int32_t PhysXTreeRebuildRate; // 0x148(0x04)
	char pad_14C[0x4]; // 0x14c(0x04)
	struct TArray<struct FPhysicalSurfaceName> PhysicalSurfaces; // 0x150(0x10)
	struct FBroadphaseSettings DefaultBroadphaseSettings; // 0x160(0x80)
	float MinDeltaVelocityForHitEvents; // 0x1e0(0x04)
	struct FChaosPhysicsSettings ChaosSettings; // 0x1e4(0x03)
	char pad_1E7[0x1]; // 0x1e7(0x01)
};

// Class Engine.PhysicsThruster
// Size: 0x298 (Inherited: 0x290)
struct APhysicsThruster : ARigidBodyBase {
	struct UPhysicsThrusterComponent* ThrusterComponent; // 0x290(0x08)
};

// Class Engine.RadialForceComponent
// Size: 0x2d0 (Inherited: 0x2a0)
struct URadialForceComponent : USceneComponent {
	float Radius; // 0x2a0(0x04)
	enum class ERadialImpulseFalloff Falloff; // 0x2a4(0x01)
	char pad_2A5[0x3]; // 0x2a5(0x03)
	float ImpulseStrength; // 0x2a8(0x04)
	char bImpulseVelChange : 1; // 0x2ac(0x01)
	char bIgnoreOwningActor : 1; // 0x2ac(0x01)
	char pad_2AC_2 : 6; // 0x2ac(0x01)
	char pad_2AD[0x3]; // 0x2ad(0x03)
	float ForceStrength; // 0x2b0(0x04)
	float DestructibleDamage; // 0x2b4(0x04)
	struct TArray<enum class EObjectTypeQuery> ObjectTypesToAffect; // 0x2b8(0x10)
	char pad_2C8[0x8]; // 0x2c8(0x08)

	void RemoveObjectTypeToAffect(enum class EObjectTypeQuery ObjectType); // Function Engine.RadialForceComponent.RemoveObjectTypeToAffect // (None) // @ game+0xffffd22bdf830041
};

// Class Engine.PhysicsFieldComponent
// Size: 0x340 (Inherited: 0x2a0)
struct UPhysicsFieldComponent : USceneComponent {
	struct TWeakObjectPtr<struct APhysicsVolume> PhysicsVolume; // 0xa8(0x08)
	struct USceneComponent* AttachParent; // 0xb0(0x08)
	struct FName AttachSocketName; // 0xb8(0x08)
	struct TArray<struct USceneComponent*> AttachChildren; // 0xc0(0x10)
	struct TArray<struct USceneComponent*> ClientAttachedChildren; // 0xd0(0x10)
	struct FVector RelativeLocation; // 0x128(0x18)
	struct FRotator RelativeRotation; // 0x140(0x18)
	struct FVector RelativeScale3D; // 0x158(0x18)
	struct FVector ComponentVelocity; // 0x170(0x18)
	char bComponentToWorldUpdated : 1; // 0x188(0x01)
	char pad_338_1 : 1; // 0x338(0x01)
	char bAbsoluteLocation : 1; // 0x188(0x01)
	char bAbsoluteRotation : 1; // 0x188(0x01)
	char bAbsoluteScale : 1; // 0x188(0x01)
	char bVisible : 1; // 0x188(0x01)
	char bShouldBeAttached : 1; // 0x188(0x01)
	char bShouldSnapLocationWhenAttached : 1; // 0x188(0x01)
	char bShouldSnapRotationWhenAttached : 1; // 0x189(0x01)
	char bShouldSnapScaleWhenAttached : 1; // 0x189(0x01)
	char bShouldUpdatePhysicsVolume : 1; // 0x189(0x01)
	char bHiddenInGame : 1; // 0x189(0x01)
	char bBoundsChangeTriggersStreamingDataRebuild : 1; // 0x189(0x01)
	char bUseAttachParentBound : 1; // 0x189(0x01)
	char bComputeFastLocalBounds : 1; // 0x189(0x01)
	char bComputeBoundsOnceForGame : 1; // 0x189(0x01)
	char bComputedBoundsOnceForGame : 1; // 0x18a(0x01)
	char bIsNotRenderAttachmentRoot : 1; // 0x18a(0x01)
	enum class EComponentMobility Mobility; // 0x18b(0x01)
	enum class EDetailMode DetailMode; // 0x18c(0x01)
	struct FMulticastSparseDelegate PhysicsVolumeChangedDelegate; // 0x18d(0x01)
	char pad_33D_2 : 6; // 0x33d(0x01)
	char pad_33E[0x2]; // 0x33e(0x02)
};

// Class Engine.PhysicsFieldStatics
// Size: 0x28 (Inherited: 0x28)
struct UPhysicsFieldStatics : UBlueprintFunctionLibrary {

	struct FVector EvalPhysicsVectorField(struct UObject* WorldContextObject, struct FVector& WorldPosition, enum class EFieldVectorType VectorType); // Function Engine.PhysicsFieldStatics.EvalPhysicsVectorField // (None) // @ game+0xffffd22edf830041
};

// Class Engine.PlatformInputDeviceMapperLibrary
// Size: 0x28 (Inherited: 0x28)
struct UPlatformInputDeviceMapperLibrary : UBlueprintFunctionLibrary {

	struct FPlatformUserId PlatformUserId_None(); // Function Engine.PlatformInputDeviceMapperLibrary.PlatformUserId_None // (None) // @ game+0xffffd241df830041
};

// Class Engine.PlayerStartPIE
// Size: 0x2c0 (Inherited: 0x2c0)
struct APlayerStartPIE : APlayerStart {
	struct FName PlayerStartTag; // 0x2b8(0x08)
};

// Class Engine.PlayerState
// Size: 0x3a8 (Inherited: 0x290)
struct APlayerState : AInfo {
	float Score; // 0x290(0x04)
	int32_t PlayerId; // 0x294(0x04)
	char CompressedPing; // 0x298(0x01)
	char pad_299[0x1]; // 0x299(0x01)
	char bShouldUpdateReplicatedPing : 1; // 0x29a(0x01)
	char bIsSpectator : 1; // 0x29a(0x01)
	char bOnlySpectator : 1; // 0x29a(0x01)
	char bIsABot : 1; // 0x29a(0x01)
	char pad_29A_4 : 1; // 0x29a(0x01)
	char bIsInactive : 1; // 0x29a(0x01)
	char bFromPreviousLevel : 1; // 0x29a(0x01)
	char pad_29A_7 : 1; // 0x29a(0x01)
	char pad_29B[0x1]; // 0x29b(0x01)
	int32_t StartTime; // 0x29c(0x04)
	struct ULocalMessage* EngineMessageClass; // 0x2a0(0x08)
	char pad_2A8[0x8]; // 0x2a8(0x08)
	struct FString SavedNetworkAddress; // 0x2b0(0x10)
	struct FUniqueNetIdRepl UniqueId; // 0x2c0(0x30)
	char pad_2F0[0x8]; // 0x2f0(0x08)
	struct FMulticastInlineDelegate OnPawnSet; // 0x2f8(0x10)
	struct APawn* PawnPrivate; // 0x308(0x08)
	char pad_310[0x78]; // 0x310(0x78)
	struct FString PlayerNamePrivate; // 0x388(0x10)
	char pad_398[0x10]; // 0x398(0x10)

	void ReceiveOverrideWith(struct APlayerState* OldPlayerState); // Function Engine.PlayerState.ReceiveOverrideWith // (None) // @ game+0xffffd254df830041
};

// Class Engine.PostProcessVolume
// Size: 0x9c0 (Inherited: 0x2c8)
struct APostProcessVolume : AVolume {
	char pad_2C8[0x8]; // 0x2c8(0x08)
	struct FPostProcessSettings Settings; // 0x2d0(0x6e0)
	float Priority; // 0x9b0(0x04)
	float BlendRadius; // 0x9b4(0x04)
	float BlendWeight; // 0x9b8(0x04)
	char bEnabled : 1; // 0x9bc(0x01)
	char bUnbound : 1; // 0x9bc(0x01)
	char pad_9BC_2 : 6; // 0x9bc(0x01)
	char pad_9BD[0x3]; // 0x9bd(0x03)

	void AddOrUpdateBlendable(struct TScriptInterface<IBlendableInterface> InBlendableObject, float InWeight); // Function Engine.PostProcessVolume.AddOrUpdateBlendable // (None) // @ game+0xffffd255df830041
};

// Class Engine.PrecomputedVisibilityVolume
// Size: 0x2c8 (Inherited: 0x2c8)
struct APrecomputedVisibilityVolume : AVolume {
	enum class EBrushType BrushType; // 0x290(0x01)
	struct FColor BrushColor; // 0x294(0x04)
	int32_t PolyFlags; // 0x298(0x04)
	char bColored : 1; // 0x29c(0x01)
	char bSolidWhenSelected : 1; // 0x29c(0x01)
	char bPlaceableFromClassBrowser : 1; // 0x29c(0x01)
	char bNotForClientOrServer : 1; // 0x29c(0x01)
	struct UModel* Brush; // 0x2a0(0x08)
	struct UBrushComponent* BrushComponent; // 0x2a8(0x08)
	char bInManipulation : 1; // 0x2b0(0x01)
	struct TArray<struct FGeomSelection> SavedSelections; // 0x2b8(0x10)
};

// Class Engine.PrimaryAssetLabel
// Size: 0x68 (Inherited: 0x30)
struct UPrimaryAssetLabel : UPrimaryDataAsset {
	struct FPrimaryAssetRules Rules; // 0x30(0x0c)
	char bLabelAssetsInMyDirectory : 1; // 0x3c(0x01)
	char bIsRuntimeLabel : 1; // 0x3c(0x01)
	char pad_3C_2 : 6; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
	struct TArray<struct TSoftObjectPtr<UObject>> ExplicitAssets; // 0x40(0x10)
	struct TArray<struct TSoftClassPtr<UObject>> ExplicitBlueprints; // 0x50(0x10)
	struct FCollectionReference AssetCollection; // 0x60(0x08)
};

// Class Engine.HealthSnapshotBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UHealthSnapshotBlueprintLibrary : UBlueprintFunctionLibrary {

	void StopPerformanceSnapshots(); // Function Engine.HealthSnapshotBlueprintLibrary.StopPerformanceSnapshots // (None) // @ game+0xffffd258df830041
};

// Class Engine.ProxyLODMeshSimplificationSettings
// Size: 0x40 (Inherited: 0x38)
struct UProxyLODMeshSimplificationSettings : UDeveloperSettings {
	struct FName ProxyLODMeshReductionModuleName; // 0x38(0x08)
};

// Class Engine.RectLight
// Size: 0x2a8 (Inherited: 0x2a0)
struct ARectLight : ALight {
	struct URectLightComponent* RectLightComponent; // 0x2a0(0x08)
};

// Class Engine.RendererSettings
// Size: 0x1d8 (Inherited: 0x38)
struct URendererSettings : UDeveloperSettings {
	enum class EMobileShadingPath MobileShadingPath; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	char bMobileSupportGPUScene : 1; // 0x3c(0x01)
	char pad_3C_1 : 7; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
	enum class EMobileAntiAliasingMethod MobileAntiAliasing; // 0x40(0x01)
	enum class EMobileFloatPrecisionMode MobileFloatPrecisionMode; // 0x41(0x01)
	char pad_42[0x2]; // 0x42(0x02)
	char bMobileAllowDitheredLODTransition : 1; // 0x44(0x01)
	char bMobileVirtualTextures : 1; // 0x44(0x01)
	char bDiscardUnusedQualityLevels : 1; // 0x44(0x01)
	char pad_44_3 : 5; // 0x44(0x01)
	char pad_45[0x3]; // 0x45(0x03)
	enum class EShaderCompressionFormat ShaderCompressionFormat; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	char bOcclusionCulling : 1; // 0x4c(0x01)
	char pad_4C_1 : 7; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	float MinScreenRadiusForLights; // 0x50(0x04)
	float MinScreenRadiusForEarlyZPass; // 0x54(0x04)
	float MinScreenRadiusForCSMdepth; // 0x58(0x04)
	char bPrecomputedVisibilityWarning : 1; // 0x5c(0x01)
	char bTextureStreaming : 1; // 0x5c(0x01)
	char bUseDXT5NormalMaps : 1; // 0x5c(0x01)
	char bVirtualTextures : 1; // 0x5c(0x01)
	char bVirtualTextureEnableAutoImport : 1; // 0x5c(0x01)
	char bVirtualTexturedLightmaps : 1; // 0x5c(0x01)
	char bVirtualTextureAnisotropicFiltering : 1; // 0x5c(0x01)
	char bEnableVirtualTextureOpacityMask : 1; // 0x5c(0x01)
	char pad_5D[0x3]; // 0x5d(0x03)
	uint32_t VirtualTextureTileSize; // 0x60(0x04)
	uint32_t VirtualTextureTileBorderSize; // 0x64(0x04)
	uint32_t VirtualTextureFeedbackFactor; // 0x68(0x04)
	enum class EWorkingColorSpace WorkingColorSpaceChoice; // 0x6c(0x01)
	char pad_6D[0x3]; // 0x6d(0x03)
	struct FVector2D RedChromaticityCoordinate; // 0x70(0x10)
	struct FVector2D GreenChromaticityCoordinate; // 0x80(0x10)
	struct FVector2D BlueChromaticityCoordinate; // 0x90(0x10)
	struct FVector2D WhiteChromaticityCoordinate; // 0xa0(0x10)
	char bClearCoatEnableSecondNormal : 1; // 0xb0(0x01)
	char pad_B0_1 : 7; // 0xb0(0x01)
	char pad_B1[0x3]; // 0xb1(0x03)
	enum class EDynamicGlobalIlluminationMethod DynamicGlobalIllumination; // 0xb4(0x01)
	enum class EReflectionMethod Reflections; // 0xb5(0x01)
	char pad_B6[0x2]; // 0xb6(0x02)
	int32_t ReflectionCaptureResolution; // 0xb8(0x04)
	char ReflectionEnvironmentLightmapMixBasedOnRoughness : 1; // 0xbc(0x01)
	char bUseHardwareRayTracingForLumen : 1; // 0xbc(0x01)
	char pad_BC_2 : 6; // 0xbc(0x01)
	char pad_BD[0x3]; // 0xbd(0x03)
	enum class ELumenRayLightingMode LumenRayLightingMode; // 0xc0(0x01)
	char pad_C1[0x3]; // 0xc1(0x03)
	char LumenFrontLayerTranslucencyReflections : 1; // 0xc4(0x01)
	char pad_C4_1 : 7; // 0xc4(0x01)
	char pad_C5[0x3]; // 0xc5(0x03)
	enum class ELumenSoftwareTracingMode LumenSoftwareTracingMode; // 0xc8(0x01)
	enum class EShadowMapMethod ShadowMapMethod; // 0xc9(0x01)
	char pad_CA[0x2]; // 0xca(0x02)
	char bEnableRayTracing : 1; // 0xcc(0x01)
	char bEnableRayTracingShadows : 1; // 0xcc(0x01)
	char bEnableRayTracingSkylight : 1; // 0xcc(0x01)
	char bEnableRayTracingTextureLOD : 1; // 0xcc(0x01)
	char bEnablePathTracing : 1; // 0xcc(0x01)
	char bGenerateMeshDistanceFields : 1; // 0xcc(0x01)
	char pad_CC_6 : 2; // 0xcc(0x01)
	char pad_CD[0x3]; // 0xcd(0x03)
	float DistanceFieldVoxelDensity; // 0xd0(0x04)
	char bNanite : 1; // 0xd4(0x01)
	char bAllowStaticLighting : 1; // 0xd4(0x01)
	char bUseNormalMapsForStaticLighting : 1; // 0xd4(0x01)
	char bForwardShading : 1; // 0xd4(0x01)
	char bVertexFoggingForOpaque : 1; // 0xd4(0x01)
	char bSeparateTranslucency : 1; // 0xd4(0x01)
	char pad_D4_6 : 2; // 0xd4(0x01)
	char pad_D5[0x3]; // 0xd5(0x03)
	enum class ETranslucentSortPolicy TranslucentSortPolicy; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
	struct FVector TranslucentSortAxis; // 0xe0(0x18)
	enum class EFixedFoveationLevels HMDFixedFoveationLevel; // 0xf8(0x01)
	char pad_F9[0x3]; // 0xf9(0x03)
	char bHMDFixedFoveationDynamic : 1; // 0xfc(0x01)
	char pad_FC_1 : 7; // 0xfc(0x01)
	char pad_FD[0x3]; // 0xfd(0x03)
	enum class ECustomDepthStencil CustomDepthStencil; // 0x100(0x01)
	char pad_101[0x3]; // 0x101(0x03)
	char bCustomDepthTaaJitter : 1; // 0x104(0x01)
	char pad_104_1 : 7; // 0x104(0x01)
	char pad_105[0x3]; // 0x105(0x03)
	enum class EAlphaChannelMode bEnableAlphaChannelInPostProcessing; // 0x108(0x01)
	char pad_109[0x3]; // 0x109(0x03)
	char bDefaultFeatureBloom : 1; // 0x10c(0x01)
	char bDefaultFeatureAmbientOcclusion : 1; // 0x10c(0x01)
	char bDefaultFeatureAmbientOcclusionStaticFraction : 1; // 0x10c(0x01)
	char bDefaultFeatureAutoExposure : 1; // 0x10c(0x01)
	char pad_10C_4 : 4; // 0x10c(0x01)
	char pad_10D[0x3]; // 0x10d(0x03)
	enum class EAutoExposureMethodUI DefaultFeatureAutoExposure; // 0x110(0x01)
	char pad_111[0x3]; // 0x111(0x03)
	float DefaultFeatureAutoExposureBias; // 0x114(0x04)
	char bExtendDefaultLuminanceRangeInAutoExposureSettings : 1; // 0x118(0x01)
	char bDefaultFeatureMotionBlur : 1; // 0x118(0x01)
	char bDefaultFeatureLensFlare : 1; // 0x118(0x01)
	char bTemporalUpsampling : 1; // 0x118(0x01)
	char pad_118_4 : 4; // 0x118(0x01)
	char pad_119[0x3]; // 0x119(0x03)
	enum class EAntiAliasingMethod DefaultFeatureAntiAliasing; // 0x11c(0x01)
	enum class ECompositingSampleCount MSAASampleCount; // 0x11d(0x01)
	enum class ELightUnits DefaultLightUnits; // 0x11e(0x01)
	enum class EDefaultBackBufferPixelFormat DefaultBackBufferPixelFormat; // 0x11f(0x01)
	char bRenderUnbuiltPreviewShadowsInGame : 1; // 0x120(0x01)
	char bStencilForLODDither : 1; // 0x120(0x01)
	char pad_120_2 : 6; // 0x120(0x01)
	char pad_121[0x3]; // 0x121(0x03)
	enum class EEarlyZPass EarlyZPass; // 0x124(0x01)
	char pad_125[0x3]; // 0x125(0x03)
	char bEarlyZPassOnlyMaterialMasking : 1; // 0x128(0x01)
	char bEnableCSMCaching : 1; // 0x128(0x01)
	char bDBuffer : 1; // 0x128(0x01)
	char pad_128_3 : 5; // 0x128(0x01)
	char pad_129[0x3]; // 0x129(0x03)
	enum class EClearSceneOptions ClearSceneMethod; // 0x12c(0x01)
	enum class EVelocityOutputPass VelocityPass; // 0x12d(0x01)
	enum class EVertexDeformationOutputsVelocity VertexDeformationOutputsVelocity; // 0x12e(0x01)
	char pad_12F[0x1]; // 0x12f(0x01)
	char bSelectiveBasePassOutputs : 1; // 0x130(0x01)
	char bDefaultParticleCutouts : 1; // 0x130(0x01)
	char pad_130_2 : 6; // 0x130(0x01)
	char pad_131[0x3]; // 0x131(0x03)
	int32_t GPUSimulationTextureSizeX; // 0x134(0x04)
	int32_t GPUSimulationTextureSizeY; // 0x138(0x04)
	char bGlobalClipPlane : 1; // 0x13c(0x01)
	char pad_13C_1 : 7; // 0x13c(0x01)
	char pad_13D[0x3]; // 0x13d(0x03)
	enum class EGBufferFormat GBufferFormat; // 0x140(0x01)
	char pad_141[0x3]; // 0x141(0x03)
	char bUseGPUMorphTargets : 1; // 0x144(0x01)
	char bNvidiaAftermathEnabled : 1; // 0x144(0x01)
	char bMultiView : 1; // 0x144(0x01)
	char bMobilePostProcessing : 1; // 0x144(0x01)
	char bMobileMultiView : 1; // 0x144(0x01)
	char bMobileUseHWsRGBEncoding : 1; // 0x144(0x01)
	char bRoundRobinOcclusion : 1; // 0x144(0x01)
	char bMeshStreaming : 1; // 0x144(0x01)
	char bEnableHeterogeneousVolumes : 1; // 0x145(0x01)
	char pad_145_1 : 7; // 0x145(0x01)
	char pad_146[0x2]; // 0x146(0x02)
	float WireframeCullThreshold; // 0x148(0x04)
	char bSupportStationarySkylight : 1; // 0x14c(0x01)
	char bSupportLowQualityLightmaps : 1; // 0x14c(0x01)
	char bSupportPointLightWholeSceneShadows : 1; // 0x14c(0x01)
	char bSupportSkyAtmosphere : 1; // 0x14c(0x01)
	char bSupportSkyAtmosphereAffectsHeightFog : 1; // 0x14c(0x01)
	char bSupportCloudShadowOnForwardLitTranslucent : 1; // 0x14c(0x01)
	char bSupportTranslucentPerObjectShadow : 1; // 0x14c(0x01)
	char bSupportCloudShadowOnSingleLayerWater : 1; // 0x14c(0x01)
	char bEnableStrata : 1; // 0x14d(0x01)
	char pad_14D_1 : 7; // 0x14d(0x01)
	char pad_14E[0x2]; // 0x14e(0x02)
	uint32_t StrataBytePerPixel; // 0x150(0x04)
	char StrataOpaqueMaterialRoughRefraction : 1; // 0x154(0x01)
	char StrataDebugAdvancedVisualizationShaders : 1; // 0x154(0x01)
	char bMaterialRoughDiffuse : 1; // 0x154(0x01)
	char bMaterialEnergyConservation : 1; // 0x154(0x01)
	char bOrderedIndependentTransparencyEnable : 1; // 0x154(0x01)
	char bSupportSkinCacheShaders : 1; // 0x154(0x01)
	char bSkipCompilingGPUSkinVF : 1; // 0x154(0x01)
	char pad_154_7 : 1; // 0x154(0x01)
	char pad_155[0x3]; // 0x155(0x03)
	enum class ESkinCacheDefaultBehavior DefaultSkinCacheBehavior; // 0x158(0x01)
	char pad_159[0x3]; // 0x159(0x03)
	float SkinCacheSceneMemoryLimitInMB; // 0x15c(0x04)
	char bMobileEnableStaticAndCSMShadowReceivers : 1; // 0x160(0x01)
	char bMobileEnableMovableLightCSMShaderCulling : 1; // 0x160(0x01)
	char bMobileForwardEnableLocalLights : 1; // 0x160(0x01)
	char bMobileForwardEnableClusteredReflections : 1; // 0x160(0x01)
	char bMobileEnableNoPrecomputedLightingCSMShader : 1; // 0x160(0x01)
	char bMobileAllowDistanceFieldShadows : 1; // 0x160(0x01)
	char bMobileAllowMovableDirectionalLights : 1; // 0x160(0x01)
	char bMobileAllowMovableSpotlightShadows : 1; // 0x160(0x01)
	char bSupport16BitBoneIndex : 1; // 0x161(0x01)
	char bGPUSkinLimit2BoneInfluences : 1; // 0x161(0x01)
	char bSupportDepthOnlyIndexBuffers : 1; // 0x161(0x01)
	char bSupportReversedIndexBuffers : 1; // 0x161(0x01)
	char bMobileAmbientOcclusion : 1; // 0x161(0x01)
	char bUseUnlimitedBoneInfluences : 1; // 0x161(0x01)
	char pad_161_6 : 2; // 0x161(0x01)
	char pad_162[0x2]; // 0x162(0x02)
	int32_t UnlimitedBonInfluencesThreshold; // 0x164(0x04)
	struct FPerPlatformInt MaxSkinBones; // 0x168(0x04)
	enum class EMobilePlanarReflectionMode MobilePlanarReflectionMode; // 0x16c(0x01)
	char pad_16D[0x3]; // 0x16d(0x03)
	char bMobileSupportsGen4TAA : 1; // 0x170(0x01)
	char pad_170_1 : 7; // 0x170(0x01)
	char pad_171[0x3]; // 0x171(0x03)
	struct FPerPlatformBool bStreamSkeletalMeshLODs; // 0x174(0x01)
	struct FPerPlatformBool bDiscardSkeletalMeshOptionalLODs; // 0x175(0x01)
	char pad_176[0x2]; // 0x176(0x02)
	struct FSoftObjectPath VisualizeCalibrationColorMaterialPath; // 0x178(0x20)
	struct FSoftObjectPath VisualizeCalibrationCustomMaterialPath; // 0x198(0x20)
	struct FSoftObjectPath VisualizeCalibrationGrayscaleMaterialPath; // 0x1b8(0x20)
};

// Class Engine.RendererOverrideSettings
// Size: 0x40 (Inherited: 0x38)
struct URendererOverrideSettings : UDeveloperSettings {
	char bSupportAllShaderPermutations : 1; // 0x38(0x01)
	char pad_38_1 : 7; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// Class Engine.SubsurfaceProfile
// Size: 0xc8 (Inherited: 0x28)
struct USubsurfaceProfile : UObject {
	struct FSubsurfaceProfileStruct Settings; // 0x28(0x9c)
	char pad_C4[0x4]; // 0xc4(0x04)
};

// Class Engine.ReplayNetConnection
// Size: 0x3d80 (Inherited: 0x3310)
struct UReplayNetConnection : UNetConnection {
	struct TArray<struct UChildConnection*> Children; // 0x48(0x10)
	struct UNetDriver* Driver; // 0x58(0x08)
	struct UPackageMap* PackageMapClass; // 0x60(0x08)
	struct UPackageMap* PackageMap; // 0x68(0x08)
	struct TArray<struct UChannel*> OpenChannels; // 0x70(0x10)
	struct TArray<struct AActor*> SentTemporaries; // 0x80(0x10)
	struct AActor* ViewTarget; // 0x90(0x08)
	struct AActor* OwningActor; // 0x98(0x08)
	int32_t MaxPacket; // 0xa0(0x04)
	char InternalAck : 1; // 0xa4(0x01)
	struct FUniqueNetIdRepl PlayerId; // 0x160(0x30)
	double LastReceiveTime; // 0x1d8(0x08)
	int32_t DefaultMaxChannelSize; // 0x13c0(0x04)
	struct TArray<struct UChannel*> ChannelsToTick; // 0x1648(0x10)
	char pad_33B8_1 : 7; // 0x33b8(0x01)
	char pad_33B9[0x9c7]; // 0x33b9(0x9c7)
};

// Class Engine.ReplaySubsystem
// Size: 0x40 (Inherited: 0x30)
struct UReplaySubsystem : UGameInstanceSubsystem {
	bool bLoadDefaultMapOnStop; // 0x30(0x01)
	char pad_31[0xf]; // 0x31(0x0f)

	void RequestCheckpoint(); // Function Engine.ReplaySubsystem.RequestCheckpoint // (None) // @ game+0xffffd25ddf830041
};

// Class Engine.ReverbEffect
// Size: 0x60 (Inherited: 0x28)
struct UReverbEffect : UObject {
	bool bBypassEarlyReflections; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	float ReflectionsDelay; // 0x2c(0x04)
	float GainHF; // 0x30(0x04)
	float ReflectionsGain; // 0x34(0x04)
	bool bBypassLateReflections; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	float LateDelay; // 0x3c(0x04)
	float DecayTime; // 0x40(0x04)
	float Density; // 0x44(0x04)
	float Diffusion; // 0x48(0x04)
	float AirAbsorptionGainHF; // 0x4c(0x04)
	float DecayHFRatio; // 0x50(0x04)
	float LateGain; // 0x54(0x04)
	float Gain; // 0x58(0x04)
	float RoomRolloffFactor; // 0x5c(0x04)
};

// Class Engine.SCS_Node
// Size: 0xd8 (Inherited: 0x28)
struct USCS_Node : UObject {
	ClassPtrProperty ComponentClass; // 0x28(0x08)
	struct UActorComponent* ComponentTemplate; // 0x30(0x08)
	struct FBlueprintCookedComponentInstancingData CookedComponentInstancingData; // 0x38(0x48)
	struct FName AttachToName; // 0x80(0x08)
	struct FName ParentComponentOrVariableName; // 0x88(0x08)
	struct FName ParentComponentOwnerClassName; // 0x90(0x08)
	bool bIsParentComponentNative; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
	struct TArray<struct USCS_Node*> ChildNodes; // 0xa0(0x10)
	struct TArray<struct FBPVariableMetaDataEntry> MetaDataArray; // 0xb0(0x10)
	struct FGuid VariableGuid; // 0xc0(0x10)
	struct FName InternalVariableName; // 0xd0(0x08)
};

// Class Engine.SimpleConstructionScript
// Size: 0xa0 (Inherited: 0x28)
struct USimpleConstructionScript : UObject {
	struct TArray<struct USCS_Node*> RootNodes; // 0x28(0x10)
	struct TArray<struct USCS_Node*> AllNodes; // 0x38(0x10)
	struct USCS_Node* DefaultSceneRootNode; // 0x48(0x08)
	char pad_50[0x50]; // 0x50(0x50)
};

// Class Engine.SkeletalMesh
// Size: 0x4e0 (Inherited: 0xd8)
struct USkeletalMesh : USkinnedAsset {
	char pad_D8[0x20]; // 0xd8(0x20)
	struct USkeleton* Skeleton; // 0xf8(0x08)
	struct FBoxSphereBounds ImportedBounds; // 0x100(0x38)
	struct FBoxSphereBounds ExtendedBounds; // 0x138(0x38)
	struct FVector PositiveBoundsExtension; // 0x170(0x18)
	struct FVector NegativeBoundsExtension; // 0x188(0x18)
	struct TArray<struct FSkeletalMaterial> Materials; // 0x1a0(0x10)
	struct TArray<struct FBoneMirrorInfo> SkelMirrorTable; // 0x1b0(0x10)
	struct TArray<struct FSkeletalMeshLODInfo> LODInfo; // 0x1c0(0x10)
	char pad_1D0[0x50]; // 0x1d0(0x50)
	struct FPerQualityLevelInt MinQualityLevelLOD; // 0x220(0x68)
	struct FPerPlatformInt MinLOD; // 0x288(0x04)
	struct FPerPlatformBool DisableBelowMinLodStripping; // 0x28c(0x01)
	enum class EAxis SkelMirrorAxis; // 0x28d(0x01)
	enum class EAxis SkelMirrorFlipAxis; // 0x28e(0x01)
	char bUseFullPrecisionUVs : 1; // 0x28f(0x01)
	char bUseHighPrecisionTangentBasis : 1; // 0x28f(0x01)
	char bHasBeenSimplified : 1; // 0x28f(0x01)
	char bHasVertexColors : 1; // 0x28f(0x01)
	char pad_28F_4 : 1; // 0x28f(0x01)
	char bEnablePerPolyCollision : 1; // 0x28f(0x01)
	char pad_28F_6 : 2; // 0x28f(0x01)
	struct UBodySetup* BodySetup; // 0x290(0x08)
	struct UPhysicsAsset* PhysicsAsset; // 0x298(0x08)
	struct UPhysicsAsset* ShadowPhysicsAsset; // 0x2a0(0x08)
	struct TArray<struct UNodeMappingContainer*> NodeMappingData; // 0x2a8(0x10)
	char bSupportRayTracing : 1; // 0x2b8(0x01)
	char pad_2B8_1 : 7; // 0x2b8(0x01)
	char pad_2B9[0x3]; // 0x2b9(0x03)
	int32_t RayTracingMinLOD; // 0x2bc(0x04)
	enum class EClothLODBiasMode ClothLODBiasMode; // 0x2c0(0x01)
	char pad_2C1[0x7]; // 0x2c1(0x07)
	struct TArray<struct UMorphTarget*> MorphTargets; // 0x2c8(0x10)
	char pad_2D8[0x178]; // 0x2d8(0x178)
	struct UAnimInstance* PostProcessAnimBlueprint; // 0x450(0x08)
	struct TArray<struct UClothingAssetBase*> MeshClothingAssets; // 0x458(0x10)
	struct FSkeletalMeshSamplingInfo SamplingInfo; // 0x468(0x30)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x498(0x10)
	struct TArray<struct USkeletalMeshSocket*> Sockets; // 0x4a8(0x10)
	char pad_4B8[0x10]; // 0x4b8(0x10)
	struct TArray<struct FSkinWeightProfileInfo> SkinWeightProfiles; // 0x4c8(0x10)
	struct UMeshDeformer* DefaultMeshDeformer; // 0x4d8(0x08)

	void SetSkeleton(struct USkeleton* InSkeleton); // Function Engine.SkeletalMesh.SetSkeleton // (None) // @ game+0xffffd276df830041
};

// Class Engine.SkeletalMeshEditorData
// Size: 0x28 (Inherited: 0x28)
struct USkeletalMeshEditorData : UObject {
};

// Class Engine.SkeletalMeshLODSettings
// Size: 0xb8 (Inherited: 0x30)
struct USkeletalMeshLODSettings : UDataAsset {
	struct FPerQualityLevelInt MinQualityLevelLOD; // 0x30(0x68)
	struct FPerPlatformInt MinLOD; // 0x98(0x04)
	struct FPerPlatformBool DisableBelowMinLodStripping; // 0x9c(0x01)
	bool bOverrideLODStreamingSettings; // 0x9d(0x01)
	struct FPerPlatformBool bSupportLODStreaming; // 0x9e(0x01)
	char pad_9F[0x1]; // 0x9f(0x01)
	struct FPerPlatformInt MaxNumStreamedLODs; // 0xa0(0x04)
	struct FPerPlatformInt MaxNumOptionalLODs; // 0xa4(0x04)
	struct TArray<struct FSkeletalMeshLODGroupSettings> LODGroups; // 0xa8(0x10)
};

// Class Engine.SkeletalMeshSimplificationSettings
// Size: 0x40 (Inherited: 0x38)
struct USkeletalMeshSimplificationSettings : UDeveloperSettings {
	struct FName SkeletalMeshReductionModuleName; // 0x38(0x08)
};

// Class Engine.ButtonStyleAsset
// Size: 0x420 (Inherited: 0x28)
struct UButtonStyleAsset : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FButtonStyle ButtonStyle; // 0x30(0x3f0)
};

// Class Engine.CheckBoxStyleAsset
// Size: 0xb00 (Inherited: 0x28)
struct UCheckBoxStyleAsset : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FCheckBoxStyle CheckBoxStyle; // 0x30(0xad0)
};

// Class Engine.SlateBrushAsset
// Size: 0x100 (Inherited: 0x28)
struct USlateBrushAsset : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FSlateBrush Brush; // 0x30(0xd0)
};

// Class Engine.SlateTextureAtlasInterface
// Size: 0x28 (Inherited: 0x28)
struct USlateTextureAtlasInterface : UInterface {
};

// Class Engine.SoundClass
// Size: 0x208 (Inherited: 0x28)
struct USoundClass : UObject {
	struct FSoundClassProperties Properties; // 0x28(0x1b8)
	struct TArray<struct USoundClass*> ChildClasses; // 0x1e0(0x10)
	struct TArray<struct FPassiveSoundMixModifier> PassiveSoundMixModifiers; // 0x1f0(0x10)
	struct USoundClass* ParentClass; // 0x200(0x08)
};

// Class Engine.SoundConcurrency
// Size: 0x48 (Inherited: 0x28)
struct USoundConcurrency : UObject {
	struct FSoundConcurrencySettings Concurrency; // 0x28(0x20)
};

// Class Engine.SoundCue
// Size: 0x558 (Inherited: 0x168)
struct USoundCue : USoundBase {
	struct USoundNode* FirstNode; // 0x168(0x08)
	float VolumeMultiplier; // 0x170(0x04)
	float PitchMultiplier; // 0x174(0x04)
	struct FSoundAttenuationSettings AttenuationOverrides; // 0x178(0x3c8)
	float SubtitlePriority; // 0x540(0x04)
	char pad_544[0x4]; // 0x544(0x04)
	char bPrimeOnLoad : 1; // 0x548(0x01)
	char bOverrideAttenuation : 1; // 0x548(0x01)
	char bExcludeFromRandomNodeBranchCulling : 1; // 0x548(0x01)
	char bHasPlayWhenSilent : 1; // 0x548(0x01)
	char pad_548_4 : 4; // 0x548(0x01)
	char pad_549[0x3]; // 0x549(0x03)
	int32_t CookedQualityIndex; // 0x54c(0x04)
	char pad_550[0x8]; // 0x550(0x08)
};

// Class Engine.SoundMix
// Size: 0x90 (Inherited: 0x28)
struct USoundMix : UObject {
	char bApplyEQ : 1; // 0x28(0x01)
	char pad_28_1 : 7; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	float EQPriority; // 0x2c(0x04)
	struct FAudioEQEffect EQSettings; // 0x30(0x40)
	struct TArray<struct FSoundClassAdjuster> SoundClassEffects; // 0x70(0x10)
	float InitialDelay; // 0x80(0x04)
	float FadeInTime; // 0x84(0x04)
	float Duration; // 0x88(0x04)
	float FadeOutTime; // 0x8c(0x04)
};

// Class Engine.SoundNodeAssetReferencer
// Size: 0x48 (Inherited: 0x48)
struct USoundNodeAssetReferencer : USoundNode {
	struct TArray<struct USoundNode*> ChildNodes; // 0x28(0x10)
};

// Class Engine.SoundNodeAttenuation
// Size: 0x420 (Inherited: 0x48)
struct USoundNodeAttenuation : USoundNode {
	struct USoundAttenuation* AttenuationSettings; // 0x48(0x08)
	struct FSoundAttenuationSettings AttenuationOverrides; // 0x50(0x3c8)
	char bOverrideAttenuation : 1; // 0x418(0x01)
	char pad_418_1 : 7; // 0x418(0x01)
	char pad_419[0x7]; // 0x419(0x07)
};

// Class Engine.SoundNodeBranch
// Size: 0x50 (Inherited: 0x48)
struct USoundNodeBranch : USoundNode {
	struct FName BoolParameterName; // 0x48(0x08)
};

// Class Engine.SoundNodeConcatenator
// Size: 0x58 (Inherited: 0x48)
struct USoundNodeConcatenator : USoundNode {
	struct TArray<float> InputVolume; // 0x48(0x10)
};

// Class Engine.SoundNodeDelay
// Size: 0x50 (Inherited: 0x48)
struct USoundNodeDelay : USoundNode {
	float DelayMin; // 0x48(0x04)
	float DelayMax; // 0x4c(0x04)
};

// Class Engine.SoundNodeDialoguePlayer
// Size: 0x70 (Inherited: 0x48)
struct USoundNodeDialoguePlayer : USoundNode {
	struct FDialogueWaveParameter DialogueWaveParameter; // 0x48(0x20)
	char bLooping : 1; // 0x68(0x01)
	char pad_68_1 : 7; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
};

// Class Engine.SoundNodeDistanceCrossFade
// Size: 0x58 (Inherited: 0x48)
struct USoundNodeDistanceCrossFade : USoundNode {
	struct TArray<struct FDistanceDatum> CrossFadeInput; // 0x48(0x10)
};

// Class Engine.SoundNodeDoppler
// Size: 0x58 (Inherited: 0x48)
struct USoundNodeDoppler : USoundNode {
	float DopplerIntensity; // 0x48(0x04)
	bool bUseSmoothing; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
	float SmoothingInterpSpeed; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// Class Engine.SoundNodeEnveloper
// Size: 0x190 (Inherited: 0x48)
struct USoundNodeEnveloper : USoundNode {
	float LoopStart; // 0x48(0x04)
	float LoopEnd; // 0x4c(0x04)
	float DurationAfterLoop; // 0x50(0x04)
	int32_t LoopCount; // 0x54(0x04)
	char bLoopIndefinitely : 1; // 0x58(0x01)
	char bLoop : 1; // 0x58(0x01)
	char pad_58_2 : 6; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct UDistributionFloatConstantCurve* VolumeInterpCurve; // 0x60(0x08)
	struct UDistributionFloatConstantCurve* PitchInterpCurve; // 0x68(0x08)
	struct FRuntimeFloatCurve VolumeCurve; // 0x70(0x88)
	struct FRuntimeFloatCurve PitchCurve; // 0xf8(0x88)
	float PitchMin; // 0x180(0x04)
	float PitchMax; // 0x184(0x04)
	float VolumeMin; // 0x188(0x04)
	float VolumeMax; // 0x18c(0x04)
};

// Class Engine.SoundNodeGroupControl
// Size: 0x58 (Inherited: 0x48)
struct USoundNodeGroupControl : USoundNode {
	struct TArray<int32_t> GroupSizes; // 0x48(0x10)
};

// Class Engine.SoundNodeLooping
// Size: 0x50 (Inherited: 0x48)
struct USoundNodeLooping : USoundNode {
	int32_t LoopCount; // 0x48(0x04)
	char bLoopIndefinitely : 1; // 0x4c(0x01)
	char pad_4C_1 : 7; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
};

// Class Engine.SoundNodeMature
// Size: 0x48 (Inherited: 0x48)
struct USoundNodeMature : USoundNode {
	struct TArray<struct USoundNode*> ChildNodes; // 0x28(0x10)
};

// Class Engine.SoundNodeMixer
// Size: 0x58 (Inherited: 0x48)
struct USoundNodeMixer : USoundNode {
	struct TArray<float> InputVolume; // 0x48(0x10)
};

// Class Engine.SoundNodeModulator
// Size: 0x58 (Inherited: 0x48)
struct USoundNodeModulator : USoundNode {
	float PitchMin; // 0x48(0x04)
	float PitchMax; // 0x4c(0x04)
	float VolumeMin; // 0x50(0x04)
	float VolumeMax; // 0x54(0x04)
};

// Class Engine.SoundNodeOscillator
// Size: 0x70 (Inherited: 0x48)
struct USoundNodeOscillator : USoundNode {
	char bModulateVolume : 1; // 0x48(0x01)
	char bModulatePitch : 1; // 0x48(0x01)
	char pad_48_2 : 6; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	float AmplitudeMin; // 0x4c(0x04)
	float AmplitudeMax; // 0x50(0x04)
	float FrequencyMin; // 0x54(0x04)
	float FrequencyMax; // 0x58(0x04)
	float OffsetMin; // 0x5c(0x04)
	float OffsetMax; // 0x60(0x04)
	float CenterMin; // 0x64(0x04)
	float CenterMax; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// Class Engine.SoundNodeParamCrossFade
// Size: 0x60 (Inherited: 0x58)
struct USoundNodeParamCrossFade : USoundNodeDistanceCrossFade {
	struct FName ParamName; // 0x58(0x08)
};

// Class Engine.SoundNodeQualityLevel
// Size: 0x50 (Inherited: 0x48)
struct USoundNodeQualityLevel : USoundNode {
	int32_t CookedQualityLevelIndex; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// Class Engine.SoundNodeRandom
// Size: 0x78 (Inherited: 0x48)
struct USoundNodeRandom : USoundNode {
	struct TArray<float> Weights; // 0x48(0x10)
	struct TArray<bool> HasBeenUsed; // 0x58(0x10)
	int32_t NumRandomUsed; // 0x68(0x04)
	int32_t PreselectAtLevelLoad; // 0x6c(0x04)
	char bShouldExcludeFromBranchCulling : 1; // 0x70(0x01)
	char bSoundCueExcludedFromBranchCulling : 1; // 0x70(0x01)
	char bRandomizeWithoutReplacement : 1; // 0x70(0x01)
	char pad_70_3 : 5; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// Class Engine.SoundNodeSoundClass
// Size: 0x58 (Inherited: 0x48)
struct USoundNodeSoundClass : USoundNode {
	struct USoundClass* SoundClassOverride; // 0x48(0x08)
	char pad_50[0x8]; // 0x50(0x08)
};

// Class Engine.SoundNodeSwitch
// Size: 0x50 (Inherited: 0x48)
struct USoundNodeSwitch : USoundNode {
	struct FName IntParameterName; // 0x48(0x08)
};

// Class Engine.SoundNodeWaveParam
// Size: 0x50 (Inherited: 0x48)
struct USoundNodeWaveParam : USoundNode {
	struct FName WaveParameterName; // 0x48(0x08)
};

// Class Engine.SoundNodeWavePlayer
// Size: 0x88 (Inherited: 0x48)
struct USoundNodeWavePlayer : USoundNodeAssetReferencer {
	struct TSoftObjectPtr<USoundWave> SoundWaveAssetPtr; // 0x48(0x30)
	struct USoundWave* SoundWave; // 0x78(0x08)
	char pad_80_0 : 1; // 0x80(0x01)
	char bLooping : 1; // 0x80(0x01)
	char pad_80_2 : 6; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
};

// Class Engine.SoundSourceBus
// Size: 0x468 (Inherited: 0x450)
struct USoundSourceBus : USoundWave {
	enum class ESourceBusChannels SourceBusChannels; // 0x450(0x01)
	char pad_451[0x3]; // 0x451(0x03)
	float SourceBusDuration; // 0x454(0x04)
	struct UAudioBus* AudioBus; // 0x458(0x08)
	char bAutoDeactivateWhenSilent : 1; // 0x460(0x01)
	char pad_460_1 : 7; // 0x460(0x01)
	char pad_461[0x7]; // 0x461(0x07)
};

// Class Engine.SoundSubmixBase
// Size: 0x40 (Inherited: 0x28)
struct USoundSubmixBase : UObject {
	bool bAutoDisable; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	float AutoDisableTime; // 0x2c(0x04)
	struct TArray<struct USoundSubmixBase*> ChildSubmixes; // 0x30(0x10)
};

// Class Engine.SoundSubmixWithParentBase
// Size: 0x48 (Inherited: 0x40)
struct USoundSubmixWithParentBase : USoundSubmixBase {
	struct USoundSubmixBase* ParentSubmix; // 0x40(0x08)
};

// Class Engine.SoundSubmix
// Size: 0x1c8 (Inherited: 0x48)
struct USoundSubmix : USoundSubmixWithParentBase {
	char bMuteWhenBackgrounded : 1; // 0x48(0x01)
	char pad_48_1 : 7; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct TArray<struct USoundEffectSubmixPreset*> SubmixEffectChain; // 0x50(0x10)
	struct USoundfieldEncodingSettingsBase* AmbisonicsPluginSettings; // 0x60(0x08)
	int32_t EnvelopeFollowerAttackTime; // 0x68(0x04)
	int32_t EnvelopeFollowerReleaseTime; // 0x6c(0x04)
	float OutputVolume; // 0x70(0x04)
	float WetLevel; // 0x74(0x04)
	float DryLevel; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct FSoundModulationDestinationSettings OutputVolumeModulation; // 0x80(0x60)
	struct FSoundModulationDestinationSettings WetLevelModulation; // 0xe0(0x60)
	struct FSoundModulationDestinationSettings DryLevelModulation; // 0x140(0x60)
	char bSendToAudioLink : 1; // 0x1a0(0x01)
	char pad_1A0_1 : 7; // 0x1a0(0x01)
	char pad_1A1[0x7]; // 0x1a1(0x07)
	struct UAudioLinkSettingsAbstract* AudioLinkSettings; // 0x1a8(0x08)
	struct FMulticastInlineDelegate OnSubmixRecordedFileDone; // 0x1b0(0x10)
	char pad_1C0[0x8]; // 0x1c0(0x08)

	void StopSpectralAnalysis(struct UObject* WorldContextObject); // Function Engine.SoundSubmix.StopSpectralAnalysis // (None) // @ game+0xffffd282df830041
};

// Class Engine.SoundfieldSubmix
// Size: 0x70 (Inherited: 0x48)
struct USoundfieldSubmix : USoundSubmixWithParentBase {
	struct FName SoundfieldEncodingFormat; // 0x48(0x08)
	struct USoundfieldEncodingSettingsBase* EncodingSettings; // 0x50(0x08)
	struct TArray<struct USoundfieldEffectBase*> SoundfieldEffectChain; // 0x58(0x10)
	struct USoundfieldEncodingSettingsBase* EncodingSettingsClass; // 0x68(0x08)
};

// Class Engine.EndpointSubmix
// Size: 0x58 (Inherited: 0x40)
struct UEndpointSubmix : USoundSubmixBase {
	struct FName EndpointType; // 0x40(0x08)
	struct UAudioEndpointSettingsBase* EndpointSettingsClass; // 0x48(0x08)
	struct UAudioEndpointSettingsBase* EndpointSettings; // 0x50(0x08)
};

// Class Engine.SoundfieldEndpointSubmix
// Size: 0x78 (Inherited: 0x40)
struct USoundfieldEndpointSubmix : USoundSubmixBase {
	struct FName SoundfieldEndpointType; // 0x40(0x08)
	struct UAudioEndpointSettingsBase* EndpointSettingsClass; // 0x48(0x08)
	struct USoundfieldEndpointSettingsBase* EndpointSettings; // 0x50(0x08)
	struct USoundfieldEncodingSettingsBase* EncodingSettingsClass; // 0x58(0x08)
	struct USoundfieldEncodingSettingsBase* EncodingSettings; // 0x60(0x08)
	struct TArray<struct USoundfieldEffectBase*> SoundfieldEffectChain; // 0x68(0x10)
};

// Class Engine.SpectatorPawnMovement
// Size: 0x178 (Inherited: 0x170)
struct USpectatorPawnMovement : UFloatingPawnMovement {
	char bIgnoreTimeDilation : 1; // 0x170(0x01)
	char pad_170_1 : 7; // 0x170(0x01)
	char pad_171[0x7]; // 0x171(0x07)
};

// Class Engine.SplineMeshActor
// Size: 0x298 (Inherited: 0x290)
struct ASplineMeshActor : AActor {
	struct USplineMeshComponent* SplineMeshComponent; // 0x290(0x08)
};

// Class Engine.StaticMeshDescriptionBulkData
// Size: 0x28 (Inherited: 0x28)
struct UStaticMeshDescriptionBulkData : UMeshDescriptionBaseBulkData {
};

// Class Engine.StereoLayerFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UStereoLayerFunctionLibrary : UBlueprintFunctionLibrary {

	void ShowSplashScreen(); // Function Engine.StereoLayerFunctionLibrary.ShowSplashScreen // (None) // @ game+0xffffd286df830041
};

// Class Engine.ActorTextureStreamingBuildDataComponent
// Size: 0xa0 (Inherited: 0xa0)
struct UActorTextureStreamingBuildDataComponent : UActorComponent {
	struct FActorComponentTickFunction PrimaryComponentTick; // 0x30(0x30)
	struct TArray<struct FName> ComponentTags; // 0x60(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x70(0x10)
	int32_t UCSSerializationIndex; // 0x84(0x04)
	char pad_F4_0 : 3; // 0xf4(0x01)
	char bNetAddressable : 1; // 0x88(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x88(0x01)
	char bReplicates : 1; // 0x88(0x01)
	char bAutoActivate : 1; // 0x8a(0x01)
	char bIsActive : 1; // 0x8a(0x01)
	char pad_F5_0 : 3; // 0xf5(0x01)
	char bEditableWhenInherited : 1; // 0x8a(0x01)
	char pad_F5_4 : 1; // 0xf5(0x01)
	char bCanEverAffectNavigation : 1; // 0x8a(0x01)
	char pad_F5_6 : 1; // 0xf5(0x01)
	char bIsEditorOnly : 1; // 0x8a(0x01)
	enum class EComponentCreationMethod CreationMethod; // 0x8d(0x01)
	struct FMulticastSparseDelegate OnComponentActivated; // 0x8e(0x01)
	struct FMulticastSparseDelegate OnComponentDeactivated; // 0x8f(0x01)
};

// Class Engine.TextureMipDataProviderFactory
// Size: 0x28 (Inherited: 0x28)
struct UTextureMipDataProviderFactory : UAssetUserData {
};

// Class Engine.AudioSubsystemCollectionRoot
// Size: 0x30 (Inherited: 0x28)
struct UAudioSubsystemCollectionRoot : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.AudioEngineSubsystem
// Size: 0x30 (Inherited: 0x30)
struct UAudioEngineSubsystem : UDynamicSubsystem {
};

// Class Engine.SubsystemBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct USubsystemBlueprintLibrary : UBlueprintFunctionLibrary {

	struct UWorldSubsystem* GetWorldSubsystem(struct UObject* ContextObject, struct UWorldSubsystem* Class); // Function Engine.SubsystemBlueprintLibrary.GetWorldSubsystem // (None) // @ game+0xffffd28cdf830041
};

// Class Engine.TargetPoint
// Size: 0x290 (Inherited: 0x290)
struct ATargetPoint : AActor {
	struct FActorTickFunction PrimaryActorTick; // 0x28(0x30)
	char bNetTemporary : 1; // 0x58(0x01)
	char pad_2C0_1 : 1; // 0x2c0(0x01)
	char bOnlyRelevantToOwner : 1; // 0x58(0x01)
	char bAlwaysRelevant : 1; // 0x58(0x01)
	char bReplicateMovement : 1; // 0x58(0x01)
	char bCallPreReplication : 1; // 0x58(0x01)
	char bCallPreReplicationForReplay : 1; // 0x58(0x01)
	char bHidden : 1; // 0x58(0x01)
	char bTearOff : 1; // 0x59(0x01)
	char bForceNetAddressable : 1; // 0x59(0x01)
	char bExchangedRoles : 1; // 0x59(0x01)
	char bNetLoadOnClient : 1; // 0x59(0x01)
	char bNetUseOwnerRelevancy : 1; // 0x59(0x01)
	char bRelevantForNetworkReplays : 1; // 0x59(0x01)
	char bRelevantForLevelBounds : 1; // 0x59(0x01)
	char bReplayRewindable : 1; // 0x59(0x01)
	char bAllowTickBeforeBeginPlay : 1; // 0x5a(0x01)
	char bAutoDestroyWhenFinished : 1; // 0x5a(0x01)
	char bCanBeDamaged : 1; // 0x5a(0x01)
	char bBlockInput : 1; // 0x5a(0x01)
	char bCollideWhenPlacing : 1; // 0x5a(0x01)
	char bFindCameraComponentWhenViewTarget : 1; // 0x5a(0x01)
	char bGenerateOverlapEventsDuringLevelStreaming : 1; // 0x5a(0x01)
	char bIgnoresOriginShifting : 1; // 0x5a(0x01)
	char bEnableAutoLODGeneration : 1; // 0x5b(0x01)
	char bIsEditorOnlyActor : 1; // 0x5b(0x01)
	char bActorSeamlessTraveled : 1; // 0x5b(0x01)
	char bReplicates : 1; // 0x5b(0x01)
	char bCanBeInCluster : 1; // 0x5b(0x01)
	char bAllowReceiveTickEventOnDedicatedServer : 1; // 0x5b(0x01)
	char pad_2C3_6 : 1; // 0x2c3(0x01)
	char bReplicateUsingRegisteredSubObjectList : 1; // 0x5b(0x01)
	char pad_2C4_0 : 7; // 0x2c4(0x01)
	char bActorEnableCollision : 1; // 0x5c(0x01)
	char bActorIsBeingDestroyed : 1; // 0x5d(0x01)
	char pad_2C5_1 : 4; // 0x2c5(0x01)
	char bAsyncPhysicsTickEnabled : 1; // 0x5d(0x01)
	enum class EActorUpdateOverlapsMethod UpdateOverlapsMethodDuringLevelStreaming; // 0x5e(0x01)
	enum class EActorUpdateOverlapsMethod DefaultUpdateOverlapsMethodDuringLevelStreaming; // 0x5f(0x01)
	float InitialLifeSpan; // 0x60(0x04)
	float CustomTimeDilation; // 0x64(0x04)
	enum class ENetRole RemoteRole; // 0x68(0x01)
	int32_t RayTracingGroupId; // 0x6c(0x04)
	struct FRepAttachment AttachmentReplication; // 0x70(0x60)
	struct FRepMovement ReplicatedMovement; // 0xd0(0x70)
	struct AActor* Owner; // 0x140(0x08)
	struct FName NetDriverName; // 0x148(0x08)
	enum class ENetRole Role; // 0x150(0x01)
	enum class ENetDormancy NetDormancy; // 0x151(0x01)
	enum class ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingMethod; // 0x152(0x01)
	enum class EAutoReceiveInput AutoReceiveInput; // 0x153(0x01)
	int32_t InputPriority; // 0x154(0x04)
	struct UInputComponent* InputComponent; // 0x160(0x08)
	float NetCullDistanceSquared; // 0x168(0x04)
	int32_t NetTag; // 0x16c(0x04)
	float NetUpdateFrequency; // 0x170(0x04)
	float MinNetUpdateFrequency; // 0x174(0x04)
	float NetPriority; // 0x178(0x04)
	struct APawn* Instigator; // 0x180(0x08)
	struct TArray<struct AActor*> Children; // 0x188(0x10)
	struct USceneComponent* RootComponent; // 0x198(0x08)
	struct TArray<struct FName> Layers; // 0x1a8(0x10)
	struct TWeakObjectPtr<struct UChildActorComponent> ParentComponent; // 0x1b8(0x08)
	struct TArray<struct FName> Tags; // 0x1c0(0x10)
	struct FMulticastSparseDelegate OnTakeAnyDamage; // 0x1d0(0x01)
	struct FMulticastSparseDelegate OnTakePointDamage; // 0x1d1(0x01)
	struct FMulticastSparseDelegate OnTakeRadialDamage; // 0x1d2(0x01)
	struct FMulticastSparseDelegate OnActorBeginOverlap; // 0x1d3(0x01)
	struct FMulticastSparseDelegate OnActorEndOverlap; // 0x1d4(0x01)
	struct FMulticastSparseDelegate OnBeginCursorOver; // 0x1d5(0x01)
	struct FMulticastSparseDelegate OnEndCursorOver; // 0x1d6(0x01)
	struct FMulticastSparseDelegate OnClicked; // 0x1d7(0x01)
	struct FMulticastSparseDelegate OnReleased; // 0x1d8(0x01)
	struct FMulticastSparseDelegate OnInputTouchBegin; // 0x1d9(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnd; // 0x1da(0x01)
	struct FMulticastSparseDelegate OnInputTouchEnter; // 0x1db(0x01)
	struct FMulticastSparseDelegate OnInputTouchLeave; // 0x1dc(0x01)
	struct FMulticastSparseDelegate OnActorHit; // 0x1dd(0x01)
	struct FMulticastSparseDelegate OnDestroyed; // 0x1de(0x01)
	struct FMulticastSparseDelegate OnEndPlay; // 0x1df(0x01)
	struct TArray<struct UActorComponent*> InstanceComponents; // 0x260(0x10)
	struct TArray<struct UActorComponent*> BlueprintCreatedComponents; // 0x270(0x10)
};

// Class Engine.AutomationTestSettings
// Size: 0x358 (Inherited: 0x28)
struct UAutomationTestSettings : UObject {
	struct TArray<struct FString> EngineTestModules; // 0x28(0x10)
	struct TArray<struct FString> EditorTestModules; // 0x38(0x10)
	struct FSoftObjectPath AutomationTestmap; // 0x48(0x20)
	struct TArray<struct FEditorMapPerformanceTestDefinition> EditorPerformanceTestMaps; // 0x68(0x10)
	struct TArray<struct FString> AssetsToOpen; // 0x78(0x10)
	struct TArray<struct FString> MapsToPIETest; // 0x88(0x10)
	bool bUseAllProjectMapsToPlayInPIE; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
	struct FBuildPromotionTestSettings BuildPromotionTest; // 0xa0(0x1f0)
	struct FMaterialEditorPromotionSettings MaterialEditorPromotionTest; // 0x290(0x30)
	struct FParticleEditorPromotionSettings ParticleEditorPromotionTest; // 0x2c0(0x10)
	struct FBlueprintEditorPromotionSettings BlueprintEditorPromotionTest; // 0x2d0(0x30)
	struct TArray<struct FString> TestLevelFolders; // 0x300(0x10)
	struct TArray<struct FExternalToolDefinition> ExternalTools; // 0x310(0x10)
	struct TArray<struct FEditorImportExportTestDefinition> ImportExportTestDefinitions; // 0x320(0x10)
	struct TArray<struct FLaunchOnTestSettings> LaunchOnSettings; // 0x330(0x10)
	struct FIntPoint DefaultScreenshotResolution; // 0x340(0x08)
	float PIETestDuration; // 0x348(0x04)
	float DefaultInteractiveFramerate; // 0x34c(0x04)
	float DefaultInteractiveFramerateWaitTime; // 0x350(0x04)
	float DefaultInteractiveFramerateDuration; // 0x354(0x04)
};

// Class Engine.TransactionDiffingTestObject
// Size: 0xa0 (Inherited: 0x28)
struct UTransactionDiffingTestObject : UObject {
	struct TArray<struct FName> NamesArray; // 0x28(0x10)
	struct FName AdditionalName; // 0x38(0x08)
	struct TArray<struct UObject*> ObjectsArray; // 0x40(0x10)
	struct UObject* AdditionalObject; // 0x50(0x08)
	struct TArray<struct TSoftObjectPtr<UObject>> SoftObjectsArray; // 0x58(0x10)
	struct TSoftObjectPtr<UObject> AdditionalSoftObject; // 0x68(0x30)
	int32_t PropertyData; // 0x98(0x04)
	char pad_9C[0x4]; // 0x9c(0x04)
};

// Class Engine.Texture2DDynamic
// Size: 0x210 (Inherited: 0x1f0)
struct UTexture2DDynamic : UTexture {
	char pad_1F0[0x8]; // 0x1f0(0x08)
	enum class EPixelFormat Format; // 0x1f8(0x01)
	char pad_1F9[0x17]; // 0x1f9(0x17)
};

// Class Engine.TextureCubeArray
// Size: 0x290 (Inherited: 0x1f0)
struct UTextureCubeArray : UTexture {
	struct FGuid LightingGuid; // 0xe0(0x10)
	int32_t LevelIndex; // 0xf0(0x04)
	int32_t LODBias; // 0xf4(0x04)
	enum class TextureCompressionSettings CompressionSettings; // 0xf8(0x01)
	enum class TextureFilter Filter; // 0xf9(0x01)
	enum class ETextureMipLoadOptions MipLoadOptions; // 0xfa(0x01)
	enum class TextureGroup LODGroup; // 0xfb(0x01)
	struct FPerPlatformFloat Downscale; // 0xfc(0x04)
	enum class ETextureDownscaleOptions DownscaleOptions; // 0x100(0x01)
	char SRGB : 1; // 0x101(0x01)
	char bNoTiling : 1; // 0x101(0x01)
	char VirtualTextureStreaming : 1; // 0x101(0x01)
	char CompressionYCoCg : 1; // 0x101(0x01)
	char bNotOfflineProcessed : 1; // 0x101(0x01)
	char bAsyncResourceReleaseHasBeenStarted : 1; // 0x101(0x01)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x108(0x10)
	char pad_221_6 : 2; // 0x221(0x01)
	char pad_222[0x6e]; // 0x222(0x6e)
};

// Class Engine.TextureEncodingProjectSettings
// Size: 0x50 (Inherited: 0x38)
struct UTextureEncodingProjectSettings : UDeveloperSettings {
	char bFinalUsesRDO : 1; // 0x38(0x01)
	char pad_38_1 : 7; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	int8_t FinalRDOLambda; // 0x3c(0x01)
	enum class ETextureEncodeEffort FinalEffortLevel; // 0x3d(0x01)
	enum class ETextureUniversalTiling FinalUniversalTiling; // 0x3e(0x01)
	char pad_3F[0x1]; // 0x3f(0x01)
	char bFastUsesRDO : 1; // 0x40(0x01)
	char pad_40_1 : 7; // 0x40(0x01)
	char pad_41[0x3]; // 0x41(0x03)
	int8_t FastRDOLambda; // 0x44(0x01)
	enum class ETextureEncodeEffort FastEffortLevel; // 0x45(0x01)
	enum class ETextureUniversalTiling FastUniversalTiling; // 0x46(0x01)
	enum class ETextureEncodeSpeed CookUsesSpeed; // 0x47(0x01)
	enum class ETextureEncodeSpeed EditorUsesSpeed; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// Class Engine.TextureEncodingUserSettings
// Size: 0x40 (Inherited: 0x38)
struct UTextureEncodingUserSettings : UDeveloperSettings {
	enum class ETextureEncodeSpeedOverride ForceEncodeSpeed; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// Class Engine.TextureLightProfile
// Size: 0x2b0 (Inherited: 0x2b0)
struct UTextureLightProfile : UTexture2D {
	float Brightness; // 0x2a8(0x04)
	float TextureMultiplier; // 0x2ac(0x04)
};

// Class Engine.TextureRenderTarget2DArray
// Size: 0x220 (Inherited: 0x200)
struct UTextureRenderTarget2DArray : UTextureRenderTarget {
	int32_t SizeX; // 0x1f8(0x04)
	int32_t SizeY; // 0x1fc(0x04)
	int32_t Slices; // 0x200(0x04)
	struct FLinearColor ClearColor; // 0x204(0x10)
	enum class EPixelFormat OverrideFormat; // 0x214(0x01)
	char bHDR : 1; // 0x215(0x01)
	char bForceLinearGamma : 1; // 0x215(0x01)
	char pad_21D_2 : 6; // 0x21d(0x01)
	char pad_21E[0x2]; // 0x21e(0x02)
};

// Class Engine.TextureRenderTargetCube
// Size: 0x210 (Inherited: 0x200)
struct UTextureRenderTargetCube : UTextureRenderTarget {
	int32_t SizeX; // 0x1f8(0x04)
	struct FLinearColor ClearColor; // 0x1fc(0x10)
	enum class EPixelFormat OverrideFormat; // 0x20c(0x01)
	char bHDR : 1; // 0x20d(0x01)
	char bForceLinearGamma : 1; // 0x20d(0x01)
};

// Class Engine.TextureRenderTargetVolume
// Size: 0x220 (Inherited: 0x200)
struct UTextureRenderTargetVolume : UTextureRenderTarget {
	int32_t SizeX; // 0x1f8(0x04)
	int32_t SizeY; // 0x1fc(0x04)
	int32_t SizeZ; // 0x200(0x04)
	struct FLinearColor ClearColor; // 0x204(0x10)
	enum class EPixelFormat OverrideFormat; // 0x214(0x01)
	char bHDR : 1; // 0x215(0x01)
	char bForceLinearGamma : 1; // 0x215(0x01)
	char pad_21D_2 : 6; // 0x21d(0x01)
	char pad_21E[0x2]; // 0x21e(0x02)
};

// Class Engine.TimelineTemplate
// Size: 0xb8 (Inherited: 0x28)
struct UTimelineTemplate : UObject {
	float TimelineLength; // 0x28(0x04)
	enum class ETimelineLengthMode LengthMode; // 0x2c(0x01)
	char bAutoPlay : 1; // 0x2d(0x01)
	char bLoop : 1; // 0x2d(0x01)
	char bReplicated : 1; // 0x2d(0x01)
	char bIgnoreTimeDilation : 1; // 0x2d(0x01)
	char pad_2D_4 : 4; // 0x2d(0x01)
	char pad_2E[0x2]; // 0x2e(0x02)
	struct TArray<struct FTTEventTrack> EventTracks; // 0x30(0x10)
	struct TArray<struct FTTFloatTrack> FloatTracks; // 0x40(0x10)
	struct TArray<struct FTTVectorTrack> VectorTracks; // 0x50(0x10)
	struct TArray<struct FTTLinearColorTrack> LinearColorTracks; // 0x60(0x10)
	struct TArray<struct FBPVariableMetaDataEntry> MetaDataArray; // 0x70(0x10)
	struct FGuid TimelineGuid; // 0x80(0x10)
	enum class ETickingGroup TimelineTickGroup; // 0x90(0x01)
	char pad_91[0x3]; // 0x91(0x03)
	struct FName VariableName; // 0x94(0x08)
	struct FName DirectionPropertyName; // 0x9c(0x08)
	struct FName UpdateFunctionName; // 0xa4(0x08)
	struct FName FinishedFunctionName; // 0xac(0x08)
	char pad_B4[0x4]; // 0xb4(0x04)
};

// Class Engine.TriggerVolume
// Size: 0x2c8 (Inherited: 0x2c8)
struct ATriggerVolume : AVolume {
	enum class EBrushType BrushType; // 0x290(0x01)
	struct FColor BrushColor; // 0x294(0x04)
	int32_t PolyFlags; // 0x298(0x04)
	char bColored : 1; // 0x29c(0x01)
	char bSolidWhenSelected : 1; // 0x29c(0x01)
	char bPlaceableFromClassBrowser : 1; // 0x29c(0x01)
	char bNotForClientOrServer : 1; // 0x29c(0x01)
	struct UModel* Brush; // 0x2a0(0x08)
	struct UBrushComponent* BrushComponent; // 0x2a8(0x08)
	char bInManipulation : 1; // 0x2b0(0x01)
	struct TArray<struct FGeomSelection> SavedSelections; // 0x2b8(0x10)
};

// Class Engine.UserDefinedEnum
// Size: 0xb8 (Inherited: 0x68)
struct UUserDefinedEnum : UEnum {
	struct TMap<struct FName, struct FText> DisplayNameMap; // 0x68(0x50)
};

// Class Engine.UserInterfaceSettings
// Size: 0x2b0 (Inherited: 0x38)
struct UUserInterfaceSettings : UDeveloperSettings {
	enum class ERenderFocusRule RenderFocusRule; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct TMap<enum class EMouseCursor, struct FHardwareCursorReference> HardwareCursors; // 0x40(0x50)
	struct TMap<enum class EMouseCursor, struct FSoftClassPath> SoftwareCursors; // 0x90(0x50)
	struct FSoftClassPath DefaultCursor; // 0xe0(0x20)
	struct FSoftClassPath TextEditBeamCursor; // 0x100(0x20)
	struct FSoftClassPath CrosshairsCursor; // 0x120(0x20)
	struct FSoftClassPath HandCursor; // 0x140(0x20)
	struct FSoftClassPath GrabHandCursor; // 0x160(0x20)
	struct FSoftClassPath GrabHandClosedCursor; // 0x180(0x20)
	struct FSoftClassPath SlashedCircleCursor; // 0x1a0(0x20)
	float ApplicationScale; // 0x1c0(0x04)
	enum class EUIScalingRule UIScaleRule; // 0x1c4(0x01)
	char pad_1C5[0x3]; // 0x1c5(0x03)
	struct FSoftClassPath CustomScalingRuleClass; // 0x1c8(0x20)
	struct FRuntimeFloatCurve UIScaleCurve; // 0x1e8(0x88)
	bool bAllowHighDPIInGameMode; // 0x270(0x01)
	char pad_271[0x3]; // 0x271(0x03)
	struct FIntPoint DesignScreenSize; // 0x274(0x08)
	bool bLoadWidgetsOnDedicatedServer; // 0x27c(0x01)
	char pad_27D[0x3]; // 0x27d(0x03)
	struct TArray<struct UObject*> CursorClasses; // 0x280(0x10)
	ClassPtrProperty CustomScalingRuleClassInstance; // 0x290(0x08)
	struct UDPICustomScalingRule* CustomScalingRule; // 0x298(0x08)
	char pad_2A0[0x10]; // 0x2a0(0x10)
};

// Class Engine.Canvas
// Size: 0x390 (Inherited: 0x28)
struct UCanvas : UObject {
	float OrgX; // 0x28(0x04)
	float OrgY; // 0x2c(0x04)
	float ClipX; // 0x30(0x04)
	float ClipY; // 0x34(0x04)
	struct FColor DrawColor; // 0x38(0x04)
	char bCenterX : 1; // 0x3c(0x01)
	char bCenterY : 1; // 0x3c(0x01)
	char bNoSmooth : 1; // 0x3c(0x01)
	char pad_3C_3 : 5; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
	int32_t SizeX; // 0x40(0x04)
	int32_t SizeY; // 0x44(0x04)
	char pad_48[0x8]; // 0x48(0x08)
	struct FPlane ColorModulate; // 0x50(0x20)
	struct UTexture2D* DefaultTexture; // 0x70(0x08)
	struct UTexture2D* GradientTexture0; // 0x78(0x08)
	struct UReporterGraph* ReporterGraph; // 0x80(0x08)
	char pad_88[0x308]; // 0x88(0x308)

	struct FVector2D K2_TextSize(struct UFont* RenderFont, struct FString RenderText, struct FVector2D Scale); // Function Engine.Canvas.K2_TextSize // (None) // @ game+0xffffd299df830041
};

// Class Engine.Console
// Size: 0x130 (Inherited: 0x28)
struct UConsole : UObject {
	char pad_28[0x10]; // 0x28(0x10)
	struct ULocalPlayer* ConsoleTargetPlayer; // 0x38(0x08)
	struct UTexture2D* DefaultTexture_Black; // 0x40(0x08)
	struct UTexture2D* DefaultTexture_White; // 0x48(0x08)
	char pad_50[0x18]; // 0x50(0x18)
	struct TArray<struct FString> HistoryBuffer; // 0x68(0x10)
	char pad_78[0xb8]; // 0x78(0xb8)
};

// Class Engine.InputSettings
// Size: 0x140 (Inherited: 0x28)
struct UInputSettings : UObject {
	struct TArray<struct FInputAxisConfigEntry> AxisConfig; // 0x28(0x10)
	char bAltEnterTogglesFullscreen : 1; // 0x38(0x01)
	char bF11TogglesFullscreen : 1; // 0x38(0x01)
	char bUseMouseForTouch : 1; // 0x38(0x01)
	char bEnableMouseSmoothing : 1; // 0x38(0x01)
	char bEnableFOVScaling : 1; // 0x38(0x01)
	char bCaptureMouseOnLaunch : 1; // 0x38(0x01)
	char bEnableLegacyInputScales : 1; // 0x38(0x01)
	char bEnableMotionControls : 1; // 0x38(0x01)
	char bFilterInputByPlatformUser : 1; // 0x39(0x01)
	char bShouldFlushPressedKeysOnViewportFocusLost : 1; // 0x39(0x01)
	char bEnableDynamicComponentInputBinding : 1; // 0x39(0x01)
	char bAlwaysShowTouchInterface : 1; // 0x39(0x01)
	char bShowConsoleOnFourFingerTap : 1; // 0x39(0x01)
	char bEnableGestureRecognizer : 1; // 0x39(0x01)
	char bUseAutocorrect : 1; // 0x39(0x01)
	char pad_39_7 : 1; // 0x39(0x01)
	char pad_3A[0x6]; // 0x3a(0x06)
	struct TArray<struct FString> ExcludedAutocorrectOS; // 0x40(0x10)
	struct TArray<struct FString> ExcludedAutocorrectCultures; // 0x50(0x10)
	struct TArray<struct FString> ExcludedAutocorrectDeviceModels; // 0x60(0x10)
	enum class EMouseCaptureMode DefaultViewportMouseCaptureMode; // 0x70(0x01)
	enum class EMouseLockMode DefaultViewportMouseLockMode; // 0x71(0x01)
	char pad_72[0x2]; // 0x72(0x02)
	float FOVScale; // 0x74(0x04)
	float DoubleClickTime; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
	struct TArray<struct FInputActionKeyMapping> ActionMappings; // 0x80(0x10)
	struct TArray<struct FInputAxisKeyMapping> AxisMappings; // 0x90(0x10)
	struct TArray<struct FInputActionSpeechMapping> SpeechMappings; // 0xa0(0x10)
	struct TSoftClassPtr<UObject> DefaultPlayerInputClass; // 0xb0(0x30)
	struct TSoftClassPtr<UObject> DefaultInputComponentClass; // 0xe0(0x30)
	struct FSoftObjectPath DefaultTouchInterface; // 0x110(0x20)
	struct TArray<struct FKey> ConsoleKeys; // 0x130(0x10)

	void SaveKeyMappings(); // Function Engine.InputSettings.SaveKeyMappings // (None) // @ game+0xffffd2a4df830041
};

// Class Engine.VectorFieldVolume
// Size: 0x298 (Inherited: 0x290)
struct AVectorFieldVolume : AActor {
	struct UVectorFieldComponent* VectorFieldComponent; // 0x290(0x08)
};

// Class Engine.TireType
// Size: 0x38 (Inherited: 0x30)
struct UTireType : UDataAsset {
	float FrictionScale; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class Engine.VisualLoggerAutomationTests
// Size: 0x28 (Inherited: 0x28)
struct UVisualLoggerAutomationTests : UObject {
};

// Class Engine.VisualLoggerFilterVolume
// Size: 0x2c8 (Inherited: 0x2c8)
struct AVisualLoggerFilterVolume : AVolume {
	enum class EBrushType BrushType; // 0x290(0x01)
	struct FColor BrushColor; // 0x294(0x04)
	int32_t PolyFlags; // 0x298(0x04)
	char bColored : 1; // 0x29c(0x01)
	char bSolidWhenSelected : 1; // 0x29c(0x01)
	char bPlaceableFromClassBrowser : 1; // 0x29c(0x01)
	char bNotForClientOrServer : 1; // 0x29c(0x01)
	struct UModel* Brush; // 0x2a0(0x08)
	struct UBrushComponent* BrushComponent; // 0x2a8(0x08)
	char bInManipulation : 1; // 0x2b0(0x01)
	struct TArray<struct FGeomSelection> SavedSelections; // 0x2b8(0x10)
};

// Class Engine.VisualLoggerKismetLibrary
// Size: 0x28 (Inherited: 0x28)
struct UVisualLoggerKismetLibrary : UBlueprintFunctionLibrary {

	void RedirectVislog(struct UObject* SourceOwner, struct UObject* DestinationOwner); // Function Engine.VisualLoggerKismetLibrary.RedirectVislog // (None) // @ game+0xffffd2aadf830041
};

// Class Engine.VoiceChannel
// Size: 0x78 (Inherited: 0x68)
struct UVoiceChannel : UChannel {
	struct UNetConnection* Connection; // 0x28(0x08)
	char pad_70[0x8]; // 0x70(0x08)
};

// Class Engine.VOIPTalker
// Size: 0xe0 (Inherited: 0xa0)
struct UVOIPTalker : UActorComponent {
	struct FVoiceSettings Settings; // 0xa0(0x18)
	char pad_B8[0x28]; // 0xb8(0x28)

	void RegisterWithPlayerState(struct APlayerState* OwningState); // Function Engine.VOIPTalker.RegisterWithPlayerState // (None) // @ game+0xffffd2afdf830041
};

// Class Engine.VOIPStatics
// Size: 0x28 (Inherited: 0x28)
struct UVOIPStatics : UBlueprintFunctionLibrary {

	void SetMicThreshold(float InThreshold); // Function Engine.VOIPStatics.SetMicThreshold // (None) // @ game+0xffffd2b0df830041
};

// Class Engine.VolumeTexture
// Size: 0x2a0 (Inherited: 0x1f0)
struct UVolumeTexture : UTexture {
	char pad_1F0[0xa0]; // 0x1f0(0xa0)
	enum class TextureAddress AddressMode; // 0x290(0x01)
	char pad_291[0xf]; // 0x291(0x0f)
};

// Class Engine.VolumetricLightmapDensityVolume
// Size: 0x2d0 (Inherited: 0x2c8)
struct AVolumetricLightmapDensityVolume : AVolume {
	struct FInt32Interval AllowedMipLevelRange; // 0x2c8(0x08)
};

// Class Engine.LightMapVirtualTexture2D
// Size: 0x2c0 (Inherited: 0x2b0)
struct ULightMapVirtualTexture2D : UTexture2D {
	struct TArray<int8_t> TypeToLayer; // 0x2a8(0x10)
};

// Class Engine.RuntimeVirtualTexture
// Size: 0xe0 (Inherited: 0x28)
struct URuntimeVirtualTexture : UObject {
	int32_t TileCount; // 0x28(0x04)
	int32_t TileSize; // 0x2c(0x04)
	int32_t TileBorderSize; // 0x30(0x04)
	enum class ERuntimeVirtualTextureMaterialType MaterialType; // 0x34(0x01)
	bool bCompressTextures; // 0x35(0x01)
	bool bUseLowQualityCompression; // 0x36(0x01)
	bool bClearTextures; // 0x37(0x01)
	bool bSinglePhysicalSpace; // 0x38(0x01)
	bool bPrivateSpace; // 0x39(0x01)
	bool bAdaptive; // 0x3a(0x01)
	bool bContinuousUpdate; // 0x3b(0x01)
	int32_t RemoveLowMips; // 0x3c(0x04)
	enum class TextureGroup LODGroup; // 0x40(0x01)
	char pad_41[0x3]; // 0x41(0x03)
	int32_t Size; // 0x44(0x04)
	struct URuntimeVirtualTextureStreamingProxy* StreamingTexture; // 0x48(0x08)
	char pad_50[0x90]; // 0x50(0x90)

	int32_t GetTileSize(); // Function Engine.RuntimeVirtualTexture.GetTileSize // (None) // @ game+0xffffd2b5df830041
};

// Class Engine.RuntimeVirtualTextureVolume
// Size: 0x298 (Inherited: 0x290)
struct ARuntimeVirtualTextureVolume : AActor {
	struct URuntimeVirtualTextureComponent* VirtualTextureComponent; // 0x290(0x08)
};

// Class Engine.VirtualTexture
// Size: 0x28 (Inherited: 0x28)
struct UVirtualTexture : UObject {
};

// Class Engine.LightMapVirtualTexture
// Size: 0x28 (Inherited: 0x28)
struct ULightMapVirtualTexture : UVirtualTexture {
};

// Class Engine.RuntimeVirtualTextureStreamingProxy
// Size: 0x2b0 (Inherited: 0x2b0)
struct URuntimeVirtualTextureStreamingProxy : UTexture2D {
	int32_t FirstResourceMemMip; // 0x1f0(0x04)
	char bTemporarilyDisableStreaming : 1; // 0x1f4(0x01)
	enum class TextureAddress AddressX; // 0x1f5(0x01)
	enum class TextureAddress AddressY; // 0x1f6(0x01)
	struct FIntPoint ImportedSize; // 0x1f8(0x08)
};

// Class Engine.VirtualTexture2D
// Size: 0x2c0 (Inherited: 0x2b0)
struct UVirtualTexture2D : UTexture2D {
	struct FVirtualTextureBuildSettings Settings; // 0x2a8(0x08)
	bool bContinuousUpdate; // 0x2b0(0x01)
	bool bSinglePhysicalSpace; // 0x2b1(0x01)
	char pad_2BA[0x6]; // 0x2ba(0x06)
};

// Class Engine.VirtualTextureBuilder
// Size: 0x38 (Inherited: 0x28)
struct UVirtualTextureBuilder : UObject {
	struct UVirtualTexture2D* Texture; // 0x28(0x08)
	uint64_t BuildHash; // 0x30(0x08)
};

// Class Engine.VirtualTexturePoolConfig
// Size: 0x40 (Inherited: 0x28)
struct UVirtualTexturePoolConfig : UObject {
	int32_t DefaultSizeInMegabyte; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct TArray<struct FVirtualTextureSpacePoolConfig> Pools; // 0x30(0x10)
};

// Class Engine.WindDirectionalSource
// Size: 0x298 (Inherited: 0x290)
struct AWindDirectionalSource : AInfo {
	struct UWindDirectionalSourceComponent* Component; // 0x290(0x08)
};

// Class Engine.WorldComposition
// Size: 0x68 (Inherited: 0x28)
struct UWorldComposition : UObject {
	char pad_28[0x20]; // 0x28(0x20)
	struct TArray<struct ULevelStreaming*> TilesStreaming; // 0x48(0x10)
	double TilesStreamingTimeThreshold; // 0x58(0x08)
	bool bLoadAllTilesDuringCinematic; // 0x60(0x01)
	bool bRebaseOriginIn3DSpace; // 0x61(0x01)
	char pad_62[0x2]; // 0x62(0x02)
	float RebaseOriginDistance; // 0x64(0x04)
};

// Class Engine.WorldPartitionBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UWorldPartitionBlueprintLibrary : UBlueprintFunctionLibrary {

	void UnloadActors(struct TArray<struct FGuid>& InActorsToLoad); // Function Engine.WorldPartitionBlueprintLibrary.UnloadActors // (None) // @ game+0xffffd2bddf830041
};

// Class Engine.ActorDescContainer
// Size: 0x30 (Inherited: 0x28)
struct UActorDescContainer : UObject {
	struct UWorld* World; // 0x28(0x08)
};

// Class Engine.ContentBundleDescriptor
// Size: 0x58 (Inherited: 0x28)
struct UContentBundleDescriptor : UObject {
	struct FString DisplayName; // 0x28(0x10)
	struct FGuid Guid; // 0x38(0x10)
	struct FString PackageRoot; // 0x48(0x10)
};

// Class Engine.ContentBundleUnsavedActorMonitor
// Size: 0x28 (Inherited: 0x28)
struct UContentBundleUnsavedActorMonitor : UObject {
};

// Class Engine.ContentBundleEngineSubsystem
// Size: 0xa0 (Inherited: 0x30)
struct UContentBundleEngineSubsystem : UEngineSubsystem {
	char pad_30[0x70]; // 0x30(0x70)
};

// Class Engine.ContentBundleManager
// Size: 0x38 (Inherited: 0x28)
struct UContentBundleManager : UObject {
	char pad_28[0x10]; // 0x28(0x10)
};

// Class Engine.ContentBundleDuplicateForPIEHelper
// Size: 0x28 (Inherited: 0x28)
struct UContentBundleDuplicateForPIEHelper : UObject {
};

// Class Engine.WorldDataLayers
// Size: 0x5b8 (Inherited: 0x290)
struct AWorldDataLayers : AInfo {
	char pad_290[0xa0]; // 0x290(0xa0)
	struct TSet<struct UDataLayerInstance*> DataLayerInstances; // 0x330(0x50)
	struct TMap<struct FName, struct TWeakObjectPtr<struct UDataLayerInstance>> DeprecatedDataLayerNameToDataLayerInstance; // 0x380(0x50)
	struct TSet<struct UDataLayer*> WorldDataLayers; // 0x3d0(0x50)
	struct TArray<struct FName> RepActiveDataLayerNames; // 0x420(0x10)
	struct TArray<struct FName> RepLoadedDataLayerNames; // 0x430(0x10)
	char pad_440[0xa0]; // 0x440(0xa0)
	struct TArray<struct FName> RepEffectiveActiveDataLayerNames; // 0x4e0(0x10)
	struct TArray<struct FName> RepEffectiveLoadedDataLayerNames; // 0x4f0(0x10)
	char pad_500[0xb8]; // 0x500(0xb8)

	void OnRep_LoadedDataLayerNames(); // Function Engine.WorldDataLayers.OnRep_LoadedDataLayerNames // (None) // @ game+0xffffd2eadf830041
};

// Class Engine.DataLayer
// Size: 0x58 (Inherited: 0x28)
struct UDataLayer : UObject {
	struct FName DataLayerLabel; // 0x28(0x08)
	char bIsRuntime : 1; // 0x30(0x01)
	char pad_30_1 : 7; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	enum class EDataLayerRuntimeState InitialRuntimeState; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
	struct FColor DebugColor; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct UDataLayer* Parent; // 0x40(0x08)
	struct TArray<struct UDataLayer*> Children; // 0x48(0x10)

	bool IsVisible(); // Function Engine.DataLayer.IsVisible // (None) // @ game+0xffffd2c8df830041
};

// Class Engine.DataLayerAsset
// Size: 0x30 (Inherited: 0x28)
struct UDataLayerAsset : UObject {
	enum class EDataLayerType DataLayerType; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	struct FColor DebugColor; // 0x2c(0x04)

	bool IsRuntime(); // Function Engine.DataLayerAsset.IsRuntime // (None) // @ game+0xffffd2cbdf830041
};

// Class Engine.DataLayerInstance
// Size: 0x48 (Inherited: 0x28)
struct UDataLayerInstance : UObject {
	enum class EDataLayerRuntimeState InitialRuntimeState; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct UDataLayerInstance* Parent; // 0x30(0x08)
	struct TArray<struct UDataLayerInstance*> Children; // 0x38(0x10)

	bool IsVisible(); // Function Engine.DataLayerInstance.IsVisible // (None) // @ game+0xffffd2d2df830041
};

// Class Engine.DataLayerInstanceWithAsset
// Size: 0x50 (Inherited: 0x48)
struct UDataLayerInstanceWithAsset : UDataLayerInstance {
	struct UDataLayerAsset* DataLayerAsset; // 0x48(0x08)
};

// Class Engine.DataLayerSubsystem
// Size: 0xa0 (Inherited: 0x30)
struct UDataLayerSubsystem : UWorldSubsystem {
	struct FMulticastInlineDelegate OnDataLayerRuntimeStateChanged; // 0x30(0x10)
	char pad_40[0x60]; // 0x40(0x60)

	void SetDataLayerStateByLabel(struct FName& InDataLayerLabel, enum class EDataLayerState InState); // Function Engine.DataLayerSubsystem.SetDataLayerStateByLabel // (None) // @ game+0xffffd2e5df830041
};

// Class Engine.DeprecatedDataLayerInstance
// Size: 0x60 (Inherited: 0x48)
struct UDeprecatedDataLayerInstance : UDataLayerInstance {
	struct FName Label; // 0x48(0x08)
	struct FName DeprecatedDataLayerFName; // 0x50(0x08)
	enum class EDataLayerType DataLayerType; // 0x58(0x01)
	char pad_59[0x3]; // 0x59(0x03)
	struct FColor DebugColor; // 0x5c(0x04)
};

// Class Engine.WorldPartitionHLOD
// Size: 0x2d0 (Inherited: 0x290)
struct AWorldPartitionHLOD : AActor {
	uint32_t LODLevel; // 0x290(0x04)
	bool bRequireWarmup; // 0x294(0x01)
	char pad_295[0x3]; // 0x295(0x03)
	struct TSoftObjectPtr<UWorldPartitionRuntimeCell> SourceCell; // 0x298(0x30)
	struct FName SourceCellName; // 0x2c8(0x08)
};

// Class Engine.HLODBuilderSettings
// Size: 0x28 (Inherited: 0x28)
struct UHLODBuilderSettings : UObject {
};

// Class Engine.NullHLODBuilder
// Size: 0x28 (Inherited: 0x28)
struct UNullHLODBuilder : UHLODBuilder {
};

// Class Engine.HLODLayer
// Size: 0x80 (Inherited: 0x28)
struct UHLODLayer : UObject {
	enum class EHLODLayerType LayerType; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct UHLODBuilder* HLODBuilderClass; // 0x30(0x08)
	struct UHLODBuilderSettings* HLODBuilderSettings; // 0x38(0x08)
	char bIsSpatiallyLoaded : 1; // 0x40(0x01)
	char pad_40_1 : 7; // 0x40(0x01)
	char pad_41[0x3]; // 0x41(0x03)
	int32_t CellSize; // 0x44(0x04)
	double LoadingRange; // 0x48(0x08)
	struct TSoftObjectPtr<UHLODLayer> ParentLayer; // 0x50(0x30)
};

// Class Engine.HLODSubsystem
// Size: 0x90 (Inherited: 0x30)
struct UHLODSubsystem : UWorldSubsystem {
	char pad_30[0x60]; // 0x30(0x60)
};

// Class Engine.NavigationDataChunkActor
// Size: 0x2d8 (Inherited: 0x290)
struct ANavigationDataChunkActor : APartitionActor {
	struct TArray<struct UNavigationDataChunk*> NavDataChunks; // 0x290(0x10)
	struct FBox DataChunkActorBounds; // 0x2a0(0x38)
};

// Class Engine.WorldPartition
// Size: 0x110 (Inherited: 0x28)
struct UWorldPartition : UObject {
	char pad_28[0x38]; // 0x28(0x38)
	struct UActorDescContainer* ActorDescContainer; // 0x60(0x08)
	struct UWorldPartitionRuntimeHash* RuntimeHash; // 0x68(0x08)
	struct UWorld* World; // 0x70(0x08)
	bool bEnableStreaming; // 0x78(0x01)
	char pad_79[0x7f]; // 0x79(0x7f)
	struct UWorldPartitionStreamingPolicy* StreamingPolicy; // 0xf8(0x08)
	char pad_100[0x10]; // 0x100(0x10)
};

// Class Engine.WorldPartitionActorLoaderInterface
// Size: 0x28 (Inherited: 0x28)
struct UWorldPartitionActorLoaderInterface : UInterface {
};

// Class Engine.WorldPartitionEditorHash
// Size: 0x28 (Inherited: 0x28)
struct UWorldPartitionEditorHash : UObject {
};

// Class Engine.WorldPartitionEditorPerProjectUserSettings
// Size: 0x28 (Inherited: 0x28)
struct UWorldPartitionEditorPerProjectUserSettings : UObject {
};

// Class Engine.WorldPartitionEditorSpatialHash
// Size: 0x28 (Inherited: 0x28)
struct UWorldPartitionEditorSpatialHash : UWorldPartitionEditorHash {
};

// Class Engine.WorldPartitionLevelStreamingDynamic
// Size: 0x1d0 (Inherited: 0x1b0)
struct UWorldPartitionLevelStreamingDynamic : ULevelStreamingDynamic {
	bool bShouldBeAlwaysLoaded; // 0x1b0(0x01)
	char pad_1B1[0x3]; // 0x1b1(0x03)
	struct TWeakObjectPtr<struct UWorldPartitionRuntimeLevelStreamingCell> StreamingCell; // 0x1b4(0x08)
	struct TWeakObjectPtr<struct UWorldPartition> OuterWorldPartition; // 0x1bc(0x08)
	char pad_1C4[0xc]; // 0x1c4(0x0c)
};

// Class Engine.WorldPartitionStreamingPolicy
// Size: 0x1f8 (Inherited: 0x28)
struct UWorldPartitionStreamingPolicy : UObject {
	char pad_28[0x1d0]; // 0x28(0x1d0)
};

// Class Engine.WorldPartitionLevelStreamingPolicy
// Size: 0x248 (Inherited: 0x1f8)
struct UWorldPartitionLevelStreamingPolicy : UWorldPartitionStreamingPolicy {
	struct TMap<struct FName, struct FName> SubObjectsToCellRemapping; // 0x1f8(0x50)
};

// Class Engine.WorldPartitionMiniMap
// Size: 0x360 (Inherited: 0x290)
struct AWorldPartitionMiniMap : AInfo {
	struct FBox MiniMapWorldBounds; // 0x290(0x38)
	struct FBox2D UVOffset; // 0x2c8(0x28)
	struct UTexture2D* MiniMapTexture; // 0x2f0(0x08)
	struct TSet<struct FActorDataLayer> ExcludedDataLayers; // 0x2f8(0x50)
	int32_t WorldUnitsPerPixel; // 0x348(0x04)
	int32_t BuilderCellSize; // 0x34c(0x04)
	enum class ESceneCaptureSource CaptureSource; // 0x350(0x01)
	char pad_351[0x3]; // 0x351(0x03)
	uint32_t CaptureWarmupFrames; // 0x354(0x04)
	int32_t MiniMapTileSize; // 0x358(0x04)
	char pad_35C[0x4]; // 0x35c(0x04)
};

// Class Engine.WorldPartitionMiniMapVolume
// Size: 0x2c8 (Inherited: 0x2c8)
struct AWorldPartitionMiniMapVolume : AVolume {
	enum class EBrushType BrushType; // 0x290(0x01)
	struct FColor BrushColor; // 0x294(0x04)
	int32_t PolyFlags; // 0x298(0x04)
	char bColored : 1; // 0x29c(0x01)
	char bSolidWhenSelected : 1; // 0x29c(0x01)
	char bPlaceableFromClassBrowser : 1; // 0x29c(0x01)
	char bNotForClientOrServer : 1; // 0x29c(0x01)
	struct UModel* Brush; // 0x2a0(0x08)
	struct UBrushComponent* BrushComponent; // 0x2a8(0x08)
	char bInManipulation : 1; // 0x2b0(0x01)
	struct TArray<struct FGeomSelection> SavedSelections; // 0x2b8(0x10)
};

// Class Engine.WorldPartitionReplay
// Size: 0x2b0 (Inherited: 0x290)
struct AWorldPartitionReplay : AActor {
	struct TArray<struct FName> StreamingSourceNames; // 0x290(0x10)
	char pad_2A0[0x10]; // 0x2a0(0x10)
};

// Class Engine.WorldPartitionRuntimeCell
// Size: 0xe8 (Inherited: 0x28)
struct UWorldPartitionRuntimeCell : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	bool bIsAlwaysLoaded; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct TArray<struct FName> DataLayers; // 0x38(0x10)
	struct FBox ContentBounds; // 0x48(0x38)
	struct FWorldPartitionRuntimeCellDebugInfo DebugInfo; // 0x80(0x30)
	int32_t Priority; // 0xb0(0x04)
	bool bClientOnlyVisible; // 0xb4(0x01)
	bool bIsHLOD; // 0xb5(0x01)
	bool bBlockOnSlowLoading; // 0xb6(0x01)
	char pad_B7[0x1]; // 0xb7(0x01)
	struct FGuid ContentBundleID; // 0xb8(0x10)
	char pad_C8[0x20]; // 0xc8(0x20)
};

// Class Engine.RuntimeHashExternalStreamingObjectBase
// Size: 0x90 (Inherited: 0x28)
struct URuntimeHashExternalStreamingObjectBase : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct TSoftObjectPtr<UWorld> OwningWorld; // 0x30(0x30)
	struct TSoftObjectPtr<UWorld> OuterWorld; // 0x60(0x30)
};

// Class Engine.WorldPartitionRuntimeHash
// Size: 0x30 (Inherited: 0x28)
struct UWorldPartitionRuntimeHash : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class Engine.WorldPartitionRuntimeSpatialHashCell
// Size: 0x138 (Inherited: 0xe8)
struct UWorldPartitionRuntimeSpatialHashCell : UWorldPartitionRuntimeCell {
	struct FVector Position; // 0xe8(0x18)
	float Extent; // 0x100(0x04)
	int32_t Level; // 0x104(0x04)
	char pad_108[0x30]; // 0x108(0x30)
};

// Class Engine.WorldPartitionRuntimeLevelStreamingCell
// Size: 0x140 (Inherited: 0x138)
struct UWorldPartitionRuntimeLevelStreamingCell : UWorldPartitionRuntimeSpatialHashCell {
	struct UWorldPartitionLevelStreamingDynamic* LevelStreaming; // 0x138(0x08)

	void OnLevelShown(); // Function Engine.WorldPartitionRuntimeLevelStreamingCell.OnLevelShown // (None) // @ game+0xffffd2ecdf830041
};

// Class Engine.SpatialHashRuntimeGridInfo
// Size: 0x298 (Inherited: 0x290)
struct ASpatialHashRuntimeGridInfo : AInfo {
	struct FSpatialHashRuntimeGrid GridSettings; // 0x290(0x01)
	char pad_291[0x7]; // 0x291(0x07)
};

// Class Engine.RuntimeSpatialHashExternalStreamingObject
// Size: 0xf0 (Inherited: 0x90)
struct URuntimeSpatialHashExternalStreamingObject : URuntimeHashExternalStreamingObjectBase {
	struct TArray<struct FSpatialHashStreamingGrid> StreamingGrids; // 0x90(0x10)
	struct TMap<struct FName, struct FName> CellToLevelStreamingPackage; // 0xa0(0x50)
};

// Class Engine.WorldPartitionRuntimeSpatialHash
// Size: 0xb0 (Inherited: 0x30)
struct UWorldPartitionRuntimeSpatialHash : UWorldPartitionRuntimeHash {
	bool bEnableZCulling; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct TArray<struct FSpatialHashStreamingGrid> StreamingGrids; // 0x38(0x10)
	char pad_48[0x58]; // 0x48(0x58)
	struct TArray<struct TWeakObjectPtr<struct URuntimeSpatialHashExternalStreamingObject>> ExternalStreamingObjects; // 0xa0(0x10)
};

// Class Engine.WorldPartitionSubsystem
// Size: 0xb0 (Inherited: 0x40)
struct UWorldPartitionSubsystem : UTickableWorldSubsystem {
	char pad_40[0x70]; // 0x40(0x70)

	bool IsStreamingCompleted(enum class EWorldPartitionRuntimeCellState QueryState, struct TArray<struct FWorldPartitionStreamingQuerySource>& QuerySources, bool bExactState); // Function Engine.WorldPartitionSubsystem.IsStreamingCompleted // (None) // @ game+0xffffd2eedf830041
};

// Class Engine.WorldPartitionVolume
// Size: 0x2c8 (Inherited: 0x2c8)
struct AWorldPartitionVolume : AVolume {
	enum class EBrushType BrushType; // 0x290(0x01)
	struct FColor BrushColor; // 0x294(0x04)
	int32_t PolyFlags; // 0x298(0x04)
	char bColored : 1; // 0x29c(0x01)
	char bSolidWhenSelected : 1; // 0x29c(0x01)
	char bPlaceableFromClassBrowser : 1; // 0x29c(0x01)
	char bNotForClientOrServer : 1; // 0x29c(0x01)
	struct UModel* Brush; // 0x2a0(0x08)
	struct UBrushComponent* BrushComponent; // 0x2a8(0x08)
	char bInManipulation : 1; // 0x2b0(0x01)
	struct TArray<struct FGeomSelection> SavedSelections; // 0x2b8(0x10)
};

