// BlueprintGeneratedClass BP_GhostTrailActor_Invisibility.BP_GhostTrailActor_Invisibility_C
// Size: 0x3e8 (Inherited: 0x3e8)
struct ABP_GhostTrailActor_Invisibility_C : ADCGhostTrailActor {
	struct UMaterialInterface* GhostTrailMaterial; // 0x2f0(0x08)
	struct FName ScalarParameterName; // 0x2f8(0x08)
	struct UCurveFloat* OpacityCurve; // 0x300(0x08)
	struct ACharacter* CharacterRef; // 0x308(0x08)
	struct FLinearColor Color; // 0x310(0x10)
	bool bAutoActive; // 0x320(0x01)
	struct UPoseableMeshComponent* PoseableMeshComp; // 0x328(0x08)
	struct TArray<struct UMeshComponent*> AttachedMeshComp; // 0x330(0x10)
	struct USceneComponent* SceneRootComp; // 0x340(0x08)
	struct FTimeline OpacityTimeline; // 0x348(0x98)
	struct UMaterialInstanceDynamic* DynamicMatInstance; // 0x3e0(0x08)
};

