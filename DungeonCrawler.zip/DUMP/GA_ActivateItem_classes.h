// BlueprintGeneratedClass GA_ActivateItem.GA_ActivateItem_C
// Size: 0x5a0 (Inherited: 0x598)
struct UGA_ActivateItem_C : UGA_ActivateItemBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x598(0x08)

	void AbilityActivated(struct FGameplayEventData TriggerEventData); // Function GA_ActivateItem.GA_ActivateItem_C.AbilityActivated // (None) // @ game+0xffff800adf830001
};

