// BlueprintGeneratedClass GA_BowReloadAmmoBase.GA_BowReloadAmmoBase_C
// Size: 0x588 (Inherited: 0x588)
struct UGA_BowReloadAmmoBase_C : UGA_ReloadAmmo_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x580(0x08)
};

