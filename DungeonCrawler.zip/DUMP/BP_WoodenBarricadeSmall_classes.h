// BlueprintGeneratedClass BP_WoodenBarricadeSmall.BP_WoodenBarricadeSmall_C
// Size: 0x498 (Inherited: 0x488)
struct ABP_WoodenBarricadeSmall_C : ABP_PropsActorBase_C {
	struct UDCGeometryCollectionComponent* GC_WoodenBarricadeSmall_Default; // 0x488(0x08)
	struct UStaticMeshComponent* StaticMesh; // 0x490(0x08)
};

