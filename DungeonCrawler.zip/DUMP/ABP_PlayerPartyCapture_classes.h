// AnimBlueprintGeneratedClass ABP_PlayerPartyCapture.ABP_PlayerPartyCapture_C
// Size: 0x418 (Inherited: 0x350)
struct UABP_PlayerPartyCapture_C : UDCPlayerCharacterLobbyAnimInstanceBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x350(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess; // 0x358(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base; // 0x360(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x368(0x20)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x388(0x48)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x3d0(0x48)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_PlayerPartyCapture.ABP_PlayerPartyCapture_C.AnimGraph // (None) // @ game+0x13634dfab0001
};

