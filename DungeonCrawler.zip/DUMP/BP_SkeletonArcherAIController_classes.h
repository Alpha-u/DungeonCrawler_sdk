// BlueprintGeneratedClass BP_SkeletonArcherAIController.BP_SkeletonArcherAIController_C
// Size: 0x458 (Inherited: 0x458)
struct ABP_SkeletonArcherAIController_C : ABP_SkeletonAIController_C {
	struct UBaseObject* BaseObject; // 0x410(0x08)
	struct FGameplayTagContainer TargetInvisibleStateTagContainer; // 0x438(0x20)
};

