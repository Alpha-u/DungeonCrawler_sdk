// Class ActorSequence.ActorSequence
// Size: 0x90 (Inherited: 0x68)
struct UActorSequence : UMovieSceneSequence {
	struct UMovieScene* MovieScene; // 0x68(0x08)
	struct FActorSequenceObjectReferenceMap ObjectReferences; // 0x70(0x20)
};

// Class ActorSequence.ActorSequenceComponent
// Size: 0xd0 (Inherited: 0xa0)
struct UActorSequenceComponent : UActorComponent {
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // 0xa0(0x20)
	struct UActorSequence* Sequence; // 0xc0(0x08)
	struct UActorSequencePlayer* SequencePlayer; // 0xc8(0x08)

	void StopSequence(); // Function ActorSequence.ActorSequenceComponent.StopSequence // (None) // @ game+0xffffb80ddf830041
};

// Class ActorSequence.ActorSequencePlayer
// Size: 0x4a8 (Inherited: 0x4a8)
struct UActorSequencePlayer : UMovieSceneSequencePlayer {
	struct TScriptInterface<IMovieSceneSequencePlayerObserver> Observer; // 0x220(0x10)
	struct FMulticastInlineDelegate OnPlay; // 0x230(0x10)
	struct FMulticastInlineDelegate OnPlayReverse; // 0x240(0x10)
	struct FMulticastInlineDelegate OnStop; // 0x250(0x10)
	struct FMulticastInlineDelegate OnPause; // 0x260(0x10)
	struct FMulticastInlineDelegate OnFinished; // 0x270(0x10)
	enum class EMovieScenePlayerStatus Status; // 0x280(0x01)
	char bReversePlayback : 1; // 0x284(0x01)
	struct UMovieSceneSequence* Sequence; // 0x288(0x08)
	struct FFrameNumber StartTime; // 0x290(0x04)
	int32_t DurationFrames; // 0x294(0x04)
	float DurationSubFrames; // 0x298(0x04)
	int32_t CurrentNumLoops; // 0x29c(0x04)
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // 0x2a0(0x20)
	struct FMovieSceneRootEvaluationTemplateInstance RootTemplateInstance; // 0x2c0(0x88)
	struct FMovieSceneSequenceReplProperties NetSyncProps; // 0x3d0(0x10)
	struct TScriptInterface<IMovieScenePlaybackClient> PlaybackClient; // 0x3e0(0x10)
	struct UMovieSceneSequenceTickManager* TickManager; // 0x3f0(0x08)
};

