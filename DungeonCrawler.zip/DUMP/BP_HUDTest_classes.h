// BlueprintGeneratedClass BP_HUDTest.BP_HUDTest_C
// Size: 0x390 (Inherited: 0x380)
struct ABP_HUDTest_C : AHUD {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x380(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x388(0x08)

	void ReceiveBeginPlay(); // Function BP_HUDTest.BP_HUDTest_C.ReceiveBeginPlay // (None) // @ game+0x168afdfab0001
};

