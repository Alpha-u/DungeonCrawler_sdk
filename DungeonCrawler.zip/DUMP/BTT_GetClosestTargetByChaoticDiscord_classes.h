// BlueprintGeneratedClass BTT_GetClosestTargetByChaoticDiscord.BTT_GetClosestTargetByChaoticDiscord_C
// Size: 0xc8 (Inherited: 0xa8)
struct UBTT_GetClosestTargetByChaoticDiscord_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	struct ABP_DCMonsterBaseWithOptions_C* As BP DCMonster Base With Options; // 0xb0(0x08)
	struct TArray<struct ADCCharacterBase*> Target Array; // 0xb8(0x10)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_GetClosestTargetByChaoticDiscord.BTT_GetClosestTargetByChaoticDiscord_C.ReceiveExecuteAI // (None) // @ game+0xffff8009df830000
};

