// ScriptStruct ABP_PlayerCharacterPreview.ABP_PlayerCharacterPreview_C.AnimBlueprintGeneratedMutableData
// Size: 0x01 (Inherited: 0x01)
struct FAnimBlueprintGeneratedMutableData : FAnimBlueprintMutableData {
};

// ScriptStruct ABP_PlayerCharacterPreview.ABP_PlayerCharacterPreview_C.AnimBlueprintGeneratedConstantData
// Size: 0x128 (Inherited: 0x01)
struct FAnimBlueprintGeneratedConstantData : FAnimBlueprintConstantData {
	char pad_1[0x3]; // 0x01(0x03)
	struct FName __NameProperty_47; // 0x04(0x08)
	bool __BoolProperty_48; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	struct FName __NameProperty_49; // 0x10(0x08)
	struct FName __NameProperty_50; // 0x18(0x08)
	int32_t __IntProperty_51; // 0x20(0x04)
	float __FloatProperty_52; // 0x24(0x04)
	struct FInputScaleBiasClampConstants __StructProperty_53; // 0x28(0x2c)
	float __FloatProperty_54; // 0x54(0x04)
	bool __BoolProperty_55; // 0x58(0x01)
	enum class EAnimSyncMethod __EnumProperty_56; // 0x59(0x01)
	enum class EAnimGroupRole __ByteProperty_57; // 0x5a(0x01)
	char pad_5B[0x1]; // 0x5b(0x01)
	struct FName __NameProperty_58; // 0x5c(0x08)
	struct FName __NameProperty_59; // 0x64(0x08)
	int32_t __IntProperty_60; // 0x6c(0x04)
	struct FAnimNodeFunctionRef __StructProperty_61; // 0x70(0x20)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess; // 0x90(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base; // 0x110(0x18)
};

