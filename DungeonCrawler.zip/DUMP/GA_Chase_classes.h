// BlueprintGeneratedClass GA_Chase.GA_Chase_C
// Size: 0x580 (Inherited: 0x558)
struct UGA_Chase_C : UDCGameplayAbilityBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x558(0x08)
	struct AActor* GameplayTagCollider; // 0x560(0x08)
	double ChaseRange; // 0x568(0x08)
	struct FPrimaryAssetId PerkId; // 0x570(0x10)

	void OnMessageReceived_48415CF145A92DD77B9BB2ACD9934E4C(struct UMsgBaseNode* ProxyObject); // Function GA_Chase.GA_Chase_C.OnMessageReceived_48415CF145A92DD77B9BB2ACD9934E4C // (None) // @ game+0x79f0710
};

