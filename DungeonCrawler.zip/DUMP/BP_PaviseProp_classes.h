// BlueprintGeneratedClass BP_PaviseProp.BP_PaviseProp_C
// Size: 0x3e8 (Inherited: 0x3d0)
struct ABP_PaviseProp_C : APavisePropBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x3d0(0x08)
	struct UDCAkComponent* DCAk; // 0x3d8(0x08)
	struct USkeletalMeshComponent* SkeletalMesh; // 0x3e0(0x08)

	void EventFMsgSoundEvent(struct FMsgSoundEvent Msg); // Function BP_PaviseProp.BP_PaviseProp_C.EventFMsgSoundEvent // (None) // @ game+0xffff8009df830000
};

