// BlueprintGeneratedClass BP_ChaoticDiscord.BP_ChaoticDiscord_C
// Size: 0x3e0 (Inherited: 0x3e0)
struct ABP_ChaoticDiscord_C : ABP_MusicActor_C {
	struct USceneComponent* DefaultSceneRoot; // 0x3d8(0x08)
};

