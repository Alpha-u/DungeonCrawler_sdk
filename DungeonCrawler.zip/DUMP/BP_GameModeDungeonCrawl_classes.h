// BlueprintGeneratedClass BP_GameModeDungeonCrawl.BP_GameModeDungeonCrawl_C
// Size: 0x520 (Inherited: 0x520)
struct ABP_GameModeDungeonCrawl_C : ABP_GameModeDungeon_C {
	struct USceneComponent* DefaultSceneRoot; // 0x518(0x08)
};

