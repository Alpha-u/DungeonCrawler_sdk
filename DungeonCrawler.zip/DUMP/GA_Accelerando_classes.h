// BlueprintGeneratedClass GA_Accelerando.GA_Accelerando_C
// Size: 0x650 (Inherited: 0x610)
struct UGA_Accelerando_C : UGA_Music_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x610(0x08)
	struct FPrimaryAssetId GrantingAbilityId; // 0x618(0x10)
	struct FDCGameplayAbilityData OutGameplayAbilityData; // 0x628(0x28)

	void OnTargetActorOverlap_8AB6079E4C212704BEE6EDB016CC0932(struct TArray<struct AActor*>& RadiusInActors); // Function GA_Accelerando.GA_Accelerando_C.OnTargetActorOverlap_8AB6079E4C212704BEE6EDB016CC0932 // (None) // @ game+0xffff8009df830000
};

