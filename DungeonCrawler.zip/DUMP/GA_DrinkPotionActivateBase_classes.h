// BlueprintGeneratedClass GA_DrinkPotionActivateBase.GA_DrinkPotionActivateBase_C
// Size: 0x5a8 (Inherited: 0x5a0)
struct UGA_DrinkPotionActivateBase_C : UGA_ActivateItem_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5a0(0x08)

	void OnFinish_17D93366455B3BE35432FCBE8DFC6E4D(); // Function GA_DrinkPotionActivateBase.GA_DrinkPotionActivateBase_C.OnFinish_17D93366455B3BE35432FCBE8DFC6E4D // (None) // @ game+0xb053dfab0001
};

