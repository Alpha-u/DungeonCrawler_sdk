// ScriptStruct ABP_PlayerCharacterResurrection.ABP_PlayerCharacterResurrection_C.AnimBlueprintGeneratedConstantData
// Size: 0x110 (Inherited: 0x01)
struct FAnimBlueprintGeneratedConstantData : FAnimBlueprintConstantData {
	char pad_1[0x3]; // 0x01(0x03)
	struct FName __NameProperty_16; // 0x04(0x08)
	float __FloatProperty_17; // 0x0c(0x04)
	struct FInputScaleBiasClampConstants __StructProperty_18; // 0x10(0x2c)
	float __FloatProperty_19; // 0x3c(0x04)
	bool __BoolProperty_20; // 0x40(0x01)
	enum class EAnimSyncMethod __EnumProperty_21; // 0x41(0x01)
	enum class EAnimGroupRole __ByteProperty_22; // 0x42(0x01)
	char pad_43[0x1]; // 0x43(0x01)
	struct FName __NameProperty_23; // 0x44(0x08)
	struct FName __NameProperty_24; // 0x4c(0x08)
	int32_t __IntProperty_25; // 0x54(0x04)
	struct FAnimNodeFunctionRef __StructProperty_26; // 0x58(0x20)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess; // 0x78(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base; // 0xf8(0x18)
};

