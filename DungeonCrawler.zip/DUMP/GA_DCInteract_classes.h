// BlueprintGeneratedClass GA_DCInteract.GA_DCInteract_C
// Size: 0x6a0 (Inherited: 0x6a0)
struct UGA_DCInteract_C : UGA_Interact {
	struct UAnimMontage* MontageToPlayBothHandEquipped; // 0x558(0x08)
	struct UAnimMontage* MontageToPlayPrimaryEquipped; // 0x560(0x08)
	struct UAnimMontage* MontageToPlaySecondaryEquipped; // 0x568(0x08)
	struct UAnimMontage* MontageToPlayPrimaryEquippedInstant; // 0x570(0x08)
	struct UAnimMontage* MontageToPlaySecondaryEquippedInstant; // 0x578(0x08)
	struct FPrimaryAssetId CharacterStopMovementThresholdConstant; // 0x580(0x10)
	struct FPrimaryAssetId InteractionStartThresholdConstant; // 0x590(0x10)
	struct UDCAT_WaitDelayPausable* WaitDelayPausableTask; // 0x5a0(0x08)
	struct FRandomStream Stream; // 0x5a8(0x08)
	struct FInteractionData CurrentData; // 0x5b0(0x90)
	struct FDesignDataPropsSkillCheck CurrentSkillCheckData; // 0x640(0x30)
	struct FGameplayTag CurrentInteractTag; // 0x670(0x08)
	struct FGameplayTag CurrentStateTag; // 0x678(0x08)
	struct AActor* InteractTargetActor; // 0x680(0x08)
};

