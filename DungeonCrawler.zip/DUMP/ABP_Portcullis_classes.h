// AnimBlueprintGeneratedClass ABP_Portcullis.ABP_Portcullis_C
// Size: 0x668 (Inherited: 0x400)
struct UABP_Portcullis_C : UDCAnimInstanceBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x400(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess; // 0x408(0x08)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base; // 0x410(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x418(0x20)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x438(0x48)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x480(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x4a8(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x4d0(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x518(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x538(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x580(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x5a0(0xc8)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Portcullis.ABP_Portcullis_C.AnimGraph // (None) // @ game+0xffff8009df830000
};

