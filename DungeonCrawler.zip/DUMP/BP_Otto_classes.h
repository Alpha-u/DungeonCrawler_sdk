// BlueprintGeneratedClass BP_Otto.BP_Otto_C
// Size: 0x1160 (Inherited: 0x1140)
struct ABP_Otto_C : ABP_DCMonsterBaseWithOptions_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1140(0x08)
	struct TArray<struct AActor*> Interacters; // 0x1148(0x10)
	struct FGameplayTag Selection; // 0x1158(0x08)

	void RandomActionFromLie(); // Function BP_Otto.BP_Otto_C.RandomActionFromLie // (None) // @ game+0xffff800902622002
};

