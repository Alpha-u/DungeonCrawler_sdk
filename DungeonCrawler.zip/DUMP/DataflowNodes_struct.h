// ScriptStruct DataflowNodes.GetSkeletalMeshDataflowNode
// Size: 0xe0 (Inherited: 0xd0)
struct FGetSkeletalMeshDataflowNode : FDataflowNode {
	struct USkeletalMesh* SkeletalMesh; // 0xd0(0x08)
	struct FName PropertyName; // 0xd8(0x08)
};

// ScriptStruct DataflowNodes.SkeletalMeshBoneDataflowNode
// Size: 0xe8 (Inherited: 0xd0)
struct FSkeletalMeshBoneDataflowNode : FDataflowNode {
	struct FName BoneName; // 0xd0(0x08)
	struct USkeletalMesh* SkeletalMesh; // 0xd8(0x08)
	int32_t BoneIndexOut; // 0xe0(0x04)
	char pad_E4[0x4]; // 0xe4(0x04)
};

// ScriptStruct DataflowNodes.GetStaticMeshDataflowNode
// Size: 0xe0 (Inherited: 0xd0)
struct FGetStaticMeshDataflowNode : FDataflowNode {
	struct UStaticMesh* StaticMesh; // 0xd0(0x08)
	struct FName PropertyName; // 0xd8(0x08)
};

