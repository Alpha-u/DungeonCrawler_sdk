// BlueprintGeneratedClass BTT_CheckWallToCanMove.BTT_CheckWallToCanMove_C
// Size: 0xd0 (Inherited: 0xa8)
struct UBTT_CheckWallToCanMove_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)
	bool FromTarget; // 0xb0(0x01)
	char pad_B1[0x7]; // 0xb1(0x07)
	double DestAngle; // 0xb8(0x08)
	double DestDistance; // 0xc0(0x08)
	struct FName Key TargetActor; // 0xc8(0x08)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_CheckWallToCanMove.BTT_CheckWallToCanMove_C.ReceiveExecuteAI // (None) // @ game+0xffff8009df830040
};

