// UserDefinedEnum E_CompareNumber.E_CompareNumber
enum class E_CompareNumber : uint8 {
	NewEnumerator4 = 0,
	NewEnumerator5 = 1,
	NewEnumerator0 = 2,
	NewEnumerator1 = 3,
	NewEnumerator2 = 4,
	NewEnumerator3 = 5,
	E_MAX = 6
};

