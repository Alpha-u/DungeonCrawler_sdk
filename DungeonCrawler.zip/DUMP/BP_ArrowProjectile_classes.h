// BlueprintGeneratedClass BP_ArrowProjectile.BP_ArrowProjectile_C
// Size: 0x6b8 (Inherited: 0x6b0)
struct ABP_ArrowProjectile_C : ABP_ProjectileActor_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x6b0(0x08)

	void ReceiveBeginPlay(); // Function BP_ArrowProjectile.BP_ArrowProjectile_C.ReceiveBeginPlay // (None) // @ game+0xffff8009df830000
};

