// BlueprintGeneratedClass AN_ChangeNaviEffect.AN_ChangeNaviEffect_C
// Size: 0x39 (Inherited: 0x38)
struct UAN_ChangeNaviEffect_C : UAnimNotify {
	bool AffectNavigation; // 0x38(0x01)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, struct FAnimNotifyEventReference& EventReference); // Function AN_ChangeNaviEffect.AN_ChangeNaviEffect_C.Received_Notify // (None) // @ game+0xffff8ff9df830e20
};

